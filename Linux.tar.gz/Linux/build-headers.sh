#!/bin/bash


###################################################
## ARGS
KARCH=x86
ARCH=amd64

LINUX_VER=$(cat .config | grep 'Linux/x86' | awk '{print $3}' | sed 's/-.*//g')
# 建置版號 (可自訂)
KBUILD_BUILD_VERSION=1
KERNVER=${LINUX_VER}-${KBUILD_BUILD_VERSION}
PKGVER=$(echo ${LINUX_VER%.*}.0)-${KBUILD_BUILD_VERSION}
UNAMER=${PKGVER}-${ARCH}

###################################################
# Install headers
sed -i '/UTS_RELEASE/s/$(UNAMER)/$(KERNELRELEASE)/g' Makefile

find scripts \( -name .*.cmd -o -name *.o \) -execdir rm {} +
find tools/objtool \( -name .*.cmd -o -name *.o \) -execdir rm {} +
find include \( -name .*.cmd \) -execdir rm {} +

# Install headers
PKGDIR=$HOME/Build/linux-headers-${UNAMER}/usr/src/linux-headers-${UNAMER}

# linux 2014 -
mkdir -p ${PKGDIR}/kernel
mkdir -p ${PKGDIR}/arch/${KARCH}/kernel
mkdir -p ${PKGDIR}/drivers/md
mkdir -p ${PKGDIR}/net/mac80211
mkdir -p ${PKGDIR}/drivers/media/dvb-core
mkdir -p ${PKGDIR}/drivers/media/i2c
mkdir -p ${PKGDIR}/drivers/media/usb/dvb-usb
mkdir -p ${PKGDIR}/drivers/media/dvb-frontends
mkdir -p ${PKGDIR}/drivers/media/tuners


install -Dt ${PKGDIR} -m644 Makefile .config Module.symvers
install -Dt "${PKGDIR}/kernel" -m644 kernel/Makefile

cp -t "${PKGDIR}" -a include scripts

install -Dt "${PKGDIR}/arch/${KARCH}" -m644 arch/${KARCH}/Makefile
install -Dt "${PKGDIR}/arch/${KARCH}/kernel" -m644 arch/${KARCH}/kernel/asm-offsets.s

cp -t "${PKGDIR}/arch/${KARCH}" -a arch/${KARCH}/include

install -Dt "${PKGDIR}/drivers/md" -m644 drivers/md/*.h
install -Dt "${PKGDIR}/net/mac80211" -m644 net/mac80211/*.h
install -Dt "${PKGDIR}/drivers/media/dvb-core" -m644 drivers/media/dvb-core/*.h
install -Dt "${PKGDIR}/drivers/media/i2c" -m644 drivers/media/i2c/msp3400-driver.h
install -Dt "${PKGDIR}/drivers/media/usb/dvb-usb" -m644 drivers/media/usb/dvb-usb/*.h
install -Dt "${PKGDIR}/drivers/media/dvb-frontends" -m644 drivers/media/dvb-frontends/*.h
install -Dt "${PKGDIR}/drivers/media/tuners" -m644 drivers/media/tuners/*.h

mkdir -p "${PKGDIR}"/{fs/xfs,mm}

find . -name Makefile\* -exec install -Dm644 {} "${PKGDIR}/{}" \;
find . -name Kconfig\* -exec install -Dm644 {} "${PKGDIR}/{}" \;

install -Dt "${PKGDIR}/tools/objtool" tools/objtool/objtool

# remove unneeded architectures
for _arch in "${PKGDIR}"/arch/*/; do
    [[ ${_arch} == */${KARCH}/ ]] && continue
    rm -r "${_arch}"
done

# remove files already in linux-docs package
rm -r "${PKGDIR}/Documentation"
rm -r "${PKGDIR}/debian"

# remove now broken symlinks
find -L "${PKGDIR}" -type l -printf 'Removing %P\n' -delete

# Fix permissions
chmod -R u=rwX,go=rX "${PKGDIR}"

# strip scripts directory
while read -rd '' file; do
    case "$(file -bi "$file")" in
        application/x-sharedlib\;*)      # Libraries (.so)
            strip -v $STRIP_SHARED "$file" ;;
        application/x-archive\;*)        # Libraries (.a)
            strip -v $STRIP_STATIC "$file" ;;
        application/x-executable\;*)     # Binaries
            strip -v $STRIP_BINARIES "$file" ;;
        application/x-pie-executable\;*) # Relocatable binaries
            strip -v $STRIP_SHARED "$file" ;;
    esac
done < <(find "$PKGDIR" -type f -perm -u+x ! -name vmlinux -print0)

# Clean files
find ${PKGDIR} \( -name .*.cmd \) -execdir rm {} +
find ${PKGDIR} \( -name *.o \) -execdir rm {} +
find ${PKGDIR} \( -name .gitignore \) -execdir rm {} +

PKGDIR=$HOME/Build/linux-headers-${UNAMER}
mkdir -p ${PKGDIR}/lib/modules/${UNAMER}
ln -sf /usr/src/linux-headers-${UNAMER} ${PKGDIR}/lib/modules/${UNAMER}/build

########################################################
# Create DEB Package
########################################################
mkdir -p $PKGDIR/DEBIAN
PKGSIZE=$(du -s $PKGDIR | awk '{print $1}')

cat > $PKGDIR/DEBIAN/control << EOF
Package: linux-headers-${UNAMER}
Source: linux
Version: $KERNVER
Architecture: $ARCH
Maintainer: Kernel Team <kernel@kernel.org>
Installed-Size: $PKGSIZE
Section: kernel
Priority: optional
Homepage: https://www.kernel.org/
Description: Header files for Linux ${UNAMER}
 This package provides the architecture-specific kernel header files for
 Linux kernel ${UNAMER}, generally used for building out-of-tree kernel
 modules.  These files are going to be installed into
 /usr/src/linux-headers-${UNAMER}, and can be used for building modules
 that load into the kernel provided by the linux-image-${UNAMER}
 package.
EOF

sudo chown -R 0:0 $PKGDIR
sudo dpkg -b $PKGDIR $HOME/Build/linux-headers-${UNAMER}_${KERNVER}_${ARCH}.deb
