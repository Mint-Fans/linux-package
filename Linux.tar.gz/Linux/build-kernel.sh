#!/bin/bash


###################################################
# ARGS
KARCH=x86
ARCH=amd64

LINUX_VER=$(cat .config | grep 'Linux/x86' | awk '{print $3}' | sed 's/-.*//g')
# 建置版號 (可自訂)
KBUILD_BUILD_VERSION=1
KERNVER=${LINUX_VER}-${KBUILD_BUILD_VERSION}
PKGVER=$(echo ${LINUX_VER%.*}.0)-${KBUILD_BUILD_VERSION}
UNAMER=${PKGVER}-${ARCH}

###################################################
# Install Kernel
PKGDIR=$HOME/Build/linux-image-${UNAMER}
install -D -m644 arch/x86/boot/bzImage $PKGDIR/boot/vmlinuz-${UNAMER}
install -D -m644 .config $PKGDIR/boot/config-${UNAMER}
install -D -m644 System.map $PKGDIR/boot/System.map-${UNAMER}

# Install Modules
sed -i '/INSTALL_FW_PATH=/s/firmware/firmware\/$(UNAMER)/g' Makefile
PKGDIR=$HOME/Build/linux-image-${UNAMER}
export INSTALL_MOD_PATH=$PKGDIR
make -j$(nproc) INSTALL_MOD_STRIP=1 modules_install
mv $PKGDIR/lib/modules/* $PKGDIR/lib/modules/${UNAMER}
sed -i '/INSTALL_FW_PATH=/s/firmware\/$(UNAMER)/firmware/g' Makefile

# Install vdso
install -D -m644 arch/x86/entry/vdso/vdso64.so $PKGDIR/lib/modules/${UNAMER}/vdso/vdso64.so
install -D -m644 arch/x86/entry/vdso/vdso32.so $PKGDIR/lib/modules/${UNAMER}/vdso/vdso32.so
install -D -m644 arch/x86/entry/vdso/vdsox32.so $PKGDIR/lib/modules/${UNAMER}/vdso/vdsox32.so

rm -rf $PKGDIR/lib/modules/${UNAMER}/build
rm -rf $PKGDIR/lib/modules/${UNAMER}/source
rm -rf $PKGDIR/lib/modules/${UNAMER}/*.bin
rm -rf $PKGDIR/lib/modules/${UNAMER}/*.alias
rm -rf $PKGDIR/lib/modules/${UNAMER}/*dep
rm -rf $PKGDIR/lib/modules/${UNAMER}/*.devname
rm -rf $PKGDIR/lib/modules/${UNAMER}/*.symbols

########################################################
# Create DEB Package
########################################################
mkdir -p $PKGDIR/DEBIAN
PKGSIZE=$(du -s $PKGDIR | awk '{print $1}')

cat > $PKGDIR/DEBIAN/control << EOF
Package: linux-image-${UNAMER}
Source: linux
Priority: optional
Section: kernel
Installed-Size: $PKGSIZE
Maintainer: Kernel Team <kernel@kernel.org>
Architecture: $ARCH
Version: $KERNVER
Depends: kmod, linux-base, initramfs-tools | linux-initramfs-tool
Recommends: firmware-linux-free, irqbalance
Description: Linux ${LINUX_VER} for 64-bit PCs
 The Linux kernel ${LINUX_VER} and modules for use on PCs with AMD64, Intel 64 or
 VIA Nano processors.
 .
 This kernel also runs on a Xen hypervisor.  It supports both privileged
 (dom0) and unprivileged (domU) operation.
Homepage: https://www.kernel.org/
EOF

cat > $PKGDIR/DEBIAN/postinst << EOF
#!/bin/sh -e

version=${UNAMER}
image_path=/boot/vmlinuz-\$version

if [ "\$1" != configure ]; then
    exit 0
fi

depmod \$version

if [ -f /lib/modules/\$version/.fresh-install ]; then
    change=install
else
    change=upgrade
fi
linux-update-symlinks \$change \$version \$image_path
rm -f /lib/modules/\$version/.fresh-install

if [ -d /etc/kernel/postinst.d ]; then
    DEB_MAINT_PARAMS="\$*" run-parts --report --exit-on-error --arg=\$version --arg=\$image_path /etc/kernel/postinst.d
fi

exit 0
EOF

cat > $PKGDIR/DEBIAN/postrm << EOF
#!/bin/sh -e

version=${UNAMER}
image_path=/boot/vmlinuz-\$version

rm -f /lib/modules/\$version/.fresh-install

if [ "\$1" != upgrade ] && command -v linux-update-symlinks >/dev/null; then
    linux-update-symlinks remove \$version \$image_path
fi

if [ -d /etc/kernel/postrm.d ]; then
    DEB_MAINT_PARAMS="\$*" run-parts --report --exit-on-error --arg=\$version --arg=\$image_path /etc/kernel/postrm.d
fi

if [ "\$1" = purge ]; then
    for extra_file in modules.dep modules.isapnpmap modules.pcimap \\
        modules.usbmap modules.parportmap \\
        modules.generic_string modules.ieee1394map \\
        modules.ieee1394map modules.pnpbiosmap \\
        modules.alias modules.ccwmap modules.inputmap \\
        modules.symbols modules.ofmap \\
        modules.seriomap modules.\*.bin \\
        modules.softdep modules.devname; do
        eval rm -f /lib/modules/\$version/\$extra_file
    done
    rmdir /lib/modules/\$version || true
fi

exit 0
EOF

cat > $PKGDIR/DEBIAN/preinst << EOF
#!/bin/sh -e

version=${UNAMER}
image_path=/boot/vmlinuz-\$version

if [ "\$1" = abort-upgrade ]; then
    exit 0
fi

if [ "\$1" = install ]; then
    # Create a flag file for postinst
    mkdir -p /lib/modules/\$version
    touch /lib/modules/\$version/.fresh-install
fi

if [ -d /etc/kernel/preinst.d ]; then
    DEB_MAINT_PARAMS="\$*" run-parts --report --exit-on-error --arg=\$version --arg=\$image_path /etc/kernel/preinst.d
fi

exit 0
EOF

cat > $PKGDIR/DEBIAN/prerm << EOF
#!/bin/sh -e

version=${UNAMER}
image_path=/boot/vmlinuz-\$version

if [ "\$1" != remove ]; then
    exit 0
fi

linux-check-removal \$version

if [ -d /etc/kernel/prerm.d ]; then
    DEB_MAINT_PARAMS="\$*" run-parts --report --exit-on-error --arg=\$version --arg=\$image_path /etc/kernel/prerm.d
fi

exit 0
EOF

chmod 755 $PKGDIR/DEBIAN/postinst $PKGDIR/DEBIAN/postrm $PKGDIR/DEBIAN/preinst $PKGDIR/DEBIAN/prerm

sudo chown -R 0:0 $PKGDIR
sudo dpkg -b $PKGDIR $HOME/Build/linux-image-${UNAMER}_${KERNVER}_${ARCH}.deb
