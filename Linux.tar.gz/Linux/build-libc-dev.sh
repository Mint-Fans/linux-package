#!/bin/bash


###################################################
# ARGS
KARCH=x86
ARCH=amd64

LINUX_VER=$(cat .config | grep 'Linux/x86' | awk '{print $3}' | sed 's/-.*//g')
# 建置版號 (可自訂)
KBUILD_BUILD_VERSION=1
KERNVER=${LINUX_VER}-${KBUILD_BUILD_VERSION}
PKGVER=$(echo ${LINUX_VER%.*}.0)-${KBUILD_BUILD_VERSION}
UNAMER=${PKGVER}-${ARCH}

###################################################
# Install libc-dev
PKGDIR=$HOME/Build/linux-libc-dev/usr

# HOST_MULTIARCH
# amd64 = x86_64-linux-gnu
# i386 = i386-linux-gnu
# armv4+ = arm-linux-gnueabi
# armv7 = arm-linux-gnueabihf
# armv8 = aarch64-linux-gnu
# HOST_MULTIARCH=x86_64-linux-gnu

# Install linux-libc-dev
make headers_install INSTALL_HDR_PATH=$PKGDIR

HOST_MULTIARCH=x86_64-linux-gnu
mkdir -p $PKGDIR/include/$HOST_MULTIARCH
cp -r $PKGDIR/include/asm $PKGDIR/include/$HOST_MULTIARCH

HOST_MULTIARCH=i386-linux-gnu
mkdir -p $PKGDIR/include/$HOST_MULTIARCH
mv $PKGDIR/include/asm $PKGDIR/include/$HOST_MULTIARCH

# Clean files
rm -rf $PKGDIR/include/drm $PKGDIR/include/scsi
find $PKGDIR/include \( -name .install -o -name ..install.cmd \) -execdir rm {} +
find $PKGDIR/include \( -name .check -o -name ..check.cmd \) -execdir rm {} +

########################################################
# Create DEB Package
########################################################
PKGDIR=$HOME/Build/linux-libc-dev
mkdir -p $PKGDIR/DEBIAN
PKGSIZE=$(du -s $PKGDIR | awk '{print $1}')

cat > $PKGDIR/DEBIAN/control << EOF
Package: linux-libc-dev
Source: linux
Version: $KERNVER
Architecture: $ARCH
Maintainer: Kernel Team <kernel@kernel.org>
Installed-Size: $PKGSIZE
Provides: linux-kernel-headers
Section: devel
Priority: optional
Multi-Arch: same
Homepage: https://www.kernel.org
Description: Linux support headers for userspace development
 .
EOF

sudo chown -R 0:0 $PKGDIR
sudo dpkg -b $PKGDIR $HOME/Build/linux-libc-dev_${KERNVER}_${ARCH}.deb

