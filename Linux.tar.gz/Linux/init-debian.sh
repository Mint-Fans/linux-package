#!/bin/bash

###################################################
## Debian / Kali
KARCH=x86
# ARCH=i386
ARCH=amd64

LINUX_VER=$(cat .config | grep 'Linux/x86' | awk '{print $3}' | sed 's/-.*//g')
# 建置版號 (可自訂)
KBUILD_BUILD_VERSION=1
KERNVER=${LINUX_VER}-${KBUILD_BUILD_VERSION}
PKGVER=$(echo ${LINUX_VER%.*}.0)-${KBUILD_BUILD_VERSION}
UNAMER=${PKGVER}-${ARCH}

export KBUILD_BUILD_VERSION=${KBUILD_BUILD_VERSION}
export UNAMER=${UNAMER}
export DISTRIBUTION_OFFICIAL_BUILD=${KBUILD_BUILD_VERSION}
export DISTRIBUTOR=Debian
export DISTRIBUTION_VERSION=${KERNVER}
export KBUILD_BUILD_VERSION_TIMESTAMP="${DISTRIBUTOR} ${DISTRIBUTION_VERSION} ($(date +%Y-%m-%d))"
export KBUILD_BUILD_USER=kernel
export KBUILD_BUILD_HOST=kernel.org

# edit scripts/mkcompile_h
# LINUX_COMPILER \"`$CC -v 2>&1 | grep ' version '`\"
# to
# LINUX_COMPILER \"`$CC -v 2>&1 | grep ' version ' | sed 's/ (.*//'`\"

sed -i '/UTS_RELEASE/s/$(KERNELRELEASE)/$(UNAMER)/g' Makefile
