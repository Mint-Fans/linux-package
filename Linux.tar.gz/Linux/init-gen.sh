#!/bin/bash

########################################################
# Distribution config
########################################################
## General
KARCH=x86
# ARCH=i386
ARCH=amd64

LINUX_VER=$(cat .config | grep 'Linux/x86' | awk '{print $3}' | sed 's/-.*//g')
# 建置版號 (可自訂)
KBUILD_BUILD_VERSION=1
KERNVER=${LINUX_VER}-${KBUILD_BUILD_VERSION}
# PKGVER=${KERNVER}
PKGVER=$(echo ${LINUX_VER%.*}.0)-${KBUILD_BUILD_VERSION}
UNAMER=${PKGVER}-${ARCH}

BUILD_DATE="($(date +%Y-%m-%d))"
export DISTRIBUTOR="Linux LTS"

export UNAMER=${UNAMER}
export KBUILD_BUILD_VERSION=${KBUILD_BUILD_VERSION}
export KBUILD_BUILD_TIMESTAMP="${DISTRIBUTOR} ${KERNVER} ${BUILD_DATE}"
# export KBUILD_BUILD_TIMESTAMP="${BUILD_DATE}"
export KBUILD_BUILD_USER=kernel
export KBUILD_BUILD_HOST=kernel.org

sed -i '/UTS_RELEASE/s/$(KERNELRELEASE)/$(UNAMER)/g' Makefile
