Module DateTrans
    '����p��
    Public SolarYear, SolarMonth, SolarDay, SolarHour, SolarMinute As Integer
    Public SolarCalendar(5), schindex, datedown As Integer

    '����p��
    Dim LunarIndex As Integer
    Dim LunarList As String
    Dim AddYear, AddMonth, AddDay, AddHour As Integer
    Public LunarYear, LunarMonth, LunarDay, LunarHour, LunarLeap As Integer
    Public MonthIn, DayIn As Integer
    Public MonthOut, DayOut, LeapOut As String

    '�`��z��p��
    '����P/�����P
    Public YTK, DTK, ONE_MTK, ONE_HTK As Integer
    '�`���
    Public STM_LINE, CDAY, CSLING_DAY, CSTM_DAY, CSTM_HOUR, CSTM_MINUTE, BSTM_DAY, BSTM_HOUR, BSTM_MINUTE As Integer
    Public SolarTerm, Current_SolarTerm As String
    '�Ѥz�a��
    'GanZhi(1-4 �`��~����,1�Ѥz 2�a�� | 5 ����,1 �Ѥz 2 �a��)
    Public GanZhi(5, 2) As Integer


    '�ϥΪ̸��
    'BirthData(1-5�~���ɤ�, 1-4���� ���� �Ѥz �a�� | 5,1 ������� | 6,1 �����Ѥz 6,2 �����a�� | 7,1 ���� 7,2 �k�k)
    Public BirthData(7, 4), ppc As Integer
    Public UserName As String

    '�@��
    Public UpTime, DownTime, ProperN(2, 12) As String
    Dim i As Integer
    '=================================================================================
    '================== ����p��
    '=================================================================================
    Sub SolarCLC()
        Dim dfd, d1 As String
        Dim MAX_DAY, n As Integer
        datedown = 0
        '�C���ƭp��
        If SolarCalendar(2) = 0 Or SolarCalendar(2) = 1 Or SolarCalendar(2) = 3 Or SolarCalendar(2) = 5 Or SolarCalendar(2) = 7 Or SolarCalendar(2) = 8 Or SolarCalendar(2) = 10 Or SolarCalendar(2) = 12 Or SolarCalendar(2) = 13 Then MAX_DAY = 32
        If SolarCalendar(2) = 4 Or SolarCalendar(2) = 6 Or SolarCalendar(2) = 9 Or SolarCalendar(2) = 11 Then MAX_DAY = 31
        '2����|�~�h�@��
        If SolarCalendar(2) = 2 Then
            If SolarCalendar(1) Mod 4 = 0 Then
                If SolarCalendar(1) = 1900 Then
                    MAX_DAY = 29
                Else
                    MAX_DAY = 30
                End If
            Else
                MAX_DAY = 29
            End If
        End If

        '�ثe�ɶ�
        dfd = DateSerial(SolarCalendar(1), SolarCalendar(2), SolarCalendar(3))
        '�ثe�ɶ���̱߮ɶ��I
        If DateDiff("d", dfd, UpTime) < 0 Then
            '�]�m�ɶ����̱߮ɶ��I
            SolarCalendar(1) = DatePart("yyyy", UpTime) : SolarCalendar(2) = DatePart("m", UpTime) : SolarCalendar(3) = DatePart("d", UpTime)
            '�ثe�ɶ���̦��ɶ��I
        ElseIf DateDiff("d", dfd, DownTime) > 0 Then
            datedown = 1 '�~�����s DownTime �ץ�
            '�]�m�ɶ����̦��ɶ��I
            SolarCalendar(1) = DatePart("yyyy", DownTime) : SolarCalendar(2) = DatePart("m", DownTime) : SolarCalendar(3) = DatePart("d", DownTime)
        Else
            '�����O�h����
            Select Case schindex
                Case 0 '�~
                Case 1 '��
                    '�p�G�뵥��13 �P �~�p��2099
                    If SolarCalendar(2) = 13 And SolarCalendar(1) < 2099 Then
                        d1 = DateAdd("m", 1, DateSerial(SolarCalendar(1), 12, SolarCalendar(3)))
                        SolarCalendar(1) = DatePart("YYYY", d1) : SolarCalendar(2) = DatePart("M", d1) : SolarCalendar(3) = DatePart("D", d1)
                    End If
                    '�p�G�뵥��0�P �~�j��1091
                    If SolarCalendar(2) = 0 And SolarCalendar(1) > 1901 Then
                        d1 = DateAdd("m", -1, DateSerial(SolarCalendar(1), 1, SolarCalendar(3)))
                        SolarCalendar(1) = DatePart("YYYY", d1) : SolarCalendar(2) = DatePart("M", d1) : SolarCalendar(3) = DatePart("D", d1)
                    End If

                    n = MAX_DAY - 1
                    If SolarCalendar(3) > n Then SolarCalendar(3) = n

                Case 2 '��
                    '�p�G�鵥��MaxDay �P �~�p��2099
                    If SolarCalendar(3) = MAX_DAY And SolarCalendar(1) < 2099 Then
                        n = MAX_DAY - 1
                        d1 = DateAdd("D", 1, DateSerial(SolarCalendar(1), SolarCalendar(2), n))
                        SolarCalendar(1) = DatePart("YYYY", d1) : SolarCalendar(2) = DatePart("M", d1) : SolarCalendar(3) = DatePart("D", d1)
                    End If
                    '�p�G�鵥��0 �P �~�j��1091
                    If SolarCalendar(3) = 0 And SolarCalendar(1) > 1901 Then
                        d1 = DateAdd("D", -1, DateSerial(SolarCalendar(1), SolarCalendar(2), 1))
                        SolarCalendar(1) = DatePart("YYYY", d1) : SolarCalendar(2) = DatePart("M", d1) : SolarCalendar(3) = DatePart("D", d1)
                    End If

                Case 3 '��
                    If SolarCalendar(4) > 23 And SolarCalendar(1) < 2099 Then
                        d1 = DateAdd("D", 1, DateSerial(SolarCalendar(1), SolarCalendar(2), SolarCalendar(3)))
                        SolarCalendar(1) = DatePart("YYYY", d1) : SolarCalendar(2) = DatePart("M", d1) : SolarCalendar(3) = DatePart("D", d1) : SolarCalendar(4) = 0
                    End If
                    If SolarCalendar(4) < 0 Then
                        d1 = DateAdd("D", -1, DateSerial(SolarCalendar(1), SolarCalendar(2), SolarCalendar(3)))
                        SolarCalendar(1) = DatePart("YYYY", d1) : SolarCalendar(2) = DatePart("M", d1) : SolarCalendar(3) = DatePart("D", d1) : SolarCalendar(4) = 23
                    End If
                Case 4 '��
                    If SolarCalendar(5) > 59 And SolarCalendar(1) < 2099 Then
                        SolarCalendar(4) = SolarCalendar(4) + 1
                        SolarCalendar(5) = 0
                    End If
                    If SolarCalendar(5) < 0 Then
                        SolarCalendar(4) = SolarCalendar(4) - 1
                        SolarCalendar(5) = 59
                    End If
            End Select
        End If

    End Sub
    '=================================================================================
    '================== ����p��
    '=================================================================================
    Sub LunarTable()
        '����j�p��δ��ӷ����
        '�榡:
        '1-12�A��j�p�� 0=�p29�� 1=�j30��
        '13�A��|��j�p 0=�p29�� 1=�j30��
        '14�A��|����
        '1516�����~�W��� '1718�����~�W���
        Select Case LunarIndex
            Case 1900 : LunarList = "010010111101080131"
            Case 1901 : LunarList = "010010101110000219"
            Case 1902 : LunarList = "101001010111000208"
            Case 1903 : LunarList = "010101001101050129"
            Case 1904 : LunarList = "110100100110000216"
            Case 1905 : LunarList = "110110010101000204"
            Case 1906 : LunarList = "011001010101140125"
            Case 1907 : LunarList = "010101101010000213"
            Case 1908 : LunarList = "100110101101000202"
            Case 1909 : LunarList = "010101011101020122"
            Case 1910 : LunarList = "010010101110000210"
            Case 1911 : LunarList = "101001011011060130"
            Case 1912 : LunarList = "101001001101000218"
            Case 1913 : LunarList = "110100100101000206"
            Case 1914 : LunarList = "110100101001150126"
            Case 1915 : LunarList = "101101010100000214"
            Case 1916 : LunarList = "110101101010000203"
            Case 1917 : LunarList = "101011011010020123"
            Case 1918 : LunarList = "100101011011000211"
            Case 1919 : LunarList = "010010010111170201"
            Case 1920 : LunarList = "010010011011000220"
            Case 1921 : LunarList = "101001001011000208"
            Case 1922 : LunarList = "101101001011050128"
            Case 1923 : LunarList = "011010100101000216"
            Case 1924 : LunarList = "011011010100000205"
            Case 1925 : LunarList = "101010110101140124"
            Case 1926 : LunarList = "001010110110000213"
            Case 1927 : LunarList = "100101010111000202"
            Case 1928 : LunarList = "010100101111020123"
            Case 1929 : LunarList = "010010010111000210"
            Case 1930 : LunarList = "011001010110060130"
            Case 1931 : LunarList = "110101001010000217"
            Case 1932 : LunarList = "111010100101000206"
            Case 1933 : LunarList = "011010101001150126"
            Case 1934 : LunarList = "010110101101000214"
            Case 1935 : LunarList = "001010110110000204"
            Case 1936 : LunarList = "100001101110130124"
            Case 1937 : LunarList = "100100101110000211"
            Case 1938 : LunarList = "110010001101170131"
            Case 1939 : LunarList = "110010010101000219"
            Case 1940 : LunarList = "110101001010000208"
            Case 1941 : LunarList = "110110001010160127"
            Case 1942 : LunarList = "101101010101000215"
            Case 1943 : LunarList = "010101101010000205"
            Case 1944 : LunarList = "101001011011140125"
            Case 1945 : LunarList = "001001011101000213"
            Case 1946 : LunarList = "100100101101000202"
            Case 1947 : LunarList = "110100101011020122"
            Case 1948 : LunarList = "101010010101000210"
            Case 1949 : LunarList = "101101010101070129"
            Case 1950 : LunarList = "011011001010000217"
            Case 1951 : LunarList = "101101010101000206"
            Case 1952 : LunarList = "010100110101150127"
            Case 1953 : LunarList = "010011011010000214"
            Case 1954 : LunarList = "101001011011000203"
            Case 1955 : LunarList = "010001010111130124"
            Case 1956 : LunarList = "010100101011000212"
            Case 1957 : LunarList = "101010011010080131"
            Case 1958 : LunarList = "111010010101000218"
            Case 1959 : LunarList = "011010101010000208"
            Case 1960 : LunarList = "101011101010060128"
            Case 1961 : LunarList = "101010110101000215"
            Case 1962 : LunarList = "010010110110000205"
            Case 1963 : LunarList = "101010101110040125"
            Case 1964 : LunarList = "101001010111000213"
            Case 1965 : LunarList = "010100100110000202"
            Case 1966 : LunarList = "111100100110030121"
            Case 1967 : LunarList = "110110010101000209"
            Case 1968 : LunarList = "010110110101070130"
            Case 1969 : LunarList = "010101101010000217"
            Case 1970 : LunarList = "100101101101000206"
            Case 1971 : LunarList = "010011011101050127"
            Case 1972 : LunarList = "010010101101000215"
            Case 1973 : LunarList = "101001001101000203"
            Case 1974 : LunarList = "110101001101040123"
            Case 1975 : LunarList = "110100100101000211"
            Case 1976 : LunarList = "110101010101080131"
            Case 1977 : LunarList = "101101010100000218"
            Case 1978 : LunarList = "101101101010000207"
            Case 1979 : LunarList = "100101011010160128"
            Case 1980 : LunarList = "100101011011000216"
            Case 1981 : LunarList = "010010011011000205"
            Case 1982 : LunarList = "101010010111040125"
            Case 1983 : LunarList = "101001001011000213"
            Case 1984 : LunarList = "1011001001110A0202"
            Case 1985 : LunarList = "011010100101000220"
            Case 1986 : LunarList = "011011010100000209"
            Case 1987 : LunarList = "101011110100060129"
            Case 1988 : LunarList = "101010110110000217"
            Case 1989 : LunarList = "100101010111000206"
            Case 1990 : LunarList = "010010101111050127"
            Case 1991 : LunarList = "010010010111000215"
            Case 1992 : LunarList = "011001001011000204"
            Case 1993 : LunarList = "011101001010030123"
            Case 1994 : LunarList = "111010100101000210"
            Case 1995 : LunarList = "011010110101080131"
            Case 1996 : LunarList = "010110101100000219"
            Case 1997 : LunarList = "101010110110000207"
            Case 1998 : LunarList = "100101101101050128"
            Case 1999 : LunarList = "100100101110000216"
            Case 2000 : LunarList = "110010010110000205"
            Case 2001 : LunarList = "110110010101040124"
            Case 2002 : LunarList = "110101001010000212"
            Case 2003 : LunarList = "110110100101000201"
            Case 2004 : LunarList = "011101010101020122"
            Case 2005 : LunarList = "010101101010000209"
            Case 2006 : LunarList = "101010111011070129"
            Case 2007 : LunarList = "001001011101000218"
            Case 2008 : LunarList = "100100101101000207"
            Case 2009 : LunarList = "110010101011050126"
            Case 2010 : LunarList = "101010010101000214"
            Case 2011 : LunarList = "101101001010000203"
            Case 2012 : LunarList = "101110101010040123"
            Case 2013 : LunarList = "101011010101000210"
            Case 2014 : LunarList = "010101011101090131"
            Case 2015 : LunarList = "010010111010000219"
            Case 2016 : LunarList = "101001011011000208"
            Case 2017 : LunarList = "010100010111160128"
            Case 2018 : LunarList = "010100101011000216"
            Case 2019 : LunarList = "101010010011000205"
            Case 2020 : LunarList = "011110010101040125"
            Case 2021 : LunarList = "011010101010000212"
            Case 2022 : LunarList = "101011010101000201"
            Case 2023 : LunarList = "010110110101020122"
            Case 2024 : LunarList = "010010110110000210"
            Case 2025 : LunarList = "101001101110060129"
            Case 2026 : LunarList = "101001001110000217"
            Case 2027 : LunarList = "110100100110000206"
            Case 2028 : LunarList = "111010100110050126"
            Case 2029 : LunarList = "110101010011000213"
            Case 2030 : LunarList = "010110101010000203"
            Case 2031 : LunarList = "011101101010030123"
            Case 2032 : LunarList = "100101101101000211"
            Case 2033 : LunarList = "010010101111070131"
            Case 2034 : LunarList = "010010101101000219"
            Case 2035 : LunarList = "101001001101000208"
            Case 2036 : LunarList = "110100001011160128"
            Case 2037 : LunarList = "110100100101000215"
            Case 2038 : LunarList = "110101010010000204"
            Case 2039 : LunarList = "110111010100050124"
            Case 2040 : LunarList = "101101011010000212"
            Case 2041 : LunarList = "010101101101000201"
            Case 2042 : LunarList = "010101011011020122"
            Case 2043 : LunarList = "010010011011000210"
            Case 2044 : LunarList = "101001010111070130"
            Case 2045 : LunarList = "101001001011000217"
            Case 2046 : LunarList = "101010100101000206"
            Case 2047 : LunarList = "101100100101150126"
            Case 2048 : LunarList = "011011010010000214"
            Case 2049 : LunarList = "101011011010000202"
            Case 2050 : LunarList = "010010110110130123"
            Case 2051 : LunarList = "100100110111000211"
            Case 2052 : LunarList = "010010011111080201"
            Case 2053 : LunarList = "010010010111000219"
            Case 2054 : LunarList = "011001001011000208"
            Case 2055 : LunarList = "011010001010160128"
            Case 2056 : LunarList = "111010100101000215"
            Case 2057 : LunarList = "011010101010000204"
            Case 2058 : LunarList = "101001101100140124"
            Case 2059 : LunarList = "101010101110000212"
            Case 2060 : LunarList = "100100101110000202"
            Case 2061 : LunarList = "110100101110030121"
            Case 2062 : LunarList = "110010010110000209"
            Case 2063 : LunarList = "110101010101070129"
            Case 2064 : LunarList = "110101001010000217"
            Case 2065 : LunarList = "110110100101000205"
            Case 2066 : LunarList = "010111010101050126"
            Case 2067 : LunarList = "010101101010000214"
            Case 2068 : LunarList = "101001101101000203"
            Case 2069 : LunarList = "010101011101040123"
            Case 2070 : LunarList = "010100101101000211"
            Case 2071 : LunarList = "101010011011080131"
            Case 2072 : LunarList = "101010010101000219"
            Case 2073 : LunarList = "101101001010000207"
            Case 2074 : LunarList = "101101101010060127"
            Case 2075 : LunarList = "101011010101000215"
            Case 2076 : LunarList = "010101011010000205"
            Case 2077 : LunarList = "101010111010040124"
            Case 2078 : LunarList = "101001011011000212"
            Case 2079 : LunarList = "010100101011000202"
            Case 2080 : LunarList = "101100100111030122"
            Case 2081 : LunarList = "011010010011000209"
            Case 2082 : LunarList = "011100110011070129"
            Case 2083 : LunarList = "011010101010000217"
            Case 2084 : LunarList = "101011010101000206"
            Case 2085 : LunarList = "010010110101150126"
            Case 2086 : LunarList = "010010110110000214"
            Case 2087 : LunarList = "101001010111000203"
            Case 2088 : LunarList = "010101001110040124"
            Case 2089 : LunarList = "110100010110000210"
            Case 2090 : LunarList = "111010010110080130"
            Case 2091 : LunarList = "110101010010000218"
            Case 2092 : LunarList = "110110101010000207"
            Case 2093 : LunarList = "011010101010160127"
            Case 2094 : LunarList = "010101101101000215"
            Case 2095 : LunarList = "010010101110000205"
            Case 2096 : LunarList = "101010011101040125"
            Case 2097 : LunarList = "101000101101000212"
            Case 2098 : LunarList = "110100010101000201"
            Case 2099 : LunarList = "111100100101020121"
            Case 2100 : LunarList = "110101010010000209"
        End Select

    End Sub
    Function GetYLDate(ByVal tYear As Integer, ByVal tMonth As Integer, ByVal tDay As Integer) As String
        On Error Resume Next
        Dim conDate As Date, setDate As Date
        Dim getDay As Integer
        Dim RunYue As Boolean

        '�p�G���O���Ħ�����A�h�X
        'If tYear > 2099 Or tYear < 1901 Then Return 0

        AddYear = tYear
        RunYue = False

CHUSHIHUA:
        LunarIndex = AddYear
        LunarTable()
        AddMonth = Val(Mid(LunarList, 15, 2)) '���
        AddDay = Val(Mid(LunarList, 17, 2)) '���
        conDate = DateSerial(AddYear, AddMonth, AddDay)
        setDate = DateSerial(tYear, tMonth, tDay)
        getDay = DateDiff("d", conDate, setDate)

        If getDay < 0 Then AddYear = AddYear - 1 : GoTo CHUSHIHUA

        LunarIndex = AddYear
        LunarTable()

        '����p��
        AddDay = 1 : AddMonth = 1

        'getDay �����߬K��� - �ثe����Ѽ�
        For i = 1 To getDay
            AddDay = AddDay + 1

            '�D�|����
            If RunYue = False Then
                If AddDay = 30 + Mid(LunarList, AddMonth, 1) Then '�D�|�����j�p����
                    AddDay = 1 '�^���@

                    '�ˬd�O�_�|����
                    If AddMonth = Val("&H" & Mid(LunarList, 14, 1)) Then
                        RunYue = True
                    Else
                        RunYue = False
                        AddMonth = AddMonth + 1 '��� +1
                    End If

                End If
            Else
                '�|����
                If AddDay = 30 + Mid(LunarList, 13, 1) Then '�|�����j�p����
                    RunYue = False
                    AddMonth = AddMonth + 1 '��� +1
                    AddDay = 1 '�^���@
                End If
            End If

        Next

        If RunYue = True Then LunarLeap = 2 Else LunarLeap = 1

    End Function

    '=================================================================================
    '================== �������ഫ������
    '=================================================================================
    Sub Date_Trans()
        Dim tya, tma, tda, tha As Integer

        '����p��
        tya = SolarYear : tma = SolarMonth : tda = SolarDay : tha = SolarHour
        If tha > 22 Then tda = tda + 1 : tha = 0
        AddHour = ((tha + 1) \ 2) + 1
        GetYLDate(tya, tma, tda)
        LunarYear = AddYear : LunarMonth = AddMonth : LunarDay = AddDay : LunarHour = AddHour

        SolarTerm_Trans() '�`���ഫ

    End Sub
    '=================================================================================
    '=== ������r��
    '=================================================================================
    Sub LunarToStr()

        If LunarLeap = 2 Then LeapOut = "�|" Else LeapOut = ""

        Select Case MonthIn
            Case 1 : MonthOut = "��"
            Case 2 : MonthOut = "�G"
            Case 3 : MonthOut = "�T"
            Case 4 : MonthOut = "�|"
            Case 5 : MonthOut = "��"
            Case 6 : MonthOut = "��"
            Case 7 : MonthOut = "�C"
            Case 8 : MonthOut = "�K"
            Case 9 : MonthOut = "�E"
            Case 10 : MonthOut = "�Q"
            Case 11 : MonthOut = "�Q�@"
            Case 12 : MonthOut = "�Q�G"
        End Select

        Select Case DayIn
            Case 1 : DayOut = "��@"
            Case 2 : DayOut = "��G"
            Case 3 : DayOut = "��T"
            Case 4 : DayOut = "��|"
            Case 5 : DayOut = "�줭"
            Case 6 : DayOut = "�줻"
            Case 7 : DayOut = "��C"
            Case 8 : DayOut = "��K"
            Case 9 : DayOut = "��E"
            Case 10 : DayOut = "��Q"
            Case 11 : DayOut = "�Q�@"
            Case 12 : DayOut = "�Q�G"
            Case 13 : DayOut = "�Q�T"
            Case 14 : DayOut = "�Q�|"
            Case 15 : DayOut = "�Q��"
            Case 16 : DayOut = "�Q��"
            Case 17 : DayOut = "�Q�C"
            Case 18 : DayOut = "�Q�K"
            Case 19 : DayOut = "�Q�E"
            Case 20 : DayOut = "�G�Q"
            Case 21 : DayOut = "�ܤ@"
            Case 22 : DayOut = "�ܤG"
            Case 23 : DayOut = "�ܤT"
            Case 24 : DayOut = "�ܥ|"
            Case 25 : DayOut = "�ܤ�"
            Case 26 : DayOut = "�ܤ�"
            Case 27 : DayOut = "�ܤC"
            Case 28 : DayOut = "�ܤK"
            Case 29 : DayOut = "�ܤE"
            Case 30 : DayOut = "�T�Q"
        End Select

    End Sub

    '=================================================================================
    '================== �r���J
    '=================================================================================
    Sub ReadProperN()
        ProperN(1, 1) = "��"
        ProperN(1, 2) = "�A"
        ProperN(1, 3) = "��"
        ProperN(1, 4) = "�B"
        ProperN(1, 5) = "��"
        ProperN(1, 6) = "�v"
        ProperN(1, 7) = "��"
        ProperN(1, 8) = "��"
        ProperN(1, 9) = "��"
        ProperN(1, 10) = "��"

        ProperN(2, 1) = "�l"
        ProperN(2, 2) = "��"
        ProperN(2, 3) = "�G"
        ProperN(2, 4) = "�f"
        ProperN(2, 5) = "��"
        ProperN(2, 6) = "�x"
        ProperN(2, 7) = "��"
        ProperN(2, 8) = "��"
        ProperN(2, 9) = "��"
        ProperN(2, 10) = "��"
        ProperN(2, 11) = "��"
        ProperN(2, 12) = "��"

    End Sub

    '=================================================================================
    '================== ����P
    '=================================================================================
    Sub FiveTiger()
        Dim n As Integer
        n = YTK Mod 5
        ONE_MTK = ((n * 2) + 1) Mod 10
    End Sub

    '=================================================================================
    '================== �����P
    '=================================================================================
    Sub FiveMouse()
        Dim n As Integer
        n = DTK Mod 5
        ONE_HTK = (n * 2) - 1
    End Sub


    '=================================================================================
    '================== �`��/�z��p��
    '=================================================================================
    Sub SolarTerm_Trans()
        Dim n, tda, STM, STY, diff_minute, diff_day, TC, TC1, TC2, mstep, HTK As Integer
        Dim st As String
        Dim AddYearX, AddYearY As Integer
        Dim A1, A2, Current_Time As String
        Dim SolarTerm_Time, Center_SolarTerm_Time, CSTM, CCSTM As String

        '�p�ɳB�z
        '�H23�ɬ��j��l��
        If SolarHour > 22 Then tda = SolarDay + 1 Else tda = SolarDay
        If SolarHour = 24 Then SolarHour = 0

        '�����B�z
        If SolarMinute = 60 Then SolarMinute = 0
        If SolarMinute < 0 Then SolarMinute = 59

        '====== �ثe����ɶ� (�~/��/�� ��:��)
        A1 = DateSerial(SolarYear, SolarMonth, tda) '�ثe���
        Dim x, y, z As String
        x = SolarHour
        y = SolarMinute
        st = x + ":" + y
        Current_Time = A1 + " " + st

        '====== �~�W�B�z
        '��������
        'Ū�������~�W���/��� read daList 15 2num & daList 17 2num
        LunarIndex = SolarYear
        LunarTable()
        A2 = DateSerial(SolarYear, Val(Mid(LunarList, 15, 2)), Val(Mid(LunarList, 17, 2))) '�����@���~�W���

        '�߬K��`��ɶ��I
        STM = 2 '�߬K�b����2���
        READ_LINE = ((SolarYear - 1900) * 24) + ((STM * 2) - 1)
        GetSolarTermTime()
        SolarTerm_Time = JCPOINT

        '�����~�W
        'A2(���~�W���) - A1(�ثe���) �j��0�h�~��-1
        diff_day = DateDiff("d", A1, A2)
        If diff_day > 0 Then AddYearX = SolarYear - 1 Else AddYearX = SolarYear

        '�����Ѥz�a�� (�褸4�~���Ҥl�~)
        If AddYearX < 3 Then
            z = AddYearX + 60
        Else
            z = AddYearX
        End If
        n = (z - 3) Mod 60

        GanZhi(5, 1) = n Mod 10 : GanZhi(5, 2) = n Mod 12
        If GanZhi(5, 1) = 0 Then GanZhi(5, 1) = 10 '�����~�W�Ѥz
        If GanZhi(5, 2) = 0 Then GanZhi(5, 2) = 12 '�����~�W�a��

        '�`��~�W
        diff_minute = DateDiff("n", Current_Time, SolarTerm_Time)
        If diff_minute > 0 Then AddYearY = SolarYear - 1 Else AddYearY = SolarYear

        '�`��Ѥz�a��
        If AddYearX < 3 Then
            z = AddYearX + 60
        Else
            z = AddYearX
        End If
        n = (z - 3) Mod 60
        GanZhi(1, 1) = n Mod 10 : GanZhi(1, 2) = n Mod 12
        If GanZhi(1, 1) = 0 Then GanZhi(1, 1) = 10 '�`��~�W�Ѥz
        If GanZhi(1, 2) = 0 Then GanZhi(1, 2) = 12 '�`��~�W�a��

        '====== ��W�B�z
        '�H������ -1 ���`����
        '�����`���I
        STM = SolarMonth
        STY = SolarYear

        STM_LINE = ((STY - 1900) * 24) + ((STM * 2) - 1)
        READ_LINE = STM_LINE
        GetSolarTermTime()
        SolarTerm_Time = JCPOINT

        '�p�b�����`��e,���^���W�@�ӥ�`���I
        diff_minute = DateDiff("n", Current_Time, SolarTerm_Time)
        If diff_minute > 0 Then
            STM = STM - 1
            If STM < 1 Then STM = STM + 12

            '�p�⥻��`���I
            If SolarMonth = 1 Then
                STM_LINE = (((STY - 1) - 1900) * 24) + ((STM * 2) - 1)
                READ_LINE = STM_LINE
            Else
                STM_LINE = ((STY - 1900) * 24) + ((STM * 2) - 1)
                READ_LINE = STM_LINE
            End If

            GetSolarTermTime()
            SolarTerm_Time = JCPOINT
        End If

        'TC �A��`����
        TC = STM - 1

        'TC1 ����a��
        TC1 = TC + 2
        If TC1 > 12 Then TC1 = TC1 - 12

        '���ݸ`��
        CSTM = "" : CCSTM = ""
        Select Case TC1
            Case 1 '��ئa��l
                CSTM = "�j��" : CCSTM = "�V��"
            Case 2 '��ئa�䤡
                CSTM = "�p�H" : CCSTM = "�j�H"
            Case 3 '��ئa��G
                CSTM = "�߬K" : CCSTM = "�B��"
            Case 4 '��ئa��f
                CSTM = "���h" : CCSTM = "�K��"
            Case 5 '��ئa�䨰
                CSTM = "�M��" : CCSTM = "�\�B"
            Case 6 '��ئa��x
                CSTM = "�߮L" : CCSTM = "�p��"
            Case 7 '��ئa���
                CSTM = "�~��" : CCSTM = "�L��"
            Case 8 '��ئa�䥼
                CSTM = "�p��" : CCSTM = "�j��"
            Case 9 '��ئa���
                CSTM = "�߬�" : CCSTM = "�B��"
            Case 10 '��ئa�䨻
                CSTM = "���S" : CCSTM = "���"
            Case 11 '��ئa�䦦
                CSTM = "�H�S" : CCSTM = "����"
            Case 12 '��ئa���
                CSTM = "�ߥV" : CCSTM = "�p��"
        End Select

        '��ة��ݤQ�G�`(�|�W�짽���)
        SolarTerm = CSTM
        '�p���ة��ݤQ�G�`�g�L��ɤ�
        BSTM_DAY = DateDiff("h", SolarTerm_Time, Current_Time) \ 24
        BSTM_HOUR = (DateDiff("n", SolarTerm_Time, Current_Time) Mod 1440) \ 60
        BSTM_MINUTE = DateDiff("n", SolarTerm_Time, Current_Time) Mod 60


        '�p�⥻�뤤��
        READ_LINE = STM_LINE + 1
        GetSolarTermTime()
        Center_SolarTerm_Time = JCPOINT

        '�p��ثe�ɶ��O�_�L����
        diff_minute = DateDiff("n", Center_SolarTerm_Time, Current_Time)
        '�p�G�ɶ��w�L����
        If diff_minute > 0 Then
            CDAY = 1
            Current_SolarTerm = CCSTM
            '�p��ثe�`��g�L��ɤ�(����ާ@��)
            CSTM_DAY = DateDiff("h", Center_SolarTerm_Time, Current_Time) \ 24
            CSTM_HOUR = (DateDiff("n", Center_SolarTerm_Time, Current_Time) Mod 1440) \ 60
            CSTM_MINUTE = DateDiff("n", Center_SolarTerm_Time, Current_Time) Mod 60
        Else
            CDAY = 0
            Current_SolarTerm = CSTM
            '�p��ثe�`��g�L��ɤ�(����ާ@��)
            CSTM_DAY = DateDiff("h", SolarTerm_Time, Current_Time) \ 24
            CSTM_HOUR = (DateDiff("n", SolarTerm_Time, Current_Time) Mod 1440) \ 60
            CSTM_MINUTE = DateDiff("n", SolarTerm_Time, Current_Time) Mod 60
        End If

        '�ثe�q�O�Ѽ�(����ާ@��)
        CSLING_DAY = DateDiff("h", SolarTerm_Time, Current_Time) \ 24

        GanZhi(2, 2) = TC1 '���

        '����P
        YTK = GanZhi(1, 1) '�~�z
        FiveTiger()

        '�p�⥿��������j
        mstep = TC - 1
        If mstep < 0 Then mstep = mstep + 12

        TC2 = ONE_MTK + mstep
        If TC2 > 10 Then TC2 = TC2 - 10
        GanZhi(2, 1) = TC2 '��z

        '====== ��W�B�z
        n = DateDiff("D", "1900/2/20", DateSerial(SolarYear, SolarMonth, tda)) Mod 60 + 1
        GanZhi(3, 1) = n Mod 10 : GanZhi(3, 2) = n Mod 12
        If GanZhi(3, 1) = 0 Then GanZhi(3, 1) = 10
        If GanZhi(3, 2) = 0 Then GanZhi(3, 2) = 12

        '====== �ɬW�B�z
        '�����P
        DTK = GanZhi(3, 1) '��z
        FiveMouse()

        HTK = ONE_HTK + AddHour - 1
        If HTK > 10 Then HTK = HTK - 10
        If HTK < 1 Then HTK = HTK + 10

        GanZhi(4, 1) = HTK
        GanZhi(4, 2) = AddHour

    End Sub

End Module
