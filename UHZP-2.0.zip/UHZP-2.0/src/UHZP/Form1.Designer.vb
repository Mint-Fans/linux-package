﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.NOW_TIME = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.OPSDJTG = New System.Windows.Forms.Label
        Me.OPSTKTG = New System.Windows.Forms.Label
        Me.OPDDJTG = New System.Windows.Forms.Label
        Me.OPDTKTG = New System.Windows.Forms.Label
        Me.OPMDJTG = New System.Windows.Forms.Label
        Me.OPMTKTG = New System.Windows.Forms.Label
        Me.OPYDJTG = New System.Windows.Forms.Label
        Me.OPYTKTG = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.OPSDJ = New System.Windows.Forms.Label
        Me.OPDDJ = New System.Windows.Forms.Label
        Me.OPSTK = New System.Windows.Forms.Label
        Me.OPDTK = New System.Windows.Forms.Label
        Me.OPMDJ = New System.Windows.Forms.Label
        Me.OPMTK = New System.Windows.Forms.Label
        Me.OPYDJ = New System.Windows.Forms.Label
        Me.OPYTK = New System.Windows.Forms.Label
        Me.LunarYMDH = New System.Windows.Forms.Label
        Me.SolarTermLAB = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.CTL_Year = New System.Windows.Forms.NumericUpDown
        Me.CTL_Minute = New System.Windows.Forms.NumericUpDown
        Me.CTL_Hour = New System.Windows.Forms.NumericUpDown
        Me.CTL_Day = New System.Windows.Forms.NumericUpDown
        Me.CTL_Month = New System.Windows.Forms.NumericUpDown
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.Button4 = New System.Windows.Forms.Button
        Me.DateLAB = New System.Windows.Forms.Label
        Me.USERLAB = New System.Windows.Forms.Label
        Me.STMLAB = New System.Windows.Forms.Label
        Me.SMTSLAB = New System.Windows.Forms.Label
        Me.YStrLAB = New System.Windows.Forms.Label
        Me.MStrLAB = New System.Windows.Forms.Label
        Me.DStrLAB = New System.Windows.Forms.Label
        Me.SStrLAB = New System.Windows.Forms.Label
        Me.DAStrLAB = New System.Windows.Forms.Label
        Me.DateStrLAB = New System.Windows.Forms.Label
        Me.YTKLAB = New System.Windows.Forms.Label
        Me.YDJLAB = New System.Windows.Forms.Label
        Me.MTKLAB = New System.Windows.Forms.Label
        Me.MDJLAB = New System.Windows.Forms.Label
        Me.DTKLAB = New System.Windows.Forms.Label
        Me.DDJLAB = New System.Windows.Forms.Label
        Me.STKLAB = New System.Windows.Forms.Label
        Me.SDJLAB = New System.Windows.Forms.Label
        Me.YTKTGLAB = New System.Windows.Forms.Label
        Me.MTKTGLAB = New System.Windows.Forms.Label
        Me.STKTGLAB = New System.Windows.Forms.Label
        Me.YDKLAB1 = New System.Windows.Forms.Label
        Me.YDKLAB2 = New System.Windows.Forms.Label
        Me.YDKLAB3 = New System.Windows.Forms.Label
        Me.MDKLAB2 = New System.Windows.Forms.Label
        Me.DDKLAB2 = New System.Windows.Forms.Label
        Me.SDKLAB2 = New System.Windows.Forms.Label
        Me.SDKLAB1 = New System.Windows.Forms.Label
        Me.MDKLAB1 = New System.Windows.Forms.Label
        Me.MDKLAB3 = New System.Windows.Forms.Label
        Me.DDKLAB1 = New System.Windows.Forms.Label
        Me.DDKLAB3 = New System.Windows.Forms.Label
        Me.SDKLAB3 = New System.Windows.Forms.Label
        Me.YDKTGLAB1 = New System.Windows.Forms.Label
        Me.YDKTGLAB2 = New System.Windows.Forms.Label
        Me.YDKTGLAB3 = New System.Windows.Forms.Label
        Me.MDKTGLAB1 = New System.Windows.Forms.Label
        Me.MDKTGLAB2 = New System.Windows.Forms.Label
        Me.MDKTGLAB3 = New System.Windows.Forms.Label
        Me.DDKTGLAB1 = New System.Windows.Forms.Label
        Me.DDKTGLAB2 = New System.Windows.Forms.Label
        Me.DDKTGLAB3 = New System.Windows.Forms.Label
        Me.SDKTGLAB1 = New System.Windows.Forms.Label
        Me.SDKTGLAB2 = New System.Windows.Forms.Label
        Me.SDKTGLAB3 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        CType(Me.CTL_Year, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CTL_Minute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CTL_Hour, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CTL_Day, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CTL_Month, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'NOW_TIME
        '
        Me.NOW_TIME.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.NOW_TIME.Location = New System.Drawing.Point(397, 21)
        Me.NOW_TIME.Name = "NOW_TIME"
        Me.NOW_TIME.Size = New System.Drawing.Size(41, 25)
        Me.NOW_TIME.TabIndex = 0
        Me.NOW_TIME.Text = "NOW"
        Me.NOW_TIME.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.OPSDJTG)
        Me.GroupBox1.Controls.Add(Me.OPSTKTG)
        Me.GroupBox1.Controls.Add(Me.OPDDJTG)
        Me.GroupBox1.Controls.Add(Me.OPDTKTG)
        Me.GroupBox1.Controls.Add(Me.OPMDJTG)
        Me.GroupBox1.Controls.Add(Me.OPMTKTG)
        Me.GroupBox1.Controls.Add(Me.OPYDJTG)
        Me.GroupBox1.Controls.Add(Me.OPYTKTG)
        Me.GroupBox1.Controls.Add(Me.Label22)
        Me.GroupBox1.Controls.Add(Me.Label21)
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.OPSDJ)
        Me.GroupBox1.Controls.Add(Me.OPDDJ)
        Me.GroupBox1.Controls.Add(Me.OPSTK)
        Me.GroupBox1.Controls.Add(Me.OPDTK)
        Me.GroupBox1.Controls.Add(Me.OPMDJ)
        Me.GroupBox1.Controls.Add(Me.OPMTK)
        Me.GroupBox1.Controls.Add(Me.OPYDJ)
        Me.GroupBox1.Controls.Add(Me.OPYTK)
        Me.GroupBox1.Controls.Add(Me.LunarYMDH)
        Me.GroupBox1.Controls.Add(Me.SolarTermLAB)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.NOW_TIME)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.CTL_Year)
        Me.GroupBox1.Controls.Add(Me.CTL_Minute)
        Me.GroupBox1.Controls.Add(Me.CTL_Hour)
        Me.GroupBox1.Controls.Add(Me.CTL_Day)
        Me.GroupBox1.Controls.Add(Me.CTL_Month)
        Me.GroupBox1.Location = New System.Drawing.Point(17, 467)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(741, 91)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        '
        'OPSDJTG
        '
        Me.OPSDJTG.AutoSize = True
        Me.OPSDJTG.Location = New System.Drawing.Point(706, 71)
        Me.OPSDJTG.Name = "OPSDJTG"
        Me.OPSDJTG.Size = New System.Drawing.Size(0, 12)
        Me.OPSDJTG.TabIndex = 71
        '
        'OPSTKTG
        '
        Me.OPSTKTG.AutoSize = True
        Me.OPSTKTG.Location = New System.Drawing.Point(706, 35)
        Me.OPSTKTG.Name = "OPSTKTG"
        Me.OPSTKTG.Size = New System.Drawing.Size(0, 12)
        Me.OPSTKTG.TabIndex = 71
        '
        'OPDDJTG
        '
        Me.OPDDJTG.AutoSize = True
        Me.OPDDJTG.Location = New System.Drawing.Point(640, 71)
        Me.OPDDJTG.Name = "OPDDJTG"
        Me.OPDDJTG.Size = New System.Drawing.Size(0, 12)
        Me.OPDDJTG.TabIndex = 71
        '
        'OPDTKTG
        '
        Me.OPDTKTG.AutoSize = True
        Me.OPDTKTG.Location = New System.Drawing.Point(640, 35)
        Me.OPDTKTG.Name = "OPDTKTG"
        Me.OPDTKTG.Size = New System.Drawing.Size(0, 12)
        Me.OPDTKTG.TabIndex = 71
        '
        'OPMDJTG
        '
        Me.OPMDJTG.AutoSize = True
        Me.OPMDJTG.Location = New System.Drawing.Point(574, 71)
        Me.OPMDJTG.Name = "OPMDJTG"
        Me.OPMDJTG.Size = New System.Drawing.Size(0, 12)
        Me.OPMDJTG.TabIndex = 71
        '
        'OPMTKTG
        '
        Me.OPMTKTG.AutoSize = True
        Me.OPMTKTG.Location = New System.Drawing.Point(574, 35)
        Me.OPMTKTG.Name = "OPMTKTG"
        Me.OPMTKTG.Size = New System.Drawing.Size(0, 12)
        Me.OPMTKTG.TabIndex = 71
        '
        'OPYDJTG
        '
        Me.OPYDJTG.AutoSize = True
        Me.OPYDJTG.Location = New System.Drawing.Point(508, 71)
        Me.OPYDJTG.Name = "OPYDJTG"
        Me.OPYDJTG.Size = New System.Drawing.Size(0, 12)
        Me.OPYDJTG.TabIndex = 71
        '
        'OPYTKTG
        '
        Me.OPYTKTG.AutoSize = True
        Me.OPYTKTG.Location = New System.Drawing.Point(508, 35)
        Me.OPYTKTG.Name = "OPYTKTG"
        Me.OPYTKTG.Size = New System.Drawing.Size(0, 12)
        Me.OPYTKTG.TabIndex = 70
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(688, 21)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(17, 12)
        Me.Label22.TabIndex = 70
        Me.Label22.Text = "時"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(621, 21)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(17, 12)
        Me.Label21.TabIndex = 70
        Me.Label21.Text = "日"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(556, 21)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(17, 12)
        Me.Label20.TabIndex = 70
        Me.Label20.Text = "月"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(490, 21)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(17, 12)
        Me.Label19.TabIndex = 69
        Me.Label19.Text = "年"
        '
        'OPSDJ
        '
        Me.OPSDJ.AutoSize = True
        Me.OPSDJ.Font = New System.Drawing.Font("細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.OPSDJ.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.OPSDJ.Location = New System.Drawing.Point(684, 60)
        Me.OPSDJ.Name = "OPSDJ"
        Me.OPSDJ.Size = New System.Drawing.Size(25, 16)
        Me.OPSDJ.TabIndex = 76
        Me.OPSDJ.Text = "子"
        '
        'OPDDJ
        '
        Me.OPDDJ.AutoSize = True
        Me.OPDDJ.Font = New System.Drawing.Font("細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.OPDDJ.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.OPDDJ.Location = New System.Drawing.Point(618, 60)
        Me.OPDDJ.Name = "OPDDJ"
        Me.OPDDJ.Size = New System.Drawing.Size(25, 16)
        Me.OPDDJ.TabIndex = 75
        Me.OPDDJ.Text = "子"
        '
        'OPSTK
        '
        Me.OPSTK.AutoSize = True
        Me.OPSTK.Font = New System.Drawing.Font("細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.OPSTK.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.OPSTK.Location = New System.Drawing.Point(684, 40)
        Me.OPSTK.Name = "OPSTK"
        Me.OPSTK.Size = New System.Drawing.Size(25, 16)
        Me.OPSTK.TabIndex = 74
        Me.OPSTK.Text = "甲"
        '
        'OPDTK
        '
        Me.OPDTK.AutoSize = True
        Me.OPDTK.Font = New System.Drawing.Font("細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.OPDTK.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.OPDTK.Location = New System.Drawing.Point(618, 40)
        Me.OPDTK.Name = "OPDTK"
        Me.OPDTK.Size = New System.Drawing.Size(25, 16)
        Me.OPDTK.TabIndex = 73
        Me.OPDTK.Text = "甲"
        '
        'OPMDJ
        '
        Me.OPMDJ.AutoSize = True
        Me.OPMDJ.Font = New System.Drawing.Font("細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.OPMDJ.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.OPMDJ.Location = New System.Drawing.Point(552, 60)
        Me.OPMDJ.Name = "OPMDJ"
        Me.OPMDJ.Size = New System.Drawing.Size(25, 16)
        Me.OPMDJ.TabIndex = 72
        Me.OPMDJ.Text = "子"
        '
        'OPMTK
        '
        Me.OPMTK.AutoSize = True
        Me.OPMTK.Font = New System.Drawing.Font("細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.OPMTK.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.OPMTK.Location = New System.Drawing.Point(552, 40)
        Me.OPMTK.Name = "OPMTK"
        Me.OPMTK.Size = New System.Drawing.Size(25, 16)
        Me.OPMTK.TabIndex = 71
        Me.OPMTK.Text = "甲"
        '
        'OPYDJ
        '
        Me.OPYDJ.AutoSize = True
        Me.OPYDJ.Font = New System.Drawing.Font("細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.OPYDJ.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.OPYDJ.Location = New System.Drawing.Point(486, 60)
        Me.OPYDJ.Name = "OPYDJ"
        Me.OPYDJ.Size = New System.Drawing.Size(25, 16)
        Me.OPYDJ.TabIndex = 70
        Me.OPYDJ.Text = "子"
        '
        'OPYTK
        '
        Me.OPYTK.AutoSize = True
        Me.OPYTK.Font = New System.Drawing.Font("細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.OPYTK.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.OPYTK.Location = New System.Drawing.Point(486, 40)
        Me.OPYTK.Name = "OPYTK"
        Me.OPYTK.Size = New System.Drawing.Size(25, 16)
        Me.OPYTK.TabIndex = 69
        Me.OPYTK.Text = "甲"
        '
        'LunarYMDH
        '
        Me.LunarYMDH.AutoSize = True
        Me.LunarYMDH.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.LunarYMDH.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.LunarYMDH.Location = New System.Drawing.Point(24, 64)
        Me.LunarYMDH.Name = "LunarYMDH"
        Me.LunarYMDH.Size = New System.Drawing.Size(206, 15)
        Me.LunarYMDH.TabIndex = 11
        Me.LunarYMDH.Text = "陰曆 甲子年十二月三十日亥時"
        '
        'SolarTermLAB
        '
        Me.SolarTermLAB.AutoSize = True
        Me.SolarTermLAB.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SolarTermLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.SolarTermLAB.Location = New System.Drawing.Point(278, 64)
        Me.SolarTermLAB.Name = "SolarTermLAB"
        Me.SolarTermLAB.Size = New System.Drawing.Size(160, 15)
        Me.SolarTermLAB.TabIndex = 12
        Me.SolarTermLAB.Text = "立春後第30日 甲木司權"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(374, 25)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(22, 15)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "分"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(309, 25)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(22, 15)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "時"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(244, 24)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(22, 15)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "日"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(181, 24)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(22, 15)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "月"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(118, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(22, 15)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "年"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(24, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(37, 15)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "西元"
        '
        'CTL_Year
        '
        Me.CTL_Year.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.CTL_Year.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.CTL_Year.Location = New System.Drawing.Point(67, 21)
        Me.CTL_Year.Maximum = New Decimal(New Integer() {2099, 0, 0, 0})
        Me.CTL_Year.Minimum = New Decimal(New Integer() {1901, 0, 0, 0})
        Me.CTL_Year.Name = "CTL_Year"
        Me.CTL_Year.Size = New System.Drawing.Size(49, 25)
        Me.CTL_Year.TabIndex = 0
        Me.CTL_Year.Tag = ""
        Me.CTL_Year.Value = New Decimal(New Integer() {1901, 0, 0, 0})
        '
        'CTL_Minute
        '
        Me.CTL_Minute.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.CTL_Minute.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.CTL_Minute.Location = New System.Drawing.Point(334, 21)
        Me.CTL_Minute.Maximum = New Decimal(New Integer() {60, 0, 0, 0})
        Me.CTL_Minute.Minimum = New Decimal(New Integer() {1, 0, 0, -2147483648})
        Me.CTL_Minute.Name = "CTL_Minute"
        Me.CTL_Minute.Size = New System.Drawing.Size(37, 25)
        Me.CTL_Minute.TabIndex = 4
        '
        'CTL_Hour
        '
        Me.CTL_Hour.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.CTL_Hour.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.CTL_Hour.Location = New System.Drawing.Point(270, 21)
        Me.CTL_Hour.Maximum = New Decimal(New Integer() {24, 0, 0, 0})
        Me.CTL_Hour.Minimum = New Decimal(New Integer() {1, 0, 0, -2147483648})
        Me.CTL_Hour.Name = "CTL_Hour"
        Me.CTL_Hour.Size = New System.Drawing.Size(37, 25)
        Me.CTL_Hour.TabIndex = 3
        '
        'CTL_Day
        '
        Me.CTL_Day.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.CTL_Day.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.CTL_Day.Location = New System.Drawing.Point(205, 21)
        Me.CTL_Day.Maximum = New Decimal(New Integer() {32, 0, 0, 0})
        Me.CTL_Day.Name = "CTL_Day"
        Me.CTL_Day.Size = New System.Drawing.Size(37, 25)
        Me.CTL_Day.TabIndex = 2
        Me.CTL_Day.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'CTL_Month
        '
        Me.CTL_Month.Font = New System.Drawing.Font("新細明體", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.CTL_Month.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.CTL_Month.Location = New System.Drawing.Point(142, 21)
        Me.CTL_Month.Maximum = New Decimal(New Integer() {13, 0, 0, 0})
        Me.CTL_Month.Name = "CTL_Month"
        Me.CTL_Month.Size = New System.Drawing.Size(37, 25)
        Me.CTL_Month.TabIndex = 1
        Me.CTL_Month.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Button1
        '
        Me.Button1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(16, 15)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(73, 28)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "排盤"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Button2.Location = New System.Drawing.Point(104, 15)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(73, 28)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "五行旺衰"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Button3.Location = New System.Drawing.Point(192, 15)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(73, 28)
        Me.Button3.TabIndex = 5
        Me.Button3.Text = "小運"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Button4.Location = New System.Drawing.Point(280, 15)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(73, 28)
        Me.Button4.TabIndex = 6
        Me.Button4.Text = "神煞"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'DateLAB
        '
        Me.DateLAB.AutoSize = True
        Me.DateLAB.Font = New System.Drawing.Font("新細明體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.DateLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DateLAB.Location = New System.Drawing.Point(16, 80)
        Me.DateLAB.Name = "DateLAB"
        Me.DateLAB.Size = New System.Drawing.Size(93, 13)
        Me.DateLAB.TabIndex = 7
        Me.DateLAB.Text = "生日陽曆(陰曆)"
        '
        'USERLAB
        '
        Me.USERLAB.AutoSize = True
        Me.USERLAB.Font = New System.Drawing.Font("新細明體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.USERLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.USERLAB.Location = New System.Drawing.Point(16, 60)
        Me.USERLAB.Name = "USERLAB"
        Me.USERLAB.Size = New System.Drawing.Size(101, 13)
        Me.USERLAB.TabIndex = 8
        Me.USERLAB.Text = "使用者名稱 歲數"
        '
        'STMLAB
        '
        Me.STMLAB.AutoSize = True
        Me.STMLAB.Font = New System.Drawing.Font("新細明體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.STMLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.STMLAB.Location = New System.Drawing.Point(16, 97)
        Me.STMLAB.Name = "STMLAB"
        Me.STMLAB.Size = New System.Drawing.Size(153, 13)
        Me.STMLAB.TabIndex = 10
        Me.STMLAB.Text = "出生節氣日時分 司權用事"
        '
        'SMTSLAB
        '
        Me.SMTSLAB.AutoSize = True
        Me.SMTSLAB.Font = New System.Drawing.Font("新細明體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SMTSLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.SMTSLAB.Location = New System.Drawing.Point(16, 115)
        Me.SMTSLAB.Name = "SMTSLAB"
        Me.SMTSLAB.Size = New System.Drawing.Size(59, 13)
        Me.SMTSLAB.TabIndex = 11
        Me.SMTSLAB.Text = "身命胎息"
        '
        'YStrLAB
        '
        Me.YStrLAB.AutoSize = True
        Me.YStrLAB.Font = New System.Drawing.Font("微軟正黑體", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.YStrLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.YStrLAB.Location = New System.Drawing.Point(350, 150)
        Me.YStrLAB.Name = "YStrLAB"
        Me.YStrLAB.Size = New System.Drawing.Size(33, 26)
        Me.YStrLAB.TabIndex = 12
        Me.YStrLAB.Text = "年"
        '
        'MStrLAB
        '
        Me.MStrLAB.AutoSize = True
        Me.MStrLAB.Font = New System.Drawing.Font("微軟正黑體", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.MStrLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.MStrLAB.Location = New System.Drawing.Point(260, 150)
        Me.MStrLAB.Name = "MStrLAB"
        Me.MStrLAB.Size = New System.Drawing.Size(33, 26)
        Me.MStrLAB.TabIndex = 13
        Me.MStrLAB.Text = "月"
        '
        'DStrLAB
        '
        Me.DStrLAB.AutoSize = True
        Me.DStrLAB.Font = New System.Drawing.Font("微軟正黑體", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.DStrLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DStrLAB.Location = New System.Drawing.Point(170, 150)
        Me.DStrLAB.Name = "DStrLAB"
        Me.DStrLAB.Size = New System.Drawing.Size(33, 26)
        Me.DStrLAB.TabIndex = 14
        Me.DStrLAB.Text = "日"
        '
        'SStrLAB
        '
        Me.SStrLAB.AutoSize = True
        Me.SStrLAB.Font = New System.Drawing.Font("微軟正黑體", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SStrLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.SStrLAB.Location = New System.Drawing.Point(80, 150)
        Me.SStrLAB.Name = "SStrLAB"
        Me.SStrLAB.Size = New System.Drawing.Size(33, 26)
        Me.SStrLAB.TabIndex = 15
        Me.SStrLAB.Text = "時"
        '
        'DAStrLAB
        '
        Me.DAStrLAB.AutoSize = True
        Me.DAStrLAB.Font = New System.Drawing.Font("新細明體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.DAStrLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DAStrLAB.Location = New System.Drawing.Point(610, 60)
        Me.DAStrLAB.Name = "DAStrLAB"
        Me.DAStrLAB.Size = New System.Drawing.Size(33, 13)
        Me.DAStrLAB.TabIndex = 16
        Me.DAStrLAB.Text = "大運"
        '
        'DateStrLAB
        '
        Me.DateStrLAB.AutoSize = True
        Me.DateStrLAB.Font = New System.Drawing.Font("新細明體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.DateStrLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DateStrLAB.Location = New System.Drawing.Point(644, 60)
        Me.DateStrLAB.Name = "DateStrLAB"
        Me.DateStrLAB.Size = New System.Drawing.Size(59, 13)
        Me.DateStrLAB.TabIndex = 17
        Me.DateStrLAB.Text = "交運日期"
        '
        'YTKLAB
        '
        Me.YTKLAB.AutoSize = True
        Me.YTKLAB.Font = New System.Drawing.Font("微軟正黑體", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.YTKLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.YTKLAB.Location = New System.Drawing.Point(350, 190)
        Me.YTKLAB.Name = "YTKLAB"
        Me.YTKLAB.Size = New System.Drawing.Size(33, 26)
        Me.YTKLAB.TabIndex = 20
        Me.YTKLAB.Text = "甲"
        '
        'YDJLAB
        '
        Me.YDJLAB.AutoSize = True
        Me.YDJLAB.Font = New System.Drawing.Font("微軟正黑體", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.YDJLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.YDJLAB.Location = New System.Drawing.Point(350, 214)
        Me.YDJLAB.Name = "YDJLAB"
        Me.YDJLAB.Size = New System.Drawing.Size(33, 26)
        Me.YDJLAB.TabIndex = 21
        Me.YDJLAB.Text = "子"
        '
        'MTKLAB
        '
        Me.MTKLAB.AutoSize = True
        Me.MTKLAB.Font = New System.Drawing.Font("微軟正黑體", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.MTKLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.MTKLAB.Location = New System.Drawing.Point(260, 190)
        Me.MTKLAB.Name = "MTKLAB"
        Me.MTKLAB.Size = New System.Drawing.Size(33, 26)
        Me.MTKLAB.TabIndex = 22
        Me.MTKLAB.Text = "甲"
        '
        'MDJLAB
        '
        Me.MDJLAB.AutoSize = True
        Me.MDJLAB.Font = New System.Drawing.Font("微軟正黑體", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.MDJLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.MDJLAB.Location = New System.Drawing.Point(260, 214)
        Me.MDJLAB.Name = "MDJLAB"
        Me.MDJLAB.Size = New System.Drawing.Size(33, 26)
        Me.MDJLAB.TabIndex = 23
        Me.MDJLAB.Text = "子"
        '
        'DTKLAB
        '
        Me.DTKLAB.AutoSize = True
        Me.DTKLAB.Font = New System.Drawing.Font("微軟正黑體", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.DTKLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DTKLAB.Location = New System.Drawing.Point(170, 190)
        Me.DTKLAB.Name = "DTKLAB"
        Me.DTKLAB.Size = New System.Drawing.Size(33, 26)
        Me.DTKLAB.TabIndex = 24
        Me.DTKLAB.Text = "甲"
        '
        'DDJLAB
        '
        Me.DDJLAB.AutoSize = True
        Me.DDJLAB.Font = New System.Drawing.Font("微軟正黑體", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.DDJLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DDJLAB.Location = New System.Drawing.Point(170, 214)
        Me.DDJLAB.Name = "DDJLAB"
        Me.DDJLAB.Size = New System.Drawing.Size(33, 26)
        Me.DDJLAB.TabIndex = 25
        Me.DDJLAB.Text = "子"
        '
        'STKLAB
        '
        Me.STKLAB.AutoSize = True
        Me.STKLAB.Font = New System.Drawing.Font("微軟正黑體", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.STKLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.STKLAB.Location = New System.Drawing.Point(80, 190)
        Me.STKLAB.Name = "STKLAB"
        Me.STKLAB.Size = New System.Drawing.Size(33, 26)
        Me.STKLAB.TabIndex = 26
        Me.STKLAB.Text = "甲"
        '
        'SDJLAB
        '
        Me.SDJLAB.AutoSize = True
        Me.SDJLAB.Font = New System.Drawing.Font("微軟正黑體", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SDJLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.SDJLAB.Location = New System.Drawing.Point(80, 214)
        Me.SDJLAB.Name = "SDJLAB"
        Me.SDJLAB.Size = New System.Drawing.Size(33, 26)
        Me.SDJLAB.TabIndex = 27
        Me.SDJLAB.Text = "子"
        '
        'YTKTGLAB
        '
        Me.YTKTGLAB.AutoSize = True
        Me.YTKTGLAB.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.YTKTGLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.YTKTGLAB.Location = New System.Drawing.Point(356, 175)
        Me.YTKTGLAB.Name = "YTKTGLAB"
        Me.YTKTGLAB.Size = New System.Drawing.Size(21, 17)
        Me.YTKTGLAB.TabIndex = 28
        Me.YTKTGLAB.Text = "比"
        '
        'MTKTGLAB
        '
        Me.MTKTGLAB.AutoSize = True
        Me.MTKTGLAB.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.MTKTGLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.MTKTGLAB.Location = New System.Drawing.Point(266, 175)
        Me.MTKTGLAB.Name = "MTKTGLAB"
        Me.MTKTGLAB.Size = New System.Drawing.Size(21, 17)
        Me.MTKTGLAB.TabIndex = 29
        Me.MTKTGLAB.Text = "比"
        '
        'STKTGLAB
        '
        Me.STKTGLAB.AutoSize = True
        Me.STKTGLAB.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.STKTGLAB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.STKTGLAB.Location = New System.Drawing.Point(86, 175)
        Me.STKTGLAB.Name = "STKTGLAB"
        Me.STKTGLAB.Size = New System.Drawing.Size(21, 17)
        Me.STKTGLAB.TabIndex = 30
        Me.STKTGLAB.Text = "比"
        '
        'YDKLAB1
        '
        Me.YDKLAB1.AutoSize = True
        Me.YDKLAB1.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.YDKLAB1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.YDKLAB1.Location = New System.Drawing.Point(376, 238)
        Me.YDKLAB1.Name = "YDKLAB1"
        Me.YDKLAB1.Size = New System.Drawing.Size(21, 17)
        Me.YDKLAB1.TabIndex = 31
        Me.YDKLAB1.Text = "己"
        '
        'YDKLAB2
        '
        Me.YDKLAB2.AutoSize = True
        Me.YDKLAB2.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.YDKLAB2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.YDKLAB2.Location = New System.Drawing.Point(356, 238)
        Me.YDKLAB2.Name = "YDKLAB2"
        Me.YDKLAB2.Size = New System.Drawing.Size(21, 17)
        Me.YDKLAB2.TabIndex = 32
        Me.YDKLAB2.Text = "己"
        '
        'YDKLAB3
        '
        Me.YDKLAB3.AutoSize = True
        Me.YDKLAB3.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.YDKLAB3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.YDKLAB3.Location = New System.Drawing.Point(336, 238)
        Me.YDKLAB3.Name = "YDKLAB3"
        Me.YDKLAB3.Size = New System.Drawing.Size(21, 17)
        Me.YDKLAB3.TabIndex = 33
        Me.YDKLAB3.Text = "己"
        '
        'MDKLAB2
        '
        Me.MDKLAB2.AutoSize = True
        Me.MDKLAB2.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.MDKLAB2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.MDKLAB2.Location = New System.Drawing.Point(266, 238)
        Me.MDKLAB2.Name = "MDKLAB2"
        Me.MDKLAB2.Size = New System.Drawing.Size(21, 17)
        Me.MDKLAB2.TabIndex = 35
        Me.MDKLAB2.Text = "己"
        '
        'DDKLAB2
        '
        Me.DDKLAB2.AutoSize = True
        Me.DDKLAB2.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.DDKLAB2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DDKLAB2.Location = New System.Drawing.Point(176, 238)
        Me.DDKLAB2.Name = "DDKLAB2"
        Me.DDKLAB2.Size = New System.Drawing.Size(21, 17)
        Me.DDKLAB2.TabIndex = 36
        Me.DDKLAB2.Text = "己"
        '
        'SDKLAB2
        '
        Me.SDKLAB2.AutoSize = True
        Me.SDKLAB2.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SDKLAB2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.SDKLAB2.Location = New System.Drawing.Point(86, 238)
        Me.SDKLAB2.Name = "SDKLAB2"
        Me.SDKLAB2.Size = New System.Drawing.Size(21, 17)
        Me.SDKLAB2.TabIndex = 37
        Me.SDKLAB2.Text = "己"
        '
        'SDKLAB1
        '
        Me.SDKLAB1.AutoSize = True
        Me.SDKLAB1.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SDKLAB1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.SDKLAB1.Location = New System.Drawing.Point(106, 238)
        Me.SDKLAB1.Name = "SDKLAB1"
        Me.SDKLAB1.Size = New System.Drawing.Size(21, 17)
        Me.SDKLAB1.TabIndex = 38
        Me.SDKLAB1.Text = "己"
        '
        'MDKLAB1
        '
        Me.MDKLAB1.AutoSize = True
        Me.MDKLAB1.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.MDKLAB1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.MDKLAB1.Location = New System.Drawing.Point(286, 238)
        Me.MDKLAB1.Name = "MDKLAB1"
        Me.MDKLAB1.Size = New System.Drawing.Size(21, 17)
        Me.MDKLAB1.TabIndex = 39
        Me.MDKLAB1.Text = "己"
        '
        'MDKLAB3
        '
        Me.MDKLAB3.AutoSize = True
        Me.MDKLAB3.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.MDKLAB3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.MDKLAB3.Location = New System.Drawing.Point(246, 238)
        Me.MDKLAB3.Name = "MDKLAB3"
        Me.MDKLAB3.Size = New System.Drawing.Size(21, 17)
        Me.MDKLAB3.TabIndex = 40
        Me.MDKLAB3.Text = "己"
        '
        'DDKLAB1
        '
        Me.DDKLAB1.AutoSize = True
        Me.DDKLAB1.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.DDKLAB1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DDKLAB1.Location = New System.Drawing.Point(196, 238)
        Me.DDKLAB1.Name = "DDKLAB1"
        Me.DDKLAB1.Size = New System.Drawing.Size(21, 17)
        Me.DDKLAB1.TabIndex = 41
        Me.DDKLAB1.Text = "己"
        '
        'DDKLAB3
        '
        Me.DDKLAB3.AutoSize = True
        Me.DDKLAB3.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.DDKLAB3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DDKLAB3.Location = New System.Drawing.Point(156, 238)
        Me.DDKLAB3.Name = "DDKLAB3"
        Me.DDKLAB3.Size = New System.Drawing.Size(21, 17)
        Me.DDKLAB3.TabIndex = 42
        Me.DDKLAB3.Text = "己"
        '
        'SDKLAB3
        '
        Me.SDKLAB3.AutoSize = True
        Me.SDKLAB3.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SDKLAB3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.SDKLAB3.Location = New System.Drawing.Point(66, 238)
        Me.SDKLAB3.Name = "SDKLAB3"
        Me.SDKLAB3.Size = New System.Drawing.Size(21, 17)
        Me.SDKLAB3.TabIndex = 43
        Me.SDKLAB3.Text = "己"
        '
        'YDKTGLAB1
        '
        Me.YDKTGLAB1.AutoSize = True
        Me.YDKTGLAB1.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.YDKTGLAB1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.YDKTGLAB1.Location = New System.Drawing.Point(376, 256)
        Me.YDKTGLAB1.Name = "YDKTGLAB1"
        Me.YDKTGLAB1.Size = New System.Drawing.Size(21, 17)
        Me.YDKTGLAB1.TabIndex = 44
        Me.YDKTGLAB1.Text = "比"
        '
        'YDKTGLAB2
        '
        Me.YDKTGLAB2.AutoSize = True
        Me.YDKTGLAB2.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.YDKTGLAB2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.YDKTGLAB2.Location = New System.Drawing.Point(356, 256)
        Me.YDKTGLAB2.Name = "YDKTGLAB2"
        Me.YDKTGLAB2.Size = New System.Drawing.Size(21, 17)
        Me.YDKTGLAB2.TabIndex = 45
        Me.YDKTGLAB2.Text = "比"
        '
        'YDKTGLAB3
        '
        Me.YDKTGLAB3.AutoSize = True
        Me.YDKTGLAB3.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.YDKTGLAB3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.YDKTGLAB3.Location = New System.Drawing.Point(336, 256)
        Me.YDKTGLAB3.Name = "YDKTGLAB3"
        Me.YDKTGLAB3.Size = New System.Drawing.Size(21, 17)
        Me.YDKTGLAB3.TabIndex = 46
        Me.YDKTGLAB3.Text = "比"
        '
        'MDKTGLAB1
        '
        Me.MDKTGLAB1.AutoSize = True
        Me.MDKTGLAB1.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.MDKTGLAB1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.MDKTGLAB1.Location = New System.Drawing.Point(286, 256)
        Me.MDKTGLAB1.Name = "MDKTGLAB1"
        Me.MDKTGLAB1.Size = New System.Drawing.Size(21, 17)
        Me.MDKTGLAB1.TabIndex = 47
        Me.MDKTGLAB1.Text = "比"
        '
        'MDKTGLAB2
        '
        Me.MDKTGLAB2.AutoSize = True
        Me.MDKTGLAB2.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.MDKTGLAB2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.MDKTGLAB2.Location = New System.Drawing.Point(266, 256)
        Me.MDKTGLAB2.Name = "MDKTGLAB2"
        Me.MDKTGLAB2.Size = New System.Drawing.Size(21, 17)
        Me.MDKTGLAB2.TabIndex = 48
        Me.MDKTGLAB2.Text = "比"
        '
        'MDKTGLAB3
        '
        Me.MDKTGLAB3.AutoSize = True
        Me.MDKTGLAB3.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.MDKTGLAB3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.MDKTGLAB3.Location = New System.Drawing.Point(246, 256)
        Me.MDKTGLAB3.Name = "MDKTGLAB3"
        Me.MDKTGLAB3.Size = New System.Drawing.Size(21, 17)
        Me.MDKTGLAB3.TabIndex = 49
        Me.MDKTGLAB3.Text = "比"
        '
        'DDKTGLAB1
        '
        Me.DDKTGLAB1.AutoSize = True
        Me.DDKTGLAB1.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.DDKTGLAB1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DDKTGLAB1.Location = New System.Drawing.Point(196, 256)
        Me.DDKTGLAB1.Name = "DDKTGLAB1"
        Me.DDKTGLAB1.Size = New System.Drawing.Size(21, 17)
        Me.DDKTGLAB1.TabIndex = 50
        Me.DDKTGLAB1.Text = "比"
        '
        'DDKTGLAB2
        '
        Me.DDKTGLAB2.AutoSize = True
        Me.DDKTGLAB2.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.DDKTGLAB2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DDKTGLAB2.Location = New System.Drawing.Point(176, 256)
        Me.DDKTGLAB2.Name = "DDKTGLAB2"
        Me.DDKTGLAB2.Size = New System.Drawing.Size(21, 17)
        Me.DDKTGLAB2.TabIndex = 51
        Me.DDKTGLAB2.Text = "比"
        '
        'DDKTGLAB3
        '
        Me.DDKTGLAB3.AutoSize = True
        Me.DDKTGLAB3.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.DDKTGLAB3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DDKTGLAB3.Location = New System.Drawing.Point(156, 256)
        Me.DDKTGLAB3.Name = "DDKTGLAB3"
        Me.DDKTGLAB3.Size = New System.Drawing.Size(21, 17)
        Me.DDKTGLAB3.TabIndex = 52
        Me.DDKTGLAB3.Text = "比"
        '
        'SDKTGLAB1
        '
        Me.SDKTGLAB1.AutoSize = True
        Me.SDKTGLAB1.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SDKTGLAB1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.SDKTGLAB1.Location = New System.Drawing.Point(106, 256)
        Me.SDKTGLAB1.Name = "SDKTGLAB1"
        Me.SDKTGLAB1.Size = New System.Drawing.Size(21, 17)
        Me.SDKTGLAB1.TabIndex = 53
        Me.SDKTGLAB1.Text = "比"
        '
        'SDKTGLAB2
        '
        Me.SDKTGLAB2.AutoSize = True
        Me.SDKTGLAB2.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SDKTGLAB2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.SDKTGLAB2.Location = New System.Drawing.Point(86, 256)
        Me.SDKTGLAB2.Name = "SDKTGLAB2"
        Me.SDKTGLAB2.Size = New System.Drawing.Size(21, 17)
        Me.SDKTGLAB2.TabIndex = 54
        Me.SDKTGLAB2.Text = "比"
        '
        'SDKTGLAB3
        '
        Me.SDKTGLAB3.AutoSize = True
        Me.SDKTGLAB3.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SDKTGLAB3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.SDKTGLAB3.Location = New System.Drawing.Point(66, 256)
        Me.SDKTGLAB3.Name = "SDKTGLAB3"
        Me.SDKTGLAB3.Size = New System.Drawing.Size(21, 17)
        Me.SDKTGLAB3.TabIndex = 55
        Me.SDKTGLAB3.Text = "比"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(776, 578)
        Me.Controls.Add(Me.SDKTGLAB3)
        Me.Controls.Add(Me.SDKTGLAB2)
        Me.Controls.Add(Me.SDKTGLAB1)
        Me.Controls.Add(Me.DDKTGLAB3)
        Me.Controls.Add(Me.DDKTGLAB2)
        Me.Controls.Add(Me.DDKTGLAB1)
        Me.Controls.Add(Me.MDKTGLAB3)
        Me.Controls.Add(Me.MDKTGLAB2)
        Me.Controls.Add(Me.MDKTGLAB1)
        Me.Controls.Add(Me.YDKTGLAB3)
        Me.Controls.Add(Me.YDKTGLAB2)
        Me.Controls.Add(Me.YDKTGLAB1)
        Me.Controls.Add(Me.SDKLAB3)
        Me.Controls.Add(Me.DDKLAB3)
        Me.Controls.Add(Me.DDKLAB1)
        Me.Controls.Add(Me.MDKLAB3)
        Me.Controls.Add(Me.MDKLAB1)
        Me.Controls.Add(Me.SDKLAB1)
        Me.Controls.Add(Me.SDKLAB2)
        Me.Controls.Add(Me.DDKLAB2)
        Me.Controls.Add(Me.MDKLAB2)
        Me.Controls.Add(Me.YDKLAB3)
        Me.Controls.Add(Me.YDKLAB2)
        Me.Controls.Add(Me.YDKLAB1)
        Me.Controls.Add(Me.STKTGLAB)
        Me.Controls.Add(Me.MTKTGLAB)
        Me.Controls.Add(Me.YTKTGLAB)
        Me.Controls.Add(Me.SDJLAB)
        Me.Controls.Add(Me.STKLAB)
        Me.Controls.Add(Me.DDJLAB)
        Me.Controls.Add(Me.DTKLAB)
        Me.Controls.Add(Me.MDJLAB)
        Me.Controls.Add(Me.MTKLAB)
        Me.Controls.Add(Me.YDJLAB)
        Me.Controls.Add(Me.YTKLAB)
        Me.Controls.Add(Me.DateStrLAB)
        Me.Controls.Add(Me.DAStrLAB)
        Me.Controls.Add(Me.SStrLAB)
        Me.Controls.Add(Me.DStrLAB)
        Me.Controls.Add(Me.MStrLAB)
        Me.Controls.Add(Me.YStrLAB)
        Me.Controls.Add(Me.SMTSLAB)
        Me.Controls.Add(Me.STMLAB)
        Me.Controls.Add(Me.USERLAB)
        Me.Controls.Add(Me.DateLAB)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Text = "淵海子平"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.CTL_Year, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CTL_Minute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CTL_Hour, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CTL_Day, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CTL_Month, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents NOW_TIME As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents CTL_Year As System.Windows.Forms.NumericUpDown
    Friend WithEvents CTL_Minute As System.Windows.Forms.NumericUpDown
    Friend WithEvents CTL_Hour As System.Windows.Forms.NumericUpDown
    Friend WithEvents CTL_Day As System.Windows.Forms.NumericUpDown
    Friend WithEvents CTL_Month As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents LunarYMDH As System.Windows.Forms.Label
    Friend WithEvents SolarTermLAB As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents DateLAB As System.Windows.Forms.Label
    Friend WithEvents USERLAB As System.Windows.Forms.Label
    Friend WithEvents STMLAB As System.Windows.Forms.Label
    Friend WithEvents SMTSLAB As System.Windows.Forms.Label
    Friend WithEvents YStrLAB As System.Windows.Forms.Label
    Friend WithEvents MStrLAB As System.Windows.Forms.Label
    Friend WithEvents DStrLAB As System.Windows.Forms.Label
    Friend WithEvents SStrLAB As System.Windows.Forms.Label
    Friend WithEvents DAStrLAB As System.Windows.Forms.Label
    Friend WithEvents DateStrLAB As System.Windows.Forms.Label
    Friend WithEvents YTKLAB As System.Windows.Forms.Label
    Friend WithEvents YDJLAB As System.Windows.Forms.Label
    Friend WithEvents MTKLAB As System.Windows.Forms.Label
    Friend WithEvents MDJLAB As System.Windows.Forms.Label
    Friend WithEvents DTKLAB As System.Windows.Forms.Label
    Friend WithEvents DDJLAB As System.Windows.Forms.Label
    Friend WithEvents STKLAB As System.Windows.Forms.Label
    Friend WithEvents SDJLAB As System.Windows.Forms.Label
    Friend WithEvents YTKTGLAB As System.Windows.Forms.Label
    Friend WithEvents MTKTGLAB As System.Windows.Forms.Label
    Friend WithEvents STKTGLAB As System.Windows.Forms.Label
    Friend WithEvents YDKLAB1 As System.Windows.Forms.Label
    Friend WithEvents YDKLAB2 As System.Windows.Forms.Label
    Friend WithEvents YDKLAB3 As System.Windows.Forms.Label
    Friend WithEvents MDKLAB2 As System.Windows.Forms.Label
    Friend WithEvents DDKLAB2 As System.Windows.Forms.Label
    Friend WithEvents SDKLAB2 As System.Windows.Forms.Label
    Friend WithEvents SDKLAB1 As System.Windows.Forms.Label
    Friend WithEvents MDKLAB1 As System.Windows.Forms.Label
    Friend WithEvents MDKLAB3 As System.Windows.Forms.Label
    Friend WithEvents DDKLAB1 As System.Windows.Forms.Label
    Friend WithEvents DDKLAB3 As System.Windows.Forms.Label
    Friend WithEvents SDKLAB3 As System.Windows.Forms.Label
    Friend WithEvents YDKTGLAB1 As System.Windows.Forms.Label
    Friend WithEvents YDKTGLAB2 As System.Windows.Forms.Label
    Friend WithEvents YDKTGLAB3 As System.Windows.Forms.Label
    Friend WithEvents MDKTGLAB1 As System.Windows.Forms.Label
    Friend WithEvents MDKTGLAB2 As System.Windows.Forms.Label
    Friend WithEvents MDKTGLAB3 As System.Windows.Forms.Label
    Friend WithEvents DDKTGLAB1 As System.Windows.Forms.Label
    Friend WithEvents DDKTGLAB2 As System.Windows.Forms.Label
    Friend WithEvents DDKTGLAB3 As System.Windows.Forms.Label
    Friend WithEvents SDKTGLAB1 As System.Windows.Forms.Label
    Friend WithEvents SDKTGLAB2 As System.Windows.Forms.Label
    Friend WithEvents SDKTGLAB3 As System.Windows.Forms.Label
    Friend WithEvents OPYTK As System.Windows.Forms.Label
    Friend WithEvents OPYDJ As System.Windows.Forms.Label
    Friend WithEvents OPSDJ As System.Windows.Forms.Label
    Friend WithEvents OPDDJ As System.Windows.Forms.Label
    Friend WithEvents OPSTK As System.Windows.Forms.Label
    Friend WithEvents OPDTK As System.Windows.Forms.Label
    Friend WithEvents OPMDJ As System.Windows.Forms.Label
    Friend WithEvents OPMTK As System.Windows.Forms.Label
    Friend WithEvents OPSDJTG As System.Windows.Forms.Label
    Friend WithEvents OPSTKTG As System.Windows.Forms.Label
    Friend WithEvents OPDDJTG As System.Windows.Forms.Label
    Friend WithEvents OPDTKTG As System.Windows.Forms.Label
    Friend WithEvents OPMDJTG As System.Windows.Forms.Label
    Friend WithEvents OPMTKTG As System.Windows.Forms.Label
    Friend WithEvents OPYDJTG As System.Windows.Forms.Label
    Friend WithEvents OPYTKTG As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label

End Class
