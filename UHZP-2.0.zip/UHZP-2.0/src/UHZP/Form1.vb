Public Class Form1
    Dim yu, zm, zd As String

    '�ŧi���N����
    Private DUSTEPS(), DUMASK() As Label

    '=================================================================================
    '=== �����Ұʸ��J
    '=================================================================================
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '���J����
        LoadLAB()
        '�M������
        Clean_Label()

        '�Ұʮ���ܥثe�ɶ�
        UpTime = DateSerial(2099, 12, 31) : DownTime = DateSerial(1901, 1, 1)
        CTL_Year.Value = DatePart("yyyy", Now)
        CTL_Month.Value = DatePart("m", Now)
        CTL_Day.Value = DatePart("d", Now)
        CTL_Hour.Value = DatePart("h", Now)
        CTL_Minute.Value = DatePart("n", Now)

        '�Cģ��P��
        WEEK_DAY = DatePart("w", Now)
        Seven_Luminaries_Day()

        'ReadProperN()
        UpTime = DateSerial(2099, 12, 31) : DownTime = DateSerial(1901, 1, 1)
        df_date()

        '�P�L
        ppc = 0
        Form2.Show()
        Me.Enabled = False

    End Sub

    '=================================================================================
    '=== �Ұʸ��J����
    '=================================================================================
    Sub LoadLAB()
        '�j�B����
        DUMASK = New Label() {dumask0, dumask1, dumask2, dumask3, dumask4, dumask5, dumask6, dumask7, dumask8, dumask9}
        DUSTEPS = New Label() {dusetp0, dusetp1, dusetp2, dusetp3, dusetp4, dusetp5, dusetp6, dusetp7, dusetp8, dusetp9}
    End Sub

    '=================================================================================
    '=== �ҰʲM������
    '=================================================================================
    Sub Clean_Label()
        '�ͤ��T
        DateLAB.Text = ""
        STMLAB.Text = ""
        SMTSLAB.Text = ""
        '�~����ɦr��
        YStrLAB.Text = ""
        MStrLAB.Text = ""
        DStrLAB.Text = ""
        SStrLAB.Text = ""
        '�|�W���ҲM��
        YTKLAB.Text = ""
        YTKTGLAB.Text = ""
        YDJLAB.Text = ""
        YDKLAB1.Text = ""
        YDKTGLAB1.Text = ""
        YDKLAB2.Text = ""
        YDKTGLAB2.Text = ""
        YDKLAB3.Text = ""
        YDKTGLAB3.Text = ""
        MTKLAB.Text = ""
        MTKTGLAB.Text = ""
        MDJLAB.Text = ""
        MDKLAB1.Text = ""
        MDKTGLAB1.Text = ""
        MDKLAB2.Text = ""
        MDKTGLAB2.Text = ""
        MDKLAB3.Text = ""
        MDKTGLAB3.Text = ""
        DTKLAB.Text = ""
        'DTKTGLAB.Text = ""
        DDJLAB.Text = ""
        DDKLAB1.Text = ""
        DDKTGLAB1.Text = ""
        DDKLAB2.Text = ""
        DDKTGLAB2.Text = ""
        DDKLAB3.Text = ""
        DDKTGLAB3.Text = ""
        STKLAB.Text = ""
        STKTGLAB.Text = ""
        SDJLAB.Text = ""
        SDKLAB1.Text = ""
        SDKTGLAB1.Text = ""
        SDKLAB2.Text = ""
        SDKTGLAB2.Text = ""
        SDKLAB3.Text = ""
        SDKTGLAB3.Text = ""

        '�j�B����r��
        DAStrLAB.Text = ""
        DateStrLAB.Text = ""

        '�j�B����
        dumask0.Text = "" : dumask1.Text = "" : dumask2.Text = "" : dumask3.Text = "" : dumask4.Text = "" : dumask5.Text = "" : dumask6.Text = "" : dumask7.Text = "" : dumask8.Text = "" : dumask9.Text = ""
        dusetp0.Text = "" : dusetp1.Text = "" : dusetp2.Text = "" : dusetp3.Text = "" : dusetp4.Text = "" : dusetp5.Text = "" : dusetp6.Text = "" : dusetp7.Text = "" : dusetp8.Text = "" : dusetp9.Text = ""

    End Sub
    '=================================================================================
    '=== ����ާ@�� ����ާ@
    '=================================================================================
    Private Sub CTL_Year_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CTL_Year.ValueChanged
        SolarCalendar(1) = CTL_Year.Value
        schindex = 0
        SolarCLC()
        df_date()

        '�~�����s DownTime �ץ�
        If datedown = 1 Then
            CTL_Year.Value = SolarCalendar(1)
            CTL_Month.Value = SolarCalendar(2)
            CTL_Day.Value = SolarCalendar(3)
        End If

    End Sub

    Private Sub CTL_Month_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CTL_Month.ValueChanged
        SolarCalendar(1) = CTL_Year.Value
        SolarCalendar(2) = CTL_Month.Value
        'SolarCalendar(3) = CTL_Day.Value
        'SolarCalendar(4) = CTL_Hour.Value
        'SolarCalendar(5) = CTL_Minute.Value
        schindex = 1
        SolarCLC()
        CTL_Year.Value = SolarCalendar(1)
        CTL_Month.Value = SolarCalendar(2)
        CTL_Day.Value = SolarCalendar(3)
        'CTL_Hour.Value = SolarCalendar(4)
        'CTL_Minute.Value = SolarCalendar(5)

        df_date()

    End Sub

    Private Sub CTL_Day_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CTL_Day.ValueChanged
        SolarCalendar(1) = CTL_Year.Value
        SolarCalendar(2) = CTL_Month.Value
        SolarCalendar(3) = CTL_Day.Value
        'SolarCalendar(4) = CTL_Hour.Value
        'SolarCalendar(5) = CTL_Minute.Value
        schindex = 2
        SolarCLC()
        CTL_Year.Value = SolarCalendar(1)
        CTL_Month.Value = SolarCalendar(2)
        CTL_Day.Value = SolarCalendar(3)
        'CTL_Hour.Value = SolarCalendar(4)
        'CTL_Minute.Value = SolarCalendar(5)

        df_date()

    End Sub

    Private Sub CTL_Hour_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CTL_Hour.ValueChanged
        SolarCalendar(1) = CTL_Year.Value
        SolarCalendar(2) = CTL_Month.Value
        SolarCalendar(3) = CTL_Day.Value
        SolarCalendar(4) = CTL_Hour.Value
        'SolarCalendar(5) = CTL_Minute.Value
        schindex = 3
        SolarCLC()
        CTL_Year.Value = SolarCalendar(1)
        CTL_Month.Value = SolarCalendar(2)
        CTL_Day.Value = SolarCalendar(3)
        CTL_Hour.Value = SolarCalendar(4)
        'CTL_Minute.Value = SolarCalendar(5)

        df_date()

    End Sub

    Private Sub CTL_Minute_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CTL_Minute.ValueChanged
        SolarCalendar(1) = CTL_Year.Value
        SolarCalendar(2) = CTL_Month.Value
        SolarCalendar(3) = CTL_Day.Value
        SolarCalendar(4) = CTL_Hour.Value
        SolarCalendar(5) = CTL_Minute.Value
        schindex = 4
        SolarCLC()
        CTL_Year.Value = SolarCalendar(1)
        CTL_Month.Value = SolarCalendar(2)
        CTL_Day.Value = SolarCalendar(3)
        CTL_Hour.Value = SolarCalendar(4)
        CTL_Minute.Value = SolarCalendar(5)

        df_date()

    End Sub

    '=================================================================================
    '=== ����ާ@��ܫ��s NOW
    '=================================================================================
    Private Sub NOW_TIME_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NOW_TIME.Click
        CTL_Year.Value = DatePart("yyyy", Now)
        CTL_Month.Value = DatePart("m", Now)
        CTL_Day.Value = DatePart("d", Now)
        CTL_Hour.Value = DatePart("h", Now)
        CTL_Minute.Value = DatePart("n", Now)

        '�Cģ��P��
        WEEK_DAY = DatePart("w", Now)
        Seven_Luminaries_Day()

        df_date()
    End Sub

    '=================================================================================
    '=== �ƽL���s
    '=================================================================================
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Form2.Show()
        Me.Enabled = False
    End Sub

    '=================================================================================
    '=== ����ާ@�B�z
    '=================================================================================
    Sub df_date()
        SolarYear = CTL_Year.Value
        SolarMonth = CTL_Month.Value
        SolarDay = CTL_Day.Value
        SolarHour = CTL_Hour.Value
        SolarMinute = CTL_Minute.Value

        LunarYear = 0 : LunarMonth = 0 : LunarDay = 0 : LunarHour = 0 : LunarLeap = 0

        Date_Trans()

        '�������
        MonthIn = LunarMonth
        DayIn = LunarDay
        LunarToStr()
        yu = LeapOut
        zm = MonthOut
        zd = DayOut

        ReadProperN()

        '�`�����
        JCHID = CSLING_DAY
        MJ = GanZhi(2, 2)
        month_sling()
        'SolarTermLAB.Text = Current_SolarTerm + "���" + Str(CSTM_DAY) + " ��" + Str(CSTM_HOUR) + " ��" + Str(CSTM_MINUTE) + " ��" + " " + SLING + "�Ψ�"
        LunarYMDH.Text = "���� " + ProperN(1, GanZhi(5, 1)) + ProperN(2, GanZhi(5, 2)) + "�~" + yu + zm + "��" + zd + "��" + ProperN(2, LunarHour) + "��  "
        LunarYMDH.Text = LunarYMDH.Text + Current_SolarTerm + "���" + Str(CSTM_DAY) + "��" + "" + SLING + "�Ψ�  " + WEEK_DAY_NAME

        '�Ѥz�a�����
        'KJLAB.Text = ProperN(1, GanZhi(1, 1)) + ProperN(2, GanZhi(1, 2)) + "�~ " + ProperN(1, GanZhi(2, 1)) + ProperN(2, GanZhi(2, 2)) + "�� " + ProperN(1, GanZhi(3, 1)) + ProperN(2, GanZhi(3, 2)) + "�� " + ProperN(1, GanZhi(4, 1)) + ProperN(2, GanZhi(4, 2)) + "��"

        '���B�z��
        RunP()

        '�p�G�w�P�L
        If ppc = 1 Then
            agex()
            USERLAB.Text = UserName + " " + Str(ages) + " ��"
        Else
            USERLAB.Text = ""
        End If

    End Sub

    '=================================================================================
    '=== �ϥΪ̸��
    '=================================================================================
    Sub user()
        '����~���ɤ�
        BirthData(1, 1) = SolarYear : BirthData(2, 1) = SolarMonth : BirthData(3, 1) = SolarDay : BirthData(4, 1) = SolarHour : BirthData(5, 1) = SolarMinute
        '����~���ɤ�
        BirthData(1, 2) = LunarYear : BirthData(2, 2) = LunarMonth : BirthData(3, 2) = LunarDay : BirthData(4, 2) = LunarHour
        '�~���ɤѤz
        BirthData(1, 3) = GanZhi(1, 1) : BirthData(2, 3) = GanZhi(2, 1) : BirthData(3, 3) = GanZhi(3, 1) : BirthData(4, 3) = GanZhi(4, 1)
        '�~���ɦa��
        BirthData(1, 4) = GanZhi(1, 2) : BirthData(2, 4) = GanZhi(2, 2) : BirthData(3, 4) = GanZhi(3, 2) : BirthData(4, 4) = GanZhi(4, 2)
        '�ͦ~�����Ѥz�a��
        BirthData(6, 1) = GanZhi(5, 1) : BirthData(6, 2) = GanZhi(5, 2)

        '���~/���~
        BirthData(7, 1) = BirthData(1, 3) Mod 2

        '�k�k�R�y
        destiny_create()

        '�p��j�B��B����P�_�B����
        getdaun_stime()

        '�|�W�짽
        ppc = 1
        bazu()

        '�j�B
        Daun()


        If ppc = 1 Then
            DownTime = DateSerial(BirthData(1, 1), BirthData(2, 1), BirthData(3, 1))
        Else
            DownTime = DateSerial(1901, 1, 1)
        End If


    End Sub

    '=================================================================================
    '=== �|�W�짽
    '=================================================================================
    Sub bazu()

        '==== �򥻸�T ===========================
        '����
        DateLAB.Text = DESTINY + " �褸 " + Str(BirthData(1, 1)) + "�~" + Str(BirthData(2, 1)) + "��" + Str(BirthData(3, 1)) + "��" + Str(BirthData(4, 1)) + "��" + Str(BirthData(5, 1)) + "��"
        '����
        MonthIn = BirthData(2, 2)
        DayIn = BirthData(3, 2)
        LunarToStr()
        yu = LeapOut
        zm = MonthOut
        zd = DayOut
        DateLAB.Text = DateLAB.Text + " (" + ProperN(1, BirthData(6, 1)) + ProperN(2, BirthData(6, 2)) + "�~" + yu + zm + "��" + zd + "��" + ProperN(2, BirthData(4, 2)) + "��)"

        '�X�͸`���ɤ� �q�v�Ψ�
        JCHID = BSTM_DAY
        MJ = BirthData(2, 4)
        month_sling()
        STMLAB.Text = SolarTerm + "���" + Str(BSTM_DAY) + " ��" + Str(BSTM_HOUR) + " ��" + Str(BSTM_MINUTE) + " ��" + " " + SLING + "�Ψ�"

        '���R�L��
        smts()
        SMTSLAB.Text = "�R�c:  " + ProperN(1, mkk) + ProperN(2, mkj) + "      ���c:  " + ProperN(1, skk) + ProperN(2, skj) + "        �L��:  " + ProperN(1, tik) + ProperN(2, tij) + "        ����: " + ProperN(1, sik) + ProperN(2, sij)

        '�j�B����r��
        DAStrLAB.Text = "�j�B"
        DateStrLAB.Text = "��B���"
        'DASTEPLAB.Text = "�I����ܤj�B������I"

        '==== �|�W ===========================
        '�~����ɦr��
        YStrLAB.Text = "�~"
        MStrLAB.Text = "��"
        DStrLAB.Text = "��"
        SStrLAB.Text = "��"

        '==== �~�W
        BTK = BirthData(1, 3)
        BDJ = BirthData(1, 4)
        KJTGC()
        '�Ѥz
        YTKLAB.ForeColor = Color.FromName(tk_color)
        YTKLAB.Text = ProperN(1, BTK)
        '�Ѥz�Q��
        YTKTGLAB.ForeColor = Color.FromName(tk_color)
        YTKTGLAB.Text = TKTG

        '�a��
        YDJLAB.ForeColor = Color.FromName(dk1_color)
        YDJLAB.Text = ProperN(2, BDJ)
        '�äz�D��
        YDKLAB1.ForeColor = Color.FromName(dk1_color)
        YDKLAB1.Text = ProperN(1, DK1)
        '�äz�D��Q��
        YDKTGLAB1.ForeColor = Color.FromName(dk1_color)
        YDKTGLAB1.Text = DK1TG

        '�äz����
        If DK2 = 0 Then
            '�äz
            YDKLAB2.Text = ""
            '�Q��
            YDKTGLAB2.Text = ""
        Else
            '�äz
            YDKLAB2.ForeColor = Color.FromName(dk2_color)
            YDKLAB2.Text = ProperN(1, DK2)
            '�Q��
            YDKTGLAB2.ForeColor = Color.FromName(dk2_color)
            YDKTGLAB2.Text = DK2TG
        End If

        '�äz�l��
        If DK3 = 0 Then
            '�äz
            YDKLAB3.Text = ""
            '�Q��
            YDKTGLAB3.Text = ""
        Else
            '�äz
            YDKLAB3.ForeColor = Color.FromName(dk3_color)
            YDKLAB3.Text = ProperN(1, DK3)
            '�Q��
            YDKTGLAB3.ForeColor = Color.FromName(dk3_color)
            YDKTGLAB3.Text = DK3TG
        End If

        '==== ��W
        BTK = BirthData(2, 3)
        BDJ = BirthData(2, 4)
        KJTGC()
        '�Ѥz
        MTKLAB.ForeColor = Color.FromName(tk_color)
        MTKLAB.Text = ProperN(1, BTK)
        '�Ѥz�Q��
        MTKTGLAB.ForeColor = Color.FromName(tk_color)
        MTKTGLAB.Text = TKTG

        '�a��
        MDJLAB.ForeColor = Color.FromName(dk1_color)
        MDJLAB.Text = ProperN(2, BDJ)
        '�äz�D��
        MDKLAB1.ForeColor = Color.FromName(dk1_color)
        MDKLAB1.Text = ProperN(1, DK1)
        '�äz�D��Q��
        MDKTGLAB1.ForeColor = Color.FromName(dk1_color)
        MDKTGLAB1.Text = DK1TG

        '�äz����
        If DK2 = 0 Then
            '�äz
            MDKLAB2.Text = ""
            '�Q��
            MDKTGLAB2.Text = ""
        Else
            '�äz
            MDKLAB2.ForeColor = Color.FromName(dk2_color)
            MDKLAB2.Text = ProperN(1, DK2)
            '�Q��
            MDKTGLAB2.ForeColor = Color.FromName(dk2_color)
            MDKTGLAB2.Text = DK2TG
        End If

        '�äz�l��
        If DK3 = 0 Then
            '�äz
            MDKLAB3.Text = ""
            '�Q��
            MDKTGLAB3.Text = ""
        Else
            '�äz
            MDKLAB3.ForeColor = Color.FromName(dk3_color)
            MDKLAB3.Text = ProperN(1, DK3)
            '�Q��
            MDKTGLAB3.ForeColor = Color.FromName(dk3_color)
            MDKTGLAB3.Text = DK3TG
        End If

        '==== ��W
        BTK = BirthData(3, 3)
        BDJ = BirthData(3, 4)
        KJTGC()
        '�Ѥz
        DTKLAB.ForeColor = Color.FromName(tk_color)
        DTKLAB.Text = ProperN(1, BTK)
        '�Ѥz�Q��
        'DTKTGLAB.ForeColor = Color.FromName(tk_color)
        'DTKTGLAB.Text = TKTG

        '�a��
        DDJLAB.ForeColor = Color.FromName(dk1_color)
        DDJLAB.Text = ProperN(2, BDJ)
        '�äz�D��
        DDKLAB1.ForeColor = Color.FromName(dk1_color)
        DDKLAB1.Text = ProperN(1, DK1)
        '�äz�D��Q��
        DDKTGLAB1.ForeColor = Color.FromName(dk1_color)
        DDKTGLAB1.Text = DK1TG

        '�äz����
        If DK2 = 0 Then
            '�äz
            DDKLAB2.Text = ""
            '�Q��
            DDKTGLAB2.Text = ""
        Else
            '�äz
            DDKLAB2.ForeColor = Color.FromName(dk2_color)
            DDKLAB2.Text = ProperN(1, DK2)
            '�Q��
            DDKTGLAB2.ForeColor = Color.FromName(dk2_color)
            DDKTGLAB2.Text = DK2TG
        End If

        '�äz�l��
        If DK3 = 0 Then
            '�äz
            DDKLAB3.Text = ""
            '�Q��
            DDKTGLAB3.Text = ""
        Else
            '�äz
            DDKLAB3.ForeColor = Color.FromName(dk3_color)
            DDKLAB3.Text = ProperN(1, DK3)
            '�Q��
            DDKTGLAB3.ForeColor = Color.FromName(dk3_color)
            DDKTGLAB3.Text = DK3TG
        End If

        '==== �ɬW
        BTK = BirthData(4, 3)
        BDJ = BirthData(4, 4)
        KJTGC()
        '�Ѥz
        STKLAB.ForeColor = Color.FromName(tk_color)
        STKLAB.Text = ProperN(1, BTK)
        '�Ѥz�Q��
        STKTGLAB.ForeColor = Color.FromName(tk_color)
        STKTGLAB.Text = TKTG

        '�a��
        SDJLAB.ForeColor = Color.FromName(dk1_color)
        SDJLAB.Text = ProperN(2, BDJ)
        '�äz�D��
        SDKLAB1.ForeColor = Color.FromName(dk1_color)
        SDKLAB1.Text = ProperN(1, DK1)
        '�äz�D��Q��
        SDKTGLAB1.ForeColor = Color.FromName(dk1_color)
        SDKTGLAB1.Text = DK1TG

        '�äz����
        If DK2 = 0 Then
            '�äz
            SDKLAB2.Text = ""
            '�Q��
            SDKTGLAB2.Text = ""
        Else
            '�äz
            SDKLAB2.ForeColor = Color.FromName(dk2_color)
            SDKLAB2.Text = ProperN(1, DK2)
            '�Q��
            SDKTGLAB2.ForeColor = Color.FromName(dk2_color)
            SDKTGLAB2.Text = DK2TG
        End If

        '�äz�l��
        If DK3 = 0 Then
            '�äz
            SDKLAB3.Text = ""
            '�Q��
            SDKTGLAB3.Text = ""
        Else
            '�äz
            SDKLAB3.ForeColor = Color.FromName(dk3_color)
            SDKLAB3.Text = ProperN(1, DK3)
            '�Q��
            SDKTGLAB3.ForeColor = Color.FromName(dk3_color)
            SDKTGLAB3.Text = DK3TG
        End If

    End Sub
    '=================================================================================
    '=== �j�B
    '=================================================================================
    Sub Daun()
        Dim i As Integer
        Dim DAUN_FONT As String

        '�j�B�z��Q���r��
        'DAUN_FONT = "�ө���"
        DAUN_FONT = "�L�n������"

        '�M���ʺA����
        For i = Me.Controls.Count - 1 To 0 Step -1
            If TypeOf Me.Controls(i) Is Label And Mid(Me.Controls(i).Name.ToString, 1, 3) = "DA_" Then
                Me.Controls.Remove(Me.Controls(i))
            End If
        Next

        Dim dakg, dadate As Label

        For i = 1 To 10
            '�j�B�z�����
            dakg = New Label
            dakg.Name = "DA_KG"
            dakg.Text = ProperN(1, dauntk(i)) + ProperN(2, daundj(i))
            dakg.Font = New Font(DAUN_FONT, 9, FontStyle.Regular)
            dakg.ForeColor = Color.FromName("MediumSeaGreen")
            dakg.AutoSize = True
            dakg.Location = New Point(610, 60 + (i * 20))
            Me.Controls.Add(dakg)
            '��j�B�������
            dadate = New Label
            dadate.Name = "DA_DATE"
            dadate.Text = daundate(i)
            dadate.Font = New Font(DAUN_FONT, 9, FontStyle.Regular)
            dadate.ForeColor = Color.FromName("MediumSeaGreen")
            dadate.AutoSize = True
            dadate.Location = New Point(644, 60 + (i * 20))
            Me.Controls.Add(dadate)

        Next

        Dim ageslab, tklab, tktglab, djlab, dk1lab, dk1tglab, dk2lab, dk2tglab, dk3lab, dk3tglab As Label

        For i = 1 To 10
            ageslab = New Label
            tklab = New Label
            djlab = New Label
            tktglab = New Label
            dk1lab = New Label
            dk1tglab = New Label
            dk2lab = New Label
            dk2tglab = New Label
            dk3lab = New Label
            dk3tglab = New Label

            '��B����
            ageslab = New Label
            ageslab.Name = "DA_AGES"
            ageslab.Text = daunage(i)
            ageslab.TextAlign = ContentAlignment.MiddleCenter
            ageslab.Font = New Font(DAUN_FONT, 9, FontStyle.Regular)
            ageslab.ForeColor = Color.FromName("Red")
            ageslab.AutoSize = False
            ageslab.Width = 61
            ageslab.Height = 12
            ageslab.Location = New Point(696 - ((i - 1) * 75), 339)
            Me.Controls.Add(ageslab)

            '�j�B�z��
            '�Ѥz
            BTK = dauntk(i)
            BDJ = daundj(i)
            KJTGC()
            tklab.Name = "DA_TK"
            tklab.Text = ProperN(1, dauntk(i))
            tklab.Font = New Font(DAUN_FONT, 16, FontStyle.Bold)
            tklab.ForeColor = Color.FromName(tk_color)
            tklab.AutoSize = True
            tklab.Location = New Point(710 - ((i - 1) * 75), 370)
            Me.Controls.Add(tklab)

            '�Ѥz�Q��
            tktglab.Name = "DA_TKTG"
            tktglab.Text = TKTG
            tktglab.Font = New Font(DAUN_FONT, 10, FontStyle.Regular)
            tktglab.ForeColor = Color.FromName(tk_color)
            tktglab.AutoSize = True
            tktglab.Location = New Point(716 - ((i - 1) * 75), 355)
            Me.Controls.Add(tktglab)

            '�a��
            djlab.Name = "DA_DJ"
            djlab.Text = ProperN(2, daundj(i))
            djlab.Font = New Font(DAUN_FONT, 16, FontStyle.Bold)
            djlab.ForeColor = Color.FromName(dk1_color)
            djlab.AutoSize = True
            djlab.Location = New Point(710 - ((i - 1) * 75), 394)
            Me.Controls.Add(djlab)

            '�a���äz�D��
            dk1lab.Name = "DA_DK1"
            dk1lab.Text = ProperN(1, DK1)
            dk1lab.Font = New Font(DAUN_FONT, 10, FontStyle.Regular)
            dk1lab.ForeColor = Color.FromName(dk1_color)
            dk1lab.AutoSize = True
            dk1lab.Location = New Point(736 - ((i - 1) * 75), 420)
            Me.Controls.Add(dk1lab)

            '�a���äz�D��Q��
            dk1tglab.Name = "DA_DK1TG"
            dk1tglab.Text = DK1TG
            dk1tglab.Font = New Font(DAUN_FONT, 10, FontStyle.Regular)
            dk1tglab.ForeColor = Color.FromName(dk1_color)
            dk1tglab.AutoSize = True
            dk1tglab.Location = New Point(736 - ((i - 1) * 75), 436)
            Me.Controls.Add(dk1tglab)

            If DK2 > 0 Then
                '�a���äz����
                dk2lab.Name = "DA_DK2"
                dk2lab.Text = ProperN(1, DK2)
                dk2lab.Font = New Font(DAUN_FONT, 10, FontStyle.Regular)
                dk2lab.ForeColor = Color.FromName(dk2_color)
                dk2lab.AutoSize = True
                dk2lab.Location = New Point(716 - ((i - 1) * 75), 420)
                Me.Controls.Add(dk2lab)

                '�a���äz����Q��
                dk2tglab.Name = "DA_DK2TG"
                dk2tglab.Text = DK2TG
                dk2tglab.Font = New Font(DAUN_FONT, 10, FontStyle.Regular)
                dk2tglab.ForeColor = Color.FromName(dk2_color)
                dk2tglab.AutoSize = True
                dk2tglab.Location = New Point(716 - ((i - 1) * 75), 436)
                Me.Controls.Add(dk2tglab)

            End If

            If DK3 > 0 Then
                '�a���äz�l��
                dk3lab.Name = "DA_DK3"
                dk3lab.Text = ProperN(1, DK3)
                dk3lab.Font = New Font(DAUN_FONT, 10, FontStyle.Regular)
                dk3lab.ForeColor = Color.FromName(dk3_color)
                dk3lab.AutoSize = True
                dk3lab.Location = New Point(696 - ((i - 1) * 75), 420)
                Me.Controls.Add(dk3lab)

                '�a���äz�l��Q��
                dk3tglab.Name = "DA_DK3TG"
                dk3tglab.Text = DK3TG
                dk3tglab.Font = New Font(DAUN_FONT, 10, FontStyle.Regular)
                dk3tglab.ForeColor = Color.FromName(dk3_color)
                dk3tglab.AutoSize = True
                dk3tglab.Location = New Point(696 - ((i - 1) * 75), 436)
                Me.Controls.Add(dk3tglab)
            End If

        Next
    End Sub
    '=================================================================================
    '=== ���B
    '=================================================================================
    Sub RunP()

        Dim OPT_FONT As String

        '�ާ@�Ϥz��Q���r��
        'OPT_FONT = "�ө���"
        OPT_FONT = "�L�n������"

        '�ާ@�Ϧ~���ɦr����Ҧr��
        Label19.Font = New Font(OPT_FONT, 9, FontStyle.Regular)
        Label20.Font = New Font(OPT_FONT, 9, FontStyle.Regular)
        Label21.Font = New Font(OPT_FONT, 9, FontStyle.Regular)
        Label22.Font = New Font(OPT_FONT, 9, FontStyle.Regular)

        If ppc = 1 Then
            Dim x, y, z, current_date As String
            Dim i As Integer

            current_date = DateSerial(SolarYear, SolarMonth, SolarDay)
            x = SolarHour
            y = SolarMinute
            z = x + ":" + y
            CTIME = current_date + " " + z
            daun_setp()

            '�M���j�B����
            'For i = Me.Controls.Count - 1 To 0 Step -1
            'If TypeOf Me.Controls(i) Is Label And Mid(Me.Controls(i).Text.ToString, 1, 3) = "��" Then
            'Me.Controls.Remove(Me.Controls(i))
            'End If
            'Next

            '�j�B����
            Dim dusp As Integer
            dusp = DA_STEP - 1
  
            For i = 0 To 9
                If i = dusp Then
                    DUMASK(i).Text = "��"
                    DUSTEPS(i).Text = "��"
                Else
                    DUMASK(i).Text = ""
                    DUSTEPS(i).Text = ""
                End If
            Next

        End If

        '==== �y�~
        BTK = GanZhi(1, 1)
        BDJ = GanZhi(1, 2)
        KJTGC()
        '�Ѥz
        OPYTK.ForeColor = Color.FromName(tk_color)
        OPYTK.Text = ProperN(1, BTK)
        OPYTK.Font = New Font(OPT_FONT, 12, FontStyle.Bold)

        If ppc = 1 Then
            '�Ѥz�Q��
            OPYTKTG.ForeColor = Color.FromName(tk_color)
            OPYTKTG.Text = TKTG
            OPYTKTG.Font = New Font(OPT_FONT, 9, FontStyle.Regular)
        End If

        '�a��
        OPYDJ.ForeColor = Color.FromName(dk1_color)
        OPYDJ.Text = ProperN(2, BDJ)
        OPYDJ.Font = New Font(OPT_FONT, 12, FontStyle.Bold)
        If ppc = 1 Then
            '�äz�D��Q��
            OPYDJTG.ForeColor = Color.FromName(dk1_color)
            OPYDJTG.Text = DK1TG
            OPYDJTG.Font = New Font(OPT_FONT, 9, FontStyle.Regular)
        End If

        '==== �y��
        BTK = GanZhi(2, 1)
        BDJ = GanZhi(2, 2)
        KJTGC()
        '�Ѥz
        OPMTK.ForeColor = Color.FromName(tk_color)
        OPMTK.Text = ProperN(1, BTK)
        OPMTK.Font = New Font(OPT_FONT, 12, FontStyle.Bold)

        If ppc = 1 Then
            '�Ѥz�Q��
            OPMTKTG.ForeColor = Color.FromName(tk_color)
            OPMTKTG.Text = TKTG
            OPMTKTG.Font = New Font(OPT_FONT, 9, FontStyle.Regular)
        End If

        '�a��
        OPMDJ.ForeColor = Color.FromName(dk1_color)
        OPMDJ.Text = ProperN(2, BDJ)
        OPMDJ.Font = New Font(OPT_FONT, 12, FontStyle.Bold)
        If ppc = 1 Then
            '�äz�D��Q��
            OPMDJTG.ForeColor = Color.FromName(dk1_color)
            OPMDJTG.Text = DK1TG
            OPMDJTG.Font = New Font(OPT_FONT, 9, FontStyle.Regular)
        End If

        '==== �y��
        BTK = GanZhi(3, 1)
        BDJ = GanZhi(3, 2)
        KJTGC()
        '�Ѥz
        OPDTK.ForeColor = Color.FromName(tk_color)
        OPDTK.Text = ProperN(1, BTK)
        OPDTK.Font = New Font(OPT_FONT, 12, FontStyle.Bold)

        If ppc = 1 Then
            '�Ѥz�Q��
            OPDTKTG.ForeColor = Color.FromName(tk_color)
            OPDTKTG.Text = TKTG
            OPDTKTG.Font = New Font(OPT_FONT, 9, FontStyle.Regular)
        End If

        '�a��
        OPDDJ.ForeColor = Color.FromName(dk1_color)
        OPDDJ.Text = ProperN(2, BDJ)
        OPDDJ.Font = New Font(OPT_FONT, 12, FontStyle.Bold)
        If ppc = 1 Then
            '�äz�D��Q��
            OPDDJTG.ForeColor = Color.FromName(dk1_color)
            OPDDJTG.Text = DK1TG
            OPDDJTG.Font = New Font(OPT_FONT, 9, FontStyle.Regular)
        End If

        '==== �y��
        BTK = GanZhi(4, 1)
        BDJ = GanZhi(4, 2)
        KJTGC()
        '�Ѥz
        OPSTK.ForeColor = Color.FromName(tk_color)
        OPSTK.Text = ProperN(1, BTK)
        OPSTK.Font = New Font(OPT_FONT, 12, FontStyle.Bold)

        If ppc = 1 Then
            '�Ѥz�Q��
            OPSTKTG.ForeColor = Color.FromName(tk_color)
            OPSTKTG.Text = TKTG
            OPSTKTG.Font = New Font(OPT_FONT, 9, FontStyle.Regular)
        End If

        '�a��
        OPSDJ.ForeColor = Color.FromName(dk1_color)
        OPSDJ.Text = ProperN(2, BDJ)
        OPSDJ.Font = New Font(OPT_FONT, 12, FontStyle.Bold)
        If ppc = 1 Then
            '�äz�D��Q��
            OPSDJTG.ForeColor = Color.FromName(dk1_color)
            OPSDJTG.Text = DK1TG
            OPSDJTG.Font = New Font(OPT_FONT, 9, FontStyle.Regular)
        End If

    End Sub

    '=================================================================================
    '=== ������I
    '=================================================================================
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If ppc = 1 Then
            Form3.Show()
        End If
    End Sub

    '=================================================================================
    '=== �y�~
    '=================================================================================
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If ppc = 1 Then
            Form4.Show()
        End If

    End Sub

    '=================================================================================
    '=== �p�B
    '=================================================================================
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If ppc = 1 Then
            Form5.Show()
        End If

    End Sub

    '=================================================================================
    '=== ����
    '=================================================================================
    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        If ppc = 1 Then
            Form6.Show()
        End If

    End Sub

    '=================================================================================
    '=== ��H
    '=================================================================================
    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        If ppc = 1 Then
            Form8.Show()
        End If

    End Sub

    '=================================================================================
    '=== �j�B����֭p�`��
    '=================================================================================
    Private Sub dusetp0_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dusetp0.Click
        If ppc = 1 Then
            FEINDEX = 1
            Form7.Show()
        End If

    End Sub

    Private Sub dusetp1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dusetp1.Click
        If ppc = 1 Then
            FEINDEX = 1
            Form7.Show()
        End If

    End Sub

    Private Sub dusetp2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dusetp2.Click
        If ppc = 1 Then
            FEINDEX = 1
            Form7.Show()
        End If

    End Sub

    Private Sub dusetp3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dusetp3.Click
        If ppc = 1 Then
            FEINDEX = 1
            Form7.Show()
        End If

    End Sub

    Private Sub dusetp4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dusetp4.Click
        If ppc = 1 Then
            FEINDEX = 1
            Form7.Show()
        End If

    End Sub

    Private Sub dusetp5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dusetp5.Click
        If ppc = 1 Then
            FEINDEX = 1
            Form7.Show()
        End If

    End Sub

    Private Sub dusetp6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dusetp6.Click
        If ppc = 1 Then
            FEINDEX = 1
            Form7.Show()
        End If

    End Sub

    Private Sub dusetp7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dusetp7.Click
        If ppc = 1 Then
            FEINDEX = 1
            Form7.Show()
        End If

    End Sub

    Private Sub dusetp8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dusetp8.Click
        If ppc = 1 Then
            FEINDEX = 1
            Form7.Show()
        End If

    End Sub

    Private Sub dusetp9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dusetp9.Click
        If ppc = 1 Then
            FEINDEX = 1
            Form7.Show()
        End If

    End Sub

    '=================================================================================
    '=== �y�~����֭p�`��
    '=================================================================================
    Private Sub Label19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label19.Click
        If ppc = 1 Then
            FEINDEX = 2
            Form7.Show()
        End If
    End Sub

    '=================================================================================
    '=== �y�뤭��֭p�`��
    '=================================================================================
    Private Sub Label20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label20.Click
        If ppc = 1 Then
            FEINDEX = 3
            Form7.Show()
        End If
    End Sub

    '=================================================================================
    '=== �y�餭��֭p�`��
    '=================================================================================
    Private Sub Label21_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label21.Click
        If ppc = 1 Then
            FEINDEX = 4
            Form7.Show()
        End If

    End Sub

    '=================================================================================
    '=== �y�ɤ���֭p�`��
    '=================================================================================
    Private Sub Label22_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label22.Click
        If ppc = 1 Then
            FEINDEX = 5
            Form7.Show()
        End If

    End Sub

End Class
