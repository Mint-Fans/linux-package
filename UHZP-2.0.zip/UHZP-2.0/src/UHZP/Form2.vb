Public Class Form2
    Dim CONUT, INDEX, MAX_INDEX, MAX_DAY As Integer
    Dim cm0, cm1, cm2, cm3, cm4 As Integer
    Dim Radio_TEXT As String '�k�k�ﶵ

    '=================================================================================
    '=== �������J�]�w
    '=================================================================================
    '����Ұʫ�ʧ@
    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ENTERLIST()
        CHECKLIST()
        InputData()
        CHECKLIST()

    End Sub
    '�����������ʧ@ VB2005
    Private Sub Form2_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        Form1.Enabled = True
    End Sub
    '����w�����ʧ@ VB2010
    'Private Sub Form2_FormClosed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.FormClosed
    '   Form1.Enabled = True
    'End Sub

    '=================================================================================
    '=== �~���ɤ�
    '=================================================================================
    '�~
    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        cm0 = ComboBox1.Text
        ComboBox2.Enabled = True
    End Sub

    '��
    Private Sub ComboBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox2.SelectedIndexChanged
        cm1 = ComboBox2.Text

        If cm1 = 1 Or cm1 = 3 Or cm1 = 5 Or cm1 = 7 Or cm1 = 8 Or cm1 = 10 Or cm1 = 12 Then
            MAX_DAY = 31
            ComboBox3.Items.Clear()
            ComboBox3.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"})
        ElseIf cm1 = 4 Or cm1 = 6 Or cm1 = 9 Or cm1 = 11 Then
            MAX_DAY = 30
            ComboBox3.Items.Clear()
            ComboBox3.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30"})
        Else
            If (cm0 Mod 4) = 0 And (cm0 Mod 100) <> 0 Then
                MAX_DAY = 29
                ComboBox3.Items.Clear()
                ComboBox3.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29"})
            Else
                MAX_DAY = 28
                ComboBox3.Items.Clear()
                ComboBox3.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28"})
            End If
        End If
        ComboBox3.Enabled = True

        If cm2 > MAX_DAY Then
            ComboBox3.Text = ""
            cm2 = MAX_DAY
        End If
    End Sub

    '��
    Private Sub ComboBox3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox3.SelectedIndexChanged
        cm2 = ComboBox3.Text
        ComboBox4.Enabled = True
        DateProc()
    End Sub
    '��
    Private Sub ComboBox4_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox4.SelectedIndexChanged
        cm3 = ComboBox4.Text
        ComboBox5.Enabled = True
        DateProc()
    End Sub
    '��
    Private Sub ComboBox5_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox5.SelectedIndexChanged
        cm4 = ComboBox5.Text
        DateProc()
    End Sub
    '=================================================================================
    '=== �X�ͦ~���ɿ�ܳB�z
    '=================================================================================
    Sub DateProc()
        Dim yu, zm, zd As String
        SolarYear = cm0
        SolarMonth = cm1
        SolarDay = cm2
        SolarHour = cm3
        SolarMinute = cm4

        LunarYear = 0 : LunarMonth = 0 : LunarDay = 0 : LunarHour = 0 : LunarLeap = 0
        Date_Trans()

        '����~������
        'Label4.Text = "����  " + ProperN(1, Point4(1, 1)) + ProperN(2, Point4(1, 2)) + "�~ " + yu + mn + "�� " + an + "�� "
        MonthIn = LunarMonth
        DayIn = LunarDay
        LunarToStr()
        yu = LeapOut
        zm = MonthOut
        zd = DayOut

        If ComboBox4.Enabled = True Then
            Label4.Text = "����" + Str(LunarYear) + "�~" + yu + zm + "��" + zd + "��" + ProperN(2, LunarHour) + "��"
        Else
            Label4.Text = "����" + Str(LunarYear) + "�~" + yu + zm + "��" + zd + "��"
        End If

    End Sub

    '=================================================================================
    '=== �������
    '=================================================================================
    '�������
    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged

        '�M��ƶq�j��0
        'Count �����ެO0�}�l
        If ListView1.Items.Count > 0 Then
            '���ɤ����ҥ�
            ComboBox2.Enabled = True
            ComboBox3.Enabled = True
            ComboBox4.Enabled = True
            ComboBox5.Enabled = True

            '�R���ק���s�ҥ�
            CHECKLIST()
            '��ܯ���(���1����=0, ���2����=1)
            INDEX = ListView1.FocusedItem.Index

            If INDEX > -1 Then
                '��ܳ���
                DateProc()

                'Ū��������
                '�m�W
                TextBox1.Text = ListView1.Items(INDEX).Text
                '�ʧO
                If Radio1.Text = ListView1.Items(INDEX).SubItems(1).Text Then
                    Radio1.Checked = True
                Else
                    Radio2.Checked = True
                End If
                '�~���ɤ�
                ComboBox1.Text = ListView1.Items(INDEX).SubItems(2).Text
                ComboBox2.Text = ListView1.Items(INDEX).SubItems(3).Text
                ComboBox3.Text = ListView1.Items(INDEX).SubItems(4).Text
                ComboBox4.Text = ListView1.Items(INDEX).SubItems(5).Text
                ComboBox5.Text = ListView1.Items(INDEX).SubItems(6).Text
            End If
        End If
    End Sub

    '=================================================================================
    '=== �@�Τl�{��
    '=================================================================================
    '�R���ק���s�ҥ�/�T��
    Sub CHECKLIST()
        If ListView1.Items.Count = 0 Then
            '�T�ΧR���ק���s
            Button3.Enabled = False
            Button4.Enabled = False
        Else
            '�ҥΧR���ק���s
            Button3.Enabled = True
            Button4.Enabled = True
        End If

    End Sub

    '�M��w�B�z
    Sub ENTERLIST()
        '�M���m�W
        TextBox1.Text = ""
        TextBox1.Focus()
        '���ɤ����T��
        ComboBox2.Enabled = False
        ComboBox3.Enabled = False
        ComboBox4.Enabled = False
        ComboBox5.Enabled = False
        '�M���������
        Label4.Text = ""
    End Sub
    '�O�s�M����ɮ�
    Sub SAVELIST()
        Dim I1 As Integer
        Dim I2 As Integer
        Dim ss As String
        Dim df As String

        df = My.Application.Info.DirectoryPath
        If Microsoft.VisualBasic.Right(df, 1) <> "\" Then df = df + "\"

        FileOpen(1, df + "User", OpenMode.Output)
        CONUT = ListView1.Items.Count
        MAX_INDEX = CONUT - 1

        For I1 = 0 To MAX_INDEX
            ss = ListView1.Items(I1).Text & Chr(9)
            For I2 = 1 To 5
                ss = ss + ListView1.Items.Item(I1).SubItems(I2).Text + Chr(9)
            Next
            ss = ss + ListView1.Items(I1).SubItems(6).Text
            PrintLine(1, ss)
        Next
        FileClose()

    End Sub
    '�ɤJUSER���
    Sub InputData()
        Dim sp(7) As String
        Dim st As String
        Dim ss As Integer
        Dim df As String

        df = My.Application.Info.DirectoryPath
        If Microsoft.VisualBasic.Right(df, 1) <> "\" Then df = df + "\"

        Dim File_Path As String
        File_Path = df + "User"

        If System.IO.File.Exists(File_Path) Then
            FileOpen(1, File_Path, OpenMode.Input)

            ss = 0
            Do While Not EOF(1)
                st = LineInput(1) '��J��Ʀr��
                If st <> "" Then
                    sp = Split(st, Chr(9)) '�HTAB��Ϥ�
                    '�m�W
                    ListView1.Items.Add(sp(0))
                    '�ʧO/�~/��/��/��/��
                    ListView1.Items(ss).SubItems.Add(sp(1))
                    ListView1.Items(ss).SubItems.Add(sp(2))
                    ListView1.Items(ss).SubItems.Add(sp(3))
                    ListView1.Items(ss).SubItems.Add(sp(4))
                    ListView1.Items(ss).SubItems.Add(sp(5))
                    ListView1.Items(ss).SubItems.Add(sp(6))

                    ss = ss + 1
                End If
            Loop
            FileClose()
        Else
            'MsgBox("USER ��󤣦s�b�A�۰ʫإ߷s�� USER ���C")
            Dim NEW_USER As Object
            NEW_USER = System.IO.File.Create(File_Path)
            NEW_USER.close()
        End If


    End Sub

    '=================================================================================
    '=== �T�w���s
    '=================================================================================
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Erase BirthData
        ReDim BirthData(7, 4)

        If cm0 > 0 And cm1 > 0 And cm2 > 0 And cm3 > -1 And cm4 > -1 Then

            '�W��
            UserName = TextBox1.Text

            '�ʧO
            If Radio1.Checked = True Then
                '�k
                BirthData(7, 2) = 1
            Else
                '�k
                BirthData(7, 2) = 0
            End If

            SolarYear = cm0
            SolarMonth = cm1
            SolarDay = cm2
            SolarHour = cm3
            SolarMinute = cm4

            LunarYear = 0 : LunarMonth = 0 : LunarDay = 0 : LunarHour = 0 : LunarLeap = 0
            Date_Trans()

            Form1.user()

            Form1.CTL_Year.Value = DatePart("yyyy", Now)
            Form1.CTL_Month.Value = DatePart("m", Now)
            Form1.CTL_Day.Value = DatePart("d", Now)
            Form1.CTL_Hour.Value = DatePart("h", Now)
            Form1.CTL_Minute.Value = DatePart("n", Now)

            Form1.df_date()

            Me.Close()

        End If

    End Sub

    '=================================================================================
    '=== ��J���s
    '=================================================================================
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        '�n�K�[������
        CONUT = ListView1.Items.Count

        '�m�W
        ListView1.Items.Add(TextBox1.Text)

        '���o���ʧO
        If Radio1.Checked = True Then
            Radio_TEXT = Radio1.Text
        Else
            Radio_TEXT = Radio2.Text
        End If

        '�ʧO/�~/��/��/��/��
        If cm0 > 0 And cm1 > 0 And cm2 > 0 And cm3 > -1 And cm4 > -1 Then
            ListView1.Items(CONUT).SubItems.Add(Radio_TEXT)
            ListView1.Items(CONUT).SubItems.Add(cm0)
            ListView1.Items(CONUT).SubItems.Add(cm1)
            ListView1.Items(CONUT).SubItems.Add(cm2)
            ListView1.Items(CONUT).SubItems.Add(cm3)
            ListView1.Items(CONUT).SubItems.Add(cm4)

            CHECKLIST()
            ENTERLIST()
            SAVELIST()
        End If

    End Sub

    '=================================================================================
    '=== �ק���s
    '=================================================================================
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        '���������
        INDEX = ListView1.FocusedItem.Index

        '�m�W
        ListView1.Items(INDEX).Text = TextBox1.Text


        '���o���ʧO
        If Radio1.Checked = True Then
            Radio_TEXT = Radio1.Text
        Else
            Radio_TEXT = Radio2.Text
        End If

        '�ʧO/�~/��/��/��/��
        ListView1.Items(INDEX).SubItems(1).Text = Radio_TEXT
        ListView1.Items(INDEX).SubItems(2).Text = ComboBox1.Text
        ListView1.Items(INDEX).SubItems(3).Text = ComboBox2.Text
        ListView1.Items(INDEX).SubItems(4).Text = ComboBox3.Text
        ListView1.Items(INDEX).SubItems(5).Text = ComboBox4.Text
        ListView1.Items(INDEX).SubItems(6).Text = ComboBox5.Text

        CHECKLIST()
        ENTERLIST()
        SAVELIST()

    End Sub

    '=================================================================================
    '=== �R�����s
    '=================================================================================
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        '���������
        INDEX = ListView1.FocusedItem.Index

        '�R������
        ListView1.Items.RemoveAt((INDEX))

        CHECKLIST()
        ENTERLIST()
        SAVELIST()

    End Sub

End Class