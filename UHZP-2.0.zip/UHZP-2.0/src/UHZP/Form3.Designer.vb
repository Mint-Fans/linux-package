﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form3))
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar
        Me.FS1 = New System.Windows.Forms.Label
        Me.TG1 = New System.Windows.Forms.Label
        Me.NL1 = New System.Windows.Forms.Label
        Me.FS2 = New System.Windows.Forms.Label
        Me.TG2 = New System.Windows.Forms.Label
        Me.ProgressBar2 = New System.Windows.Forms.ProgressBar
        Me.NL2 = New System.Windows.Forms.Label
        Me.FS3 = New System.Windows.Forms.Label
        Me.TG3 = New System.Windows.Forms.Label
        Me.ProgressBar3 = New System.Windows.Forms.ProgressBar
        Me.NL3 = New System.Windows.Forms.Label
        Me.FS4 = New System.Windows.Forms.Label
        Me.TG4 = New System.Windows.Forms.Label
        Me.ProgressBar4 = New System.Windows.Forms.ProgressBar
        Me.NL4 = New System.Windows.Forms.Label
        Me.ProgressBar5 = New System.Windows.Forms.ProgressBar
        Me.NL5 = New System.Windows.Forms.Label
        Me.FS5 = New System.Windows.Forms.Label
        Me.TG5 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(14, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(325, 41)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "印星比劫分數相加如果超過30分或以上，可論定為身強。但有一種狀況是分數為25分，月令為印比，則這種狀況也算身強(因為月令份量較重的關係)。"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(14, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(281, 12)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "單一五行在7分以下太弱，8至16分平，17分以上旺。"
        '
        'ProgressBar1
        '
        Me.ProgressBar1.BackColor = System.Drawing.Color.White
        Me.ProgressBar1.ForeColor = System.Drawing.Color.LimeGreen
        Me.ProgressBar1.Location = New System.Drawing.Point(90, 105)
        Me.ProgressBar1.Maximum = 60
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(215, 22)
        Me.ProgressBar1.TabIndex = 2
        '
        'FS1
        '
        Me.FS1.AutoSize = True
        Me.FS1.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.FS1.ForeColor = System.Drawing.Color.LimeGreen
        Me.FS1.Location = New System.Drawing.Point(11, 107)
        Me.FS1.Name = "FS1"
        Me.FS1.Size = New System.Drawing.Size(25, 16)
        Me.FS1.TabIndex = 3
        Me.FS1.Text = "木"
        '
        'TG1
        '
        Me.TG1.AutoSize = True
        Me.TG1.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.TG1.ForeColor = System.Drawing.Color.LimeGreen
        Me.TG1.Location = New System.Drawing.Point(42, 107)
        Me.TG1.Name = "TG1"
        Me.TG1.Size = New System.Drawing.Size(42, 16)
        Me.TG1.TabIndex = 4
        Me.TG1.Text = "財星"
        '
        'NL1
        '
        Me.NL1.AutoSize = True
        Me.NL1.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.NL1.ForeColor = System.Drawing.Color.LimeGreen
        Me.NL1.Location = New System.Drawing.Point(311, 107)
        Me.NL1.Name = "NL1"
        Me.NL1.Size = New System.Drawing.Size(26, 16)
        Me.NL1.TabIndex = 6
        Me.NL1.Text = "60"
        '
        'FS2
        '
        Me.FS2.AutoSize = True
        Me.FS2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.FS2.ForeColor = System.Drawing.Color.Red
        Me.FS2.Location = New System.Drawing.Point(11, 152)
        Me.FS2.Name = "FS2"
        Me.FS2.Size = New System.Drawing.Size(25, 16)
        Me.FS2.TabIndex = 7
        Me.FS2.Text = "火"
        '
        'TG2
        '
        Me.TG2.AutoSize = True
        Me.TG2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.TG2.ForeColor = System.Drawing.Color.Red
        Me.TG2.Location = New System.Drawing.Point(42, 152)
        Me.TG2.Name = "TG2"
        Me.TG2.Size = New System.Drawing.Size(42, 16)
        Me.TG2.TabIndex = 8
        Me.TG2.Text = "財星"
        '
        'ProgressBar2
        '
        Me.ProgressBar2.BackColor = System.Drawing.Color.White
        Me.ProgressBar2.ForeColor = System.Drawing.Color.Red
        Me.ProgressBar2.Location = New System.Drawing.Point(90, 150)
        Me.ProgressBar2.Maximum = 60
        Me.ProgressBar2.Name = "ProgressBar2"
        Me.ProgressBar2.Size = New System.Drawing.Size(215, 22)
        Me.ProgressBar2.TabIndex = 9
        '
        'NL2
        '
        Me.NL2.AutoSize = True
        Me.NL2.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.NL2.ForeColor = System.Drawing.Color.Red
        Me.NL2.Location = New System.Drawing.Point(311, 152)
        Me.NL2.Name = "NL2"
        Me.NL2.Size = New System.Drawing.Size(26, 16)
        Me.NL2.TabIndex = 10
        Me.NL2.Text = "60"
        '
        'FS3
        '
        Me.FS3.AutoSize = True
        Me.FS3.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.FS3.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.FS3.Location = New System.Drawing.Point(11, 197)
        Me.FS3.Name = "FS3"
        Me.FS3.Size = New System.Drawing.Size(25, 16)
        Me.FS3.TabIndex = 11
        Me.FS3.Text = "土"
        '
        'TG3
        '
        Me.TG3.AutoSize = True
        Me.TG3.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.TG3.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.TG3.Location = New System.Drawing.Point(42, 197)
        Me.TG3.Name = "TG3"
        Me.TG3.Size = New System.Drawing.Size(42, 16)
        Me.TG3.TabIndex = 12
        Me.TG3.Text = "財星"
        '
        'ProgressBar3
        '
        Me.ProgressBar3.BackColor = System.Drawing.Color.White
        Me.ProgressBar3.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.ProgressBar3.Location = New System.Drawing.Point(90, 195)
        Me.ProgressBar3.Maximum = 60
        Me.ProgressBar3.Name = "ProgressBar3"
        Me.ProgressBar3.Size = New System.Drawing.Size(215, 22)
        Me.ProgressBar3.TabIndex = 13
        '
        'NL3
        '
        Me.NL3.AutoSize = True
        Me.NL3.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.NL3.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.NL3.Location = New System.Drawing.Point(311, 197)
        Me.NL3.Name = "NL3"
        Me.NL3.Size = New System.Drawing.Size(26, 16)
        Me.NL3.TabIndex = 14
        Me.NL3.Text = "60"
        '
        'FS4
        '
        Me.FS4.AutoSize = True
        Me.FS4.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.FS4.ForeColor = System.Drawing.Color.Orange
        Me.FS4.Location = New System.Drawing.Point(11, 242)
        Me.FS4.Name = "FS4"
        Me.FS4.Size = New System.Drawing.Size(25, 16)
        Me.FS4.TabIndex = 15
        Me.FS4.Text = "金"
        '
        'TG4
        '
        Me.TG4.AutoSize = True
        Me.TG4.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.TG4.ForeColor = System.Drawing.Color.Orange
        Me.TG4.Location = New System.Drawing.Point(42, 242)
        Me.TG4.Name = "TG4"
        Me.TG4.Size = New System.Drawing.Size(42, 16)
        Me.TG4.TabIndex = 16
        Me.TG4.Text = "財星"
        '
        'ProgressBar4
        '
        Me.ProgressBar4.BackColor = System.Drawing.Color.White
        Me.ProgressBar4.ForeColor = System.Drawing.Color.Orange
        Me.ProgressBar4.Location = New System.Drawing.Point(90, 240)
        Me.ProgressBar4.Maximum = 60
        Me.ProgressBar4.Name = "ProgressBar4"
        Me.ProgressBar4.Size = New System.Drawing.Size(215, 22)
        Me.ProgressBar4.TabIndex = 17
        '
        'NL4
        '
        Me.NL4.AutoSize = True
        Me.NL4.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.NL4.ForeColor = System.Drawing.Color.Orange
        Me.NL4.Location = New System.Drawing.Point(311, 242)
        Me.NL4.Name = "NL4"
        Me.NL4.Size = New System.Drawing.Size(26, 16)
        Me.NL4.TabIndex = 18
        Me.NL4.Text = "60"
        '
        'ProgressBar5
        '
        Me.ProgressBar5.BackColor = System.Drawing.Color.White
        Me.ProgressBar5.ForeColor = System.Drawing.Color.Blue
        Me.ProgressBar5.Location = New System.Drawing.Point(90, 285)
        Me.ProgressBar5.Maximum = 60
        Me.ProgressBar5.Name = "ProgressBar5"
        Me.ProgressBar5.Size = New System.Drawing.Size(215, 22)
        Me.ProgressBar5.TabIndex = 19
        '
        'NL5
        '
        Me.NL5.AutoSize = True
        Me.NL5.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.NL5.ForeColor = System.Drawing.Color.Blue
        Me.NL5.Location = New System.Drawing.Point(311, 287)
        Me.NL5.Name = "NL5"
        Me.NL5.Size = New System.Drawing.Size(26, 16)
        Me.NL5.TabIndex = 20
        Me.NL5.Text = "60"
        '
        'FS5
        '
        Me.FS5.AutoSize = True
        Me.FS5.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.FS5.ForeColor = System.Drawing.Color.Blue
        Me.FS5.Location = New System.Drawing.Point(11, 287)
        Me.FS5.Name = "FS5"
        Me.FS5.Size = New System.Drawing.Size(25, 16)
        Me.FS5.TabIndex = 21
        Me.FS5.Text = "水"
        '
        'TG5
        '
        Me.TG5.AutoSize = True
        Me.TG5.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.TG5.ForeColor = System.Drawing.Color.Blue
        Me.TG5.Location = New System.Drawing.Point(42, 287)
        Me.TG5.Name = "TG5"
        Me.TG5.Size = New System.Drawing.Size(42, 16)
        Me.TG5.TabIndex = 22
        Me.TG5.Text = "財星"
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(351, 333)
        Me.Controls.Add(Me.TG5)
        Me.Controls.Add(Me.FS5)
        Me.Controls.Add(Me.NL5)
        Me.Controls.Add(Me.ProgressBar5)
        Me.Controls.Add(Me.NL4)
        Me.Controls.Add(Me.ProgressBar4)
        Me.Controls.Add(Me.TG4)
        Me.Controls.Add(Me.FS4)
        Me.Controls.Add(Me.NL3)
        Me.Controls.Add(Me.ProgressBar3)
        Me.Controls.Add(Me.TG3)
        Me.Controls.Add(Me.FS3)
        Me.Controls.Add(Me.NL2)
        Me.Controls.Add(Me.ProgressBar2)
        Me.Controls.Add(Me.TG2)
        Me.Controls.Add(Me.FS2)
        Me.Controls.Add(Me.NL1)
        Me.Controls.Add(Me.TG1)
        Me.Controls.Add(Me.FS1)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form3"
        Me.Text = "五行旺衰"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents FS1 As System.Windows.Forms.Label
    Friend WithEvents TG1 As System.Windows.Forms.Label
    Friend WithEvents NL1 As System.Windows.Forms.Label
    Friend WithEvents FS2 As System.Windows.Forms.Label
    Friend WithEvents TG2 As System.Windows.Forms.Label
    Friend WithEvents ProgressBar2 As System.Windows.Forms.ProgressBar
    Friend WithEvents NL2 As System.Windows.Forms.Label
    Friend WithEvents FS3 As System.Windows.Forms.Label
    Friend WithEvents TG3 As System.Windows.Forms.Label
    Friend WithEvents ProgressBar3 As System.Windows.Forms.ProgressBar
    Friend WithEvents NL3 As System.Windows.Forms.Label
    Friend WithEvents FS4 As System.Windows.Forms.Label
    Friend WithEvents TG4 As System.Windows.Forms.Label
    Friend WithEvents ProgressBar4 As System.Windows.Forms.ProgressBar
    Friend WithEvents NL4 As System.Windows.Forms.Label
    Friend WithEvents ProgressBar5 As System.Windows.Forms.ProgressBar
    Friend WithEvents NL5 As System.Windows.Forms.Label
    Friend WithEvents FS5 As System.Windows.Forms.Label
    Friend WithEvents TG5 As System.Windows.Forms.Label
End Class
