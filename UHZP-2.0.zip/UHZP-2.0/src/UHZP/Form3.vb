﻿Public Class Form3
    'Inherits System.Windows.Forms.Form
    '進度條顏色
    'Private Declare Function SendMessageLong Lib "user32" Alias "SendMessageA" (ByVal hWnd As Integer, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Integer
    'Private Const PBM_SETBARCOLOR As Integer = &H409S

    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '進度條顏色設定
        'Call SendMessageLong(ProgressBar1.Handle, PBM_SETBARCOLOR, 0, 49152) '綠色
        'Call SendMessageLong(ProgressBar2.Handle, PBM_SETBARCOLOR, 0, 255) '紅色
        'Call SendMessageLong(ProgressBar3.Handle, PBM_SETBARCOLOR, 0, 16512) '茶色
        'Call SendMessageLong(ProgressBar4.Handle, PBM_SETBARCOLOR, 0, 33023) '橙黃色
        'Call SendMessageLong(ProgressBar5.Handle, PBM_SETBARCOLOR, 0, 16711680) '藍色

        Wood = 0
        Fire = 0
        Earth = 0
        Metal = 0
        Water = 0

        '十神五行標籤
        FETG()

        '計算五行
        MUL = 1
        CLCFE()

        '填入分數
        NL1.Text = Wood '木
        NL2.Text = Fire '火
        NL3.Text = Earth '土
        NL4.Text = Metal '金
        NL5.Text = Water '水

        ProgressBar1.Value = Wood '木
        ProgressBar2.Value = Fire '火
        ProgressBar3.Value = Earth '土
        ProgressBar4.Value = Metal '金
        ProgressBar5.Value = Water '水

        NL1.Text = Wood
    End Sub
    '=================================================================================
    '=== 十神五行標籤
    '=================================================================================
    Sub FETG()
        Dim z As Integer

        '取日主五行
        z = (BirthData(3, 3) + 1) \ 2

        Select Case z

            Case 1 '木日主
                TG1.Text = "比劫"
                TG2.Text = "食傷"
                TG3.Text = "財星"
                TG4.Text = "官殺"
                TG5.Text = "印星"
            Case 2 '火日主
                TG1.Text = "印星"
                TG2.Text = "比劫"
                TG3.Text = "食傷"
                TG4.Text = "財星"
                TG5.Text = "官殺"
            Case 3 '土日主
                TG1.Text = "官殺"
                TG2.Text = "印星"
                TG3.Text = "比劫"
                TG4.Text = "食傷"
                TG5.Text = "財星"
            Case 4 '金日主
                TG1.Text = "財星"
                TG2.Text = "官殺"
                TG3.Text = "印星"
                TG4.Text = "比劫"
                TG5.Text = "食傷"
            Case 5 '水日主
                TG1.Text = "食傷"
                TG2.Text = "財星"
                TG3.Text = "官殺"
                TG4.Text = "印星"
                TG5.Text = "比劫"
        End Select

    End Sub

    '=================================================================================
    '=== 計算五行
    '=================================================================================
    Sub CLCFE()

        '計算年干
        TKX = BirthData(1, 3)
        CLCTK()

        '計算月干
        TKX = BirthData(2, 3)
        CLCTK()

        '計算日干
        TKX = BirthData(3, 3)
        CLCTK()

        '計算時干
        TKX = BirthData(4, 3)
        CLCTK()

        '計算年支
        DJX = BirthData(1, 4)
        CLCDJ()

        '計算月支
        MUL = 2
        DJX = BirthData(2, 4)
        CLCDJ()
        MUL = 1

        '計算日支
        DJX = BirthData(3, 4)
        CLCDJ()

        '計算時支
        DJX = BirthData(4, 4)
        CLCDJ()

    End Sub

End Class