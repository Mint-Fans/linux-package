Public Class Form4


    Private Sub Form4_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i, j, s, n, BYEAR, CTK, CDJ As Integer
        Dim lioyear, liotk, liodj As Label
        Dim LIO_FONT As String
        Dim MASK As Boolean
        Dim OSTEP As Boolean
        Dim TSTEP As Boolean

        LIO_FONT = "�L�n������"

        BYEAR = BirthData(1, 2) '�����ͦ~

        '�ͦ~�����z��
        CTK = BirthData(6, 1)
        CDJ = BirthData(6, 2)

        If (ages < 60) Then
            OSTEP = True
            TSTEP = False
        Else
            OSTEP = False
            TSTEP = True
        End If

        s = 0 '�p��g���~��

        For j = 1 To 10

            For i = 1 To 10
                '�~������
                n = BYEAR + s

                '�p��Ѥz�a��
                If s > 0 Then
                    CTK = CTK + 1
                    If CTK > 10 Then CTK = CTK - 10
                    CDJ = CDJ + 1
                    If CDJ > 12 Then CDJ = CDJ - 12
                End If

                '�B�n�}��
                MASK = False

                If (s < 60) Then
                    If CTK = GanZhi(1, 1) And CDJ = GanZhi(1, 2) Then
                        If OSTEP = True Then
                            MASK = True
                        End If
                    End If
                Else
                    If CTK = GanZhi(1, 1) And CDJ = GanZhi(1, 2) Then
                        If TSTEP = True Then
                            MASK = True
                        End If
                    End If
                End If

                lioyear = New Label
                lioyear.Name = "LIO_YEAR"
                lioyear.AutoSize = False
                lioyear.Width = 43
                lioyear.Height = 18
                lioyear.TextAlign = ContentAlignment.MiddleCenter
                lioyear.Font = New Font(LIO_FONT, 9, FontStyle.Bold)
                lioyear.Text = n '����
                If MASK = True Then
                    lioyear.BackColor = Color.FromName("Yellow")
                Else
                    lioyear.BackColor = Color.FromName("Gainsboro")
                End If
                lioyear.ForeColor = Color.FromName("Gray")
                lioyear.Location = New Point(24 + ((i - 1) * 47), 24 + ((j - 1) * 50)) '(X���k,Y�W�U)
                Me.Controls.Add(lioyear)

                '�z���C��
                BTK = CTK
                BDJ = CDJ
                KJTGC()

                '�y�~�Ѥz
                liotk = New Label
                liotk.Name = "LIO_TK"
                liotk.Text = ProperN(1, CTK)
                liotk.AutoSize = False
                liotk.Width = 22
                liotk.Height = 20
                liotk.TextAlign = ContentAlignment.MiddleLeft
                liotk.Font = New Font(LIO_FONT, 12, FontStyle.Bold)
                If MASK = True Then
                    liotk.BackColor = Color.FromName("Yellow")
                Else
                    liotk.BackColor = Color.FromName("WhiteSmoke")
                End If

                liotk.ForeColor = Color.FromName(tk_color)
                liotk.Location = New Point(24 + ((i - 1) * 47), 45 + ((j - 1) * 50)) '(X���k,Y�W�U)
                Me.Controls.Add(liotk)

                '�y�~�a��
                liodj = New Label
                liodj.Name = "LIO_DJ"
                liodj.Text = ProperN(2, CDJ)
                liodj.AutoSize = False
                liodj.Width = 21
                liodj.Height = 20
                liodj.TextAlign = ContentAlignment.MiddleRight
                liodj.Font = New Font(LIO_FONT, 12, FontStyle.Bold)
                If MASK = True Then
                    liodj.BackColor = Color.FromName("Yellow")
                Else
                    liodj.BackColor = Color.FromName("WhiteSmoke")
                End If
                liodj.ForeColor = Color.FromName(dk1_color)
                liodj.Location = New Point(46 + ((i - 1) * 47), 45 + ((j - 1) * 50)) '(X���k,Y�W�U)
                Me.Controls.Add(liodj)

                s = s + 1 '�p�ⷳ��

            Next
        Next

    End Sub

End Class