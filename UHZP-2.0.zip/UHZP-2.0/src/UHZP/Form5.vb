Public Class Form5
    '�ŧi���N����
    Private ssone(), sstwo(), ssthree(), longevity(), vacuum() As Label

    Dim LongLife(12), TaiSui(12) As String

    '=================================================================================
    '=== �����_�l
    '=================================================================================
    Private Sub Form5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        '���Ұ}�C�]�m
        ShenshaLabelInit()

        '�ɤJ�r��
        ReadShenshaString()

        '�]�m����
        ShenshaConfig()

    End Sub
    '=================================================================================
    '=== ���Ұ}�C�]�m
    '=================================================================================
    Sub ShenshaLabelInit()
        '���ҳ]�m
        '����1 (��t) ssone(0) - ssone(11)
        ssone = New Label() {SSO0, SSO1, SSO2, SSO3, SSO4, SSO5, SSO6, SSO7, SSO8, SSO9, SSO10, SSO11}
        '����2 (�~�t) sstwo(0) - sstwo(11)
        sstwo = New Label() {SST0, SST1, SST2, SST3, SST4, SST5, SST6, SST7, SST8, SST9, SST10, SST11}
        '����3 (���e�ѬP ����b) ssthree(0) - ssthree(11)
        ssthree = New Label() {SSS0, SSS1, SSS2, SSS3, SSS4, SSS5, SSS6, SSS7, SSS8, SSS9, SSS10, SSS11}
        '����12�B longevity(0) - longevity(11)
        longevity = New Label() {NB0, NB1, NB2, NB3, NB4, NB5, NB6, NB7, NB8, NB9, NB10, NB11}
        '���ҪŤ` vacuum(0) - vacuum(11)
        vacuum = New Label() {VAC0, VAC1, VAC2, VAC3, VAC4, VAC5, VAC6, VAC7, VAC8, VAC9, VAC10, VAC11}

    End Sub
    '=================================================================================
    '=== �ɤJ�r��
    '=================================================================================
    Sub ReadShenshaString()
        '�ɤJ�r��
        LongLife(1) = "����"
        LongLife(2) = "�N�D"
        LongLife(3) = "�a�a"
        LongLife(4) = "�{�x"
        LongLife(5) = "�ҩ�"
        LongLife(6) = "�I"
        LongLife(7) = "�f"
        LongLife(8) = "��"
        LongLife(9) = "��"
        LongLife(10) = "��"
        LongLife(11) = "�L"
        LongLife(12) = "�i"

        TaiSui(1) = "�ӷ�"
        TaiSui(2) = "�Ӷ�"
        TaiSui(3) = "���"
        TaiSui(4) = "�ӳ�"
        TaiSui(5) = "�x��"
        TaiSui(6) = "����"
        TaiSui(7) = "���}"
        TaiSui(8) = "�s�w"
        TaiSui(9) = "�ժ�"
        TaiSui(10) = "�Ѽw"
        TaiSui(11) = "�ݫ�"
        TaiSui(12) = "�f��"

    End Sub
    '=================================================================================
    '=== ���ٳ]�m
    '=================================================================================
    Sub ShenshaConfig()
        Dim i, n, zkn, NB, ko1, ko2, TAIS, ss As Integer
        Dim st, tendo, uedo As String

        '���ͤQ�G�B
        st = "12070310031006010904"
        NB = Val(Mid(st, (BirthData(3, 3) - 1) * 2 + 1, 2)) '���ͦ�
        zkn = BirthData(3, 3) Mod 2 '��z����

        For i = 1 To 12
            If zkn = 1 Then
                '���z����
                n = NB + i - 1
                If n > 12 Then n = n - 12
                longevity(n - 1).Text = LongLife(i)
            Else
                '���z�f��
                n = NB - i + 1
                If n < 1 Then n = n + 12
                longevity(n - 1).Text = LongLife(i)
            End If

        Next


        '== ���ҪŤ`
        '��W�Ť`
        n = BirthData(3, 4) - (BirthData(3, 3) - 1)
        If n < 1 Then n = n + 12

        If n = 1 Then ko1 = 11 : ko2 = 12 '�Ҥl��
        If n = 11 Then ko1 = 9 : ko2 = 10 '�Ҧ���
        If n = 9 Then ko1 = 7 : ko2 = 8 '�ҥӦ�
        If n = 7 Then ko1 = 5 : ko2 = 6 '�ҤȦ�
        If n = 5 Then ko1 = 3 : ko2 = 4 '�Ҩ���
        If n = 3 Then ko1 = 1 : ko2 = 2 '�ұG��

        vacuum(ko1 - 1).Text = vacuum(ko1 - 1).Text + "��W�Ť`" + " "
        vacuum(ko2 - 1).Text = vacuum(ko2 - 1).Text + "��W�Ť`" + " "

        '�~�W�Ť`
        n = BirthData(1, 4) - (BirthData(1, 3) - 1)
        If n < 1 Then n = n + 12

        If n = 1 Then ko1 = 11 : ko2 = 12 '�Ҥl��
        If n = 11 Then ko1 = 9 : ko2 = 10 '�Ҧ���
        If n = 9 Then ko1 = 7 : ko2 = 8 '�ҥӦ�
        If n = 7 Then ko1 = 5 : ko2 = 6 '�ҤȦ�
        If n = 5 Then ko1 = 3 : ko2 = 4 '�Ҩ���
        If n = 3 Then ko1 = 1 : ko2 = 2 '�ұG��

        vacuum(ko1 - 1).Text = vacuum(ko1 - 1).Text + "�~�W�Ť`" + " "
        vacuum(ko2 - 1).Text = vacuum(ko2 - 1).Text + "�~�W�Ť`" + " "
        '==== ��z����
        '��S
        st = "03040607060709101201"
        ss = Val(Mid(st, (BirthData(3, 3) - 1) * 2 + 1, 2))
        ssone(ss - 1).Text = ssone(ss - 1).Text + "��S" + " "

        '���b
        ss = ss + 1
        If ss > 12 Then ss = ss - 12
        n = BirthData(3, 3) Mod 2
        If n = 1 Then
            ssone(ss - 1).Text = ssone(ss - 1).Text + "���b" + " "
        End If

        '���b
        ss = ss + 6
        If ss > 12 Then ss = ss - 12
        n = BirthData(3, 3) Mod 2
        If n = 1 Then
            ssone(ss - 1).Text = ssone(ss - 1).Text + "���b" + " "
        End If

        '����
        st = "05060809080911120203"
        ss = Val(Mid(st, (BirthData(3, 3) - 1) * 2 + 1, 2))
        ssone(ss - 1).Text = ssone(ss - 1).Text + "����" + " "


        '�ѤA�Q�H
        st = "02011212020102070404"
        ss = Val(Mid(st, (BirthData(3, 3) - 1) * 2 + 1, 2))
        ssone(ss - 1).Text = ssone(ss - 1).Text + "�ѤA" + " "
        st = "08091010080908030606"
        ss = Val(Mid(st, (BirthData(3, 3) - 1) * 2 + 1, 2))
        ssone(ss - 1).Text = ssone(ss - 1).Text + "�ѤA" + " "

        '���
        n = BirthData(3, 3)
        Select Case n
            Case 1 '��
                ss = 6
            Case 2 '�A
                ss = 7
            Case 3 '��
                ss = 9
            Case 4 '�B
                ss = 10
            Case 5 '��
                ss = 9
            Case 6 '�v
                ss = 10
            Case 7 '��
                ss = 12
            Case 8 '��
                ss = 1
            Case 9 '��
                ss = 3
            Case 10 '��
                ss = 4
        End Select

        ssone(ss - 1).Text = ssone(ss - 1).Text + "���" + " "

        '�ǰ�
        n = BirthData(3, 3)
        Select Case n
            Case 1 '��
                ss = 12
            Case 2 '�A
                ss = 7
            Case 3 '��
                ss = 3
            Case 4 '�B
                ss = 10
            Case 5 '��
                ss = 3
            Case 6 '�v
                ss = 10
            Case 7 '��
                ss = 6
            Case 8 '��
                ss = 1
            Case 9 '��
                ss = 9
            Case 10 '��
                ss = 4
        End Select

        ssone(ss - 1).Text = ssone(ss - 1).Text + "�ǰ�" + " "

        '�ӷ��Q�H
        n = BirthData(3, 3)
        Select Case n
            Case 1 '��
                ssone(0).Text = ssone(0).Text + "�ӷ�" + " "
                ssone(6).Text = ssone(6).Text + "�ӷ�" + " "
            Case 2 '�A
                ssone(0).Text = ssone(0).Text + "�ӷ�" + " "
                ssone(6).Text = ssone(6).Text + "�ӷ�" + " "
            Case 3 '��
                ssone(3).Text = ssone(3).Text + "�ӷ�" + " "
                ssone(9).Text = ssone(9).Text + "�ӷ�" + " "
            Case 4 '�B
                ssone(3).Text = ssone(3).Text + "�ӷ�" + " "
                ssone(9).Text = ssone(9).Text + "�ӷ�" + " "
            Case 5 '��
                ssone(1).Text = ssone(1).Text + "�ӷ�" + " "
                ssone(4).Text = ssone(4).Text + "�ӷ�" + " "
                ssone(7).Text = ssone(7).Text + "�ӷ�" + " "
                ssone(10).Text = ssone(10).Text + "�ӷ�" + " "
            Case 6 '�v
                ssone(1).Text = ssone(1).Text + "�ӷ�" + " "
                ssone(4).Text = ssone(4).Text + "�ӷ�" + " "
                ssone(7).Text = ssone(7).Text + "�ӷ�" + " "
                ssone(10).Text = ssone(10).Text + "�ӷ�" + " "
            Case 7 '��
                ssone(2).Text = ssone(2).Text + "�ӷ�" + " "
                ssone(11).Text = ssone(11).Text + "�ӷ�" + " "
            Case 8 '��
                ssone(2).Text = ssone(2).Text + "�ӷ�" + " "
                ssone(11).Text = ssone(11).Text + "�ӷ�" + " "
            Case 9 '��
                ssone(5).Text = ssone(5).Text + "�ӷ�" + " "
                ssone(8).Text = ssone(8).Text + "�ӷ�" + " "
            Case 10 '��
                ssone(5).Text = ssone(5).Text + "�ӷ�" + " "
                ssone(8).Text = ssone(8).Text + "�ӷ�" + " "

        End Select

        '�Ѽp�Q�H
        n = BirthData(3, 3)
        Select Case n
            Case 1 '��
                ss = 6
            Case 2 '�A
                ss = 7
            Case 3 '��
                ss = 6
            Case 4 '�B
                ss = 7
            Case 5 '��
                ss = 9
            Case 6 '�v
                ss = 10
            Case 7 '��
                ss = 12
            Case 8 '��
                ss = 1
            Case 9 '��
                ss = 3
            Case 10 '��
                ss = 4
        End Select

        ssone(ss - 1).Text = ssone(ss - 1).Text + "�Ѽp" + " "

        '�֬P�Q�H
        n = BirthData(3, 3)
        Select Case n
            Case 1 '��
                ssone(0).Text = ssone(0).Text + "�֬P" + " "
                ssone(2).Text = ssone(2).Text + "�֬P" + " "
            Case 2 '�A
                ssone(1).Text = ssone(1).Text + "�֬P" + " "
                ssone(3).Text = ssone(3).Text + "�֬P" + " "
            Case 3 '��
                ssone(0).Text = ssone(0).Text + "�֬P" + " "
                ssone(2).Text = ssone(2).Text + "�֬P" + " "
            Case 4 '�B
                ssone(11).Text = ssone(11).Text + "�֬P" + " "
            Case 5 '��
                ssone(8).Text = ssone(8).Text + "�֬P" + " "
            Case 6 '�v
                ssone(7).Text = ssone(7).Text + "�֬P" + " "
            Case 7 '��
                ssone(6).Text = ssone(6).Text + "�֬P" + " "
            Case 8 '��
                ssone(5).Text = ssone(5).Text + "�֬P" + " "
            Case 9 '��
                ssone(4).Text = ssone(4).Text + "�֬P" + " "
            Case 10 '��
                ssone(1).Text = ssone(1).Text + "�֬P" + " "
                ssone(3).Text = ssone(3).Text + "�֬P" + " "
        End Select

        '�ѩx�Q�H
        n = BirthData(3, 3)
        Select Case n
            Case 1 '��
                ss = 8
            Case 2 '�A
                ss = 5
            Case 3 '��
                ss = 6
            Case 4 '�B
                ss = 10
            Case 5 '��
                ss = 11
            Case 6 '�v
                ss = 4
            Case 7 '��
                ss = 2
            Case 8 '��
                ss = 9
            Case 9 '��
                ss = 3
            Case 10 '��
                ss = 7
        End Select

        ssone(ss - 1).Text = ssone(ss - 1).Text + "�ѩx" + " "

        '���v
        n = BirthData(3, 3)
        Select Case n
            Case 1 '��
                ss = 7
            Case 2 '�A
                ss = 9
            Case 3 '��
                ss = 3
            Case 4 '�B
                ss = 8
            Case 5 '��
                ss = 5
            Case 6 '�v
                ss = 5
            Case 7 '��
                ss = 11
            Case 8 '��
                ss = 10
            Case 9 '��
                ss = 1
            Case 10 '��
                ss = 9
        End Select

        ssone(ss - 1).Text = ssone(ss - 1).Text + "���v" + " "

        '�y��
        n = BirthData(3, 3)
        Select Case n
            Case 1 '��
                ss = 10
            Case 2 '�A
                ss = 11
            Case 3 '��
                ss = 8
            Case 4 '�B
                ss = 9
            Case 5 '��
                ss = 6
            Case 6 '�v
                ss = 7
            Case 7 '��
                ss = 5
            Case 8 '��
                ss = 4
            Case 9 '��
                ss = 3
            Case 10 '��
                ss = 12
        End Select

        ssone(ss - 1).Text = ssone(ss - 1).Text + "�y��" + " "


        '==== ��䯫��
        '�氨
        n = BirthData(3, 4) Mod 4 ' ���
        Select Case n
            Case 0 '��f��
                ss = 6
            Case 1 '�Ӥl��
                ss = 3
            Case 2 '�x����
                ss = 12
            Case 3 '�G�Ȧ�
                ss = 9
        End Select

        ssone(ss - 1).Text = ssone(ss - 1).Text + "�氨" + " "

        '�N�P
        n = BirthData(3, 4) Mod 4 ' ���
        Select Case n
            Case 0 '��f��
                ss = 4
            Case 1 '�Ӥl��
                ss = 1
            Case 2 '�x����
                ss = 10
            Case 3 '�G�Ȧ�
                ss = 7
        End Select

        ssone(ss - 1).Text = ssone(ss - 1).Text + "�N�P" + " "

        '�ػ\
        n = BirthData(3, 4) Mod 4 ' ���
        Select Case n
            Case 0 '��f��
                ss = 8
            Case 1 '�Ӥl��
                ss = 5
            Case 2 '�x����
                ss = 2
            Case 3 '�G�Ȧ�
                ss = 11
        End Select

        ssone(ss - 1).Text = ssone(ss - 1).Text + "�ػ\" + " "

        '�w��
        n = BirthData(3, 4) Mod 4 ' ���
        Select Case n
            Case 0 '��f��
                ss = 1
            Case 1 '�Ӥl��
                ss = 10
            Case 2 '�x����
                ss = 7
            Case 3 '�G�Ȧ�
                ss = 4
        End Select

        ssone(ss - 1).Text = ssone(ss - 1).Text + "�w��" + " "

        '�T��
        n = BirthData(3, 4) Mod 4 ' ���
        Select Case n
            Case 0 '��f��
                ss = 9
            Case 1 '�Ӥl��
                ss = 6
            Case 2 '�x����
                ss = 3
            Case 3 '�G�Ȧ�
                ss = 12
        End Select

        ssone(ss - 1).Text = ssone(ss - 1).Text + "�T��" + " "

        '�`��
        n = BirthData(3, 4) Mod 4 ' ���
        Select Case n
            Case 0 '��f��
                ss = 3
            Case 1 '�Ӥl��
                ss = 12
            Case 2 '�x����
                ss = 9
            Case 3 '�G�Ȧ�
                ss = 6
        End Select

        ssone(ss - 1).Text = ssone(ss - 1).Text + "�`��" + " "

        '==== �~�䯫��
        '�氨
        n = BirthData(1, 4) Mod 4 ' �~��
        Select Case n
            Case 0 '��f��
                ss = 6
            Case 1 '�Ӥl��
                ss = 3
            Case 2 '�x����
                ss = 12
            Case 3 '�G�Ȧ�
                ss = 9
        End Select

        sstwo(ss - 1).Text = sstwo(ss - 1).Text + "�氨" + " "

        '�~��N�P ����
        n = BirthData(1, 4) Mod 4 ' �~��
        Select Case n
            Case 0 '��f��
                ss = 4
            Case 1 '�Ӥl��
                ss = 1
            Case 2 '�x����
                ss = 10
            Case 3 '�G�Ȧ�
                ss = 7
        End Select

        sstwo(ss - 1).Text = sstwo(ss - 1).Text + "����" + " "


        '�ػ\
        n = BirthData(1, 4) Mod 4 ' �~��
        Select Case n
            Case 0 '��f��
                ss = 8
            Case 1 '�Ӥl��
                ss = 5
            Case 2 '�x����
                ss = 2
            Case 3 '�G�Ȧ�
                ss = 11
        End Select

        sstwo(ss - 1).Text = sstwo(ss - 1).Text + "�ػ\" + " "

        '�w��
        n = BirthData(1, 4) Mod 4 ' �~��
        Select Case n
            Case 0 '��f��
                ss = 1
            Case 1 '�Ӥl��
                ss = 10
            Case 2 '�x����
                ss = 7
            Case 3 '�G�Ȧ�
                ss = 4
        End Select

        sstwo(ss - 1).Text = sstwo(ss - 1).Text + "�w��" + " "

        '�T��
        n = BirthData(1, 4) Mod 4 ' �~��
        Select Case n
            Case 0 '��f��
                ss = 9
            Case 1 '�Ӥl��
                ss = 6
            Case 2 '�x����
                ss = 3
            Case 3 '�G�Ȧ�
                ss = 12
        End Select

        sstwo(ss - 1).Text = sstwo(ss - 1).Text + "�T��" + " "

        '�`��
        n = BirthData(1, 4) Mod 4 ' �~��
        Select Case n
            Case 0 '��f��
                ss = 3
            Case 1 '�Ӥl��
                ss = 12
            Case 2 '�x����
                ss = 9
            Case 3 '�G�Ȧ�
                ss = 6
        End Select

        sstwo(ss - 1).Text = sstwo(ss - 1).Text + "�`��" + " "

        '�a��
        n = BirthData(1, 4) Mod 4 ' �~��
        Select Case n
            Case 0 '��f��
                ss = 10
            Case 1 '�Ӥl��
                ss = 7
            Case 2 '�x����
                ss = 4
            Case 3 '�G�Ȧ�
                ss = 1
        End Select

        sstwo(ss - 1).Text = sstwo(ss - 1).Text + "�a��" + " "

        '����
        n = BirthData(1, 4) Mod 4 ' �~��
        Select Case n
            Case 0 '��f��
                ss = 7
            Case 1 '�Ӥl��
                ss = 4
            Case 2 '�x����
                ss = 1
            Case 3 '�G�Ȧ�
                ss = 10
        End Select

        sstwo(ss - 1).Text = sstwo(ss - 1).Text + "����" + " "

        '�t��
        n = BirthData(1, 4) ' �~��
        If n = 12 Then n = 0
        n = n \ 3
        Select Case n
            Case 0 '��l��
                ss = 3
            Case 1 '�G�f��
                ss = 6
            Case 2 '�x�ȥ�
                ss = 9
            Case 3 '�Ө���
                ss = 12
        End Select

        sstwo(ss - 1).Text = sstwo(ss - 1).Text + "�t��" + " "

        '��J
        n = BirthData(1, 4) ' �~��
        If n = 12 Then n = 0
        n = n \ 3
        Select Case n
            Case 0 '��l��
                ss = 11
            Case 1 '�G�f��
                ss = 2
            Case 2 '�x�ȥ�
                ss = 5
            Case 3 '�Ө���
                ss = 8
        End Select

        sstwo(ss - 1).Text = sstwo(ss - 1).Text + "��J" + " "

        '���q�ѳ�
        n = BirthData(1, 4) ' �~��
        ss = 5 - n
        If ss < 1 Then ss = ss + 12
        sstwo(ss - 1).Text = sstwo(ss - 1).Text + "���q" + " "

        n = BirthData(1, 4) ' �~��
        ss = 11 - n
        If ss < 1 Then ss = ss + 12
        sstwo(ss - 1).Text = sstwo(ss - 1).Text + "�ѳ�" + " "

        '��b
        n = BirthData(1, 4) ' �~��
        ss = 12 - n
        If ss < 1 Then ss = ss + 12
        sstwo(ss - 1).Text = sstwo(ss - 1).Text + "��b" + " "

        '����
        n = BirthData(1, 4) ' �~��
        If BirthData(5, 1) = BirthData(5, 2) Then
            '���k���k
            ss = n + 7
            If ss > 12 Then ss = ss - 12
            sstwo(ss - 1).Text = sstwo(ss - 1).Text + "����" + " "
        Else
            '���k���k
            ss = n + 5
            If ss > 12 Then ss = ss - 12
            sstwo(ss - 1).Text = sstwo(ss - 1).Text + "����" + " "
        End If

        '�ĵ�
        n = BirthData(1, 4) ' �~��
        If BirthData(5, 1) = BirthData(5, 2) Then
            '���k���k
            ss = n + 3
            If ss > 12 Then ss = ss - 12
            sstwo(ss - 1).Text = sstwo(ss - 1).Text + "��" + " "
            ss = n + 9
            If ss > 12 Then ss = ss - 12
            sstwo(ss - 1).Text = sstwo(ss - 1).Text + "��" + " "

        Else
            '���k���k
            ss = n + 9
            If ss > 12 Then ss = ss - 12
            sstwo(ss - 1).Text = sstwo(ss - 1).Text + "��" + " "
            ss = n + 3
            If ss > 12 Then ss = ss - 12
            sstwo(ss - 1).Text = sstwo(ss - 1).Text + "��" + " "
        End If


        '==== �ӷ�����
        TAIS = BirthData(1, 4)
        For i = 1 To 12
            n = TAIS + i - 1
            If n > 12 Then n = n - 12
            ssthree(n - 1).Text = TaiSui(i)
        Next

        '==== ��䯫��
        '��b (���)
        n = BirthData(2, 4)
        Select Case n
            Case 1 '��ئa��l
                ss = 7
            Case 2 '��ئa�䤡
                ss = 1
            Case 3 '��ئa��G
                ss = 2
            Case 4 '��ئa��f
                ss = 8
            Case 5 '��ئa�䨰
                ss = 3
            Case 6 '��ئa��x
                ss = 9
            Case 7 '��ئa���
                ss = 4
            Case 8 '��ئa�䥼
                ss = 10
            Case 9 '��ئa���
                ss = 5
            Case 10 '��ئa�䨻
                ss = 11
            Case 11 '��ئa�䦦
                ss = 6
            Case 12 '��ئa���
                ss = 12
        End Select

        ssthree(ss - 1).Text = ssthree(ss - 1).Text + "��b" + " "

        '�Ѽw�Q�H
        tendo = ""
        n = BirthData(2, 4)
        Select Case n
            Case 1 '��ئa��l
                tendo = "�x"
            Case 2 '��ئa�䤡
                tendo = "��"
            Case 3 '��ئa��G
                tendo = "�B"
            Case 4 '��ئa��f
                tendo = "��"
            Case 5 '��ئa�䨰
                tendo = "��"
            Case 6 '��ئa��x
                tendo = "��"
            Case 7 '��ئa���
                tendo = "��"
            Case 8 '��ئa�䥼
                tendo = "��"
            Case 9 '��ئa���
                tendo = "��"
            Case 10 '��ئa�䨻
                tendo = "�G"
            Case 11 '��ئa�䦦
                tendo = "��"
            Case 12 '��ئa���
                tendo = "�A"
        End Select

        '��w�Q�H
        uedo = ""
        n = BirthData(2, 4) Mod 4
        Select Case n
            Case 0 '��f��
                uedo = "��"
            Case 1 '�Ӥl��
                uedo = "��"
            Case 2 '�x����
                uedo = "��"
            Case 3 '�G�Ȧ�
                uedo = "��"
        End Select

        TED.Text = "�Ѽw    " + tendo
        UED.Text = "��w    " + uedo

    End Sub

End Class