Public Class Form5


    Private Sub Form5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i, j, s, n, BYEAR, CTK, CDJ As Integer
        Dim siauyear, siautk, siaudj As Label
        Dim SIAU_FONT As String

        SIAU_FONT = "�L�n������"

        '�p��p�B�_�B�z��
        'If BirthData(7, 1) = BirthData(7, 2) Then
        '���k���k
        'STK = BirthData(4, 3) + 1
        'If STK > 10 Then STK = STK - 10
        'SDJ = BirthData(4, 4) + 1
        'If SDJ > 12 Then SDJ = SDJ - 12
        'Else
        '���k���k
        'STK = BirthData(4, 3) - 1
        'If STK < 1 Then STK = STK + 10
        'SDJ = BirthData(4, 4) - 1
        'If SDJ < 1 Then SDJ = SDJ + 12
        'End If

        BYEAR = BirthData(1, 1)

        CTK = BirthData(4, 3)
        CDJ = BirthData(4, 4)

        s = 0 '�p��g���~��

        For j = 1 To 10

            For i = 1 To 10
                '�~������
                'n �~�� s ���g����
                n = BYEAR + s

                '�p��Ѥz�a��
                If BirthData(7, 1) = BirthData(7, 2) Then
                    '���k���k
                    CTK = CTK + 1
                    If CTK > 10 Then CTK = CTK - 10
                    CDJ = CDJ + 1
                    If CDJ > 12 Then CDJ = CDJ - 12
                Else
                    '���k���k
                    CTK = CTK - 1
                    If CTK < 1 Then CTK = CTK + 10
                    CDJ = CDJ - 1
                    If CDJ < 1 Then CDJ = CDJ + 12

                End If

                siauyear = New Label
                siauyear.Name = "SIAU_YEAR"
                siauyear.AutoSize = False
                siauyear.Width = 43
                siauyear.Height = 18
                siauyear.TextAlign = ContentAlignment.MiddleCenter
                siauyear.Font = New Font(SIAU_FONT, 9, FontStyle.Bold)
                siauyear.Text = n
                If s = ages Then
                    siauyear.BackColor = Color.FromName("Yellow")
                Else
                    siauyear.BackColor = Color.FromName("Gainsboro")
                End If
                siauyear.ForeColor = Color.FromName("Gray")
                siauyear.Location = New Point(24 + ((i - 1) * 47), 24 + ((j - 1) * 50)) '(X���k,Y�W�U)
                Me.Controls.Add(siauyear)

                '�z���C��
                BTK = CTK
                BDJ = CDJ
                KJTGC()

                '�p�B�Ѥz
                siautk = New Label
                siautk.Name = "SIAU_TK"
                siautk.Text = ProperN(1, CTK)
                siautk.AutoSize = False
                siautk.Width = 22
                siautk.Height = 20
                siautk.TextAlign = ContentAlignment.MiddleLeft
                siautk.Font = New Font(SIAU_FONT, 12, FontStyle.Bold)
                If s = ages Then
                    siautk.BackColor = Color.FromName("Yellow")
                Else
                    siautk.BackColor = Color.FromName("WhiteSmoke")
                End If

                siautk.ForeColor = Color.FromName(tk_color)
                siautk.Location = New Point(24 + ((i - 1) * 47), 45 + ((j - 1) * 50)) '(X���k,Y�W�U)
                Me.Controls.Add(siautk)

                '�p�B�a��
                siaudj = New Label
                siaudj.Name = "SIAU_DJ"
                siaudj.Text = ProperN(2, CDJ)
                siaudj.AutoSize = False
                siaudj.Width = 21
                siaudj.Height = 20
                siaudj.TextAlign = ContentAlignment.MiddleRight
                siaudj.Font = New Font(SIAU_FONT, 12, FontStyle.Bold)
                If s = ages Then
                    siaudj.BackColor = Color.FromName("Yellow")
                Else
                    siaudj.BackColor = Color.FromName("WhiteSmoke")
                End If
                siaudj.ForeColor = Color.FromName(dk1_color)
                siaudj.Location = New Point(46 + ((i - 1) * 47), 45 + ((j - 1) * 50)) '(X���k,Y�W�U)
                Me.Controls.Add(siaudj)

                s = s + 1 '�p�ⷳ��

            Next
        Next

    End Sub
End Class