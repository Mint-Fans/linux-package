﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form6
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form6))
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.SSS5 = New System.Windows.Forms.Label
        Me.SST5 = New System.Windows.Forms.Label
        Me.SSO5 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.VAC5 = New System.Windows.Forms.Label
        Me.NB5 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.SSS6 = New System.Windows.Forms.Label
        Me.SST6 = New System.Windows.Forms.Label
        Me.SSO6 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.VAC6 = New System.Windows.Forms.Label
        Me.NB6 = New System.Windows.Forms.Label
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.SSS7 = New System.Windows.Forms.Label
        Me.SST7 = New System.Windows.Forms.Label
        Me.SSO7 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.VAC7 = New System.Windows.Forms.Label
        Me.NB7 = New System.Windows.Forms.Label
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.SSS8 = New System.Windows.Forms.Label
        Me.SST8 = New System.Windows.Forms.Label
        Me.SSO8 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.VAC8 = New System.Windows.Forms.Label
        Me.NB8 = New System.Windows.Forms.Label
        Me.Panel5 = New System.Windows.Forms.Panel
        Me.SSS4 = New System.Windows.Forms.Label
        Me.SST4 = New System.Windows.Forms.Label
        Me.SSO4 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.VAC4 = New System.Windows.Forms.Label
        Me.NB4 = New System.Windows.Forms.Label
        Me.Panel6 = New System.Windows.Forms.Panel
        Me.SSS3 = New System.Windows.Forms.Label
        Me.SST3 = New System.Windows.Forms.Label
        Me.SSO3 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.VAC3 = New System.Windows.Forms.Label
        Me.NB3 = New System.Windows.Forms.Label
        Me.Panel7 = New System.Windows.Forms.Panel
        Me.SSS2 = New System.Windows.Forms.Label
        Me.SST2 = New System.Windows.Forms.Label
        Me.SSO2 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.VAC2 = New System.Windows.Forms.Label
        Me.NB2 = New System.Windows.Forms.Label
        Me.Panel8 = New System.Windows.Forms.Panel
        Me.SSS1 = New System.Windows.Forms.Label
        Me.SST1 = New System.Windows.Forms.Label
        Me.SSO1 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.VAC1 = New System.Windows.Forms.Label
        Me.NB1 = New System.Windows.Forms.Label
        Me.Panel9 = New System.Windows.Forms.Panel
        Me.SSS0 = New System.Windows.Forms.Label
        Me.SST0 = New System.Windows.Forms.Label
        Me.SSO0 = New System.Windows.Forms.Label
        Me.Label0 = New System.Windows.Forms.Label
        Me.VAC0 = New System.Windows.Forms.Label
        Me.NB0 = New System.Windows.Forms.Label
        Me.Panel10 = New System.Windows.Forms.Panel
        Me.SSS11 = New System.Windows.Forms.Label
        Me.SST11 = New System.Windows.Forms.Label
        Me.SSO11 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.VAC11 = New System.Windows.Forms.Label
        Me.NB11 = New System.Windows.Forms.Label
        Me.Panel11 = New System.Windows.Forms.Panel
        Me.SSS10 = New System.Windows.Forms.Label
        Me.SST10 = New System.Windows.Forms.Label
        Me.SSO10 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.VAC10 = New System.Windows.Forms.Label
        Me.NB10 = New System.Windows.Forms.Label
        Me.Panel12 = New System.Windows.Forms.Panel
        Me.SSS9 = New System.Windows.Forms.Label
        Me.SST9 = New System.Windows.Forms.Label
        Me.SSO9 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.VAC9 = New System.Windows.Forms.Label
        Me.NB9 = New System.Windows.Forms.Label
        Me.TED = New System.Windows.Forms.Label
        Me.UED = New System.Windows.Forms.Label
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel1.Controls.Add(Me.SSS5)
        Me.Panel1.Controls.Add(Me.SST5)
        Me.Panel1.Controls.Add(Me.SSO5)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.VAC5)
        Me.Panel1.Controls.Add(Me.NB5)
        Me.Panel1.Location = New System.Drawing.Point(12, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(207, 106)
        Me.Panel1.TabIndex = 7
        '
        'SSS5
        '
        Me.SSS5.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSS5.ForeColor = System.Drawing.Color.Gray
        Me.SSS5.Location = New System.Drawing.Point(138, 11)
        Me.SSS5.Name = "SSS5"
        Me.SSS5.Size = New System.Drawing.Size(35, 56)
        Me.SSS5.TabIndex = 11
        Me.SSS5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SST5
        '
        Me.SST5.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SST5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.SST5.Location = New System.Drawing.Point(87, 11)
        Me.SST5.Name = "SST5"
        Me.SST5.Size = New System.Drawing.Size(35, 56)
        Me.SST5.TabIndex = 10
        Me.SST5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SSO5
        '
        Me.SSO5.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSO5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.SSO5.Location = New System.Drawing.Point(32, 11)
        Me.SSO5.Name = "SSO5"
        Me.SSO5.Size = New System.Drawing.Size(36, 56)
        Me.SSO5.TabIndex = 8
        Me.SSO5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.Label5.Location = New System.Drawing.Point(179, 78)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(26, 20)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "巳"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'VAC5
        '
        Me.VAC5.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.VAC5.ForeColor = System.Drawing.Color.Gray
        Me.VAC5.Location = New System.Drawing.Point(46, 79)
        Me.VAC5.Name = "VAC5"
        Me.VAC5.Size = New System.Drawing.Size(127, 21)
        Me.VAC5.TabIndex = 9
        Me.VAC5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NB5
        '
        Me.NB5.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.NB5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.NB5.Location = New System.Drawing.Point(2, 81)
        Me.NB5.Name = "NB5"
        Me.NB5.Size = New System.Drawing.Size(44, 17)
        Me.NB5.TabIndex = 8
        Me.NB5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel2.Controls.Add(Me.SSS6)
        Me.Panel2.Controls.Add(Me.SST6)
        Me.Panel2.Controls.Add(Me.SSO6)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.VAC6)
        Me.Panel2.Controls.Add(Me.NB6)
        Me.Panel2.Location = New System.Drawing.Point(225, 12)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(207, 106)
        Me.Panel2.TabIndex = 8
        '
        'SSS6
        '
        Me.SSS6.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSS6.ForeColor = System.Drawing.Color.Gray
        Me.SSS6.Location = New System.Drawing.Point(138, 11)
        Me.SSS6.Name = "SSS6"
        Me.SSS6.Size = New System.Drawing.Size(35, 56)
        Me.SSS6.TabIndex = 11
        Me.SSS6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SST6
        '
        Me.SST6.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SST6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.SST6.Location = New System.Drawing.Point(87, 11)
        Me.SST6.Name = "SST6"
        Me.SST6.Size = New System.Drawing.Size(35, 56)
        Me.SST6.TabIndex = 10
        Me.SST6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SSO6
        '
        Me.SSO6.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSO6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.SSO6.Location = New System.Drawing.Point(32, 11)
        Me.SSO6.Name = "SSO6"
        Me.SSO6.Size = New System.Drawing.Size(36, 56)
        Me.SSO6.TabIndex = 8
        Me.SSO6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.Label6.Location = New System.Drawing.Point(179, 78)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(26, 20)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "午"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'VAC6
        '
        Me.VAC6.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.VAC6.ForeColor = System.Drawing.Color.Gray
        Me.VAC6.Location = New System.Drawing.Point(46, 79)
        Me.VAC6.Name = "VAC6"
        Me.VAC6.Size = New System.Drawing.Size(127, 21)
        Me.VAC6.TabIndex = 9
        Me.VAC6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NB6
        '
        Me.NB6.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.NB6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.NB6.Location = New System.Drawing.Point(2, 81)
        Me.NB6.Name = "NB6"
        Me.NB6.Size = New System.Drawing.Size(44, 17)
        Me.NB6.TabIndex = 8
        Me.NB6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel3.Controls.Add(Me.SSS7)
        Me.Panel3.Controls.Add(Me.SST7)
        Me.Panel3.Controls.Add(Me.SSO7)
        Me.Panel3.Controls.Add(Me.Label7)
        Me.Panel3.Controls.Add(Me.VAC7)
        Me.Panel3.Controls.Add(Me.NB7)
        Me.Panel3.Location = New System.Drawing.Point(438, 12)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(207, 106)
        Me.Panel3.TabIndex = 9
        '
        'SSS7
        '
        Me.SSS7.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSS7.ForeColor = System.Drawing.Color.Gray
        Me.SSS7.Location = New System.Drawing.Point(138, 11)
        Me.SSS7.Name = "SSS7"
        Me.SSS7.Size = New System.Drawing.Size(35, 56)
        Me.SSS7.TabIndex = 11
        Me.SSS7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SST7
        '
        Me.SST7.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SST7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.SST7.Location = New System.Drawing.Point(87, 11)
        Me.SST7.Name = "SST7"
        Me.SST7.Size = New System.Drawing.Size(35, 56)
        Me.SST7.TabIndex = 10
        Me.SST7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SSO7
        '
        Me.SSO7.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSO7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.SSO7.Location = New System.Drawing.Point(32, 11)
        Me.SSO7.Name = "SSO7"
        Me.SSO7.Size = New System.Drawing.Size(36, 56)
        Me.SSO7.TabIndex = 8
        Me.SSO7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.Label7.Location = New System.Drawing.Point(179, 78)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(26, 20)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "未"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'VAC7
        '
        Me.VAC7.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.VAC7.ForeColor = System.Drawing.Color.Gray
        Me.VAC7.Location = New System.Drawing.Point(46, 79)
        Me.VAC7.Name = "VAC7"
        Me.VAC7.Size = New System.Drawing.Size(127, 21)
        Me.VAC7.TabIndex = 9
        Me.VAC7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NB7
        '
        Me.NB7.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.NB7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.NB7.Location = New System.Drawing.Point(2, 81)
        Me.NB7.Name = "NB7"
        Me.NB7.Size = New System.Drawing.Size(44, 17)
        Me.NB7.TabIndex = 8
        Me.NB7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel4.Controls.Add(Me.SSS8)
        Me.Panel4.Controls.Add(Me.SST8)
        Me.Panel4.Controls.Add(Me.SSO8)
        Me.Panel4.Controls.Add(Me.Label8)
        Me.Panel4.Controls.Add(Me.VAC8)
        Me.Panel4.Controls.Add(Me.NB8)
        Me.Panel4.Location = New System.Drawing.Point(651, 12)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(207, 106)
        Me.Panel4.TabIndex = 10
        '
        'SSS8
        '
        Me.SSS8.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSS8.ForeColor = System.Drawing.Color.Gray
        Me.SSS8.Location = New System.Drawing.Point(138, 11)
        Me.SSS8.Name = "SSS8"
        Me.SSS8.Size = New System.Drawing.Size(35, 56)
        Me.SSS8.TabIndex = 11
        Me.SSS8.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SST8
        '
        Me.SST8.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SST8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.SST8.Location = New System.Drawing.Point(87, 11)
        Me.SST8.Name = "SST8"
        Me.SST8.Size = New System.Drawing.Size(35, 56)
        Me.SST8.TabIndex = 10
        Me.SST8.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SSO8
        '
        Me.SSO8.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSO8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.SSO8.Location = New System.Drawing.Point(32, 11)
        Me.SSO8.Name = "SSO8"
        Me.SSO8.Size = New System.Drawing.Size(36, 56)
        Me.SSO8.TabIndex = 8
        Me.SSO8.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.Label8.Location = New System.Drawing.Point(179, 78)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(26, 20)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "申"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'VAC8
        '
        Me.VAC8.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.VAC8.ForeColor = System.Drawing.Color.Gray
        Me.VAC8.Location = New System.Drawing.Point(46, 79)
        Me.VAC8.Name = "VAC8"
        Me.VAC8.Size = New System.Drawing.Size(127, 21)
        Me.VAC8.TabIndex = 9
        Me.VAC8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NB8
        '
        Me.NB8.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.NB8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.NB8.Location = New System.Drawing.Point(2, 81)
        Me.NB8.Name = "NB8"
        Me.NB8.Size = New System.Drawing.Size(44, 17)
        Me.NB8.TabIndex = 8
        Me.NB8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel5.Controls.Add(Me.SSS4)
        Me.Panel5.Controls.Add(Me.SST4)
        Me.Panel5.Controls.Add(Me.SSO4)
        Me.Panel5.Controls.Add(Me.Label4)
        Me.Panel5.Controls.Add(Me.VAC4)
        Me.Panel5.Controls.Add(Me.NB4)
        Me.Panel5.Location = New System.Drawing.Point(12, 124)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(207, 106)
        Me.Panel5.TabIndex = 11
        '
        'SSS4
        '
        Me.SSS4.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSS4.ForeColor = System.Drawing.Color.Gray
        Me.SSS4.Location = New System.Drawing.Point(138, 11)
        Me.SSS4.Name = "SSS4"
        Me.SSS4.Size = New System.Drawing.Size(35, 56)
        Me.SSS4.TabIndex = 11
        Me.SSS4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SST4
        '
        Me.SST4.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SST4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.SST4.Location = New System.Drawing.Point(87, 11)
        Me.SST4.Name = "SST4"
        Me.SST4.Size = New System.Drawing.Size(35, 56)
        Me.SST4.TabIndex = 10
        Me.SST4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SSO4
        '
        Me.SSO4.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSO4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.SSO4.Location = New System.Drawing.Point(32, 11)
        Me.SSO4.Name = "SSO4"
        Me.SSO4.Size = New System.Drawing.Size(36, 56)
        Me.SSO4.TabIndex = 8
        Me.SSO4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.Label4.Location = New System.Drawing.Point(179, 78)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(26, 20)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "辰"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'VAC4
        '
        Me.VAC4.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.VAC4.ForeColor = System.Drawing.Color.Gray
        Me.VAC4.Location = New System.Drawing.Point(46, 79)
        Me.VAC4.Name = "VAC4"
        Me.VAC4.Size = New System.Drawing.Size(127, 21)
        Me.VAC4.TabIndex = 9
        Me.VAC4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NB4
        '
        Me.NB4.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.NB4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.NB4.Location = New System.Drawing.Point(2, 81)
        Me.NB4.Name = "NB4"
        Me.NB4.Size = New System.Drawing.Size(44, 17)
        Me.NB4.TabIndex = 8
        Me.NB4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel6.Controls.Add(Me.SSS3)
        Me.Panel6.Controls.Add(Me.SST3)
        Me.Panel6.Controls.Add(Me.SSO3)
        Me.Panel6.Controls.Add(Me.Label3)
        Me.Panel6.Controls.Add(Me.VAC3)
        Me.Panel6.Controls.Add(Me.NB3)
        Me.Panel6.Location = New System.Drawing.Point(12, 236)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(207, 106)
        Me.Panel6.TabIndex = 12
        '
        'SSS3
        '
        Me.SSS3.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSS3.ForeColor = System.Drawing.Color.Gray
        Me.SSS3.Location = New System.Drawing.Point(138, 11)
        Me.SSS3.Name = "SSS3"
        Me.SSS3.Size = New System.Drawing.Size(35, 56)
        Me.SSS3.TabIndex = 11
        Me.SSS3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SST3
        '
        Me.SST3.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SST3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.SST3.Location = New System.Drawing.Point(87, 11)
        Me.SST3.Name = "SST3"
        Me.SST3.Size = New System.Drawing.Size(35, 56)
        Me.SST3.TabIndex = 10
        Me.SST3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SSO3
        '
        Me.SSO3.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSO3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.SSO3.Location = New System.Drawing.Point(32, 11)
        Me.SSO3.Name = "SSO3"
        Me.SSO3.Size = New System.Drawing.Size(36, 56)
        Me.SSO3.TabIndex = 8
        Me.SSO3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.Label3.Location = New System.Drawing.Point(179, 78)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(26, 20)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "卯"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'VAC3
        '
        Me.VAC3.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.VAC3.ForeColor = System.Drawing.Color.Gray
        Me.VAC3.Location = New System.Drawing.Point(46, 79)
        Me.VAC3.Name = "VAC3"
        Me.VAC3.Size = New System.Drawing.Size(127, 21)
        Me.VAC3.TabIndex = 9
        Me.VAC3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NB3
        '
        Me.NB3.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.NB3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.NB3.Location = New System.Drawing.Point(2, 81)
        Me.NB3.Name = "NB3"
        Me.NB3.Size = New System.Drawing.Size(44, 17)
        Me.NB3.TabIndex = 8
        Me.NB3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel7.Controls.Add(Me.SSS2)
        Me.Panel7.Controls.Add(Me.SST2)
        Me.Panel7.Controls.Add(Me.SSO2)
        Me.Panel7.Controls.Add(Me.Label2)
        Me.Panel7.Controls.Add(Me.VAC2)
        Me.Panel7.Controls.Add(Me.NB2)
        Me.Panel7.Location = New System.Drawing.Point(12, 348)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(207, 106)
        Me.Panel7.TabIndex = 13
        '
        'SSS2
        '
        Me.SSS2.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSS2.ForeColor = System.Drawing.Color.Gray
        Me.SSS2.Location = New System.Drawing.Point(138, 11)
        Me.SSS2.Name = "SSS2"
        Me.SSS2.Size = New System.Drawing.Size(35, 56)
        Me.SSS2.TabIndex = 11
        Me.SSS2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SST2
        '
        Me.SST2.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SST2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.SST2.Location = New System.Drawing.Point(87, 11)
        Me.SST2.Name = "SST2"
        Me.SST2.Size = New System.Drawing.Size(35, 56)
        Me.SST2.TabIndex = 10
        Me.SST2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SSO2
        '
        Me.SSO2.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSO2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.SSO2.Location = New System.Drawing.Point(32, 11)
        Me.SSO2.Name = "SSO2"
        Me.SSO2.Size = New System.Drawing.Size(36, 56)
        Me.SSO2.TabIndex = 8
        Me.SSO2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.Label2.Location = New System.Drawing.Point(179, 78)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(26, 20)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "寅"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'VAC2
        '
        Me.VAC2.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.VAC2.ForeColor = System.Drawing.Color.Gray
        Me.VAC2.Location = New System.Drawing.Point(46, 79)
        Me.VAC2.Name = "VAC2"
        Me.VAC2.Size = New System.Drawing.Size(127, 21)
        Me.VAC2.TabIndex = 9
        Me.VAC2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NB2
        '
        Me.NB2.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.NB2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.NB2.Location = New System.Drawing.Point(2, 81)
        Me.NB2.Name = "NB2"
        Me.NB2.Size = New System.Drawing.Size(44, 17)
        Me.NB2.TabIndex = 8
        Me.NB2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel8.Controls.Add(Me.SSS1)
        Me.Panel8.Controls.Add(Me.SST1)
        Me.Panel8.Controls.Add(Me.SSO1)
        Me.Panel8.Controls.Add(Me.Label1)
        Me.Panel8.Controls.Add(Me.VAC1)
        Me.Panel8.Controls.Add(Me.NB1)
        Me.Panel8.Location = New System.Drawing.Point(225, 348)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(207, 106)
        Me.Panel8.TabIndex = 14
        '
        'SSS1
        '
        Me.SSS1.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSS1.ForeColor = System.Drawing.Color.Gray
        Me.SSS1.Location = New System.Drawing.Point(138, 11)
        Me.SSS1.Name = "SSS1"
        Me.SSS1.Size = New System.Drawing.Size(35, 56)
        Me.SSS1.TabIndex = 11
        Me.SSS1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SST1
        '
        Me.SST1.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SST1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.SST1.Location = New System.Drawing.Point(87, 11)
        Me.SST1.Name = "SST1"
        Me.SST1.Size = New System.Drawing.Size(35, 56)
        Me.SST1.TabIndex = 10
        Me.SST1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SSO1
        '
        Me.SSO1.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSO1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.SSO1.Location = New System.Drawing.Point(32, 11)
        Me.SSO1.Name = "SSO1"
        Me.SSO1.Size = New System.Drawing.Size(36, 56)
        Me.SSO1.TabIndex = 8
        Me.SSO1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.Label1.Location = New System.Drawing.Point(179, 78)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(26, 20)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "丑"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'VAC1
        '
        Me.VAC1.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.VAC1.ForeColor = System.Drawing.Color.Gray
        Me.VAC1.Location = New System.Drawing.Point(46, 79)
        Me.VAC1.Name = "VAC1"
        Me.VAC1.Size = New System.Drawing.Size(127, 21)
        Me.VAC1.TabIndex = 9
        Me.VAC1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NB1
        '
        Me.NB1.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.NB1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.NB1.Location = New System.Drawing.Point(2, 81)
        Me.NB1.Name = "NB1"
        Me.NB1.Size = New System.Drawing.Size(44, 17)
        Me.NB1.TabIndex = 8
        Me.NB1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel9.Controls.Add(Me.SSS0)
        Me.Panel9.Controls.Add(Me.SST0)
        Me.Panel9.Controls.Add(Me.SSO0)
        Me.Panel9.Controls.Add(Me.Label0)
        Me.Panel9.Controls.Add(Me.VAC0)
        Me.Panel9.Controls.Add(Me.NB0)
        Me.Panel9.Location = New System.Drawing.Point(438, 348)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(207, 106)
        Me.Panel9.TabIndex = 15
        '
        'SSS0
        '
        Me.SSS0.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSS0.ForeColor = System.Drawing.Color.Gray
        Me.SSS0.Location = New System.Drawing.Point(138, 11)
        Me.SSS0.Name = "SSS0"
        Me.SSS0.Size = New System.Drawing.Size(35, 56)
        Me.SSS0.TabIndex = 11
        Me.SSS0.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SST0
        '
        Me.SST0.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SST0.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.SST0.Location = New System.Drawing.Point(87, 11)
        Me.SST0.Name = "SST0"
        Me.SST0.Size = New System.Drawing.Size(35, 56)
        Me.SST0.TabIndex = 10
        Me.SST0.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SSO0
        '
        Me.SSO0.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSO0.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.SSO0.Location = New System.Drawing.Point(32, 11)
        Me.SSO0.Name = "SSO0"
        Me.SSO0.Size = New System.Drawing.Size(36, 56)
        Me.SSO0.TabIndex = 8
        Me.SSO0.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label0
        '
        Me.Label0.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label0.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.Label0.Location = New System.Drawing.Point(179, 78)
        Me.Label0.Name = "Label0"
        Me.Label0.Size = New System.Drawing.Size(26, 20)
        Me.Label0.TabIndex = 8
        Me.Label0.Text = "子"
        Me.Label0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'VAC0
        '
        Me.VAC0.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.VAC0.ForeColor = System.Drawing.Color.Gray
        Me.VAC0.Location = New System.Drawing.Point(46, 79)
        Me.VAC0.Name = "VAC0"
        Me.VAC0.Size = New System.Drawing.Size(127, 21)
        Me.VAC0.TabIndex = 9
        Me.VAC0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NB0
        '
        Me.NB0.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.NB0.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.NB0.Location = New System.Drawing.Point(2, 81)
        Me.NB0.Name = "NB0"
        Me.NB0.Size = New System.Drawing.Size(44, 17)
        Me.NB0.TabIndex = 8
        Me.NB0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel10.Controls.Add(Me.SSS11)
        Me.Panel10.Controls.Add(Me.SST11)
        Me.Panel10.Controls.Add(Me.SSO11)
        Me.Panel10.Controls.Add(Me.Label11)
        Me.Panel10.Controls.Add(Me.VAC11)
        Me.Panel10.Controls.Add(Me.NB11)
        Me.Panel10.Location = New System.Drawing.Point(651, 348)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(207, 106)
        Me.Panel10.TabIndex = 16
        '
        'SSS11
        '
        Me.SSS11.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSS11.ForeColor = System.Drawing.Color.Gray
        Me.SSS11.Location = New System.Drawing.Point(138, 11)
        Me.SSS11.Name = "SSS11"
        Me.SSS11.Size = New System.Drawing.Size(35, 56)
        Me.SSS11.TabIndex = 11
        Me.SSS11.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SST11
        '
        Me.SST11.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SST11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.SST11.Location = New System.Drawing.Point(87, 11)
        Me.SST11.Name = "SST11"
        Me.SST11.Size = New System.Drawing.Size(35, 56)
        Me.SST11.TabIndex = 10
        Me.SST11.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SSO11
        '
        Me.SSO11.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSO11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.SSO11.Location = New System.Drawing.Point(32, 11)
        Me.SSO11.Name = "SSO11"
        Me.SSO11.Size = New System.Drawing.Size(36, 56)
        Me.SSO11.TabIndex = 8
        Me.SSO11.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.Label11.Location = New System.Drawing.Point(179, 78)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(26, 20)
        Me.Label11.TabIndex = 8
        Me.Label11.Text = "亥"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'VAC11
        '
        Me.VAC11.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.VAC11.ForeColor = System.Drawing.Color.Gray
        Me.VAC11.Location = New System.Drawing.Point(46, 79)
        Me.VAC11.Name = "VAC11"
        Me.VAC11.Size = New System.Drawing.Size(127, 21)
        Me.VAC11.TabIndex = 9
        Me.VAC11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NB11
        '
        Me.NB11.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.NB11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.NB11.Location = New System.Drawing.Point(2, 81)
        Me.NB11.Name = "NB11"
        Me.NB11.Size = New System.Drawing.Size(44, 17)
        Me.NB11.TabIndex = 8
        Me.NB11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel11
        '
        Me.Panel11.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel11.Controls.Add(Me.SSS10)
        Me.Panel11.Controls.Add(Me.SST10)
        Me.Panel11.Controls.Add(Me.SSO10)
        Me.Panel11.Controls.Add(Me.Label10)
        Me.Panel11.Controls.Add(Me.VAC10)
        Me.Panel11.Controls.Add(Me.NB10)
        Me.Panel11.Location = New System.Drawing.Point(651, 236)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(207, 106)
        Me.Panel11.TabIndex = 17
        '
        'SSS10
        '
        Me.SSS10.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSS10.ForeColor = System.Drawing.Color.Gray
        Me.SSS10.Location = New System.Drawing.Point(138, 11)
        Me.SSS10.Name = "SSS10"
        Me.SSS10.Size = New System.Drawing.Size(35, 56)
        Me.SSS10.TabIndex = 11
        Me.SSS10.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SST10
        '
        Me.SST10.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SST10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.SST10.Location = New System.Drawing.Point(87, 11)
        Me.SST10.Name = "SST10"
        Me.SST10.Size = New System.Drawing.Size(35, 56)
        Me.SST10.TabIndex = 10
        Me.SST10.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SSO10
        '
        Me.SSO10.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSO10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.SSO10.Location = New System.Drawing.Point(32, 11)
        Me.SSO10.Name = "SSO10"
        Me.SSO10.Size = New System.Drawing.Size(36, 56)
        Me.SSO10.TabIndex = 8
        Me.SSO10.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.Label10.Location = New System.Drawing.Point(179, 78)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(26, 20)
        Me.Label10.TabIndex = 8
        Me.Label10.Text = "戌"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'VAC10
        '
        Me.VAC10.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.VAC10.ForeColor = System.Drawing.Color.Gray
        Me.VAC10.Location = New System.Drawing.Point(46, 79)
        Me.VAC10.Name = "VAC10"
        Me.VAC10.Size = New System.Drawing.Size(127, 21)
        Me.VAC10.TabIndex = 9
        Me.VAC10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NB10
        '
        Me.NB10.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.NB10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.NB10.Location = New System.Drawing.Point(2, 81)
        Me.NB10.Name = "NB10"
        Me.NB10.Size = New System.Drawing.Size(44, 17)
        Me.NB10.TabIndex = 8
        Me.NB10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel12
        '
        Me.Panel12.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel12.Controls.Add(Me.SSS9)
        Me.Panel12.Controls.Add(Me.SST9)
        Me.Panel12.Controls.Add(Me.SSO9)
        Me.Panel12.Controls.Add(Me.Label9)
        Me.Panel12.Controls.Add(Me.VAC9)
        Me.Panel12.Controls.Add(Me.NB9)
        Me.Panel12.Location = New System.Drawing.Point(651, 124)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(207, 106)
        Me.Panel12.TabIndex = 18
        '
        'SSS9
        '
        Me.SSS9.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSS9.ForeColor = System.Drawing.Color.Gray
        Me.SSS9.Location = New System.Drawing.Point(138, 11)
        Me.SSS9.Name = "SSS9"
        Me.SSS9.Size = New System.Drawing.Size(35, 56)
        Me.SSS9.TabIndex = 11
        Me.SSS9.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SST9
        '
        Me.SST9.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SST9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.SST9.Location = New System.Drawing.Point(87, 11)
        Me.SST9.Name = "SST9"
        Me.SST9.Size = New System.Drawing.Size(35, 56)
        Me.SST9.TabIndex = 10
        Me.SST9.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'SSO9
        '
        Me.SSO9.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SSO9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.SSO9.Location = New System.Drawing.Point(32, 11)
        Me.SSO9.Name = "SSO9"
        Me.SSO9.Size = New System.Drawing.Size(36, 56)
        Me.SSO9.TabIndex = 8
        Me.SSO9.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.Label9.Location = New System.Drawing.Point(179, 78)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(26, 20)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "酉"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'VAC9
        '
        Me.VAC9.Font = New System.Drawing.Font("微軟正黑體", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.VAC9.ForeColor = System.Drawing.Color.Gray
        Me.VAC9.Location = New System.Drawing.Point(46, 79)
        Me.VAC9.Name = "VAC9"
        Me.VAC9.Size = New System.Drawing.Size(127, 21)
        Me.VAC9.TabIndex = 9
        Me.VAC9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NB9
        '
        Me.NB9.Font = New System.Drawing.Font("微軟正黑體", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.NB9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.NB9.Location = New System.Drawing.Point(2, 81)
        Me.NB9.Name = "NB9"
        Me.NB9.Size = New System.Drawing.Size(44, 17)
        Me.NB9.TabIndex = 8
        Me.NB9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TED
        '
        Me.TED.Font = New System.Drawing.Font("微軟正黑體", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TED.Location = New System.Drawing.Point(469, 155)
        Me.TED.Name = "TED"
        Me.TED.Size = New System.Drawing.Size(39, 148)
        Me.TED.TabIndex = 19
        Me.TED.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'UED
        '
        Me.UED.Font = New System.Drawing.Font("微軟正黑體", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UED.Location = New System.Drawing.Point(363, 155)
        Me.UED.Name = "UED"
        Me.UED.Size = New System.Drawing.Size(39, 148)
        Me.UED.TabIndex = 20
        Me.UED.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form6
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(870, 465)
        Me.Controls.Add(Me.UED)
        Me.Controls.Add(Me.TED)
        Me.Controls.Add(Me.Panel12)
        Me.Controls.Add(Me.Panel11)
        Me.Controls.Add(Me.Panel10)
        Me.Controls.Add(Me.Panel9)
        Me.Controls.Add(Me.Panel8)
        Me.Controls.Add(Me.Panel7)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form6"
        Me.Text = "神煞"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel7.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.Panel9.ResumeLayout(False)
        Me.Panel10.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        Me.Panel12.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents VAC5 As System.Windows.Forms.Label
    Friend WithEvents NB5 As System.Windows.Forms.Label
    Friend WithEvents SSO5 As System.Windows.Forms.Label
    Friend WithEvents SST5 As System.Windows.Forms.Label
    Friend WithEvents SSS5 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents SSS6 As System.Windows.Forms.Label
    Friend WithEvents SST6 As System.Windows.Forms.Label
    Friend WithEvents SSO6 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents VAC6 As System.Windows.Forms.Label
    Friend WithEvents NB6 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents SSS7 As System.Windows.Forms.Label
    Friend WithEvents SST7 As System.Windows.Forms.Label
    Friend WithEvents SSO7 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents VAC7 As System.Windows.Forms.Label
    Friend WithEvents NB7 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents SSS8 As System.Windows.Forms.Label
    Friend WithEvents SST8 As System.Windows.Forms.Label
    Friend WithEvents SSO8 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents VAC8 As System.Windows.Forms.Label
    Friend WithEvents NB8 As System.Windows.Forms.Label
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents SSS4 As System.Windows.Forms.Label
    Friend WithEvents SST4 As System.Windows.Forms.Label
    Friend WithEvents SSO4 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents VAC4 As System.Windows.Forms.Label
    Friend WithEvents NB4 As System.Windows.Forms.Label
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents SSS3 As System.Windows.Forms.Label
    Friend WithEvents SST3 As System.Windows.Forms.Label
    Friend WithEvents SSO3 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents VAC3 As System.Windows.Forms.Label
    Friend WithEvents NB3 As System.Windows.Forms.Label
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents SSS2 As System.Windows.Forms.Label
    Friend WithEvents SST2 As System.Windows.Forms.Label
    Friend WithEvents SSO2 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents VAC2 As System.Windows.Forms.Label
    Friend WithEvents NB2 As System.Windows.Forms.Label
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents SSS1 As System.Windows.Forms.Label
    Friend WithEvents SST1 As System.Windows.Forms.Label
    Friend WithEvents SSO1 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents VAC1 As System.Windows.Forms.Label
    Friend WithEvents NB1 As System.Windows.Forms.Label
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents SSS0 As System.Windows.Forms.Label
    Friend WithEvents SST0 As System.Windows.Forms.Label
    Friend WithEvents SSO0 As System.Windows.Forms.Label
    Friend WithEvents Label0 As System.Windows.Forms.Label
    Friend WithEvents VAC0 As System.Windows.Forms.Label
    Friend WithEvents NB0 As System.Windows.Forms.Label
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents SSS11 As System.Windows.Forms.Label
    Friend WithEvents SST11 As System.Windows.Forms.Label
    Friend WithEvents SSO11 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents VAC11 As System.Windows.Forms.Label
    Friend WithEvents NB11 As System.Windows.Forms.Label
    Friend WithEvents Panel11 As System.Windows.Forms.Panel
    Friend WithEvents SSS10 As System.Windows.Forms.Label
    Friend WithEvents SST10 As System.Windows.Forms.Label
    Friend WithEvents SSO10 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents VAC10 As System.Windows.Forms.Label
    Friend WithEvents NB10 As System.Windows.Forms.Label
    Friend WithEvents Panel12 As System.Windows.Forms.Panel
    Friend WithEvents SSS9 As System.Windows.Forms.Label
    Friend WithEvents SST9 As System.Windows.Forms.Label
    Friend WithEvents SSO9 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents VAC9 As System.Windows.Forms.Label
    Friend WithEvents NB9 As System.Windows.Forms.Label
    Friend WithEvents TED As System.Windows.Forms.Label
    Friend WithEvents UED As System.Windows.Forms.Label
End Class
