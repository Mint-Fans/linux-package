﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form8
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form8))
        Me.YTK = New System.Windows.Forms.PictureBox
        Me.YDJ = New System.Windows.Forms.PictureBox
        Me.MTK = New System.Windows.Forms.PictureBox
        Me.MDJ = New System.Windows.Forms.PictureBox
        Me.DTK = New System.Windows.Forms.PictureBox
        Me.DDJ = New System.Windows.Forms.PictureBox
        Me.STK = New System.Windows.Forms.PictureBox
        Me.SDJ = New System.Windows.Forms.PictureBox
        Me.datk0 = New System.Windows.Forms.PictureBox
        Me.dadj0 = New System.Windows.Forms.PictureBox
        Me.dadj1 = New System.Windows.Forms.PictureBox
        Me.datk1 = New System.Windows.Forms.PictureBox
        Me.dadj2 = New System.Windows.Forms.PictureBox
        Me.datk2 = New System.Windows.Forms.PictureBox
        Me.dadj3 = New System.Windows.Forms.PictureBox
        Me.datk3 = New System.Windows.Forms.PictureBox
        Me.dadj4 = New System.Windows.Forms.PictureBox
        Me.datk4 = New System.Windows.Forms.PictureBox
        Me.dadj5 = New System.Windows.Forms.PictureBox
        Me.datk5 = New System.Windows.Forms.PictureBox
        Me.dadj6 = New System.Windows.Forms.PictureBox
        Me.datk6 = New System.Windows.Forms.PictureBox
        Me.dadj7 = New System.Windows.Forms.PictureBox
        Me.datk7 = New System.Windows.Forms.PictureBox
        Me.dadj8 = New System.Windows.Forms.PictureBox
        Me.datk8 = New System.Windows.Forms.PictureBox
        Me.dadj9 = New System.Windows.Forms.PictureBox
        Me.datk9 = New System.Windows.Forms.PictureBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.daages0 = New System.Windows.Forms.Label
        Me.daages1 = New System.Windows.Forms.Label
        Me.daages2 = New System.Windows.Forms.Label
        Me.daages3 = New System.Windows.Forms.Label
        Me.daages4 = New System.Windows.Forms.Label
        Me.daages5 = New System.Windows.Forms.Label
        Me.daages6 = New System.Windows.Forms.Label
        Me.daages7 = New System.Windows.Forms.Label
        Me.daages8 = New System.Windows.Forms.Label
        Me.daages9 = New System.Windows.Forms.Label
        CType(Me.YTK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.YDJ, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MTK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MDJ, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DTK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DDJ, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.STK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SDJ, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.datk0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dadj0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dadj1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.datk1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dadj2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.datk2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dadj3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.datk3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dadj4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.datk4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dadj5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.datk5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dadj6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.datk6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dadj7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.datk7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dadj8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.datk8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dadj9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.datk9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'YTK
        '
        Me.YTK.Image = CType(resources.GetObject("YTK.Image"), System.Drawing.Image)
        Me.YTK.Location = New System.Drawing.Point(360, 67)
        Me.YTK.Name = "YTK"
        Me.YTK.Size = New System.Drawing.Size(50, 50)
        Me.YTK.TabIndex = 0
        Me.YTK.TabStop = False
        '
        'YDJ
        '
        Me.YDJ.Image = CType(resources.GetObject("YDJ.Image"), System.Drawing.Image)
        Me.YDJ.Location = New System.Drawing.Point(360, 123)
        Me.YDJ.Name = "YDJ"
        Me.YDJ.Size = New System.Drawing.Size(50, 50)
        Me.YDJ.TabIndex = 1
        Me.YDJ.TabStop = False
        '
        'MTK
        '
        Me.MTK.Image = CType(resources.GetObject("MTK.Image"), System.Drawing.Image)
        Me.MTK.Location = New System.Drawing.Point(304, 67)
        Me.MTK.Name = "MTK"
        Me.MTK.Size = New System.Drawing.Size(50, 50)
        Me.MTK.TabIndex = 2
        Me.MTK.TabStop = False
        '
        'MDJ
        '
        Me.MDJ.Image = CType(resources.GetObject("MDJ.Image"), System.Drawing.Image)
        Me.MDJ.Location = New System.Drawing.Point(304, 123)
        Me.MDJ.Name = "MDJ"
        Me.MDJ.Size = New System.Drawing.Size(50, 50)
        Me.MDJ.TabIndex = 3
        Me.MDJ.TabStop = False
        '
        'DTK
        '
        Me.DTK.Image = CType(resources.GetObject("DTK.Image"), System.Drawing.Image)
        Me.DTK.Location = New System.Drawing.Point(248, 67)
        Me.DTK.Name = "DTK"
        Me.DTK.Size = New System.Drawing.Size(50, 50)
        Me.DTK.TabIndex = 4
        Me.DTK.TabStop = False
        '
        'DDJ
        '
        Me.DDJ.Image = CType(resources.GetObject("DDJ.Image"), System.Drawing.Image)
        Me.DDJ.Location = New System.Drawing.Point(248, 123)
        Me.DDJ.Name = "DDJ"
        Me.DDJ.Size = New System.Drawing.Size(50, 50)
        Me.DDJ.TabIndex = 5
        Me.DDJ.TabStop = False
        '
        'STK
        '
        Me.STK.Image = CType(resources.GetObject("STK.Image"), System.Drawing.Image)
        Me.STK.Location = New System.Drawing.Point(192, 67)
        Me.STK.Name = "STK"
        Me.STK.Size = New System.Drawing.Size(50, 50)
        Me.STK.TabIndex = 6
        Me.STK.TabStop = False
        '
        'SDJ
        '
        Me.SDJ.Image = CType(resources.GetObject("SDJ.Image"), System.Drawing.Image)
        Me.SDJ.Location = New System.Drawing.Point(192, 123)
        Me.SDJ.Name = "SDJ"
        Me.SDJ.Size = New System.Drawing.Size(50, 50)
        Me.SDJ.TabIndex = 7
        Me.SDJ.TabStop = False
        '
        'datk0
        '
        Me.datk0.Image = CType(resources.GetObject("datk0.Image"), System.Drawing.Image)
        Me.datk0.Location = New System.Drawing.Point(528, 227)
        Me.datk0.Name = "datk0"
        Me.datk0.Size = New System.Drawing.Size(50, 50)
        Me.datk0.TabIndex = 8
        Me.datk0.TabStop = False
        '
        'dadj0
        '
        Me.dadj0.Image = CType(resources.GetObject("dadj0.Image"), System.Drawing.Image)
        Me.dadj0.Location = New System.Drawing.Point(528, 283)
        Me.dadj0.Name = "dadj0"
        Me.dadj0.Size = New System.Drawing.Size(50, 50)
        Me.dadj0.TabIndex = 9
        Me.dadj0.TabStop = False
        '
        'dadj1
        '
        Me.dadj1.Image = CType(resources.GetObject("dadj1.Image"), System.Drawing.Image)
        Me.dadj1.Location = New System.Drawing.Point(472, 283)
        Me.dadj1.Name = "dadj1"
        Me.dadj1.Size = New System.Drawing.Size(50, 50)
        Me.dadj1.TabIndex = 11
        Me.dadj1.TabStop = False
        '
        'datk1
        '
        Me.datk1.Image = CType(resources.GetObject("datk1.Image"), System.Drawing.Image)
        Me.datk1.Location = New System.Drawing.Point(472, 227)
        Me.datk1.Name = "datk1"
        Me.datk1.Size = New System.Drawing.Size(50, 50)
        Me.datk1.TabIndex = 10
        Me.datk1.TabStop = False
        '
        'dadj2
        '
        Me.dadj2.Image = CType(resources.GetObject("dadj2.Image"), System.Drawing.Image)
        Me.dadj2.Location = New System.Drawing.Point(416, 283)
        Me.dadj2.Name = "dadj2"
        Me.dadj2.Size = New System.Drawing.Size(50, 50)
        Me.dadj2.TabIndex = 13
        Me.dadj2.TabStop = False
        '
        'datk2
        '
        Me.datk2.Image = CType(resources.GetObject("datk2.Image"), System.Drawing.Image)
        Me.datk2.Location = New System.Drawing.Point(416, 227)
        Me.datk2.Name = "datk2"
        Me.datk2.Size = New System.Drawing.Size(50, 50)
        Me.datk2.TabIndex = 12
        Me.datk2.TabStop = False
        '
        'dadj3
        '
        Me.dadj3.Image = CType(resources.GetObject("dadj3.Image"), System.Drawing.Image)
        Me.dadj3.Location = New System.Drawing.Point(360, 283)
        Me.dadj3.Name = "dadj3"
        Me.dadj3.Size = New System.Drawing.Size(50, 50)
        Me.dadj3.TabIndex = 15
        Me.dadj3.TabStop = False
        '
        'datk3
        '
        Me.datk3.Image = CType(resources.GetObject("datk3.Image"), System.Drawing.Image)
        Me.datk3.Location = New System.Drawing.Point(360, 227)
        Me.datk3.Name = "datk3"
        Me.datk3.Size = New System.Drawing.Size(50, 50)
        Me.datk3.TabIndex = 14
        Me.datk3.TabStop = False
        '
        'dadj4
        '
        Me.dadj4.Image = CType(resources.GetObject("dadj4.Image"), System.Drawing.Image)
        Me.dadj4.Location = New System.Drawing.Point(304, 283)
        Me.dadj4.Name = "dadj4"
        Me.dadj4.Size = New System.Drawing.Size(50, 50)
        Me.dadj4.TabIndex = 17
        Me.dadj4.TabStop = False
        '
        'datk4
        '
        Me.datk4.Image = CType(resources.GetObject("datk4.Image"), System.Drawing.Image)
        Me.datk4.Location = New System.Drawing.Point(304, 227)
        Me.datk4.Name = "datk4"
        Me.datk4.Size = New System.Drawing.Size(50, 50)
        Me.datk4.TabIndex = 16
        Me.datk4.TabStop = False
        '
        'dadj5
        '
        Me.dadj5.Image = CType(resources.GetObject("dadj5.Image"), System.Drawing.Image)
        Me.dadj5.Location = New System.Drawing.Point(248, 283)
        Me.dadj5.Name = "dadj5"
        Me.dadj5.Size = New System.Drawing.Size(50, 50)
        Me.dadj5.TabIndex = 19
        Me.dadj5.TabStop = False
        '
        'datk5
        '
        Me.datk5.Image = CType(resources.GetObject("datk5.Image"), System.Drawing.Image)
        Me.datk5.Location = New System.Drawing.Point(248, 227)
        Me.datk5.Name = "datk5"
        Me.datk5.Size = New System.Drawing.Size(50, 50)
        Me.datk5.TabIndex = 18
        Me.datk5.TabStop = False
        '
        'dadj6
        '
        Me.dadj6.Image = CType(resources.GetObject("dadj6.Image"), System.Drawing.Image)
        Me.dadj6.Location = New System.Drawing.Point(192, 283)
        Me.dadj6.Name = "dadj6"
        Me.dadj6.Size = New System.Drawing.Size(50, 50)
        Me.dadj6.TabIndex = 21
        Me.dadj6.TabStop = False
        '
        'datk6
        '
        Me.datk6.Image = CType(resources.GetObject("datk6.Image"), System.Drawing.Image)
        Me.datk6.Location = New System.Drawing.Point(192, 227)
        Me.datk6.Name = "datk6"
        Me.datk6.Size = New System.Drawing.Size(50, 50)
        Me.datk6.TabIndex = 20
        Me.datk6.TabStop = False
        '
        'dadj7
        '
        Me.dadj7.Image = CType(resources.GetObject("dadj7.Image"), System.Drawing.Image)
        Me.dadj7.Location = New System.Drawing.Point(136, 283)
        Me.dadj7.Name = "dadj7"
        Me.dadj7.Size = New System.Drawing.Size(50, 50)
        Me.dadj7.TabIndex = 23
        Me.dadj7.TabStop = False
        '
        'datk7
        '
        Me.datk7.Image = CType(resources.GetObject("datk7.Image"), System.Drawing.Image)
        Me.datk7.Location = New System.Drawing.Point(136, 227)
        Me.datk7.Name = "datk7"
        Me.datk7.Size = New System.Drawing.Size(50, 50)
        Me.datk7.TabIndex = 22
        Me.datk7.TabStop = False
        '
        'dadj8
        '
        Me.dadj8.Image = CType(resources.GetObject("dadj8.Image"), System.Drawing.Image)
        Me.dadj8.Location = New System.Drawing.Point(80, 283)
        Me.dadj8.Name = "dadj8"
        Me.dadj8.Size = New System.Drawing.Size(50, 50)
        Me.dadj8.TabIndex = 25
        Me.dadj8.TabStop = False
        '
        'datk8
        '
        Me.datk8.Image = CType(resources.GetObject("datk8.Image"), System.Drawing.Image)
        Me.datk8.Location = New System.Drawing.Point(80, 227)
        Me.datk8.Name = "datk8"
        Me.datk8.Size = New System.Drawing.Size(50, 50)
        Me.datk8.TabIndex = 24
        Me.datk8.TabStop = False
        '
        'dadj9
        '
        Me.dadj9.Image = CType(resources.GetObject("dadj9.Image"), System.Drawing.Image)
        Me.dadj9.Location = New System.Drawing.Point(24, 283)
        Me.dadj9.Name = "dadj9"
        Me.dadj9.Size = New System.Drawing.Size(50, 50)
        Me.dadj9.TabIndex = 27
        Me.dadj9.TabStop = False
        '
        'datk9
        '
        Me.datk9.Image = CType(resources.GetObject("datk9.Image"), System.Drawing.Image)
        Me.datk9.Location = New System.Drawing.Point(24, 227)
        Me.datk9.Name = "datk9"
        Me.datk9.Size = New System.Drawing.Size(50, 50)
        Me.datk9.TabIndex = 26
        Me.datk9.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("微軟正黑體", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label1.Location = New System.Drawing.Point(363, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 36)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "年"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("微軟正黑體", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label2.Location = New System.Drawing.Point(307, 23)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 36)
        Me.Label2.TabIndex = 29
        Me.Label2.Text = "月"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("微軟正黑體", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label3.Location = New System.Drawing.Point(251, 23)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 36)
        Me.Label3.TabIndex = 30
        Me.Label3.Text = "日"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("微軟正黑體", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label4.Location = New System.Drawing.Point(195, 23)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 36)
        Me.Label4.TabIndex = 31
        Me.Label4.Text = "時"
        '
        'daages0
        '
        Me.daages0.Location = New System.Drawing.Point(526, 197)
        Me.daages0.Name = "daages0"
        Me.daages0.Size = New System.Drawing.Size(52, 18)
        Me.daages0.TabIndex = 32
        Me.daages0.Text = "100 - 100"
        Me.daages0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'daages1
        '
        Me.daages1.Location = New System.Drawing.Point(470, 197)
        Me.daages1.Name = "daages1"
        Me.daages1.Size = New System.Drawing.Size(52, 18)
        Me.daages1.TabIndex = 33
        Me.daages1.Text = "100 - 100"
        Me.daages1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'daages2
        '
        Me.daages2.Location = New System.Drawing.Point(414, 197)
        Me.daages2.Name = "daages2"
        Me.daages2.Size = New System.Drawing.Size(52, 18)
        Me.daages2.TabIndex = 34
        Me.daages2.Text = "100 - 100"
        Me.daages2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'daages3
        '
        Me.daages3.Location = New System.Drawing.Point(358, 197)
        Me.daages3.Name = "daages3"
        Me.daages3.Size = New System.Drawing.Size(52, 18)
        Me.daages3.TabIndex = 35
        Me.daages3.Text = "100 - 100"
        Me.daages3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'daages4
        '
        Me.daages4.Location = New System.Drawing.Point(302, 197)
        Me.daages4.Name = "daages4"
        Me.daages4.Size = New System.Drawing.Size(52, 18)
        Me.daages4.TabIndex = 36
        Me.daages4.Text = "100 - 100"
        Me.daages4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'daages5
        '
        Me.daages5.Location = New System.Drawing.Point(246, 197)
        Me.daages5.Name = "daages5"
        Me.daages5.Size = New System.Drawing.Size(52, 18)
        Me.daages5.TabIndex = 37
        Me.daages5.Text = "100 - 100"
        Me.daages5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'daages6
        '
        Me.daages6.Location = New System.Drawing.Point(190, 197)
        Me.daages6.Name = "daages6"
        Me.daages6.Size = New System.Drawing.Size(52, 18)
        Me.daages6.TabIndex = 38
        Me.daages6.Text = "100 - 100"
        Me.daages6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'daages7
        '
        Me.daages7.Location = New System.Drawing.Point(134, 197)
        Me.daages7.Name = "daages7"
        Me.daages7.Size = New System.Drawing.Size(52, 18)
        Me.daages7.TabIndex = 39
        Me.daages7.Text = "100 - 100"
        Me.daages7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'daages8
        '
        Me.daages8.Location = New System.Drawing.Point(78, 197)
        Me.daages8.Name = "daages8"
        Me.daages8.Size = New System.Drawing.Size(52, 18)
        Me.daages8.TabIndex = 40
        Me.daages8.Text = "100 - 100"
        Me.daages8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'daages9
        '
        Me.daages9.Location = New System.Drawing.Point(22, 197)
        Me.daages9.Name = "daages9"
        Me.daages9.Size = New System.Drawing.Size(52, 18)
        Me.daages9.TabIndex = 41
        Me.daages9.Text = "100 - 100"
        Me.daages9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form8
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(604, 359)
        Me.Controls.Add(Me.daages9)
        Me.Controls.Add(Me.daages8)
        Me.Controls.Add(Me.daages7)
        Me.Controls.Add(Me.daages6)
        Me.Controls.Add(Me.daages5)
        Me.Controls.Add(Me.daages4)
        Me.Controls.Add(Me.daages3)
        Me.Controls.Add(Me.daages2)
        Me.Controls.Add(Me.daages1)
        Me.Controls.Add(Me.daages0)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dadj9)
        Me.Controls.Add(Me.datk9)
        Me.Controls.Add(Me.dadj8)
        Me.Controls.Add(Me.datk8)
        Me.Controls.Add(Me.dadj7)
        Me.Controls.Add(Me.datk7)
        Me.Controls.Add(Me.dadj6)
        Me.Controls.Add(Me.datk6)
        Me.Controls.Add(Me.dadj5)
        Me.Controls.Add(Me.datk5)
        Me.Controls.Add(Me.dadj4)
        Me.Controls.Add(Me.datk4)
        Me.Controls.Add(Me.dadj3)
        Me.Controls.Add(Me.datk3)
        Me.Controls.Add(Me.dadj2)
        Me.Controls.Add(Me.datk2)
        Me.Controls.Add(Me.dadj1)
        Me.Controls.Add(Me.datk1)
        Me.Controls.Add(Me.dadj0)
        Me.Controls.Add(Me.datk0)
        Me.Controls.Add(Me.SDJ)
        Me.Controls.Add(Me.STK)
        Me.Controls.Add(Me.DDJ)
        Me.Controls.Add(Me.DTK)
        Me.Controls.Add(Me.MDJ)
        Me.Controls.Add(Me.MTK)
        Me.Controls.Add(Me.YDJ)
        Me.Controls.Add(Me.YTK)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form8"
        Me.Text = "八字氣象"
        CType(Me.YTK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.YDJ, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MTK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MDJ, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DTK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DDJ, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.STK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SDJ, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.datk0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dadj0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dadj1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.datk1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dadj2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.datk2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dadj3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.datk3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dadj4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.datk4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dadj5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.datk5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dadj6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.datk6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dadj7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.datk7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dadj8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.datk8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dadj9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.datk9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents YTK As System.Windows.Forms.PictureBox
    Friend WithEvents YDJ As System.Windows.Forms.PictureBox
    Friend WithEvents MTK As System.Windows.Forms.PictureBox
    Friend WithEvents MDJ As System.Windows.Forms.PictureBox
    Friend WithEvents DTK As System.Windows.Forms.PictureBox
    Friend WithEvents DDJ As System.Windows.Forms.PictureBox
    Friend WithEvents STK As System.Windows.Forms.PictureBox
    Friend WithEvents SDJ As System.Windows.Forms.PictureBox
    Friend WithEvents datk0 As System.Windows.Forms.PictureBox
    Friend WithEvents dadj0 As System.Windows.Forms.PictureBox
    Friend WithEvents dadj1 As System.Windows.Forms.PictureBox
    Friend WithEvents datk1 As System.Windows.Forms.PictureBox
    Friend WithEvents dadj2 As System.Windows.Forms.PictureBox
    Friend WithEvents datk2 As System.Windows.Forms.PictureBox
    Friend WithEvents dadj3 As System.Windows.Forms.PictureBox
    Friend WithEvents datk3 As System.Windows.Forms.PictureBox
    Friend WithEvents dadj4 As System.Windows.Forms.PictureBox
    Friend WithEvents datk4 As System.Windows.Forms.PictureBox
    Friend WithEvents dadj5 As System.Windows.Forms.PictureBox
    Friend WithEvents datk5 As System.Windows.Forms.PictureBox
    Friend WithEvents dadj6 As System.Windows.Forms.PictureBox
    Friend WithEvents datk6 As System.Windows.Forms.PictureBox
    Friend WithEvents dadj7 As System.Windows.Forms.PictureBox
    Friend WithEvents datk7 As System.Windows.Forms.PictureBox
    Friend WithEvents dadj8 As System.Windows.Forms.PictureBox
    Friend WithEvents datk8 As System.Windows.Forms.PictureBox
    Friend WithEvents dadj9 As System.Windows.Forms.PictureBox
    Friend WithEvents datk9 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents daages0 As System.Windows.Forms.Label
    Friend WithEvents daages1 As System.Windows.Forms.Label
    Friend WithEvents daages2 As System.Windows.Forms.Label
    Friend WithEvents daages3 As System.Windows.Forms.Label
    Friend WithEvents daages4 As System.Windows.Forms.Label
    Friend WithEvents daages5 As System.Windows.Forms.Label
    Friend WithEvents daages6 As System.Windows.Forms.Label
    Friend WithEvents daages7 As System.Windows.Forms.Label
    Friend WithEvents daages8 As System.Windows.Forms.Label
    Friend WithEvents daages9 As System.Windows.Forms.Label
End Class
