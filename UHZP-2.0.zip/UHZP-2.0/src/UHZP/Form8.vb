Public Class Form8

    '�ŧi���N����
    Private DUTK(), DUDJ() As PictureBox
    Private DUAGES() As Label

    Private Sub Form8_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        DUTK = New PictureBox() {datk0, datk1, datk2, datk3, datk4, datk5, datk6, datk7, datk8, datk9}
        DUDJ = New PictureBox() {dadj0, dadj1, dadj2, dadj3, dadj4, dadj5, dadj6, dadj7, dadj8, dadj9}
        DUAGES = New Label() {daages0, daages1, daages2, daages3, daages4, daages5, daages6, daages7, daages8, daages9}

        Dim i As Integer

        Dim NUM As String

        '�~�W
        NUM = BirthData(1, 3)
        YTK.Image = Image.FromFile(My.Application.Info.DirectoryPath + "\images\" + "1_" + NUM + ".gif")
        NUM = BirthData(1, 4)
        YDJ.Image = Image.FromFile(My.Application.Info.DirectoryPath + "\images\" + "2_" + NUM + ".gif")
        '��W
        NUM = BirthData(2, 3)
        MTK.Image = Image.FromFile(My.Application.Info.DirectoryPath + "\images\" + "1_" + NUM + ".gif")
        NUM = BirthData(2, 4)
        MDJ.Image = Image.FromFile(My.Application.Info.DirectoryPath + "\images\" + "2_" + NUM + ".gif")
        '��W
        NUM = BirthData(3, 3)
        DTK.Image = Image.FromFile(My.Application.Info.DirectoryPath + "\images\" + "1_" + NUM + ".gif")
        NUM = BirthData(3, 4)
        DDJ.Image = Image.FromFile(My.Application.Info.DirectoryPath + "\images\" + "2_" + NUM + ".gif")
        '�ɬW
        NUM = BirthData(4, 3)
        STK.Image = Image.FromFile(My.Application.Info.DirectoryPath + "\images\" + "1_" + NUM + ".gif")
        NUM = BirthData(4, 4)
        SDJ.Image = Image.FromFile(My.Application.Info.DirectoryPath + "\images\" + "2_" + NUM + ".gif")

        '�j�B
        For i = 0 To 9
            '�j�B�Ѥz
            NUM = dauntk(i + 1)
            DUTK(i).Image = Image.FromFile(My.Application.Info.DirectoryPath + "\images\" + "1_" + NUM + ".gif")

            '�j�B�a��
            NUM = daundj(i + 1)
            DUDJ(i).Image = Image.FromFile(My.Application.Info.DirectoryPath + "\images\" + "2_" + NUM + ".gif")

            '�j�B����
            DUAGES(i).Text = daunage(i + 1)
        Next


    End Sub
End Class