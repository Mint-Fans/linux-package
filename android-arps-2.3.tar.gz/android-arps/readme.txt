adb remount

adb push arps /system/bin/arps
adb shell chown 0.0 /system/bin/arps
adb shell chmod 0755 /system/bin/arps

adb push arpspoof /system/bin/arpspoof
adb shell chown 0.0 /system/bin/arpspoof
adb shell chmod 0755 /system/bin/arpspoof

adb push libnet.so /system/lib/libnet.so
adb shell chown 0.0 /system/lib/libnet.so
adb shell chmod 0644 /system/lib/libnet.so

adb push libpcap.so /system/lib/libpcap.so
adb shell chown 0.0 /system/lib/libpcap.so
adb shell chmod 0644 /system/lib/libpcap.so

adb push libpcre.so /system/lib/libpcre.so
adb shell chown 0.0 /system/lib/libpcre.so
adb shell chmod 0644 /system/lib/libpcre.so

adb push libltdl.so /system/lib/libltdl.so
adb shell chown 0.0 /system/lib/libltdl.so
adb shell chmod 0644 /system/lib/libltdl.so

adb push libgif.so /system/lib/libgif.so
adb shell chown 0.0 /system/lib/libgif.so
adb shell chmod 0644 /system/lib/libgif.so
