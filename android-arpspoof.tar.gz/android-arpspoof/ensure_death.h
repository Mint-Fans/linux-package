/*    provides declarations and includes needed for ensure_death
    Copyright (C) 2011 Robbie Clemons <robclemons@gmail.com> */
    
#ifndef ENSURE_DEATH_H
#define ENSURE_DEATH_H

void ensure_death();

#endif
