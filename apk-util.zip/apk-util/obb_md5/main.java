import java.security.MessageDigest;
import java.io.FileInputStream;
import java.io.File;

public class main
{
	String get_obb_md5_string(String fileName)
	{
		try
		{
			MessageDigest 	md = MessageDigest.getInstance("md5");
			FileInputStream fins = new FileInputStream(fileName);
			File		file = new File(fileName);
			long		fileLength = file.length();
			final long 	fileLengthConst = 0x10016;	//65558
			long  		minNum = Math.min(fileLength, fileLengthConst);
			fileLength	= fileLength - minNum;
			fins.skip(fileLength);
			byte byteArray[]  = new byte[0x400];
			int ret = 0;
			while (true)
			{
				if (ret == -1) break;
				md.update(byteArray, 0, ret);
				ret = fins.read(byteArray);
			}
			byte md5Res[] = md.digest();
			if (md5Res == null)
			{
				return "";
			}
			StringBuffer sb = new StringBuffer();
			int i = 0;
			while (true)
			{
				int md5ResLength = md5Res.length;
				if (i >= md5ResLength)
				{
					break;
				}
				byte tmp_b = md5Res[i];
				int tmp_byte = tmp_b & 0xff;
				tmp_byte = tmp_byte + 0x100;
				String str_tmp = Integer.toString(tmp_byte, 0x10);
				str_tmp = str_tmp.substring(0x1);
				sb.append(str_tmp);
				i++;
			}
			return sb.toString();
		}
		catch (Exception e)
		{
			System.out.println("catch some exception");
			return "";
		}
	}

	public static void main(String args[])
	{
		main ma = new main();

		String str = ma.get_obb_md5_string(args[0]);
		System.out.println(str);
	}
}
