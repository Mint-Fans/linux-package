######################################################
### BOO TW Auto Revenue By Mint Fans
### dep: firefoxdriver, python-selenium, geckodriver
### geckodriver download:
### https://github.com/mozilla/geckodriver/releases/download/v0.21.0/geckodriver-v0.21.0-linux64.tar.gz
### Run: python boo.tw.py $code
######################################################
# coding = utf-8
from time import sleep
from selenium import webdriver
import sys

code = sys.argv[1]

## GUI Mode
browser = webdriver.Firefox();

## Headless Mode
# options = webdriver.FirefoxOptions()
# options.add_argument('-headless')
# browser = webdriver.Firefox(options=options)

## URL
browser.get("http://boo.tw/" + code)

# print(browser.page_source)
## Go To b00.tw
sleep(3)
# browser.find_element_by_xpath("//*[@id='shorturl-go']/strong[1]").click()
browser.find_element_by_class_name("shorutl-string-color").click()

## Go To Link
sleep(3)
# browser.find_element_by_xpath("//*[@id='shorturl-go']/strong[1]").click()
# browser.find_element_by_class_name("shorutl-string-color").click()

# sleep(1)
browser.quit()
