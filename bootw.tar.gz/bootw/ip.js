var page = require('webpage').create();
var url = 'http://www.icanhazip.com';

page.open(url, function (status) {
    console.log(page.plainText);
    phantom.exit();
});

