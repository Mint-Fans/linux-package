######################################################
### BOO TW Auto Revenue By Mint Fans
### dep: firefoxdriver, python-selenium, geckodriver
### geckodriver download:
### https://github.com/mozilla/geckodriver/releases/download/v0.21.0/geckodriver-v0.21.0-linux64.tar.gz
### Run: python boo.tw.py $code
######################################################
# coding = utf-8
from time import sleep
from selenium import webdriver
import subprocess
import sys
import os

code = sys.argv[1]

def kill_firefox():
    if subprocess.call( [ "killall", "-9", "firefox" ] ) > 0:
        print( 'Firefox cleanup - FAILURE!' )
    else:
        print( 'Firefox cleanup - SUCCESS!' )

def restart_tor():
    os.system("sudo systemctl restart tor")
    sleep(5)
    ip_adds = os.system("curl --socks5 127.0.0.1:9050 www.icanhazip.com")
    print("\n" + str(ip_adds))
    main()

def main():
    ## GUI Mode
    #browser = webdriver.Firefox();

    ## Headless Mode
    options = webdriver.FirefoxOptions()
    options.add_argument('-headless')
    browser = webdriver.Firefox(options=options)

    ## URL
    browser.get("http://boo.tw/" + code)

    boo_title = browser.title
    print(boo_title)

    if boo_title == "BOO.TW":
        ## boo.tw
        linkclick = browser.find_element_by_id("shorturl-go")
        links = linkclick.get_attribute('href')
        print(links)

        browser.quit()
        # kill_firefox()

        ## curl
        agent = 'Mozilla/5.0 (X11; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0'
        proxy = '--socks5 127.0.0.1:9050'
        os.system("curl -A '" +  agent + "' " + proxy + " -e http://boo.tw/" + code + " " + links + " -o /tmp/b00.tw.html")

        b00_title = os.system("cat /tmp/b00.tw.html | grep b00.tw | sed 's/.*\/\///g' | sed 's/\/.*//g'")
        print(b00_title)

    else:
        print("boo.tw connection failed!!")

    sleep(2)
    restart_tor()

#if __name__ =="__main__":
main()
