var get = "4662411";
var host = "http://adfoc.us/";
var url = host + get;

var fs = require('fs');
var path = '/tmp/adfoc.us.txt';

var page = require('webpage').create();
page.settings.userAgent = 'Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko';

page.open(url, function(status) {
  var title = page.evaluate(function() {
    return document.title;
  });

  fs.write(path, page.content, 'w');
  console.log('Page title is ' + title);
  phantom.exit();
});