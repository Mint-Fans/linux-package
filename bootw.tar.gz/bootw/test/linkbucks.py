######################################################
### BOO TW Auto Revenue By Mint Fans
### dep: firefoxdriver, python-selenium, geckodriver
### geckodriver download:
### https://github.com/mozilla/geckodriver/releases/download/v0.21.0/geckodriver-v0.21.0-linux64.tar.gz
### Run: python linkbucks.py $code
######################################################
# coding = utf-8
from time import sleep
from selenium import webdriver
import sys
import os

code = sys.argv[1]

def restart_tor():
    os.system("sudo systemctl restart tor")
    sleep(5)
    ip_addr = os.system("curl --socks5 127.0.0.1:9050 ipecho.net/plain")
    print(str(ip_addr))
    main()

def main():
    ## GUI Mode
    browser = webdriver.Firefox();

    ## Headless Mode
    # options = webdriver.FirefoxOptions()
    # options.add_argument('-headless')
    # browser = webdriver.Firefox(options=options)

    ## URL
    browser.get("http://www.linkbucks.com/" + code)

    print(browser.title)

    # check_recaptcha()

    # print(browser.page_source)
    ## Go To b00.tw
    sleep(3)
    # browser.find_element_by_xpath("//*[@id='shorturl-go']/strong[1]").click()
    # browser.find_element_by_class_name("shorutl-string-color").click()

    print(browser.title)
    ## Go To Link
    sleep(5)
    # browser.find_element_by_xpath("//*[@id='shorturl-go']/strong[1]").click()
    # browser.find_element_by_class_name("shorutl-string-color").click()

    # sleep(1)
    browser.quit()

    # kill_firefox()
    restart_tor()

#if __name__ =="__main__":
main()
