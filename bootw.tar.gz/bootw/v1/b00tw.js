var get = "Sr2ba";
var lang = "zh-TW";
var host = "http://b00.tw/";

var fs = require('fs');
var path = '/tmp/boo.tw/b00.tw.txt';

var url = host + get + '?l=' + lang;
var page = require('webpage').create();
page.settings.userAgent = 'Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko';

page.customHeaders = {
  "Referer": "http://boo.tw/" + get
};

page.open(url, function(status) {
  var title = page.evaluate(function() {
    return document.title;
  });
  fs.write(path, page.content, 'w');
  console.log('Page title is ' + title);
  phantom.exit();
});