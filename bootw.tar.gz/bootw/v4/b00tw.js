var system = require('system');

var get = system.args[1];
var lang = system.args[3];
var host = "http://b00.tw/";

var browse_num = system.args[2];

if (browse_num === '1') {
  var browse_name = 'Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko'
} else if (browse_num === '2') {
  var browse_name = 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0'
} else if (browse_num === '3') {
  var browse_name = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/601.7.7 (KHTML, like Gecko) Version/9.1.2 Safari/601.7.7'
} else if (browse_num === '4') {
  var browse_name = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'
} else if (browse_num === '5') {
  var browse_name = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36 OPR/54.0.2952.60'
} else {
  var browse_name = 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:58.0) Gecko/20100101 Firefox/58.0'
}

//var fs = require('fs');
//var html_path = 'b00.tw.html';
//var pic_path = 'b00-screenshot.png';

var gads_data1 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><script>(adsbygoogle = window.adsbygoogle || []).push({google_ad_client: "ca-pub-5853818035217866",enable_page_level_ads: true}); </script>';
var gads_data2 = '<script src="https://js.kiwihk.net/?id=boo" type="text/javascript"></script><script>var KIWI = KIWI || {};KIWI.geminiMobileSticky = true;KIWI.geminiMobilePopup = true;KIWI.geminiDesktopSticky = true;KIWI.geminiDesktopPopup = true;</script>';
var gads_data3 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><ins class="adsbygoogle" style="display:block" data-ad-format="fluid" data-ad-layout-key="-6x+g-gg+ed+135" data-ad-client="ca-pub-5853818035217866" data-ad-slot="7281986666"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>';
var gads_data4 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><ins class="adsbygoogle" style="display:inline-block;width:728px;height:90px" data-ad-client="ca-pub-5853818035217866" data-ad-slot="3756634239"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>';
var gads_data5 = '<script src="https://js.kiwihk.net/?id=boo" type="text/javascript"></script><script>var KIWI = KIWI || {};KIWI.geminiMobileSticky = true;KIWI.geminiMobilePopup = true;KIWI.geminiDesktopSticky = true;KIWI.geminiDesktopPopup = true;</script>';
var gads_data6 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><ins class="adsbygoogle" style="display:block" data-ad-format="fluid" data-ad-layout-key="-8f+1t-dl+em+fa" data-ad-client="ca-pub-5853818035217866" data-ad-slot="8326639838"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>';
var gads_data7 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><ins class="adsbygoogle" style="display:block" data-ad-format="fluid" data-ad-layout-key="-6t+ed+2i-1n-4w" data-ad-client="ca-pub-5853818035217866" data-ad-slot="6050113664"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>';
var gads_data8 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><ins class="adsbygoogle" style="display:block" data-ad-format="fluid" data-ad-layout-key="-6x+g-gg+ed+135" data-ad-client="ca-pub-5853818035217866" data-ad-slot="5373173434"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>';
var gads_data9 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><ins class="adsbygoogle" style="display:block" data-ad-format="fluid" data-ad-layout-key="-6t+ed+2i-1n-4w" data-ad-client="ca-pub-5853818035217866" data-ad-slot="9774164194"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>';
var gads_data10 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><ins class="adsbygoogle" style="display:block" data-ad-format="fluid" data-ad-layout-key="-8e+1r-dc+en+ek" data-ad-client="ca-pub-5853818035217866" data-ad-slot="4220560006"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>';
var gads_data11 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><ins class="adsbygoogle" style="display:block" data-ad-format="fluid" data-ad-layout-key="-8e+1r-dc+en+ek" data-ad-client="ca-pub-5853818035217866" data-ad-slot="8459187913"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>';
var gads_data = gads_data1 + gads_data2 + gads_data3 + gads_data4 + gads_data5 + gads_data6 + gads_data7 + gads_data8 + gads_data9 + gads_data10 + gads_data11;

var url = host + get + '?l=' + lang;

var page = require('webpage').create();

page.settings.userAgent = browse_name;

page.customHeaders = {
  "Referer": "http://boo.tw/" + get
};

page.open(url, function(status) {
    console.log('link to ' + url);
    page.setContent(gads_data, url);
    page.onLoadFinished = function(status) {
        //fs.write(html_path, page.content, 'w');
        //page.render(pic_path);
        phantom.exit();
    };
});

