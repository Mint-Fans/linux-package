var system = require('system');

var get = system.args[1];
var host = "http://boo.tw/";
var url = host + get;

var browse_num = system.args[2];

if (browse_num === '1') {
  var browse_name = 'Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko'
} else if (browse_num === '2') {
  var browse_name = 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0'
} else if (browse_num === '3') {
  var browse_name = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/601.7.7 (KHTML, like Gecko) Version/9.1.2 Safari/601.7.7'
} else if (browse_num === '4') {
  var browse_name = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'
} else if (browse_num === '5') {
  var browse_name = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36 OPR/54.0.2952.60'
} else {
  var browse_name = 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:58.0) Gecko/20100101 Firefox/58.0'
}

//var fs = require('fs');
//var html_path = 'boo.tw.html';
//var pic_path = 'boo-screenshot.png';

var gads_data1 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><script>(adsbygoogle = window.adsbygoogle || []).push({google_ad_client: "ca-pub-5853818035217866", enable_page_level_ads: true});</script>';
var gads_data2 = '<script src="https://js.kiwihk.net/?id=boo" type="text/javascript"></script><script>var KIWI = KIWI || {};KIWI.geminiMobileSticky = true;KIWI.geminiMobilePopup = true;KIWI.geminiDesktopSticky = true;KIWI.geminiDesktopPopup = true;</script>';
var gads_data3 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><ins class="adsbygoogle" style="display:block" data-ad-format="fluid" data-ad-layout-key="-70+i-gg+ee+12j" data-ad-client="ca-pub-5853818035217866" data-ad-slot="5433895984"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>';
var gads_data4 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><ins class="adsbygoogle" style="display:inline-block;width:728px;height:90px" data-ad-client="ca-pub-5853818035217866" data-ad-slot="7130121036"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>';
var gads_data5 = '<script src="https://js.kiwihk.net/?id=boo" type="text/javascript"></script><script>var KIWI = KIWI || {};KIWI.geminiMobileSticky = true;KIWI.geminiMobilePopup = true;KIWI.geminiDesktopSticky = true;KIWI.geminiDesktopPopup = true;</script>';
var gads_data6 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><ins class="adsbygoogle" style="display:block" data-ad-format="fluid" data-ad-layout-key="-6x+g-gg+ed+135" data-ad-client="ca-pub-5853818035217866" data-ad-slot="3420436115"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>';
var gads_data7 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><ins class="adsbygoogle" style="display:block" data-ad-format="fluid" data-ad-layout-key="-6x+g-gg+ed+135" data-ad-client="ca-pub-5853818035217866" data-ad-slot="1456197926"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>';
var gads_data8 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><ins class="adsbygoogle" style="display:block" data-ad-format="fluid" data-ad-layout-key="-70+i-gg+ee+12j" data-ad-client="ca-pub-5853818035217866" data-ad-slot="7162567167"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>';
var gads_data9 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><ins class="adsbygoogle" style="display:block" data-ad-format="fluid" data-ad-layout-key="-70+i-gg+ee+12j" data-ad-client="ca-pub-5853818035217866" data-ad-slot="1683606247"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>';
var gads_data10 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><ins class="adsbygoogle" style="display:block" data-ad-format="fluid" data-ad-layout-key="-6x+g-gg+ed+135" data-ad-client="ca-pub-5853818035217866" data-ad-slot="7885874901"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>';
var gads_data11 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><ins class="adsbygoogle" style="display:block" data-ad-format="fluid" data-ad-layout-key="-6x+g-gg+ed+135" data-ad-client="ca-pub-5853818035217866" data-ad-slot="7993686116"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>';
var gads_data12 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><ins class="adsbygoogle" style="display:block" data-ad-format="fluid" data-ad-layout-key="-8e+1r-dc+en+ek" data-ad-client="ca-pub-5853818035217866" data-ad-slot="4220560006"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>';
var gads_data13 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><ins class="adsbygoogle" style="display:block" data-ad-format="fluid" data-ad-layout-key="-8e+1r-dc+en+ek" data-ad-client="ca-pub-5853818035217866" data-ad-slot="8459187913"></ins><script>(adsbygoogle = window.adsbygoogle || []).push({});</script>';
var gads_data = gads_data1 + gads_data2 + gads_data3 + gads_data4 + gads_data5 + gads_data6 + gads_data7 + gads_data8 + gads_data9 + gads_data10 + gads_data11 + gads_data12 + gads_data13;

var page = require('webpage').create();

page.settings.userAgent = browse_name;

page.customHeaders = {
  "Referer": "https://www.google.com/search?q=" + url
};

page.open(url, function(status) {
    console.log('link to ' + url);
    page.setContent(gads_data, url);
    page.onLoadFinished = function(status) {
        //fs.write(html_path, page.content, 'w');
        //page.render(pic_path);
        phantom.exit();
    };
});
