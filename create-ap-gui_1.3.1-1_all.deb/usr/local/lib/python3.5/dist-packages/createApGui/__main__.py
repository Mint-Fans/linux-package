#!/usr/bin/python3
__author__ = 'Jakub Pelikan'
from createApGui.gui import Gui

## Method start GUI application which show data from FIT Information System
def main():
    tray = Gui()


if __name__ == "__main__":
   # main()
    tray = Gui()
