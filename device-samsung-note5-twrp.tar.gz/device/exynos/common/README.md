Generic common Exynos platform tools and libraries
===============================

Put together by the jcadduono himself.
