Generic common qcom configuration tools
===============================

Copyright 2014 - The CyanogenMod Project
