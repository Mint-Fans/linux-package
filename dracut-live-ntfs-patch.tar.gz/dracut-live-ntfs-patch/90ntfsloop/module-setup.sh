#!/bin/bash

command -v

check() {
    return 0
}

depends() {
    echo base dm
    return 0
}

install() {
    inst_multiple ntfs-3g lowntfs-3g mount.fuse kpartx umount losetup
    inst_script "$moddir/ntfsloop.sh" /sbin/ntfsloop
    inst_hook cmdline 90 "$moddir/parse-ntfsloop.sh"
    inst_hook shutdown 90 "$moddir/shutdown-ntfsloop.sh"
    ln -sf /usr/bin/lowntfs-3g "${initdir}/sbin/mount.lowntfs-3g"
    ln -sf /usr/bin/ntfs-3g "${initdir}/sbin/mount.ntfs"
    ln -sf /usr/bin/ntfs-3g "${initdir}/sbin/mount.ntfs-3g"
    dracut_need_initqueue
}

installkernel() {
    hostonly='' instmods fuse loop
}
