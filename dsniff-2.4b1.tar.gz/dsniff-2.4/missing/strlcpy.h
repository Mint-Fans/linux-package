size_t strlcpy(char *dst, const char *src, size_t siz);
