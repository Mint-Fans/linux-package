Ikariam
=======

The new ikariam server files.

To run the game you must ability the php short tag from php.ini!
