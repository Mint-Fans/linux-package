<div id="breadcrumbs">
    <h3><?=$this->lang->line('you_here')?>:</h3>
    <span class="building"><?=$this->lang->line('full_info')?></span>
</div>