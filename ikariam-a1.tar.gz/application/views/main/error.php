<div id="wrapper"></div>
<div id="text">
    <h1>Ошибка!</h1><br/>
    <a href="<?=$this->config->item('base_url')?>"><?=$this->session->flashdata('error')?></a><br><br><br>
</div>