<h2>Ikariam - <?=$this->lang->line('welcome_title')?></h2>
<div class="txt">
	<p><?=$this->lang->line('welcome_text')?></p>
	<div style="display:block; width:452px; height:250px; background-image: url('<?=$this->config->item('base_url')?>design/trailer-img.jpg')" id="player"></div>
	<!-- this will install flowplayer inside previous A- tag. -->
</div>
<p id="registerForFree" ><?=$this->lang->line('link_playnow_text')?></p>