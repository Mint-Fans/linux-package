<div id="backTo" class="dynamic">
    <h3 class="header"><?=$this->lang->line('constructions_review')?></h3>
    <div class="content">
        <a href="<?=$this->config->item('base_url')?>game/tradeAdvisor/" title="<?=$this->lang->line('back_to')?> <?=$this->lang->line('mayor')?>">
        <img style="border:1px solid #dda654; margin-bottom:10px;" src="<?=$this->config->item('style_url')?>skin/layout/city_logo.gif" width="160" height="100" />
        <span class="textLabel">&lt;&lt; <?=$this->lang->line('back_to')?> <?=$this->lang->line('mayor')?></span></a>
    </div>
    <div class="footer"></div>
</div>