
<head>
<link rel="stylesheet" type="text/css" href="<?=$this->config->item('base_url')?>design/style.css" />
</head>
<body>
<div id="credits">
	<h1>Riconoscimenti</h1>

	<div id="creditNames">
	    <h2>Leader</h2>
		   <p>Idro</p>
</div>	    
</div>
</body>