<div id="rulesOverlay">
	<h1 ><?=$this->lang->line('ikariam')?> - <?=$this->lang->line('rules_1')?><br><br></h1>
	<div id="rulesText">
		<div id="rules">
    <div align="center">
        <?=$this->lang->line('rules_2')?><?=$this->config->item('nome_gioco')?><br /><br />
        <?=$this->lang->line('rules_3')?><br /><br />
        <?=$this->lang->line('rules_4')?></div>
    <h2><?=$this->lang->line('rules_5')?></h2>
    <ul>
        <li>
            <?=$this->lang->line('rules_6')?><br /><br />
            <?=$this->lang->line('rules_7')?></li>
    </ul>
    <h2><?=$this->lang->line('rules_8')?></h2>
    <ul>
        <li>
            <?=$this->lang->line('rules_9')?><br /><br />
            <em><u><strong><?=$this->lang->line('rules_10')?></strong></u></em><br /><br />
            <?=$this->lang->line('rules_11')?></li>
        <li><?=$this->lang->line('rules_12')?></li>
        <li><?=$this->lang->line('rules_13')?></li>
        <li><?=$this->lang->line('rules_14')?></li>
        <li><?=$this->lang->line('rules_15')?></li>
        <li>
            <?=$this->lang->line('rules_16')?><br /><br />
            <u><em><strong><?=$this->lang->line('rules_17')?></strong></em></u>
        </li>
        <li><?=$this->lang->line('rules_18')?></li>
        <li><?=$this->lang->line('rules_19')?></li>
        <li>
            <?=$this->lang->line('rules_20')?><br /><br />
            <u><em><strong><?=$this->lang->line('rules_21')?></strong></em></u>
        </li>
        <li><?=$this->lang->line('rules_22')?></li>
        <li><?=$this->lang->line('rules_23')?></li>
        <li><?=$this->lang->line('rules_24')?></li>
        <li><?=$this->lang->line('rules_25')?></li>
        <li><?=$this->lang->line('rules_26')?></li>
        <li><?=$this->lang->line('rules_27')?></li>
    </ul>
    <h2><?=$this->lang->line('rules_28')?></h2>
    <ul>
        <li>
            <?=$this->lang->line('rules_29')?><br /><br />
            <?=$this->lang->line('rules_30')?><br /><br />
            <?=$this->lang->line('rules_31')?></li>
    </ul>
    <h2><?=$this->lang->line('rules_32')?></h2>
    <ul>
        <li>
            <?=$this->lang->line('rules_33')?><br /><br />
            <?=$this->lang->line('rules_34')?><br /><br />
            <?=$this->lang->line('rules_35')?></li>
    </ul>
    <h2><?=$this->lang->line('rules_36')?></h2>
    <ul>
        <li>
            <?=$this->lang->line('rules_37')?><br /><br />
            <u><em><strong><?=$this->lang->line('rules_38')?></strong></em></u>
        </li>
        <li><?=$this->lang->line('rules_39')?></li>
        <li><?=$this->lang->line('rules_40')?></li>
        <li><?=$this->lang->line('rules_41')?></li>
        <li>
            <?=$this->lang->line('rules_42')?><br /><br />
            <em><strong><?=$this->lang->line('rules_43')?></strong></em>
        </li>
        <li><?=$this->lang->line('rules_44')?></li>
        <li><?=$this->lang->line('rules_45')?></li>
        <li>
            <?=$this->lang->line('rules_46')?><br /><br />
            <u><strong><em><?=$this->lang->line('rules_47')?></em></strong></u><br />
            <?=$this->lang->line('rules_48')?></li>
    </ul>
    <h2><?=$this->lang->line('rules_49')?></h2>
    <ul>
        <li><?=$this->lang->line('rules_50')?></li>
    </ul>
    <h2><?=$this->lang->line('rules_51')?></h2>
    <ul>
        <li>
            <?=$this->lang->line('rules_52')?><br /><br />
            <em><u><strong><?=$this->lang->line('rules_53')?></strong></u></em>
        </li>
        <li><?=$this->lang->line('rules_54')?></li>
        <li><?=$this->lang->line('rules_55')?></li>
        <li>
            <?=$this->lang->line('rules_56')?><br /><br />
            <strong><em><?=$this->lang->line('rules_57')?></em></strong> <?=$this->lang->line('rules_58')?></li>
    </ul>
    <h2><?=$this->lang->line('rules_59')?></h2>
    <ul>
        <li><?=$this->lang->line('rules_60')?></li>
    </ul>
    <h2><?=$this->lang->line('rules_61')?></h2>
    <ul>
        <li>
            <?=$this->lang->line('rules_62')?><br /><br />
            <u><em><strong><?=$this->lang->line('rules_63')?></strong></em></u>
        </li>
        <li><?=$this->lang->line('rules_64')?></li>
        <li><?=$this->lang->line('rules_65')?></li>
        <li><?=$this->lang->line('rules_66')?></li>
    </ul>
    <h2><?=$this->lang->line('rules_67')?></h2>
    <ul>
        <li><?=$this->lang->line('rules_68')?></li>
    </ul>
    <h2><?=$this->lang->line('rules_69')?></h2>
    <ul>
        <li>
            <?=$this->lang->line('rules_70')?><br /><br />
            <u><em><strong><?=$this->lang->line('rules_71')?></strong></em></u>
        </li>
        <li><?=$this->lang->line('rules_72')?></li>
        <li><?=$this->lang->line('rules_73')?></li>
    </ul>
    <h2><?=$this->lang->line('rules_74')?></h2>
    <ul>
        <li><?=$this->lang->line('rules_75')?><br />
<?=$this->lang->line('rules_76')?><br />
<?=$this->lang->line('rules_77')?></li>
    </ul>
    <h2><?=$this->lang->line('rules_78')?></h2>
    <ul>
        <li>
            <?=$this->lang->line('rules_79')?><br /><br />
            <strong><em><u><?=$this->lang->line('rules_80')?></u></em></strong>
        </li>
        <li><?=$this->lang->line('rules_81')?></li>
        <li><?=$this->lang->line('rules_82')?></li>
        <li><?=$this->lang->line('rules_83')?></li>
    </ul>
    <p>&nbsp;</p>
</div>
</div>
</div>	