<div id="researchLibrary" class="dynamic">
    <h3 class="header"><?=$this->lang->line('library')?></h3>
    <div class="content">
        <img src="<?=$this->config->item('style_url')?>skin/research/img_library.jpg" width="203" height="85">
        <p><?=$this->lang->line('library_info')?></p>
        <div class="centerButton">
            <a href="<?=$this->config->item('base_url')?>game/researchOverview/" class="button"><?=$this->lang->line('to_library')?></a>
        </div>
    </div>
    <div class="footer"></div>
</div>