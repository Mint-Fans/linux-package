<div class="dynamic" id="viewMilitaryImperium">
    <h3 class="header"><?=$this->lang->line('military_review')?></h3>
    <div class="content">
        <img src="<?=$this->config->item('style_url')?>skin/premium/sideAd_premiumMilitaryAdvisor.jpg" width="203" height="85" />
        <p><?=$this->lang->line('military_review_text1')?></p>
        <div class="centerButton">
            <a href="<?=$this->config->item('base_url')?>game/premiumDetails/" class="button"><?=$this->lang->line('look_now')?></a>
        </div>
    </div>
    <div class="footer"></div>
</div>