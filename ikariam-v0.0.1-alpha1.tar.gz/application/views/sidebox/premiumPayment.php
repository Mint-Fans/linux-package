<div id="backTo" class="dynamic">
    <h3 class="header"><?=$this->lang->line('back')?></h3>
    <div class="content">
        <a href="<?=$this->config->item('base_url')?>game/premium" title="<?=$this->lang->line('back_to')?> <?=$this->lang->line('ikariam_plus')?>">
            <span class="textLabel">&lt;&lt; <?=$this->lang->line('back_to')?> <?=$this->lang->line('ikariam_plus')?></span>
        </a>
        </div>
    <div class="footer"></div>
</div>