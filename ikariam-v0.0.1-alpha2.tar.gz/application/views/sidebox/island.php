<div id="infocontainer" class="dynamic">
    <h3 class="header"><?php echo $this->lang->line('info');?></h3>
    <div id="information" class="content">
        <div class="accesshint"><?php echo $this->lang->line('info_text');?></div>
    </div>
    <div class="footer"></div>
</div>
<div id="actioncontainer" class="dynamic">
    <h3 class="header"><?php echo $this->lang->line('actions');?></h3>
    <div id="actions" class="content">
        <div class="accesshint"><?php echo $this->lang->line('info_text');?></div>
    </div>
    <div class="footer"></div>
</div>
