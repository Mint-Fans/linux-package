<div id="civilopedia_menu" class="dynamic" style="margin-bottom:10px;">
    <h3 class="header">Икипедия</h3>
    <div class="main">
        <ul>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_1_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/1/"><?=$this->lang->line('information_1_title')?></a>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_5_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/5/"><?=$this->lang->line('information_5_title')?></a>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_12_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/12/"><?=$this->lang->line('information_12_title')?></a>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_13_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/13/"><?=$this->lang->line('information_13_title')?></a>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_14_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/14/"><?=$this->lang->line('information_14_title')?></a>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_15_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/15/"><?=$this->lang->line('information_15_title')?></a>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_16_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/16/"><?=$this->lang->line('information_16_title')?></a>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_17_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/17/"><?=$this->lang->line('information_17_title')?></a>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_18_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/18/"><?=$this->lang->line('information_18_title')?></a>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_27_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/27/"><?=$this->lang->line('information_27_title')?></a>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_35_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/35/"><?=$this->lang->line('information_35_title')?></a>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_36_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/36/"><?=$this->lang->line('information_36_title')?></a>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_41_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/41/"><?=$this->lang->line('information_41_title')?></a>
            </li>
                    <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('researches')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/"><?=$this->lang->line('researches')?></a>

            <ul>
            <li><strong><?=$this->lang->line('way1_name')?>:</strong></li>
            <ul>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research1_1_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/1/1/"><?=$this->lang->line('research1_1_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research1_2_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/1/2/"><?=$this->lang->line('research1_2_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research1_3_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/1/3/"><?=$this->lang->line('research1_3_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research1_4_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/1/4/"><?=$this->lang->line('research1_4_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research1_5_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/1/5/"><?=$this->lang->line('research1_5_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research1_6_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/1/6/"><?=$this->lang->line('research1_6_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research1_7_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/1/7/"><?=$this->lang->line('research1_7_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research1_8_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/1/8/"><?=$this->lang->line('research1_8_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research1_9_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/1/9/"><?=$this->lang->line('research1_9_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research1_10_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/1/10/"><?=$this->lang->line('research1_10_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research1_11_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/1/11/"><?=$this->lang->line('research1_11_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research1_12_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/1/12/"><?=$this->lang->line('research1_12_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research1_13_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/1/13/"><?=$this->lang->line('research1_13_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research1_14_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/1/14/"><?=$this->lang->line('research1_14_name')?></a></li>
            </ul>
            <li><strong><?=$this->lang->line('way2_name')?>:</strong></li>
            <ul>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research2_1_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/2/1/"><?=$this->lang->line('research2_1_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research2_2_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/2/2/"><?=$this->lang->line('research2_2_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research2_3_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/2/3/"><?=$this->lang->line('research2_3_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research2_4_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/2/4/"><?=$this->lang->line('research2_4_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research2_5_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/2/5/"><?=$this->lang->line('research2_5_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research2_6_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/2/6/"><?=$this->lang->line('research2_6_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research2_7_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/2/7/"><?=$this->lang->line('research2_7_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research2_8_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/2/8/"><?=$this->lang->line('research2_8_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research2_9_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/2/9/"><?=$this->lang->line('research2_9_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research2_10_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/2/10/"><?=$this->lang->line('research2_10_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research2_11_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/2/11/"><?=$this->lang->line('research2_11_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research2_12_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/2/12/"><?=$this->lang->line('research2_12_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research2_13_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/2/13/"><?=$this->lang->line('research2_13_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research2_14_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/2/14/"><?=$this->lang->line('research2_14_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research2_15_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/2/15/"><?=$this->lang->line('research2_15_name')?></a></li>
            </ul>
            <li><strong><?=$this->lang->line('way3_name')?>:</strong></li>
            <ul>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research3_1_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/3/1/"><?=$this->lang->line('research3_1_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research3_2_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/3/2/"><?=$this->lang->line('research3_2_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research3_3_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/3/3/"><?=$this->lang->line('research3_3_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research3_4_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/3/4/"><?=$this->lang->line('research3_4_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research3_5_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/3/5/"><?=$this->lang->line('research3_5_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research3_6_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/3/6/"><?=$this->lang->line('research3_6_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research3_7_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/3/7/"><?=$this->lang->line('research3_7_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research3_8_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/3/8/"><?=$this->lang->line('research3_8_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research3_9_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/3/9/"><?=$this->lang->line('research3_9_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research3_10_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/3/10/"><?=$this->lang->line('research3_10_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research3_11_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/3/11/"><?=$this->lang->line('research3_11_name')?>а</a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research3_12_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/3/12/"><?=$this->lang->line('research3_12_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research3_13_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/3/13/"><?=$this->lang->line('research3_13_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research3_14_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/3/14/"><?=$this->lang->line('research3_14_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research3_15_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/3/15/"><?=$this->lang->line('research3_15_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research3_16_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/3/16/"><?=$this->lang->line('research3_16_name')?></a></li>
            </ul>
            <li><strong><?=$this->lang->line('way4_name')?>:</strong></li>
            <ul>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research4_1_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/4/1/"><?=$this->lang->line('research4_1_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research4_2_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/4/2/"><?=$this->lang->line('research4_2_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research4_3_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/4/3/"><?=$this->lang->line('research4_3_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research4_4_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/4/4/"><?=$this->lang->line('research4_4_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research4_5_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/4/5/"><?=$this->lang->line('research4_5_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research4_6_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/4/6/"><?=$this->lang->line('research4_6_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research4_7_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/4/7/"><?=$this->lang->line('research4_7_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research4_8_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/4/8/"><?=$this->lang->line('research4_8_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research4_9_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/4/9/"><?=$this->lang->line('research4_9_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research4_10_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/4/10/"><?=$this->lang->line('research4_10_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research4_11_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/4/11/"><?=$this->lang->line('research4_11_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research4_12_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/4/12/"><?=$this->lang->line('research4_12_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research4_13_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/4/13/"><?=$this->lang->line('research4_13_name')?></a></li>
                        <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('research4_14_name')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/4/14/"><?=$this->lang->line('research4_14_name')?></a></li>
            </ul>
            </ul>
                    </li>

                    <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('units')?>..." href="<?=$this->config->item('base_url')?>game/unitDescription/"><?=$this->lang->line('units')?></a></li>
                    <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('ships')?>..." href="<?=$this->config->item('base_url')?>game/shipDescription/"><?=$this->lang->line('ships')?></a></li>
                    <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('buildings')?>..." href="<?=$this->config->item('base_url')?>game/buildingDetail/"><?=$this->lang->line('buildings')?></a></li>

            <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('wonders')?>..." href="<?=$this->config->item('base_url')?>game/wonderDetail/"><?=$this->lang->line('wonders')?></a></li>

        </ul>
    </div>
    <div class="footer"></div>
</div>