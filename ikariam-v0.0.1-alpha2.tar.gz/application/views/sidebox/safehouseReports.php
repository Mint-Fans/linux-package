<div id="backTo" class="dynamic">
    <h3 class="header"><?=$this->lang->line('building14_name')?></h3>
    <div class="content">
        <a href="<?=$this->config->item('base_url')?>game/safehouse/reports/" title="<?=$this->lang->line('back_to')?> <?=$this->lang->line('building14_name')?>">
            <img src="<?=$this->config->item('style_url')?>skin/buildings/y100/safehouse.gif" width="160" height="100">
            <span class="textLabel">&lt;&lt; <?=$this->lang->line('back_to')?> <?=$this->lang->line('building14_name')?></span>
        </a>
    </div>
    <div class="footer"></div>
</div>