<div id="mainview">
    <div class="buildingDescription">
        <h1>Agorà</h1>
    </div>
    <div class="contentBoxMessage">    
        <!-- TODO: if there aren't message show this:-->
		<p class="warning">Su questa agorà non ci sono ancora messaggi. Creando un nuovo messaggio potrai metterti in contatto con i vicini della tua città.</p>        <a class="button" href="?view=islandBoard&id=622&show=1">Nuovo messaggio</a><br/><br/>
        <br/>
        <!-- else show this-->
    
            <a class="button" href="?view=islandBoard&id=622&show=1">Nuovo messaggio</a><br/><br/>
    		<div class="contentBox01h">    
            <h3 class="header"><span class="textLabel">idro ha scritto il 15.06.2013 14:45:45</span></h3>
            <div class="content"><p><b>inattivi</b></p><p>Tutti inattivi siete? </p></div>
            <div class="footer"></div>
        </div>
		
        <br/>
        <div class="pageBrowser"><a href='?view=islandBoard&id=622&page=0'>
	        <img src='<?php echo base_url('design/skin/img/resource/btn_min.png');?>'></a> 
			<span class="currentPage">1</span> <a href='?view=islandBoard&id=622&page=0'>
			<img src='<?php echo base_url('design/skin/img/resource/btn_max.png');?>'></a></div>
      </div>
</div>


