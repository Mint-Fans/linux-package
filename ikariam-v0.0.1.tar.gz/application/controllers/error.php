<?php
error_reporting(0);
class Error extends Game{

    function error_404()
    {
        $this->error();
    }

}