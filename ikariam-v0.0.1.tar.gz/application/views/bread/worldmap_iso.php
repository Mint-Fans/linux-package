<div id="breadcrumbs">
    <h3><?=$this->lang->line('you_here')?>:</h3>
    <span id="worldBread" class="world"><?=$this->lang->line('world')?> > </span>
    <div id="islandBread" class="island"></div>
</div> 