<div id="backTo" class="dynamic">
	<h3 class="header"><?=$this->lang->line('building12_name')?></h3>
	<div class="content">
		<a href="<?=$this->config->item('base_url')?>game/branchOffice/" title="<?=$this->lang->line('back')?>">
      <img src="<?=$this->config->item('style_url')?>skin/buildings/y100/branchOffice.gif" />
			<span class="textLabel"><?=$this->lang->line('back')?></span>
    </a>
	</div>
	<div class="footer"></div>
</div>
