<?php

$lang['scaff_view_records']		= 'Просмотр записей';
$lang['scaff_create_record']	= 'Создать новую запись';
$lang['scaff_add']				= 'Добавить данные';
$lang['scaff_view']				= 'Просмотр данных';
$lang['scaff_edit']				= 'Редактирование';
$lang['scaff_delete']			= 'Удаление';
$lang['scaff_view_all']			= 'Все';
$lang['scaff_yes']				= 'Да';
$lang['scaff_no']				= 'Нет';
$lang['scaff_no_data']			= 'В этой таблице нет данных.';
$lang['scaff_del_confirm']		= 'Вы уверены, что хотите удалить эту запись:';
