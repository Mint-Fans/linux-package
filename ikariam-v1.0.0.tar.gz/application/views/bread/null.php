<div id="breadcrumbs">
    <h3><?=$this->lang->line('you_here')?>:</h3>
	<span class="textLabel"><?=$caption?></span>
</div> 