<div id="civilopedia_menu" class="dynamic" style="margin-bottom:10px;">
    <h3 class="header"><?=$this->lang->line('ikapedia')?></h3>
    <div class="main">
        <ul>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_1_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/1/"><?=$this->lang->line('information_1_title')?></a>
<?if($id >=1 and $id <= 4){?>
                <ul>
                    <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_2_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/2/"><?=$this->lang->line('information_2_title')?></a></li>
                    <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_3_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/3/"><?=$this->lang->line('information_3_title')?></a></li>
                    <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_4_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/4/"><?=$this->lang->line('information_4_title')?></a></li>
                </ul>
<?}?>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_5_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/5/"><?=$this->lang->line('information_5_title')?></a>
<?if($id >= 5 and $id <= 11){?>
                <ul>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_6_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/6/"><?=$this->lang->line('information_6_title')?></a></li>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_7_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/7/"><?=$this->lang->line('information_7_title')?></a></li>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_8_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/8/"><?=$this->lang->line('information_8_title')?></a></li>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_9_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/9/"><?=$this->lang->line('information_9_title')?></a></li>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_10_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/10/"><?=$this->lang->line('information_10_title')?></a></li>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_11_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/11/"><?=$this->lang->line('information_11_title')?></a></li>
                </ul>
<?}?>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_12_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/12/"><?=$this->lang->line('information_12_title')?></a>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_13_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/13/"><?=$this->lang->line('information_13_title')?></a>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_14_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/14/"><?=$this->lang->line('information_14_title')?></a>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_15_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/15/"><?=$this->lang->line('information_15_title')?></a>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_16_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/16/"><?=$this->lang->line('information_16_title')?></a>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_27_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/27/"><?=$this->lang->line('information_27_title')?></a>
<?if($id >= 27 and $id <= 34){?>
                    <ul>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_28_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/28/"><?=$this->lang->line('information_28_title')?></a></li>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_29_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/29/"><?=$this->lang->line('information_29_title')?></a></li>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_30_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/30/"><?=$this->lang->line('information_30_title')?></a></li>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_31_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/31/"><?=$this->lang->line('information_31_title')?></a></li>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_32_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/32/"><?=$this->lang->line('information_32_title')?></a></li>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_33_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/33/"><?=$this->lang->line('information_33_title')?></a></li>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_34_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/34/"><?=$this->lang->line('information_34_title')?></a></li>
                    </ul>
<?}?>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_35_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/35/"><?=$this->lang->line('information_35_title')?></a>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_36_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/36/"><?=$this->lang->line('information_36_title')?></a>
<?if($id >= 36 and $id <= 40){?>
                    <ul>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_37_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/37/"><?=$this->lang->line('information_37_title')?></a></li>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_38_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/38/"><?=$this->lang->line('information_38_title')?></a></li>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_39_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/39/"><?=$this->lang->line('information_39_title')?></a></li>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_40_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/40/"><?=$this->lang->line('information_40_title')?></a></li>
                    </ul>
<?}?>
            </li>
            <li>
                <a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_41_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/41/"><?=$this->lang->line('information_41_title')?></a>
<?if($id >= 41 and $id <= 44){?>
                    <ul>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_42_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/42/"><?=$this->lang->line('information_42_title')?></a></li>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_43_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/43/"><?=$this->lang->line('information_43_title')?></a></li>
                      <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('information_44_title')?>..." href="<?=$this->config->item('base_url')?>game/informations/44/"><?=$this->lang->line('information_44_title')?></a></li>
                    </ul>
<?}?>
            </li>
                    <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('researches')?>..." href="<?=$this->config->item('base_url')?>game/researchDetail/"><?=$this->lang->line('researches')?></a></li>
                    <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('units')?>..." href="<?=$this->config->item('base_url')?>game/unitDescription/"><?=$this->lang->line('units')?></a></li>
                    <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('ships')?>..." href="<?=$this->config->item('base_url')?>game/shipDescription/"><?=$this->lang->line('ships')?></a></li>
                    <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('buildings')?>..." href="<?=$this->config->item('base_url')?>game/buildingDetail/"><?=$this->lang->line('buildings')?></a></li>

            <li><a title="<?=$this->lang->line('learn_more')?> <?=$this->lang->line('wonders')?>..." href="<?=$this->config->item('base_url')?>game/wonderDetail/"><?=$this->lang->line('wonders')?></a></li>



        </ul>
    </div>
    <div class="footer"></div>
</div>