<div id="backTo" class="dynamic">
    <h3 class="header"><?=$this->lang->line('merchant_navy')?></h3>
    <div class="content">
        <a href="<?=$this->config->item('base_url')?>game/city/" title="<?=$this->lang->line('back_town')?>">
        <img src="<?=$this->config->item('style_url')?>skin/img/action_back.gif" width="160" height="100" />
        <span class="textLabel"><?=$this->lang->line('back_town')?></span></a>
    </div>
    <div class="footer"></div>
</div>
<div id="backTo" class="dynamic">
	<h3 class="header"><?=$this->lang->line('back_island')?></h3>
	<div class="content">
        <div class="centerButton">
    		<a class="button" href="<?=$this->config->item('base_url')?>game/island/" title="<?=$this->lang->line('back_island')?>">
    			<span class="textLabel"><?=$this->lang->line('back_island')?></span>
            </a>
        </div>
	</div>
	<div class="footer"></div>
</div>