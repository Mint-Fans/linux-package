<div id="information" class="dynamic"></div>
<div id="mainview">
    <div class="buildingDescription">
        <h1></h1>
    </div>
    <br><br><br><br><br>
</div>