<div id="mainview">
    <div class="buildingDescription">
        <h1>Амброзия</h1>
        <p>За амброзию Вы можете приобрести услуги ПЛЮС. Нажмите на предпочитаемый Вами метод оплаты и выберите интересующий Вас пакет амброзии.</p>
    </div>

<form id=pay name=pay method="POST" action="https://merchant.webmoney.ru/lmi/payment.asp">

<center>
	<input type="hidden" name="LMI_PAYMENT_AMOUNT" value="1.0">
	<input type="hidden" name="LMI_PAYMENT_DESC" value="Покупка Амброзии">
	<input type="hidden" name="LMI_PAYMENT_NO" value="1">
	<input type="hidden" name="LMI_PAYEE_PURSE" value="R121862190369">
	<input type="hidden" name="LMI_SIM_MODE" value="0">
<p><b>Стоимость одной еденицы амброзии = 1 WMR!</b></p>

<div class="centerButton">
    <input type="submit" value="Купить"  class="button">
</div>

</center>
</form>
    
</div>