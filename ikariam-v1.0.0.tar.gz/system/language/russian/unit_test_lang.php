<?php

$lang['ut_test_name']		= 'Имя теста';
$lang['ut_test_datatype']	= 'Тестируемый тип даных ';
$lang['ut_res_datatype']	= 'Ожидаемый тип данных';
$lang['ut_result']			= 'Результат';
$lang['ut_undefined']		= 'Имя теста неопределено';
$lang['ut_file']			= 'Имя файла';
$lang['ut_line']			= 'Номер строки';
$lang['ut_passed']			= 'Пройден';
$lang['ut_failed']			= 'Не пройден';
// не уверен, что стоит вообще переводить типы данных
$lang['ut_boolean']			= 'булево';
$lang['ut_integer']			= 'целое';
$lang['ut_float']			= 'с плавающей точкой';
$lang['ut_double']			= 'с плавающей точкой'; // can be the same as float
$lang['ut_string']			= 'строка';
$lang['ut_array']			= 'массив';
$lang['ut_object']			= 'объект';
$lang['ut_resource']		= 'ресурс';
$lang['ut_null']			= 'null';
