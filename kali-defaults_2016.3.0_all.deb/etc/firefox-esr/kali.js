/* Kali default settings */
pref("browser.startup.homepage", "data:text/plain,browser.startup.homepage=file:///usr/share/kali-defaults/web/homepage.html");
pref("browser.showPersonalToolbar", true);
