# unpack boot image
mkdir -p boot/ramdisk
./unpackbootimg -i boot.img -o boot
cd boot
gzip -d boot.img-ramdisk.gz
cd ramdisk
cpio -i -F ../boot.img-ramdisk
rm ../boot.img-ramdisk

BOARD_KERNEL_CMDLINE bootopt=64S3,32S1,32S1 buildvariant=user
BOARD_KERNEL_BASE 40000000
BOARD_NAME 
BOARD_PAGE_SIZE 2048
BOARD_HASH_TYPE sha1
BOARD_KERNEL_OFFSET 00008000
BOARD_RAMDISK_OFFSET 05000000
BOARD_SECOND_OFFSET 00f00000
BOARD_TAGS_OFFSET 04000000
BOARD_OS_VERSION 8.1.0
BOARD_OS_PATCH_LEVEL 2018-08

# Rebuild boot image
rm boot.img
cd boot/ramdisk
find . | cpio -o -H newc | gzip > ../ramdisk.cpio.gz
cd ../..
./mkbootimg --pagesize 2048 \
--base 0x40000000 \
--kernel_offset 0x00008000 \
--ramdisk_offset 0x05000000 \
--second_offset 0x00f00000 \
--tags_offset 0x04000000 \
--os_version 8.1.0 \
--os_patch_level 2019-08 \
--cmdline "bootopt=64S3,32S1,32S1 buildvariant=user" \
--kernel boot/boot.img-zImage \
--ramdisk boot/ramdisk.cpio.gz \
-o boot_fix.img

# magiskboot unpack
mkdir boot
cd boot
../magiskboot unpack ../boot.img


