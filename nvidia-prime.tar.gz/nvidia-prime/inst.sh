sudo install -D -m755 sbin/prime-offload /sbin/prime-offload
sudo install -D -m755 usr/bin/prime-select /usr/bin/prime-select
sudo cp -a etc/prime /etc/

sudo prime-select nvidia

