## for Laptop Optimus
sudo sh -c 'echo xrandr --output \$monitor --gamma 0.75:0.71:0.67 >> /sbin/prime-offload'