sudo prime-select intel

sudo rm -rf /sbin/prime-offload
sudo rm -rf /usr/bin/prime-select
sudo rm -rf /etc/prime
sudo rm -rf /etc/modprobe.d/blacklist-nvidia.conf
sudo rm -rf /etc/ld.so.conf.d/nvidia-glx.conf
sudo ldconfig
