#!/bin/bash

############################################
### NVIDIA Driver 384.x Install
############################################
## Depends:
# Debian:
# sudo apt-get install dkms gcc make patch linux-headers-amd64
# sudo dpkg --add-architecture i386
# sudo apt-get update
# sudo apt-get install libglx-mesa0:i386 | libgl1-mesa-glx:i386
# Archlinux:
# sudo pacman -S dkms gcc make patch linux-headers
# sudo pacman -S lib32-mesa
# Fedora:
# sudo dnf install dkms gcc make patch kernel-devel
# sudo dnf install mesa-libGL.i686
# openSuSE:
# sudo zypper install dkms gcc make patch kernel-default-devel
# sudo zypper install Mesa-libGL1-32bit

# Debian Paths
XMOD_PATH=/usr/lib/xorg/modules
NV_XMOD_PATH=/usr/lib/nvidia
LIB64_PATH=/usr/lib/x86_64-linux-gnu
LIB32_PATH=/usr/lib/i386-linux-gnu
LIB_PATH=/usr/lib

# Fedora / openSuSE Paths
# XMOD_PATH=/usr/lib64/xorg/modules
# NV_XMOD_PATH=/usr/lib64/nvidia
# LIB64_PATH=/usr/lib64
# LIB32_PATH=/usr/lib
# LIB_PATH=/usr/lib

# Archlinux Paths
# XMOD_PATH=/usr/lib/xorg/modules
# NV_XMOD_PATH=/usr/lib/nvidia
# LIB64_PATH=/usr/lib
# LIB32_PATH=/usr/lib32
# LIB_PATH=/usr/lib


NV_NAME=NVIDIA-Linux-x86_64
NV_VER='384.111'

# wget -c http://us.download.nvidia.com/XFree86/Linux-x86_64/$NV_VER/"$NV_NAME"-"$NV_VER".run
# sh ${NV_NAME}-${NV_VER}.run -x
# cd ${NV_NAME}-${NV_VER}

# X WFB
sudo install -D -m755 libnvidia-wfb.so.${NV_VER} ${NV_XMOD_PATH}/libnvidia-wfb.so.${NV_VER}
sudo ln -sf libnvidia-wfb.so.${NV_VER} ${NV_XMOD_PATH}/libnvidia-wfb.so.1

# X Driver
sudo install -D -m755 nvidia_drv.so ${XMOD_PATH}/drivers/nvidia_drv.so
sudo ln -sf ../xorg/modules/drivers/nvidia_drv.so ${NV_XMOD_PATH}/nvidia_drv.so

# GLX extension module
sudo install -D -m755 libglx.so.${NV_VER} ${NV_XMOD_PATH}/libglx.so.$NV_VER
sudo ln -sf libglx.so.$NV_VER ${NV_XMOD_PATH}/libglx.so

# NVIDIA VDPAU 64-bit Library
sudo install -D -m755 libvdpau_nvidia.so.${NV_VER} $LIB64_PATH/vdpau/libvdpau_nvidia.so.${NV_VER}
sudo ln -sf libvdpau_nvidia.so.${NV_VER} $LIB64_PATH/vdpau/libvdpau_nvidia.so.1
sudo ln -sf vdpau/libvdpau_nvidia.so.${NV_VER} $LIB64_PATH/libvdpau_nvidia.so

# NVIDIA CUDA 64-bit Library
sudo install -D -m755 libcuda.so.${NV_VER} $LIB64_PATH/libcuda.so.${NV_VER}
sudo ln -sf libcuda.so.${NV_VER} $LIB64_PATH/libcuda.so.1
sudo ln -sf libcuda.so.1 $LIB64_PATH/libcuda.so
sudo install -D -m755 libnvcuvid.so.${NV_VER} $LIB64_PATH/libnvcuvid.so.${NV_VER}
sudo ln -sf libnvcuvid.so.${NV_VER} $LIB64_PATH/libnvcuvid.so.1
sudo ln -sf libnvcuvid.so.1 $LIB64_PATH/libnvcuvid.so

# NVIDIA 64-bit Library
sudo install -D -m755 libnvidia-cfg.so.${NV_VER} $LIB64_PATH/libnvidia-cfg.so.${NV_VER}
sudo ln -sf libnvidia-cfg.so.${NV_VER} $LIB64_PATH/libnvidia-cfg.so.1
sudo ln -sf libnvidia-cfg.so.1 $LIB64_PATH/libnvidia-cfg.so
sudo install -D -m755 libnvidia-fbc.so.${NV_VER} $LIB64_PATH/libnvidia-fbc.so.${NV_VER}
sudo ln -sf libnvidia-fbc.so.${NV_VER} $LIB64_PATH/libnvidia-fbc.so.1
sudo ln -sf libnvidia-fbc.so.1 $LIB64_PATH/libnvidia-fbc.so
sudo install -D -m755 libnvidia-gtk2.so.${NV_VER} $LIB64_PATH/libnvidia-gtk2.so.${NV_VER}
sudo install -D -m755 libnvidia-gtk3.so.${NV_VER} $LIB64_PATH/libnvidia-gtk3.so.${NV_VER}
sudo install -D -m755 libnvidia-compiler.so.${NV_VER} $LIB64_PATH/libnvidia-compiler.so.${NV_VER}
sudo install -D -m755 libnvidia-encode.so.${NV_VER} $LIB64_PATH/libnvidia-encode.so.${NV_VER}
sudo ln -sf libnvidia-encode.so.${NV_VER} $LIB64_PATH/libnvidia-encode.so.1
sudo ln -sf libnvidia-encode.so.1 $LIB64_PATH/libnvidia-encode.so
sudo install -D -m755 libnvidia-fatbinaryloader.so.${NV_VER} $LIB64_PATH/libnvidia-fatbinaryloader
sudo install -D -m755 libnvidia-ifr.so.${NV_VER} $LIB64_PATH/libnvidia-ifr.so.${NV_VER}
sudo ln -sf libnvidia-ifr.so.${NV_VER} $LIB64_PATH/libnvidia-ifr.so.1
sudo ln -sf libnvidia-ifr.so.1 $LIB64_PATH/libnvidia-ifr.so
sudo install -D -m755 libnvidia-ml.so.${NV_VER} $LIB64_PATH/libnvidia-ml.so.${NV_VER}
sudo ln -sf libnvidia-ml.so.${NV_VER} $LIB64_PATH/libnvidia-ml.so.1
sudo ln -sf libnvidia-ml.so.1 $LIB64_PATH/libnvidia-ml.so
sudo install -D -m755 libnvidia-ptxjitcompiler.so.${NV_VER} $LIB64_PATH/libnvidia-ptxjitcompiler.so.${NV_VER}
sudo ln -sf libnvidia-ptxjitcompiler.so.${NV_VER} $LIB64_PATH/libnvidia-ptxjitcompiler.so.1
sudo ln -sf libnvidia-ptxjitcompiler.so.1 $LIB64_PATH/libnvidia-ptxjitcompiler.so

### -----
# ocl-icd OpenCL 64-bit Library
# sudo install -D -m755 libOpenCL.so.1.0.0 $LIB64_PATH/nvidia/libOpenCL.so.1.0.0
# sudo ln -sf libOpenCL.so.1.0.0 $LIB64_PATH/nvidia/libOpenCL.so.1.0
# sudo ln -sf libOpenCL.so.1.0 $LIB64_PATH/nvidia/libOpenCL.so.1
# sudo ln -sf libOpenCL.so.1 $LIB64_PATH/nvidia/libOpenCL.so

# Glvnd 64-bit Library
# sudo install -D -m755 libEGL.so.1 $LIB64_PATH/nvidia/libEGL.so.1
# sudo ln -sf libEGL.so.1 $LIB64_PATH/nvidia/libEGL.so
# sudo install -D -m755 libGLdispatch.so.0 $LIB64_PATH/nvidia/libGLdispatch.so.0
# sudo install -D -m755 libGLESv1_CM.so.1 $LIB64_PATH/nvidia/libGLESv1_CM.so.1
# sudo ln -sf libGLESv1_CM.so.1 $LIB64_PATH/nvidia/libGLESv1_CM.so
# sudo install -D -m755 libGLESv2.so.2 $LIB64_PATH/nvidia/libGLESv2.so.2
# sudo ln -sf libGLESv2.so.2 $LIB64_PATH/nvidia/libGLESv2.so
# sudo install -D -m755 libGL.so.1.0.0 $LIB64_PATH/nvidia/libGL.so.1.0.0
# sudo ln -sf libGL.so.1.0.0 $LIB64_PATH/nvidia/libGL.so.1
# sudo ln -sf libGL.so.1 $LIB64_PATH/nvidia/libGL.so
# sudo install -D -m755 libOpenGL.so.0 $LIB64_PATH/nvidia/libOpenGL.so.0
# sudo ln -sf libOpenGL.so.0 $LIB64_PATH/nvidia/libOpenGL.so
# sudo install -D -m755 libGLX.so.0 $LIB64_PATH/nvidia/libGLX.so.0
# sudo ln -sf libGLX.so.0 $LIB64_PATH/nvidia/libGLX.so

# NVIDIA OpenCL 64-bit Library
sudo install -D -m755 libnvidia-opencl.so.${NV_VER} $LIB64_PATH/libnvidia-opencl.so.${NV_VER}
sudo ln -sf libnvidia-opencl.so.${NV_VER} $LIB64_PATH/libnvidia-opencl.so.1

# NVIDIA OpenGL 64-bit Library
sudo install -D -m755 libnvidia-eglcore.so.${NV_VER} $LIB64_PATH/libnvidia-eglcore.so.${NV_VER}
sudo install -D -m755 libnvidia-egl-wayland.so.1.0.1 $LIB64_PATH/libnvidia-egl-wayland.so.1.0.1
sudo install -D -m755 libnvidia-glcore.so.${NV_VER} $LIB64_PATH/libnvidia-glcore.so.${NV_VER}
sudo install -D -m755 libnvidia-glsi.so.${NV_VER} $LIB64_PATH/libnvidia-glsi.so.${NV_VER}
sudo install -D -m755 libnvidia-tls.so.${NV_VER} $LIB64_PATH/libnvidia-tls.so.${NV_VER}
sudo install -D -m755 tls/libnvidia-tls.so.${NV_VER} $LIB64_PATH/tls/libnvidia-tls.so.${NV_VER}

# NVIDIA Glvnd 64-bit Library
sudo install -D -m755 libEGL_nvidia.so.${NV_VER} $LIB64_PATH/nvidia/libEGL_nvidia.so.${NV_VER}
sudo ln -sf libEGL_nvidia.so.${NV_VER} $LIB64_PATH/nvidia/libEGL_nvidia.so.0
sudo install -D -m755 libEGL.so.${NV_VER} $LIB64_PATH/nvidia/libEGL.so.${NV_VER}
sudo ln -sf libEGL.so.${NV_VER} $LIB64_PATH/nvidia/libEGL.so.1
sudo ln -sf libEGL.so.1 $LIB64_PATH/nvidia/libEGL.so
sudo install -D -m755 libGLESv1_CM_nvidia.so.${NV_VER} $LIB64_PATH/nvidia/libGLESv1_CM_nvidia.so.${NV_VER}
sudo ln -sf libGLESv1_CM_nvidia.so.${NV_VER} $LIB64_PATH/nvidia/libGLESv1_CM_nvidia.so.1
sudo install -D -m755 libGLESv2_nvidia.so.${NV_VER} $LIB64_PATH/nvidia/libGLESv2_nvidia.so.${NV_VER}
sudo ln -sf libGLESv2_nvidia.so.${NV_VER} $LIB64_PATH/nvidia/libGLESv2_nvidia.so.2
sudo install -D -m755 libGL.so.${NV_VER} $LIB64_PATH/nvidia/libGL.so.${NV_VER}
sudo ln -sf libGL.so.${NV_VER} $LIB64_PATH/nvidia/libGL.so.1
sudo ln -sf libGL.so.1 $LIB64_PATH/nvidia/libGL.so

# NVIDIA GLX 64-bit Library
sudo install -D -m755 libGLX_nvidia.so.${NV_VER} $LIB64_PATH/nvidia/libGLX_nvidia.so.${NV_VER}
sudo ln -sf libGLX_nvidia.so.${NV_VER} $LIB64_PATH/nvidia/libGLX_nvidia.so.0
sudo ln -sf libGLX_nvidia.so.0 $LIB64_PATH/nvidia/libGLX_indirect.so.0

# NVIDIA VDPAU 32-bit Library
sudo install -D -m755 32/libvdpau_nvidia.so.${NV_VER} $LIB32_PATH/vdpau/libvdpau_nvidia.so.${NV_VER}
sudo ln -sf libvdpau_nvidia.so.${NV_VER} $LIB32_PATH/vdpau/libvdpau_nvidia.so.1
sudo ln -sf vdpau/libvdpau_nvidia.so.${NV_VER} $LIB32_PATH/libvdpau_nvidia.so

# NVIDIA CUDA 32-bit Library
sudo install -D -m755 32/libcuda.so.${NV_VER} $LIB32_PATH/libcuda.so.${NV_VER}
sudo ln -sf libcuda.so.${NV_VER} $LIB32_PATH/libcuda.so.1
sudo ln -sf libcuda.so.1 $LIB32_PATH/libcuda.so
sudo install -D -m755 32/libnvcuvid.so.${NV_VER} $LIB32_PATH/libnvcuvid.so.${NV_VER}
sudo ln -sf libnvcuvid.so.${NV_VER} $LIB32_PATH/libnvcuvid.so.1
sudo ln -sf libnvcuvid.so.1 $LIB32_PATH/libnvcuvid.so

# NVIDIA 32-bit Library
sudo install -D -m755 32/libnvidia-fbc.so.${NV_VER} $LIB32_PATH/libnvidia-fbc.so.${NV_VER}
sudo ln -sf libnvidia-fbc.so.${NV_VER} $LIB32_PATH/libnvidia-fbc.so.1
sudo ln -sf libnvidia-fbc.so.1 $LIB32_PATH/libnvidia-fbc.so
sudo install -D -m755 32/libnvidia-compiler.so.${NV_VER} $LIB32_PATH/libnvidia-compiler.so.${NV_VER}
sudo install -D -m755 32/libnvidia-encode.so.${NV_VER} $LIB32_PATH/libnvidia-encode.so.${NV_VER}
sudo ln -sf libnvidia-encode.so.${NV_VER} $LIB32_PATH/libnvidia-encode.so.1
sudo ln -sf libnvidia-encode.so.1 $LIB32_PATH/libnvidia-encode.so
sudo install -D -m755 32/libnvidia-fatbinaryloader.so.${NV_VER} $LIB32_PATH/libnvidia-fatbinaryloader.so.${NV_VER}
sudo install -D -m755 32/libnvidia-ifr.so.${NV_VER} $LIB32_PATH/libnvidia-ifr.so.${NV_VER}
sudo ln -sf libnvidia-ifr.so.${NV_VER} $LIB32_PATH/libnvidia-ifr.so.1
sudo ln -sf libnvidia-ifr.so.1 $LIB32_PATH/libnvidia-ifr.so
sudo install -D -m755 32/libnvidia-ml.so.${NV_VER} $LIB32_PATH/libnvidia-ml.so.${NV_VER}
sudo ln -sf libnvidia-ml.so.${NV_VER} $LIB32_PATH/libnvidia-ml.so.1
sudo ln -sf libnvidia-ml.so.1 $LIB32_PATH/libnvidia-ml.so
sudo install -D -m755 32/libnvidia-ptxjitcompiler.so.${NV_VER} $LIB32_PATH/libnvidia-ptxjitcompiler.so.${NV_VER}
sudo ln -sf libnvidia-ptxjitcompiler.so.${NV_VER} $LIB32_PATH/libnvidia-ptxjitcompiler.so.1
sudo ln -sf libnvidia-ptxjitcompiler.so.1 $LIB32_PATH/libnvidia-ptxjitcompiler.so


### -----
# ocl-icd OpenCL 32-bit Library
# sudo install -D -m755 32/libOpenCL.so.1.0.0 $LIB32_PATH/nvidia/libOpenCL.so.1.0.0
# sudo ln -sf libOpenCL.so.1.0.0 $LIB32_PATH/nvidia/libOpenCL.so.1.0
# sudo ln -sf libOpenCL.so.1.0 $LIB32_PATH/nvidia/libOpenCL.so.1
# sudo ln -sf libOpenCL.so.1 $LIB32_PATH/nvidia/libOpenCL.so

# Glvnd 32-bit Library
# sudo install -D -m755 32/libEGL.so.1 $LIB32_PATH/nvidia/libEGL.so.1
# sudo ln -sf libEGL.so.1 $LIB32_PATH/nvidia/libEGL.so
# sudo install -D -m755 32/libGLdispatch.so.0 $LIB32_PATH/nvidia/libGLdispatch.so.0
# sudo install -D -m755 32/libGLESv1_CM.so.1 $LIB32_PATH/nvidia/libGLESv1_CM.so.1
# sudo ln -sf libGLESv1_CM.so.1 $LIB32_PATH/nvidia/libGLESv1_CM.so
# sudo install -D -m755 32/libGLESv2.so.2 $LIB32_PATH/nvidia/libGLESv2.so.2
# sudo ln -sf libGLESv2.so.2 $LIB32_PATH/nvidia/libGLESv2.so
# sudo install -D -m755 32/libGL.so.1.0.0 $LIB32_PATH/nvidia/libGL.so.1.0.0
# sudo ln -sf libGL.so.1.0.0 $LIB32_PATH/nvidia/libGL.so.1
# sudo ln -sf libGL.so.1 $LIB32_PATH/nvidia/libGL.so
# sudo install -D -m755 32/libGLX.so.0 $LIB32_PATH/nvidia/libGLX.so.0
# sudo ln -sf libGLX.so.0 $LIB32_PATH/nvidia/libGLX.so
# sudo install -D -m755 32/libOpenGL.so.0 $LIB32_PATH/nvidia/libOpenGL.so.0
# sudo ln -sf libOpenGL.so.0 $LIB32_PATH/nvidia/libOpenGL.so
# sudo install -D -m755 32/libGL.la $LIB32_PATH/nvidia/libGL.la


# NVIDIA OpenCL 32-bit Library
sudo install -D -m755 32/libnvidia-opencl.so.${NV_VER} $LIB32_PATH/libnvidia-opencl.so.${NV_VER}
sudo ln -sf libnvidia-opencl.so.${NV_VER} $LIB32_PATH/libnvidia-opencl.so.1

# NVIDIA OpenGL 32-bit Library
sudo install -D -m755 32/libnvidia-eglcore.so.${NV_VER} $LIB32_PATH/libnvidia-eglcore.so.${NV_VER}
sudo install -D -m755 32/libnvidia-glcore.so.${NV_VER} $LIB32_PATH/libnvidia-glcore.so.${NV_VER}
sudo install -D -m755 32/libnvidia-glsi.so.${NV_VER} $LIB32_PATH/libnvidia-glsi.so.${NV_VER}
sudo install -D -m755 32/libnvidia-tls.so.${NV_VER} $LIB32_PATH/libnvidia-tls.so.${NV_VER}
sudo install -D -m755 32/tls/libnvidia-tls.so.${NV_VER} $LIB32_PATH/tls/libnvidia-tls.so.${NV_VER}

# NVIDIA Glvnd 32-bit Library
sudo install -D -m755 32/libEGL_nvidia.so.${NV_VER} $LIB32_PATH/nvidia/libEGL_nvidia.so.${NV_VER}
sudo ln -sf libEGL_nvidia.so.${NV_VER} $LIB32_PATH/nvidia/libEGL_nvidia.so.0
sudo install -D -m755 32/libEGL.so.${NV_VER} $LIB32_PATH/nvidia/libEGL.so.${NV_VER}
sudo ln -sf libEGL.so.${NV_VER} $LIB32_PATH/nvidia/libEGL.so.1
sudo ln -sf libEGL.so.1 $LIB32_PATH/nvidia/libEGL.so
sudo install -D -m755 32/libGLESv1_CM_nvidia.so.${NV_VER} $LIB32_PATH/nvidia/libGLESv1_CM_nvidia.so.${NV_VER}
sudo ln -sf libGLESv1_CM_nvidia.so.${NV_VER} $LIB32_PATH/nvidia/libGLESv1_CM_nvidia.so.1
sudo install -D -m755 32/libGLESv2_nvidia.so.${NV_VER} $LIB32_PATH/nvidia/libGLESv2_nvidia.so.${NV_VER}
sudo ln -sf libGLESv2_nvidia.so.${NV_VER} $LIB32_PATH/nvidia/libGLESv2_nvidia.so.2
sudo install -D -m755 32/libGL.so.${NV_VER} $LIB32_PATH/nvidia/libGL.so.${NV_VER}
sudo ln -sf libGL.so.${NV_VER} $LIB32_PATH/nvidia/libGL.so.1
sudo ln -sf libGL.so.1 $LIB32_PATH/nvidia/libGL.so

# NVIDIA GLX 32-bit Library
sudo install -D -m755 32/libGLX_nvidia.so.${NV_VER} $LIB32_PATH/nvidia/libGLX_nvidia.so.${NV_VER}
sudo ln -sf libGLX_nvidia.so.${NV_VER} $LIB32_PATH/nvidia/libGLX_nvidia.so.0
sudo ln -sf libGLX_nvidia.so.0 $LIB32_PATH/nvidia/libGLX_indirect.so.0

sudo /sbin/ldconfig

## Config for EGL
cat nvidia_icd.json.template | sed /api_version/d | sed 's/__NV_VK_ICD__/libEGL_mesa.so.0/g' > 50_mesa.json
# Using Mesa Glvnd EGL
# sudo install -D -m644 50_mesa.json /usr/share/glvnd/egl_vendor.d/50_mesa.json
# Using NVIDIA Glvnd EGL
sudo install -D -m644 10_nvidia.json /usr/share/glvnd/egl_vendor.d/10_nvidia.json

# Config EGL external platform library
sudo install -D -m644 10_nvidia_wayland.json /usr/share/egl/egl_external_platform.d/10_nvidia_wayland.json

## Config for OpenCL
# Using Mesa OpenCL
# sudo mkdir -p /etc/OpenCL/vendors
# sudo sh -c "echo libMesaOpenCL.so.1 > /etc/OpenCL/vendors/mesa.icd"
# Using NVIDIA OpenCL
sudo mkdir -p /etc/OpenCL/vendors
sudo sh -c "echo libnvidia-opencl.so.1 > /etc/OpenCL/vendors/nvidia.icd"

# application profiles
sudo install -D -m644 nvidia-application-profiles-"$NV_VER"-key-documentation /usr/share/nvidia/nvidia-application-profiles-"$NV_VER"-key-documentation
sudo install -D -m644 nvidia-application-profiles-"$NV_VER"-rc /usr/share/nvidia/nvidia-application-profiles-"$NV_VER"-rc
sudo install -D -m644 nvidia-drm-outputclass.conf /usr/share/X11/xorg.conf.d/nvidia-drm-outputclass.conf

sed -e 's:__UTILS_PATH__:/usr/bin:' -e 's:__PIXMAP_PATH__:/usr/share/pixmaps:' -i nvidia-settings.desktop
sudo install -D -m644 nvidia-settings.desktop /usr/share/applications/nvidia-settings.desktop
sudo install -D -m644 nvidia-settings.png /usr/share/pixmaps/nvidia-settings.png

sudo install -D -m755 nvidia-bug-report.sh /usr/bin/nvidia-bug-report.sh
sudo install -D -m755 nvidia-cuda-mps-control /usr/bin/nvidia-cuda-mps-control
sudo install -D -m644 nvidia-cuda-mps-control.1.gz /usr/share/man/man1/nvidia-cuda-mps-control.1.gz
sudo install -D -m755 nvidia-cuda-mps-server /usr/bin/nvidia-cuda-mps-server
sudo install -D -m755 nvidia-debugdump /usr/bin/nvidia-debugdump
sudo install -D -m755 nvidia-modprobe /usr/bin/nvidia-modprobe
sudo install -D -m644 nvidia-modprobe.1.gz /usr/share/man/man1/nvidia-modprobe.1.gz
sudo install -D -m755 nvidia-persistenced /usr/bin/nvidia-persistenced
sudo install -D -m644 nvidia-persistenced.1.gz /usr/share/man/man1/nvidia-persistenced.1.gz
sudo install -D -m755 nvidia-settings /usr/bin/nvidia-settings
sudo install -D -m644 nvidia-settings.1.gz /usr/share/man/man1/nvidia-settings.1.gz
sudo install -D -m755 nvidia-smi /usr/bin/nvidia-smi
sudo install -D -m644 nvidia-smi.1.gz /usr/share/man/man1/nvidia-smi.1.gz
sudo install -D -m755 nvidia-xconfig /usr/bin/nvidia-xconfig
sudo install -D -m644 nvidia-xconfig.1.gz /usr/share/man/man1/nvidia-xconfig.1.gz

# docs
sudo install -D -m644 nvidia-persistenced-init.tar.bz2 /usr/share/doc/NVIDIA/sample/nvidia-persistenced-init.tar.bz2
sudo install -D -m644 LICENSE /usr/share/doc/NVIDIA/LICENSE
sudo install -D -m644 README.txt /usr/share/doc/NVIDIA/README.txt
sudo install -D -m644 NVIDIA_Changelog /usr/share/doc/NVIDIA/NVIDIA_Changelog
sudo cp -a html /usr/share/doc/NVIDIA/

# GL Include
# sudo install -D -m644 glext.h /usr/include/GL/glext.h
# sudo install -D -m644 gl.h /usr/include/GL/gl.h
# sudo install -D -m644 glxext.h /usr/include/GL/glxext.h
# sudo install -D -m644 glx.h /usr/include/GL/glx.h

## Install nVidia Kernel modules
cat > kernel/dkms.conf << EOF
PACKAGE_NAME="nvidia"
PACKAGE_VERSION=$NV_VER
AUTOINSTALL=yes

MAKE[0]="unset ARCH; IGNORE_CC_MISMATCH=1 env NV_VERBOSE=1 make \${parallel_jobs+-j\$parallel_jobs} modules KERNEL_UNAME=\${kernelver}"
CLEAN="make KERNEL_UNAME=\${kernelver} clean"

BUILT_MODULE_NAME[0]=nvidia
DEST_MODULE_LOCATION[0]="/kernel/drivers/video"
BUILT_MODULE_NAME[1]="nvidia-modeset"
DEST_MODULE_LOCATION[1]="/kernel/drivers/video"
BUILT_MODULE_NAME[2]="nvidia-drm"
DEST_MODULE_LOCATION[2]="/kernel/drivers/video"
BUILT_MODULE_NAME[3]="nvidia-uvm"
DEST_MODULE_LOCATION[3]="/kernel/drivers/video"
EOF

sudo cp -r kernel /usr/src/nvidia-"$NV_VER"
# sudo sh -c 'echo "blacklist nouveau" > /etc/modprobe.d/50-blacklist.conf'

sudo dkms install -m nvidia -v $NV_VER -k $(uname -r)

# Debian:
sudo update-initramfs -u
# fedora / openSuse:
# sudo dracut -f -v
# archlinux:
# sudo mkinitcpio -p linux

## clean
# cd ..
# sudo rm -rf "$NV_NAME"-"$NV_VER".run
# sudo rm -rf "$NV_NAME"-"$NV_VER"
