#!/bin/bash
############################################
### NVIDIA Driver 304.x Install
############################################
# Debian Paths
XMOD_PATH=/usr/lib/xorg/modules
NV_XMOD_PATH=/usr/lib/nvidia/xorg
LIB64_PATH=/usr/lib/x86_64-linux-gnu
LIB32_PATH=/usr/lib/i386-linux-gnu
LIB_PATH=/usr/lib

NV_NAME=NVIDIA-Linux-x86_64
NV_VER='304.137'

# wget -c http://us.download.nvidia.com/XFree86/Linux-x86_64/$NV_VER/"$NV_NAME"-"$NV_VER".run
# sh ${NV_NAME}-${NV_VER}.run -x
# cd ${NV_NAME}-${NV_VER}

# X WFB
sudo install -D -m755 libnvidia-wfb.so.${NV_VER} ${NV_XMOD_PATH}/libnvidia-wfb.so.${NV_VER}
# sudo ln -sf libnvidia-wfb.so.${NV_VER} ${NV_XMOD_PATH}/libnvidia-wfb.so.1

# X Driver
sudo install -D -m755 nvidia_drv.so ${XMOD_PATH}/drivers/nvidia_drv.so
sudo ln -sf ../../xorg/modules/drivers/nvidia_drv.so ${NV_XMOD_PATH}/nvidia_drv.so

# GLX extension module
sudo install -D -m755 libglx.so.${NV_VER} ${NV_XMOD_PATH}/libglx.so.$NV_VER
sudo ln -sf libglx.so.$NV_VER ${NV_XMOD_PATH}/libglx.so

# X Lib
sudo install -D -m755 libXvMCNVIDIA.so.${NV_VER} $LIB64_PATH/libXvMCNVIDIA.so.${NV_VER}
sudo ln -sf libXvMCNVIDIA.so.${NV_VER} $LIB64_PATH/libXvMCNVIDIA.so.1
sudo ln -sf libXvMCNVIDIA.so.${NV_VER} $LIB64_PATH/libXvMCNVIDIA_dynamic.so.1
sudo ln -sf libXvMCNVIDIA_dynamic.so.1 $LIB64_PATH/libXvMCNVIDIA_dynamic.so
sudo install -D -m444 libXvMCNVIDIA.a $LIB64_PATH/libXvMCNVIDIA.a

# NVIDIA CUDA 64-bit Library
sudo install -D -m755 libcuda.so.${NV_VER} $LIB64_PATH/libcuda.so.${NV_VER}
sudo ln -sf libcuda.so.${NV_VER} $LIB64_PATH/libcuda.so.1
sudo ln -sf libcuda.so.1 $LIB64_PATH/libcuda.so
sudo install -D -m755 libnvcuvid.so.${NV_VER} $LIB64_PATH/libnvcuvid.so.${NV_VER}
sudo ln -sf libnvcuvid.so.${NV_VER} $LIB64_PATH/libnvcuvid.so.1
sudo ln -sf libnvcuvid.so.1 $LIB64_PATH/libnvcuvid.so

# NVIDIA VDPAU 64-bit Library
sudo install -D -m755 libvdpau_nvidia.so.${NV_VER} $LIB64_PATH/vdpau/libvdpau_nvidia.so.${NV_VER}
sudo ln -sf libvdpau_nvidia.so.${NV_VER} $LIB64_PATH/vdpau/libvdpau_nvidia.so.1
sudo ln -sf vdpau/libvdpau_nvidia.so.${NV_VER} $LIB64_PATH/libvdpau_nvidia.so

# NVIDIA 64-bit Library
sudo install -D -m755 libnvidia-cfg.so.${NV_VER} $LIB64_PATH/libnvidia-cfg.so.${NV_VER}
sudo ln -sf libnvidia-cfg.so.${NV_VER} $LIB64_PATH/libnvidia-cfg.so.1
sudo ln -sf libnvidia-cfg.so.1 $LIB64_PATH/libnvidia-cfg.so
sudo install -D -m755 libnvidia-compiler.so.${NV_VER} $LIB64_PATH/libnvidia-compiler.so.${NV_VER}
sudo install -D -m755 libnvidia-ml.so.${NV_VER} $LIB64_PATH/libnvidia-ml.so.${NV_VER}
sudo ln -sf libnvidia-ml.so.${NV_VER} $LIB64_PATH/libnvidia-ml.so.1
sudo ln -sf libnvidia-ml.so.1 $LIB64_PATH/libnvidia-ml.so

# ocl-icd OpenCL 64-bit Library
# sudo install -D -m755 libOpenCL.so.1.0.0 $LIB64_PATH/nvidia/ocl-icd/libOpenCL.so.1.0.0
# sudo ln -sf libOpenCL.so.1.0.0 $LIB64_PATH/nvidia/ocl-icd/libOpenCL.so.1.0
# sudo ln -sf libOpenCL.so.1.0 $LIB64_PATH/nvidia/ocl-icd/libOpenCL.so.1
# sudo ln -sf libOpenCL.so.1 $LIB64_PATH/nvidia/ocl-icd/libOpenCL.so

# NVIDIA OpenCL 64-bit Library
sudo install -D -m755 libnvidia-opencl.so.${NV_VER} $LIB64_PATH/libnvidia-opencl.so.${NV_VER}
sudo ln -sf libnvidia-opencl.so.${NV_VER} $LIB64_PATH/libnvidia-opencl.so.1

# NVIDIA Glvnd 64-bit Library
sudo install -D -m755 libGL.so.${NV_VER} $LIB64_PATH/nvidia/libGL.so.${NV_VER}
sudo ln -sf libGL.so.${NV_VER} $LIB64_PATH/nvidia/libGL.so.1
sudo ln -sf libGL.so.1 $LIB64_PATH/nvidia/libGL.so
sudo install -D -m644 libGL.la $LIB64_PATH/nvidia/libGL.la

# NVIDIA OpenGL 64-bit Library
sudo install -D -m755 libnvidia-glcore.so.${NV_VER} $LIB64_PATH/libnvidia-glcore.so.${NV_VER}
sudo install -D -m755 libnvidia-tls.so.${NV_VER} $LIB64_PATH/libnvidia-tls.so.${NV_VER}
sudo install -D -m755 tls/libnvidia-tls.so.${NV_VER} $LIB64_PATH/tls/libnvidia-tls.so.${NV_VER}


# NVIDIA VDPAU 32-bit Library
sudo install -D -m755 32/libvdpau_nvidia.so.${NV_VER} $LIB32_PATH/vdpau/libvdpau_nvidia.so.${NV_VER}
sudo ln -sf libvdpau_nvidia.so.${NV_VER} $LIB32_PATH/vdpau/libvdpau_nvidia.so.1
sudo ln -sf vdpau/libvdpau_nvidia.so.${NV_VER} $LIB32_PATH/libvdpau_nvidia.so

# NVIDIA CUDA 32-bit Library
sudo install -D -m755 32/libcuda.so.${NV_VER} $LIB32_PATH/libcuda.so.${NV_VER}
sudo ln -sf libcuda.so.${NV_VER} $LIB32_PATH/libcuda.so.1
sudo ln -sf libcuda.so.1 $LIB32_PATH/libcuda.so

# NVIDIA 32-bit Library
sudo install -D -m755 32/libnvidia-compiler.so.${NV_VER} $LIB32_PATH/libnvidia-compiler.so.${NV_VER}
sudo install -D -m755 32/libnvidia-ml.so.${NV_VER} $LIB32_PATH/libnvidia-ml.so.${NV_VER}
sudo ln -sf libnvidia-ml.so.${NV_VER} $LIB32_PATH/libnvidia-ml.so.1
sudo ln -sf libnvidia-ml.so.1 $LIB32_PATH/libnvidia-ml.so

# ocl-icd OpenCL 32-bit Library
# sudo install -D -m755 32/libOpenCL.so.1.0.0 $LIB32_PATH/nvidia/ocl-icd/libOpenCL.so.1.0.0
# sudo ln -sf libOpenCL.so.1.0.0 $LIB32_PATH/nvidia/ocl-icd/libOpenCL.so.1.0
# sudo ln -sf libOpenCL.so.1.0 $LIB32_PATH/nvidia/ocl-icd/libOpenCL.so.1
# sudo ln -sf libOpenCL.so.1 $LIB32_PATH/nvidia/ocl-icd/libOpenCL.so

# NVIDIA OpenCL 32-bit Library
sudo install -D -m755 32/libnvidia-opencl.so.${NV_VER} $LIB32_PATH/libnvidia-opencl.so.${NV_VER}
sudo ln -sf libnvidia-opencl.so.${NV_VER} $LIB32_PATH/libnvidia-opencl.so.1

# NVIDIA OpenGL 32-bit Library
sudo install -D -m755 32/libnvidia-glcore.so.${NV_VER} $LIB32_PATH/libnvidia-glcore.so.${NV_VER}
sudo install -D -m755 32/libnvidia-tls.so.${NV_VER} $LIB32_PATH/libnvidia-tls.so.${NV_VER}
sudo install -D -m755 32/tls/libnvidia-tls.so.${NV_VER} $LIB32_PATH/tls/libnvidia-tls.so.${NV_VER}

# NVIDIA Glvnd 32-bit Library
sudo install -D -m755 32/libGL.so.${NV_VER} $LIB32_PATH/nvidia/libGL.so.${NV_VER}
sudo ln -sf libGL.so.${NV_VER} $LIB32_PATH/nvidia/libGL.so.1
sudo ln -sf libGL.so.1 $LIB32_PATH/nvidia/libGL.so
sudo install -D -m644 32/libGL.la $LIB32_PATH/nvidia/libGL.la

sudo /sbin/ldconfig

## Config for OpenCL
# Using Mesa OpenCL
# echo libMesaOpenCL.so.1 > mesa.icd"
# sudo install -D -m644 mesa.icd /etc/OpenCL/vendors/mesa.icd
# Using NVIDIA OpenCL
sudo install -D -m644 nvidia.icd /etc/OpenCL/vendors/nvidia.icd

# application profiles
sudo install -D -m644 nvidia-drm-outputclass.conf /usr/share/X11/xorg.conf.d/nvidia-drm-outputclass.conf

sed -e 's:__UTILS_PATH__:/usr/bin:' -e 's:__PIXMAP_PATH__:/usr/share/pixmaps:' -i nvidia-settings.desktop
sudo install -D -m644 nvidia-settings.desktop /usr/share/applications/nvidia-settings.desktop
sudo install -D -m644 nvidia-settings.png /usr/share/pixmaps/nvidia-settings.png

sudo install -D -m755 nvidia-bug-report.sh /usr/bin/nvidia-bug-report.sh
sudo install -D -m755 nvidia-cuda-proxy-control /usr/bin/nvidia-cuda-proxy-control
sudo install -D -m644 nvidia-cuda-proxy-control.1.gz /usr/share/man/man1/nvidia-cuda-proxy-control.1.gz
sudo install -D -m755 nvidia-cuda-proxy-server /usr/bin/nvidia-cuda-proxy-server
sudo install -D -m755 nvidia-debugdump /usr/bin/nvidia-debugdump
sudo install -D -m755 nvidia-settings /usr/bin/nvidia-settings
sudo install -D -m644 nvidia-settings.1.gz /usr/share/man/man1/nvidia-settings.1.gz
sudo install -D -m755 nvidia-smi /usr/bin/nvidia-smi
sudo install -D -m644 nvidia-smi.1.gz /usr/share/man/man1/nvidia-smi.1.gz
sudo install -D -m755 nvidia-xconfig /usr/bin/nvidia-xconfig
sudo install -D -m644 nvidia-xconfig.1.gz /usr/share/man/man1/nvidia-xconfig.1.gz

# docs
sudo install -D -m644 LICENSE /usr/share/doc/NVIDIA/LICENSE
sudo install -D -m644 README.txt /usr/share/doc/NVIDIA/README.txt
sudo install -D -m644 NVIDIA_Changelog /usr/share/doc/NVIDIA/NVIDIA_Changelog
sudo cp -a html /usr/share/doc/NVIDIA/

# GL Include
sudo install -D -m644 glext.h /usr/include/GL/glext.h
sudo install -D -m644 gl.h /usr/include/GL/gl.h
sudo install -D -m644 glxext.h /usr/include/GL/glxext.h
sudo install -D -m644 glx.h /usr/include/GL/glx.h

## Install nVidia Kernel modules
cat > kernel/dkms.conf << EOF
# DKMS
PACKAGE_NAME="nvidia"
PACKAGE_VERSION="$NV_VER"
BUILT_MODULE_NAME[0]=nvidia
DEST_MODULE_LOCATION[0]="/kernel/drivers/video"
MAKE[0]="unset ARCH; IGNORE_CC_MISMATCH=1 env NV_VERBOSE=1 make \${parallel_jobs+-j\$parallel_jobs} module KERNEL_UNAME=\${kernelver}"
CLEAN="make KERNEL_UNAME=\${kernelver} clean"
AUTOINSTALL="yes"
EOF

# patch for linux 4.3 - 4.15
wget https://github.com/Mint-Fans/linux-package/raw/NVIDIA/nvidia-304-patches.tar.gz
tar zxvf nvidia-304-patches.tar.gz
cd kernel
patch -Np1 -i ../patches/disable-mtrr.patch
patch -Np1 -i ../patches/pud-offset.patch
patch -Np1 -i ../patches/nvidia-drm-pci-init.patch
patch -Np1 -i ../patches/timer.patch
cd ..

sudo cp -r kernel /usr/src/nvidia-"$NV_VER"

sudo sh -c 'echo "blacklist nouveau" > /etc/modprobe.d/nvidia-blacklists-nouveau.conf'

sudo dkms install -m nvidia -v $NV_VER -k $(uname -r)

wget https://raw.githubusercontent.com/Mint-Fans/linux-package/NVIDIA/update-glx-304
sudo install -D -m755 update-glx-304 ${NV_XMOD_PATH}/update-glx

# Debian
sudo sed -i 's/^LIB64=.*/LIB64=\/usr\/lib\/x86_64-linux-gnu/g' ${NV_XMOD_PATH}/update-glx
sudo sed -i 's/^LIB32=.*/LIB32=\/usr\/lib\/i386-linux-gnu/g' ${NV_XMOD_PATH}/update-glx
sudo sed -i 's/^XMOD_PATH=.*/XMOD_PATH=\/usr\/lib\/xorg\/modules/g' ${NV_XMOD_PATH}/update-glx
sudo sed -i 's/^NV_XMOD_PATH=.*/NV_XMOD_PATH=\/usr\/lib\/nvidia\/xorg/g' ${NV_XMOD_PATH}/update-glx

# Fedora / openSuSE
sudo sed -i 's/^LIB64=.*/LIB64=\/usr\/lib64/g' ${NV_XMOD_PATH}/update-glx
sudo sed -i 's/^LIB32=.*/LIB32=\/usr\/lib/g' ${NV_XMOD_PATH}/update-glx
sudo sed -i 's/^XMOD_PATH=.*/XMOD_PATH=\/usr\/lib64\/xorg\/modules/g' ${NV_XMOD_PATH}/update-glx
sudo sed -i 's/^NV_XMOD_PATH=.*/NV_XMOD_PATH=\/usr\/lib64\/nvidia\/xorg/g' ${NV_XMOD_PATH}/update-glx

# ArchLinux
sudo sed -i 's/^LIB64=.*/LIB64=\/usr\/lib/g' ${NV_XMOD_PATH}/update-glx
sudo sed -i 's/^LIB32=.*/LIB32=\/usr\/lib32/g' ${NV_XMOD_PATH}/update-glx
sudo sed -i 's/^XMOD_PATH=.*/XMOD_PATH=\/usr\/lib\/xorg\/modules/g' ${NV_XMOD_PATH}/update-glx
sudo sed -i 's/^NV_XMOD_PATH=.*/NV_XMOD_PATH=\/usr\/lib\/nvidia\/xorg/g' ${NV_XMOD_PATH}/update-glx


sudo ${NV_XMOD_PATH}/update-glx install


# Debian:
sudo update-initramfs -u
# fedora / openSuse:
# sudo dracut -f -v
# archlinux:
# sudo mkinitcpio -p linux

## clean
# cd ..
# sudo rm -rf "$NV_NAME"-"$NV_VER".run
# sudo rm -rf "$NV_NAME"-"$NV_VER"
