#!/bin/bash
############################################
### NVIDIA Driver 340.x Remove
############################################
# Debian Paths
XMOD_PATH=/usr/lib/xorg/modules
NV_XMOD_PATH=/usr/lib/nvidia/xorg
LIB64_PATH=/usr/lib/x86_64-linux-gnu
LIB32_PATH=/usr/lib/i386-linux-gnu
LIB_PATH=/usr/lib

NV_VER=$(sudo modinfo nvidia | grep ^version | awk '{print $2}')

sudo ${NV_XMOD_PATH}/update-glx remove

# X Driver
sudo rm -rf ${XMOD_PATH}/drivers/nvidia_drv.so
sudo rm -rf ${NV_XMOD_PATH}/nvidia_drv.so

# GLX extension module
sudo rm -rf ${NV_XMOD_PATH}/libglx.so.$NV_VER
sudo rm -rf ${NV_XMOD_PATH}/libglx.so

# X WFB
sudo rm -rf ${NV_XMOD_PATH}/libnvidia-wfb.so.${NV_VER}
sudo rm -rf ${NV_XMOD_PATH}/libnvidia-wfb.so.1

# NVIDIA CUDA 64-bit Library
sudo rm -rf $LIB64_PATH/libcuda.so.${NV_VER}
sudo rm -rf $LIB64_PATH/libcuda.so.1
sudo rm -rf $LIB64_PATH/libcuda.so
sudo rm -rf $LIB64_PATH/libnvcuvid.so.${NV_VER}
sudo rm -rf $LIB64_PATH/libnvcuvid.so.1
sudo rm -rf $LIB64_PATH/libnvcuvid.so

# NVIDIA VDPAU 64-bit Library
sudo rm -rf $LIB64_PATH/vdpau/libvdpau_nvidia.so.${NV_VER}
sudo rm -rf $LIB64_PATH/vdpau/libvdpau_nvidia.so.1
sudo rm -rf $LIB64_PATH/libvdpau_nvidia.so

# NVIDIA 64-bit Library
sudo rm -rf $LIB64_PATH/libnvidia-cfg.so.${NV_VER}
sudo rm -rf $LIB64_PATH/libnvidia-cfg.so.1
sudo rm -rf $LIB64_PATH/libnvidia-cfg.so
sudo rm -rf $LIB64_PATH/libnvidia-compiler.so.${NV_VER}
sudo rm -rf $LIB64_PATH/libnvidia-encode.so.${NV_VER}
sudo rm -rf $LIB64_PATH/libnvidia-encode.so.1
sudo rm -rf $LIB64_PATH/libnvidia-encode.so
sudo rm -rf $LIB64_PATH/libnvidia-fbc.so.${NV_VER}
sudo rm -rf $LIB64_PATH/libnvidia-fbc.so.1
sudo rm -rf $LIB64_PATH/libnvidia-fbc.so
sudo rm -rf $LIB64_PATH/libnvidia-ifr.so.${NV_VER}
sudo rm -rf $LIB64_PATH/libnvidia-ifr.so.1
sudo rm -rf $LIB64_PATH/libnvidia-ifr.so
sudo rm -rf $LIB64_PATH/libnvidia-ml.so.${NV_VER}
sudo rm -rf $LIB64_PATH/libnvidia-ml.so.1
sudo rm -rf $LIB64_PATH/libnvidia-ml.so

# ocl-icd OpenCL 64-bit Library
sudo rm -rf $LIB64_PATH/nvidia/libOpenCL.so.1.0.0
sudo rm -rf $LIB64_PATH/nvidia/libOpenCL.so.1.0
sudo rm -rf $LIB64_PATH/nvidia/libOpenCL.so.1
sudo rm -rf $LIB64_PATH/nvidia/libOpenCL.so

# NVIDIA OpenCL 64-bit Library
sudo rm -rf $LIB64_PATH/libnvidia-opencl.so.${NV_VER}
sudo rm -rf $LIB64_PATH/libnvidia-opencl.so.1

# NVIDIA Glvnd 64-bit Library
sudo rm -rf $LIB64_PATH/nvidia/libEGL.so.${NV_VER}
sudo rm -rf $LIB64_PATH/nvidia/libEGL.so.1
sudo rm -rf $LIB64_PATH/nvidia/libEGL.so
sudo rm -rf $LIB64_PATH/nvidia/libGLESv1_CM.so.${NV_VER}
sudo rm -rf $LIB64_PATH/nvidia/libGLESv1_CM.so.1
sudo rm -rf $LIB64_PATH/nvidia/libGLESv1_CM.so
sudo rm -rf $LIB64_PATH/nvidia/libGLESv2.so.${NV_VER}
sudo rm -rf $LIB64_PATH/nvidia/libGLESv2.so.2
sudo rm -rf $LIB64_PATH/nvidia/libGLESv2.so
sudo rm -rf $LIB64_PATH/nvidia/libGL.so.${NV_VER}
sudo rm -rf $LIB64_PATH/nvidia/libGL.so.1
sudo rm -rf $LIB64_PATH/nvidia/libGL.so
sudo rm -rf $LIB64_PATH/nvidia/libGL.la

# NVIDIA OpenGL 64-bit Library
sudo rm -rf $LIB64_PATH/libnvidia-eglcore.so.${NV_VER}
sudo rm -rf $LIB64_PATH/libnvidia-glcore.so.${NV_VER}
sudo rm -rf $LIB64_PATH/libnvidia-glsi.so.${NV_VER}
sudo rm -rf $LIB64_PATH/libnvidia-tls.so.${NV_VER}
sudo rm -rf $LIB64_PATH/tls/libnvidia-tls.so.${NV_VER}



# NVIDIA VDPAU 32-bit Library
sudo rm -rf $LIB32_PATH/vdpau/libvdpau_nvidia.so.${NV_VER}
sudo rm -rf $LIB32_PATH/vdpau/libvdpau_nvidia.so.1
sudo rm -rf $LIB32_PATH/libvdpau_nvidia.so

# NVIDIA CUDA 32-bit Library
sudo rm -rf $LIB32_PATH/libcuda.so.${NV_VER}
sudo rm -rf $LIB32_PATH/libcuda.so.1
sudo rm -rf $LIB32_PATH/libcuda.so
sudo rm -rf $LIB32_PATH/libnvcuvid.so.${NV_VER}
sudo rm -rf $LIB32_PATH/libnvcuvid.so.1
sudo rm -rf $LIB32_PATH/libnvcuvid.so

# NVIDIA 32-bit Library
sudo rm -rf $LIB32_PATH/libnvidia-compiler.so.${NV_VER}
sudo rm -rf $LIB32_PATH/libnvidia-encode.so.${NV_VER}
sudo rm -rf $LIB32_PATH/libnvidia-encode.so.1
sudo rm -rf $LIB32_PATH/libnvidia-encode.so
sudo rm -rf $LIB32_PATH/libnvidia-fbc.so.${NV_VER}
sudo rm -rf $LIB32_PATH/libnvidia-fbc.so.1
sudo rm -rf $LIB32_PATH/libnvidia-fbc.so
sudo rm -rf $LIB32_PATH/libnvidia-ifr.so.${NV_VER}
sudo rm -rf $LIB32_PATH/libnvidia-ifr.so.1
sudo rm -rf $LIB32_PATH/libnvidia-ifr.so
sudo rm -rf $LIB32_PATH/libnvidia-ml.so.${NV_VER}
sudo rm -rf $LIB32_PATH/libnvidia-ml.so.1
sudo rm -rf $LIB32_PATH/libnvidia-ml.so

# ocl-icd OpenCL 32-bit Library
sudo rm -rf $LIB32_PATH/nvidia/libOpenCL.so.1.0.0
sudo rm -rf $LIB32_PATH/nvidia/libOpenCL.so.1.0
sudo rm -rf $LIB32_PATH/nvidia/libOpenCL.so.1
sudo rm -rf $LIB32_PATH/nvidia/libOpenCL.so

# NVIDIA OpenCL 32-bit Library
sudo rm -rf $LIB32_PATH/libnvidia-opencl.so.${NV_VER}
sudo rm -rf $LIB32_PATH/libnvidia-opencl.so.1

# NVIDIA OpenGL 32-bit Library
sudo rm -rf $LIB32_PATH/libnvidia-eglcore.so.${NV_VER}
sudo rm -rf $LIB32_PATH/libnvidia-glcore.so.${NV_VER}
sudo rm -rf $LIB32_PATH/libnvidia-glsi.so.${NV_VER}
sudo rm -rf $LIB32_PATH/libnvidia-tls.so.${NV_VER}
sudo rm -rf $LIB32_PATH/tls/libnvidia-tls.so.${NV_VER}

# NVIDIA Glvnd 32-bit Library
sudo rm -rf $LIB32_PATH/nvidia/libEGL.so.${NV_VER}
sudo rm -rf $LIB32_PATH/nvidia/libEGL.so.1
sudo rm -rf $LIB32_PATH/nvidia/libEGL.so
sudo rm -rf $LIB32_PATH/nvidia/libGLESv1_CM.so.${NV_VER}
sudo rm -rf $LIB32_PATH/nvidia/libGLESv1_CM.so.1
sudo rm -rf $LIB32_PATH/nvidia/libGLESv1_CM.so
sudo rm -rf $LIB32_PATH/nvidia/libGLESv2.so.${NV_VER}
sudo rm -rf $LIB32_PATH/nvidia/libGLESv2.so.2
sudo rm -rf $LIB32_PATH/nvidia/libGLESv2.so
sudo rm -rf $LIB32_PATH/nvidia/libGL.so.${NV_VER}
sudo rm -rf $LIB32_PATH/nvidia/libGL.so.1
sudo rm -rf $LIB32_PATH/nvidia/libGL.so
sudo rm -rf $LIB32_PATH/nvidia/libGL.la

sudo rm -rf $LIB64_PATH/nvidia
sudo rm -rf $LIB32_PATH/nvidia
sudo rm -rf $LIB_PATH/nvidia
sudo rm -rf $LIB64_PATH/tls
sudo rm -rf $LIB32_PATH/tls

# profiles
sudo rm -rf /etc/OpenCL
sudo rm -rf /usr/share/nvidia

# application
sudo rm -rf /usr/share/applications/nvidia-settings.desktop
sudo rm -rf /usr/share/pixmaps/nvidia-settings.png

sudo rm -rf /usr/bin/nvidia-bug-report.sh
sudo rm -rf /usr/bin/nvidia-cuda-mps-control
sudo rm -rf /usr/share/man/man1/nvidia-cuda-mps-control.1.gz
sudo rm -rf /usr/bin/nvidia-cuda-mps-server
sudo rm -rf /usr/bin/nvidia-debugdump
sudo rm -rf /usr/bin/nvidia-modprobe
sudo rm -rf /usr/share/man/man1/nvidia-modprobe.1.gz
sudo rm -rf /usr/bin/nvidia-persistenced
sudo rm -rf /usr/share/man/man1/nvidia-persistenced.1.gz
sudo rm -rf /usr/bin/nvidia-settings
sudo rm -rf /usr/share/man/man1/nvidia-settings.1.gz
sudo rm -rf /usr/bin/nvidia-smi
sudo rm -rf /usr/share/man/man1/nvidia-smi.1.gz
sudo rm -rf /usr/bin/nvidia-xconfig
sudo rm -rf /usr/share/man/man1/nvidia-xconfig.1.gz

# docs
sudo rm -rf /usr/share/doc/NVIDIA

# GL Include
# sudo rm -rf /usr/include/GL/glext.h
# sudo rm -rf /usr/include/GL/gl.h
# sudo rm -rf /usr/include/GL/glxext.h
# sudo rm -rf /usr/include/GL/glx.h

## Remove nVidia Kernel modules
sudo /sbin/rmmod nvidia >/dev/null 2>&1
sudo dkms remove -m nvidia -v "$NV_VER" --all
sudo rm -rf /usr/src/nvidia-$NV_VER
sudo rm -rf /lib/modules/"$(uname -r)"/kernel/drivers/video/nvidia.ko
sudo rm -rf /lib/modules/"$(uname -r)"/kernel/drivers/video/nvidia-uvm.ko

## config
sudo /sbin/ldconfig
sudo rm -rf /etc/modprobe.d/nvidia-blacklists-nouveau.conf

sudo depmod
# sudo update-initramfs -u
