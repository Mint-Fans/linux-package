sudo nvidia-settings
