sudo optirun -b none nvidia-settings -c :8
