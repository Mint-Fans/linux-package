sudo systemctl stop bumblebeed.service
sudo systemctl start bumblebeed.service

