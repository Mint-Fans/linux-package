Fun：Get obb file md5

Run：
java main <file>
