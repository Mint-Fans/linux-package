# load mod
sudo insmod opemu.ko

# unload mod
sudo rmmod opemu

# view debug log
sudo dmesg | grep 'OPEMU'


