//
//  half.h
//  opemu
//
//  Created by Meowthra on 2019/5/24.
//  Copyright © 2019 Meowthra. All rights reserved.
//  Made in Taiwan.

#ifndef half_h
#define half_h

//float    overflow (void);
short    FloatToHalf (int i);
unsigned int HalfToFloat (unsigned short y);

#endif /* half_h */
