## 編譯指令
# 編譯 Linux 原始碼內的模塊
# CONFIG_SND_HDA_CODEC_REALTEK=m 編譯 snd-hda-codec-realtek 為模塊
# M 模塊目錄
make CONFIG_SND_HDA_CODEC_REALTEK=m M=sound/pci/hda

# 編譯 Linux 原始碼以外的模塊
# -C 指定 /usr/src/linux-headers-$(uname -r) 或 /usr/lib/modules/$(uname -r)
# M 模塊目錄
lINUX_HEADERS_DIR=/usr/src/linux-headers-$(uname -r)
make -C ${lINUX_HEADERS_DIR} M=$(pwd) modules


## 無 linux headers 編譯模塊
下載 Linux 原始碼解壓縮，並在目錄建立 ext 目錄。
將模塊原始碼放進 ext 目錄內，ext 目錄內建立一個 Makefile 檔案，內容:
obj-$(CONFIG_TEST)		+= testmod/

# 編譯 ARMv7 平台範例
export CROSS_COMPILE=../prebuilts/gcc/linux-x86/arm/arm-linux-androideabi-4.9/bin/arm-linux-androideabi-
make ARCH=arm CONFIG_TEST=m M=ext/testmod

# 編譯 ARMv8 平台範例
export CROSS_COMPILE=../prebuilts/gcc/linux-x86/aarch64/aarch64-linux-android-4.9/bin/aarch64-linux-android-
make ARCH=arm64 CONFIG_TEST=m M=ext/testmod
