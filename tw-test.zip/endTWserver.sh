#!/usr/bin/bash

DB_PROC_ID=`ps -ef|grep "./db"|grep -v grep|awk '{print $2}'`
[ "$DB_PROC_ID" ] && kill -9 $DB_PROC_ID >/dev/null
 
# jtales0プロセスKILL
JTALES_PROC_0=`ps -ef|grep "./jtales -d 12 jtales0"|grep -v grep|awk '{print $2}'`
[ "$JTALES_PROC_0" ] && kill -9 $JTALES_PROC_0 >/dev/null
 
# jtales1プロセスKILL
JTALES_PROC_1=`ps -ef|grep "./jtales -d 12 jtales1"|grep -v grep|awk '{print $2}'`
[ "$JTALES_PROC_1" ] && kill -9 $JTALES_PROC_1 >/dev/null
 
# jtales2プロセスKILL
JTALES_PROC_2=`ps -ef|grep "./jtales -d 12 jtales2"|grep -v grep|awk '{print $2}'`
[ "$JTALES_PROC_2" ] && kill -9 $JTALES_PROC_2 >/dev/null
