// $Id: TW_NPC_Talk.h,v 1.4 2003/02/12 09:51:49 jaekim Exp $

#Import quest/system.h

function void clickTest();
function void SendNpcTalk(string funcName);
function void SendNpcScript(string filename, string functionname);
