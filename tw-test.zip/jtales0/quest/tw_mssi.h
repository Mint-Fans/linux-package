// $Id: tw_mssi.h,v 1.1 2003/02/20 07:05:01 softmax Exp $
//------------------
// tw_mssi.Q
// 2003. 2. 20
// Written by mssi
//------------------

#Import quest/system.h
#Import quest/tales_system.h

function void SetDynamicField(integer map, integer x, integer y);

function void BeginVE(string evID);
function void BeginVEfrArea(string evID);

function void BeginDEFunc(string funcName);
function void BeginDEFileFunc(string fileName, string funcName);
