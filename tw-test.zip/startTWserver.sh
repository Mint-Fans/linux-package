#!/usr/bin/bash
 
#=====================================================
# 啟動紀錄文件功能
# $1:程序名稱
#=====================================================
Fnc_START_PROC() {
  STARTDATE=`date +"%Y/%m/%d %H:%M:%S"`
   LOG_FILE=/tw404/logs/$1.log
   
   # 紀錄文件存在檢查
   LOG_FILE_CHECK=`ls $LOG_FILE 2>/dev/null`
   
   if [ "$LOG_FILE_CHECK" != "" ];then
       echo >> $LOG_FILE
       echo >> $LOG_FILE
   fi
   echo "#--------------------------------------------------------------------------------------" >> $LOG_FILE
   echo "#   $STARTDATE [$1] START" >> $LOG_FILE
   echo "#--------------------------------------------------------------------------------------" >> $LOG_FILE
}
 
# MySQL Start
# /etc/init.d/mysql.server start
 
# logs Make
mkdir -p /tw404/logs
 
# db Start
Fnc_START_PROC db
cd /tw404/db
./db >> /tw404/logs/db.log &

# jtales Start
list="0 1 2"
for n in ${list};do
  Fnc_START_PROC jtales${n}
   cd /tw404/jtales${n}
   ./start  >> /tw404/logs/jtales${n}.log & 
done
 
# 要重新啟動，如果已經下降到每60秒監控過程
while [ "a" != "b" ];do
  db_check=`ps -ef|grep ./db|grep -v grep`
   if [ "${db_check}" = "" ];then
       Fnc_START_PROC db
       cd /tw404/db
       ./db >> /tw404/logs/db_`date +"%Y%m%d"`.log &
   fi
   
   jtales0_check=`ps -ef|grep "./jtales -d 12 jtales0"|grep -v grep`
   if [ "${jtales0_check}" = "" ];then
       Fnc_START_PROC jtales0
       cd /tw404/jtales0
       ./start  >> /tw404/logs/jtales0.log &
   fi
   
   jtales1_check=`ps -ef|grep "./jtales -d 12 jtales1"|grep -v grep`
   if [ "${jtales1_check}" = "" ];then
       Fnc_START_PROC jtales1
       cd /tw404/jtales1
       ./start  >> /tw404/logs/jtales1.log &
   fi
   
   jtales2_check=`ps -ef|grep "./jtales -d 12 jtales2"|grep -v grep`
   if [ "${jtales2_check}" = "" ];then
       Fnc_START_PROC jtales2
       cd /tw404/jtales2
       ./start  >> /tw404/logs/jtales2.log &
   fi
   sleep 60
done
