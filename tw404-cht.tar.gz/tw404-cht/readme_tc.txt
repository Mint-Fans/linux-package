未繁化部份
quest/TW_CHAP12_Log.h
quest/TW_CHAP13_Log.h
quest/TW_EP2_CHAP00_Log.h
quest/TW_EP2_CHAP01_Log.h

等任務選單內紀錄訊息
