// $Id: tw_Header.h,v 1.1 2003/03/18 13:09:33 softmax Exp $
//------------------
// tw_Header.h
// 2003. 3. 18
// Written by mssi
//------------------

function boolean f_FieldEvent01110002();
function boolean fFieldEvent_00300001();
function boolean fFieldEvent_00340001();

