#!/bin/bash

fileList=`/bin/ls | grep "tales" | awk -F. '{printf("%s\n",$1)}'`
for file in $fileList
do
    echo "huhu: $file"
    mv $file.tales $file.jtales
done

    


