./uh -n -l 2 -g jtales $NAME
./uh -n -l 2 -g ctales $NAME

PATH=$(./uh -n -l 2 -g jtales $NAME)
PATH=$(./uh -n -l 2 -g ctales $NAME)
