// $Id:$
//------------------
// TW_QUEST_List.h
// 2003. 09. 09
// Written by hmmzzz
//------------------

#Define	STATE_INIT		0
#Define	STATE_TIME		1
#Define	STATE_TIME1		2
#Define	STATE_TIME2		3
#Define	STATE_TIME3		4
#Define	STATE_TIME4		5

#Define	STATE_CHECK1		6
#Define	STATE_CHECK2		7
#Define	STATE_CHECK3		8
#Define	STATE_CHECK4		9

#Define	STATE_BOSS1		10
#Define	STATE_BOSS2		11
#Define	STATE_BOSS3		12
#Define	STATE_BOSS_CHECK1	13
#Define	STATE_BOSS_CHECK2	14
#Define	STATE_BOSS_CHECK3	15
#Define	STATE_BOSS_END		16

#Define	STATE_CLEAR		97
#Define	STATE_FAIL		98
#Define	STATE_END		99

#Define	ANI_DIR_UP		2
#Define	ANI_DIR_LEFTUP		0
#Define	ANI_DIR_LEFT		14
#Define	ANI_DIR_LEFTDOWN	12
#Define	ANI_DIR_DOWN		10

// TW_DF_Narb_00207.Q
#Define	N_R_MAGIC_STORE_INDEX		1
#Define	N_R_INN_INDEX			2
#Define	N_R_GROCERY_INDEX		3
#Define	N_R_WEAPON_STORE_INDEX		4

#Define	N_R_START			"0"
#Define	N_R_MAGIC_STORE_1		"1"
#Define	N_R_INN_1			"2"
#Define	N_R_GROCERY_1			"3"
#Define	N_R_WEAPON_STORE_1		"4"
#Define	N_R_MAGIC_STORE_2		"5"
#Define	N_R_INN_2			"6"
#Define	N_R_GROCERY_2			"7"
#Define	N_R_WEAPON_STORE_2		"8"
#Define	N_R_MAGIC_STORE_3		"9"
#Define	N_R_INN_3			"10"
#Define	N_R_GROCERY_3			"11"
#Define	N_R_WEAPON_STORE_3		"12"
#Define	N_R_END				"13"

