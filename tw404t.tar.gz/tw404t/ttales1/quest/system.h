// $Id: system.h,v 1.125 2007/01/04 05:48:23 kyungho Exp $
// DON'T EDIT THIS FILE.
// THIS FILE IS MANAGED BY SERVER TEAM

/***********************************************************************
  * This is standard quest supplied functions
***********************************************************************/

Event {
	// wait for event type		: �̺�Ʈ �߻����� ��ٸ�
	// supported type : hear	: ���� ������ �̺�Ʈ hear
    static function void waitFor(integer event_type);
    static function void timedWaitFor(integer event_type, integer expireTime);
	// get event result		: �̺�Ʈ ����� ��Ʈ������ �ޱ�
	// tip: save to another var	: �׶��׶� �θ��� ���� ������ �����ؼ� ����.
    static function string result(integer event_type);
    static function void waitIfRunning(string questName);
};

String {
	// check whether two strings are matched : caseinsensitive
	// ���ڿ� �� : �����ڽ� ��ҹ��� ������
    static function boolean  match(string a, string b);
	// check whether two strings are matched : casesensitive
	// ���ڿ� �� : ������ ��ҹ��� ������
    static function boolean casematch(string a, string b);
	// check whether stringA contains stringB
	// ù��° ���ڿ��� �ι��� ���ڿ��� �����ϴ��� �׽�Ʈ
    static function boolean contains(string a, string b);
	// return joined string. e.g) "this" + "that" -> "thisthat"
	// �� ���ڿ��� ��ģ ���� ���� e.g) "��" + "��" -> "�ȳ�"
    static function string join(string a, string b);
	// return splitted string with given delimiter.
	// front position is 0 and post position is 1
	// ���ڿ����� �־��� ���������� ���ڿ��� ����
	// position�� 0�̸� �߶� ���� ����, 1�̸� ���� ���� ����
    static function string split(string delim, integer position, string source);
	// make string to integer. e.g) "1233" -> 1233
	// ���������� ���ڿ��� ���ڷ� �����. e.g) "1233" -> 1233
    static function integer toInteger(string a);
	// return length of string
	// ���ڿ��� ���̸� ������
    static function integer length(string a);

    static function string addObjectiveSuffix(string str);
    static function string addSubjectiveSuffix(string str);
    static function string addDescriptiveSuffix(string str);
    static function string addConjunctiveSuffix(string str);
};

Integer {
	// make string from integer. e.g) 1234 -> "1234"
	// ���ڿ��� ���ڿ��� �����. e.g) 1234 -> "1234"
    static function string toString(integer i);
};

Util {
    static function void log(string content);
	// return randomized number within given range
	// �־��� ���������� ���� ���� ����
    static function integer random(integer from, integer to);
	// suspend quest for given seconded time
	// �־��� �ð���ŭ ����. �� ������ ��:
    static function void sleep(integer sec);
	// return real world clock
    static function integer getTime();
	// return formatted real world clock string. man strftime to overview format
    static function string getTimeString(string format);
	// return game world tick count
    static function integer getTick();
    static function integer getTotalSeconds(integer tick);
    static function integer getYear(integer tick);
    static function integer getMonth(integer tick);
    static function integer getDay(integer tick);
    static function integer getWday(integer tick);
    static function integer getHour(integer tick);
    static function integer getMinute(integer tick);
    static function integer getSecond(integer tick);
	// return formatted game world time string. man strftime to overview format itself
	// but only %c, %Y, %y, %m %d, %H, %h, %M, %S, %p are supported
    static function string getTickString(string format);
    static function integer getNeighborX(integer x, integer direction);
    static function integer getNeighborY(integer y, integer direction);
    static function integer hexToDec(string hexString);
    static function string decToHex(integer dec);
    static function string getStringFor(string stringKey);

    static function string filterCurse(string userText);
    static function void notifyToAllUser(string str);

    static function integer getRealNationType();

    static function void canUseShoutScroll();
};

Machine {
    static function string getWholeArgs();
    static function integer getArgCount();
    static function string getArgAt(integer index);
    static function void setBooleanReturn(boolean result);
    static function void setIntegerReturn(integer result);
    static function void setStringReturn(string result);
    static function void setSavable();
    static function void exit();
    static function integer getDomainNumber();
};

Game {
    static function integer getNatureValue(integer attackNature, integer defenseNature);
    static function integer getThac0(integer class, integer level);
    static function integer getThac0_NPC(integer level);
    static function integer safetyPointAdjustment(integer dex);
    static function integer hitProbabilityAdjustment(integer str);
    static function integer damageAdjustment(integer str, integer dex);
};

/***********************************************************************
  * Game dependent functions 
  * HIERARCHY NOTE:
  *   If A is B, A can call all functions in B
  *   If A is B, A can be used wherever B is needed
  *   Example) User is Creature. so User can call all functions in Creature
  *            as well as can be used where Creature is needed.
  *
  *   Object : root class
  *
  *   Visible			is Object
  *   World			is Object
  *   Nation			is Object
  *   Clan			is Object
  *   Guild 			is Object
  *   Action			is Object
  *   Casted			is Object
  *   ActionInventory		is Object
  *   CarryingItemInventory	is Object
  *   EntrustedItemInventory	is Object
  *   CastedSpellInventory	is Object
  *   ClientController		is Object
  *   Container			is Object
  *   Rank			is Object
  *   Point			is Object
  *   Location			is Object
  *   Rectangle			is Object
  *   Castle			is Object
  *   WaitingRoomList		is Object
  *
  *   Creature			is Visible
  *   Monster			is Creature
  *   Guardian			is Monster
  *   Merchant			is Monster
  *   User			is Creature
  *   Item			is Visible
  *   Reactor			is Visible
  *
  *   StringArray		is Container
  *   IntegerArray		is Container
  *
  *   Machine			have nothing to do with Object
  *   Menu			have nothing to do with Object
  *   Event			have nothing to do with Object
  *   String			have nothing to do with Object
  *   Integer			have nothing to do with Object
  *   Util			have nothing to do with Object
***********************************************************************/
Object {
    function string getTypeName();
    function void giveQuestTo(string questName, object target, string argumentString);
    function integer getId();
};

Visible {
    static function object at(integer x, integer y);
    static function object named(string name);

    function boolean isCreature();
    function boolean isReactor();
    function boolean isPortal();

    function string getName();
    function string getDesc();
    function object getWorld();
    function integer getX();
    function integer getY();
    function void setX(integer x);
    function void setY(integer y);
    function integer getTile();
    function void setTile(integer tile);

    function boolean isInSight(object target);

    function boolean hasIntValue(integer index);
    function integer getIntValue(integer index);
    function void setIntValue(integer index, integer value);

    function string getStringValue(integer index);
    function integer getStringValueSize();
    function string getStringValueRandom(boolean bRemove);
    function void setStringValueRandom(string value);
    function void setStringValue(integer index, string value);
    function void resetStringValue(integer index);
};

Creature {
    static function object create(string name);
	// check wheter Trigger running given quest
	// suspended quest �߿� �����ϰ� �ִ� ���� �ִ��� return
    function boolean hasQuest(string quest_name);
	// suspend quest �߿� ������ ����
    function boolean endQuest(string quest_name);
	// suspend action of creature
	// �ڵ����� �����̴� �� ����
    function void suspend();
	// resume action of creature
	// �ڵ����� ������ ���
    function void resume();
    function boolean isDead();
    function boolean isAlive();
    function void show();
    function void hide();
    function integer getMaxInvenWeight();
    function void setMaxInvenWeight(integer bonus);
	// make trigger say
	// Trigger �� ���ϰ� ����
    function void say(string word_to_say);
    function void sayTo(string word_to_say, object listener);
	// make trigger be moved to direction : north: "n", south: "s" northwest: "nw", ...
	// �־��� �������� �̵���Ű��
    function void move(integer dir);
	// make trigger take some motion
	// ��� �����ְ� �ϱ�
    function void motion(integer motion, integer delay);
	// show effect
    function void effect(integer effect, integer delay);
    function void effectTo(object target, integer effect, integer delay);
    function void successAttackEffectTo(object target, integer damage, integer sound, integer attackMotion, integer attackEffect, integer attackEffectWhen, integer attackedMotion, integer attackedEffect, integer attackedEffectWhen, boolean bForcelyShowDamageBar);
    function void failAttackEffectTo(object target, integer attackMotion, integer attackEffect);
    function void successAttackEffectFromObjectToObject(object target, integer damage, integer sound, integer attackMotion, integer attackEffect, integer attackDelay, integer attackEffectWhen, integer attackedMotion, integer attackedEffect, integer attackedDelay, integer attackedEffectWhen, boolean bForcelyShowDamageBar, boolean bIgnoreSameMotion);
    function void failAttackEffectFromObjectToObject(object target, integer attackMotion, integer attackEffect, integer delay, boolean bIgnoreSameMotion);
    function void successAttackEffectFromObjectToVictimPoint(object target, integer damage, integer sound, integer attackMotion, integer attackEffect, integer attackDelay, integer attackEffectWhen, integer attackedMotion, integer attackedEffect, integer attackedDelay, integer attackedEffectWhen, boolean bForcelyShowDamageBar, boolean bIgnoreSameMotion);
    function void failAttackEffectFromObjectToVictimPoint(object target, integer attackMotion, integer attackEffect, integer delay, boolean bIgnoreSameMotion);
    function void successAttackEffectFromAttackerPointToObject(object target, integer damage, integer sound, integer attackMotion, integer attackEffect, integer attackDelay, integer attackEffectWhen, integer attackedMotion, integer attackedEffect, integer attackedDelay, integer attackedEffectWhen, boolean bForcelyShowDamageBar, boolean bIgnoreSameMotion);
    function void failAttackEffectFromAttackerPointToObject(object target, integer attackMotion, integer attackEffect, integer delay, boolean bIgnoreSameMotion);
    function void successAttackEffectFromAttackerPointToVictimPoint(object target, integer damage, integer sound, integer attackMotion, integer attackEffect, integer attackDelay, integer attackEffectWhen, integer attackedMotion, integer attackedEffect, integer attackedDelay, integer attackedEffectWhen, boolean bForcelyShowDamageBar, boolean bIgnoreSameMotion);
    function void failAttackEffectFromAttackerPointToVictimPoint(object target, integer attackMotion, integer attackEffect, integer delay, boolean bIgnoreSameMotion);
    function void successAttackEffectFromObjectToFixedPoint(object point, integer sound, integer attackMotion, integer attackEffect, integer attackDelay, integer attackEffectWhen, integer attackedMotion, integer attackedEffect, integer attackedDelay, integer attackEffectWhen, boolean bIgnoreSameMotion);
    function void failAttackEffectFromObjectToFixedPoint(object point, integer attackMotion, integer attackEffect, integer delay, boolean bIgnoreSameMotion);
    function void successAttackEffectFromAttackerPointToFixedPoint(object point, integer sound, integer attackMotion, integer attackEffect, integer attackDelay, integer attackEffectWhen, integer attackedMotion, integer attackedEffect, integer attackedDelay, integer attackEffectWhen, boolean bIgnoreSameMotion);
    function void failAttackEffectFromAttackerPointToFixedPoint(object point, integer attackMotion, integer attackEffect, integer delay, boolean bIgnoreSameMotion);
    function void damageEffectTo(object target, integer damage, integer delay);
    function void healEffectTo(object target, integer hp, integer delay);
	// return level of trigger
	// Trigger �� ���� ����
    function integer getLevel();
	// set tigger's level
	// Trigger �� ���� ����
    function void setLevel(integer lev_to_set);
	// return trigger's gender : MALE:0, FEMALE:1, NEUTRAL:2
	// Ʈ������ �������� : ����:0, ����:1, �߼�:2
    function integer getGender();
    function integer getDirection();
    function void setDirection(integer direction);
	// set trigger's gender
	// Ʈ������ ��������
    function void setGender(integer gender);
	// get trigger's hp
	// trigger �� hp �޾ƿ�
    function integer getHP();
	// set trigger's hp
	// trigger �� hp ����
    function void setHP(integer hp);
    function integer getMP();
    function void setMP(integer mp);
    function integer getSP();
    function void setSP(integer sp);
    function integer getSkillPoint();
    function void setSkillPoint(integer sp);
    function integer getMaxHP();
    function void setMaxHP(integer hp);
    function integer getMaxMP();
    function void setMaxMP(integer mp);
    function integer getMaxSP();
    function void setMaxSP(integer sp);
    function integer getOrgMaxHP();
    function void setOrgMaxHP(integer hp);
    function integer getOrgMaxMP();
    function void setOrgMaxMP(integer mp);
    function integer getOrgMaxSP();
    function void setOrgMaxSP(integer sp);
    function integer getMaxSkillPoint();
    function void setMaxSkillPoint(integer sp);
    function integer getGold();
    function void setGold(integer gold);
    function integer getInt();
    function integer getStr();
    function integer getHack();
    function integer getStab();
    function integer getCon();
    function integer getDex();
    function integer getAgi();
    function integer getWis();
    function integer getLuck();
    function void setInt(integer value);
    function void setStr(integer value);
    function void setHack(integer value);
    function void setStab(integer value);
    function void setCon(integer value);
    function void setDex(integer value);
    function void setAgi(integer value);
    function void setWis(integer value);
    function void setLuck(integer value);
    function void addInt(integer value);
    function void addStr(integer value);
    function void addHack(integer value);
    function void addStab(integer value);
    function void addCon(integer value);
    function void addDex(integer value);
    function void addAgi(integer value);
    function void addWis(integer value);
    function void addLuck(integer value);
    function void subInt(integer value);
    function void subStr(integer value);
    function void subHack(integer value);
    function void subStab(integer value);
    function void subCon(integer value);
    function void subDex(integer value);
    function void subAgi(integer value);
    function void subWis(integer value);
    function void subLuck(integer value);
    function integer getOrgInt();
    function integer getOrgStr();
    function integer getOrgHack();
    function integer getOrgStab();
    function integer getOrgCon();
    function integer getOrgDex();
    function integer getOrgAgi();
    function integer getOrgWis();
    function integer getOrgLuck();
    function void setOrgInt(integer value);
    function void setOrgStr(integer value);
    function void setOrgHack(integer value);
    function void setOrgStab(integer value);
    function void setOrgCon(integer value);
    function void setOrgDex(integer value);
    function void setOrgAgi(integer value);
    function void setOrgWis(integer value);
    function void setOrgLuck(integer value);
//    function integer getTendency();
//    function void setTendency(integer tend);
    function integer getAttackNature();
    function void setAttackNature(integer nature);
    function integer getDefenseNature();
    function void setDefenseNature(integer nature);
    function integer getNature();
    function void setNature(integer value);

    function void addNatureResist(integer nature, integer value);
    function void subNatureResist(integer nature, integer value);
    function void setNatureResist(integer nature, integer value);
    function integer getNatureResist(integer nature);
    function void setOrgNatureResist(integer nature, integer value);
    function integer getOrgNatureResist(integer nature);

	// check whether trigger is user
	// trigger �� �������� �Ǵ�
    function boolean isUser();
	// check whether trigger is Monster
	// trigger �� �������� �Ǵ�
    function boolean isMonster();
    function boolean isMerchant();
    function boolean isPet();
    function boolean isGuardian();
	// update trigger's attribute values
	// NOTE : quest does not update attributes though you change them
	//        since, too many update make network load and server load
	// 	  So you should call explitcitly this function
	// trigger �� �Ӽ��� ������Ʈ
	// NOTE : trigger �Ӽ��� �ٷιٷ� ������Ʈ ���� �ʴ´�. ���Լ���
	//	  �ҷ��߸��Ѵ�
    function boolean isBuilder();
    function void updateEquipAt(integer part);
    function void updateAttr();
    function void broadcastAbnormalState(integer abnormalStateId, integer skillId, integer byOther, integer value);
    function void broadcastDamage(integer damage);
	// update trigger's shape. shape is appearance
	// NOTE : quest does not update user shapes though you change them
	// trigger �� �ܾ��� ������Ʈ
	// NOTE : trigger �� �Ӽ��� �ٷιٷ� ������Ʈ ���� �ʳ���. ���Լ���
	// 	  �ҷ��߸��Ѵ�.
    function void updateShape();

    function object getSkillActionInventory();
    function object getCastedSpellInventory();
    function object getCarryingItemInventory();

    function void castNamed(string actionName);
    function void castNamedWithDuration(string actionName, integer duration);
    function void castObjected(object actionOrCastedObject);

    function integer defaultDamageCalculation(object victim, integer damage, integer attackType, integer attackNature);

    function void rememberAttacker(object enemy);
    function boolean canAttack(object enemy);
    function object getDefaultTarget();

    function integer getSpellAvoidRate();
    function void setSpellAvoidRate(integer rate);
    function integer getAttackAvoidRate();
    function void setAttackAvoidRate(integer rate);
    function integer getAttackHitRate();
    function void setAttackHitRate(integer rate);
    function integer getAttackBonusDamage();
    function void setAttackBonusDamage(integer damage);

    function integer getDefence();
    function void setDefence(integer ac);
    function void addDefence(integer ac);
    function void subDefence(integer ac);
    function integer getOrgDefence();
    function void setOrgDefence(integer ac);
    function integer getDamageClass();
    function void setDamageClass(integer dc);
    function void addDamageClass(integer dc);
    function void subDamageClass(integer dc);
    function integer getMagicResist();
    function void setMagicResist(integer mac);
    function void addMagicResist(integer mac);
    function void subMagicResist(integer mac);
    function integer getOrgMagicResist();
    function void setOrgMagicResist(integer mac);
    function integer getDamRole();
    function void setDamRole(integer damRole);
    function integer getHitRole();
    function void setHitRole(integer hitRole);
    function integer getRegen();
    function void setRegen(integer value);
    function integer getMregen();
    function void setMregen(integer value);
    function integer getStaminaRegen();
    function void setStaminaRegen(integer value);

    function integer getMoveMotionMultiplier();
    function void setMoveMotionMultiplier(integer val);
    function void addMoveMotionMultiplier(integer val);
    function void subMoveMotionMultiplier(integer val);

    function void message(string message, integer type);

    function void teleportTo(object location);
    function void recall(string userName);
    function void recallAt(string userName, integer worldNum);
    function void approachTo(string userName);

    function boolean isAbsolutelyImmortal();
    function boolean isPhysicallyImmortal();
    function boolean isMagicallyImmortal();
    function void setImmortal(integer immortal_mode);
    function void unsetImmortal(integer immortal_mode);

    // item related creature functions
    function boolean doesHaveItemAt(integer slot);
    function integer doesHaveItemClassNamed(string className);
    function boolean doesEquipItemClassNamed(string className);
    function boolean doesEquipPart(integer part);
    function string getDescAtSlot(integer slot);		
    function string getDescAtPart(integer part);		
    function string getClassNameAtSlot(integer slot);	
    function string getDescAtDepositSlot(integer slot);		
    function string getClassNameAtDepositSlot(integer slot);	
    function string getClassNameAtPart(integer part);
    function boolean equipClassNamed(string className);
    function boolean equipAtInvenSlot(integer slot);
    function boolean unequipAtEquipPart(integer part, boolean destroyAfterUnequip);
    function boolean useClassNamed(string className);
    function boolean useAtInvenSlot(integer slot);
    function void identifyItemAtInvenSlot(integer slot);
    function void identifyItemClassNamed(string itemName);
    function integer getEmptyInvenSlotCount();
    function integer getAvailInvenWeight();
    function integer getEmptyDepositSlotCount();
    function integer getTileAtSlot(integer slot);
    function integer getPriceAtSlot(integer slot);
    function integer getWeightAtSlot(integer slot);
    function integer getNumberAtSlot(integer slot);
    function integer getEnduranceAtSlot(integer slot);
    function boolean isIdentifiedAtSlot(integer slot);
    function boolean canDepositItemAtSlot(integer slot);
    function integer getTileAtDepositSlot(integer slot);
    function integer getPriceAtDepositSlot(integer slot);
    function integer getWeightAtDepositSlot(integer slot);
    function integer getNumberAtDepositSlot(integer slot);
    function integer getEnduranceAtDepositSlot(integer slot);
    function boolean isIdentifiedAtDepositSlot(integer slot);
    function integer getFirstItemSlot();
    function integer getNextItemSlot(integer slot);
    function integer getFirstDepositItemSlot();
    function integer getNextDepositItemSlot(integer slot);

    function void addItemClassNamed(string className, integer number);
    function void removeItemClassNamed(string className, integer number);
    function void removeItemEndureZeroAtPart(integer part);
    function boolean unequipItemBelowEndureAtPart(integer part, integer ratio);

    function void setLastHitter(object hitter);
    function void setAttacker(object hitter);
    function object getLastHitter();

    function void setState(integer state, boolean flag);
    function boolean isState(integer state);

    function integer getWalkSpeed();
    function void setWalkSpeed(integer speed);
    function integer getRunSpeed();
    function void setRunSpeed(integer speed);

    function void setEventTerminator(string eventid, integer minute, string script, boolean bShowTimer);
    function void resetEventTerminator(string eventid);
    function void resetEventTerminator2(string eventid, boolean bSuccess);
    function void modifyEventTerminator(string eventid, integer newdurationMin);
    function boolean hasShownTerminator();

    function void increaseTalkFlag();
    function void decreaseTalkFlag();

    function boolean canBeCasted(integer state);
    function void setDamageUp(integer up);

    function void setNightSight(integer value);
    function integer getNightSight();
};

User {
    function void setExp(integer exp);
    function void addExp(integer exp);
    function void subExp(integer exp);
    function integer getExp();
    function string getMasterId();

    function string getIpString();
    function integer getFD();

    function object getEntrustedItemInventory();

    function integer getAvailGold();
    function integer getAvailBalance();
	// reurn trigger's user class : game dependent value
	// Ʈ������ ����Ŭ������ ���� : ���Ӹ��� �ٸ�
    function integer getClass();
	// set trigger's user class
	// Ʈ������ ����Ŭ������ ����
    function void setClass(integer class);
	// get trigger's path
	// trigger �� ���� �н� ����
    function integer getPath();
	// set trigger's path
	// trigger �� ���� �н� ����
    function void setPath(integer path);
	// get trigger's grade
	// trigger �� ���� �н� ����
    function integer getGrade();
	// set trigger's grade
	// trigger �� ���� �н� ����
    function void setGrade(integer grade);
	// return trigger's clan name
	// trigger �� Ŭ�� �̸� ����
    function object getClan();
    function object getGuild(integer type);
    function void addGuildExp(integer exp);
    function void setGuildExp(integer exp);

    function integer getBalance();
    function void setBalance(integer balance);

    function object getClientController();

    function void setAttackFlag();

    function void resurrect(boolean bPenalty);
    function void setWarpPoint(integer episodeNum, integer flagId, boolean bOn);
    function boolean hasWarpPoint(integer episodeNum, integer flagId);
    function void sendWarpPoint(integer warpGroup);

    function void setLimited(boolean limit);
    function boolean isLimited();

    function void setCookie(string key, string value, integer duration);	
    function void resetCookie(string key);			
    function string getCookie(string key);
    function integer getCookieDuration(string key);

    function void setQuestInfo(string title);
    function void resetQuestInfo(string title);

    function boolean addSummonee(integer id);

    function void addStamina(integer stamina);

    function integer getShapeAttribute(integer shapeType);
    function void setShapeAttribute(integer shapeType, integer value);

    function integer getOrgShapeAttribute(integer shapeType);
    function void setOrgShapeAttribute(integer shapeType, integer value);

    function void updateTEIPAtPart(integer teip, integer valueType, integer part, integer value);
    function void updateMaxTEIPAtPart(integer teip, integer valueType, integer part, integer value);
    function void updateManufactureCntAtPart(integer valueType, integer part, integer value);
    function void enableItemAction();
    function void disableItemAction();

    function boolean isLeaderOfGroup();
    function boolean isMemberOfGroup(object user);
    function boolean isMemberNamedOfGroup(string user);

    function boolean openMerchantMenu(string dbid);

    function void setFame(integer fame);
    function void addFame(integer fame);
    function void subFame(integer fame);
    function integer getFame();
    function integer getLastCutExp();
    function object lastVisitedVillageLoc();
    function void setLastVisitedWorld(integer worldNum);

    function void setPhysicalAttackLimitBreakLev(integer level);
    function integer physicalAttackLimitBreakLev();
    function void setPhysicalDefenseLimitBreakLev(integer level);
    function integer physicalDefenseLimitBreakLev();
    function void setSpellAttackLimitBreakLev(integer level);
    function integer spellAttackLimitBreakLev();
    function void setSpellDefenseLimitBreakLev(integer level);
    function integer spellDefenseLimitBreakLev();
    function void setXienLimitBreakLev(integer level);
    function integer xienLimitBreakLev();
    function integer getLevelOfMaxXien();

    function void disableEventTriggerCondition();
    function void disableTeamEventTriggerCondition();
    function void endCreateEvent();

    function boolean setExtraCharacterSlot(integer extraCharacterSlot);
    function integer getExtraCharacterSlot();

    function boolean hasGlobalSwitch(integer episode, integer switchID);
    function integer getGlobalSwitch(integer episode, integer switchID);
    function void setGlobalSwitch(integer episode, integer switchID, integer value);

    function integer sendGlobalSwitchAll();
    function integer sendGlobalSwitchForEpisode(integer episode);
    function integer sendGlobalSwitchForSwitch(integer episode, integer switchID);
    function integer putGlobalSwitchLog(integer episode, string log);
    function integer sendGlobalSwitchLog();

    function integer getCharacterType();
    function void setEventState(boolean bShow);
    function void giveEventInfo(integer identifier);

    function integer getPlayTime();
    function void checkClosedBetaUser();

    function integer getColor(integer colorPart);
    function void setColor(integer colorPart, integer color);
    function void getOrgColor(integer colorPart);
    function void setOrgColor(integer colorPart, integer color);

    function integer getToolTipColor();
    function void setToolTipColor(integer color);

    function integer getTeamMemberType();
    function boolean hasTeam();
    function object getTeamChiefUser();
    function object getTeamEventMemberTyped(integer type);
    function void getTeamMemberTypedToContainer(integer type, object container);

    static function void setGoodwillForDBID(integer merchantId, integer value);		// value > 0
    static function void addGoodwillForDBID(integer merchantId, integer value);		// value > 0
    static function void subGoodwillForDBID(integer merchantId, integer value);		// value > 0

    function void setGoodwillFor(object merchant, integer value);
    function void addGoodwillFor(object merchant, integer diff);		// diff > 0
    function void subGoodwillFor(object merchant, integer diff);		// diff > 0

    function void updateComboDelay();

    function integer getMaxShield();
    function void setMaxShield(integer maxShield);

    function integer getShield();
    function void setShield(integer shield);

    function integer getMaxDefenceCount();
    function void setMaxDefenceCount(integer maxDefenceCount);

    function integer getDefenceCount();
    function void setDefenceCount(integer defenceCount);

    function boolean startTrade(boolean bSpecial, integer userShopTradeFeeRate);
    function void setConsumeStamina(integer stamina);

    function void groupEventTeleportTo(object location);

    function integer getExpFromAllAbilityLevel();
    function void resetCharacter(integer resetType);
    function integer getDBID();
    function integer setDBID(integer dbid);
    function integer getLevelupPoint();
    function void setLevelupPoint(integer levelupPoint);

    function void setActCancelPercentByDamage(integer percent);
    function void setSMHpAbsorbByDamage(integer type, integer point);
    function void setSkillCastSelfByDamage(string skill, integer percent);
    function void setSkillCastTargetByDamage(string skill, integer percent);

    function integer getBirthTime();

    function string getGroupName();
    function integer getGroupSize();
    function integer getGroupBirthTime();

    function void sendSelectQuestMessage(string question, string positiveQuest, string negativeQuest, object obj);
    function void sendDescribeQuestMessage(string question, string currentQuest, object obj);

    function string getQuestArgument();

    function void setGesture(integer gestrue);

    function void setSignColor(integer signColor);
    function integer getSignColor();

    function boolean haveXien(integer type, integer xienID);
    function boolean addXien(integer type, integer xienID);
    function boolean removeXien(integer type, integer xienID);

    function integer getBuilderType();
    function boolean exceedMaxExp();
    function void forceEventUpdate();

    function boolean isPaid();
    function boolean isFromPCBang();

    function object getPetInventory();
    function object getPet();
    function boolean hasPet();
    function void setExpByPet(integer exp);
    function integer getExpByPet();

    function void useCoupon(string couponNumber);

    function void removeAllItem();

    static function void setToSameEventWorld(object stringArray);

    function void setFishID(string dbid);
    function void setFishCatchTime(integer sec);
    function string getFishingRod();
    function string getSelectedBait();
    function void setFishingProb(integer prob);

    function boolean hasRecipe(string dbid, integer type);
    function boolean canAddRecipe(string dbid, integer type);
    function void addRecipe(string dbid, integer type);
    function void removeRecipe(string dbid, integer type);

    function void sendUrl(string url);
    function void sendEmoticon(integer type);
    function void setDetectRange(integer range);

    function void maxComboCount();
    function void resetMaxComboCount();

    function boolean getRandomItem(integer category);
    static function void registerBroadcast(string message, integer type);

    function void setMonsterCorpseDropRate(integer prob);
    function integer monsterCorpseDropRate();

    function void setBonusExpRate(integer prob);
    function integer bonusExpRate();

    //mail
    function void setMailReceivedLimit(integer lim);
    function integer getMailReceivedLimit();
    function void setMailStoredLimit(integer lim);
    function integer getMailStoredLimit();
    function integer getMailUseCount();
    function void setMailUseCount(integer count);
    function boolean addMailBG(integer bgType);

    function void setEmoticonPackValue(integer packNumber, boolean flag);

    function integer getLogoutTime();

    function void meet(string userName);
    // :::
//    function boolean canMacroTest();
//    function void macroTest();
    function boolean macroTest();

    function void setExpandedInven(boolean bSwitch, integer num);
};

PetInventory {
    function void update();
    function void setCleanItem(integer dbid, boolean bSpecial);
    function void setNutritionItem(integer dbid, boolean bSpecial);
    function void setFoodItem(integer dbid, boolean bSpecial);
    function integer remainTime();
    function void setRemainTime(integer time);	// sec
    function void setSanitation(integer value);
    function void setNutrition(integer value);
    function void setPartnerPetOwner(object user);
    function void truncate();
    function boolean isEggInIncubator();
    function integer nutrition();
    function integer eggMinNutritionRatio();
    function integer eggMaxNutritionRatio();
};

Pet {
    function object getOwner();
    function void setColor(integer part, integer color);
    function integer getColor(integer part);
    function integer levelUp();
    function integer skillInit();
    function integer getType();
    function boolean resurrectPaidPet();
    function void setSpecialAction(string actionName);
    function object getSpecialAction(string actionName);
    function integer getToolTipColor();
    function void setToolTipColor(integer color);
};

Guardian {
    function string getOwnerGuildName();
    function string setOwnerGuildName(string guildName);
    function integer getGuardianNumber();
    static function object summon(string guildName, integer world, integer sx, integer sy, integer ex, integer ey, integer patternNum);
    static function object summonByNumber(string guildName, integer number, integer world, integer sx, integer sy, integer ex, integer ey, integer patternNum);
    function void unsummon();
    function void catchBy(string guildName);
    function integer getBelongedCastleNum();
    static function integer getCastleNumOfOwner(string guildName);
    static function integer resetGuardian(string guildName);
    static function string getOwnerByNumber(integer number);
};

Monster {
    function void setSummonerId(integer id);
    function integer getSummonerId();
    function string getSummonerName();
    function void setCompanionId(integer id);
    function integer getCompanionId();
    function void setSCount(integer count);
    function void changePattern(string patternName);

    function integer getShapeAttribute(integer shapeType);
    function integer setShapeAttribute(integer shapeType, integer value);

    function integer getMaxDiceAttack();
    function integer getMaxDice2Attack(integer bonus);
    function integer getRollDiceAttack();
    function integer getRollDice2Attack(integer bonus);
};

Merchant {
    static function void setGoodwillForDBID(object user, integer merchantId, integer value);		// value > 0
    static function void addGoodwillForDBID(object user, integer merchantId, integer value);		// value > 0
    static function void subGoodwillForDBID(object user, integer merchantId, integer value);		// value > 0

    function integer getGoodwillFor(object user);
    function void setGoodwillFor(object user, integer value);
    function void addGoodwillFor(object user, integer diff);		// diff > 0
    function void subGoodwillFor(object user, integer diff);		// diff > 0
};

World {
    static function object getNumbered(integer number);

    function void putToContainerInRect(object container, integer sx, integer sy, integer ex, integer ey);

    function integer getNumber();
    function string getName();

    function boolean canResurrect();
    function boolean canFight();
    function boolean canPK();
    function boolean canUseSpell();
    function boolean canUseSkill();
    function boolean canUseBomb();
    function boolean canSay();
    function boolean canMove();
    function boolean canFastMove();
    function boolean canUseCustomWarp();
    function boolean canUseMeet();
    function boolean canUsePotion();
    function boolean canHearShout();

    function boolean isJail();
    function boolean isHell();
    function boolean isVoid();
    function boolean isBattleField();
    function boolean isRaining();

    function integer getXSize();
    function integer getYSize();

    function integer getBGMNumber();
    function integer getUserCount();
    function integer getMonsterCount();
    function boolean doesSendHellWhenDead();

    function integer allowedWarpGroup();

    function object getNation();

    function void effectFromObjectToObject(object source, object target, integer effectID, integer option, object effectMaker);
    function void effectFromObjectToPoint(object source, object target, integer effectID, integer option, object effectMaker);
    function void effectFromPointToObject(object source, object target, integer effectID, integer option, object effectMaker);
    function void effectFromPointToPoint(object source, object target, integer effectID, integer option, object effectMaker);

    function void enablePortalNumbered(integer number, boolean bFlag);
    function void enablePortalNumberedInRect(integer number, boolean bFlag, integer sx, integer sy, integer ex, integer ey);
    function void visiblePortalNumbered(integer number, integer visibleType);

    function integer getMonsterCountClassNamed(string className);
    function integer getMonsterCountClassNamedInRect(string className, integer startX, integer startY, integer endX, integer endY);
    function integer genMonsterClassNamed(string className, integer numberToCreate, string patternName);
    function integer genMonsterClassNamedInRect(string className, integer numberToCreate, string patternName, integer startX, integer startY, integer endX, integer endY);
    function integer genMonster(string className, integer numberToCreate, string patternName, integer force, integer startX, integer startY, integer endX, integer endY);
    function integer genItemClassNamed(string className, integer numberToCreate);
    function integer genItemClassNamedInRect(string className, integer numberToCreate, integer startX, integer startY, integer endX, integer endY);

    function void removeItemClassNamed(string className);
    function integer getCountItemClassNamed(string className);

    function integer getIntValue(integer key);
    function void setIntValue(integer key, integer value);
    function void addIntValue(integer key, integer amount);
    function void subIntValue(integer key, integer amount);
    function void giveQuestToAllUser(string questName, string argString);
    function void moveAllUserTo(integer world, integer x, integer y);
    function void stopAllUser(boolean bFlag);
    function void stopAllMonster(boolean bFlag);
    function void stopAllCreature(boolean bFlag);

    function boolean isEventWorld();
    function void destroyAllMonsters();

    function integer createReactor(string reactorType, integer strartX, integer startY, integer endX, integer endY, object creator, integer state, integer duration);
    function void setReactorDuration(integer indexNumber, integer duration);
    function void showReactor(integer indexNumber);
    function integer getReactorMaxState(integer indexNumber);
    function void setReactorMaxState(integer indexNumber, integer maxState);
    function integer getReactorState(integer indexNumber);
    function void setReactorState(integer indexNumber, integer state);
    function integer getReactorShowType(integer indexNumber);
    function void setReactorShowType(integer indexNumber, integer showType);
    function integer getReactorAniFileId(integer indexNumber);
    function void setReactorAniFileId(integer indexNumber, integer aniFileId);
    function integer getReactorAniActionId(integer indexNumber);
    function void setReactorAniActionId(integer indexNumber, integer aniActionId);
    function integer getReactorAniDirection(integer indexNumber);
    function void setReactorAniDirection(integer indexNumber, integer aniDirection);
    function integer getReactorAniLayer(integer indexNumber);
    function void setReactorAniLayer(integer indexNumber, integer aniLayer);
    function integer getReactorAniRepeat(integer indexNumber);
    function void setReactorAniRepeat(integer indexNumber, integer aniRepeat);
    function void setReactorHibernate(integer indexNumber, integer flag, integer duration);
    function void setReactorAnimation(integer indexNumber, integer fileId, integer actionId, integer direction, integer layer, integer repeat);

    function void setTimerForAllUser(string timerIdentifier, integer minute);
    function void resetTimerForAllUser(string timerIdentifier);
    function void broadcast(string message, integer msgType);

    function boolean canPutObject(integer x, integer y);

    function integer getCastleNumber();
};

EventWorld {
    function void getUsersToContainer(object container);
};

Nation {
    static function object getNamed(string name);
    function object getHellLocation();
    function object getVoidLocation();
    function object getJailLocation();
    function object getStartLocation();
    function object getGateLocation();
    function object getKaoHellLocation();
    function object getMeetingLocation();
    function string getCitizenName();
    function string getName();
};

Clan {
    function string getName();
    function integer getId();
};

Guild {
    static function object sendCreate();
    static function object create(string name, integer type, string master);
    static function object remove(string name, integer type);
    static function object select(string name, integer type);

    function string getName();
    function integer getBirthTick();
    function integer getLevel();
    function integer getSize();
    function integer getSizeWithoutVolunteer();
    function integer getType();

    function integer getSubType();
    function boolean setSubType(integer type);

    function boolean addMember(string name);
    function boolean removeMember(string name);

    function void setGoodwill(integer goodwill);

    function boolean isMemberNamed(string name);
    function integer getMemberType(string name);
    function boolean setMemberType(string name, integer type);

    function void setAlly(string name);
    function boolean isAlly(string name);

    function void setEnemy(string name);
    function boolean isEnemy(string name);

    function void startVote(integer type);
    function void vote(string name, integer value);
    function void messageToAll(string message, integer type);
    function void hasGuardian();
    function void getGuardianNum();
    function integer getLoginMemberNum();
};

Casted {
    static function integer getRelationBtw(string casted1, string casted2);
    static function string getDescClassNamed(string className);

    function boolean is(string relationName);
    function integer getRelation(object casted);
    function void setVisible();
    function void setInvisible();
    function string getName();
    function string getDesc();
    function integer getDuration();
    function void setDuration(integer newDuration);

    function void terminate();
    function void finalize();

    function integer getShield();

    function integer getDefenceCount();
    function integer getLevel();
};

CastedSpellInventory {
    function void addNamed(string name);
    function boolean hasNamed(string name);
    function integer getCount();
    function void addObjected(object obj);
    function void terminateNamed(string name);
    function void terminateObjected(object obj);
    function void terminateAll();
    function void terminatePassiveAll();
    function void finalizeNamed(string name);
    function void finalizeObjected(object obj);
    function void finalizeAll();
    function object getObjectCreatureStated(integer creatureState);
};

ActionInventory {
    function object getNamed(string name);
    function object getInSlot(integer slot);
    function integer getCount();
    function void addNamed(string name);
    function void removeNamed(string name);
    function void updateSlot(integer slot);
    function void updateNamed(string name);
};

Action {
    function integer getLevel();
    function integer setLevel();
};

CarryingItemInventory {					// NOTE: DO NOT MAKE ADD and REMOVE with Item object
    function integer size();				// for inventory, not for equipment pool

    function integer maxWeight();
    function integer weight();

    function integer availCount();
    function integer availWeight();

    function integer getInvenSlotClassNamed(string classname, integer fromSlot);	// for inventory
    function integer getCountClassNamed(string classname);	// for both inventory and equipment
    function boolean doesEquipClassNamed(string classname);	// for equipment only

    function object at(integer slot);
    function object part(integer part);
    function void recalcTEIP();

    function void clearInventory();
};

EntrustedItemInventory {				// NOTE: DO NOT MAKE ADD and REMOVE with Item Object
    function integer size();
};

Item {
    static function string getDescClassNamed(string className);
    static function boolean isEquippableClassNamed(string className);
    static function integer getMaxEnduranceClassNamed(string className);
    static function integer getBundleClassNamed(string classname);

    function string getName();
    function string getClassName();

    function string getStringArgumentAt(integer index);         // client input
    function integer getIntegerArgumentAt(integer index);       // client input
    function object getObjectArgumentAt(integer index);         // client input
    function object getPointArgumentAt(integer index);       	// client input
		    

    // cast some action to Trigger
    function void cast(string casted_name, object target);

    // ������ ������ number �� �����ϴ� �Լ����� 
    // �ܼ��� �������� �ٲ� ��, ���� �κ��丮 ��� ���� ���� ���� �ʴ´�. 
    // ���� ���࿡ ���� �κ��丮�� �ִ� �������� ����ϰų��ؼ� ������ �ٲ�� �����
    // quest �� wait �� ���� ���� (Event.waitFor ���� �θ� �Ŀ�) ������ �θ��� �ȵȴ�.
    // (quest �� wait �� �ƴ� ���� �������. ���� Ŭ���̾�Ʈ�κ��� � ������ ���� �ڿ�
    //  ������ ��� �����۵��� �̸� ���� �ȵȴ�)
    // ��� sweepNumbered �� ����� ��.

    // -- ������������ Ư���� �� ����� �ڸ�Ʈ --
    // �̴� ���� inventory ���� �������� �����Ѵ�. 
    // decreaseNumber ���� ������ �ʰ� (sweepNumbered �� �������� �ʰ�) �׳� �δ� ����
    // ������ ������ ��� �κ��� source code ItemProperty.m �� useSlot �ε�,
    // �̶� ��� ������ ������ ���ؼ� ������ �ٲ� ��쿡 �������� �����Ѵ�.
    // �� �̷� ���� �ܼ��� ������ ���̴� ���� �ҷ��� �Ѵ�. 
    function void increaseNumber(integer value);		
    function void decreaseNumber(integer value);
    function void setNumber(integer value);
    function integer getNumber();

    function string getAttribute(string key);
    function boolean checkAttribute(string key);
    function void setAttribute(string key, string value);
    function void resetAttribute(string key);

    function integer getPrice();
    function string getUserDefinedName();
    function void setUserDefinedName(string name);

    function integer getWeight();
    function integer getIdenFlag();
    function boolean isIdentified();
    function integer getProcessOnDeathType();
    function integer getLocality();
    function integer getBundle();
    function integer getPart();
    function integer getCanBeRepaired();
    function integer getTEIP(integer typeTEIP);
    function integer getLowerOrUpperTEIP(integer typeTEIP, integer lowerOrUpper);
    function void setTEIP(integer typeTEIP, integer value);
    function integer getMaxTEIP(integer typeTEIP);
    function void setMaxTEIP(integer typeTEIP, integer value);
    function integer getMaxManufactureCnt();
    function integer getManufactureCnt();
    function void setManufactureCnt(integer value);
    function boolean isEquippable();
    function boolean isUsable();
    function boolean isUsed();
    function boolean canBeExhausted();
    function void effectBy(object user);

    function void sweep();
    function void sweepNumbered(integer number);
    function boolean canBeUsedBy(object creature);
    function boolean canBeEquippedBy(object creature);
    function boolean canBeUnequippedBy(object creature);

    function void setLocked(boolean flag);
    function boolean isLocked();

    function void setExpireTime(integer expireTime);
    function integer getExpireTime();

    function boolean isCashItem();

    function void setBelong(boolean value);
    function boolean belong();
    function boolean canBelong();
};

Reactor {
    static function object create(string type);
    function void setDuration(integer sec);
    function void setCreator(string name);
    function void show();
    function void stop();					// remove reactor from world
    function void setHibernate(integer flag, integer duration);
    function integer getIndexNumber();
    function void setIndexNumber(integer indexNumber);
    function integer getMaxState();
    function void setMaxState(integer maxState);
    function integer getState();
    function void setState(integer state);
    function integer getShowType();
    function void setShowType(integer showType);
    function integer getAniFileId();
    function void setAniFileId(integer aniFileId);
    function integer getAniActionId();
    function void setAniActionId(integer aniActionId);
    function integer getAniDirection();
    function void setAniDirection(integer aniDirection);
    function integer getAniLayer();
    function void setAniLayer(integer aniLayer);
    function integer getAniRepeat();
    function void setAniRepeat(integer aniRepeat);
    function void setAnimation(integer fileId, integer actionId, integer direction, integer layer, integer repeat);
};

CastleTemplate {
    function integer getCastleNumber();

    function string getName();
    function void setName(string name);
    function string getKingName();
    function string getRulingGuildName();
    function void setRulingGuildName(string name);
    function void addChallengingGuild(string name);
    function string getChallengingGuildName();
    function void removeChallengingGuild();
    function string getFallenGuildName();
    function void setFallenGuildName(string name);

    function integer getState();
    function void setState(integer value);
    function integer getFortitude(integer index);
    function void setFortitude(integer index, integer bSet);
    function integer getVictoryTick();
    function integer getPlayingGuildType();

    function integer isInSiegeWar();

    function object getOuterFieldStartLocation();
    function object getInnerFieldStartLocation();
    function void siegeWarFinish();

    function integer getRemainTime();
    function void setRemainTime(integer time);
    function void reset(integer number);
    function void broadcast(string msg, integer type);
};

Castle {
    static function object getNumbered(integer number);
    static function boolean checkRulingGuild(string name);
    static function boolean checkChallengingGuild(string name);
    static function boolean checkReadyGuild(string name);

    function void kickAllButGuild();
    function integer getVictories();
    function void setVictories(integer value);

    function integer getStartHour();
    function integer getStartMinute();
    function void setStartTime(integer time);
    function integer getNextSiegeWarWeekday();
    function boolean isSiegeWarDay();

    function object getRulingGuardian();
    function object setRulingGuardian(object guardian);
    function object getChallengeGuardian();
    function object setChallengeGuardian(object guardian);

    function void setCancelGuildName(string name);
    function string getCancelGuildName();

    function boolean isReadyGuild(string name);
    function boolean addReadyGuild(string name);
    function boolean removeReadyGuild(string name);
    function integer getReadyGuildNumber();
    function void changeReadyGuildToChallenger();

    function boolean addItemClassNamedInCastleBank(string dbid, integer number, integer rank, integer expireTime);
    function void removeItemClassNamedInCastleBank(string dbid);
};

FlagCastle {
    static function object getObject(integer oId);
    function object getBattleWorld();
    function integer getPlayingGuildType();
    function void setAward(integer amount);
    function integer getAward();
    function void setRulerScore(integer amout);
    function integer getRulerScore();
    function integer addRulerScore(integer amount);
    function void setChallengerScore(integer amount);
    function integer getChallengerScore();
    function integer addChallengerScore(integer amount);
    function integer getFinalScore();
    function integer getGameMode();
};

ClientController {
    function void beginControl(integer control_type);
    function void blockTime(integer sec, integer control_type);
    function void endControl();
};

Rank {
    static function object select(string rank_name);			// return Rank object

    function void add(string key, integer val1, integer val2, integer val3, integer birthTime, string description);	// registration method
    function void update(string key, integer val1, integer val2, integer val3, integer birthTime, string description);	// add and refresh
    function void put(string key, integer val1, integer val2, integer val3, integer birthTime, string description, integer putType);
    function integer getCapacity();
    function void reset();

    function string getKeyFor(integer ranking);
    function integer getVal1For(integer ranking);
    function integer getVal2For(integer ranking);
    function integer getVal3For(integer ranking);
    function integer getBirthTimeFor(integer ranking);
    function integer getRecordTimeFor(integer ranking);
    function string getDescFor(integer ranking);
    function integer getNextRankingFor(string name, integer birthTime, integer ranking);
    function string getRankingStringFor(string name, integer birthTime);
    function integer getCount();

    function string getBackupKeyFor(integer ranking);
    function integer getBackupVal1For(integer ranking);
    function integer getBackupVal2For(integer ranking);
    function integer getBackupVal3For(integer ranking);
    function integer getBackupBirthTimeFor(integer ranking);
    function integer getBackupRecordTimeFor(integer ranking);
    function string getBackupDescFor(integer ranking);
    function integer getBackupNextRankingFor(string name, integer birthTime, integer ranking);
    function string getBackupRankingStringFor(string name, integer birthTime);
    function integer getBackupCount();
};

Meta {
    static function object select(string metadata_name);

    function string getValueAsString(string key, integer index);
    function integer getValueAsInteger(string key, integer index);
};

Container {
    static function object create();			// return new Container object
    function void add(object obj);
    function object at(integer index);
    function integer size();
};

StringArray {
    static function object create();
    function void add(string value);
    function string stringAt(integer index);
};

IntegerArray {
    static function object create();
    function void add(integer value);
    function integer integerAt(integer index);
};

Point {
    static function object create();			// return new Point object
    function integer getX();
    function integer getY();
    function void set(integer x, integer y);
};

Location {
    static function object create();			// return new Location object
    function integer getWorldNumber();
    function integer getX();
    function integer getY();
    function void set(integer world_number, integer x, integer y);
};

Rectangle {						// return new Rectangle object
    static function object create();
    function integer getStartX();
    function integer getStartY();
    function integer getEndX();
    function integer getEndY();
    function void set(integer start_x, integer start_y, integer end_x, integer end_y);
};

Menu {
    static function void setVisualEvent(string eventFileName);
    static function void setDynamicEvent(string entryFuncName);
    static function void setDynamicEvent2(string eventFileName, string entryFuncName);
    static function void showTo(object user);
    static function void showToGroup(object groupMemberActiveUser);
    static function void setLocalSwitch(integer key, integer value);
    static function void setGlobalSwitch(integer key, integer value);
    static function integer getResult(integer key);
};

Sound {
    static function void toUser(integer soundId, integer src_x, integer src_y, object user);
    static function void broadcast(integer soundId, integer src_x, integer src_y, object world);
};

WaitingRoomList {
    static function void sendWaitingRoomListTo(integer listNumber, object user);
};

Coupon {
    static function string getItemId(string couponNumber);
};

HardCode {
    static function boolean fishingBaitCheckQuest();
    static function void fishingStartQuest();

    static function boolean itemUpHP(object creature, integer value);
    static function boolean itemDownHP(object creature, integer value);
    static function boolean itemUpMP(object creature, integer value);
    static function boolean itemDownMP(object creature, integer value);
};

enum {
    NO = 0,
    YES = 1
};

enum {			// gender related
    MALE = 0,
    FEMALE = 1,
    NEWTRAL = 2
};

enum {			// message type
    MSG_TYPE__SYSTEM = 3,
    MSG_TYPE__ALERT = 4,
    MSG_TYPE__INFO = 5,
    MSG_TYPE__WINDOWED = 8,
    MSG_TYPE__AUTOHIDE_WINDOW = 17,
    MSG_TYPE__AUTOHIDE = 20,
    MSG_TYPE__USERBROADCAST = 24
};

enum {			// sleep state
    SLEEP_TYPE__NO = 0,
    SLEEP_TYPE__BARE,
    SLEEP_TYPE__DEEP
};

enum {			// direction related
    NORTH = 0,
    EAST, 
    SOUTH,
    WEST,
    NORTHEAST,
    SOUTHEAST,
    SOUTHWEST,
    NORTHWEST,
    MAX_DIR
};

enum {			// menu related
    MENU_TYPE__MESSAGE = 0,
    MENU_TYPE__CHOICE,
    MENU_TYPE__TEXTINPUT
};

enum {			// attack type
    ATTACK__FRONT = 1,
    ATTACK__REAR,
    ATTACK__SIDE
};

enum {			// action relation
    ORDER__NOTHING = 0,
    ORDER__LOW,
    ORDER__EQUAL,
    ORDER__HIGH
};

enum {			// immoral mode
    IMMORTAL__NOTHING = 0,
    IMMORTAL__PHYSICAL = 1,
    IMMORTAL__MAGICAL = 2,
    IMMORTAL__ABSOULTE = 3
};

enum {			// action category
    ACTION_CATEGORY__SPELL,
    ACTION_CATEGORY__SKILL
};

enum {			// attack effect when
    ATTACK_WHEN__REGARDLESS_ATTACK_MOTION = 0,
    ATTACK_WHEN__REGARDING_ATTACK_MOTION =1
};

enum {			// attacked effect when
    ATTACKED_WHEN__AFTER_ATTACK_MOTION = 0,
    ATTACKED_WHEN__AFTER_ATTACK_EFFECT = 1
};

enum {			// event related. related with GQLib.h
    EVENT_HEAR		= 2,
    EVENT_CLICK		= 4,
    EVENT_CLICK_OTHERS	= 8,
    EVENT_PICK		= 16,
    EVENT_USE		= 32,
    EVENT_DROP		= 64,
    EVENT_GET		= 128,
    EVENT_ERASE		= 256,
    EVENT_STEP_IN	= 512,
    EVENT_STEP_OUT	= 1024,
    EVENT_MENU		= 2048,
    EVENT_KILL		= 4096,
    EVENT_LEVEL_UP	= 8192,
    EVENT_WORLD_ENTER	= 16384,
    EVENT_MANUFACTURE	= 32768,
    EVENT_MASK		= 65536,
    EVENT_USER_MERCHANT	= 131072,
    EVENT_SCRIPT_SYNC	= 262144,
    EVENT_COUPON	= 524288

};

enum {
    SHOW_EFFECT_RANGE	= 0,
    SHOW_EFFECT_ALWAYS	= 1,
    SHOW_EFFECT_NEVER	= 2
};

enum {
    TRANSPARENT_OTHER_INVISIBLE	= 1,
    TRANSPARENT_OTHER_CANCLICK	= 2,
    TRANSPARENT_OTHER_DETECTED	= 4,

    TRANSPARENT_SELF_INVISIBLE	= 65536,
    TRANSPARENT_SELF_CANCLICK	= 131072,
    TRANSPARENT_SELF_DETECTED	= 262144
};

enum {
    PASS_THROUGH_USER		= 1,
    PASS_THROUGH_MONSTER	= 2,
    PASS_THROUGH_STATIC		= 4
};

enum {
    TYPE_NUMBER = 0,
    TYPE_PERCENT
};

enum {			// related with VisibleEffect enums
    EFFECT_BROADCAST = 0,
    EFFECT_ONLY_ME,
    EFFECT_NOT_ME
};

enum {		// Group(Team) member type
    INVALID_MEMBER = 0,
    CHIEF_MEMBER,
    EVENT_MEMBER,
    BATTLE_MEMBER
};

enum {		// real nation
    KOREA = 0,
    TAIWAN,
    JAPAN,
    CHINA
};

enum {
    FLAG_GAME_SINGLE_ROUND = 0,
    FLAG_GAME_BEST_OF_THREE
};

enum {
    RESET_CHAR_LEVEL = 1,
    RESET_CHAR_ACTION = 2
};

enum {
    PET_NORMAL		= 0,
    PET_MONSTER		= 1,
    PET_CASH_NORMAL	= 2,
    PET_CASH_MONSTER	= 3
};
