// $Id:$
// SecretPassage. Text

// 2007. 03. 02. by Stunlee
#Import quest/TW_NPC_Talk.h

#Define TEXT_EP2_CH1_GAWI			"�ŤM!!!"
#Define TEXT_EP2_CH1_BAWI			"���Y!!!"
#Define TEXT_EP2_CH1_BO				"��!!!"
#Define TEXT_EP2_CH1_SAME				"�R�l�C���G!"
#Define TEXT_EP2_CH1_LOSE				"�t!"
#Define TEXT_EP2_CH1_WIN				"��!"



