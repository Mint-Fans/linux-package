<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/approveposts.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$inlist = "";
$query = "
	select FORUM_ID
	from {$config['TABLE_PREFIX']}FORUMS
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while(list($forum_id) = $dbh->fetch_array($sth)) {
	if ($userob->check_access("forum","APPROVE_ANY",$forum_id)) {
		$inlist .= "$forum_id,";
	} // end while
}
$inlist = preg_replace("/,$/","",$inlist);
if (!$inlist) $inlist = '';
$inlist = "AND t4.FORUM_ID in ($inlist)";

$admin->doAuth(array("APPROVE_POSTS"));

$post = array();
// Grab info on all posts that aren't approved
$query = "
	SELECT t1.POST_ID,t1.POST_SUBJECT,t3.FORUM_TITLE,t1.USER_ID,t2.USER_DISPLAY_NAME
	FROM {$config['TABLE_PREFIX']}POSTS AS t1,
	{$config['TABLE_PREFIX']}USERS AS t2,
	{$config['TABLE_PREFIX']}FORUMS AS t3,
	{$config['TABLE_PREFIX']}TOPICS as t4
	WHERE t1.POST_IS_APPROVED = '0'
	AND t1.USER_ID = t2.USER_ID
	AND t1.TOPIC_ID = t4.TOPIC_ID
	AND t3.FORUM_ID = t4.FORUM_ID
	$inlist
	ORDER BY t4.FORUM_ID,t1.POST_ID DESC
";

$sth = $dbh->do_query($query,__LINE__,__FILE__);
$i=0;
while(list($number,$subject,$board,$posterid,$poster) = $dbh->fetch_array($sth)) {
	$post[$i]['number'] = $number;
	$post[$i]['subject'] = $subject;
	$post[$i]['board'] = $board;
	if ($posterid == "1") {
		$post[$i]['poster'] = $ubbt_lang['ANON_TEXT'];
	}
	else {
		$post[$i]['poster'] = "<a href=\"{$config['BASE_URL']}/admin/showuser.php?uid=$posterid\" target=\"_blank\">$poster</a>";
	}
	$i++;
}


$tabs = array(
	"{$ubbt_lang['APPROVE_THREADS']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['APPROVE_THREADS']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['APPROVE_THREADS']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
include("../templates/default/admin/approveposts.tmpl");

$admin->sendFooter();
?>
