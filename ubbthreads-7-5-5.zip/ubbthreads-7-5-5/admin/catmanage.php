<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/catmanage.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Grab all categories
$query = "
	SELECT CATEGORY_ID,CATEGORY_TITLE,CATEGORY_DESCRIPTION,CATEGORY_SORT_ORDER
	FROM {$config['TABLE_PREFIX']}CATEGORIES
	ORDER BY CATEGORY_SORT_ORDER
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$i=0;
while(list($centry,$ctitle,$cdescription,$sort) = $dbh->fetch_array($sth)) {
	$cat[$i]['number'] = $centry;
	$cat[$i]['title'] = htmlspecialchars($ctitle);
	$cat[$i]['description'] = $cdescription;
	$cat[$i]['sort'] = $sort;
	$i++;
}


$tabs = array(
	"{$ubbt_lang['CAT_SET']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['CAT_SET']);
$admin->setPageTitle($ubbt_lang['CAT_SET']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/catmanage.tmpl");

$bottomtabs[$ubbt_lang['ADD_NEW']] = "{$config['BASE_URL']}/admin/createcat.php";

$admin->createBottomTabs($bottomtabs);

$admin->sendFooter();
?>
