<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/doapprovepdn.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate();
$html = new html;

$admin = new Admin;
$mailer = new Mailer("../");

$admin->doAuth();

$returntab = get_input("returntab","post");
$totaldsp = get_input("totaldsp","post");

for ($i=0;$i<=$totaldsp;$i++) {
	$field = "action-$i";
	$useraction = get_input($field,"post");
	list($action,$uid) = preg_split("#-#",$useraction);
	$field = "reason-$i";
	$reason = get_input($field,"post");

	if ($action != "none") {
		$query = "
			SELECT DISPLAY_NAME_REQUEST
			FROM {$config['TABLE_PREFIX']}DISPLAY_NAMES
			WHERE USER_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
		list($newdisplay) = $dbh->fetch_array($sth);

		$query = "
			SELECT COUNT(*)
			FROM {$config['TABLE_PREFIX']}USERS
			WHERE (USER_LOGIN_NAME = ? OR USER_DISPLAY_NAME = ? )
			AND USER_ID <> ?
		";
		$sth = $dbh->do_placeholder_query($query,array($newdisplay,$newdisplay,$uid),__LINE__,__FILE__);
		list($check) = $dbh-> fetch_array($sth);
		if ($check) {
			$reason = $ubbt_lang['TAKEN'];
			$action = "delete";
		}
	}

	// Approve the registration
	if ($action == "approve") {
		$query = "
			select USER_DISPLAY_NAME
			from {$config['TABLE_PREFIX']}USERS
			where USER_ID = ?
		";
		$stx=$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
		list($oldname) = $dbh->fetch_array($stx);

		admin_log("NAME_CHANGE", "$oldname -> <a href='{$config['BASE_URL']}/admin/showuser.php?uid=$uid' target='_blank'>$newdisplay</a>");
		$query = "
			UPDATE {$config['TABLE_PREFIX']}USERS
			SET USER_DISPLAY_NAME = ?
			WHERE USER_ID = ?
		";
		$dbh->do_placeholder_query($query,array($newdisplay,$uid),__LINE__,__FILE__);
		$subject = $ubbt_lang['PDN_APP'];
		$msg = "{$ubbt_lang['PDN_BODY']} '$newdisplay'.";
		$html->send_message($user['USER_ID'],$uid,$subject,$msg);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}DISPLAY_NAMES
			WHERE USER_ID = ?
		";
		$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
	}

	// Delete the registration
	if ($action == "delete") {
		$query = "
			select USER_DISPLAY_NAME
			from {$config['TABLE_PREFIX']}USERS
			where USER_ID = ?
		";
		$stx = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
		list($oldname) = $dbh->fetch_array($stx);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}DISPLAY_NAMES
			WHERE USER_ID = ?
		";
		$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
		$subject = $ubbt_lang['PDN_DEN'];
		$msg = "{$ubbt_lang['DEN_BODY']} '$newdisplay'.\n\n$reason";
		admin_log("DENY_NAME_CHANGE", "<a href='{$config['BASE_URL']}/admin/showuser.php?uid=$uid' target='_blank'>$oldname</a>");
		$html->send_message($user['USER_ID'],$uid,$subject,$msg);
	}
}


$admin->redirect($ubbt_lang['CONF_BODY'],"{$config['BASE_URL']}/admin/membermanage.php?returntab=$returntab",$ubbt_lang['F_LOC']);

?>
