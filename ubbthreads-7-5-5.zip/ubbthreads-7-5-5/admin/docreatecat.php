<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$title = get_input("title","post");
$desc = get_input("desc","post");

// Get the max sort order
$query = "
	select max(CATEGORY_SORT_ORDER)
	from {$config['TABLE_PREFIX']}CATEGORIES
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
list($max_sort) = $dbh->fetch_array($sth);
if (!$max_sort) $max_sort = 0;


$query_vars = array($title,$desc,$max_sort + 1);
$query = "
	INSERT INTO {$config['TABLE_PREFIX']}CATEGORIES
	(CATEGORY_TITLE,CATEGORY_DESCRIPTION,CATEGORY_SORT_ORDER)
	VALUES
	( ? , ? , ? )
";
$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

build_forum_cache();
// ---------------
// Log this action
admin_log("ADD_CATEGORY", $title);

$admin->redirect($ubbt_lang['CAT_ADDED'],"{$config['BASE_URL']}/admin/catmanage.php",$ubbt_lang['CAT_F_LOC']);

?>
