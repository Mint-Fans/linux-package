<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/doeditcustomisland.php");

// -------------
// Get the input
$returntab = get_input("returntab","post");
$island = get_input("island","post");
$portal_name = get_input("portal_name","post");
$portal_cache = get_input("portal_cache","post");
$portal_body = get_input("portal_body","post");
$always_build = get_input("always_build","post");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();


$new_body = <<<EOF
<?php
$portal_body
?>
EOF;

/*
ob_start();
eval("\$test = $new_body");
$error = ob_get_contents();
ob_end_clean();

if (!isset($test) || !$test) {
	list($printerror,$junk) = preg_split("# in #",$error);
	$admin->error(sprintf($ubbt_lang['PROBLEM'],$printerror));
	exit;
}
*/


$portal_cache = $portal_cache * 60;
$query = "
	update 	{$config['TABLE_PREFIX']}PORTAL_BOXES
	set	PORTAL_NAME = ? ,
		PORTAL_CACHE = ? ,
		PORTAL_BODY = ? 
	where	PORTAL_ID = ?
";

$dbh->do_placeholder_query($query,array($portal_name,$portal_cache,$portal_body,$island),__LINE__,__FILE__);

define('PORTAL',1);
$check = lock_and_write("{$config['FULL_PATH']}/cache_builders/custom/portal_box_$island.php",$new_body);
if ($check == "no_write") {
	$admin->error(sprintf($ubbt_lang['NO_WRITE'],$island));
} // end if

if ($always_build && !in_array("portal_box_{$island}",$config['BUILD_ISLANDS'])) {
	// put it in
	if (is_array($config['BUILD_ISLANDS'])) {
		array_push($config['BUILD_ISLANDS'],"portal_box_{$island}");
	} else {
		$config['BUILD_ISLANDS'][] = "portal_box_{$island}";
	} // end if

	$_POST['BUILD_ISLANDS'] = $config['BUILD_ISLANDS'];
	$newconfig = array("BUILD_ISLANDS");
	include("./doeditconfig.php");
	
} else {
	// take it out

	$newarray = array();
	foreach($config['BUILD_ISLANDS'] as $k => $v) {
		if ($v == "portal_box_{$island}") continue;
		$newarray[] = $v;
	}

	$_POST['BUILD_ISLANDS'] = $newarray;	
	$newconfig = array("BUILD_ISLANDS");
	include("./doeditconfig.php");
}

admin_log("EDIT_CUSTOM_ISLAND","<a href='{$config['BASE_URL']}/admin/editcustomisland.php?island=$island&returntab=$returntab' target='_blank'>$portal_name</a>");

$admin->redirect($ubbt_lang['CUSTOM_UPDATED'],"{$config['BASE_URL']}/admin/editcustomisland.php?island=$island&returntab=$returntab",$ubbt_lang['CUSTOM_F_LOC']);

?>
