<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/doeditmoodimages.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

$removedmoods = "";

// -------------
// Get the input
$returntab = get_input("returntab","post");

// -----------------
// Get the user info
$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// ------------------
// Remove all checked
$dir = opendir("{$config['FULL_PATH']}/images/{$style_array['mood']}");
$i=0;
while( ($file = readdir($dir)) != false) {
	if ( ($file == ".") || ($file == "..") || ($file == "index.html") ) {
		continue;
	}
	list($name,$ext) = preg_split("#\.#",$file);
	$upload = "file-$ext-$name";
	if (isset($_POST[$name])) {
		$filename = "$name.{$_POST[$name]}";
		$test = @unlink("{$config['FULL_PATH']}/images/{$style_array['mood']}/$filename");
		if (!$test) {
			$admin -> error("{$ubbt_lang['NOREMOVE']}");
		}
		$removedmoods .= "$filename-";
	}
	elseif (!empty($_FILES[$upload]['name'])) {
		$fileupload = $_FILES[$upload]['name'];
		$file_temp = $_FILES[$upload]['tmp_name'];
		$check = @move_uploaded_file($file_temp,"{$config['FULL_PATH']}/images/{$style_array['mood']}/$file");
		@chmod("{$config['FULL_PATH']}/images/{$style_array['mood']}/$file",0666);
		if (!$check) {
			$admin->error("{$config['FULL_PATH']}/images/{$style_array['mood']}/$file {$ubbt_lang['NO_OVERW']}");
		}
	}
}

// ---------------
// Log this action
admin_log("EDIT_MOODS", '');

$admin->redirect($ubbt_lang['REMOVED'],"{$config['BASE_URL']}/admin/mood_display.php?returntab=5",$ubbt_lang['F_LOC']);

?>
