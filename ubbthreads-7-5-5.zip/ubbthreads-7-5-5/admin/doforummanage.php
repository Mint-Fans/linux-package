<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Grab all current boards
$query = "
	SELECT FORUM_ID,FORUM_TITLE,FORUM_SORT_ORDER,CATEGORY_ID,FORUM_IS_ACTIVE
	FROM {$config['TABLE_PREFIX']}FORUMS
	ORDER BY CATEGORY_ID, FORUM_SORT_ORDER
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$i=0;
while(list($number,$title,$sort,$catn,$active) = $dbh->fetch_array($sth)) {
	$forums[$i]['number'] = $number;
	$forums[$i]['title'] = $title;
	$forums[$i]['sort'] = $sort;
	$forums[$i]['cat'] = $catn;
	$forums[$i]['active'] = $active;
	$i++;
}
for ($x=0;$x<$i;$x++) {
	$fnum = $forums[$x]['number'];
	$titles = get_input("forum","post");
	$orders = get_input("order","post");
	$active = get_input("active","post");
	if (!isset($active[$fnum])) {
		$active[$fnum] = '0';
	}
	$update = 0;
	$params = "";
	if ($titles[$fnum] != $forums[$x]['title']) {
		$update = 1;

		$newtitle = addslashes($titles[$fnum]);
		$newtitle = htmlspecialchars($newtitle);
		$params .= "FORUM_TITLE = '$newtitle',";
	}
	if ($orders[$fnum] != $forums[$x]['sort']) {
		$update = 1;
		$neworder = addslashes($orders[$fnum]);
		$params .= "FORUM_SORT_ORDER='$neworder',";
	}
	if ($active[$fnum] != $forums[$x]['active']) {
		$update = 1;
		$newactive = addslashes($active[$fnum]);
		$params .= "FORUM_IS_ACTIVE = '$newactive'";
	}
	if ($update) {
		$params = preg_replace("/,$/","",$params);
		$query = "
			UPDATE {$config['TABLE_PREFIX']}FORUMS
			SET $params
			WHERE FORUM_ID='$fnum'
		";
		$dbh->do_query($query,__LINE__,__FILE__);
	}
}
admin_log("FORUM_MANAGE","");
build_forum_cache();

$admin->redirect($ubbt_lang['FORUMS_UPDATED'],"{$config['BASE_URL']}/admin/forummanage.php?returntab=0",$ubbt_lang['FORUMS_F_LOC']);

?>
