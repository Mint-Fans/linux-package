<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","post");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Get the new registration options
$regopt = get_input("regopt","post");

while(list($key,$value) = each($regopt)) {
	$show = 0;
	$require = 0;
	if ($value == "show") {
		$show = 1;
	}
	if ($value == "require") {
		$require = 1;
	}
	$query = "
		REPLACE INTO {$config['TABLE_PREFIX']}REGISTRATION_FIELDS
		VALUES
		('$key','$show','$require')
	";
	$dbh->do_query($query,__LINE__,__FILE__);
}

// What config vars are we updating?
$newconfig = array("NEW_USER_MODERATION","EMAIL_VERIFICATION","SPECIAL_CHARACTERS","MIN_PDN_LENGTH","MAX_PDN_LENGTH","DO_AGE_CHECK","ALLOW_UNDER_13","SUSPEND_REGISTRATIONS","CUSTOM_FIELD_1","CUSTOM_FIELD_2","CUSTOM_FIELD_3","CUSTOM_FIELD_4","CUSTOM_FIELD_5","MINIMUM_AGE","REQUIRE_UNIQUE_EMAIL","CAPTCHA");

// Forcing the board rules to be accepted?
if (get_input("FORCE_RULES","post")) {
	array_push($newconfig,"FORCE_RULES");
} // end if

// Update newusergroup
$newusergroups = '1';

// Update the config file
include("doeditconfig.php");

// Update the board rules file if necessary
$oldboardrules = "";
$boardfile = file("{$config['FULL_PATH']}/includes/boardrules.php");
while (list($linenum,$line) = each($boardfile)) {
	$oldboardrules .= "$line";
}
$boardrulestext = get_input("boardrulestext","post");
if ($boardrulestext != $oldboardrules) {
	
	$check = lock_and_write("{$config['FULL_PATH']}/includes/boardrules.php",$boardrulestext);
	if ($check == "no_write") {
		$admin->error($ubbt_lang['NO_WRITE_RULES']);
	} // end if
} // end if

// Get current badips
$badnames = get_input("badnames","post");
$query = "
SELECT RESERVED_USERNAME
FROM {$config['TABLE_PREFIX']}RESERVED_NAMES
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$currnames = array();
while(list($bname) = $dbh->fetch_array($sth)) {
$currnames[] = $bname;
}
$badnames = str_replace("\r","",$badnames);
$newnames = preg_split("#\n#",$badnames);

// Update the ReservedName List
for($i=0;$i<sizeof($newnames);$i++) {
	if (!in_array($newnames[$i],$currnames)) {
		$name_q = addslashes($newnames[$i]);
		if ($name_q) {
			$query = "
				INSERT INTO {$config['TABLE_PREFIX']}RESERVED_NAMES
				VALUES
				('$name_q')
			";
			$dbh->do_query($query,__LINE__,__FILE__);
		}
	}
}

for($i=0;$i<sizeof($currnames);$i++) {
	if (!in_array($currnames[$i],$newnames)) {
		$name_q = addslashes($currnames[$i]);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}RESERVED_NAMES
			WHERE RESERVED_USERNAME = '$name_q'
		";
		$dbh->do_query($query,__LINE__,__FILE__);
	}
}


// Update the coppa file if necessary
$oldcoppa = "";
$file = file("{$config['FULL_PATH']}/includes/coppainsert.php");
while (list($linenum,$line) = each($file)) {
	$oldcoppa .= "$line";
}
$coppa = get_input("coppa","post");
if ($coppa != $oldcoppa) {
	
	$check = lock_and_write("{$config['FULL_PATH']}/includes/coppainsert.php",$coppa);
	if ($check == "no_write") {
		$admin->error($ubbt_lang['NO_WRITE_COPPA']);
	} // end if
} // end if

admin_log("REGISTRATION_SETTINGS","$log_diffs");

$admin->redirect($ubbt_lang['SET_UPDATED'],"{$config['BASE_URL']}/admin/reg_settings.php?returntab=$returntab",$ubbt_lang['REG_SET_F_LOC']);

?>
