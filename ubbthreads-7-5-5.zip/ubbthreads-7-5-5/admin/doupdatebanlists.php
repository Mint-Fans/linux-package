<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/doupdatebanlists.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$returntab = get_input("returntab","post");
$badips = get_input("badips","post");
$bademails = get_input("bademails","post");

// Get current badips
$query = "
	SELECT BANNED_HOST
	FROM {$config['TABLE_PREFIX']}BANNED_HOSTS
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$currips = array();
while(list($hostname) = $dbh->fetch_array($sth)) {
	$currips[] = $hostname;
}
$badips = preg_replace("/ +/","",$badips);
$badips = str_replace("\r","",$badips);
$newips = preg_split("#\n#",$badips);

// Update the IP List
for($i=0;$i<sizeof($newips);$i++) {
	if (!in_array($newips[$i],$currips)) {
		$ip = addslashes($newips[$i]);
		if ($ip) {
			$query = "
				INSERT INTO {$config['TABLE_PREFIX']}BANNED_HOSTS
				VALUES
				('$ip')
			";
			$dbh->do_query($query,__LINE__,__FILE__);
		}
	}
}

for($i=0;$i<sizeof($currips);$i++) {
	if (!in_array($currips[$i],$newips)) {
		$ip = addslashes($currips[$i]);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}BANNED_HOSTS
			WHERE BANNED_HOST = '$ip'
		";
		$dbh->do_query($query,__LINE__,__FILE__);
	}
}

// Get current bademails
$query = "
	SELECT BANNED_EMAIL
	FROM {$config['TABLE_PREFIX']}BANNED_EMAILS
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$curremail = array();
while(list($email) = $dbh->fetch_array($sth)) {
	$curremail[] = $email;
}
$bademails = preg_replace("/ +/","",$bademails);
$bademails = str_replace("\r","",$bademails);
$newemail = preg_split("#\n#",$bademails);

// Update the Email List
for($i=0;$i<sizeof($newemail);$i++) {
	if (!in_array($newemail[$i],$curremail)) {
		$email = addslashes($newemail[$i]);
		if ($email) {
			$query = "
				INSERT INTO {$config['TABLE_PREFIX']}BANNED_EMAILS
				VALUES
				('$email')
			";
			$dbh->do_query($query,__LINE__,__FILE__);
		}
	}
}

for($i=0;$i<sizeof($curremail);$i++) {
	if (!in_array($curremail[$i],$newemail)) {
		$email = addslashes($curremail[$i]);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}BANNED_EMAILS
			WHERE BANNED_EMAIL = '$email'
		";
		$dbh->do_query($query,__LINE__,__FILE__);
	}
}

admin_log("UPDATE_BANLISTS","");

$admin->redirect($ubbt_lang['UPDATED'],"{$config['BASE_URL']}/admin/membermanage.php?returntab=$returntab",$ubbt_lang['F_LOC']);

?>
