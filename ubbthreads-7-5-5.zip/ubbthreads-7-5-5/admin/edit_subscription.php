<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/edit_subscription.php");

// Get the input
$returntab = get_input("returntab","both");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$group = get_input("group","get","int");

$query = "
	select GROUP_NAME
	from {$config['TABLE_PREFIX']}GROUPS
	where GROUP_ID = ?
";
$sth = $dbh->do_placeholder_query($query,array($group),__LINE__,__FILE__);
list($gtitle) = $dbh->fetch_array($sth);

$group_title = $html->substitute($ubbt_lang['THIS_GROUP'], array('GROUP_TITLE' => $gtitle));

$query = "
	select SUBSCRIPTION_NAME,SUBSCRIPTION_DESCRIPTION,SUBSCRIPTION_BY_DONATION,SUBSCRIPTION_DONATION_AMOUNT,SUBSCRIPTION_BY_TRIAL,SUBSCRIPTION_TRIAL_AMOUNT,SUBSCRIPTION_TRIAL_DURATION,SUBSCRIPTION_TRIAL_INTERVAL,SUBSCRIPTION_BY_REGULAR,SUBSCRIPTION_REGULAR_AMOUNT,SUBSCRIPTION_REGULAR_DURATION,SUBSCRIPTION_REGULAR_INTERVAL,SUBSCRIPTION_IS_RECURRING,SUBSCRIPTION_REATTEMPT 
	from {$config['TABLE_PREFIX']}SUBSCRIPTIONS
	where GROUP_ID = ?
";
$sth = $dbh->do_placeholder_query($query,array($group),__LINE__,__FILE__);
list($name,$desc,$donation,$donation_amount,$trial,$trial_amount,$trial_duration,$trial_interval,$sub,$sub_amount,$sub_duration,$sub_interval,$recurring,$reattempt) = $dbh->fetch_array($sth);

if ($recurring) {
	$recurring_checked = "checked='checked'";
} // end if

if ($reattempt) {
	$reattempt_checked = "checked='checked'";
} // end if

if ($donation) {
	$donation_checked = "checked='checked'";
} // end if

list($donation_dollar,$donation_cent) = preg_split("#\.#",$donation_amount);

if ($trial) {
	$trial_checked = "checked='checked'";
} // end if

list($trial_dollar,$trial_cent) = preg_split("#\.#",$trial_amount);

$trial_var = "trial_dur_$trial_duration";
${$trial_var} = "selected='selected'";

$trial_var = "trial_int_$trial_interval";
${$trial_var} = "selected='selected'";

if ($sub) {
	$sub_checked = "checked='checked'";
} // end if

list($sub_dollar,$sub_cent) = preg_split("#\.#",$sub_amount);

$sub_var = "sub_dur_$sub_duration";
${$sub_var} = "selected='selected'";

$sub_var = "sub_int_$sub_interval";
${$sub_var} = "selected='selected'";

$tabs = array(
	"{$ubbt_lang['TITLE']}" => "",
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['SUB_SETUP']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['TITLE']);
$admin->setParentTitle($ubbt_lang['SUB_SETUP']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/edit_subscription.tmpl");

$admin->sendFooter();
?>
