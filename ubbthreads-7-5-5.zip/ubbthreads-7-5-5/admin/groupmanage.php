<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/groupmanage.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();


$group = array();
// Grab all current groups that aren't disabled
$query = "
	SELECT GROUP_ID,GROUP_NAME,GROUP_IS_DISABLED,GROUP_POST_COUNT_JOIN,GROUP_IMAGE
	FROM {$config['TABLE_PREFIX']}GROUPS
	WHERE GROUP_IS_DISABLED <> '1'
	ORDER BY GROUP_ID
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$i=0;
while(list($gid,$gname,$gdisabled,$post_count,$image) = $dbh->fetch_array($sth)) {
	$group[$i]['id'] = $gid;
	$group[$i]['name'] = $gname;
	$group[$i]['post'] = $post_count;
	$group[$i]['image'] = "";
	if ($image) {
		$group[$i]['image'] = "<img src='{$config['BASE_URL']}/images/groups/$image' />";
	} // end if

	// Grab the total # of users in each group
	$query = "
		SELECT COUNT(*)
		FROM {$config['TABLE_PREFIX']}USER_GROUPS
		WHERE GROUP_ID = '$gid'
	";
	$stx = $dbh->do_query($query,__LINE__,__FILE__);
	list($group[$i]['users']) = $dbh->fetch_array($stx);
	$group[$i]['users'] = "<a href=\"{$config['BASE_URL']}/admin/membersearch.php?Group-$gid=$gid&newsearch=1\">{$group[$i]['users']}</a>";
	$i++;
}

// Grab all current groups that we can edit the permissions for
$query = "
	SELECT GROUP_ID,GROUP_NAME,GROUP_IS_DISABLED
	FROM {$config['TABLE_PREFIX']}GROUPS
	WHERE GROUP_IS_DISABLED <> '1'
	ORDER BY GROUP_ID
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$i=0;
$selectlist = "<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">";
$cols = 1;
while(list($gid,$gname) = $dbh->fetch_array($sth)) {
	$perm[$i]['id'] = $gid;
	$perm[$i]['name'] = $gname;
	$i++;
	if ($cols == 1) {
		$selectlist .= "<tr>";
	}
	if ($cols == 4) {
		$selectlist .= "</tr>";
		$cols = 1;
	}
	$selectlist .= <<<EOF
<td class="stdautorow colored-row">
<input type="checkbox" name="group$gid" onclick="show_group($gid,this.form.group$gid)" onchange="show_group($gid,this.form.group$gid)" id="group$gid" /> 
 <label class="radio" for="group$gid">$gname</label>
</td>
EOF;
	$cols++;
}

if ($cols < 4) {
	for ($i=$cols;$i<4;$i++) {
		$selectlist .= "<td class=\"stdautorow colored-row\">&nbsp;</td>";
	}
	$selectlist .= "</tr>";
}
$selectlist .="</table>";

$tabs = array(
	"{$ubbt_lang['G_EDIT']}" => "",
);

$admin->setCurrentMenu($ubbt_lang['GROUP_SET']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['GROUP_SET']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
$counter = 0;
include("../templates/default/admin/groupmanage.tmpl");

$bottom = array(
	"{$ubbt_lang['ADD_GROUP']}" => "creategroup.php"
);
$admin->createBottomTabs($bottom);
$admin->sendFooter();
?>
