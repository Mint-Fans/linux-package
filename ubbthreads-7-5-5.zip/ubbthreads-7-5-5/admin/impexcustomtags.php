<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/rebuildcontent.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// Get supplied operation
$op = get_input("op","get","","export");

// Setup the user and check permissions
$userob = new user;
$user = $userob->authenticate();

$admin = new Admin;
$admin->doAuth();

// Choose which operation to perform
if ($op == 'import') {
	// Setup the form to allow the user to select a file and submit
	$tabs = array(
		"{$ubbt_lang['BBCODE_IMPORT']}" => "",
	);

	// Create the Page
	$admin->setCurrentMenu($ubbt_lang['CONT_REBUILD']);
	$admin->setParentTitle($ubbt_lang['CONT_REBUILD'],"rebuildcontent.php?returtab=1");
	$admin->setPageTitle($ubbt_lang['BBCODE_IMPORT']);
	$admin->sendHeader();
	$admin->createTopTabs($tabs);

	// Include the template
	include("../templates/default/admin/impexcustomtags.tmpl");

	$admin->sendFooter();

} elseif ($op == 'export') {
	// Setup for the export
	header("Content-type: text/plain");
	header("Content-Disposition: attachment; filename=CustomTags.txt");
	header("Content-Description: UBBThreads content tags export");

	$export_tags = array();
	$query = "
		SELECT BBCODE_TAG, BBCODE_DESCRIPTION, BBCODE_MENU_PROMPT, BBCODE_MATCH_REGEX, BBCODE_MARKUP_RESULT
			FROM {$config['TABLE_PREFIX']}BBCODE
			ORDER BY BBCODE_MENU_ORDER, BBCODE_ID
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	$i = 0;
	while(list($tag, $descrip, $prompt, $regex, $markup) = $dbh->fetch_array($sth)) {
		$export_tags[$i]['tag'] = $tag;
		$export_tags[$i]['descrip'] = $descrip;
		$export_tags[$i]['prompt'] = $prompt;
		$export_tags[$i]['regex'] = $regex;
		$export_tags[$i]['markup'] = $markup;
		$i++;
	}


	echo "<?php\n\$export_tags = " . var_export($export_tags, true) . ";\n?>";

} else {
	// Must be an upload attempt submitted from the import screen
	if (empty($_FILES['tags']['tmp_name'])) {
		$admin->error($ubbt_lang['BBCODE_STAT_NOFILE']);
	}

	// Open this puppy and get contents, then process (imports to $export_tags)
	@include($_FILES['tags']['tmp_name']);

	// Don't enable imports by default. Force the admin to decide what to turn on
	$enabled = 0;
	$show = 0;
	$order = 0;
	$query = "
		INSERT INTO {$config['TABLE_PREFIX']}BBCODE
			(BBCODE_MENU_ORDER, BBCODE_MENU_SHOW, BBCODE_ENABLE, BBCODE_TAG, BBCODE_DESCRIPTION,
			 BBCODE_MENU_PROMPT, BBCODE_MATCH_REGEX, BBCODE_MARKUP_RESULT)
		VALUES
		( ? , ? , ? , ? , ? , ? , ? , ? )
	";
	foreach($export_tags as $custom) {
		$tag = $custom['tag'];
		$descrip = '[new]' . $custom['descrip'];
		$prompt = $custom['prompt'];
		$regex = $custom['regex'];
		$markup = $custom['markup'];

		$query_vars = array($order, $show, $enabled, $tag, $descrip, $prompt, $regex, $markup);
		$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	}

	// Redirect back to custom tag editor tab
	header("Location: {$config['BASE_URL']}/admin/rebuildcontent.php?op=imported");
}

?>
