<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/layout.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
error_reporting(7);

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("");

$admin = new Admin;

$admin->doAuth();

$tabs = array(
	"{$ubbt_lang['LAYOUT']}" => "",
);

$admin->setCurrentMenu($ubbt_lang['LAYOUT']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['LAYOUT']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

foreach($config['LEFT_COLUMN_BOXES'] as $pos => $island) {
	$left_select[$island][$pos] = "selected=\"selected\"";
} // end foreach

foreach($config['RIGHT_COLUMN_BOXES'] as $pos => $island) {
	$right_select[$island][$pos] = "selected=\"selected\"";
} // end foreach

foreach($config['BUILD_ISLANDS'] as $key => $island) {
	$build[$island] = "checked=\"checked\"";
} // end foreach

$names = array();

$islands = array(
	1 => "search",
	2 => "online_now",
	3 => "new_users",
	4 => "shoutbox",
	5 => "top_posters",
	6 => "top_posters_30",
	7 => "forum_stats",
	8 => "birthdays",
	9 => "featured_member",
	10 => "popular_topics",
);

if ($config['CALENDAR']) {
	$islands[] = "calendar";
	$islands[] = "public_calendar";
} // end if

foreach($islands as $k => $v) {
	$names[$v] = $ubbt_lang[$v];
} // end foreach

// Let's see what custom islands they have setup
$query = "
	select PORTAL_ID,PORTAL_NAME
	from {$config['TABLE_PREFIX']}PORTAL_BOXES
	where PORTAL_CUSTOM = '1'
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$i = 1;
while(list($portal_id,$portal_name) = $dbh->fetch_array($sth)) {
	if ($portal_name) {
		$names["portal_box_" . $portal_id] = "<a href=\"{$config['BASE_URL']}/admin/editcustomisland.php?island=$portal_id\">$portal_name</a>";
	} else {
		$names["portal_box_" . $portal_id] = "<a href=\"{$config['BASE_URL']}/admin/editcustomisland.php?island=$portal_id\">" . $ubbt_lang['portal_box'] . $i . "</a>";
	} // end if
	array_push($islands,"portal_box_{$portal_id}");
	$i++;
} // end while

// Let's see what post islands they have setup
$query = "
	select PORTAL_ID,PORTAL_NAME
	from {$config['TABLE_PREFIX']}PORTAL_BOXES
	where PORTAL_CUSTOM = '2'
	order by PORTAL_ID
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$i=1;
while(list($portal_id,$portal_name) = $dbh->fetch_array($sth)) {
	if ($portal_name) {
		$names["post_island_" . $portal_id] = "<a href=\"{$config['BASE_URL']}/admin/editpostisland.php?island=$portal_id\">$portal_name</a>";
	} else {
		$names["post_island_" . $portal_id] = "<a href=\"{$config['BASE_URL']}/admin/editpostisland.php?island=$portal_id\">" . $ubbt_lang['post_island'] . $i . "</a>";
	} // end if
	array_push($islands,"post_island_{$portal_id}");
	$i++;
} // end while

// Let's see what gallery islands they have setup
$query = "
	select PORTAL_ID,PORTAL_NAME
	from {$config['TABLE_PREFIX']}PORTAL_BOXES
	where PORTAL_CUSTOM = '3'
	order by PORTAL_ID
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$i=1;
while(list($portal_id,$portal_name) = $dbh->fetch_array($sth)) {
	if ($portal_name) {
		$names["gallery_island_" . $portal_id] = "<a href=\"{$config['BASE_URL']}/admin/editgalleryisland.php?island=$portal_id\">$portal_name</a>";
	} else {
		$names["gallery_island_" . $portal_id] = "<a href=\"{$config['BASE_URL']}/admin/editgalleryisland.php?island=$portal_id\">" . $ubbt_lang['gallery_island'] . $i . "</a>";
	} // end if
	array_push($islands,"gallery_island_{$portal_id}");
	$i++;
} // end while

// Include the template
include("../templates/default/admin/layout.tmpl");

//$admin->createBottomTabs($bottomtabs,0);

$admin->sendFooter();

?>
