<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/memberaction.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Get the input
$action = get_input("action","post");
$which = get_input("which","post");

if (!$action) {
	$admin->error($ubbt_lang['NO_ACTION']);
}

// Excluded results
$query = "
	SELECT ADMIN_SEARCH_REMOVED_RESULTS,ADMIN_SEARCH_TERMS
	FROM {$config['TABLE_PREFIX']}ADMIN_SEARCHES
	WHERE USER_ID='{$user['USER_ID']}'
	AND ADMIN_SEARCH_TYPE='member'
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
list($removed,$query) = $dbh->fetch_array($sth);
$removedinlist = "";
if ($removed) {
	$removedinlist = "AND USER_ID NOT IN ($removed)";
}

if ($which == "selected") {
	$inlist = "";
	$userarray = array();
	while(list($key,$value) = each($_POST)) {
		if (preg_match("/selected-/",$key)) {
			if ($value == $config['MAIN_ADMIN_ID'] && ($action == "delete" || $action == "ban" || $action == "unban")) {
				continue;
			}
			$inlist .= "'$value',";
			$userarray[] = $value;
		}
	}
	$inlist = preg_replace("/,$/","",$inlist);
	$sel_inlist = $inlist;

}
else {
	$query = "
		SELECT t1.USER_ID
		FROM {$config['TABLE_PREFIX']}USERS AS t1,
		{$config['TABLE_PREFIX']}USER_PROFILE as t2,
		{$config['TABLE_PREFIX']}USER_DATA as t3,
		{$config['TABLE_PREFIX']}USER_GROUPS as t4
		WHERE t1.USER_ID <> '1'
		and   t1.USER_ID = t2.USER_ID
		and   t1.USER_ID = t3.USER_ID
		and		t1.USER_ID = t4.USER_ID
		$query
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	$inlist = "";
	$userarray = array();
	while(list($number) = $dbh->fetch_array($sth)) {
		if ($number == $config['MAIN_ADMIN_ID'] && ($action == "delete" || $action == "ban" || $action == "unban")) {
			continue;
		}
		$inlist .= "'$number',";
		$userarray[] = $number;
	}
	$inlist = preg_replace("/,$/","",$inlist);
	$sel_inlist = "";
}

// Remove from the result list
if ($action == "remove" && $inlist) {
	if ($removed) {
		$removed = "$removed,$inlist";
	}
	else {
		$removed = $inlist;
	}
	$removedinlist = "AND USER_ID NOT IN ($removed)";
	$removed = addslashes($removed);
	$query = "
		UPDATE {$config['TABLE_PREFIX']}ADMIN_SEARCHES
		SET ADMIN_SEARCH_REMOVED_RESULTS='$removed'
		WHERE USER_ID = '{$user['USER_ID']}'
	";
	$dbh->do_query($query,__LINE__,__FILE__);
}
// Ban the users
if (($action == "ban") && $inlist) {
	$query = "
		UPDATE {$config['TABLE_PREFIX']}USERS
		SET USER_IS_BANNED='1'
		WHERE USER_ID IN ($inlist)
		$removedinlist
	";
	$dbh->do_query($query,__LINE__,__FILE__);
}
// Unban the users
if (($action == "unban") && $inlist) {
	$query = "
		UPDATE {$config['TABLE_PREFIX']}USERS
		SET USER_IS_BANNED='0'
		WHERE USER_ID IN ($inlist)
		$removedinlist
	";
	$dbh->do_query($query,__LINE__,__FILE__);
}
// Delete the users
if (($action == "delete") && $inlist) {
	for ($i=0;$i<sizeof($userarray);$i++) {
		$query = "
			SELECT USER_DISPLAY_NAME
			FROM {$config['TABLE_PREFIX']}USERS
			WHERE USER_ID='{$userarray[$i]}'
		";
		$sth = $dbh->do_query($query,__LINE__,__FILE__);
		list($uname) = $dbh->fetch_array($sth);
		$uname = addslashes($uname);
		// Set all posts to owned by anonymous
		$query = "
			UPDATE {$config['TABLE_PREFIX']}POSTS
			SET USER_ID = '1'
			WHERE USER_ID = '{$userarray[$i]}'
		";
		$dbh->do_query($query,__LINE__,__FILE__);
		
		
		// Delete private messages for this user
		$query = "
			select 	TOPIC_ID	
			from 		{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
			where		USER_ID = '{$userarray[$i]}'
		";
		$sth = $dbh->do_query($query,__LINE__,__FILE__);
		while(list($message_id) = $dbh->fetch_array($sth)) {
			$query = "
				delete from {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
				where	USER_ID = '{$userarray[$i]}'
				and	TOPIC_ID = '$message_id'
			";
			$dbh->do_query($query,__LINE__,__FILE__);
	
			$query = "
				select	count(*)
				from 	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
				where	TOPIC_ID = '$message_id'
			";
			$sth2 = $dbh->do_query($query,__LINE__,__FILE__);
			list($users) = $dbh->fetch_array($sth2);
			if ($users < 1) {
				$query = "
				DELETE FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS
				WHERE TOPIC_ID = '$message_id'
				";
				$dbh->do_query($query,__LINE__,__FILE__);
				$query = "
				DELETE FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
				WHERE TOPIC_ID = '$message_id'
				";
				$dbh->do_query($query,__LINE__,__FILE__);
			}
		}
		
	}
	// Delete from the users table
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}USERS
		WHERE USER_ID IN ($inlist)
	";
	$dbh->do_query($query,__LINE__,__FILE__);
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}USER_PROFILE
		WHERE USER_ID IN ($inlist)
	";
	$dbh->do_query($query,__LINE__,__FILE__);
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}USER_DATA
		WHERE USER_ID IN ($inlist)
	";
	$dbh->do_query($query,__LINE__,__FILE__);
	// Delete from the ratings table
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}RATINGS
		WHERE RATING_TARGET IN ($inlist)
	";
	$dbh->do_query($query,__LINE__,__FILE__);
	// Delete any pending display name changed
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}DISPLAY_NAMES
		WHERE USER_ID IN ($inlist)
	";
	$dbh->do_query($query,__LINE__,__FILE__);

	// Delete all favorites and reminders
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}WATCH_LISTS
		WHERE USER_ID IN ($inlist)
	";
	$dbh->do_query($query,__LINE__,__FILE__);

	
	// Delete any calendar events this user made
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}CALENDAR_EVENTS
		WHERE USER_ID IN ($inlist)
	";
	$dbh->do_query($query,__LINE__,__FILE__);
	// Set saved messages to the placeholder user
	$query = "
		UPDATE {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
		SET USER_ID='1'
		WHERE USER_ID IN ($inlist)
	";
	$dbh->do_query($query,__LINE__,__FILE__);
	// Set saved messages to the placeholder user
	$query = "
		UPDATE {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
		SET USER_ID='1'
		WHERE USER_ID IN ($inlist)
	";
	$dbh->do_query($query,__LINE__,__FILE__);
	// Delete from moderator list
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}MODERATORS
		WHERE USER_ID IN ($inlist)
	";
	$dbh->do_query($query,__LINE__,__FILE__);

	// Delete from USER_GROUPS
	$query = "
		delete from {$config['TABLE_PREFIX']}USER_GROUPS
		where USER_ID in ($inlist)
	";
	$dbh->do_query($query,__LINE__,__FILE__);

	// Update the boards table if they made the last post
	$query = "
		UPDATE {$config['TABLE_PREFIX']}FORUMS
		SET FORUM_LAST_POSTER_ID = '1',
		FORUM_LAST_POSTER_NAME = '{$ubbt_lang['ANON_TEXT']}'
		WHERE FORUM_LAST_POSTER_ID IN ($inlist)
	";
	$dbh->do_query($query,__LINE__,__FILE__);
	// Delete all last viewed entries for the user
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}CALENDAR_EVENTS
		WHERE USER_ID IN ($inlist)
	";
	$dbh->do_query($query,__LINE__,__FILE__);
	admin_log("DELETEUSERS", $inlist);
}

if ($action == "email" && $inlist) {
	define('EMAIL',1);
	include("emailusers.php");
}

if ($action == "group" && $inlist) {
	define("GROUP",1);
	include("changeusergroups.php");
}

$admin->redirect($ubbt_lang['PERFORMED'],"{$config['BASE_URL']}/admin/membersearch.php",$ubbt_lang['F_LOC']);
?>
