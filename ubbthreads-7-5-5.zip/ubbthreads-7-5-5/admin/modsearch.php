<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/modsearch.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$f = get_input("f","post");
$thisvar = get_input("thisvar","post");
$loginpdn = get_input("loginpdn","post");
$number = get_input("number","post");

// Grab the title of this forum
$query = "
	SELECT FORUM_TITLE
	FROM {$config['TABLE_PREFIX']}FORUMS
	WHERE FORUM_ID='$f'
";
$sth=$dbh->do_query($query,__LINE__,__FILE__);
list($ftitle) = $dbh->fetch_array($sth);

$extra = "";
if ($loginpdn) {
	$loginpdn = addslashes($loginpdn);
	$extra = "OR USER_LOGIN_NAME LIKE '%$loginpdn%' OR USER_DISPLAY_NAME LIKE '%$loginpdn%'";
}

// Grab all matches
$query = "
	SELECT USER_ID,USER_DISPLAY_NAME
	FROM {$config['TABLE_PREFIX']}USERS
	WHERE USER_ID='$number'
	AND USER_MEMBERSHIP_LEVEL = 'User'
	$extra
";
$sth=$dbh->do_query($query,__LINE__,__FILE__);

$existing = "";
while(list($unum,$uname) = $dbh->fetch_array($sth)) {

	if (!preg_match("/$unum/",$thisvar)) {
		$js_uname = preg_replace("/'/","\'",$uname);
		$existing .= <<<EOF

<tr>
<td class="stdautorow"><b>$uname</b> (# $unum)</td>
<td class="stdautorow">[<a href="{$config['BASE_URL']}/admin/showuser.php?uid=$unum" target="_blank">{$ubbt_lang['PROFILE']}</a>]</td>
<td class="stdautorow">[<a  id="promote-$unum" href="javascript:void(0);"
onclick="window.opener.add_moderator($f, '$unum', $unum, '$js_uname'); document.getElementById('promote-$unum').style.visibility='hidden';"
>{$ubbt_lang['ADD']}</a>]</td>
</tr>
EOF;
}
}

include("../templates/default/admin/modsearch.tmpl");
?>
