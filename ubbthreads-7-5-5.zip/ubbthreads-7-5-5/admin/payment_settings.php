<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/payment_settings.php");

// Get the input
$returntab = get_input("returntab","both");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$tabs = array(
	"{$ubbt_lang['PAYMENT_SET']}" => "",
);

// Paypal
if ($config['ALLOW_PAYPAL']) {
	$allow_paypal = "checked='checked'";
} // end if

// mail payment
$no_check_mo = "";
$check = "";
$mo = "";
$check_mo = "";
if ($config['ALLOW_MAIL'] == "check") {
	$check = "selected='selected'";
} elseif ($config['ALLOW_MAIL'] == "mo") {
	$mo = "selected='selected'";
} elseif ($config['ALLOW_MAIL'] == "check_mo") {
	$check_mo = "selected='selected'";
} else {
	$no_check_mo = "selected='selected'";
} // end if

// Currency
if ($config['CURRENCY'] == "CAD") {
	$cad = "selected='selected'";
} elseif ($config['CURRENCY'] == "EUR") {
	$eur = "selected='selected'";
} elseif ($config['CURRENCY'] == "GBP") {
	$gbp = "selected='selected'";
} elseif ($config['CURRENCY'] == "JPY") {
	$jpy = "selected='selected'";
} else {
	$usd = "selected='selected'";
}

// Create the Page
$admin->setCurrentMenu($ubbt_lang['PAYMENT_SET']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['PAYMENT_SET']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/payment_settings.tmpl");

$admin->sendFooter();
?>
