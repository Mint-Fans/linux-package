<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/primary.php");

// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME,USER_REAL_EMAIL");

$admin = new Admin;

$admin->doAuth();

// Set the default values
$isclosed_checked = "";
if ($config['BOARD_IS_CLOSED']) {
	$isclosed_checked = "checked=\"checked\"";
}

$MULTI_URL_checked = "";
if ($config['MULTI_URL']) {
	$MULTI_URL_checked = "checked=\"checked\"";
} // end if
$ubbt_lang['ALLOW_MULTI_URL_1'] = $html->substitute($ubbt_lang['ALLOW_MULTI_URL_1'],array("FULL_URL" => $config['FULL_URL']));

$usezlib_checked = "";
if ($config['ZLIB_COMPRESSION']) {
	$usezlib_checked = "checked=\"checked\"";
}

$log_mysql_checked = "";
if ($config['LOG_SQL_ERRORS']) {
	$log_mysql_checked = "checked=\"checked\"";
}

$log_refer_checked = "";
if ($config['LOG_REFERS']) {
	$log_refer_checked = "checked=\"checked\"";
} // end if

$DO_CENSOR_checked = "";
if ($config['DO_CENSOR']) {
	$DO_CENSOR_checked = "checked=\"checked\"";
}

$nofollow_post_checked = "";
$nofollow_sig_checked = "";
if ($config['NOFOLLOW_POST']) {
	$nofollow_post_checked = "checked=\"checked\"";
} // end if
if ($config['NOFOLLOW_SIG']) {
	$nofollow_sig_checked = "checked=\"checked\"";
} // end if

$DISABLE_REFERER_CHECK_checked = "";
if ($config['DISABLE_REFERER_CHECK']) {
	$DISABLE_REFERER_CHECK_checked = "checked=\"checked\"";
}

$search_urls_checked = "";
if ($config['SEARCH_FRIENDLY_URLS']) {
	$search_urls_checked = "checked=\"checked\"";
}

$search_html_ext_checked = "";
if ($config['SEARCH_FRIENDLY_HTML_EXT']) {
	$search_html_ext_checked = "checked=\"checked\"";
}

if (!$config['REPLACE_WORD']) {
	$config['REPLACE_WORD'] = "[censored]";
}

$debugging_checked = "";
if ($config['ALLOW_DEBUGGING']) {
	$debugging_checked = "checked=\"checked\"";
}

// Grab the current closed forum message
$closedmessage ="";
$closedfile = file("{$config['FULL_PATH']}/includes/closedforums.php");
while (list($linenum,$line) = each($closedfile)) {
	$closedmessage  .= "$line";
}

// Grab the censored words
$censorlist ="";
$query = "
	SELECT CENSOR_WORD,CENSOR_REPLACE_WITH
	FROM {$config['TABLE_PREFIX']}CENSOR_LIST
	ORDER BY CENSOR_WORD
";
$sth = $dbh->do_query($query);
while(list($cword,$creplace) = $dbh->fetch_array($sth)) {
	if ($creplace) {
		$censorlist .= "$cword=$creplace\n";
	}
	else {
		$censorlist .= "$cword\n";
	}
}

// Default board email address
if (!$config['SITE_EMAIL']) {
	$config['SITE_EMAIL'] = $user['USER_REAL_EMAIL'];
}

$tabs = array(
	"{$ubbt_lang['GENERAL']}" => "",
	"{$ubbt_lang['LOG_BACK']}" => "",
	"{$ubbt_lang['CENSOR']}" => "",
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['PRIMARY']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['PRIMARY']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);
$admin->setCommonSubmit($ubbt_lang['UPDATE']);

// Include the template
include("../templates/default/admin/primary.tmpl");

$admin->sendFooter();
?>
