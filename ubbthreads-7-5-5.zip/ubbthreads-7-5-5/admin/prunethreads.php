<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/prunethreads.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = 0;

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$tabs = array(
	"{$ubbt_lang['PRUNE_THREADS']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['PRUNE_THREADS']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['PRUNE_THREADS']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

$temp = getdate();
$thisyear = $temp["year"];
$thismonth = $temp["mon"];
$thisday = $temp["mday"];

// Build the year list
$yearlist = "<select name=\"olderyear\">";
$yearlist .= "<option selected=\"selected\"></option>";
for ($i=$thisyear;$i>1990;$i--) {
	$yearlist .= "<option>$i</option>";
}
$yearlist .= "</select>";

// Build the month list
$monthlist = "<select name=\"oldermonth\">";
$monthlist .= "<option selected=\"selected\"></option>";
for ($i=1;$i<=12;$i++) {
	$month = "MONTH$i";
	$monthlist .= "<option value=\"$i\">{$ubbt_lang[$month]}</option>";
}
$monthlist .= "</select>";

// Build the day list
$daylist = "<select name=\"olderday\">";
$daylist .= "<option selected=\"selected\"></option>";
for ($i=1;$i<=31;$i++) {
	$daylist .= "<option value=\"$i\">$i</option>";
}
$daylist .= "</select>";

$yearlist_n = preg_replace("/olderyear/","neweryear",$yearlist);
$monthlist_n = preg_replace("/oldermonth/","newermonth",$monthlist);
$daylist_n = preg_replace("/olderday/","newerday",$daylist);

$sourcelist = "<select name=\"source[]\" multiple=\"multiple\" size=\"10\">";
$sourcelist .= "<option value=\"allforums\">{$ubbt_lang['ALLFORUMS']}</option>";
$initialcat = "";

include("{$config['FULL_PATH']}/cache/forum_cache.php");
if (!sizeof($tree)) {
	list($tree,$style_cache,$lang_cache) = build_forum_cache();
}
		
$category = "";
$forums = 0;
foreach($tree['categories'] as $cat => $cat_title) {
	$category = "";
	$forums = 0;
	$category .= "<option value=\"category\">$cat_title ------</option>";
	if (!isset($tree[$cat])) continue;
	foreach($tree[$cat] as $forum_id => $forum_title) {
		$category .= "<option value=\"$forum_id\">$forum_title</option>";
		$forums++;
	}
	if ($forums) $sourcelist .= $category;
}
		
$sourcelist .= "</select>";

// Include the template
include("../templates/default/admin/prunethreads.tmpl");

$admin->sendFooter();
?>
