<?php
//  Whoops!  If you see this text in your browser,
//  your web hosting provider has not installed PHP.
//
//  You will be unable to use UBB until PHP has been properly installed.
//
//  You may wish to ask your web hosting provider to install PHP.
//  Both Windows and Unix versions are available on the PHP website,
//  http://www.php.net/
//
//
//
//  Ultimate Bulletin Board
//  Script Version 7.5.5
//
//  Program authors: Rick Baker
//  Copyright (C) 2010 Mindraven.
//
//  You may not distribute this program in any manner, modified or
//  otherwise, without the express, written consent from
//  Mindraven.
//
//  You may make modifications, but only for your own use and
//  within the confines of the UBB License Agreement
//  (see our website for that).
//
//  Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");
require("../languages/{$config['LANGUAGE']}/admin/rebuildcontent.php");

// --------------
// Get the inputs
$returntab = get_input("returntab","both");
if (!$returntab) { $returntab = 0; }

// -----------------
// Get the user info
$userob = new user;
$user = $userob->authenticate();
$html = new html;

$admin = new Admin;
$admin->doAuth();

// Tab 0 contents
$types = array(
	'rebuild' => array(
		array("posts","POSTS"),
		array("topics","TOPICS"),
		array("forums","FORUMS"),
		array("postcounts","POST_COUNTS"),
		array("signatures","SIGNATURES"),
		array("private_messages","PMS"),
	),
	'prune' => array(
		array("pruneorphans","PT_ORPHANS",),
	),
);

// Tab 1 operations
$op = get_input("op","both");
if ($op) {
	$returntab = 1;
	if ($op == "addnew" || $op == "update") {

		// Clean inputs as best as we can
		$order = get_input("order","post");
		if (!$order || !is_numeric($order)) {
			$order = 0;
		}
		$enabled = get_input("enabled","post");
		if (!$enabled) {
			$enabled = 0;
		}
		$show = get_input("show","post");
		if (!$show) {
			$show = 0;
		}
		$tag = get_input("tag","post");
		if (!$tag) {
			$tag = '[media]';
		} else {
			$tag = str_replace(array(']','['),'',$tag);
		}
		$description = get_input("description","post");
		if (!$description) {
			$description = 'Default description';
		} else {
		}
		$prompt = get_input("prompt","post");
		if (!$prompt) {
			$prompt = 'Paste clipboard here:';
		} else {
		}
		$regex = get_input("regex","post");
		$markup = get_input("markup","post");
		if (!$regex || !$markup) {
			$user_message = $ubbt_lang['BBCODE_STAT_BAD'];
		} else {
			if ($op == "addnew") {
				$user_message = $ubbt_lang['BBCODE_STAT_CREATED'];

				// Insert this puppy into the DB
				$query_vars = array($order, $show, $enabled, $tag, $description, $prompt, $regex, $markup);
				$query = "
					INSERT INTO {$config['TABLE_PREFIX']}BBCODE
						(BBCODE_MENU_ORDER, BBCODE_MENU_SHOW, BBCODE_ENABLE, BBCODE_TAG, BBCODE_DESCRIPTION,
						 BBCODE_MENU_PROMPT, BBCODE_MATCH_REGEX, BBCODE_MARKUP_RESULT)
					VALUES
					( ? , ? , ? , ? , ? , ? , ? , ? )
				";
				$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
				} else {
					$user_message = $ubbt_lang['BBCODE_STAT_EDITED'];
					$which = get_input("which","post");
					$query_vars = array($order, $show, $enabled, $tag, $description, $prompt, $regex, $markup, $which);
					$query = "
						UPDATE {$config['TABLE_PREFIX']}BBCODE
						SET
							BBCODE_MENU_ORDER = ?,
							BBCODE_MENU_SHOW = ?,
							BBCODE_ENABLE = ?,
							BBCODE_TAG = ?,
							BBCODE_DESCRIPTION = ?,
							BBCODE_MENU_PROMPT = ?,
							BBCODE_MATCH_REGEX = ?,
							BBCODE_MARKUP_RESULT = ?
						WHERE BBCODE_ID = ?
					";
					$sth = $dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
				}
			}
		} elseif ($op == "delete") {
			$user_message = $ubbt_lang['BBCODE_STAT_DELETE'];
			$which = get_input("which","get");
			$query = "
				DELETE FROM {$config['TABLE_PREFIX']}BBCODE
				WHERE	BBCODE_ID = $which
			";
			$sth = $dbh->do_query($query,__LINE__,__FILE__);
		}

		// Now that we've done the deed, just clean up vars so the form is clean
		$order = ''; $show = ''; $enabled = ''; $tag = ''; $description = '';
		$regex = ''; $markup = ''; $which = ''; $prompt = '';

		// Also rebuild our cache for others to use (very much like $tree)
		build_custom_tag_cache();
	} elseif ($op == "imported") {
		$user_message = $ubbt_lang['BBCODE_STAT_IMPORTED'];
	}

// Get the current Media stuff
$media = array();
$i = 0;
$query = "
	SELECT BBCODE_ID, BBCODE_MENU_ORDER, BBCODE_MENU_SHOW, BBCODE_ENABLE, BBCODE_TAG,
	       BBCODE_DESCRIPTION, BBCODE_MENU_PROMPT, BBCODE_MATCH_REGEX, BBCODE_MARKUP_RESULT
		FROM {$config['TABLE_PREFIX']}BBCODE
	ORDER BY BBCODE_MENU_ORDER, BBCODE_ID
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while (list($mID, $morder, $mshow, $menabled, $mtag, $mdescription, $mprompt, $mregex, $mmarkup) = $dbh->fetch_array($sth)) {
	$media[$i]['ID'] = $mID;
	$media[$i]['order'] = $morder;
	$media[$i]['show'] = ($mshow) ? 'checked' : '';
	$media[$i]['enable'] = ($menabled) ? 'checked' : '';
	$media[$i]['tag'] = $mtag;
	$media[$i]['description'] = $mdescription;
	$media[$i]['prompt'] = $mprompt;
	$media[$i]['regex'] = $mregex;
	$media[$i]['markup'] = $mmarkup;
	$i++;
}

$tabs = array(
	"{$ubbt_lang['REBUILD_TITLE']}" => "",
	"{$ubbt_lang['BBCODE_TITLE']}" => "",
);

$admin->setCurrentMenu($ubbt_lang['CONT_REBUILD']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['CONT_REBUILD']);
$admin->setReturnTab($returntab);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

include("../templates/default/admin/rebuildcontent.tmpl");

// Bottom tabs for Tab 1
$bottomtabs = array(
	"{$ubbt_lang['BBCODE_ADDNEW']}" => "javascript:void(0);\" onclick=\"addNew();\"",
	"{$ubbt_lang['BBCODE_EXPORT']}" => "{$config['BASE_URL']}/admin/impexcustomtags.php?op=export",
	"{$ubbt_lang['BBCODE_IMPORT']}" => "{$config['BASE_URL']}/admin/impexcustomtags.php?op=import",
);

$admin->createBottomTabs($bottomtabs,1);
$admin->sendFooter();

?>
