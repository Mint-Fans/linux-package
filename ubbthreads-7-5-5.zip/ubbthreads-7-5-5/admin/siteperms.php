<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/siteperms.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();


$perm_list = array();
$query = "
	select PERMISSION_NAME,PERMISSION_IS_HIGH,PERMISSION_IS_LOW
	from {$config['TABLE_PREFIX']}PERMISSION_LIST
	where PERMISSION_TYPE='site'
	order by PERMISSION_ORDER
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while($row = $dbh->fetch_array($sth)) {
	$perm_list[] = $row;
} // end while

$perms = array();
$query = "
	select *
	from {$config['TABLE_PREFIX']}SITE_PERMISSIONS
	order by GROUP_ID
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while($row = $dbh->fetch_array($sth,MYSQL_ASSOC)) {
	foreach($row as $k => $v) {
		if ($k == "GROUP_ID") {
			$gid = $v;
			continue;
		}
		$perms[$k][$gid] = $v;
	}
}


// Now grab all groups
$groups = array();
$query = "
	select GROUP_ID,GROUP_NAME
	from {$config['TABLE_PREFIX']}GROUPS
	where GROUP_IS_DISABLED = '0'
	order by GROUP_ID
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while(list($gid,$gname) = $dbh->fetch_array($sth)) {
	$groups[$gid] = $gname;
} // end while



$tabs = array(
	"{$ubbt_lang['SITE_PERMS']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['SITE_PERMS']);
$admin->setPageTitle($ubbt_lang['SITE_PERMS']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
include("../templates/default/admin/siteperms.tmpl");

$admin->sendFooter();
?>
