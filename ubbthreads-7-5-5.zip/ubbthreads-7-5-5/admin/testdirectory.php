<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/testdirectory.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$type = get_input("type","get");
$dirname = get_input("dirname","get");

// -----------------
// Get the user info
$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");
$html = new html;

$admin = new Admin;

$admin->doAuth();



// -----------------------------
// Make sure they should be here
if ($user['USER_MEMBERSHIP_LEVEL'] != 'Administrator'){
	$html -> not_right ("{$ubbt_lang['ADMIN_ONLY']}");
}

// ------------------------
// Send them a confirmation
$results = "";
if (file_exists($dirname)) {
	$results .= "{$ubbt_lang['EXIST']} ";
	$check = @fopen("$dirname/test.file","w");
	if (!$check) {
		$results .= sprintf('<span style="color: #F00;">%s</span>', $ubbt_lang['NOWRITE']);
		$error = 1;
	}
	else {
		$results .= sprintf('<span style="color: #0F0;">%s</span>', $ubbt_lang['CANWRITE']);
	}
}
else {
	$results .= sprintf('<span style="color: #F00;">%s</span>', $ubbt_lang['NOEXIST']);
	$error = 1;
}

if (isset($error)) {
	$results .= "<br />{$ubbt_lang['FAIL']}";
	if ($type=="sess") {
		$results .= " {$ubbt_lang['SESS']}";
	}
}
else {
	$results .= "<br /><br />{$ubbt_lang['PASS']}";
}
include("../templates/default/admin/testdirectory.tmpl");
?>
