<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","both");

// -----------------
// Get the user info
$userob = new user;
$user = $userob->authenticate();

$admin = new Admin;
$admin->doAuth();

foreach($_POST['single_rss'] as $feed => $forum_id) {
	$cache = $_POST['single_cache'][$feed];
	$active = $_POST['single_active'][$feed];
	$name = stripslashes($_POST['single_name'][$feed]);
	if (!$cache) {$cache = 5; }
	$cache = $cache * 60;
	if (!$active) $active = 0;
	$query_vars = array($active,$cache,$name,$feed);
	$query = "
		update {$config['TABLE_PREFIX']}RSS_FEEDS
		set FEED_IS_ACTIVE = ? ,
				FEED_CACHE_TIME = ? ,
				FEED_NAME = ?
		where FEED_ID = ?
	";
	$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

	$query_vars = array($active,$name,$forum_id);
	$query = "
		update {$config['TABLE_PREFIX']}FORUMS
		set FORUM_IS_RSS = ? ,
				FORUM_RSS_TITLE = ?
		where FORUM_ID = ?
	";
	$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
}

generate_rss_feeds(1);

// What config vars are we updating?
$newconfig = array("MY_FEEDS");

// Update the config file
include("doeditconfig.php");

// ---------------
// Log this action
admin_log("RSS","$log_diffs");

$admin->redirect($ubbt_lang['RSS_UPDATED'],"{$config['BASE_URL']}/admin/rss.php?returntab=$returntab",$ubbt_lang['RSS_F_LOC']);
?>