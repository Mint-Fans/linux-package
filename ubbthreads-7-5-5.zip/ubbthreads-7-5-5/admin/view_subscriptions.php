<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/view_subscriptions.php");

// Get the input
$returntab = get_input("returntab","both");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Grab any filter params
$active = get_input("active","post","");
$status = get_input("status","post","");
$group = get_input("group","post","");
$username = get_input("username","post","");
$invoice = get_input("invoice","post","");
$custom = get_input("custom","post","");
$txn = get_input("txn","post","");
$filter = get_input("filter","post","");
$page = get_input("page","get","");

if (!$page) $page = 1;

if (!$filter) {
	$filter_array = unserialize($_SESSION['filter_array']);
	$active = $filter_array['active'];
	$status = $filter_array['status'];
	$group = $filter_array['group'];
	$username = $filter_array['username'];
	$invoice = $filter_array['invoice'];
	$custom = $filter_array['custom'];
	$txn = $filter_array['txn'];
} // end if

$clause = "";

$any_active = "";
$yes_active = "";
$no_active = "";

if ($active == "") {
	$any_active = "selected='selected'";
} // end if
if ($active == "0") {
	$no_active = "selected='selected'";
} // end if
if ($active == "1") {
	$yes_active = "selected='selected'";
} // end if


if ($status == "") {
	$any_status = "selected='selected'";
} // end if
if ($status == "FREE TRIAL") {
	$ft_status = "selected='selected'";
} // end if
if ($status == "PAYMENT RECEIVED") {
	$pr_status = "selected='selected'";
} // end if
if ($status == "PAYMENT PENDING") {
	$pp_status = "selected='selected'";
} // end if
if ($status == "DONATION") {
	$d_status = "selected='selected'";
} // end if
if ($status == "PAYMENT FAILED") {
	$pf_status = "selected='selected'";
} // end if
if ($status == "PAYMENT DENIED") {
	$pd_status = "selected='selected'";
} // end if
if ($status == "SUBSCRIPTION FAILED") {
	$sf_status = "selected='selected'";
} // end if
if ($status == "EOT") {
	$eot_status = "selected='selected'";
} // end if
if ($status == "CANCELED") {
	$c_status = "selected='selected'";
} // end if
if ($status == "REFUND") {
	$ref_status = "selected='selected'";
} // end if
if ($status == "REVERSAL") {
	$rev_status = "selected='selected'";
} // end if
if ($status == "CANCELED REVERSAL") {
	$cr_status = "selected='selected'";
} // end if

if ($filter || sizeof($filter_array)) {

	$filter_array['active'] = $active;
	if ($active != "") {
		$active = addslashes($active);
		$clause = " and t1.SUBSCRIPTION_IS_ACTIVE = '$active'";
	} // end if

	$filter_array['status'] = $status;
	if ($status != "") {
		$status = addslashes($status);
		$clause .= " and t1.SUBSCRIPTION_STATUS = '$status'";
	} // end if

	$filter_array['group'] = $group;	
	if ($group != "") {
		$group = addslashes($group);
		$clause .= " and t3.GROUP_ID = '$group'";
	} // end if
	
	$filter_array['username'] = $username;
	if ($username != "") {
		$query = "
			select USER_ID
			from {$config['TABLE_PREFIX']}USERS
			where USER_DISPLAY_NAME = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($username),__LINE__,__FILE__);
		list ($uid) = $dbh->fetch_array($sth);
	
		$clause .= " and t1.USER_ID = '$uid'";
	} // end if
	
	$filter_array['custom'] = $custom;
	if ($custom != "") {
		$custom = addslashes($custom);
		$clause .= " and t1.CUSTOM_ID = '$custom'";
	} // end if
	
	$filter_array['txn'] = $txn;
	if ($txn != "") {
		$query = "
			select CUSTOM_ID
			from {$config['TABLE_PREFIX']}PAYPAL_DATA
			where TXN_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($txn),__LINE__,__FILE__);
		list ($inv) = $dbh->fetch_array($sth);
		
		$clause .= " and t1.CUSTOM_ID = '$inv'";
	} // end if

	$_SESSION['filter_array'] = serialize($filter_array);
	
} // end if

// Get all groups
$query = "
	select SUBSCRIPTION_NAME,GROUP_ID
	from {$config['TABLE_PREFIX']}SUBSCRIPTIONS
	order by GROUP_ID
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$sub_groups = "";
while(list($sub_name,$g_id) = $dbh->fetch_array($sth)) {
	$selected = "";
	if ($group == $g_id) {
		$selected = "selected='selected'";
	} // end if
	$sub_groups .="<option $selected value='$g_id'>$sub_name</option>";
} // end while

$query = "
	select count(t1.SUBSCRIPTION_ID)
	from {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA as t1,
	{$config['TABLE_PREFIX']}USERS as t2,
	{$config['TABLE_PREFIX']}SUBSCRIPTIONS as t3
	where t1.USER_ID = t2.USER_ID
	and t1.GROUP_ID = t3.GROUP_ID
	$clause
	order by t1.SUBSCRIPTION_ID desc
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
list($total_rows) = $dbh->fetch_array($sth);


if ($page == 1) {
	$limit = "LIMIT 1";
} else {
	$limit = "LIMIT " . (($page - 1) * 1) . ",1";
} // end if

// Setup the pages
$totalpages = ceil($total_rows / 1);
for ($i=1;$i<=$totalpages;$i++) {
	if ($i == $page) {
		$pageprint .= $i . " ";
	} else {
		$pageprint .= "<a href=\"view_subscriptions.php?page=$i\">$i</a> ";
	} // end if
} // end if

$query = "
	select t1.SUBSCRIPTION_ID,t2.USER_DISPLAY_NAME,t3.SUBSCRIPTION_NAME,t1.SUBSCRIPTION_START_DATE,t1.SUBSCRIPTION_END_DATE,t1.SUBSCRIPTION_STATUS,t1.SUBSCRIPTION_IS_ACTIVE,t1.SUBSCRIPTION_PAYMENT,t1.USER_ID,t3.GROUP_ID
	from {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA as t1,
	{$config['TABLE_PREFIX']}USERS as t2,
	{$config['TABLE_PREFIX']}SUBSCRIPTIONS as t3
	where t1.USER_ID = t2.USER_ID
	and t1.GROUP_ID = t3.GROUP_ID
	$clause
	order by t1.SUBSCRIPTION_ID desc
	$limit
";

$sth = $dbh->do_query($query,__LINE__,__FILE__);
while(list($invoice_no,$user,$name,$start,$end,$status,$active,$payment,$uid,$group_id) = $dbh->fetch_array($sth)) {
	if ($active) {
		$active = $ubbt_lang['TEXT_YES'];
	} else {
		$active = $ubbt_lang['TEXT_NO'];
	} // end if

	if (!$end) {
		$end = $ubbt_lang['NO_END'];
	} else {
		$end = $html->convert_time($end);
	} // end if
	
	if (!$start) {
		$start = $ubbt_lang['NOT_STARTED'];
	} else { 
		$start = $html->convert_time($start);
	} // end if

	$subs[] = array(
		"invoice_no" => $invoice_no,
		"user" => $user,
		"name" => $name,
		"start" => $start,
		"end" => $end,
		"status" => $status,
		"active" => $active,
		"payment" => $payment,
		"uid" => $uid,
		"group_id" => $group_id,
	);
} // end while



$tabs = array(
	"{$ubbt_lang['VIEW_SUBS']}" => "",
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['VIEW_SUBS']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['VIEW_SUBS']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/view_subscriptions.tmpl");

$admin->sendFooter();
?>
