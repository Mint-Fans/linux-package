<?php
define('UBB_MAIN_PROGRAM', 1);

// Setup the smarty class
require_once('../libs/smarty/Smarty.class.php');
$smarty = new Smarty();
$smarty->template_dir = 'templates/default';
$smarty->compile_dir = 'templates/compile';
// include all of the required libraries
require_once( "../libs/phpmailer/class.phpmailer.php" );
require_once( "../includes/config.inc.php" );
require_once( "../libs/mysql.inc.php" );
require_once("../libs/bbcode.inc.php");
require_once("../styles/wrappers.php");
require_once("../libs/html.inc.php");
require_once("../libs/user.inc.php");
require_once("../libs/ubbthreads.inc.php");
$html = new html;

rebuild_islands();

?>
