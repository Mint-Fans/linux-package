<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if (!defined('UBB_MAIN_PROGRAM')) {
	exit;
}

$query = "
	SELECT count(USER_ID)
		FROM {$config['TABLE_PREFIX']}USERS
	WHERE USER_IS_APPROVED = 'yes'
		AND	USER_ID > 1
";
$sth = $dbh->do_query($query);
list($total) = $dbh->fetch_array($sth);

$query = "
		select u.USER_DISPLAY_NAME,u.USER_ID,u.USER_MEMBERSHIP_LEVEL,p.USER_NAME_COLOR
		from {$config['TABLE_PREFIX']}USERS as u,
		{$config['TABLE_PREFIX']}USER_PROFILE as p
		where u.USER_IS_APPROVED='yes'
		and u.USER_ID = p.USER_ID
		and u.USER_IS_BANNED = '0'
		and u.USER_ID <> '1'
		order by u.USER_ID desc limit 5
";
$sth = $dbh->do_query($query);
$users = array();
$i=0;
while(list($uname,$uid,$level,$color) = $dbh->fetch_array($sth)) {
	$users[$i]['name'] = $html->user_color($uname, $color, $level);
	$users[$i]['uid'] = $uid;
	$i++;
} // end while

$smarty->assign("users",$users);
$smarty->assign("total",$total);

$island = $smarty->fetch("island_new_users.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/new_users.php",$island);

@chmod("{$config['FULL_PATH']}/cache/new_users.php",0666);

?>
