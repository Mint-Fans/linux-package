<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if (!defined('UBB_MAIN_PROGRAM')) exit;

// J.I.C.
global $html, $dbh, $userob;

// Grab spider-list
$spiders_list = get_spider_list();


// Grab total # of registered/anonymous users online
$Outdated = $html->get_date() - ( $config['ONLINE_TIME'] * 60 );

// Now grab the most recent visitors
$query = "
	SELECT	USER_ID, ONLINE_USER_TYPE, ONLINE_AGENT, ONLINE_LAST_ACTIVITY
	FROM	{$config['TABLE_PREFIX']}ONLINE
	WHERE	ONLINE_LAST_ACTIVITY > '$Outdated'
	order by ONLINE_LAST_ACTIVITY desc
";

$users_times = array();
$users = array();
$spiders = array();
$spider_cache = array();
$order = array();

$reg = 0;
$anon = 0;
$invisible = 0;
$spi = 0;

$user_total = 0;

$temp_result = array();

$sth = $dbh->do_query( $query, __LINE__, __FILE__ );

while( $result = $dbh->fetch_array( $sth ) ) {
	$temp_result[] = $result;
}

foreach( $temp_result as $result ) {

	list( $id, $type, $agent, $time ) = $result;
	if( $type == "r" ) {
		$users_times["$id"] = $time;
		$order[] = $id;
	} else {
		if( ! isset( $spiders_cache[$agent] ) ) {
			$is_spider = false;
			foreach( $spiders_list as $k => $spidey ) {
				if( preg_match( "#" . preg_quote( $spidey, "#" ) . "#i", $agent ) ) {
					$spiders_cache[$agent] = $k;
					$spiders[] = $k;
					$is_spider = true;
					$spi++;
					break;
				}
			}

			// We're a guest but not a spider
			if( ! $is_spider ) $anon++;
		} else {
			$spiders[] = $spiders_cache[$agent];
			$spi++;
		}
	}
}
unset( $spiders_cache );


if (count($users_times) > 0 || ($userob->is_logged_in && $user['USER_ID'] != 1)) {
	if( $userob->is_logged_in && !isset($users_times[$user['USER_ID']]) ) {
		$users_times[$result['USER_ID']] = $html->get_date();
	}

	// Now get's get info about the user's we have
	$query = "
		SELECT	t1.USER_ID, t1.USER_DISPLAY_NAME, t1.USER_MEMBERSHIP_LEVEL, t2.USER_NAME_COLOR, t2.USER_VISIBLE_ONLINE_STATUS
		FROM	{$config['TABLE_PREFIX']}USERS as t1
		LEFT JOIN	{$config['TABLE_PREFIX']}USER_PROFILE as t2
		ON t1.USER_ID = t2.USER_ID
		WHERE	t1.USER_ID in ( ? ) AND t1.USER_ID <> 1
		order by t1.USER_DISPLAY_NAME asc
	";
	$sth = $dbh->do_placeholder_query( $query, array( array_keys($users_times) ), __LINE__, __FILE__ );

	$users = array();

	// All times should be relative
	$old_relative_setting = $config['RELATIVE_TIME'];
	$old_user_relative_setting = $user['USER_RELATIVE_TIME'];

	$config['RELATIVE_TIME'] = true;
	$user['USER_RELATIVE_TIME'] = '1';

	while( $result = $dbh->fetch_array( $sth ) ) {
		if ($config['DISABLE_ONLINE_INVISIBLE'] || $result['USER_VISIBLE_ONLINE_STATUS'] == "yes") {
			$name_color = $html->user_color($result['USER_DISPLAY_NAME'], $result['USER_NAME_COLOR'], $result['USER_MEMBERSHIP_LEVEL']);
			$reg++;

			if (!$config['TOTAL_ONLINE'] || $reg <= $config['TOTAL_ONLINE']) {
        if (!isset($users[$result['USER_ID']])) {
				  $users[$result['USER_ID']] = array(
					  'ID' => $result['USER_ID'],
					  'NAME' => $result['USER_DISPLAY_NAME'],
					  'NAME_COLOR' => $name_color,
					  'LAST_ACTIVE' => $html->convert_time($users_times[$result['USER_ID'].""],0,"",false,0),
				  );
        }
			}
		} else {
			$invisible++;
			$reg++;
		}
	}
	$config['RELATIVE_TIME'] = $old_relative_setting;
	$user['USER_RELATIVE_TIME'] = $old_user_relative_setting;
}

$users_sorted = array();
foreach($order as $k => $v) {
	if (!$users[$v]) continue;
	$users_sorted[] = $users[$v];
}

$smarty->assign("registered", $reg);
$smarty->assign("anonymous", $anon);
$smarty->assign("users", $users_sorted);
$smarty->assign("invisible", $invisible);
$smarty->assign("spiders", $spi);

$island = $smarty->fetch("island_whos_online.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/online_now.php",$island);

@chmod("{$config['FULL_PATH']}/cache/online_now.php",0666);

?>
