<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if (!defined('UBB_MAIN_PROGRAM')) {
	exit;
}

if (!$name) $name = "Post Island $portal_id";

$smarty->assign("name",$name);

if (!$forums) return;

$forums = unserialize($forums);

if (!sizeof($forums)) return;
$inlist = "";
if (in_array("allforums",$forums)) {
	$forum_clause = "";
} else {
	foreach($forums as $k => $forum) {
		$inlist .= "'$forum',";
	} // end foreach
	$inlist = preg_replace("/,$/","",$inlist);
	$forum_clause = "and t1.FORUM_ID in  ($inlist)";
}


// Topics or Posts?
if ($type == "topics") {
	$order = "t1.TOPIC_CREATED_TIME desc";
} else {
	$order = "t1.TOPIC_LAST_REPLY_TIME desc";
} // end if

if (!$items) {
	$items = 5;
} // end if

$html = new html;

$one_month = $html->get_date() - (86400 *30);
	
$query = "
	select t1.TOPIC_ID,t1.POST_ID,t1.TOPIC_SUBJECT,t1.TOPIC_CREATED_TIME,t1.TOPIC_LAST_REPLY_TIME,t1.TOPIC_LAST_POST_ID,t1.TOPIC_LAST_POSTER_ID,t1.TOPIC_LAST_POSTER_NAME,t1.TOPIC_POSTER_NAME
	from {$config['TABLE_PREFIX']}TOPICS as t1,
	{$config['TABLE_PREFIX']}FORUMS as t2
	where t2.FORUM_IS_GALLERY='0'
	and t1.FORUM_ID = t2.FORUM_ID
	and t1.TOPIC_IS_APPROVED = '1'
	and t1.TOPIC_LAST_REPLY_TIME > $one_month
	and t1.TOPIC_STATUS <> 'M'
	$forum_clause
	ORDER BY $order
	limit $items
";

$sth = $dbh->do_query($query,__LINE__,__FILE__);
$items = array();
$latest = 0;
while($posts = $dbh->fetch_array($sth)) {
	if ($posts['TOPIC_LAST_REPLY_TIME'] > $latest) {
		$latest = $posts['TOPIC_LAST_REPLY_TIME'];
	}
	if (isset($posts['POST_BODY'])) {
		$posts['POST_BODY'] = substr($posts['POST_BODY'],0,$feed_include_body);
		if ($type == "posts") {
			$posts['TOPIC_SUBJECT'] = "Re: {$posts['TOPIC_SUBJECT']}";
		} // end if
	} // end if
	$words = explode(" ", $posts['TOPIC_SUBJECT']);
	foreach ($words as $i => $w) {
		if ( strlen ( html_entity_decode($words[$i]) ) > 20 ) {
			$words[$i] = $html->utf8_wordwrap($words[$i], 20, "<br />", 1);
		} // end if
	} // end foreach
	$posts['TOPIC_SUBJECT'] = implode(" ", $words);
		
	if ($type == "topics") {
		$posts['TOPIC_LAST_POSTER_NAME'] = $posts['TOPIC_POSTER_NAME'];
		$posts['TOPIC_LAST_REPLY_TIME'] = $html->convert_time($posts['TOPIC_CREATED_TIME']);
	} else {
		$posts['TOPIC_LAST_REPLY_TIME'] = $html->convert_time($posts['TOPIC_LAST_REPLY_TIME']);
	}
	
	$items[] = $posts;
} // end while
		
$smarty->assign_by_ref("items",$items);
$smarty->assign("island",$portal_id);
$smarty->assign("type",$type);
$island = $smarty->fetch("post_island.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/post_island_$portal_id.php",$island);

@chmod("{$config['FULL_PATH']}/cache/post_island_$portal_id.php",0666);

?>
