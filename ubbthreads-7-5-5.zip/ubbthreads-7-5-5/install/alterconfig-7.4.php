<?php
$newconfigs['MULTI_URL'] = '0';
$newconfigs['MAX_WIDTH_IMAGE'] = '400';
?>
