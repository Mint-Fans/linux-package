<?php
$newconfigs['LOG_REFERS'] = '1';
$newconfigs['CALENDAR'] = '1';
$newconfigs['NOFOLLOW_POST'] = '1';
$newconfigs['NOFOLLOW_SIG'] = '1';
$newconfigs['NESTED_QUOTES'] = '4';
$newconfigs['COMMENTS_MIN_POST'] = '25';
?>
