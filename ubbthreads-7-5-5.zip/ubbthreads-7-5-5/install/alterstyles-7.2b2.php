<?php
$newstyles['.new-alt-newintopic']['copy'] = ".newintopic";
$newstyles['.new-alt-topicicon']['copy'] = ".topicicon";
$newstyles['.new-alt-topicsubject']['copy'] = ".topicsubject";
$newstyles['.new-alt-topicreplies']['copy'] = ".topicreplies";
$newstyles['.new-alt-topicviews']['copy'] = ".topicviews";
$newstyles['.new-alt-topictime']['copy'] = ".topictime";

?>
