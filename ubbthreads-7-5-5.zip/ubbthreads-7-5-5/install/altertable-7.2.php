<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)
include ("altertable.inc.php");

echo "<table border='0' width='70%' align='center'>";

// Check if we need to pick up at a certain step
$query = "
	SELECT LAST_ALTER_STEP
	FROM {$config['TABLE_PREFIX']}VERSION
";
$sth = $dbh->do_query($query);
list($thisstep) = $dbh->fetch_array($sth);

if (!$thisstep) {
	$thisstep = 1;
}

// How many steps in this altertable?
$totalsteps = 14;
for($i=$thisstep;$i<=$totalsteps;$i++) {
	if (!defined('DIDFAIL')) {
		ob_start();
		step_start($i);
		$whichstep = "";
		$whichstep = "alterstep$i";
		$whichstep();
		if (function_exists('ob_flush')) {
			ob_flush();
		}
		else {
			ob_end_flush();
		}
	}
}

if (!defined('DIDFAIL')) {
	step_stop();
}

//  All database updates go here
function alterstep1() {
}

function alterstep2() {
	global $config;
	$query = "
		ALTER TABLE {$config['TABLE_PREFIX']}USERS
		ADD	USER_RULES_ACCEPTED int(11) unsigned not null default '0'
	";
	$sth = do_query($query,"Adding a field to the {$config['TABLE_PREFIX']}USERS table to store the last timestamp that the forum rules were accepted...");
}


function alterstep3() {
        global $config;
        $query = "
                alter table {$config['TABLE_PREFIX']}ONLINE
                add ONLINE_POST_ID int(9),
		add ONLINE_POST_SUBJECT varchar(255) 
        ";
        $sth = do_query($query,"Adding fields to the {$config['TABLE_PREFIX']}ONLINE table to store the post a user is looking at...");                                          
}

function alterstep4() {
        global $config;
        $query = "
		alter table {$config['TABLE_PREFIX']}USER_PROFILE
		add USER_NOTIFY_NEW_USER tinyint(1) not null default '0',
		add USER_POST_LAYOUT varchar(4),
		add USER_CANNOT_PM tinyint(1)
        ";
        $sth = do_query($query,"Adding new fields to {$config['TABLE_PREFIX']}USER_PROFILE to store several new user preferences...");                                          
}

function alterstep5() {
        global $config;
        $query = "
		alter table {$config['TABLE_PREFIX']}FILES
		add FILE_ORIGINAL_NAME varchar(255),
		add FILE_DESCRIPTION varchar(255),
		add FILE_WIDTH mediumint(5),
		add FILE_HEIGHT mediumint(5),
		add FILE_DIR varchar(25)
        ";
        $sth = do_query($query,"Adding a couple fields to {$config['TABLE_PREFIX']}FILES store the description of the uploaded file, as well as a few fields for the new gallery forums..."); 
}

function alterstep6() {
	global $config;
	$query = "
        	create table {$config['TABLE_PREFIX']}REFERER_LOG (
                	REFERER_ID bigint(20) unsigned not null auto_increment primary key,
                	REFERER_DATE int(9) unsigned not null,
                	REFERER_URL varchar(255),
                	index referer_date (REFERER_ID)
        	) TYPE=MyISAM
	";
	$sth = do_query($query,"Creating new table {$config['TABLE_PREFIX']}REFERER_LOG to store how guests are getting to your forums...");
}

function alterstep7() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}FORUMS
		add FORUM_IS_TEASER tinyint(1) not null default '0',
		add FORUM_IS_GALLERY tinyint(1) not null default '0'
	";
	$sth = do_query($query,"Adding new fields to {$config['TABLE_PREFIX']}FORUMS to designate a forum as a teaser forum, or as a gallery forum...");
}

function alterstep8() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}POSTS
		add POST_POSTER_NAME varchar(50),
		add POST_MD5 varchar(32),
		add index MD5_ndx (POST_MD5)
	";
	$sth = do_query($query,"Adding a field to the {$config['TABLE_PREFIX']}POSTS table to store a username for guest posts, also a new field to prevent duplicate posts...");
}

function alterstep9() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}TOPICS
		add TOPIC_POSTER_NAME varchar(50),
		add TOPIC_THUMBNAIL varchar(255)
	";
	$sth = do_query($query,"Adding a field to the {$config['TABLE_PREFIX']}TOPICS table to store a username for guest posts...");

}

function alterstep10() {
	global $config,$dbh;

	$query = "
		create table {$config['TABLE_PREFIX']}ADMIN_LOG (
		LOG_DATE int(9) unsigned not null,
		USER_ID int(9) unsigned not null,
		LOG_IP varchar(15),
		LOG_ACTION varchar(50),
		LOG_INFO text,
		index log_date (LOG_DATE),
		index user_id (USER_ID),
		index log_ip (LOG_IP),
		index log_action (LOG_ACTION)
		) TYPE=MyISAM
	";

	do_query($query,"Creating a table to store admin logs...");

}

function alterstep11() {
	global $config;

	$query = "
		insert into {$config['TABLE_PREFIX']}CACHE
		(CACHE_FIELD,CACHE_VALUE)
		values
		('birthdays','0')
	";
	do_query($query,"Adding an entry to the CACHE table that will be used for birthday notifications...");
}

function alterstep12() {
	global $config;

	$query = "
		update {$config['TABLE_PREFIX']}FORUMS
		set FORUM_ALLOW_ATTACHMENTS ='5'
		where FORUM_ALLOW_ATTACHMENTS = '1'
	";
	do_query($query,"Update forums that allow file attachments to allow a default of 5 attachments per post...");
}

function alterstep13() {
	global $config;

	// THUMBNAIL ISLANDS
	for ($i=1;$i<=10;$i++) {
		$query = "
			insert into {$config['TABLE_PREFIX']}PORTAL_BOXES
			(PORTAL_LAST_BUILD,PORTAL_CACHE,PORTAL_LOCK,PORTAL_CUSTOM)
			values
			('0','0','0','3')
		";
		do_query($query,"Adding several new side islands for gallery thumbnails...");
	} // end for
}

function alterstep14() {
	global $config;
	
	$query = "
		update {$config['TABLE_PREFIX']}FILES
		set FILE_ORIGINAL_NAME = FILE_NAME
	";
	do_query($query,"Updating old attachment names...");
} 




?>
