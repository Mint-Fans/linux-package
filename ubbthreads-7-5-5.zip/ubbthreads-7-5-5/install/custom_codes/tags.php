<?php
$export_tags = array (
  0 => 
  array (
    'tag' => 'video:google',
    'descrip' => 'Google Video',
    'prompt' => 'Google URL or ID; eg: http://video.google.com/videoplay?docid=xxxxxx or just xxxxxx',
    'regex' => '(|.*docid=)(\\d{8,20})(|&.*)',
    'markup' => '<object width="425" height="350">
 <param name="movie" value="http://video.google.com/googleplayer.swf?docId=\\\\2&hl=en"></param>
 <param name="wmode" value="transparent"></param>
 <embed src="http://video.google.com/googleplayer.swf?docId=\\\\2&hl=en"
  type="application/x-shockwave-flash" wmode="transparent"
  width="425" height="350">
 </embed>
</object>',
  ),
  1 => 
  array (
    'tag' => 'video:myspace',
    'descrip' => 'MySpace Video',
    'prompt' => 'MySpace URL or ID; eg: http://vids.myspace.com/index.cfm?fuseaction=vids.individual&videoid=xxxxxx or just xxxxx',
    'regex' => '(|.*[dD]=)(\\d{5,20})(|&.*)',
    'markup' => '<object type="application/x-shockwave-flash" style="width: 448px; height: 386px;" data="http://lads.myspace.com/videos/vplayer.swf?m=\\\\2&v=2&type=video">
<param name="quality" value="best" />
<param name="wmode" value="transparent" />
<param name="movie" value="http://lads.myspace.com/videos/vplayer.swf?m=\\\\2&v=2&type=video" />
<param name="pluginspage" value="http://www.macromedia.com/go/getflashplayer" />
</object>',
  ),
  2 => 
  array (
    'tag' => 'video:yahoo',
    'descrip' => 'Yahoo Video',
    'prompt' => 'Yahoo URL or ID; eg: http://video.yahoo.com/video/play?vid=xxxxxx or just xxxxxx',
    'regex' => '(|.*vid=)([^&]+)(|&.*)',
    'markup' => '<embed src="http://us.i1.yimg.com/cosmos.bcst.yahoo.com/player/media/swf/FLVVideoSolo.swf" flashvars="id=\\\\2" type="application/x-shockwave-flash" width="425" height="350">
</embed>',
  ),
  3 => 
  array (
    'tag' => 'video:youtube',
    'descrip' => 'YouTube Video',
    'prompt' => 'YouTube ID; eg: xxxxxxxxxx (or http://www.youtube.com/watch?v=xxxxxxxxxx)',
    'regex' => '(|.*v=)([a-zA-Z0-9_-]{8,12})(|&.*)',
    'markup' => '<object width="425" height="350">
 <param name="movie" value="http://www.youtube.com/v/\\\\2"></param>
 <param name="wmode" value="transparent"></param>
 <embed src="http://www.youtube.com/v/\\\\2"
  type="application/x-shockwave-flash" wmode="transparent"
  width="425" height="350">
 </embed>
</object>',
  ),
);
?>
