<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Turn all errors/warnings on
//error_reporting(E_ALL);
error_reporting(E_ERROR | E_PARSE);
ini_set("display_errors", true);

// include all of the required libraries
require('../libs/smarty/Smarty.class.php');

$smarty = new Smarty();

define('IS_ADMIN',1);
define('UBB_MAIN_PROGRAM',1);

$smarty->template_dir = '../templates/default';
$smarty->compile_dir = '../templates/compile';

require_once("../libs/phpmailer/class.phpmailer.php");
require_once("../includes/config.inc.php");
require_once("../libs/mysql.inc.php");
require_once("../languages/{$config['LANGUAGE']}/generic.php");
require_once("../libs/bbcode.inc.php");
require_once("../libs/html.inc.php");
require_once("../libs/mailer.inc.php");
require_once("../libs/user.inc.php");
require_once("../libs/ubbthreads.inc.php");
require_once("../libs/triggers.inc.php");
include("{$config['FULL_PATH']}/styles/{$config['DEFAULT_STYLE']}.php");

$html = new HTML;

explode_data();

// 7.1 fix - force a mood default
if (!$style_array['mood']) {
	$style_array['mood'] = "moods/default";
}

$smarty->assign_by_ref('config',$config);


class Admin {

	var $pagetitle = "";
	var $redirect = "";
	var $redirect_time = "";
	var $returntab = "";
	var $submit = "";
	var $parent_title = "";
	var $current_menu = array();
	var $menucode = "";
	var $style = "";

	function Admin() {
		global $ubbt_lang;
		$this -> current_menu = array(
			$ubbt_lang['DB_P_U'] => "",
			$ubbt_lang['REG_SET'] => "",
			$ubbt_lang['APPROVE_THREADS'] => "",
			$ubbt_lang['PRUNE_THREADS'] => "",
			$ubbt_lang['MOVE_THREADS'] => "",
			$ubbt_lang['MEM_MAN'] => "",
			$ubbt_lang['PRIMARY'] => "",
			$ubbt_lang['FEATURES'] => "",
			$ubbt_lang['GALLERY'] => "",
			$ubbt_lang['GENERAL'] => "",
			$ubbt_lang['LAYOUT'] => "",
			$ubbt_lang['CUSTOM_ISLANDS'] => "",
			$ubbt_lang['PORTAL_SETTINGS'] => "",
			$ubbt_lang['POST_ISLANDS'] => "",
			$ubbt_lang['GALLERY_ISLANDS'] => "",
			$ubbt_lang['IM_IC'] => "",
			$ubbt_lang['STYLES'] => "",
			$ubbt_lang['LANGS'] => "",
			$ubbt_lang['TEMPLATES'] => "",
			$ubbt_lang['FORUM_SET'] => "",
			$ubbt_lang['CAT_SET'] => "",
			$ubbt_lang['MOD_SET'] => "",
			$ubbt_lang['GROUP_SET'] => "",
			$ubbt_lang['DATABASE'] => "",
			$ubbt_lang['PHPINFO'] => "",
			$ubbt_lang['FILE_PERMS'] => "",
			$ubbt_lang['RSS_FEEDS'] => "",
			$ubbt_lang['CACHE'] => "",
			$ubbt_lang['WIZARD'] => "",
			$ubbt_lang['PROF_SET'] => "",
			$ubbt_lang['LOGS'] => "",
			$ubbt_lang['FORUM_PERMS'] => "",
			$ubbt_lang['SITE_PERMS'] => "",
			$ubbt_lang['CP_PERMS'] => "",
			$ubbt_lang['PAYMENT_SET'] => "",
			$ubbt_lang['SUB_GROUPS'] => "",
			$ubbt_lang['VIEW_SUBS'] => "",
		);
	}

	// #######################################################################
	// Set the current page title
	// #######################################################################
	function setPageTitle($title) {
		$this->pagetitle = $title;
	}

	function setStyle($style) {
		global $config;
		$this->style = "<link rel=\"stylesheet\" href=\"{$config['BASE_URL']}/styles/{$style}\" type=\"text/css\" />";
	}

	function setCurrentMenu($title) {
		$this->current_menu[$title] = "class=\"cpanel-menu-block-curpage\"";
	}

	function setParentTitle($title,$script) {
		global $config;
		$this->parent_title = "&raquo; <a href=\"{$config['BASE_URL']}/admin/$script\">$title</a>";
	}

	function setReturnTab($returntab=0) {
		$this->returntab = $returntab;
	}

	function setCommonSubmit($text) {
		$this->submit = $text;
	}
	// #######################################################################
	// Make sure they should be here
	// #######################################################################
	function doAuth($perm=array()) {

		global $user,$ubbt_lang,$userob;

		$auth = 0;

		$checks = array_merge(array("FULL_ACCESS"),$perm);		

		foreach($checks as $k => $v) {
			if ($userob->check_access("cp",$v)) {
				$auth = 1;
				break;
			} // end if
		} // end if

		if (!$auth) {
			$this->error($ubbt_lang['LOGIN_BODY'],1);
		}

		// ALL _POST methods should contain the valid_post key
		if ($_SERVER['REQUEST_METHOD'] == "POST" && !isset($_POST['valid_post'])) {
			$this->error($ubbt_lang['BAD_FORM']);
		} // end if


	}

	// #######################################################################
	// Generate the proper admin header
	// #######################################################################
	function sendHeader($charset="") {
		global $ubbt_lang,$config,$user;

		if (!$charset) {
			$charset = $ubbt_lang['CHARSET'];
		}
		$returntab = $this->returntab;
		if (!$returntab) { $returntab = '0'; }
		$pagetitle = $this->pagetitle;
		$parenttitle = $this->parent_title;
		$meta_refresh = "";

		header('Content-Type: text/html; charset=' . $charset);

		if ($this->redirect) {
			$meta_refresh = "<meta http-equiv=\"refresh\" content=\"" . $this->redirect_time . ";URL=" . $this->redirect . "\" />";
		}
		if ($this->menucode) {
			$menucode = $this->menucode;
		}
		else {
			$menucode = $this->sendMenu();
		}
		$style = "";
		if ($this->style) {
			$style = $this->style;
		}
		if (!$config['COMMUNITY_TITLE']) {
			$config['COMMUNITY_TITLE'] = "<em>You have not set a title of the community.</em>";
		}
		include("../templates/default/admin/admin_header.tmpl");

	}

	// #######################################################################
	// Generate the proper admin footer
	// #######################################################################
	function sendFooter() {
		global $tabs, $VERSION_FRIENDLY;
		$returntab = $this->returntab;
		$commonsubmit = "";
		if ($this->submit) {
			$commonsubmit .= "<tr><td class=\"stdautorow\" align=\"middle\" valign=\"top\" colspan=\"2\">";
			$commonsubmit .= "<input type=\"submit\" name=\"".$this->submit."\" value=\"".$this->submit."\" /></form></td></tr>";
		}

		if (!$returntab) { $returntab = '0'; }
		$tabsize = sizeof($tabs);
		global $ubbt_lang,$config,$VERSION;
		include("../templates/default/admin/admin_footer.tmpl");

	}

	// #######################################################################
	// Generate the proper menu for the admin area
	// #######################################################################
	function sendMenu() {

		global $user,$config,$ubbt_lang,$userob;
		$current_menu = $this->current_menu;

		if ($userob->check_access("cp","FULL_ACCESS")) {
			$code = include("../templates/default/admin/admin_adminmenu.tmpl");
			return $code;
		} 
		if ($userob->check_access("cp","EDIT_USERS") || $userob->check_access("cp","APPROVE_POSTS")) {
			if ($userob->check_access("cp","EDIT_USERS")) {
				$edit = 1;
			}
			if ($userob->check_access("cp","APPROVE_POSTS")) {
				$approve = 1;
			}
			$code = include("../templates/default/admin/admin_modmenu.tmpl");
			return $code;
		}
	}

	// #######################################################################
	// Make the tabs for the top of each screen
	// #######################################################################
	function createTopTabs($tabs,$returntab="") {

		$spacer = "";
		$i=0;
		if (!$returntab) { $returntab = '0'; }
		while (list($key,$value) = each($tabs)) {
			if ($i == $returntab) {
				$selected[$i] = "-selected";
			}
			else {
				$selected[$i] = "";
			}
			$text[$i] = $key;
			if (!$value) {
				$link[$i] = "javascript:switch_tab($i);";
				$target[$i] = "_self";
			}
			else {
				$link[$i] = "$value";
				if (preg_match("/(infopop|groupee|ubbcentral)\.com/",$value)) {
					$target[$i] = "_blank";
				}
				else {
					$target[$i] = "_self";
				}
			}
			$i++;
		}

		$colspan = $i * 2;
		if (sizeof($tabs) == 1) {
			$spacer = "<td class=\"tab-grippysep\" width=\"45%\">&nbsp;</td>";
			$colspan++;
		}
		$tabsize = sizeof($tabs);
		include("../templates/default/admin/top_tabs.tmpl");

	}

	function createBottomTabs($tabs="",$div="") {

		global $config;
		if (!$div) { $div = "0"; }
		$spacer = "";
		$i=0;
		while (list($key,$value) = each($tabs)) {
			$taburl[$i] = $value;
			$tabtitle[$i] = $key;
			$i++;
		}

		$colspan = $i * 2;
		if (sizeof($tabs) == 1) {
			$spacer = "<td class=\"tab-grippysep\" width=\"45%\">&nbsp;</td>";
			$colspan++;
		}
		$tabsize = sizeof($tabs);
		include("../templates/default/admin/bottom_tabs.tmpl");

	}

	function error($error="",$noaccess="") {
		global $ubbt_lang,$user,$config;

		if (!$user['USER_DISPLAY_NAME']) {
			$ocurl = urlencode(get_current_url());
			$this->redirect($ubbt_lang['LOGIN_BODY'],make_ubb_url("", "", true) . "?ubb=login&ON_COMPLETION_URL=$ocurl",$ubbt_lang['GO_LOGIN']);
			exit;
		}
		$this -> setPageTitle($ubbt_lang['CP_MESS']);
		$tabs = array(
		    "{$ubbt_lang['CP_MESS']}" => ""
		);
		if ($noaccess) {
			$this->menucode = include("../templates/default/admin/admin_nullmenu.tmpl");
		}
		else {
			$this->menucode = $this -> sendMenu();
		}
		$this -> sendHeader();
		$this->createTopTabs($tabs);
		$error .= "<br /><br /><b>&raquo; <a href=\"javascript:history.go(-1)\">{$ubbt_lang['RETURN']}</a></b>";
		include("../templates/default/admin/error.tmpl");
		$this -> sendFooter();
		exit;
	}

	function setRedirect($url) {
		$this -> redirect = $url;
	}

	function setRedirectTime($time) {
		$this->redirect_time = $time;
	}

	function redirect($message="",$redirect="",$forward="",$time="") {
		global $ubbt_lang;
		$this -> setPageTitle($ubbt_lang['CP_MESS']);
		$tabs = array(
		    "{$ubbt_lang['CP_MESS']}" => ""
		);
		if (!$time) {
			$time = "5";
		}
		$this -> redirect_time = $time;
		$this -> redirect = $redirect;
		$this -> sendHeader();
		$this->createTopTabs($tabs);
		include("../templates/default/admin/redirect.tmpl");
		$this -> sendFooter();
		exit;
	}

	function get_config($key, $exists, $default="") {
		if ($config[$key]) {
			return $exists;
		} else {
			return $default;
		}
	}

}

?>
