<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function captcha_setup($type="",$test="") {
	global $config;

	$fdir = opendir("{$config['FULL_PATH']}/images/captcha/fonts");
	while(($font = readdir($fdir)) == true) {
		if ($font == "index.html" || $font == "." || $font == "..") continue;
		$fonts[] = $font;
	}

	$bdir = opendir("{$config['FULL_PATH']}/images/captcha/backgrounds");
	while(($img = readdir($bdir)) == true) {
		if ($img == "index.html" || $img == "." || $img == "..") continue;
		$backgrounds[] = $img;
	}

	// Generate a 6 character code
	$charset = array('a','b','c','d','e','f','h','k','m','n','p','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','H','K','M','N','P','R','S','T','U','V','W','X','Y','Z',2,3,4,5,7,8,9);
	$code = "";
	for ($i=0;$i<6;$i++) {
		$code .= $charset[array_rand($charset)];
	}

	if ($test) {
		$code = "UBB.threads";
	} // end if

	// Assign the code to a session
	session_save_path($config['SESSION_PATH']);
	session_start();
	$_SESSION['cp_code'] = $code;
	session_write_close();

	if ($type == "gd" || $type == "im") $config['CAPTCHA'] = $type;

	// Determine function to use here:
	if ($config['CAPTCHA'] == "gd") {
		captcha_gd($code,$fonts,$backgrounds,$test);
	} elseif ($config['CAPTCHA'] == "im") {
		captcha_magick($code,$fonts,$backgrounds,$test);
	} // end if

} // end function captcha_setup


function captcha_magick($code="",$fonts=array(),$backgrounds=array(),$test="") {

	global $config;

	$width = 200;
	$height = 50;
	$minfont = 21;
	$maxfont = 25;

	if (!function_exists("exec")) {
		echo "exec() is not available.";
		return false;
	}

	// Need to generate a random name for imagemagick images
	$filename = md5(uniqid($_SERVER['REMOTE_ADDR'] . microtime()));

	$rand_img = "{$config['FULL_PATH']}/images/captcha/backgrounds/" . $backgrounds[array_rand($backgrounds)];
	$exec = "{$config['CONVERT_PATH']} \"$rand_img\" -resize {$width}x{$height}! -swirl " . mt_rand(10,100);
	
	$x = 20;

	$angle_array = array("0x0","0x30","20x20","45x45","0x330");

	for ($i=0;$i<strlen($code);$i++) {
		$font = "{$config['FULL_PATH']}/images/captcha/fonts/" . $fonts[array_rand($fonts)];
		if (!$test) {
			$angle = $angle_array[array_rand($angle_array)];
			$red = mt_rand(0,80);
			$blue = mt_rand(0,80);
			$green = mt_rand(0,80);
			$size = mt_rand($minfont,$maxfont);
			$y = mt_rand($maxfont,$height-10);
		} else {
			$red = 0;
			$blue = 0;
			$green = 0;
			$size = $maxfont;
			$y = $maxfont;
		}
		$exec .= " -font \"$font\" -pointsize $size -fill \"rgb($red,$blue,$green)\" -annotate $angle+$x+$y '{$code[$i]}' ";
		$x = $x + (180 / strlen($code));

	}
	if (!$test) {
		$exec .= ' -flatten -swirl 15 ';
	}
	$exec .= " -stroke black -strokewidth 1 -fill none -draw \"rectangle 0,49,199,0\" -depth 8 GIF:\"{$config['FULL_PATH']}/cache/$filename.gif\" 2>&1";
	$image = exec($exec,$error,$output);

	if (sizeof($error)) {
		echo "PHP error: " . implode(' ',$error);
		return false;
	} // end if 

	header('Content-disposition: inline; filename=captcha.gif');
	header('Content-transfer-encoding: binary');
	header('Content-Type: image/gif');
	readfile("{$config['FULL_PATH']}/cache/$filename.gif");
	unlink("{$config['FULL_PATH']}/cache/$filename.gif");

	
} // end function captcha_magick

function captcha_gd($code="",$fonts=array(),$backgrounds=array(),$test="") {

	global $config;

	$width = 200;
	$height = 50;
	$minfont = 20;
	$maxfont = 24;

	$output_image = imagecreatetruecolor($width,$height);
	$bgcolor = imagecolorallocate($output_image,255,255,255);
	imagefill($output_image,0,0,$bgcolor);

	$rand_img = "{$config['FULL_PATH']}/images/captcha/backgrounds/" . $backgrounds[array_rand($backgrounds)];

	$background_image = imagecreatefromjpeg($rand_img);


	// Now create each character
	for ($i=0; $i < strlen($code); $i++) {

		// Choose a random font
		$font = "{$config['FULL_PATH']}/images/captcha/fonts/" . $fonts[array_rand($fonts)];

		if (!$test) {
			$color = imagecolorallocate($output_image, rand(0,50), rand(0,50), rand(0,50));
			$size = rand($minfont,$maxfont);

			// Don't angle the first or last font too much
			if ($i==0) {
				$angle = rand(0,10);
			} elseif ($i==5) {
				$angle = rand(-10,0);
			} else {
				$angle = rand(-20,20);
			}
			$y = rand(30,$height-10);
		} else {
			$color = imagecolorallocate($output_image, rand(0,1), rand(0,1), rand(0,1));
			$size = $minfont;
			$angle = 0;
			$y = 35;
		}
		
		// Get width/height of each character
		$char_info = imageftbbox($size,$angle,$font,$code[$i],array());

		// Where are we placing this character?
		$x = ($i +1) * (170 / strlen($code));
		imagefttext($output_image,$size,$angle,$x,$y,$color,$font,$code[$i],array());
	
	}

	$iw = imagesx($output_image);
	$ih = imagesy($output_image);

	$temp = imagecreate($iw, $ih);

	// Which way are we bending this code?
	$bend = (time() & 1) ? 1 : 0;

	// This is where we'll bend the letters right or left

	for ($x = 0; $x < $iw; $x++) {
		$xadjust = 0;
		for ($y = 0; $y < $ih; $y++) {

			$xadjust = $xadjust + ($y / 50);

			if ($bend) {
				$bendx = $x - $xadjust;
			} else {
				$bendx = $x + $xadjust;
			}

			if (($bendx > 0 AND $bendx < $iw) AND ($y > 0 AND $y < $ih)) {
				$current = imagecolorat($output_image, $bendx, $y);
				$color_array = imagecolorsforindex($output_image, $current);
				$current_color = imagecolorresolve($temp, $color_array['red'], $color_array['green'], $color_array['blue']);
				if (rand(1,50) > 48) {
					$current_color = imagecolorresolve($temp, 255, 255, 255);
				}
			} else {
				$current_color = imagecolorresolve($temp, 255, 255, 255);
			}
	
			imagesetpixel($temp, $x, $y, $current_color);
		}
	}

	// Make transparency
	$transcolor = imagecolorallocate($temp,255,255,255);
	imagecolortransparent($temp,$transcolor);

	// Copy the Background
	imagecopymerge($background_image,$temp,0,0,0,0,$width,$height,100);

	$newimage = $background_image;

	$iw = imagesx($newimage);
	$ih = imagesy($newimage);

	// Create the final image and also the mask for blurring
	$final_image = imagecreatetruecolor($iw, $ih);
	$blur_mask = imagecreatetruecolor($iw, $ih);
	imagecopy ($final_image, $newimage, 0, 0, 0, 0, $iw, $ih);

	for ($z = 0; $z < 2; $z++) {
		imagecopy($blur_mask,$final_image,0,0,1,1,$iw-1,$ih-1);
		imagecopymerge($blur_mask,$final_image,1,1,0,0,$iw,$ih,50);
		imagecopymerge($blur_mask,$final_image,0,1,1,0,$iw-1,$ih,33.33333);
		imagecopymerge($blur_mask,$final_image,1,0,0,1,$iw,$ih-1,25);
		imagecopymerge($blur_mask,$final_image,0,0,1,0,$iw-1,$ih,33.33333);
		imagecopymerge($blur_mask,$final_image,1,0,0,0,$iw,$ih,25);
		imagecopymerge($blur_mask,$final_image,0,0,0,1,$iw,$ih-1,20); 
		imagecopymerge($blur_mask,$final_image,0,1,0,0,$iw,$ih,16.66667);
		imagecopymerge($blur_mask,$final_image,0,0,0,0,$iw,$ih,50); 
		imagecopy($final_image,$blur_mask,0,0,0,0,$iw,$ih);
	}
	
	// Get rid of the mask 
	imagedestroy($blur_mask);

	header ("Content-type: image/gif");
	imagegif($final_image);
}

?>
