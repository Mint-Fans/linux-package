<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function resize_image($type,$sourcefile="") {
	global $config;

	if ($type == "thumb") {
		$size = $config['MAX_THUMB_W_H'];
	} elseif ($type == "medium") {
		$size = $config['MAX_MEDIUM_W_H'];
	} elseif ($type == "full") {
		$size = $config['MAX_FULL_W_H'];
	} else {
	}

	// Get the extension
	$ext = explode('.',"{$config['FULL_PATH']}/tmp/$sourcefile");
	$ext = strtolower($ext[count($ext)-1]);

	$is = getimagesize("{$config['FULL_PATH']}/tmp/$sourcefile");

	$width = 0;
	$height =0;
	if ( $is[0] > $size || $is[1] > $size) {
		if ( ($is[0] - $size ) >= ( $is[1] - $size ) ) {
			$width = $size;
			$height = ($size / $is[0] ) * $is[1];
		} else {
			$height = $size;
			$width = ( $size / $is[1] ) * $is[0];
		}
	} else {
		$width = $is[0];
		$height = $is[1];
	} // end if 

	$function = "resize_image_{$config['GRAPHICS_LIBRARY']}";
	$filename = $function ($type,$sourcefile,intval($width),intval($height),$is,$ext);
	
	return array($filename,$width,$height);

} // end resize_image

function resize_image_gd($type="",$sourcefile="",$width,$height,$original,$ext) {
	global $config;
	
	$img_dst = imagecreatetruecolor($width,$height);
		
	if ($ext == "jpg" || $ext == "jpeg") {
		$img_src = imagecreatefromjpeg( "{$config['FULL_PATH']}/tmp/$sourcefile" );
	} elseif ($ext == "png") {
		$img_src = imagecreatefrompng( "{$config['FULL_PATH']}/tmp/$sourcefile" );
		if (version_compare(phpversion(), "4.3.2", ">=")) {
			imagealphablending($img_dst, false);
			imagesavealpha($img_dst, true);
		}
	} elseif ($ext == "gif") {
		$img_src = imagecreatefromgif( "{$config['FULL_PATH']}/tmp/$sourcefile" );		
		$transparentIndex = imagecolortransparent($img_src);
		if ($transparentIndex >= 0) {
			// Image has transparency
			if (!(($width - $original[0]) || ($height - $original[1]))) {
				// Image isn't being resized, so make it transparent
				$trans_color = @imagecolorallocate($image, 255, 255, 255);
				@imagecolortransparent($img_dst, $trans_color);
			} else {
				// Image isn't being resized, so give it white background
				$trans_color = @imagecolorallocate($img_dst, 255, 255, 255);
				@imagefilledrectangle($img_dst, 0, 0, $width, $height, $trans_color);
			}
		}
	} // end if
	
	imagecopyresampled($img_dst,$img_src,0,0,0,0,$width,$height,$original[0],$original[1]);
	
	if ($ext == "gif" && function_exists('imagegif')) {
		imagetruecolortopalette($img_dst, false, 255);
	}

	$sourcefile = preg_replace("/\.$ext$/i","",$sourcefile);

	if ($type == "thumb") $quality = $config['THUMB_QUALITY'];
	if ($type == "medium") $quality = $config['MEDIUM_QUALITY'];
	if ($type == "full") $quality = $config['FULL_QUALITY'];

	// If it's a jpg or if we can't handle gifs
	if (($ext == "jpg" || $ext == "jpeg") || (($ext == "gif") && !function_exists('imagegif'))) {
		imagejpeg($img_dst,"{$config['FULL_PATH']}/tmp/$sourcefile.jpg.$type",$quality);
		return "$sourcefile.jpg";
	} else if ($ext == "png") {
		imagepng($img_dst,"{$config['FULL_PATH']}/tmp/$sourcefile.png.$type");
		return "$sourcefile.png";
	} else if ($ext == "gif") {
		imagegif($img_dst,"{$config['FULL_PATH']}/tmp/$sourcefile.gif.$type");
		return "$sourcefile.gif";
	}
} // end resize_image_gd

function resize_image_im($type="",$sourcefile="",$width,$height,$original="",$ext="") {
	global $config;

	if ($ext == "jpg" || $ext == "jpeg") {

		if ($type == "thumb") {
			$output = "JPG";
			$quality = " -quality {$config['THUMB_QUALITY']} ";
		} elseif ($type == "medium") {
			$output = "JPG";
			$quality = " -quality {$config['MEDIUM_QUALITY']} ";
		} else {
			$output = "JPG";
			$quality = " -quality {$config['FULL_QUALITY']} ";
		} // end if

	}

	if ($ext == "png") {
		$output = "PNG";
		$quality = " -quality 95 ";
	} // end if

	if ($ext == "gif") {
		$quality = "";
		$output = "GIF";
	} // end if

	if ($type == "thumb" || $type == "medium") {
		$thumb = " -thumbnail ";
	} else {
		$thumb = "";
	} // end if

	$exec = "\"{$config['CONVERT_PATH']}\" {$config['FULL_PATH']}/tmp/$sourcefile $thumb {$width}x{$height} $quality {$output}:\"{$config['FULL_PATH']}/tmp/$sourcefile.$type\" 2>&1";

	exec($exec);

	return "$sourcefile";

} // end resize_image_im

?>
