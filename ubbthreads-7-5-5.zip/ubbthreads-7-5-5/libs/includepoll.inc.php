<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//	$Id: includepoll.inc.php 374 2006-09-22 16:16:21Z rick $
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	You may not distribute "hacks" for UBB without approval from
//	Mindraven
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// ------------------------------------------------
// THIS FILE IS INCLUDED BY SHOWFLAT/SHOWTHREAD.PHP
if(!defined("UBB_MAIN_PROGRAM")) exit;

require ("languages/{$user['USER_LANGUAGE']}/includepoll.php");

$showpoll = "";

$voter = $user['USER_ID'];
if (!$userob->is_logged_in) {
	$voter = find_environmental('REMOTE_ADDR');
}
$currtime = $html -> get_date();

if ($view_results) {
	$clause = "WHERE POLL_ID = ?";
	$vars = $Poll;
} else {
	$clause = "WHERE POST_ID = ?";
	$vars = $Number;
}
// --------------------------
// Grab the main poll options
$query = "
	SELECT POLL_ID,POLL_START_TIME,POLL_STOP_TIME,POLL_MUST_VOTE,POLL_HIDE_RESULTS_UNTIL_END,POLL_BODY,POLL_TYPE
	FROM   {$config['TABLE_PREFIX']}POLL_DATA
	$clause
	order by POLL_ID
";
$sta = $dbh -> do_placeholder_query($query,array($vars),__LINE__,__FILE__);
while(list($Poll,$pstart,$pstop,$pmustvote,$pnoresults,$question,$type) = $dbh -> fetch_array($sta)) {
	
	$query = "
		SELECT VOTES_USER_ID_IP
		FROM   {$config['TABLE_PREFIX']}POLL_VOTES
		WHERE  POLL_ID = ?
		AND    VOTES_USER_ID_IP = ?
	";
	$stz = $dbh -> do_placeholder_query($query,array($Poll,$voter),__LINE__,__FILE__);
	list($check) = $dbh -> fetch_array($stz);
	
	$currtime = $html -> get_date();

	// If topic is closed, then just bump the current time to an
	// obnoxiously long date
	if ($topic_info['TOPIC_STATUS'] == "C") {
		$pstop = $currtime;
		$currtime = "999999999999";
	}

		
	// Do we show the poll or the results?
	$poll_viewer = false;
	if (!$check && !$view_results) {
		$poll_viewer = true;
	}
	if ($pnoresults && ($currtime < $pstop)) {
		$poll_viewer = true;
	}
	if ($pstop && $currtime > $pstop) {
		$poll_viewer = false;
	}
	if ($pstart > $currtime) {
		$poll_viewer = true;
	}
	
	if ($poll_viewer === true) {

		// ------------------------------------
		// Can they view results before voting?
		// and can the view results before the
		// poll is over

		$mustvotetext = "";
		$viewresults = "";
		$noresults = "";
		if ($pnoresults && ($currtime < $pstop)) {
			$noresults = "{$ubbt_lang['NORESULTS']}<br />";
			if ($check) {
				$buttontype = "button";
				$buttontext = "{$ubbt_lang['COUNTED']}";
			} elseif ($html->get_date() < $pstart) {
				$buttontype = "button";
				$buttontext = "{$ubbt_lang['NOTYET']}";
			}
			else {
				$buttontype = "submit";
				$buttontext = "{$ubbt_lang['SUBMIT_VOTE']}";
			}
		}
		else {
			if ($pmustvote) {
				$mustvotetext = $ubbt_lang['MUSTVOTE'];
			}
			else {
				$viewresults = "<a href=\"javascript:void(0);\" onclick=\"window.open('" . make_ubb_url("ubb=viewpoll&Poll=$Poll", "", false) . "','_blank','scrollbars=yes,toolbar=no,menubar=no,location=no,directories=no,status=no,width=500,height=300,top=200,left=200,scrollbar=yes');\">{$ubbt_lang['VIEWRESULTS']}</a>";
			}		

			// ---------------------------
			// Can they vote at this time?
			if ($html->get_date() < $pstart) {
				$buttontype = "button";
				$buttontext = "{$ubbt_lang['NOTYET']}";
			}
			else {
				$buttontype = "submit";
				$buttontext = "{$ubbt_lang['SUBMIT_VOTE']}";
			}
		}	

		// ----------------------------------
		// How long are votes being accepted?
		$pstart = $html -> convert_time($pstart,$useroffset,$user['USER_TIME_FORMAT']);
		if ($pstop) {
			$pstop = $html -> convert_time($pstop,$useroffset,$user['USER_TIME_FORMAT']);
		}

		if ($pstop) {
			$timeframe = "{$ubbt_lang['ACCEPTED']} ($pstart) {$ubbt_lang['UNTIL']} ($pstop)<br />";
		} else {
			$timeframe = "{$ubbt_lang['ACCEPTED']} {$pstart}<br />";
		} // end if

		$pollarray['name'] = "$question";

		if ($type == "one") {
			$pollarray['choices'] = $ubbt_lang['CHOOSE_ONE'];
		}
		elseif ($type == "many") {
			$pollarray['choices'] = $ubbt_lang['CHOOSE_MANY'];
		}
		else {
			$pollarray['choices'] = $html->substitute($ubbt_lang['CHOOSE_NUM'],array("NUMBER" => $type));
		}

		// ----------------------------------
		// Grab the options for this question
		$query = "
			SELECT OPTION_ID,OPTION_BODY
			FROM   {$config['TABLE_PREFIX']}POLL_OPTIONS
			WHERE  POLL_ID = ?
			ORDER BY OPTION_ID
		";
		$stj = $dbh -> do_placeholder_query($query,array($Poll),__LINE__,__FILE__);
		$x = 0;
		while(list($optionnum,$option) = $dbh -> fetch_array($stj)) {
			$option = stripslashes($option);
			if ($type == "one") {
				$pollarray[$x]['type'] = "radio";
				$pollarray[$x]['name'] = "option";
				$pollarray[$x]['value'] = $optionnum;
				$pollarray[$x]['option'] = "$option";
			}
			else {
				$num = $x + 1;
				$pollarray[$x]['type'] = "checkbox";
				$pollarray[$x]['option'] = "$option";
				$pollarray[$x]['value'] = $optionnum;
				$pollarray[$x]['name'] = "option$num";
			}
			$x++;
		}
		$pollarray['options'] = $x;


		$smarty->assign("Poll",$Poll);
		$smarty->assign("Board",$Board);
		$smarty->assign("Number",$Number);
		$smarty->assign("page",$page);
		$smarty->assign("what",$what);
		$smarty->assign("fpart",$fpart);
		$smarty->assign("buttontype",$buttontype);
		$smarty->assign("timeframe",$timeframe);
		$smarty->assign("noresults",$noresults);
		$smarty->assign("mustvotetext",$mustvotetext);
		$smarty->assign("viewresults",$viewresults);
		$smarty->assign("buttontext",$buttontext);
		$smarty->assign("questions",$questions);
		$smarty->assign("pollarray",$pollarray);	

		$showpoll .= $smarty->fetch("includepoll.tpl");
		
	} else {

		// ---------------------------------------
		// Couple of variables for the percentages
		$maxvotes = 0;
		$totaloptions = 0;

		// ---------------------------------------------
		// Grab all the distinct votes for this question
		$query = "
			SELECT DISTINCT VOTES_USER_ID_IP,COUNT(*)
			FROM   {$config['TABLE_PREFIX']}POLL_VOTES
			WHERE  POLL_ID = ?
			GROUP BY POLL_ID
		";
		$stb = $dbh -> do_placeholder_query($query,array($Poll),__LINE__,__FILE__);
		list ($tvotes,$count) = $dbh -> fetch_array($stb);

		$pollarray['name'] = "$question";
		$pollarray['tvotes'] = $count;

		// ----------------------------------
		// Now grab all votes for each option
		$query = "
			SELECT OPTION_ID,COUNT(*)
			FROM   {$config['TABLE_PREFIX']}POLL_VOTES
			WHERE  POLL_ID = ?
			GROUP BY OPTION_ID
		";
		$stb = $dbh -> do_placeholder_query($query,array($Poll),__LINE__,__FILE__);
		while(list($votedoption,$optionvotes) = $dbh -> fetch_array($stb)) {
			$polloptions[$votedoption] = $optionvotes;
			$totaloptions = $totaloptions + $optionvotes;
			if ($optionvotes > $maxvotes) {
				$maxvotes = $optionvotes;
			}
		}

		// ----------------------------------------------
		// Setup a multiplier for the width of the images
		for ($c=10;$c<=100;$c=$c+10) {
			if ($maxvotes < $c) {
				$multiplier = (100 / $c);
				break;
			}
		}
		if (!$multiplier) {
			$multiplier = 100 / $maxvotes;
		}

		if ($type == "one") {
			$pollarray['choices'] = $ubbt_lang['CHOOSE_ONE'];
		}
		elseif ($type == "many") {
			$pollarray['choices'] = $ubbt_lang['CHOOSE_MANY'];
		}
		else {
			$pollarray['choices'] = $ubbt_lang['CHOOSE_NUM'] . " $type ";
		}

		// ----------------------------------
		// Grab the options for this question
		$query = "
			SELECT OPTION_ID,OPTION_BODY
			FROM   {$config['TABLE_PREFIX']}POLL_OPTIONS
			WHERE  POLL_ID = ?
			ORDER BY OPTION_ID
		";
		$stj = $dbh -> do_placeholder_query($query,array($Poll),__LINE__,__FILE__);
		$x = 1;
		while(list($optionnum,$option) = $dbh -> fetch_array($stj)) {
			$pollarray[$x]['option'] = $option;
			if(isset($polloptions[$optionnum])) {
				$pollarray[$x]['tvotes'] = $polloptions[$optionnum];
				$pollarray[$x]['width'] = intval($polloptions[$optionnum] * $multiplier);
			}
			else {
				$pollarray[$x]['tvotes'] = 0;
				$pollarray[$x]['width'] = 0;
			}

			$division = $totaloptions * 1000;
			$thisone = "";
			if (isset($polloptions[$optionnum])) {
				$thisone = $polloptions[$optionnum] * 1000;
			}
			$per = "";
			if ($division) {
				$per = ($thisone/$division);
			}
			@list($crap,$percent) = @preg_split("#\.#",$per);
			if ($percent < 10) {
				$percent .= "0";
			}
			$rounder = substr($percent,2,1);
			$percent = substr($percent,0,2);
			if ($rounder >=5) { $percent++; }
			if ($per == 1) {  $percent = "100"; }
			$pollarray[$x]['percent'] = $percent;
			$x++;
		}
		$pollarray['options'] = $x - 1;
		if ($pstop) {
			$pstop = $html->substitute($ubbt_lang['VOTING_ENDS'],array('END' => $html -> convert_time($pstop,$useroffset,$user['USER_TIME_FORMAT'])));
		} // end if

		$smarty->assign("questions",$questions);
		$smarty->assign("pollarray",$pollarray);
		$smarty->assign("pstop",$pstop);
		$showpoll .= $smarty->fetch("includepollresults.tpl");
	}
}

?>
