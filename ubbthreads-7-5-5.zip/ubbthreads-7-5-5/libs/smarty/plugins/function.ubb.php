<?php
/**
 * Usage:    <a href="{ubb url="ubb=cfrm&c=4"}">Cat 4</a>
 * Becomes:  <a href="/threads/ubbthreads.php?ubb=cfrm&amp;c=4">Cat 4</a>
 */
function smarty_function_ubb( $params, &$smarty ) {
	return make_ubb_url( $params['url'], isset($params['title']) ? $params['title'] : "", isset($params['full']) && $params['full'] == "true" );
}
?>
