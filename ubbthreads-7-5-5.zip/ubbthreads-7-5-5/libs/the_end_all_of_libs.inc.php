<?php
//  Ultimate Bulletin Board
//
//  Program authors: Rick Baker
//  Copyright (C) 2010 Mindraven.
//  Script Version 7.5.5

//  You may not distribute this program in any manner, modified or
//  otherwise, without the express, written consent from
//  Mindraven.
//
//  You may make modifications, but only for your own use and
//  within the confines of the UBB License Agreement
//  (see our website for that).
//
//  Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

class bulletin {
	var $html;
	var $dbh;
	var $input;
	var $userob;
	var $user;
	var $is_debug_mode;
	var $config;
	var $smarty;
	var $style_array;
	var $lang;
	
	function bulletin() {
		global $config, $ubbt_lang;
		$this->config      = $config;
		$this->lang	   =& $ubbt_lang;
		$this->html	   = new html;
		$this->dbh	   = $this->get_database_handler();
		$this->userob	   = new User;
		$this->user	   = $this->userob->authenticate("*");
		$this->smarty	   = new Smarty;
		$this->style_array = $this->html->get_style_array();
	}
	
	function &get_database_handler() {
		$tmp = array_get($this->config, 'DB_TYPE', 'mysql');
		
		$file = sprintf('%s/libs/db/%s.inc.php', $this->config['FULL_PATH'], $this->config['DB_TYPE']);
		
		if (file_exists($file)) {
			include_once($file);
			return init_db_connection($this->config);
		}
		
		$this->html->not_right($this->lang['INVALID_DB_CONNECTION'])
	}
}

class database_handler {
	var $debug_output;
	var $handler;
	var $errors;
	
	var $show_errors;

	function __construct() {
		// Setting this option will trickle down to all children of this class.
		$this->show_errors = true;
		
		$this->handler = null;
		$this->debug_output = "";
		$this->errors = array(
			'CONNECT' => 'Unable to connect to database server.  The error returned was %s.',
			'DB_SELECT' => 'Unable to select database.  The error returned was %s.',
			'INVALID_ESCAPE' => 'The developer forgot to define an escape function.',
			'INVALID_REPLACEMENT' => 'The size of the replacement array does not match the amount of placeholders.',
			'NO_REPLACEMENT' => 'The second parameter of this function must be an array.',
			'DO_QUERY' => '',
		);
	}
	
	function __destruct() {}

	function connect() {}

	function do_query($query) {}
	function do_placeholder_query($query, $replacements) {}
	
	function fetch_array($sth) {}
	function free_result($sth) {}
	
	function get_affected($sth) {}
	function get_last_insert() {}
	function get_field_name() {}
	function get_total_rows() {}
	function get_total_fields() {}
	
	function throw_error() {}
	function explain_query() {}
	
	function is_integer($var) {
		if (is_string($var)) {
			return preg_match('#^\d+$#', $var);
		} else {
			return is_int($var);
		}
	}
	
	function get_caller() {
		// Identifies $a in the following sequence
		// $a calls $dbh->something calls get_caller
	
		$caller = debug_backtrace();
		
		$line = $caller[2]['line'];
		$file = $caller[2]['file'];
		
		return array($line, $file);
	}
	
	function escape($var) {
		$this->throw_error("INVALID_ESCAPE", E_ERROR);	
	}
	
	function throw_error($err, $type) {
		$message = sprintf($this->errors[$err], $this->get_error_desc());
		if ($type == E_ERROR) {
			die($message);
		} else {
			echo $message;
		}
	}
	
	function do_placeholder_query($query, $subst) {
		if (!is_array($subst)) {
			$this->throw_error("NO_REPLACEMENT", E_ERROR);
		}

		$parts = explode("?", $query);
		
		$find = count($parts) - 1;
		$replaces = count($subst);
		
		if ($find !== $replaces) {
			$this->throw_error("INVALID_REPLACEMENT", E_ERROR);
		}
		
		$query = "";
		
		for ($i = 0; $i < $replaces; $i++) {
			$query .= array_shift($parts);
			
			$repl = array_shift($subst);
			
			
			if (is_array($repl)) {
				$new = array();
				
				foreach ($repl as $r) {
					$new[] = ($this->is_integer($r) ? $r : "'" . $this->escape($r) . "'");
				}
				
				$repl = implode(", ", $new);
			} else {
				$repl = ($this->is_integer($repl) ? $repl : "'" . $this->escape($repl) . "'");
			}
			
			$query .= $repl;
		}

		$query .= array_shift($parts);

		return $this->do_query($query, $line, $file);
	}
}

class mysql_database extends database_handler {
	function __construct() {
		// Once we go completely PHP5...		
		// parent::__construct();
	
		database_handler::__construct();
	}
	
	function mysql_database() {
		$this->__construct();
	}

	function connect($server, $user, $pass, $dbname, $persistent = false) {
		if ($this->handler == null) {
			if ($persistent) {
				$this->handler = mysql_pconnect($server, $user, $pass);
			} else {
				$this->handler = mysql_connect($server, $user, $pass, true);
			}
			
			if ($this->handler === false) {
				// Cannot connect to database, stop the script.
				$this->throw_error('CONNECT', E_ERROR);
			}
			
			if (mysql_select_db($db_name, $this->handler) === false) {
				// Cannot select the desired database.
				$this->throw_error('DB_SELECT', E_ERROR);
			}
		}
	}
	
	function escape($var) {
		return mysql_real_escape_string($var);
	}
}

class mysqli_database extends database_handler {
	function __construct() {
		// Once we go completely PHP5...		
		// parent::__construct();
	
		database_handler::__construct();
	}
	
	function mysqli_database() {
		$this->__construct();
	}
	
	function connect($server, $user, $pass, $dbname, $persistent = false) {
		if ($this->handler == null) {
			$this->handler = mysqli_connect($server, $user, $pass, $dbname);
			if ($this->handler === false) {
				$this->throw_error('CONNECT', E_ERROR);
			}
		}
	}

	function escape($var) {
		return mysqli_real_escape_string($var);
	}
	
	function do_query($query) {
		if ($this->is_debug_mode) {
			$this->explain_query($query);
		}
		
		$result = mysqli_query($this->handler, $query, MYSQLI_STORE_RESULT);
		
		if ($result === false) {
			$this->throw_error('DO_QUERY', E_ERROR);
		}
	}
}
?>
