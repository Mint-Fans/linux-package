<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)



/**
 * Current Version of UBB.threads
 */
$VERSION = "7.5.5";

// ALL_VERSIONS - This is used in a few places
$all_versions = array('7.0.0b4','7.0.0b5','7.0.0rc1','7.0','7.0.1','7.0.2','7.1b1','7.1b2','7.1b3','7.1b4','7.1b5','7.1','7.1.1','7.2b1','7.2b2','7.2b3','7.2b4','7.2b5','7.2','7.2.1b1','7.2.1','7.2.2','7.3a1','7.3a2','7.3a3','7.3b1','7.3b2','7.3b3','7.3b4','7.3b5','7.3','7.3.1b1','7.3.1','7.4b1','7.4b2','7.4','7.4.1','7.4.2','7.5b1','7.5b2','7.5','7.5.1','7.5.2','7.5.3','7.5.4','7.5.4.1','7.5.4.2','7.5.5');

$timea = getmicrotime(); // oops...

/**
 * Initialize important variables
 */

init_vars();

// Bump up the session_cache_expire to prevent post tracking
// variables from being lost due to inactivity
@ini_set("session.gc_probability",1);
@ini_set("session.gc_maxlifetime",3600);
if(session_cache_expire() < 120) {
	session_cache_expire(120);
} // end if

// Add a custom error handler
set_error_handler( "ubb_error_handler" );

// ----------------------
// Start the session here
if (!defined('ALTER') && !defined('IMPORT')) {
	session_save_path($config['SESSION_PATH']);
	$check = @session_start();
	header("Cache-control: private");
}




// -------------------------------------
// Cookies are needed all over the place
$myinfo = array();
$myinfo['id'] = get_input($config['COOKIE_PREFIX']."ubbt_myid","cookie");
$myinfo['key'] = get_input($config['COOKIE_PREFIX']."ubbt_key","cookie");
$myinfo['session'] = get_input($config['COOKIE_PREFIX']."ubbt_mysess","cookie");
$myinfo['pass']  = get_input($config['COOKIE_PREFIX']."ubbt_pass","cookie");
$myinfo['dob']  = get_input($config['COOKIE_PREFIX']."ubbt_dob","cookie");
$myinfo['myids'] = get_input($config['COOKIE_PREFIX']."ubbt_x","cookie");

// Search engine friendly URLs?
$var_start = "?";
$var_eq = "=";
$var_sep = "&amp;";
$var_extra = "";
if (array_get($config, 'SEARCH_FRIENDLY_URLS', false)) {
	$var_start = "/";
	$var_eq = "/";
	$var_sep = "/";
	$var_extra = "/";
}

if (!isset($_SESSION['topicread']) || !$_SESSION['topicread']) {
	$_SESSION['topicread'] = array();
}

if (!isset($_SESSION['forumvisit']) || !$_SESSION['forumvisit']) {
	$_SESSION['forumvisit'] = array();
}

if (!isset($_SESSION['current_topic']) || !$_SESSION['current_topic']) {
	$_SESSION['current_topic'] = '';
}

$smarty->assign('var_start',$var_start);
$smarty->assign('var_eq',$var_eq);
$smarty->assign('var_sep',$var_sep);
$smarty->assign('var_extra',$var_extra);

// ---------------------------
// Turn off the magic quoting
@set_magic_quotes_runtime(0);

$dbh = new sql;
$dbh->connect();

// ########################################################################
// MAILER CLASS (mailer.inc.php)
// Define class for sending email
// ########################################################################

// ########################################################################
// HTML CLASS (html.inc.php)
// Define class for sending html
// ########################################################################

// ########################################################################
// USER CLASS (user.inc.php)
// Define a class for the user object
// ########################################################################

// ----------------------------------------------
// Check if a loginname / displayname is valid
function is_valid_name($name="",$type="",$uid="") {
	global $config, $dbh;

	// Check for proper length
	if ($type == "display") {
		if ((strlen($name) > $config['MAX_PDN_LENGTH']) || (strlen($name) < $config['MIN_PDN_LENGTH'])) {
			return array(false, 'LONG_NAME');
		} // end if

		if (!$config['SPECIAL_CHARACTERS']) {
			if (!preg_match("/^\w+$/",$name)) {
				return array(false, 'BAD_UNAME');
			}
		}
		else {
			// ----------------------------------
			// No html characters in the username
			if ( (stristr($name,"&nbsp;")) || ( strstr($name,"<")) || (strstr($name,">")) || (preg_match("/^\s/",$name)) || (preg_match("/\s$/",$name)) ) {
				return array(false, 'BAD_UNAME');
			}
		}
	} else {
		if ( (stristr($name,"&nbsp;")) || ( strstr($name,"<")) || (strstr($name,">")) || (preg_match("/^\s/",$name)) || (preg_match("/\s$/",$name)) ) {
			return array(false, 'BAD_LNAME');
		}
		if ((strlen($name) > 60) || (strlen($name) < 3)) {
			return array(false, 'LONG_LNAME');
		}
	} // end if

	$clause = "";
	if ($uid) {
		$clause = "AND USER_ID <> '$uid'";
	}
	$query = "
		SELECT USER_DISPLAY_NAME
			FROM {$config['TABLE_PREFIX']}USERS
		WHERE (USER_DISPLAY_NAME = ?
			 OR USER_LOGIN_NAME = ?)
		$clause
	";
	$sth = $dbh->do_placeholder_query($query,array($name,$name),__LINE__,__FILE__);
	list($check) = $dbh->fetch_array($sth);
	if ($check) {
		if ($type == "display") {
			return array(false, 'USER_EXISTS');
		} else {
			return array(false, 'LOGIN_EXISTS');
		} // end if
	} // end if

	$query = "
		SELECT RESERVED_USERNAME
		FROM {$config['TABLE_PREFIX']}RESERVED_NAMES
	";
	$sth = $dbh->do_query($query);
	$namelist = "";
	while(list($rname) = $dbh->fetch_array($sth)) {
		if (!preg_match("/^\(/",$rname)) {
			$rname = "^$rname";
		} // end if
		if (!preg_match("/\)$/",$rname)) {
			$rname = "$rname\$";
		} // end if
		if (preg_match("/$rname/i",$name)) {
			if ($type == "display") {
				return array(false, 'USER_EXISTS');
			} else {
				return array(false, 'LOGIN_EXISTS');
			} // end if
		} // end if
	} // end if

	return array(true, null);
}

// Make sure we can get POST,GET,COOKIE variables on any system
function strip_slashes_full( $value ) {
	return is_array( $value ) ?
		array_map( 'strip_slashes_full', $value ) :
		stripslashes( $value );
}


function get_input($name = "", $type = "", $validate = "", $default = "") {
	// Special case:
	if (is_array($validate) && !is_array($default)) {
		$default = array();
	}

	switch ($type) {
		case "both":
			return ubbt_validate($validate, array_get($_GET, $name, array_get($_POST, $name, $default)));
		case "get":
			return ubbt_validate($validate, array_get($_GET, $name, $default));
		case "post":
			return ubbt_validate($validate, array_get($_POST, $name, $default));
		case "cookie":
			return ubbt_validate($validate, array_get($_COOKIE, $name, $default));
		case "session":
			return array_get($_SESSION, $name, $default);
		default:
			return $default;
	}
}

// ----------------------------------------------------------
// Make sure we can find environment variables on any system
function find_environmental ($name) {
	return array_get($_SERVER, $name, null);
}

function getmicrotime(){
	list($usec, $sec) = explode(" ",microtime());
	return ((float)$usec + (float)$sec);
}


function ubbt_validate($validate, $value) {
	if (is_array($value)) {
		$return_array = array();

		foreach ($value as $k => $v) {
			$return_array[$k] = ubbt_validate($validate, $v);
		}

		return $return_array;
	}

	if (is_scalar($value)) {
		if (is_array($validate)) {
			return (in_array($value, $validate) ? $value : "");
		} else {
			switch ($validate) {
				case "int":
					return preg_replace("/[^\d\.\-]/", "", $value) + 0;
				case "alpha":
					return preg_replace("/[^A-Za-z\-_]/", "", $value);
				case "alphanum":
					return preg_replace("/[^A-Za-z0-9\-_]/", "", $value);
				default:
					return $value;
			}
		}
	}
}

// #######################################################################
// Grab an insert and return it's contents with the proper table wrappers
// #######################################################################
function get_portal_box($box) {

	global $wrapper;
	$tbopen = $wrapper['0'];
	$tbclose = $wrapper['1'];

	$island_insert = "";
	ob_start();
	$style_side = "";
	include("./cache/$box");
	$island_insert = ob_get_contents();
	ob_end_clean();

	return $island_insert;

} // end get_portal_box

// #####################################################################
// Grab the table wrappers
// #####################################################################
function table_wrapper() {

	global $debug,$smarty,$config,$style_array,$wrappers, $wrapper;

	$wrapper_id = $style_array['wrappers'];

	$tbopen = $wrappers[$wrapper_id]['open'];
	$tbclose = $wrappers[$wrapper_id]['close'];

	$smarty->assign('tbopen',$tbopen);
	$smarty->assign('tbclose',$tbclose);

	$wrapper['0'] = $tbopen;
	$wrapper['1'] = $tbclose;
	return($wrapper);

}

function clear_online() {

        global $dbh, $config, $html;

        // -------------------------
        // Delete the inactive users
        if (!isset($config['ONLINE_TIME'])) {
                $config['ONLINE_TIME'] = 10;
        }

        $Outdated = $html -> get_date() - ($config['ONLINE_TIME'] * 60 );
        $query = "
                DELETE FROM {$config['TABLE_PREFIX']}ONLINE
                WHERE       ONLINE_LAST_ACTIVITY < ?
        ";
        $dbh -> do_placeholder_query($query,array($Outdated),__LINE__,__FILE__);

}

function generate_rss_feeds($clear='') {

	global $config, $ubbt_lang, $dbh, $html, $smarty;

	$now = time();

	$clear_clause = "";
	if ($clear) $clear_clause = "or 1";

	// Lock everything that needs to be rebuilt
	$query = "
		update	{$config['TABLE_PREFIX']}RSS_FEEDS
		set 	FEED_LOCK = '$now'
		where 	FEED_IS_ACTIVE = 1 AND
			(($now - FEED_LAST_BUILD > FEED_CACHE_TIME) AND
			(FEED_LOCK = '0' OR (FEED_LOCK > 0 AND ($now - FEED_LOCK > 120)))
			$clear_clause)
	";
	$dbh->do_query($query,__LINE__,__FILE__);

	// Grab the feeds that need to be rebuilt
	// anything with a lock time of now or that has been locked for over
	// 2 minutes
	$query = "
		select 	FEED_ID,FEED_FORUM,FEED_FORUM_ARRAY,FEED_NAME,FEED_TYPE,FEED_INCLUDE_BODY,FEED_ITEMS,FEED_LAST_BUILD,FEED_IS_MULTI
		from	{$config['TABLE_PREFIX']}RSS_FEEDS
		where 	FEED_IS_ACTIVE = 1
			and (($now - FEED_LAST_BUILD > FEED_CACHE_TIME
			and (FEED_LOCK = '$now' or (FEED_LOCK > 0 and ($now - FEED_LOCK > 120))))
			$clear_clause)
		order by FEED_ID
	";

	$sth_islands = $dbh->do_query($query,__LINE__,__FILE__);
	while(list($feed_id,$feed_forum,$forum_array,$feed_name,$feed_type,$feed_include_body,$feed_items,$feed_last_build,$multi) = $dbh->fetch_array($sth_islands)) {

		// Querying 1 or multiple forums?
		$feed_xml_file = "rss$feed_forum.xml";
		$clause = "";
		$t1clause = "";
		if ($multi) {
			$feed_xml_file = "global_rss$feed_id.xml";
			$sources = unserialize($forum_array);
			$inlist = "";
			foreach($sources as $k => $v) {
				if ($v == "allforums") {
					$inlist = "";
					continue;
				} else {
					$inlist .= "'$v',";
				} // end if
			}
			if ($inlist) {
				$inlist = preg_replace("/,$/","",$inlist);
				$t1clause = "AND t1.FORUM_ID in ($inlist)";
			}
		} else {
			$t1clause = "AND t1.FORUM_ID = '$feed_forum'";
		} // end if

		// Topics or Posts?
		if ($feed_type == "topics") {
			$order = "TOPIC_CREATED_TIME desc";
		} else {
			$order = "TOPIC_LAST_REPLY_TIME desc";
		} // end if

		if (!$feed_include_body) {
			$query = "
				select t1.TOPIC_ID,t1.POST_ID,t1.TOPIC_SUBJECT,t1.TOPIC_CREATED_TIME,t1.TOPIC_LAST_REPLY_TIME,t1.TOPIC_LAST_POST_ID,t1.TOPIC_LAST_POSTER_ID,t1.TOPIC_LAST_POSTER_NAME,t2.USER_DISPLAY_NAME
				from {$config['TABLE_PREFIX']}TOPICS as t1,
				{$config['TABLE_PREFIX']}USERS as t2
				where t1.TOPIC_IS_APPROVED = '1'
				and t1.USER_ID = t2.USER_ID
				$t1clause
				ORDER BY t1.$order
				limit $feed_items
			";
		} else {
			$query = "
				select t1.TOPIC_ID,t1.POST_ID,t1.TOPIC_SUBJECT,t1.TOPIC_CREATED_TIME,t1.TOPIC_LAST_REPLY_TIME,t1.TOPIC_LAST_POST_ID,t1.TOPIC_LAST_POSTER_ID,t1.TOPIC_LAST_POSTER_NAME,t2.POST_DEFAULT_BODY,t3.USER_DISPLAY_NAME
				from {$config['TABLE_PREFIX']}TOPICS as t1,
				{$config['TABLE_PREFIX']}POSTS as t2,
				{$config['TABLE_PREFIX']}USERS as t3
				where t1.TOPIC_LAST_POST_ID = t2.POST_ID
				and t2.USER_ID = t3.USER_ID
				$t1clause
				and t2.POST_IS_APPROVED = '1'
				ORDER BY t1.$order
				limit $feed_items
			";
		}
		$sth = $dbh->do_query($query,__LINE__,__FILE__);
		$items = array();
		$latest = 0;
		while($posts = $dbh->fetch_array($sth)) {
			if ($posts['TOPIC_LAST_REPLY_TIME'] > $latest) {
				$latest = $posts['TOPIC_LAST_REPLY_TIME'];
			}
			$posts['TOPIC_SUBJECT'] = htmlspecialchars($posts['TOPIC_SUBJECT']);
			if (isset($posts['POST_DEFAULT_BODY'])) {
				$posts['POST_DEFAULT_BODY'] = htmlspecialchars(substr(strip_tags($posts['POST_DEFAULT_BODY']),0,$feed_include_body));
				if ($feed_type == "posts") {
					$posts['TOPIC_SUBJECT'] = "Re: {$posts['TOPIC_SUBJECT']}";
				} // end if
			} // end if
			if ($feed_type == "topics") {
				$posts['TOPIC_LAST_REPLY_TIME'] = $posts['TOPIC_CREATED_TIME'];
				$posts['TOPIC_LAST_POSTER_NAME'] = $posts['USER_DISPLAY_NAME'];
				$posts['TOPIC_LAST_POST_ID'] = $posts['POST_ID'];
			} // end if
			$posts['TOPIC_LAST_REPLY_TIME'] = $html->convert_time($posts['TOPIC_LAST_REPLY_TIME'],0,"rss",1,0);
			$items[] = $posts;
		} // end while


		if ($latest  <= ($feed_last_build + ($config['SERVER_TIME_OFFSET'] * 3600)) && !$clear) {
			continue;
		} // end if

		$smarty->assign_by_ref("items",$items);
		$smarty->assign("generated_on",$html->convert_time($now,0,"rss",1,0));
		$smarty->assign("feed_name",htmlspecialchars($feed_name));
		$rss_data = $smarty->fetch("rss_xml.tpl");

		lock_and_write("{$config['FULL_PATH']}/cache/$feed_xml_file",$rss_data);

	} // end while


	// Unlock everything
	$query = "
		update 	{$config['TABLE_PREFIX']}RSS_FEEDS
		set 	FEED_LAST_BUILD = '$now',
			FEED_LOCK = '0'
		where	FEED_IS_ACTIVE = '1' AND
			((FEED_LOCK = '$now' or (FEED_LOCK > 0 and ($now - FEED_LOCK > 120)))
			$clear_clause)
	";
	$dbh->do_query($query,__LINE__,__FILE__);

} // end function generate_rss_feeds




function rebuild_islands($clear='',$type=array()) {

	global $smarty,$config,$ubbt_lang,$dbh,$tbopenfull,$tbopen,$tbclose, $html, $style_array;

	if (!is_object($html)) {
		$html = new html;
	}

	$birthdays_done = 0;

	$smarty->assign("config",$config);
	$smarty->assign("style_side",'<?php echo $style_side ?' . '>');
	$smarty->assign("tbopen",'<?php echo $tbopen ?' . '>');
	$smarty->assign("tbclose",'<?php echo $tbclose ?' . '>');

	if ($clear || in_array("search",$type)) {
		include("{$config['FULL_PATH']}/cache_builders/search.php");
	}
	if ($clear || in_array("new_users",$type)) {
		include("{$config['FULL_PATH']}/cache_builders/new_users.php");
	}
	if ($clear || in_array("birthdays",$type)) {
		$birthdays_done = 1;
		include("{$config['FULL_PATH']}/cache_builders/birthdays.php");
	}
	if ($clear || in_array("shoutbox",$type)) {
		include("{$config['FULL_PATH']}/cache_builders/shoutbox.php");
	}
  $online_run = 0;
	if ($clear || in_array("online",$type)) {
    $online_run = 1;
		include("{$config['FULL_PATH']}/cache_builders/online_now.php");
	}

	$now = time();

	$clause = "and PORTAL_CACHE <> '0'";
	if ($clear) {
		$clause = "or 1";
	}

	// Lock everything that needs to be rebuilt
	$query = "
		update	{$config['TABLE_PREFIX']}PORTAL_BOXES
		set 	PORTAL_LOCK = '$now'
		where 	(($now - PORTAL_LAST_BUILD > PORTAL_CACHE)
		and	(PORTAL_LOCK = '0' or (PORTAL_LOCK > 0 and ($now - PORTAL_LOCK > 120))))
		$clause
	";
	$dbh->do_query($query,__LINE__,__FILE__);

	// Grab the box id's that need to be rebuilt
	// anything with a lock time of now or that has been locked for over
	// 2 minutes
	$query = "
		select 	PORTAL_ID,PORTAL_NAME,PORTAL_CUSTOM,PORTAL_POST_TYPE,PORTAL_FORUMS,PORTAL_ITEMS,PORTAL_LAST_BUILD
		from	{$config['TABLE_PREFIX']}PORTAL_BOXES
		where	($now - PORTAL_LAST_BUILD > PORTAL_CACHE
		and	(PORTAL_LOCK = '$now' or (PORTAL_LOCK > 0 and ($now - PORTAL_LOCK > 120))))
		$clause
	";

	$sth_islands = $dbh->do_query($query,__LINE__,__FILE__);

	$count = 0;
	while(list($portal_id,$name,$custom,$type,$forums,$items,$real_last_build) = $dbh->fetch_array($sth_islands)) {

		// Birthday islands only need to be rebuilt once per day
		if ($name == "birthdays") {
			$tempnow = getdate($now);
			$tempbuild = getdate($real_last_build);
			if (($tempnow['mday'] == $tempbuild['mday']) || $birthdays_done) {
				continue;
			}
		}
		$body = "";
		if ($custom == 1) {
			if (!$clear && (!in_array("portal_box_$portal_id",$config['BUILD_ISLANDS']) && !in_array("portal_box_$portal_id",$config['LEFT_COLUMN_BOXES']) && !in_array("portal_box_$portal_id",$config['RIGHT_COLUMN_BOXES'])) ){
				continue;
			} // end if
			include("{$config['FULL_PATH']}/cache_builders/portal_box.php");
		} elseif ($custom == 2) {
			if (!$clear && (!in_array("post_island_$portal_id",$config['BUILD_ISLANDS']) && !in_array("post_island_$portal_id",$config['LEFT_COLUMN_BOXES']) && !in_array("post_island_$portal_id",$config['RIGHT_COLUMN_BOXES'])) ){
				continue;
			} // end if
			include("{$config['FULL_PATH']}/cache_builders/post_island.php");
		} elseif ($custom == 3) {
			if (!$clear && (!in_array("gallery_island_$portal_id",$config['BUILD_ISLANDS']) && !in_array("gallery_island_$portal_id",$config['LEFT_COLUMN_BOXES']) && !in_array("gallery_island_$portal_id",$config['RIGHT_COLUMN_BOXES'])) ){
				continue;
			} // end if
			include("{$config['FULL_PATH']}/cache_builders/gallery_island.php");
		} else {
			if (!$clear && (!in_array("$name",$config['BUILD_ISLANDS']) &&  !in_array($name,$config['LEFT_COLUMN_BOXES']) && !in_array($name,$config['RIGHT_COLUMN_BOXES']))) {
				continue;
			} // end if
      if ($name == "online_now" && $online_run) continue;
		  include("{$config['FULL_PATH']}/cache_builders/$name.php");
		} // end if
	} // end while

	// Unlock everything
	$query = "
		update 	{$config['TABLE_PREFIX']}PORTAL_BOXES
		set 	PORTAL_LAST_BUILD = '$now',
			PORTAL_LOCK = '0'
		where	(PORTAL_LOCK = '$now' or (PORTAL_LOCK > 0 and ($now - PORTAL_LOCK > 120)))
		$clause
	";
	$dbh->do_query($query,__LINE__,__FILE__);

	list($tbopen,$tbclose) = table_wrapper();
	$smarty->assign("tbopen",$tbopen);
	$smarty->assign("tbclose",$tbclose);
}

function rebuild_topic_data($id) {
	global $config;
	require_once("{$config['FULL_PATH']}/libs/content_rebuild.inc.php");
	rebuild_topic($id);
} // end rebuild_topic_data


function rebuild_forum_data($id = "all") {
	global $config;
	require_once("{$config['FULL_PATH']}/libs/content_rebuild.inc.php");
	rebuild_forum($id);
} // end rebuild_forum_data

function admin_log($Operation, $Description) {

	global $config, $user, $dbh, $html;

	if (!is_object($html)) {
		$html = new html;
	}

	$time = $html->get_date();
	$IP = find_environmental ("REMOTE_ADDR");
	$Uid = $user['USER_ID'];

	$query = "
		insert into {$config['TABLE_PREFIX']}ADMIN_LOG
		(LOG_DATE,USER_ID,LOG_IP,LOG_ACTION,LOG_INFO)
		values
		( ? , ? , ? , ? , ? )
	";
	$dbh->do_placeholder_query($query,array($time,$Uid,$IP,$Operation,$Description),__LINE__,__FILE__);

} // end admin_log


function oncomplete_validate ($ocurl) {
	global $config;
	$ocp = parse_url($ocurl);
	$ocr = parse_url($config['FULL_URL']);

	if(isset($ocp['user']) || isset($ocp['pass'])) return false;
	if (!isset($ocp['host']) || !isset($ocr['host'])) return false;
	if($ocp['host'] != $ocr['host']) return false;
	return true;
} // end oncomplete_validate


// Build a forum list with indentation for cachine
function build_forum_cache () {
	global $config,$dbh,$pre_tree,$tree;
	$query = "
		select CATEGORY_ID,CATEGORY_TITLE
		from {$config['TABLE_PREFIX']}CATEGORIES
		order by CATEGORY_SORT_ORDER
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	$pre_tree = array();
	$tree = array();
	while ($result = $dbh->fetch_array($sth)) {
		$tree['categories'][$result['CATEGORY_ID']] = $result['CATEGORY_TITLE'];
		$pre_tree['categories'][$result['CATEGORY_ID']] = $result['CATEGORY_TITLE'];
	} // end while

	$query = "
		select CATEGORY_ID,FORUM_ID,FORUM_TITLE,FORUM_PARENT,FORUM_IS_ACTIVE
		from {$config['TABLE_PREFIX']}FORUMS
		order by FORUM_SORT_ORDER
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	while ($result = $dbh->fetch_array($sth)) {
		$cat_id = $result['CATEGORY_ID'];
		$forum_id = $result['FORUM_ID'];

		$tree['active'][$result['FORUM_ID']] = $result['FORUM_IS_ACTIVE'];
		$pre_tree['parent'][$result['FORUM_ID']] = $result['FORUM_PARENT'];
		if ($result['FORUM_PARENT']) {
			$tree['kids'][$result['FORUM_PARENT']][] = $result['FORUM_ID'];
			$pre_tree['subforums'][$result['FORUM_PARENT']][$result['FORUM_ID']] = $result['FORUM_TITLE'];
		} else {
			$pre_tree['forums'][$result['CATEGORY_ID']][$result['FORUM_ID']] = $result['FORUM_TITLE'];
		}
	} // end while

	$indent = "";
	foreach($pre_tree['categories'] as $category => $cat_name) {
		$indent = "&nbsp;&nbsp;&nbsp;";
		if (isset($pre_tree['forums'][$category])) {
			foreach($pre_tree['forums'][$category] as $forum => $forum_title) {
				$tree[$category][$forum] = "$indent$forum_title";
				get_subs($forum,$category,$indent);
			} // end foreach
		}
	}

	foreach($pre_tree['parent'] as $forum_id => $forum_parent) {
		if (!$forum_parent) continue;
		$array = array();
		$array = get_parents($forum_id,array());
		$tree['tree'][$forum_id] = array_reverse($array);
	} // end foreach

	// Grab all available styles
	$styles = array();
	$query = "
		SELECT STYLE_ID,STYLE_NAME
		FROM {$config['TABLE_PREFIX']}STYLES
		WHERE STYLE_IS_ACTIVE='1'
		ORDER BY STYLE_NAME
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	while(list($style_id,$style_name) = $dbh->fetch_array($sth)) {
		$styles[$style_id] = $style_name;
	} // end while


	// Grab all available languages
	$langs = array();
	$query = "
		SELECT LANGUAGE_ID,LANGUAGE_TYPE,LANGUAGE_DESCRIPTION
		FROM {$config['TABLE_PREFIX']}LANGUAGES
		WHERE LANGUAGE_IS_ACTIVE='1'
		ORDER BY LANGUAGE_TYPE
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	while(list($lang_id,$lang_name,$lang_desc) = $dbh->fetch_array($sth)) {
		$langs[$lang_id] = array(
			"dir" => $lang_name,
			"name" => $lang_desc,
		);
	} // end while

	unlink("{$config['FULL_PATH']}/cache/forum_cache.php");

	lock_and_write("{$config['FULL_PATH']}/cache/forum_cache.php","<?php\n\$tree = " . var_export($tree,true) . ";\n\n\$style_cache = " . var_export($styles,true) . ";\n\n\$lang_cache = " . var_export($langs,true) . ";\n ?" . ">");
	@chmod("{$config['FULL_PATH']}/cache/forum_cache.php",0666);

	return array($tree,$styles,$langs);

} // end build_forums_list

// Build a custom bbcode tag parse list for Text editor to insert and do_markup to parse
function build_custom_tag_cache() {
	global $config,$dbh;

	$bbcode_tags = array();
	$query = "
		SELECT BBCODE_ID, BBCODE_TAG, BBCODE_MENU_SHOW, BBCODE_DESCRIPTION, BBCODE_MENU_PROMPT, BBCODE_MATCH_REGEX, BBCODE_MARKUP_RESULT
			FROM {$config['TABLE_PREFIX']}BBCODE
			WHERE BBCODE_ENABLE = 1
			ORDER BY BBCODE_MENU_ORDER, BBCODE_ID
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	while(list($ID, $tag, $show, $descrip, $prompt, $regex, $markup) = $dbh->fetch_array($sth)) {
		list($rawtag,$junk) = preg_split('#[:]#',$tag);
		$bbcode_tags[$ID]['descrip'] = $descrip;
		$bbcode_tags[$ID]['open'] = '[' . $tag . ']';
		$bbcode_tags[$ID]['close'] = '[/' . $rawtag . ']';
		$bbcode_tags[$ID]['show'] = $show;
		$bbcode_tags[$ID]['prompt'] = $prompt;
		$bbcode_tags[$ID]['regex'] = "#\[$tag\]" . $regex . "\[\/$rawtag\]#";
		$bbcode_tags[$ID]['markup'] = str_replace(array("\r\n", "\n", "\r"),'',stripslashes($markup));
	}

	lock_and_write("{$config['FULL_PATH']}/cache/custom_tag_cache.php","<?php\n\$bbcode_tags = " . var_export($bbcode_tags,true) . ";\n?>");
	@chmod("{$config['FULL_PATH']}/cache/custom_tag_cache.php",0666);
	return $bbcode_tags;
}

function get_parents($forum_id,$array) {

	global $pre_tree;

	if ($pre_tree['parent'][$forum_id]) {
		$array[] = $pre_tree['parent'][$forum_id];
		$array = get_parents($pre_tree['parent'][$forum_id],$array);
	}
	return $array;

} // end get_parents


function get_subs($forum,$category,$indent) {

	global $pre_tree,$tree;

	$indent = $indent . "&nbsp;&nbsp;&nbsp;";
	if (!isset($pre_tree['subforums'][$forum])) return;
	foreach($pre_tree['subforums'][$forum] as $k => $v) {
		$tree[$category][$k] = "$indent$v";
		if (isset($pre_tree['subforums'][$k])) {
			get_subs($k,$category,$indent);
		}
	}
}


// Lock a file, and write if lock was successful
function lock_and_write($file, $body, $append = 0) {
	ignore_user_abort(1);

	$mode = ($append == 1) ? "a" : "w";

	if ($fp = fopen($file, $mode)) {
		if (flock($fp, LOCK_EX)) {
			fwrite($fp, $body);
			flock($fp, LOCK_UN);
			fclose($fp);
			ignore_user_abort(0);
			return "";
		} else {
			fclose($fp);
			ignore_user_abort(0);
			return "no_lock";
		}
	} else {
		ignore_user_abort(0);
		return "no_write";
	}
}

function graemlin_url( $output, &$smarty ) {
	global $style_array, $config;

	if (!get_major_browser("ie")) {
		//$output = preg_replace('#ubbcode\-(body|pre)" style="height:\s+\d+px;"#s', 'ubbcode-\1" style="width: auto; height: auto;"', $output);
	}

	$output = str_replace('[end_news_blurb]', '', $output);
	$patterns[0] = "/%%GRAEMLIN_URL%%/";
	$patterns[1] = "/<<GRAEMLIN_URL>>/";
	$replaces[0] = $style_array['graemlins'];
	$replaces[1] = "{$config['BASE_URL']}/images/{$style_array['graemlins']}";
	return preg_replace( $patterns, $replaces , $output );
}


function array_get($arr, $key, $default = false) {
	if (is_array($arr) && array_key_exists($key, $arr) && !is_null($arr[$key])) {
		return $arr[$key];
	} else {
		return $default;
	}
}

function startElement( $parser, $tagName, $attrs) {
	global $current_tag,$xml_data,$item_id;
	if (strtolower($tagName) == "item" && !$item_id) {
		$item_id = 1;
	}
	$current_tag = strtolower( $tagName );
}
function endElement( $parser, $tagName ) {
	global $item_id;
	if (strtolower($tagName) == "item") {
		$item_id++;
	}
}
function charElement( $parser, $text ) {
	global $current_tag,$xml_data,$item_id;

	if ($item_id) {
		if (isset($xml_data[$item_id][$current_tag])) {
			$xml_data[$item_id][$current_tag] .= $text;
		} else {
			$xml_data[$item_id][$current_tag] = $text;
		}
	}
}

function getFeed($xml_feed) {

	global $xml_data, $item_id;

	// Open connection to RSS XML file for parsing.
	if (function_exists("curl_init"))	{
		$feed = curl_init(trim($xml_feed));
		curl_setopt($feed, CURLOPT_RETURNTRANSFER, 1);
		$raw_data = curl_exec($feed);
		curl_close($feed);
	} else {
		$raw_data = @file_get_contents(trim($xml_feed));
	}

	if (isset($raw_data)) {

		$xmlParser = xml_parser_create();

		// Set up element handler
		xml_set_element_handler( $xmlParser, "startElement", "endElement" );

		// Set up character handler
		xml_set_character_data_handler( $xmlParser, "charElement" );

		// Parse the data
		xml_parse( $xmlParser, $raw_data);

		// Free xml parser from memory
		xml_parser_free( $xmlParser );

	} else {
   		$xml_data = array();
	}

	return $xml_data;

} // end function getFeed

function ubb_error_handler( $code, $error, $file, $line, $context = array() ) {
	if ($code == E_PARSE) {
		echo @sprintf('<b>Error #%s:</b> %s<br />', $code, $error);
		echo @sprintf('<b>Line:</b> %s<br /><b>File:</b> %s<br />', $line, $file);
		exit;
	}
	if ($code == E_USER_ERROR) {
		echo @sprintf('<b>Error #%s:</b> %s<br />', $code, $error);
		echo @sprintf('<b>Line:</b> %s<br /><b>File:</b> %s<br />', $line, $file);
	}

	if (defined('E_STRICT') && $code == E_STRICT) {
		return true;
	}

	if (defined('UBB_FULL_DEBUG')) {
		global $ubb_debug;

		$ubb_debug .= @sprintf('<b>Error #%s:</b> %s<br />', $code, $error);
		$ubb_debug .= @sprintf('<b>Line:</b> %s<br /><b>File:</b> %s<br />', $line, $file);

	//===============================================================================================================
	//	Never, ever uncomment this.  This code could lead to security risks if uncommented.
	//	By that, I mean if there is ever an error on the forums, it could print the db login, db password, etc.
	//	It'll essentially dump out the contents of your config.inc.php file.
	//	This code is here PURELY for development, and purely for Ian Spence.
	//	Even if you are a developer, unless you access your development forums via 127.0.0.1, don't use this.
	//	Even if that is how you access it, keep in mind anyone who can access the site can have enough info to delete
	//	the forums. DELETE! That means no more data.
	//
	//	if (function_exists('debug_print_backtrace')) {
	//		ob_start();
	//			debug_print_backtrace();
	//			$trace = ob_get_contents();
	//		ob_end_clean();
	//		$ubb_debug .= @sprintf('<b>Backtrace:</b><pre style="overflow:auto">%s</pre><br />', htmlspecialchars($trace));
	//	}
	//
	//	Notice: If you have read all that and still want to uncomment the code, keep in mind
	//		that dingos will eat your baby. Then the dingo will steal your cell phone
	//		and you'll get a huge bill in the mail. AT&T won't believe that a dingo stole the phone,
	//		so don't even try telling them that. There goes your credit rating.
	//===============================================================================================================

		//$ubb_debug .= '<hr />';
	}

	return true;

}

function get_major_browser($var) {
	static $browser = null;

	if ($browser == null) {
		$tmp = strtolower($_SERVER['HTTP_USER_AGENT']);

		if (strpos($tmp, "opera") !== false) {
			if (strpos($tmp, "mozilla") !== false) {
				$browser = "firefox";
			} else {
				$browser = "opera";
			}
		} else if (strpos($tmp, "msie") !== false) {
			$browser = "ie";
		} else if (strpos($tmp, "mozilla") !== false || strpos($tmp, "gecko") !== false) {
			$browser = "firefox";
		} else if (strpos($tmp, "applewebKit") !== false) {
			$browser = "safari";
		} else {
			$browser = "";
			return false;
		}
	} else if ($browser == "") {
		return false;
	}
	return preg_match('#' . $var . '#i', $browser);
}

function get_spider_list($rebuild = false) {
	global $config, $dbh;

	static $spiders = null;

	if ($spiders == null) {
		$query = "
			SELECT	AGENTS
			FROM	{$config['TABLE_PREFIX']}SEARCH_AGENTS
		";

		$sth = $dbh->do_query( $query, __LINE__, __FILE__ );
		$result = $dbh->fetch_array($sth, MYSQL_ASSOC);

		if (trim($result['AGENTS']) == "") {
			return array();
		}

		$x = explode( "\n", $result['AGENTS'] );

		foreach( $x as $y ) {
			$tmp = explode('=', trim($y));
			$spiders[$tmp[0]] = $tmp[1];
		}
	}
	return $spiders;
}

function escape_ampersand($text) {
	$text = str_replace('&', '&amp;', $text);
	$text = preg_replace('/&amp;(#[0-9]+|[a-z]+);/', '&$1;', $text);
	return $text;
}

function get_current_url() {
	$http = "";
	if ($_SERVER['HTTPS'] == "off" || !$_SERVER['HTTPS']) {
		$http = "http";
	} else {
		$http = "https";
	}
	if ($_SERVER['REQUEST_URI']) {
		$url = $_SERVER['REQUEST_URI'];
	} else {
		$url = $_SERVER['SCRIPT_NAME'];
		if ($_SERVER['QUERY_STRING']) {
			$url .= "?{$_SERVER['QUERY_STRING']}";
		} // end if
	} // end if
	return "$http://{$_SERVER['HTTP_HOST']}{$url}";
}

function init_vars() {
	global $config;

	/**
	 * For variables added in new versions,
	 * give them a default value.
	 */

	$config['IMAGE_LIMIT'] = array_get($config, 'IMAGE_LIMIT', 10);
	$config['ENABLE_POST_COUNTS'] = array_get($config, 'ENABLE_POST_COUNTS', 1);
	$config['SHOW_ALL_GRAEMLINS'] = array_get($config, 'SHOW_ALL_GRAEMLINS', 0);
	$config['SHOW_TEASER_LATEST_POST'] = array_get($config, 'SHOW_TEASER_LATEST_POST', 0);
	$config['CATEGORY_ONLY_MODE'] = array_get($config, 'CATEGORY_ONLY_MODE', 0);
	$config['DISABLE_ONLINE_INVISIBLE'] = array_get($config, 'DISABLE_ONLINE_INVISIBLE', 0);
	$config['SEARCH_FRIENDLY_URLS'] = array_get($config, 'SEARCH_FRIENDLY_URLS', 0);
	$config['SEARCH_FRIENDLY_HTML_EXT'] = array_get($config, 'SEARCH_FRIENDLY_HTML_EXT', 0);
	$config['CALENDAR_START_DAY'] = array_get($config, 'CALENDAR_START_DAY', 0);
	$config['HOT_VIEWS'] = array_get($config, 'HOT_VIEWS', 100);
	$config['HOT_REPLIES'] = array_get($config, 'HOT_REPLIES', 10);
}

if (!function_exists("htmlspecialchars_decode")) {
    function htmlspecialchars_decode($string, $quote_style = ENT_COMPAT) {
    }
}

function rebuild_pm_count($user_id) {
	global $dbh, $config;

	$query = "
		SELECT t1.TOPIC_ID,t1.MESSAGE_LAST_READ
		FROM	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS as t1,
			{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS as t2
		WHERE	t1.TOPIC_ID = t2.TOPIC_ID
			AND t2.TOPIC_LAST_REPLY_TIME > t1.MESSAGE_LAST_READ
			AND t1.USER_ID = ?
	";

	$sth = $dbh->do_placeholder_query($query, array($user_id), __LINE__, __FILE__);
	$count = 0;
	while(list($tid,$lread) = $dbh->fetch_array($sth)) {
		$query = "
			select POST_TIME
			from {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
			where TOPIC_ID = ?
			order by POST_ID desc
			limit 1
		";
		$sti = $dbh->do_placeholder_query($query,array($tid),__LINE__,__FILE__);
		list($time) = $dbh->fetch_array($sti);
		if ($time && $lread < $time) {
			$count++;
		} // end if
	} // end while

	$query = "
		UPDATE	{$config['TABLE_PREFIX']}USER_PROFILE
		SET	USER_TOTAL_PM = ?
		WHERE	USER_ID = ?
	";
	$dbh->do_placeholder_query($query, array($count, $user_id), __LINE__, __FILE__);
}

function update_views_counter() {
	global $config, $dbh;

	$query = "
		select count(*),TOPIC_ID
		from {$config['TABLE_PREFIX']}TOPIC_VIEWS
		group by TOPIC_ID
	";
	$sth = $dbh->do_query($query, __LINE__, __FILE__);
	while(list($views,$view_topic) = $dbh->fetch_array($sth)) {
		$query = "
			update {$config['TABLE_PREFIX']}TOPICS
			set TOPIC_VIEWS = TOPIC_VIEWS + $views
			where TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query,array($view_topic),__LINE__,__FILE__);
	}
	$query = "
		delete from {$config['TABLE_PREFIX']}TOPIC_VIEWS
	";
	$dbh->do_query($query, __LINE__, __FILE__);
}

function handle_watchlist_notifications(&$data) {
	global $config, $dbh, $smarty, $html;

	$event = array_get($data, 'EVENT', 'REPLY');
	$poster = array_get($data, 'USER', false);
	$poster_name = array_get($data, 'USERNAME', false);
	$forum_id = array_get($data, 'FORUM', false);
	$post_id = array_get($data, 'POST', false);
	$topic_id = array_get($data, 'TOPIC', false);
	$post_body = array_get($data, 'BODY', '');
	$post_html = array_get($data, 'HTMLBODY', '');
	$title = array_get($data, 'TITLE', false);
	$attachments = array_get($data, 'ATTACHMENTS', false);
	$forumname = array_get($data, 'FORUM_NAME', false);

	if (!($poster && $forum_id && $post_id && $topic_id && $title)) {
		return null;
	}

	// Figure out who should be notified.
	// Check which groups have access to the forum this is in

	$query = "
		SELECT	GROUP_ID
		FROM	{$config['TABLE_PREFIX']}FORUM_PERMISSIONS
		WHERE	FORUM_ID = ? AND READ_TOPICS = 1
	";
	$sth = $dbh->do_placeholder_query($query,array($forum_id),__LINE__,__FILE__);


	$group_array = array();
	while($result = $dbh->fetch_array($sth)) {
		$group_array[] = $result['GROUP_ID'];
	}

	if (count($group_array) == 0) {
		return null;
	}

	$new_topic_clause = '';
	if ($event == 'TOPIC') {
		$new_topic_clause = ' OR wl.WATCH_NOTIFY_IMMEDIATE = 2 ';
	}

	// If I group by user language, I guarantee that I'll only do X includes,
	// where X is the total number of languages on these forums
	$query = "
		SELECT	up.USER_REAL_EMAIL, up.USER_LANGUAGE, wl.WATCH_TYPE, u.USER_DISPLAY_NAME, up.USER_TIME_OFFSET, up.USER_TIME_FORMAT
		FROM	{$config['TABLE_PREFIX']}USER_PROFILE up,
			{$config['TABLE_PREFIX']}WATCH_LISTS wl,
			{$config['TABLE_PREFIX']}USER_GROUPS ug,
			{$config['TABLE_PREFIX']}USERS u
		WHERE	((wl.WATCH_ID = ? and wl.WATCH_TYPE = 'f')
			OR (wl.WATCH_ID = ? and wl.WATCH_TYPE = 'u')
			OR (wl.WATCH_ID = ? and wl.WATCH_TYPE = 't'))
			AND up.USER_ID = wl.USER_ID
			AND ug.USER_ID = up.USER_ID
			AND up.USER_ID = u.USER_ID
			AND (wl.WATCH_NOTIFY_IMMEDIATE = 1 $new_topic_clause)
			AND up.USER_ID <> ?
			AND ug.GROUP_ID IN ( ? )
			AND u.USER_IS_BANNED <> 1
		GROUP BY up.USER_ID
		ORDER BY up.USER_LANGUAGE
	";
	$sth = $dbh->do_placeholder_query($query, array($forum_id, $poster, $topic_id, $poster, $group_array), __LINE__, __FILE__);

	$already_sent = array();
	$mailer = new mailer();

	while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
		if (in_array($result['USER_REAL_EMAIL'], $already_sent)) continue;
		$already_sent[] = $result['USER_REAL_EMAIL'];

		$mailer->set_language($result['USER_LANGUAGE']);
		$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $result['USER_DISPLAY_NAME']));

		// Fill in the subject
		switch ($result['WATCH_TYPE']) {
			case 't':
				$mailer->set_subject('WNT_SUBJECT', array('TITLE' => $title));
				break;
			case 'f':
				$mailer->set_subject('WNF_SUBJECT', array('FORUM' => $forumname, 'TITLE' => $title));
				break;
			case 'u':
				$mailer->set_subject('WNU_SUBJECT', array('USER' => $poster_name, 'TITLE' => $title));
				break;
		}

		if ($event == 'TOPIC') {
			$mailer->add_content('WNT_CONTENT', array('USERNAME' => $poster_name, 'BOARD_TITLE' => $config['COMMUNITY_TITLE']));
		} else {
			$mailer->add_content('WNP_CONTENT', array('USERNAME' => $poster_name, 'BOARD_TITLE' => $config['COMMUNITY_TITLE']));
		}
		$mailer->add_content('WNX_CONTENT');
		$mailer->add_content('WNX_CONTENT1', array('POST_URL' => make_ubb_url("ubb=showflat&Number=$post_id#Post$post_id", "", true, true)),true);
		$mailer->add_post($poster_name,$title,array(),$post_html,$post_body,array(),false);
		$mailer->ubbt_mail($result['USER_REAL_EMAIL']);
	}
}

function make_ubb_url($url, $title = "", $full = false, $texturl = false) {
	global $config, $var_start, $var_eq, $var_sep, $ubbt_lang;

	$base = ($full ? $config['FULL_URL'] : $config['BASE_URL']) . '/ubbthreads.php';

	if ($url == "") {
		return $base;
	}

	$base .= $var_start;

	// There should be no '&amp;' or '&amp;amp;' in the url, strip those JIC
	$url = str_replace('&amp;', '&', $url);

	if ($title && strtoupper($ubbt_lang['CHARSET']) != "UTF-8") {
		// Replace accented characters
		$title = htmlentities($title);
		$title = preg_replace('/&([a-zA-Z])(uml|acute|grave|circ|tilde|cedil|ring);/','$1',$title);
		$title = html_entity_decode($title);

		$title = preg_replace("#(&(amp|gt|lt|quot);|[^a-zA-Z0-9_])+#", " ", $title);
		$title = str_replace(' ', '_', trim($title));
	}
	$title = substr($title, 0, 30);
	

	// Old Fashioned URLs
	if ($var_eq == "=") {
		$url = ($texturl == true) ? $url : str_replace('&', '&amp;', $url);
		return $base . $url;
	}
	$anchor = "";
	if (strpos($url, '#') !== false) {
		list($url, $anchor) = explode('#', $url);
	}

	if ($anchor) {
		$anchor = '#' . $anchor;
	}

	$x = explode('&', $url);
	$params = array();
	foreach ($x as $y) {
		$m = explode('=', $y);
		$params[$m[0]] = $m[1];
	}

	$end = ($title ? $var_sep . $title : "") . ($config['SEARCH_FRIENDLY_HTML_EXT'] ? '.html' : "" ) . $anchor;

	$page = array_get($params, 'page', false);

	switch ($params['ubb']) {
		case "showflat":
			if (array_get($params, 'fpart', null) != null) {
				$params['page'] = $params['fpart'];
				unset($params['fpart']);
			}
			if (!(isset($params['topic']) || isset($params['Words']) || isset($params['gonew'])))
				return $base . "topics{$var_sep}{$params['Number']}" . ($page ? "{$var_sep}$page" : '') . $end;
			break;
		case "showthreaded":
			if (!(isset($params['topic']) || isset($params['Words']) || isset($params['gonew'])))
				return $base . "posts{$var_sep}{$params['Number']}" . $gonew . $end;
			break;
		case "showgallery":
			if (array_get($params, 'fpart', null) != null) {
				$params['page'] = $params['fpart'];
				unset($params['fpart']);
			}
			if (!(isset($params['topic']) || isset($params['Words']) || isset($params['gonew'])))
				return $base . "galleries{$var_sep}{$params['Number']}" . ($page ? "{$var_sep}$page" : '') . $end;
			break;
		case "showprofile":
			return $base . "users{$var_sep}{$params['User']}" . ($page ? "{$var_sep}$page" : '') . $end;
		case "cfrm":
			if (isset($params['c'])) {
				return $base . "category{$var_sep}{$params['c']}" . $end;
			} else {
				return $base . "forum_summary" . $end;
			}
		case "activetopics":
			if ($params['type'] == 't') {
				return $base . "activetopics{$var_sep}{$params['range']}{$var_sep}" . array_get($params, 'page', 1) . $end;
			} else if ($params['type'] == 'u') {
				return $base . "unansweredposts{$var_sep}{$params['range']}{$var_sep}" . array_get($params, 'page', 1) . $end;
			} else {
				return $base . "activeposts{$var_sep}{$params['range']}{$var_sep}" . array_get($params, 'page', 1) . $end;
			}
		case "postlist":

			if (!isset($params['order'])) {
				// Don't handle the conversion for sorting
				return $base . "forums{$var_sep}{$params['Board']}{$var_sep}" . array_get($params, 'page', 1) . $end;
			}
			break;
		case "search":
			return $base . "search" . $end;
		case "online":
			return $base . "online" . $end;

	}

	return $base . str_replace(array('&', '='), array($var_sep, $var_eq), $url) . $end;
}

function explode_data() {
	global $var_start, $var_sep, $config;

	if ($var_sep != "&amp;") {
		  $PATH_INFO = array_get($_SERVER, 'PATH_INFO', '');
    if (!$PATH_INFO) {
		  $PATH_INFO = array_get($_SERVER, 'ORIG_PATH_INFO', '');
    }
		$PATH_INFO = preg_replace( '#\.html$#', '', $PATH_INFO);

		$data = array();

		if ($PATH_INFO && (strpos($PATH_INFO, "{$var_start}ubb{$var_sep}") !== false)) {
			// Old Fashioned SE URLs
			$data = explode($var_sep,$PATH_INFO);
			$num_data = count($data);
			if($num_data % 2 == 0) {
				$data[] = '';
				$num_data++;
			} // end if

			$num_data = count($data);
			for ($i=1;$i<$num_data;$i+=2) {
				$_GET[$data[$i]] = $data[$i+1];
				$_REQUEST[$data[$i]] = $data[$i+1];
			} // end for

		} else {
			$parts = explode($var_sep, $PATH_INFO);
			if (count($parts) > 1) {
				array_shift($parts);
				$opts = array();
				switch ($parts[0]) {
					case "forum_summary":
						$opts['ubb'] = "cfrm";
						break;
					case "forums":
						$opts['ubb'] = "postlist";
						$opts['Board'] = $parts[1];
						$opts['page'] = array_get($parts, 2, 1);
						break;
					case "posts":
						$opts['ubb'] = "showthreaded";
						$opts['Number'] = $parts[1];
						$opts['page'] = array_get($parts, 2, 0);
						break;
					case "topics":
						$opts['ubb'] = "showflat";
						$opts['Number'] = $parts[1];
						$opts['page'] = array_get($parts, 2, 0);
						break;
					case "galleries":
						$opts['ubb'] = "showgallery";
						$opts['Number'] = $parts[1];
						$opts['page'] = array_get($parts, 2, 0);
						break;
					case "activeposts":
						$opts['ubb'] = "activetopics";
						$opts['type'] = "p";
						$opts['range'] = $parts[1];
						$opts['page'] = array_get($parts, 2, 1);
						break;
					case "unansweredposts":
						$opts['ubb'] = "activetopics";
						$opts['type'] = "u";
						$opts['range'] = $parts[1];
						$opts['page'] = array_get($parts, 2, 1);
						break;
					case "activetopics":
						$opts['ubb'] = "activetopics";
						$opts['type'] = "t";
						$opts['range'] = $parts[1];
						$opts['page'] = array_get($parts, 2, 1);
						break;
					case "users":
						$opts['ubb'] = "showprofile";
						$opts['User'] = $parts[1];
						$opts['page'] = $parts[2];
						break;
					case "category":
						$opts['ubb'] = "cfrm";
						$opts['c'] = $parts[1];
						break;
					case "search":
						$opts['ubb'] = "search";
						break;
					case "online":
						$opts['ubb'] = "online";
						break;
				}
				if (array_key_exists('page', $opts) && (!is_numeric($opts['page']) && $opts['page'] != "all")) {
					$opts['page'] = 0;
					}
				foreach ($opts as $k => $v) {
					$_GET[$k] = $v;
					$_REQUEST[$k] = $v;
				}
			}
		}
	}

	if(get_magic_quotes_gpc()) {
		$_GET = strip_slashes_full($_GET);
		$_REQUEST = strip_slashes_full($_REQUEST);
		$_POST = strip_slashes_full($_POST);
		$_COOKIE = strip_slashes_full($_COOKIE);
	}
} // end explode_data

function file_size($size) {
	$filesizename = array(" Bytes", " KB", " MB", " GB", " TB", " PB", " EB", " ZB", " YB");
	return $size ? round($size/pow(1024, ($i = floor(log($size, 1024)))), 2) . $filesizename[$i] : '0 Bytes'; 
} // end file_size

?>
