<?php
//  Ultimate Bulletin Board
//
//  Program authors: Rick Baker
//  Copyright (C) 2010 Mindraven.
//  Script Version 7.5.5

//  You may not distribute this program in any manner, modified or
//  otherwise, without the express, written consent from
//  Mindraven.
//
//  You may make modifications, but only for your own use and
//  within the confines of the UBB License Agreement
//  (see our website for that).
//
//  Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)


if(!defined("UBB_MAIN_PROGRAM")) exit;

class user {

	var $forum_access = array();
	var $site_access = array();
	var $cp_access = array();
	var $access_built = false;
	var $is_logged_in = false;

	// #######################################################################
	// Build the permission list for a userid
	// #######################################################################
	function build_permissions($Uid = "") {

		global $dbh, $config;

		if (!$Uid || $Uid == "deleted") $Uid = 1;

		// Get the list of perms
		$perm_list = array();
		$query = "
			select PERMISSION_NAME,PERMISSION_IS_HIGH,PERMISSION_IS_LOW,PERMISSION_TYPE from {$config['TABLE_PREFIX']}PERMISSION_LIST
		";
		$sth = $dbh->do_query($query,__LINE__,__FILE__);
		while(list($perm_name,$is_high,$is_low,$perm_type) = $dbh->fetch_array($sth)) {

			$value = "";
			if ($is_high == "1") {
				$value = "high";
			} else {
				$value = "low";
			} // end if

			$perm_list[$perm_type][$perm_name] = $value;
		} // end while

		// Build their permission list

		// First we grab all of their groups
		$query = "
			select GROUP_ID
			from {$config['TABLE_PREFIX']}USER_GROUPS
			where USER_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($Uid),__LINE__,__FILE__);

		$groups = array();
		while($result = $dbh->fetch_array($sth)) {
			$groups[] = $result['GROUP_ID'];
		} // end while

		$_SESSION['mygroups'] = serialize($groups);

		// If the user is in group 3, we need to grab all forums they
		// moderate
		$mod_forums = array();
		if (in_array("3",$groups)) {
			$query = "
				select FORUM_ID
				from {$config['TABLE_PREFIX']}MODERATORS
				where USER_ID = ?
			";
			$sth = $dbh->do_placeholder_query($query,array($Uid),__LINE__,__FILE__);

			while($result = $dbh->fetch_array($sth)) {
				$mod_forums[] = $result['FORUM_ID'];
			} // end while
		} // end if


		if (!sizeof($groups)) {
			$groups[] = "5";
		} // end if

		// Now build their forum access list based on those groups
		$build_forum_access = array();
		$build_site_access = array();
		$build_cp_access = array();
		$forum_negatives = array();
		$forum_zeros = array();
		$site_negatives = array();
		$site_zeros = array();
		$cp_negatives = array();
		$cp_zeros = array();
		$approve_posts = 0;

		foreach($groups as $k => $gid) {

			/**
			 * Build Forum Permissions
			 */

			$query = "
				select *
				from {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
				where GROUP_ID = ?
			";

			$sth = $dbh->do_placeholder_query($query,array($gid),__LINE__,__FILE__);
			while($result = $dbh->fetch_array($sth,MYSQL_ASSOC)) {
				$this_group = 0;
				foreach($result as $k => $v) {
					if ($k == "GROUP_ID") {
						$this_group = $v;
						continue;
					}
					if ($k == "FORUM_ID") {
						$fid = $v;
						continue;
					} // end if
					if ($fid == "New Forum Template") continue;

					// If they can approve posts, then we need to 
					// set CP access to true.
					if ($k == "APPROVE_ANY" && ($v > 0)) {
						$approve_posts=1;
					}

					// If this is the moderator group, only set permissions
					// if they actually moderate this forum.
					if ($this_group == 3) {
						if (!in_array($fid,$mod_forums)) continue;
					}

					// If it's zero, we add it to the list of perms with 0
					if ($v == 0) {
						$forum_zeros[$k][$fid] = 1;
					} // end if

					// If this is a negative permission, they do not
					// get access to this permission at all
					if ($v == -1) {
						$forum_negatives[$fid][] = $k;
						continue;
					} // end if

					// Set with a high or low value?
					$hilo = $perm_list['forum'][$k];
					if ($hilo == "high") {
						if ($v > $build_forum_access[$k][$fid] && $v != 0) {
							$build_forum_access[$k][$fid] = $v;
						} // end if
					} else {
						if (!isset($build_forum_access[$k][$fid]) && !$forum_zeros[$k][$fid]) {
							$build_forum_access[$k][$fid] = $v;
						} // end if
						if ($v < $build_forum_access[$k][$fid]) {
							$build_forum_access[$k][$fid] = $v;
						} // end if
					} // end if

				} // end foreach

			} // end while
			/**
			 * Build Site Permissions
			 */

			$query = "
				select *
				from {$config['TABLE_PREFIX']}SITE_PERMISSIONS
				where GROUP_ID = ?
			";

			$sth = $dbh->do_placeholder_query($query,array($gid),__LINE__,__FILE__);
			while($result = $dbh->fetch_array($sth,MYSQL_ASSOC)) {
				foreach($result as $k => $v) {
					if ($k == "GROUP_ID") continue;

					// If it's zero, we add it to the list of perms with 0
					if ($v == 0) {
						$site_zeros[$k] = 1;
					} // end if

					// If this is a negative permission, they do not
					// get access to this permission at all
					if ($v == -1) {
						$site_negatives[] = $k;
						continue;
					} // end if

					// Set with a high or low value?
					$hilo = $perm_list['site'][$k];
					if ($hilo == "high") {
						if (($v > $build_site_access[$k]) && $v != 0) {
							$build_site_access[$k] = $v;
						} // end if
					} else {
						if (!isset($build_site_access[$k]) && !$site_zeros[$k]) {
							$build_site_access[$k] = $v;
						} // end if
						if ($v < $build_site_access[$k]) {
							$build_site_access[$k] = $v;
						} // end if
					} // end if

				} // end foreach

			} // end while


			/**
			 * Build CP Permissions
			 */

			if ($approve_posts) {
				$build_cp_access['APPROVE_POSTS'] = 1;
			}
			$query = "
				select *
				from {$config['TABLE_PREFIX']}CP_PERMISSIONS
				where GROUP_ID = ?
			";

			$sth = $dbh->do_placeholder_query($query,array($gid),__LINE__,__FILE__);
			while($result = $dbh->fetch_array($sth,MYSQL_ASSOC)) {
				foreach($result as $k => $v) {
					if ($k == "GROUP_ID") continue;

					// If it's zero, we add it to the list of perms with 0
					if ($v == 0) {
						$cp_zeros[$k] = 1;
					} // end if

					// If this is a negative permission, they do not
					// get access to this permission at all
					if ($v == -1) {
						$cp_negatives[] = $k;
						continue;
					} // end if

					// Set with a high or low value?
					$hilo = $perm_list['cp'][$k];
					if ($hilo == "high") {
						if (($v > $build_cp_access[$k]) && $v != 0) {
							$build_cp_access[$k] = $v;
						} // end if
					} else {
						if (!isset($build_cp_access[$k]) && !$cp_zeros[$k]) {
							$build_cp_access[$k] = $v;
						} // end if
						if ($v < $build_cp_access[$k]) {
							$build_cp_access[$k] = $v;
						} // end if
					} // end if

				} // end foreach

			} // end while
		} // end foreach

		// We need to unset any negative permissions
		foreach($forum_negatives as $fid => $array) {
			foreach($array as $k => $v) {
				unset($build_forum_access[$v][$fid]);
			} // end foreach
		} // end foreach

		// Unset any perms that are 0, we don't need em
		foreach ($forum_zeros as $pid => $array) {
			foreach($array as $k => $v) {
				if ($build_forum_access[$pid][$k] == 0) {
					unset($build_forum_access[$pid][$k]);
				}
			}
		}

		foreach($site_negatives as $k => $v) {
			unset($build_site_access[$v]);
		} // end foreach

		// Unset any perms that are 0, we don't need em
		foreach ($site_zeros as $k => $v) {
			if ($build_site_access[$k] == 0) {
				unset($build_site_access[$k]);
			}
		}

		foreach($cp_negatives as $k => $v) {
			unset($build_cp_access[$v]);
		} // end foreach

		// Unset any perms that are 0, we don't need em
		foreach ($cp_zeros as $k => $v) {
			if ($build_cp_access[$k] == 0) {
				unset($build_cp_access[$k]);
			}
		}

		$this->forum_access = $build_forum_access;
		$this->site_access = $build_site_access;
		$this->cp_access = $build_cp_access;
		$this->access_built = true;

		$now = time();
		$stale = $now - ((60 * 60) * 4);

		// Get rid of any stale permissions (Older than 4 hours)
		$query = "
			delete from {$config['TABLE_PREFIX']}CACHED_PERMISSIONS
			where CACHED_TIMESTAMP < ?
		";
		$dbh->do_placeholder_query($query,array($stale),__LINE__,__FILE__);

		// Now populate the cached permissions table with the serialized results
		$query_vars = array($Uid,serialize($build_forum_access),serialize($build_site_access),serialize($build_cp_access),$now);
		$query = "
			replace into {$config['TABLE_PREFIX']}CACHED_PERMISSIONS
			(USER_ID,FORUM_PERMISSIONS,SITE_PERMISSIONS,CP_PERMISSIONS,CACHED_TIMESTAMP)
			values
			( ? , ? , ? , ? , ? )
		";
		$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);



	} // end function build_permissions

	// ######################################################################
	// Grab a user's permission list
	// ######################################################################
	function get_permissions($Uid = "") {

		global $dbh, $config;

		if (!$Uid) $Uid = 1;
		// FIXME:  This causes problems during the install
		if (defined('INSTALL')) return;

		$query = "
			select USER_ID,FORUM_PERMISSIONS,SITE_PERMISSIONS,CP_PERMISSIONS
			from {$config['TABLE_PREFIX']}CACHED_PERMISSIONS
			where USER_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($Uid),__LINE__,__FILE__);
		list($id,$forum_perms,$site_perms,$cp_perms) = $dbh->fetch_array($sth);

		if ($forum_perms) {
			$this->forum_access = unserialize($forum_perms);
		} else {
			$this->forum_access = array();
		} // end if

		if ($site_perms) {
			$this->site_access = unserialize($site_perms);
		} else {
			$this->site_access = array();
		} // end if

		if ($cp_perms) {
			$this->cp_access = unserialize($cp_perms);
		} else {
			$this->cp_access = array();
		} // end if

		$this->access_built = true;

		// If we didn't find an entry, then we need to rebuild the permission
		/// list for this user.
		if (!$id) {
			$this->build_permissions($Uid);
		}

	} // end function get_permissions

	// ######################################################################
	// Get Watch lists
	// ######################################################################
	function cache_watch_lists($uid) {

		global $config,$dbh;

		$query = "
			select WATCH_ID,WATCH_TYPE
			from {$config['TABLE_PREFIX']}WATCH_LISTS
			where USER_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
		$watch_list = array();
		while(list($id,$type) = $dbh->fetch_array($sth)) {
			$watch_list[$type][$id] = $id;
		} // end while
		$_SESSION['watch_lists'] = serialize($watch_list);

	} //end cache_watch_lists

	// ######################################################################
	// Check access to a permission
	// ######################################################################
	function check_access($type="",$perm="",$board="") {

		$access = false;
		// Check forum access
		if ($type == "forum") {
			if (isset($this->forum_access[$perm][$board])) {
				$access = $this->forum_access[$perm][$board];
			} // end if
			return $access;
		} // end if

		// Check Site access
		if ($type == "site") {
			if (isset($this->site_access[$perm])) {
				$access = $this->site_access[$perm];
			} // end if
			return $access;
		} // end if

		// Check CP access
		if ($type == "cp") {
			if (!$perm) {
				return sizeof($this->cp_access);
			} // end if
			if (isset($this->cp_access[$perm])) {
				$access = $this->cp_access[$perm];
			} // end if
			return $access;
		} // end if

	} // end function check_access



	// ######################################################################
	// AUTHENTICATE FUNCTION
	// Authenticate the user
	// ######################################################################
	function authenticate($Query="") {

		global $dbh, $config, $myinfo ,$ubbt_lang,$forumvisit, $html;

		// -----------------------------------------
		// There are some fields that we ALWAYS need
		if ($Query != "*") {
			if ($Query) { $Query .=", "; }
			$Query .= "t1.USER_ID, t1.USER_DISPLAY_NAME, t1.USER_PASSWORD, t1.USER_SESSION_ID, t1.USER_MEMBERSHIP_LEVEL, t1.USER_IS_BANNED,t1.USER_RULES_ACCEPTED, t1.USER_IS_UNDERAGE, t2.USER_TOTAL_PM, t2.USER_STYLE, t2.USER_HIDE_LEFT_COLUMN,t2.USER_HIDE_RIGHT_COLUMN, t2.USER_LANGUAGE, t2.USER_MOOD, t2.USER_RELATIVE_TIME, t2.USER_TIME_OFFSET,t2.USER_SHOW_ALL_GRAEMLINS, t2.USER_AVATAR, t2.USER_TITLE, t2.USER_CUSTOM_TITLE, t2.USER_NAME_COLOR, t2.USER_SHOW_LEFT_MYSTUFF,t2.USER_GROUP_IMAGES,t2.USER_TIME_FORMAT";
		}
		$Uid = $myinfo['id'];

		$query = "
			SELECT $Query
			FROM {$config['TABLE_PREFIX']}USERS as t1,
				 {$config['TABLE_PREFIX']}USER_PROFILE as t2
			WHERE t1.USER_ID = ?
			AND	t1.USER_ID = t2.USER_ID
		";
		$sth = $dbh -> do_placeholder_query($query,array($Uid),__LINE__,__FILE__);

		$thisuser = $dbh -> fetch_array($sth);
		$dbh -> finish_sth($query);


		// Check if board is locked into flat or threaded
		if (isset($config['TOPIC_DISPLAY_OPTIONS']) && $config['TOPIC_DISPLAY_OPTIONS'] == "flat") {
			$thisuser['USER_TOPIC_VIEW_TYPE'] = "flat";
		} // end if
		if (isset($config['TOPIC_DISPLAY_OPTIONS']) && $config['TOPIC_DISPLAY_OPTIONS'] == "threaded") {
			$thisuser['USER_TOPIC_VIEW_TYPE'] = "threaded";
		} // end if

		// Assume they aren't logged in for starters
		$this->is_logged_in = false;

		if ( ($thisuser['USER_SESSION_ID']) && ($thisuser['USER_SESSION_ID'] == $myinfo['session']) ) {
			$this->is_logged_in = true;
		} elseif ($myinfo['key']) {

			if ($myinfo['key'] == md5("{$thisuser['USER_ID']}{$thisuser['USER_PASSWORD']}")) {

				$this->is_logged_in = true;
				srand((double)microtime()*1000000);
				$newsessionid = md5(rand(0,32767));
				$date = $html->get_date();

				$query = "
					select 	USER_LAST_VISIT_TIME
					from 	{$config['TABLE_PREFIX']}USER_DATA
					where	USER_ID = ?
				";
				$sth = $dbh->do_placeholder_query($query,array($Uid),__LINE__,__FILE__);
				list($laston) = $dbh->fetch_array($sth);

				$query = "
					update	{$config['TABLE_PREFIX']}USERS
					set	USER_SESSION_ID = ?
					where	USER_ID = ?
				";
				$dbh -> do_placeholder_query($query,array($newsessionid,$Uid),__LINE__,__FILE__);

				$query = "
					update	{$config['TABLE_PREFIX']}USER_DATA
					set	USER_LAST_VISIT_TIME = ?
					where	USER_ID = ?
				";
				$dbh -> do_placeholder_query($query,array($date,$Uid),__LINE__,__FILE__);
				$html -> ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_mysess","$newsessionid","0");
				$html->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_x","-{$Uid}-",time()+$config['COOKIE_LIFETIME']);

				rebuild_pm_count($Uid);
				$this->cache_watch_lists($Uid);
        rebuild_islands(0,array("online"));
			} // end if
		}  // end if

		if ($this->is_logged_in == false) {
			$myinfo['id'] = 0;
			$Uid = 1;
			$myinfo['key'] == "";
			$html->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_myid","0");
			$html -> ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_key","",time()+$config['COOKIE_LIFETIME']);

			$thisuser = array();
			// ------------------------------------------------------------------
			// Authenticate failed so we need to return all of the array keys with
			// an empty value
			$keys = preg_split("#,#",$Query);
			for($i=0;$i<sizeof($keys);$i++) {
				$keys[$i] = str_replace(" ","",$keys[$i]);
				$keys[$i] = str_replace("t1.","",$keys[$i]);
				$keys[$i] = str_replace("t2.","",$keys[$i]);
				$thisuser[$keys[$i]] = "";
			} // end for
		} // end if

		// ------------------------
		// Check if they are banned
		if ($thisuser['USER_IS_BANNED']) {
			$html->check_ban($Uid,$thisuser['USER_TIME_OFFSET'],$thisuser['USER_TIME_FORMAT']);
			$this->check_ban();
		}

		// Now grab their permission list if needed
		if (!$this->access_built) {
			$this->get_permissions($Uid);
		} // end if

		return $thisuser;
	}


	// #######################################################################
	// Clear any cached permissions
	// #######################################################################
	// Get rid of any old cached permissions so they are rebuilt
	function clear_cached_perms($Uid="") {
		global $config,$dbh;

		$clause = "";
		if ($Uid) {
			$Uid = addslashes($Uid);
			$clause = "where USER_ID = '$Uid'";
		} // end if
		$query = "
			delete from {$config['TABLE_PREFIX']}CACHED_PERMISSIONS
			$clause
		";
		$dbh->do_query($query,__LINE__,__FILE__);
	} // end function rebuild_perms


	// #######################################################################
	// Check_ban
	// #######################################################################
	function check_ban() {
		global $ubbt_lang,$dbh,$config, $html,$smarty;
		$Hostname = find_environmental('REMOTE_ADDR');

		$query = "
			SELECT BANNED_HOST
			FROM   {$config['TABLE_PREFIX']}BANNED_HOSTS
			WHERE  ? LIKE BANNED_HOST
		";
		$sth = $dbh -> do_placeholder_query($query,array($Hostname),__LINE__,__FILE__);
		list ($Checkhost) = $dbh -> fetch_array($sth);
		$dbh -> finish_sth($sth);
		if ($Checkhost) {
			$html = new html;
			require_once("{$config['FULL_PATH']}/languages/{$config['LANGUAGE']}/generic.php");
			$smarty->assign_by_ref('lang',$ubbt_lang);
			$html->not_right("{$ubbt_lang['IP_BANNED']}");
		}
	}


	// #######################################################################
	// Check auto-join groups
	// #######################################################################
	function check_group_join($uid="",$count="") {
		global $config,$dbh;

		$mygroups = unserialize($_SESSION['mygroups']);
		$newgroup = 0;
		$query = "
			select GROUP_ID,GROUP_POST_COUNT_JOIN
			from {$config['TABLE_PREFIX']}GROUPS
			where GROUP_POST_COUNT_JOIN > 0
			order by GROUP_POST_COUNT_JOIN desc
		";
		$sth = $dbh->do_query($query,__LINE__,__FILE__);
		while(list($gid,$posts) = $dbh->fetch_array($sth)) {
			if ($count >= $posts && (!in_array($gid,$mygroups))) {
				$newgroup = 1;
				$query = "
					replace into {$config['TABLE_PREFIX']}USER_GROUPS
					(USER_ID,GROUP_ID)
					values
					( ? , ? )
				";
				$dbh->do_placeholder_query($query,array($uid,$gid),__LINE__,__FILE__);
				// TODO:
				// Give some type of notice to the user?
			} // end if
		} // end while

		if ($newgroup) {
			$this->clear_cached_perms($uid);
		}

	} // end function


/*
	function get_read_status($type, $id, $time, $extra = null) {
		global $config;

		if ($type == "post") {
			return !(in_array($id,
		if (!in_array($PNumber,$_SESSION['topicread']['threaded_read']['track']) && $time > $extra) {
			return true;
		} else { return false;
		}

		switch ($type) {
			case "post":
			case "topic":
			case "forum":

		}
	}

	function set_read_status($type, $id, $val = null) {
		if ($val == null) {
			global $html;
			$val = $html->get_date();
		}

		if ($type == "post") {
			$_SESSION['topicread']['threaded_read']['track'][] =
		}



	}

	function rebuild_read_status() {

	}

	function save_read_status() {

	}*/
}
?>
