<?php

//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_addfavforum_gpc () {
	return array(
		"input" => array(
			"Board" => array("Board","get","int"),
		),
		"wordlets" => array("addfavforum"),
		"user_fields" => "USER_EMAIL_WATCHLISTS",
		"regonly" => 0,
	);
} // end page_addfavforum_gpc
	
function page_addfavforum_run () {

	global $userob,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$var_start,$var_eq,$var_sep,$var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars
	
	$smarty_data = array();

	$html = new html;

	// --------------------------------------------
	// Let's find out if they should be here or not
	if (!$userob->check_access("forum","READ_TOPICS",$Board)) {
		$html -> not_right($ubbt_lang['NO_PERM']);
	}
	
	$query_vars = array($user['USER_ID'],$Board);
	$query = "
	SELECT count(*)
	FROM   {$config['TABLE_PREFIX']}WATCH_LISTS
	WHERE  USER_ID = ?
	AND		 WATCH_ID = ?
	AND    WATCH_TYPE = 'f'
	";
	$sth = $dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	list($check) = $dbh -> fetch_array($sth);

	$currtime = $html->get_date();

	// -----------------------------------------------
	// Let's make sure this  isn't already in our list
	// If it is then we remove it from the fav list
	if (!$check){

		if ($user['USER_EMAIL_WATCHLISTS']) {
			$notify = 1;
		} else {
			$notify = 0;
		} // end if
		
		$query_vars_2 = array($user['USER_ID'],$Board,$notify);
		
		$query = "
			insert into {$config['TABLE_PREFIX']}WATCH_LISTS
			(USER_ID,WATCH_ID,WATCH_TYPE,WATCH_NOTIFY_IMMEDIATE)
			values
			( ? , ? , 'f' , ? )
		";
		$dbh -> do_placeholder_query($query,$query_vars_2,__LINE__,__FILE__);
		
		$watch_lists = unserialize($_SESSION['watch_lists']);
		$watch_lists['f'][$Board] = $Board;
		$_SESSION['watch_lists'] = serialize($watch_lists);
		
		$query_vars = array($currtime,$user['USER_ID']);
		$query = "
		UPDATE {$config['TABLE_PREFIX']}USER_DATA
		SET    USER_LAST_VISIT_TIME = ?
		WHERE  USER_ID  = ?
		";
		$dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
		
		$heading = $ubbt_lang['FORUM_IN'];
		$forumconfirm = $ubbt_lang['FORUM_CONFIRM'];
	}
	else {

		// ------------------------------------------------------
		// Delete the forum

		$query_vars = array($user['USER_ID'],$Board);
		$query = "
			delete from {$config['TABLE_PREFIX']}WATCH_LISTS
			where	USER_ID = ?
			and		WATCH_ID = ?
			and   WATCH_TYPE = 'f'
		";
		$dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
		
		$watch_lists = unserialize($_SESSION['watch_lists']);
		unset($watch_lists['f'][$Board]);
		$_SESSION['watch_lists'] = serialize($watch_lists);
		
		$query_vars = array($currtime,$user['USER_ID']);
		$query = "
		UPDATE {$config['TABLE_PREFIX']}USER_DATA
		SET    USER_LAST_VISIT_TIME = ?
		WHERE  USER_ID  = ?
		";
		$dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
		
		$heading = $ubbt_lang['FORUM_OUT'];
		$forumconfirm = $ubbt_lang['FORUMOUT_CONFIRM'];
	}

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$html->send_redirect(
		array(
			"redirect" => "postlist&Board=$Board",
			"heading" => $heading,
			"body" => "{$forumconfirm} {$ubbt_lang['RET_FORUM']}",
			"returnlink" => "<a href=\"" . make_ubb_url("ubb=postlist&Board=$Board", "", false) . "\">{$ubbt_lang['FORUM_RETURN']}</a>",
			"breadcrumb" => <<<EOF
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 $heading
EOF
			,
		)
	);

}
?>
