<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;


function page_addfavuser_gpc () {
	return array(
		"input" => array(
			"User" => array("User","get","int"),
			"n" => array("n","get","int"),
			"p" => array("p","get","int"),
			"f" => array("f","get","int"),
		),
		"wordlets" => array("addfavuser"),
		"user_fields" => "USER_TOPIC_VIEW_TYPE",
		"regonly" => 1,
	);
} // end page_cfrm_gpc


function page_addfavuser_run () {
	
	global $in,$user,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$var_start,$var_eq,$var_sep,$var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars
	
	$html = new html;
	
	// Smarty data
	$data = array();
	
	// -----------------------------------------------------------
	// Let's make sure this user isn't already in our favorites
	$query_vars = array($user['USER_ID'],$User);
	$query = "
		SELECT USER_ID
		FROM   {$config['TABLE_PREFIX']}WATCH_LISTS
		WHERE  USER_ID  = ?
		AND    WATCH_ID = ?
		AND		 WATCH_TYPE = 'u'
	";
	$sth = $dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	list($check) = $dbh -> fetch_array($sth);
	$dbh -> finish_sth($sth);
		
	if (!$check) {

		// ------------------------------------------------------
		// Insert the details into the database
		$query = "
			INSERT INTO {$config['TABLE_PREFIX']}WATCH_LISTS
			(USER_ID, WATCH_ID, WATCH_TYPE)
			VALUES ( ? , ? , 'u' )
		";
		$dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
		$heading = $ubbt_lang['ADDED'];
		$body = $ubbt_lang['ADDED_BODY'];
		
		$watch_lists = unserialize($_SESSION['watch_lists']);
		$watch_lists['u'][$User] = $User;
		$_SESSION['watch_lists'] = serialize($watch_lists);
	} else {
		
		// Remove from favorites
		$query = "
			delete from	{$config['TABLE_PREFIX']}WATCH_LISTS
			where				USER_ID = ?
			and					WATCH_ID = ?
			and					WATCH_TYPE = 'u'
		";
		$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
		$heading = $ubbt_lang['REMOVED'];
		$body = $ubbt_lang['REMOVED_BODY'];	
		$watch_lists = unserialize($_SESSION['watch_lists']);
		unset($watch_lists['u'][$User]);
		$_SESSION['watch_lists'] = serialize($watch_lists);
	}
		
	if (!isset($PHPSESSID)) {
		$PHPSESSID = "";
	}
	
	if ($n) {
		$return_page = "show{$user['USER_TOPIC_VIEW_TYPE']}&Number=$n&page=$p&fpart=$f";
	} else {
		$return_page = "showprofile&User=$User";
	} // end if

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$html->send_redirect(
		array(
			"redirect" => "$return_page",
			"heading" => $heading,
			"body" => "{$body}",
			"returnlink" => "<a href=\"" . make_ubb_url("ubb=$return_page", "", false) . "\">{$ubbt_lang['RETURN']}</a>",
			"breadcrumb" => <<<EOF
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 $heading
EOF
			,
		)
	);
		

}

?>
