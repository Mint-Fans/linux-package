<?php

//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_adduser_gpc () {
	return array(
		"input" => array(
			"p" => array("p","post","alpha"),
			"Loginname" => array("Loginname","post",""),
			"Displayname" => array("Displayname","post",""),
			"Email" => array("Email","post",""),
			"Email_verify" => array("Email_verify","post",""),
			"month" => array("month","post","int"),
			"day" => array("day","post","int"),
			"year" => array("year","post","int"),
			"Loginpass" => array("USER_PASSWORD","post",""),
			"Verify" => array("Verify","post",""),
			"captcha" => array("captcha","post","alphanum"),
		),
		"wordlets" => array("adduser","changebasic","changedisplay"),
		"user_fields" => "",
		"regonly" => 0,
	);
} // end page_cfrm_gpc

function page_adduser_run () {

	global $smarty,$user,$html,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$var_start,$var_eq,$var_sep,$var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$smarty_data = array();

	// ----------------------------------------------------
	// If Displayname is blank then set it to the Loginname
	if (!$Displayname) {
		$Displayname = $Loginname;
	}

	// --------------------------------------
	// Check to see if this is the first user
	$query = "
		SELECT COUNT(USER_ID)
		FROM   {$config['TABLE_PREFIX']}USERS
	";
	$sth = $dbh -> do_query($query,__LINE__,__FILE__);
	list ($firstuser) = $dbh -> fetch_array($sth);
	$dbh -> finish_sth($sth);


	// --------------------------------------------------------
	// If we are checking age, we make sure they are old enough
	if ( ($config['DO_AGE_CHECK']) && ($p != "y") ){
		if (isset($_COOKIE[$config['COOKIE_PREFIX'] . "ubbt_dob"])) {
        		list ($month,$day,$year) = preg_split("#/#",$_COOKIE[$config['COOKIE_PREFIX'] . "ubbt_dob"]);
    		}
    		if (!checkdate($month,$day,$year)) {
        		$html -> not_right($ubbt_lang['INVALID_DATE']);
    		}
    		$currday = date("d");
    		$currmon = date("m");
    		$curryea = date("Y");
    		$years = $curryea - $year;
    		if ($years < $config['MINIMUM_AGE']) {
        		$nopass = 1;
    		}
    		if ($years == $config['MINIMUM_AGE']) {
        		if ($currmon < $month) {
            		$nopass = 1;
        		}
        		if ( ($currmon == $month) && ($currday < $day) ) {
             		$nopass = 1;
        		}
    		}
    		if ($nopass && !$config['under13']) {
        		$html -> ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_pass","invalid",time()+30758400);
        		$html -> ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_dob","$month/$day/$year",time()+30758400);
        		$html -> not_right($ubbt_lang['UNDERAGE'],$Cat);
    		}
    		else {
        		if ($nopass) {
            			$html -> ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_coppauser","1");
        		}
        		$html -> ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_pass","ok",time()+30758400);
        		$html -> ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_dob","$month/$day/$year",time()+30758400);
        		header("Location: {$config['FULL_URL']}/ubbthreads.php?ubb=newuser&p=y&PHPSESSID=$PHPSESSID");
    		}
	}

	// If CAPTCHA is turned on, let's make sure it matches
	if (($config['CAPTCHA'] == "gd" || $config['CAPTCHA'] == "im") && ((strtolower($captcha) != strtolower($_SESSION['cp_code'])) || !$captcha)) {
		$html->not_right($ubbt_lang['NO_IMAGE_VERIFY']);
	} // end if

	// --------------------------------------------------------------------
	// Get rid of any unverified email accounts that are over 24 hours old
	$deldate = $html -> get_date();
	$deldate = $deldate - 86400;

	$query = "
		SELECT USER_ID
		FROM {$config['TABLE_PREFIX']}USERS
		WHERE  USER_IS_APPROVED <> 'no'
		AND    USER_IS_APPROVED <> 'yes'
		AND    USER_REGISTERED_ON < '$deldate'
	";
	$sth = $dbh -> do_query($query,__LINE__,__FILE__);

	while (list($number) = $dbh -> fetch_array($sth)) {
		$query = "
			select	TOPIC_ID
			from 	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
			where	USER_ID= '$number'
		";
		$sth2 = $dbh->do_query($query,__LINE__,__FILE__);
		while(list($message_id) = $dbh->fetch_array($sth2)) {
			$query = "
				DELETE FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS
				WHERE  TOPIC_ID = '$message_id'
			";
			$dbh -> do_query($query,__LINE__,__FILE__);
			$query = "
				delete from {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
				where TOPIC_ID = '$message_id'
			";
			$dbh->do_query($query,__LINE__,__FILE__);
			$query = "
				delete from	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
				where	USER_ID = '$number'
			";
			$dbh->do_query($query,__LINE__,__FILE__);
		}

		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}USERS
			WHERE  USER_ID='$number'
		";
		$dbh -> do_query($query,__LINE__,__FILE__);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}USER_PROFILE
			WHERE  USER_ID='$number'
		";
		$dbh -> do_query($query,__LINE__,__FILE__);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}USER_DATA
			WHERE  USER_ID='$number'
		";
		$dbh -> do_query($query,__LINE__,__FILE__);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}USER_GROUPS
			WHERE  USER_ID='$number'
		";
		$dbh -> do_query($query,__LINE__,__FILE__);
	}


	// ------------------------
	// Predefine some variables
	$Password = $Loginpass;
	$nopass = "";
	$extrahtml = "";
	if (!isset($PHPSESSID)) {
		$PHPSESSID = "";
	}

	// Make sure Email and Email_verify are the same
	if ($Email != $Email_verify) {
		$html->not_right($ubbt_lang['EMAIL_NO_MATCH']);
	}

	// ------------------------------------------------------------
	// If all required info is not filled in, then we can't proceed
	if((!$Loginname)||(!$Displayname)||(!$Email)||(!$Email_verify)||(!$Password)||(!$Verify)){
		$html -> not_right($ubbt_lang['ALL_FIELDS']);
	}

	// Get rid of spaces at the beginning and end of Login/Display/Password
	$Loginname = trim($Loginname);
	$Displayname = trim($Displayname);
	$Password = trim($Password);

	// Make sure the password has been provided properly
	list($ok,$err) = reg_validate_passwd($Password, $Verify, $Displayname);
	if($ok === false) { $html->not_right($ubbt_lang[$err]); }
	$pass = $Password;

	// -----------------------------------------------
	// Check all required optional registration fields
	// Another ugly section that makes sure fields are
	// of the proper format and within the proper boundaries.
	$uploaded = 0;
	$pictype = "";
	$query = "
	SELECT REGISTRATION_FIELD,REGISTRATION_SHOW_FIELD,REGISTRATION_REQUIRE_FIELD
	FROM {$config['TABLE_PREFIX']}REGISTRATION_FIELDS
	WHERE REGISTRATION_SHOW_FIELD='1'
	OR REGISTRATION_REQUIRE_FIELD='1'
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	$regfields = "";
	$regvalues = "";
	while(list($field,$show,$required) = $dbh->fetch_array($sth)) {
		if (!$show && !$required) {
			continue;
		}

		${$field} = get_input($field,"post");

		// Make sure we have a 1 or 0 for this field
		if ($field == "USER_SHOW_AVATARS") {
			if (!$USER_SHOW_AVATARS) $USER_SHOW_AVATARS = "0";
		} // end if

		// Censor the Fake Email?
		if ($field == "USER_DISPLAY_EMAIL") {
			if ($config['DO_CENSOR']) {
				$USER_DISPLAY_EMAIL = $html->do_censor($USER_DISPLAY_EMAIL);
			}
			$USER_DISPLAY_EMAIL = str_replace("<","&lt;",$USER_DISPLAY_EMAIL);
		}

		// Birthday?
		elseif ($field == "USER_BIRTHDAY") {
			if (isset(${$config['COOKIE_PREFIX']."ubbt_dob"})) {
				$USER_BIRTHDAY = ${$config['COOKIE_PREFIX']."ubbt_dob"};
			}
			else {
				$bmonth = get_input("bmonth","post");
				$bday = get_input("bday","post");
				$byear = get_input("byear","post");
				if ($bmonth) {
					$USER_BIRTHDAY = "$bmonth/$bday/$byear";
				}
			}
		}

		// Picture
		elseif ($field == "USER_AVATAR") {
			$picchange = get_input("picchange","post");

			if ($picchange == "url") {
				if ( ($USER_AVATAR) && ($USER_AVATAR != "http://") && ($USER_AVATAR != "none") ) {
					if (!preg_match("/(png|jpg|gif)$/i",$USER_AVATAR)) {
						$html -> not_right($ubbt_lang['BAD_PIC']);
					}
					$imagehw = getimagesize($USER_AVATAR);
					$imagewidth = $imagehw[0];
					$imageheight = $imagehw[1];
					if ($config['AVATAR_MAX_WIDTH'] && $config['AVATAR_MAX_HEIGHT']) {
						if ($imagewidth > $config['AVATAR_MAX_WIDTH']) {
							$div = $imagewidth / $config['AVATAR_MAX_WIDTH'];
							$imagewidth = ceil($imagewidth / $div);
							$imageheight = ceil($imageheight / $div);
						}
						if ($imageheight > $config['AVATAR_MAX_HEIGHT']) {
							$div = $imageheight / $config['AVATAR_MAX_HEIGHT'];
							$imageheight = ceil($imageheight / $div);
							$imagewidth = ceil($imageheight / $div);
						}
					} // end if

					$picsize = ",USER_AVATAR_WIDTH = '$imagewidth', USER_AVATAR_HEIGHT = '$imageheight'";
				}
			}

			if ($picchange == "avatar") {
				$USER_AVATAR = get_input("avurl","post");
				$avwidth = get_input("avwidth","post");
				$avheight = get_input("avheight","post");
				$picsize = ",USER_AVATAR_WIDTH='$avwidth',USER_AVATAR_HEIGHT='$avheight'";
			}

			// --------------------------------------------------
			// If we have a picture attachment then we handle it here
			if ($picchange == "upload") {
				if (isset($_FILES['userfile'])) {
					if ( (!empty($_FILES['userfile']['name'])) && ($_FILES['userfile']['name'] != "none") ){
						if (!preg_match("/(png|jpg|gif)$/i",$_FILES['userfile']['name'])) {
							$html -> not_right($ubbt_lang['BAD_PIC']);
						}
					}
					if ( ($_FILES['userfile']['size'] > $config['MAX_AVATAR_SIZE']) ) {
						$html -> not_right($html->substitute($ubbt_lang['FILE_TOO_BIG'], array('AVVY_SIZE' => $config['MAX_AVATAR_SIZE'])));
					}
					if ( ($_FILES['userfile']['name'] != "none") && ($_FILES['userfile']['name']) ){

						// -----------------
						// Grab the filetype
						$piece['0'] = "";
						preg_match("/(\.gif|\.png|\.jpg)$/i",$_FILES['userfile']['name'],$piece);
						$type = $piece['1'];
						$pictime = time();
						$Picturefile = "$pictime$type";
						$Picturefile = strtolower($Picturefile);
						if ( ($_FILES['userfile']['tmp_name'] != "none") && ($_FILES['userfile']['tmp_name']) ){
							copy($_FILES['userfile']['tmp_name'], "{$config['UPLOADED_AVATAR_PATH']}/$Picturefile");
						}
						$imagehw = getimagesize("{$config['UPLOADED_AVATAR_URL']}/$Picturefile");
						$imagewidth = $imagehw[0];
						$imageheight = $imagehw[1];
						if ($config['AVATAR_MAX_WIDTH'] && $config['AVATAR_MAX_HEIGHT']) {
							if ($imagewidth > $config['AVATAR_MAX_WIDTH']) {
								$div = $imagewidth / $config['AVATAR_MAX_WIDTH'];
								$imagewidth = ceil($imagewidth / $div);
								$imageheight = ceil($imageheight / $div);
							}
							if ($imageheight > $config['AVATAR_MAX_HEIGHT']) {
								$div = $imageheight / $config['AVATAR_MAX_HEIGHT'];
								$imageheight = ceil($imageheight / $div);
								$imagewidth = ceil($imageheight / $div);
							}
						} // end if
						$USER_AVATAR = "{$config['UPLOADED_AVATAR_URL']}/$Picturefile";
						$pictype = $type;
						$uploaded = 1;
					}

					// Make sure we have a width/height
					if (!isset($imagewidth)) { $imagewidth = $config['AVATAR_MAX_WIDTH']; }
					if (!isset($imageheight)) { $imageheight = $config['AVATAR_MAX_HEIGHT']; }

					$picsize = ",USER_AVATAR_WIDTH = '$imagewidth', USER_AVATAR_HEIGHT = '$imageheight'";
				}
			}
		}

		// Signature field
		elseif ($field == "USER_SIGNATURE") {
			if ( strlen($USER_SIGNATURE) > 255 ) {
				$html -> not_right($ubbt_lang['SIG_TOO_LONG']);
			}
			if ($config['DO_CENSOR']) {
				$USER_SIGNATURE = $html->do_censor($USER_SIGNATURE);
			}
			$USER_SIGNATURE = $html -> do_markup($USER_SIGNATURE,"signature","markup");
		}

		// Homepage field
		elseif ($field == "USER_HOMEPAGE") {
			if ( strlen($USER_HOMEPAGE) > 150 ) {
				$html -> not_right($ubbt_lang['HOME_TOO_LONG']);
			}
			if ($config['DO_CENSOR']) {
				$USER_HOMEPAGE = $html->do_censor($USER_HOMEPAGE);
			}
			$USER_HOMEPAGE = str_replace("<","&lt;",$USER_HOMEPAGE);
		}

		// Occupation field
		elseif ($field == "USER_OCCUPATION") {
			if ( strlen($USER_OCCUPATION) > 150 ) {
				$html -> not_right($ubbt_lang['OCC_TOO_LONG']);
			}
			if ($config['DO_CENSOR']) {
				$USER_OCCUPATION = $html->do_censor($USER_OCCUPATION);
			}
			$USER_OCCUPATION = str_replace("<","&lt;",$USER_OCCUPATION);
		}

		// Hobbies field
		elseif ($field == "USER_HOBBIES") {
			if ( strlen($USER_HOBBIES) > 200 ) {
				$html -> not_right($ubbt_lang['HOBB_TOO_LONG']);
			}
			if ($config['DO_CENSOR']) {
				$USER_HOBBIES = $html->do_censor($USER_HOBBIES);
			}
			$USER_HOBBIES = str_replace("<","&lt;",$USER_HOBBIES);
		}

		// Location field
		elseif ($field == "USER_LOCATION") {
			if ( strlen($USER_LOCATION) > 200 ) {
				$html -> not_right($ubbt_lang['LOC_TOO_LONG']);
			}
			if ($config['DO_CENSOR']) {
				$USER_LOCATION = $html->do_censor($USER_LOCATION);
			}
			$USER_LOCATION = str_replace("<","&lt;",$USER_LOCATION);
		}

		//  ICQ
		elseif ($field == "USER_ICQ") {
			if ($config['DO_CENSOR']) {
				$USER_ICQ = $html->do_censor($USER_ICQ);
			}
			$USER_ICQ = str_replace("<","&lt;",$USER_ICQ);
		}

		// YAHOO
		elseif ($field == "USER_YAHOO") {
			if ($config['DO_CENSOR']) {
				$USER_YAHOO = $html->do_censor($USER_YAHOO);
			}
			$USER_YAHOO = str_replace("<","&lt;",$USER_YAHOO);
		}

		// MSN
		elseif ($field == "USER_MSN") {
			if ($config['DO_CENSOR']) {
				$USER_MSN = $html->do_censor($USER_MSN);
			}
			$USER_MSN = str_replace("<","&lt;",$USER_MSN);
		}

		// AIM
		elseif ($field == "USER_AIM") {
			if ($config['DO_CENSOR']) {
				$USER_AIM = $html->do_censor($USER_AIM);
			}
			$USER_AIM = str_replace("<","&lt;",$USER_AIM);
		}

		// Extra1 field
		elseif ($field == "USER_EXTRA_FIELD_1") {
			if ($config['DO_CENSOR']) {
				$USER_EXTRA_FIELD_1 = $html->do_censor($USER_EXTRA_FIELD_1);
			}
			$USER_EXTRA_FIELD_1 = str_replace("<","&lt;",$USER_EXTRA_FIELD_1);
		}

		// Extra2 field
		elseif ($field == "USER_EXTRA_FIELD_2") {
			if ($config['DO_CENSOR']) {
				$USER_EXTRA_FIELD_2 = $html->do_censor($USER_EXTRA_FIELD_2);
			}
			$USER_EXTRA_FIELD_2 = str_replace("<","&lt;",$USER_EXTRA_FIELD_2);
		}

		// Extra3 field
		elseif ($field == "USER_EXTRA_FIELD_3") {
			if ($config['DO_CENSOR']) {
				$USER_EXTRA_FIELD_3 = $html->do_censor($USER_EXTRA_FIELD_3);
			}
			$USER_EXTRA_FIELD_3 = str_replace("<","&lt;",$USER_EXTRA_FIELD_3);
		}

		// Extra4 field
		elseif ($field == "USER_EXTRA_FIELD_4") {
			if ($config['DO_CENSOR']) {
				$USER_EXTRA_FIELD_4 = $html->do_censor($USER_EXTRA_FIELD_4);
			}
			$USER_EXTRA_FIELD_4 = str_replace("<","&lt;",$USER_EXTRA_FIELD_4);
		}

		// Extra5 field
		elseif ($field == "USER_EXTRA_FIELD_5") {
			if ($config['DO_CENSOR']) {
				$USER_EXTRA_FIELD_5 = $html->do_censor($USER_EXTRA_FIELD_5);
			}
			$USER_EXTRA_FIELD_5 = str_replace("<","&lt;",$USER_EXTRA_FIELD_5);
		}

		// TimeOffset field
		elseif ($field == "USER_TIME_OFFSET") {
			if (!is_numeric($USER_TIME_OFFSET)) {
				$USER_TIME_OFFSET = "0";
			}
		}
		elseif ($field == "USER_TIME_FORMAT") {
			$USER_TIME_FORMAT = $config['TIME_FORMATS'][$USER_TIME_FORMAT];
		}

		// Topics per page
		elseif ($field == "USER_TOPICS_PER_PAGE") {
			if( ($USER_TOPICS_PER_PAGE < 1) || ($USER_TOPICS_PER_PAGE > 99) ) {
				$html -> not_right($ubbt_lang['POSTS_PER']);
			}
		}

		// Replies per page
		elseif ($field == "USER_POSTS_PER_TOPIC") {
			if ( ($USER_POSTS_PER_TOPIC < 1) || ($USER_POSTS_PER_TOPIC > 99) ) {
				$html -> not_right($ubbt_lang['FLAT_BAD']);
			}
		}

		if ((isset(${$field})) && ($field != "USER_PASSWORD")) {
			$regfields .= ",$field";
			$regvalues .= ",'" .addslashes(${$field}) ."'";
		}

		if ($required) {
			if (!${$field} && $field != "USER_AVATAR" && ${$field} != '0') {
				if ($field == "USER_BIRTHDAY" && $config['DO_AGE_CHECK']) {
					continue;
				}

				$html -> not_right($ubbt_lang['ALL_FIELDS']);
			}
		}

	}

	// Sanity check on our login info
	list($ok,$err) = is_valid_name($Loginname,"login");
	if ($ok ===false) { $html->not_right($ubbt_lang[$err]); }
	$Loginname_q = addslashes($Loginname);

	// Validate the PDN
	list($ok, $err) = is_valid_name($Displayname,"display");
	if($ok === false) { $html->not_right($ubbt_lang[$err]); }
	$Displayname_q = addslashes($Displayname);


	// ----------------------
	// Check the email format
	list($ok, $err) = reg_validate_email($Email);
	if($ok === false) { $html->not_right($ubbt_lang[$err]); }
	$Email_q = addslashes($Email);


	// ---------------------------------------------------------------
	// If we are allowing registration with parental consent form then
	// we need to check the age and populate a couple of fields
	$coppauser = 0;
	if (isset(${$config['COOKIE_PREFIX']."ubbt_dob"})) {
		list ($month,$day,$year) = preg_split("#/#",${$config['COOKIE_PREFIX']."ubbt_dob"});
	}
	$currday = date("d");
	$currmon = date("m");
	$curryea = date("Y");
	$years = $curryea - $year;
	if ($years < $config['MINIMUM_AGE'] && !$config['ALLOW_UNDER_13']) {
		$html -> not_right($ubbt_lang['UNDERAGE']);
	}
	elseif ($years < $config['MINIMUM_AGE'] && $config['ALLOW_UNDER_13']) {
		$coppauser = 1;
	}


	// ---------------------------------------
	// Are we requiring registration approval?
	$approved = "";
	if ($config['EMAIL_VERIFICATION']) {

		// ------------------------------------------------
		// Now we need to generate a random verification key
		$keyset = array('a','b','c','d','e','f','g','h','i','j','k','m','n','o','p','q','r','s','t','u','v','x','y','z','A','B','C','D','E','F','G','H','I','J','K','M','N','P','Q','R','S','T','U','V','W','X','Y','Z','2','3','4','5','6','7','8','9');
		$chars = sizeof($keyset) - 1;

		$key = "";
		$a = time();
		mt_srand($a);
		for ($i=0; $i < 8; $i++) {
			$randnum = intval(mt_rand(0,$chars))    ;
			$key .= $keyset[$randnum];
		}
		$approved = $key;
	}
	elseif ( ($config['NEW_USER_MODERATION']) || ($coppauser == 1) ){
		if (!$approved) {
			$approved = 'no';
		}
	}
	else {
		$approved = 'yes';
	}

	// -------------------------------------------------------
	// If this is the first user, then status is Administrator
	// otherwise they are just get normal user status.
	if ($firstuser < 2){
		$Status = "Administrator";
		$config['DEFAULT_USER_GROUPS'][] = "1";
		$approved = "yes";
		if (!$config['SITE_EMAIL']) {
			$config['SITE_EMAIL'] = $Email;
		}
	} else {
		$Status = "User";
	}

	// ---------------------
	// Set the default title
	$query = "
		SELECT USER_TITLE_NAME
		FROM {$config['TABLE_PREFIX']}USER_TITLES
		WHERE USER_TITLE_POST_COUNT = '0'
	";
	$sth = $dbh->do_query($query);
	list($utitle) = $dbh->fetch_array($sth);
	$Title_q = addslashes($utitle);

	// ------------
	// Get the date
	$date = $html -> get_date();

	// ------------------------------
	// Put the user into the database
	$Status_q   = addslashes($Status);
	$Login_q    = addslashes($Loginname);
	$Displayn_q    = addslashes($Displayname);
	$Email_q    = addslashes($Email);
	$Display_q  = addslashes($config['TOPIC_DISPLAY_STYLE']);

	if (!isset($USER_TOPIC_VIEW_TYPE)) {
		$regfields .= ",USER_TOPIC_VIEW_TYPE";
		$regvalues .= ",'$Display_q'";
	}
	if (!isset($USER_TOPICS_PER_PAGE)) {
		$regfields .= ",USER_TOPICS_PER_PAGE";
		$regvalues .= ",'{$config['TOPICS_PER_PAGE']}'";
	}
	if (!isset($USER_ACCEPT_ADMIN_EMAILS)) {
		$regfields .= ",USER_ACCEPT_ADMIN_EMAILS";
		$regvalues .= ",''";
	}


	// -------------------------------
	// Grab the registering IP address
	$ip = find_environmental('REMOTE_ADDR');
	$ip_q = addslashes($ip);


	// --------------------------------------------------------------------
	// Now we need to generate a random password if they didn't specify one
	$random_pass = 0;
	if (!$pass) {
		$random_pass = 1;
		$passset = array('a','b','c','d','e','f','g','h','i','j','k','m','n','o','p','q','r','s','t','u','v','x','y','z','A','B','C','D','E','F','G','H','I','J','K','M','N','P','Q','R','S','T','U','V','W','X','Y','Z','2','3','4','5','6','7','8','9');
		$chars = sizeof($passset) - 1;

		$pass = "";
		$a = time() + 2;
		mt_srand($a);
		for ($i=0; $i < 6; $i++) {
			$randnum = intval(mt_rand(0,$chars));
			$pass .= $passset[$randnum];
		}
	}

	// ----------------------------
	// Now let's crypt the password
	$crypt = md5($pass);


	// ----------------------------------
	// Insert this user into the database
	$query = "
		INSERT INTO {$config['TABLE_PREFIX']}USERS (USER_LOGIN_NAME,USER_DISPLAY_NAME,USER_PASSWORD,USER_MEMBERSHIP_LEVEL,USER_REGISTERED_ON,USER_REGISTRATION_EMAIL,USER_REGISTRATION_IP,USER_IS_APPROVED,USER_IS_UNDERAGE)
		VALUES ('$Login_q','$Displayn_q','$crypt','$Status_q','$date','$Email_q','$ip_q','$approved','$coppauser')
	";
	$dbh -> do_query($query,__LINE__,__FILE__);

	$query = "
		select last_insert_id()
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	list ($Uid) = $dbh->fetch_array($sth);

	$query = "
		insert into {$config['TABLE_PREFIX']}USER_PROFILE
		(USER_ID,USER_FLOOD_CONTROL_OVERRIDE,USER_REAL_EMAIL,USER_TOTAL_POSTS,USER_TITLE,USER_TOTAL_PM{$regfields})
		values
		('$Uid','-1','$Email_q',0,'$Title_q',1{$regvalues})
	";
	$dbh -> do_query($query,__LINE__,__FILE__);

	$query = "
		insert into {$config['TABLE_PREFIX']}USER_DATA
		(USER_ID,USER_LAST_VISIT_TIME)
		values
		('$Uid','$date')
	";
	$dbh -> do_query($query,__LINE__,__FILE__);


	foreach($config['DEFAULT_USER_GROUPS'] as $key => $group) {
		$query = "
		insert into {$config['TABLE_PREFIX']}USER_GROUPS
		values
		('$Uid','$group')
		";
		$dbh->do_query($query);
	}

	// If uploaded has been set to 1, we need to change the uploaded picture file
	// and the picture field in the database with the user's number
	if ($uploaded) {
		$newpicname = "{$config['UPLOADED_AVATAR_URL']}/$Uid$pictype";
		copy($Picturefile, "$newpicname");
		@unlink($Picturefile);
		$query = "
			UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
			SET USER_AVATAR='" .addslashes($newpicname)."'
			WHERE USER_ID='$Uid'
		";
		$dbh->do_query($query,__LINE__,__FILE__);
	}

	// ---------------------------------
	// Set up some stuff for the message
	$dbh -> finish_sth($sth);
	$Subject    = $ubbt_lang['INTRO_SUB2'];
	$Subject_q  = addslashes($Subject);
	$Message_q  = addslashes($ubbt_lang['WEL_MSG']);

	// --------------------------------------
	// Put the message into the Messages table
	$query = "
		INSERT INTO {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS
		(TOPIC_TIME,TOPIC_REPLIES,TOPIC_SUBJECT,USER_ID,TOPIC_LAST_REPLY_TIME)
		values
		('$date','0','$Subject_q','{$config['MAIN_ADMIN_ID']}','$date')
	";
	$dbh->do_query($query,__LINE__,__FILE__);

	$query = "
		select last_insert_id()
	";
	$sth=$dbh->do_query($query,__LINE__,__FILE__);
	list($message_id) = $dbh->fetch_array($sth);

	$query = "
		insert into {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
		(TOPIC_ID,USER_ID,POST_BODY,POST_DEFAULT_BODY,POST_TIME)
		values
		('$message_id','{$config['MAIN_ADMIN_ID']}','$Message_q','$Message_q','$date')
	";
	$dbh -> do_query($query,__LINE__,__FILE__);

	$query = "
		insert into {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
		(TOPIC_ID,USER_ID,MESSAGE_LAST_READ)
		values
		('$message_id','$Uid',1)
	";
	$dbh->do_query($query,__LINE__,__FILE__);


	// -------------------------------------
	// Now we need to mail them the password
	if ($Loginname && $Email) {
		$mailer = new mailer();
		$mailer->set_subject('REG_SUBJECT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
		$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $Displayname));
		$mailer->add_content('REG_CONTENT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
		$mailer->add_content('REG_CONTENT1', array('USERNAME' => $Loginname, 'PASSWORD' => $pass));
		$mailer->add_content('REG_CONTENT2', array('BOARD_URL' => make_ubb_url("","",true)),true);

		// Append the fact that they need to verify their email
		if ($config['EMAIL_VERIFICATION']) {
			$mailer->add_content('REG_CONTENT3');
			$mailer->add_content('REG_CONTENT4', array('VERIFY_URL' => make_ubb_url("ubb=verifyemail&verify=$Uid-$approved", "", true, true)),true);
		}
		// Also indicate that they are queued, if the board requires approval
		if ($config['NEW_USER_MODERATION']) {
			$mailer->add_content('REG_CONTENT5');
		}
		$mailer->ubbt_mail($Email);
	}

	// -------------------------------------------------------------------------
	// Send out an email only to admins who want to receive them for new signups
	//
	// Note: If there is no email verify, they are at the final frontier, so we
	// can tell any admins who want to know as just an inform or a prod to
	// moderate the new sign-up
	if (!$config['EMAIL_VERIFICATION']) {
		$query = "
			SELECT up.USER_REAL_EMAIL, up.USER_NOTIFY_NEW_USER, up.USER_LANGUAGE, u.USER_DISPLAY_NAME
			FROM  {$config['TABLE_PREFIX']}USER_PROFILE up,
						{$config['TABLE_PREFIX']}USERS u
			WHERE	u.USER_MEMBERSHIP_LEVEL = 'Administrator'
				AND	up.USER_ID = u.USER_ID
				AND up.USER_NOTIFY_NEW_USER = '1'
		";
		$sth = $dbh -> do_query($query,__LINE__,__FILE__);

		$mailer = new mailer();
		while(list($adminemail,$notify_newuser,$lang,$username) = $dbh -> fetch_array($sth)) {
			if (!$adminemail) continue;

			$mailer->set_language($lang);
			$mailer->set_subject('REGN_SUBJECT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
			$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $username));
			$subs = array(
				'EMAIL_ADDY' => $Email,
				'DISPLAY_NAME' => $Displayname,
				'IP_ADDY' => $ip);
			$mailer->add_content('REGN_CONTENT', $subs);
			// Tell them they need to moderate or just be informative
			if ($config['NEW_USER_MODERATION']) {
				$mailer->add_content('REGN_CONTENT1');
				$mailer->add_content('REGN_CONTENT2',array('MANAGE_URL' => "{$config['FULL_URL']}/admin/membermanage.php?returntab=1"),true);
			}
			else {
				$mailer->add_content('REGN_CONTENT3');
			}
			$mailer -> ubbt_mail($adminemail);
		}
	}

	rebuild_islands(0,array("new_users","birthdays"));

	// ------------------------
	// Send them a confirmation
	$delay = 2;
	if ($config['EMAIL_VERIFICATION']) {
		$delay = 10;
		$extrahtml = $ubbt_lang['VERIFY'];
	} elseif ($config['NEW_USER_MODERATION']) {
		$delay = 10;
		$extrahtml = $ubbt_lang['NEEDAPPROVAL'];
	}

	if ($coppauser) {
		$extrahtml .= "<br /><br />" . $html->substitute($ubbt_lang['PARENT_FORM'], array('COPPA_URL' => make_ubb_url("ubb=coppaform", "", true)));
	}

	if (!$extrahtml) {
		$extrahtml = $ubbt_lang['NOW_LOGIN'];
	}


	// -----------------------------------------------------
	// If this is a coppauser we need to set one more cookie
	if ($coppauser) {
		$html -> ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_coppaid","$Uid",time()+30758400);
	}

	if ($random_pass) {
		$text = $ubbt_lang['NEW_BODY_WITH_PASS'];
	} else {
		$text = $ubbt_lang['NEW_BODY'];
	} // end if

	$html->send_redirect(
		array(
			"redirect" => "login",
			"heading" => $ubbt_lang['NEW_CONFIRM'],
			"body" => "$text $extrahtml",
			"returnlink" => "",
			"delay" => $delay
		)
	);

}


// Validate an email address
function reg_validate_email ($email) {

	// FIXME: Needs Classic copy pasta (spaghetti?) from email_test in ubb_lib
	global $dbh, $config;

	if (!preg_match("#^[+_a-z0-9-]+(\.[+_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$#i", $email)) {
		return array(false, 'BAD_FORMAT');
	} // end if

	// --------------------------------------
	// Let's see if the email domain is valid
	$Email_q = addslashes($email);
	$query = "
	SELECT COUNT(*)
	FROM {$config['TABLE_PREFIX']}BANNED_EMAILS
	WHERE '$Email_q' LIKE BANNED_EMAIL
	";
	$sth = $dbh->do_query($query);
	list($etest) = $dbh->fetch_array($sth);
	if ($etest) {
		return array(false, 'BAD_EMAIL');
	} // end if

	$query = "
		SELECT USER_REAL_EMAIL
		FROM   {$config['TABLE_PREFIX']}USER_PROFILE
		WHERE USER_REAL_EMAIL = '$Email_q'
	";
	$sth = $dbh -> do_query($query,__LINE__,__FILE__);
	list($emailcheck) = $dbh -> fetch_array($sth);
	$dbh -> finish_sth($sth);
	if($emailcheck && $config['REQUIRE_UNIQUE_EMAIL']){
		return array(false, 'NO_MULTI');
	}

	$query = "
	SELECT USER_REGISTRATION_EMAIL
	FROM   {$config['TABLE_PREFIX']}USERS
	WHERE USER_REGISTRATION_EMAIL = '$Email_q'
	";
	$sth = $dbh -> do_query($query,__LINE__,__FILE__);
	list($emailcheck) = $dbh -> fetch_array($sth);
	$dbh -> finish_sth($sth);
	if($emailcheck && $config['REQUIRE_UNIQUE_EMAIL']){
		return array(false, 'NO_MULTI');
	}

	return array(true, null);

} // end reg_validate_email

// Validate a password
function reg_validate_passwd ($passwd, $verify, $Displayname) {
	if ($passwd != $verify) {
		return array(false, 'PASS_MATCH');
	}
	if((strlen($passwd) > 21) || (strlen($passwd) < 4)) {
		return array(false, 'PASS_TOO_LONG');
	}
	if (preg_match("/^\W+$/",$passwd)) {
		return array(false, 'ILL_PASS');
	}
	if ($passwd == $Displayname) {
		return array(false, 'PASS_USER_MATCH');
	}

	return array(true, false);
} // end reg_validate_passwd

?>
