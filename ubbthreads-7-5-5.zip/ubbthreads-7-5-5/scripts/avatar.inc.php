<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;
define('NO_WRAPPER',1);
function page_avatar_gpc () {
	return array(
		"input" => array(
			"startat" => array("startat","get","int"),
			"form" => array("form","get","alphanum"),
		),
		"wordlets" => array("avatar"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_avatar_gpc

function page_avatar_run () {

	global $style_array,$smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$var_start,$var_eq,$var_sep,$var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$smarty_data = array();

	if (!$startat) { $startat = "0"; }

	$html = new html;

	// --------------------------------
	// Let's grab all the avatar images
	$avatarlist = "";
	$dir = opendir("{$config['FULL_PATH']}/images/{$style_array['avatars']}");
	$i=0;
	$currentwidth = 0;
	$prevpage = "";
	$nextpage = "";
	if ($startat > 0) {
		$start = $startat - 10;
		$prevpage = "<a href=\"" . make_ubb_url("ubb=avatar&startat=$start&form=$form", "", false) . "\">&laquo;</a>";
	}

	while( ($file = readdir($dir)) != false) {
		if ( ($file == ".") || ($file == "..") || ($file == "index.html") ) {
			continue;
		}
		if ($i < $startat) {
			$i++;
			continue;
		}
		$imagehw = @GetImageSize("{$config['FULL_PATH']}/images/{$style_array['avatars']}/$file");
		$iw = $imagehw[0];
		$ih = $imagehw[1];
		if (!$iw) { $iw = "48"; }
		if (!$ih) { $ih = "48"; }

		$currentwidth = $currentwidth + $iw;
		if ($currentwidth > 250) {
			$currentwidth = $iw;
			$avatarlist .= "<br />";
		}
		if ($i == $startat + 10) {
			$start = $startat + 10;
			$nextpage = "<a href=\"" . make_ubb_url("ubb=avatar&startat=$start&form=$form", "", false) . "\">&raquo;</a>";
			$prevpage = "&nbsp; &nbsp; &nbsp; $prevpage";
			break;
		}

		$avatarlist .= "<a href=\"javascript:void(0);\" onclick=\"javascript:preview('$file','$iw','$ih');\"><img border=\"1\" src=\"{$config['BASE_URL']}/images/{$style_array['avatars']}/$file\" alt=\"\"/></a> ";
		$i++;
	}
		
	$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";
	
	$smarty_data = array(
		"stylesheet" => $stylesheet,
		"avatarlist" => & $avatarlist,
		"prevpage" => $prevpage,
		"nextpage" => $nextpage,
		"form" => $form,
	);

	return array(
		"header" => array (
			"title" => $ubbt_lang['AVATAR'],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => "",
		),
		"template" => "avatar",
		"data" => & $smarty_data,
		"footer" => false,
		"location" => "",
	);

}

?>
