<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_boardrules_gpc () {
	return array(
		"input" => array(
			"ocurl" => array("ocurl","post",""),
			"agree" => array("agree","post","int"),
			"v" => array("v","get","int"),
		),
		"wordlets" => array(""),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_boardrules_gpc

function page_boardrules_run () {

	global $user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$html = new html;

	// Just viewing?
	if ($v == 1) {
		$html->give_rules(1);
		exit;
	}

	// Make sure this is a legit submission
	if (!$agree) {
		$html->not_right($ubbt_lang['RULE_ACCEPT_BODY']);
	}

	if (!$user['USER_ID']) {
		$_SESSION['rules_accept'] = 1;
	} else { 
		$query = "
			update {$config['TABLE_PREFIX']}USERS
			set USER_RULES_ACCEPTED = ?
			where USER_ID = ?
		";
		$dbh->do_placeholder_query($query,array($html->get_date(),$user['USER_ID']),__LINE__,__FILE__);
	} // end if 
	
	header("Location: $ocurl");
	exit;
}

?>
