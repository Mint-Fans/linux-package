<?php

//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_calendar_gpc () {
	return array(
		"input" => array(
			"month" => array("month","both","int"),
			"year" => array("year","both","int"),
		),
		"wordlets" => array("calendar"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_calendar_gpc

function page_calendar_run () {

	global $userob,$smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$smarty_data = array();

	if (!$config['CALENDAR']) {
		$html->not_right($ubbt_lang['DISABLED']);
	} // end if

	// -------------------------------------------------------------------------
	// Need to see what forums they have access to, so we don't show events with
	// topics in private forums

	$canview = array();
	$query = "
	SELECT FORUM_ID
	FROM   {$config['TABLE_PREFIX']}FORUMS
	WHERE FORUM_IS_ACTIVE = '1'
	";
	$sth = $dbh -> do_query($query,__LINE__,__FILE__);
	$i = 0;
	while (list($thisboard) = $dbh -> fetch_array($sth)) {
		if ($userob->check_access("forum","SEE_FORUM",$thisboard)) {
			$canview[$i] = $thisboard;
			$i++;
		}
	}
	
	$now = $html -> get_date();
	// Show 2 months
	if (!$month) {
		$temp = getdate($now);
		$thismonth = $temp["mon"];
		$thisyear  = $temp["year"];
	}
	else {
		$thismonth = $month;
		$thisyear  = $year;
	}
	
	$last_month = $thismonth - 1;
	$last_year  = $thisyear;
	if( $last_month == 0 ) {
		$last_year--;
		$last_month = 12;
	}

	$month0 = make_month($last_month, $last_year );
	
	$month1 = make_month($thismonth,$thisyear,false);

	$nextmonth = $thismonth + 1;
	$year = $thisyear;
	if ($nextmonth == 13) {
		$nextmonth = 1;
		$year = $year + 1;
	}
	$month2 = make_month($nextmonth,$year);

	$monthselect = "<select name=\"month\" class=\"form-select\">";
	for ($i=1;$i<=12;$i++) {
		$mname = "MONTH$i";
		$selected = "";
		if ($thismonth == $i) {
			$selected = "selected=\"selected\"";
		}
		$monthselect .= "<option value=\"$i\" $selected>$ubbt_lang[$mname]</option>";
	}
	$monthselect .= "</select>";

	$temp = getdate($now);
	$tyear  = $temp["year"];

	$yearselect = "<select name=\"year\" class=\"form-select\">";
	for ($i=$tyear;$i<=($tyear+10);$i++) {
		$selected = "";
		if ($thisyear == $i) {
			$selected = "selected=\"selected\"";
		}
		$yearselect .= "<option $selected>$i</option>";
	}
	$yearselect .= "</select>";

	$addevent = "";
	if ($user['USER_DISPLAY_NAME']) {
		$addevent = "<br /><a href=\"" . make_ubb_url("ubb=addevent", "", false) . "\">{$ubbt_lang['ADDEVENT']}</a>";
	}

	// ----------------------------------------
	// Setup the links for prev and next months
	$prevmonth = $thismonth - 1;
	$prevyear  = $thisyear;
	if ($prevmonth < 1) {
		$prevmonth = 12;
		$prevyear = $prevyear - 1;
	}
	$nextmonth = $thismonth + 1;
	$nextyear  = $thisyear;
	if ($nextmonth > 12) {
		$nextmonth = 1;
		$nextyear= $nextyear + 1;
	}
	
	$smarty_data['month0'] = $month0;
	$smarty_data['month1'] = $month1;
	$smarty_data['month2'] = $month2;
	$smarty_data['prevmonth'] = $prevmonth;
	$smarty_data['prevyear'] = $prevyear;
	$smarty_data['monthselect'] = $monthselect;
	$smarty_data['yearselect'] = $yearselect;
	$smarty_data['addevent'] = $addevent;
	$smarty_data['nextmonth'] = $nextmonth;
	$smarty_data['nextyear'] = $nextyear;
	
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array (
			"title" => $ubbt_lang['CAL_HEAD'],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 {$ubbt_lang['CAL_HEAD']}
BREADCRUMB
			,
		),
		"template" => "calendar",
		"data" => $smarty_data,
		"footer" => true,
		"location" => "",
	);
	
}


// ------------------------------------------------------------
// THIS FUNCTION ACTUALLY CREATES THE CALENDAR AND GRABS EVENTS
function make_month($month="",$year="",$tiny = true) {

	global $userob,$smarty,$ubbt_lang,$config,$dbh,$user, $debug, $tempstyle, $html;

	$events = array_fill(0, 31, '');
	
	
	$now = $html -> get_date();
	// ---------------------------------
	// Get some info on the current date
	$temp = getdate($now);
	$thismonth = $temp["mon"];
	$thisyear  = $temp["year"];
	$thisday   = $temp["mday"];
	
	// Real date
	$real = getdate();
	$realmonth = $temp["mon"];
	$realyear = $temp["year"];
	$realday = $temp["mday"];

	// ----------------------------------------------------------------
	// If we didn't pass month/year then we grab the current month/year
	if (!$month) {
		$month = $thismonth;
	}
	if (!$year) {
		$year = $thisyear;
	}

	$weekday_array = array(
		$ubbt_lang["SUNDAY"],
		$ubbt_lang["MONDAY"],
		$ubbt_lang["TUESDAY"],
		$ubbt_lang["WEDNESDAY"],
		$ubbt_lang["THURSDAY"],
		$ubbt_lang["FRIDAY"],
		$ubbt_lang["SATURDAY"],
	);
	
	for ($j = 0; $j < $config['CALENDAR_START_DAY']; $j++) {
		$weekday_array[] = array_shift($weekday_array);
	}

	// -----------------------------------------------------------
	// Grab all the birthday's for this month if showing birthdays
	$bdays = array();
	$marray = array();
	if (isset($config['BIRTHDAYS_IN_CALENDAR']) && $config['BIRTHDAYS_IN_CALENDAR']) {
		$query = "
		SELECT t1.USER_DISPLAY_NAME,t2.USER_BIRTHDAY,t1.USER_IS_UNDERAGE
		FROM   {$config['TABLE_PREFIX']}USERS as t1,
			{$config['TABLE_PREFIX']}USER_PROFILE as t2
		WHERE  t2.USER_BIRTHDAY LIKE ?
		AND    t2.USER_PUBLIC_BIRTHDAY = '1'
		AND t1.USER_ID = t2.USER_ID
		";
		$sth = $dbh -> do_placeholder_query($query,array("$month/%"),__LINE__,__FILE__);
		$marray[0] = "";
		
		while(list($uname,$birthday,$coppauser) = $dbh -> fetch_array($sth)) {
			@list($bmonth,$bday,$byear) = @preg_split("#/#",$birthday);
			$age = "";
			if ($config['AGE_WITH_BIRTHDAYS'] && !$coppauser && $byear) {
				$age = $year - $byear;
				$age = " ($age)";
			}
			if (!isset($marray[$bday])) {
				$marray[$bday] = "{$ubbt_lang['BDAY']}: $uname $age<br />";
				$bdays[$bday] = 1;
			} else {
				$marray[$bday] .= "{$ubbt_lang['BDAY']}: $uname $age<br />";
				$bdays[$bday]++;
			}
		}
	}

	// ----------------------------------
	// Now grab all events for this month
	$query_vars = array($month,$year,$month,$user['USER_ID']);
	$query = "
	SELECT CALENDAR_EVENT_SUBJECT,CALENDAR_EVENT_DAY,CALENDAR_EVENT_MONTH,CALENDAR_EVENT_YEAR,CALENDAR_EVENT_RECURRING,TOPIC_ID
	FROM {$config['TABLE_PREFIX']}CALENDAR_EVENTS
	WHERE ( (CALENDAR_EVENT_MONTH = ? AND CALENDAR_EVENT_YEAR = ? AND CALENDAR_EVENT_RECURRING='never')
	OR   (CALENDAR_EVENT_MONTH = ? AND CALENDAR_EVENT_RECURRING='yearly')
	OR   (CALENDAR_EVENT_RECURRING='monthly') )
	AND ( (CALENDAR_EVENT_TYPE='public')
	OR   (CALENDAR_EVENT_TYPE='private' AND USER_ID = ? ) )
	";
	$sth = $dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	while(list($brief,$eday,$emonth,$eyear,$recurring,$topic) = $dbh -> fetch_array($sth)) {
		if ($topic) {
			$query = "
				select FORUM_ID
				from {$config['TABLE_PREFIX']}TOPICS
				where TOPIC_ID = ?
			";
			$stx = $dbh->do_placeholder_query($query,array($topic),__LINE__,__FILE__);
			list($forum_id) = $dbh->fetch_array($stx);
			if (!$userob->check_access("forum","SEE_FORUM",$forum_id)) {
				continue;
			} // end if
		}
		
		if (!isset($marray[$eday])) {
			if ($topic) {
				$string = "TOPIC";
			} else {
				$string = "EVENT";
			}
			$marray[$eday] = "{$ubbt_lang[$string]}: $brief<br />";
			$events[$eday] = 1;
		} else {
			if ($topic) {
				$string = "TOPIC";
			} else {
				$string = "EVENT";
			}
			$marray[$eday] .= "{$ubbt_lang[$string]}: $brief<br />";
			$events[$eday]++;
		}
	}
	// --------------------------------
	// get what weekday the first is on
	$temp = getdate(mktime(0,0,0,$month,1,$year));
	$firstweekday = $temp["wday"] - $config['CALENDAR_START_DAY'];
	$monthnum    = $temp["mon"];
	$mname = "MONTH$monthnum";
	$monthname    = $ubbt_lang[$mname];
	
	if ($firstweekday < 0) {
		$firstweekday += 7;
	}

	// -----------------------------
	// get the last day of the month
	$nextmonth = $month + 1;
	$tempyear = $year;
	if ($nextmonth == 13) {
		$nextmonth = 1;
		$tempyear = $tempyear + 1;
	}
	$temp = getdate(mktime(0,0,0,$nextmonth,0,$tempyear));
	$lastday = $temp["mday"];
	$currentdate = 1;
	$firstweek = true;
	$weekday = 1;
	$currentweek = 1;

	// --------------------------------------
	// Loop through all the days of the month
	while ($currentdate <= $lastday) {

		$days[$currentdate] = "";
		$printdate = $currentdate;

		if (($firstweek) && ($firstweekday)) {
			$days[$currentdate] .= "<tr>";
			for ($i=1;$i<=$firstweekday;$i++) {
				$days[$currentdate] .= "<td class=\"alt-1\">&nbsp;</td>";
				$weekday++;
			}
			$firstweek = false;
		}else {
			$firstweek = false;
		}
		if ($weekday == 1) {
			$days[$currentdate] .= "<tr>";
		}
		$class = "alt-1";
		$alt = "";
		if (($currentdate == $thisday) && ($year == $thisyear) && ($month == $thismonth)) {
			$class="alt-2";
			$printdate = "<span class=\"standouttext\">$printdate</span>";
		}

		// --------------------
		// Event for this day?
		$linkstart = "";
		$linkstop = "";
		$title_attr = "";
		if (isset($marray[$currentdate])) {
			$class="alt-2";
			$printdate = "<b>$printdate</b>";
			$alt .= "$marray[$currentdate]";
			
			if (!$tiny) {
				$bdayc = array_get($bdays, $currentdate, 0);
				if ($bdayc > 1) {
					// We have two or more birthdays
					$title_attr = preg_replace("#^.*?(" . preg_quote($ubbt_lang['BDAY'], '-#') . '.+)$#', '\1', $alt);
					
					$title_attr = sprintf(' title="%s" ', preg_replace('#,\s*$#', '', trim(str_replace('<br />', ",\n", $title_attr))));
					
					$alt = preg_replace("#" . preg_quote($ubbt_lang['BDAY'], '-#') . '.+$#', '', $alt);
					$alt .= "$bdayc {$ubbt_lang['BIRTHDAYS']}\n";
				}
			}
			$linkstart = "<a href=\"" . make_ubb_url("ubb=showday&day=$currentdate&month=$month&year=$year", "", false) . "\">";
			$total = $events[$currentdate] + $bdays[$currentdate];
			if( $total > 0 && !$tiny) {
				$linkstart .= "($total {$ubbt_lang['EVENTS']}) ";
			}
			$linkstop = "</a>";
		}

		
		if( $tiny ) {
			$alt = trim(str_replace( "<br />", "\n", $alt ));
			$title_attr = " title=\"$alt\" ";
			$alt = "";
		}
		
		$height = $tiny ? 'height="10"' : 'height="100"';
		
		$days[$currentdate] .= "<td class=\"$class\" width=\"14%\" {$height} valign=\"top\"><div align=\"right\" class=\"small\" $title_attr>$linkstart{$printdate}$linkstop<br />&nbsp;$alt</div></td>\n";
		if ($weekday == 7) {
			$days[$currentdate] .= "</tr>";
			$currentweek++;
			$weekday = 1;
		} else {
			$weekday++;
		}

		$currentdate++;
	}

	// Fill out the rest of the table
	if ($weekday > 1) {
		for ($i = $weekday; $i <= 7; $i++) {
			$days[$currentdate] = "<td class=\"alt-1\">&nbsp;</td>\n";
			$currentdate = $currentdate + 1;
		}
		$currentdate = $currentdate - 1;
		$days[$currentdate] .= "</tr>";
	}

	$smarty->assign("monthname",$monthname);
	$smarty->assign("year",$year);
	$smarty->assign("weekday_array", $weekday_array);

	$smarty->assign("days",$days);

	$template = $smarty->fetch("calendar_makemonth.tpl");
	return $template;

}

?>
