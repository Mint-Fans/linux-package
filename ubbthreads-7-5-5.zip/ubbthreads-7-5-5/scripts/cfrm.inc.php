<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_cfrm_gpc () {
	return array(
		"input" => array(
			"c" => array("c","both","int"),
			"s" => array("s","get","int"),
		),
		"wordlets" => array("cfrm"),
		"user_fields" => "t2.USER_TOPIC_VIEW_TYPE",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_cfrm_gpc


function page_cfrm_run () {
	global $style_array,$tree,$myinfo,$userob,$smarty,$in,$ubbt_lang,$config,$visit,$dbh,$html,$user;

	require_once("{$config['FULL_PATH']}/libs/functions_forums.inc.php");

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// Clear out any favorites data from the session
	// we don't want to get sent back to the favorites
	// screen when navigating from here
	$_SESSION['favorites'] = array();

	// ------------------------------
	// Define any necessary variables
	$catboards = array();
	$spacer      = "";
	$Username    = "";
	$mode   = "";
	$Groups  = "";
	$useroffset  = "";
	$userstatus  = "";
	$birthdays = "";
	$Cat_Title = "";

	// Get this users last visit time
	$user['USER_LAST_VISIT_TIME'] = time();

	if ($userob->is_logged_in == true) {
		$query = "
			select 	USER_LAST_VISIT_TIME
			from	{$config['TABLE_PREFIX']}USER_DATA
			where	USER_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
		$result = $dbh->fetch_array($sth);
		$user['USER_LAST_VISIT_TIME'] = $result['USER_LAST_VISIT_TIME'];
	}

	$Username = $user['USER_DISPLAY_NAME'];
	$mode = $user['USER_TOPIC_VIEW_TYPE'];
	isset($user['USER_TIME_OFFSET']) && $useroffset = $user['USER_TIME_OFFSET'];

	$userstatus = $user['USER_MEMBERSHIP_LEVEL'];

	$laston = $user['USER_LAST_VISIT_TIME'];
	if ($userob->is_logged_in == false) $laston = $html->get_date();

	// Grab max online
	$query = "
		select CACHE_FIELD,CACHE_VALUE
		from {$config['TABLE_PREFIX']}CACHE
		where CACHE_FIELD in ('max_online','birthdays')
	";
	$sth = $dbh -> do_query($query,__LINE__,__FILE__);
	while(list($cfield,$cvalue) = $dbh->fetch_array($sth)) {
		if ($cfield == "max_online") {
			$c_maxonline = $cvalue;
		} elseif ($cfield == "birthdays") {
			$birthdays_sent = $cvalue;
		}
	}

	$cachenow = $html->get_date();

	// Do we need to send out birthday notifications?
	$today = $html->convert_time($cachenow,$config['SERVER_TIME_OFFSET'],"j",1,0);
	if ($today != $birthdays_sent && $config['BIRTHDAY_NOTICE'] && !$config['BOARD_IS_CLOSED']) {
		include("libs/triggers.inc.php");
		trigger_birthday_notifications($birthdays_sent,$cachenow,$today);
	}

	// =====================
	// Where the forum output is produced
	// =====================
	$totalon = 0;
	$forums =& get_forum_display_info("*", "cfrm", $totalon);
	$totalon = $forums['ONLINE'];
	unset($forums['ONLINE']);

	// -------------------------------
	// Do we need to update the cache?
	$update_maxonline = 0;

	if ($totalon > $c_maxonline) {
		$query = "
			update {$config['TABLE_PREFIX']}CACHE
			set CACHE_VALUE = ?
			where CACHE_FIELD = 'max_online'
		";
		$dbh->do_placeholder_query($query,array($totalon),__LINE__,__FILE__);

		$query = "
			update {$config['TABLE_PREFIX']}CACHE
			set CACHE_VALUE = ?
			where CACHE_FIELD = 'max_online_timestamp'
		";
		$dbh->do_placeholder_query($query,array($cachenow),__LINE__,__FILE__);
	} // end if

	$clause = "";
	if (!is_numeric($c)) $c = "";
	if ($c) {
		$clause = "AND c.CATEGORY_ID = " . addslashes($c);
	} // end if

	// -------------------------------------------------------
	// Get the list of categories (filter any that are devoid)
	$query = "
		SELECT c.CATEGORY_TITLE,c.CATEGORY_ID,c.CATEGORY_DESCRIPTION
		FROM	{$config['TABLE_PREFIX']}CATEGORIES as c,
					{$config['TABLE_PREFIX']}FORUMS as f
		WHERE (f.FORUM_IS_ACTIVE = 1)
		AND  	(f.CATEGORY_ID=c.CATEGORY_ID) $clause
		GROUP BY c.CATEGORY_ID
		ORDER BY c.CATEGORY_SORT_ORDER
	";
	$categories = $dbh->do_query($query,__LINE__,__FILE__);
	$j = 0;

	// Get current collapsed categories
	$collapsed = get_input("ubbt_collapsed", "cookie");

	// ----------------------------
	// Cycle through the categories
	$build_catrow  = array();
	$catindex = array();
	$i = 0;

	while ($result = $dbh->fetch_array($categories)) {
		$build_catrow[$i] = $result;

		if ((strpos($collapsed, "|cat{$result['CATEGORY_ID']}|") !== false) && $in['c'] != $result['CATEGORY_ID'] ) {
			$build_catrow[$i]['display'] = "display: none;";
			$build_catrow[$i]['image'] = "toggle_open.gif";
		} else {
			$build_catrow[$i]['display'] = "";
			$build_catrow[$i]['image'] = "toggle_closed.gif";
		} // end if

		$catindex["{$result['CATEGORY_ID']}"] = $i;
		if ($build_catrow[$i]['CATEGORY_ID'] == $in['c'] && $in['c'] > 0) {
			$Cat_Title = $build_catrow[$i]['CATEGORY_TITLE'];
		}
		$i++;
	}

	$are_forums = false;
	$build_forum = array();
	$f_count = count($forums);
	for ($i = 0; $i < $f_count; $i++) {
		$are_forums = true;
		$index = array_get($catindex, "{$forums[$i]['CATEGORY_ID']}", 0);
		$build_forum[$index][] =& $forums[$i];
	}

	$c_count = count($build_catrow);
	$catrow = array();
	$forum = array();
	for ($i = 0; $i < $c_count; $i++) {
		if (isset($build_forum[$catindex["{$build_catrow[$i]['CATEGORY_ID']}"]]) || is_array($build_forum[$catindex["{$build_catrow[$i]['CATEGORY_ID']}"]])) {
			$catrow[] = $build_catrow[$i];
			$forum[] = $build_forum[$i];
		}
	}

	unset($build_catrow);
	unset($build_forum);

	$template = "cfrm";

	if ($config['CATEGORY_ONLY_MODE'] && ($in['c'] <= 0)) {
		$template = "cfrm_cat_only";

		foreach ($catrow as $k => $v) {
			$catrow[$k]['FORUM_FORUMS'] = 0;
			$catrow[$k]['FORUM_POSTS'] = 0;
			$catrow[$k]['FORUM_TOPICS'] = 0;
			$catrow[$k]['IS_NEW'] = false;
			$catrow[$k]['FORUM_LAST_POST_TIME'] = 0;

			$keys = array_keys($forum[$k]);
			foreach ($keys as $key) {
				$catrow[$k]['FORUM_FORUMS']++;
				$catrow[$k]['FORUM_POSTS'] += $forum[$k][$key]['FORUM_POSTS'];
				$catrow[$k]['FORUM_TOPICS'] += $forum[$k][$key]['FORUM_TOPICS'];
				$catrow[$k]['IS_NEW'] = ($catrow[$k]['IS_NEW'] || $forum[$k][$key]['IS_NEW']);

				if ($forum[$k][$key]['FORUM_LAST_POST_TIME_ORIG'] > $catrow[$k]['FORUM_LAST_POST_TIME_ORIG']) {
					$catrow[$k]['FORUM_LAST_POST_TIME'] = $forum[$k][$key]['FORUM_LAST_POST_TIME'];
					$catrow[$k]['FORUM_LAST_POST_TIME_ORIG'] = $forum[$k][$key]['FORUM_LAST_POST_TIME_ORIG'];
					$catrow[$k]['FORUM_LAST_POST_ID'] = $forum[$k][$key]['FORUM_LAST_POST_ID'];
					$catrow[$k]['FORUM_LAST_TOPIC_ID'] = $forum[$k][$key]['FORUM_LAST_TOPIC_ID'];
					$catrow[$k]['FORUM_LAST_POSTER_ID'] = $forum[$k][$key]['FORUM_LAST_POSTER_ID'];
					$catrow[$k]['FORUM_LAST_POSTER_NAME'] = $forum[$k][$key]['FORUM_LAST_POSTER_NAME'];
					$catrow[$k]['FORUM_LAST_POST_SUBJECT'] = $forum[$k][$key]['FORUM_LAST_POST_SUBJECT'];
					$catrow[$k]['FORUM_LAST_POST_ICON'] = $forum[$k][$key]['FORUM_LAST_POST_ICON'];

					$catrow[$k]['FORUM_LAST_LINK'] = $forum[$k][$key]['FORUM_LAST_LINK'];
					$catrow[$k]['FORUM_LAST_POSTER'] = $forum[$k][$key]['FORUM_LAST_POSTER'];
				}
			}
		}
	}

	if ($are_forums == false) {
		define('NO_RETURN',1);
		$html->not_right($ubbt_lang['NO_FORUMS']);
	} // end if

	// Are we showing the community Intro?
	$introbody = "";
	$introtitle = "";
	if ($config['COMMUNITY_INTRO']) {
		$introtitle = $config['COMMUNITY_INTRO_TITLE'];
		ob_start();
		include("{$config['FULL_PATH']}/includes/community_intro.php");
		$introbody = ob_get_contents();
		ob_end_clean();
	}

	$smarty_data = array(
		'introbody' => & $introbody,
		'introtitle' => $introtitle,
		'catrow' => & $catrow,
	);

	if ($template == "cfrm_cat_only") {
		unset($forum);
	} else {
		$smarty_data['forum'] =& $forum;
	}

	$extra_bread = "";
	if ($c) {
		$extra_bread = " &raquo; $Cat_Title";
	} // end if

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array (
			"title" => (($Cat_Title != "") ? $Cat_Title : $config['COMMUNITY_TITLE']),
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => "",
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 $extra_bread
BREADCRUMB
			,
		),
		"template" => $template,
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
