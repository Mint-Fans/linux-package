<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_changebasic_gpc () {
	return array(
		"input" => array(
			"profilehash" => array("profilehash","post",""),
			"Email" => array("Email","post",""),
			"Email_Verify" => array("Email_Verify","post",""),
			"adminemails" => array("adminemails","post","alpha"),
			"ChosenPassword" => array("ChosenPassword","post",""),
			"Verify" => array("Verify","post",""),
			"Username" => array("Username","post",""),
			"displayname" => array("displayname","post",""),
			"Hobbies" => array("Hobbies","post",""),
			"Fakeemail"  => array("Fakeemail","post",""),
			"bmonth" => array("bmonth","post","int"),
			"bday"   => array("bday","post","int"),
			"byear"  => array("byear","post","int"),
			"showbday" => array("showbday","post","int"),
			"Occupation" => array("Occupation","post",""),
			"Location" => array("Location","post",""),
			"Homepage" => array("Homepage","post",""),
			"Extra1"  => array("CUSTOM_FIELD_1","post",""),
			"Extra2"  => array("CUSTOM_FIELD_2","post",""),
			"Extra3" => array("CUSTOM_FIELD_3","post",""),
			"Extra4" => array("CUSTOM_FIELD_4","post",""),
			"Extra5" => array("CUSTOM_FIELD_5","post",""),
			"icq"  => array("icq","post",""),
			"yahoo"  => array("yahoo","post",""),
			"msn"  => array("msn","post",""),
			"aim"  => array("aim","post",""),
			"Signature"  => array("Signature","post",""),
			"Picture" => array("Picture","post",""),
			"picchange" => array("picchange","post","alpha"),
			"avurl" => array("avurl","post",""),
			"avwidth" => array("avwidth","post","int"),
			"avheight" => array("avheight","post","int"),
			"custom_title" => array("custom_title","post",""),
			"gimages" => array("gimages","post",""),
		),
		"wordlets" => array("changebasic"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_changebasic_gpc

function page_changebasic_run () {

	global $user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$var_start,$var_eq,$var_sep,$var_extra,$userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$picsize = "";

	$Username = $user['USER_DISPLAY_NAME'];
	$Password = $user['USER_PASSWORD'];

	$default_sig = $Signature;

	$html = new html;

	$query = "
		select USER_PROFILE_KEY
		from	{$config['TABLE_PREFIX']}USER_DATA
		where USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
	list($user['USER_PROFILE_KEY']) = $dbh->fetch_array($sth);


	// Make sure this is a legit submission
	if ($profilehash != $user['USER_PROFILE_KEY']) {
		$html -> not_right($ubbt_lang['PHASH']);
	}


	if (!$Email) {
		$html->not_right($ubbt_lang['EMAIL_REQ']);
	}

	// ----------------------
	// Check the email format
	if (!preg_match("#^[+_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$#i", $Email)) {
		$html -> not_right($ubbt_lang['BAD_FORMAT']);
	}

	// Make sure Email and Verify Email match
	if ($Email != $Email_Verify) {
		$html->not_right($ubbt_lang['NO_EMAIL_MATCH']);
	} // end if

	// -----------------------------------------
	// Check if they changed their email address
	$query = "
		SELECT USER_REAL_EMAIL
		FROM   {$config['TABLE_PREFIX']}USER_PROFILE
		WHERE  USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
	list ($origemail) = $dbh -> fetch_array($sth);

	$changeemail = 0;
	if ($origemail != $Email) {
		$query = "
			SELECT USER_REAL_EMAIL
			FROM   {$config['TABLE_PREFIX']}USER_PROFILE
			WHERE  USER_REAL_EMAIL = ?
			AND USER_ID <> ?
		";
		$sth = $dbh->do_placeholder_query($query,array($Email,$user['USER_ID']),__LINE__,__FILE__);
		list ($check) = $dbh -> fetch_array($sth);
		if ($check && $config['REQUIRE_UNIQUE_EMAIL']) {
			$html -> not_right ($ubbt_lang['NO_MULTI']);
		}
		$changeemail = 1;

		// --------------------------------------
		// Let's see if the email domain is valid
		$query = "
			SELECT COUNT(*)
			FROM {$config['TABLE_PREFIX']}BANNED_EMAILS
			WHERE ? LIKE BANNED_EMAIL
		";
		$sth = $dbh->do_placeholder_query($query,array($Email),__LINE__,__FILE__);
		list($etest) = $dbh->fetch_array($sth);
		if ($etest) {
			$html->not_right($ubbt_lang['BANNED_EMAIL']);
		} // end if

		// Insert this into the unverified email field
		$query = "
			update {$config['TABLE_PREFIX']}USER_PROFILE
			set USER_UNVERIFIED_EMAIL = ?
			where USER_ID = ?
		";
		$dbh->do_placeholder_query($query,array($Email,$user['USER_ID']),__LINE__,__FILE__);

		$newemail = $Email;
		$Email = $origemail;



	}

	// Make sure they have chosen an option for receiving admin emails
	if (!$adminemails) {
		$html -> not_right($ubbt_lang['ADMIN_EMAIL']);
	}

	// -----------------------------------------------------------
	// If the 2 given password do not match then we can't proceed
	if($ChosenPassword != $Verify){
		$html -> not_right($ubbt_lang['PASS_MATCH']);
	}

	// --------------------------------------------------------
	// If the password isn't the proper length we can't proceed
	if ($ChosenPassword != "123456789123456789") {
		if((strlen($ChosenPassword)<4) || (strlen($ChosenPassword)>20)){
			$html -> not_right($ubbt_lang['PASS_TOO_LONG']);
		}
	}

	// Make sure password isn't the same as displayname
	if (($ChosenPassword == $displayname) || ($ChosenPassword == $Username)) {
		$html -> not_right($ubbt_lang['PASS_USER_MATCH']);
	} // end if

	$ChosenPassword = trim($ChosenPassword);

	// -----------------------------------------------
	// If this is a new password we need to encrypt it
	$changepassword = 0;
	if ($ChosenPassword != "123456789123456789") {
		$changepassword = 1;
		$ChosenPassword = md5($ChosenPassword);
	}


	// -----------------------------------------------
	// Strip trailing/leading spaces from $displayname
	$displayname = trim($displayname);
	$displayname = preg_replace("/^&nbsp;/","",$displayname);
	$displayname = preg_replace("/&nbsp;$/","",$displayname);


	// ----------------------------------------
	// Check if they changed their display name
	// or their email address
	$query = "
		SELECT USER_DISPLAY_NAME,USER_REGISTERED_ON
		FROM   {$config['TABLE_PREFIX']}USERS
		WHERE  USER_ID = ?
	";
	$sth = $dbh -> do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
	list ($currentname,$regedon) = $dbh -> fetch_array($sth);

	$changedisplay = 0;
	$displayname = trim($displayname);
	if ($currentname != $displayname) {



		$query = "
			SELECT USER_ID
			FROM   {$config['TABLE_PREFIX']}USERS
			WHERE  (USER_DISPLAY_NAME = ?
			OR     USER_LOGIN_NAME = ?)
			AND	 USER_ID <> ?
		";
		$sth = $dbh -> do_placeholder_query($query,array($displayname,$displayname,$user['USER_ID']),__LINE__,__FILE__);
		list($Usercheck) = $dbh -> fetch_array($sth);
		if ( ($Usercheck) && ($Usercheck != $user['USER_ID']) ){
			$html -> not_right($ubbt_lang['NAME_TAKEN']);
		}
		list($ok,$err) = is_valid_name($displayname,"display",$user['USER_ID']);
		if ($ok === false) {
			$html->not_right($ubbt_lang[$err]);
		} // end if

		// -------------------------------------------------
		// Delete the old display name from the Online table
		$Username_q = addslashes($Username);
		$query = "
		DELETE FROM {$config['TABLE_PREFIX']}ONLINE
		WHERE  ONLINE_DISPLAY_NAME = ?
		";
		$dbh -> do_placeholder_query($query,array($Username),__LINE__,__FILE__);


		if ($config['DISPLAY_NAME_CHANGE'] == "1" || ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator") ) {
			$changedisplay = 1;
		}
		if ($config['DISPLAY_NAME_CHANGE'] == "2" && ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator")) {

			$query = "
			SELECT COUNT(*) FROM {$config['TABLE_PREFIX']}DISPLAY_NAMES
			WHERE USER_ID = ?
			";
			$sth = $dbh -> do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
			list($check) = $dbh -> fetch_array($sth);
			if ($check) {
				$html -> not_right("{$ubbt_lang['DUP_REQUEST']}");
			}
			$query = "
			INSERT INTO {$config['TABLE_PREFIX']}DISPLAY_NAMES
			(USER_ID,DISPLAY_NAME_REQUEST)
			VALUES
			( ? , ? )
			";
			$dbh -> do_placeholder_query($query,array($user['USER_ID'],$displayname),__LINE__,__FILE__);

			// ---------------------------------------------------------------------
			// Now if we are manually approving displayname changes we need to send an
			// email to all admins
			$query = "
				SELECT up.USER_REAL_EMAIL, up.USER_LANGUAGE, u.USER_DISPLAY_NAME
					FROM {$config['TABLE_PREFIX']}USER_PROFILE up,
							 {$config['TABLE_PREFIX']}USERS u
				WHERE u.USER_MEMBERSHIP_LEVEL = 'Administrator'
					AND up.USER_ID = u.USER_ID
			";
			$sth = $dbh -> do_query($query,__LINE__,__FILE__);
			$mailer = new mailer();
			while(list($adminemail, $adminlang, $adminname) = $dbh -> fetch_array($sth)) {
				if (!$adminemail) continue;
				// Must set the language first!
				$mailer->set_language($adminlang);
				$mailer->set_subject('PDN_SUBJECT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
				$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $adminname));
				$mailer->add_content('PDN_CONTENT', array('OLDNAME' => $currentname, 'NEWNAME' => $displayname));
				$mailer->add_content('PDN_CONTENT1', array('APPROVE_URL' => "{$config['FULL_URL']}/admin/login.php?file=approvepdn.php"), true);
				$mailer->ubbt_mail($adminemail);
			}
		}
	}

	// ----------------------------
	// Did they specify a birthday?
	if (!$showbday) { $showbday = "0"; }
	$temp = getdate();
	$thisyear  = $temp["year"];
	if ($bmonth == 1 && $bday == 1 && $byear == $thisyear) {
		$birthday = "";
	}
	else {
		$birthday = "$bmonth/$bday/$byear";
	}

	// --------------------------------------------------------
	// If Occupation is greater than 150 then we can't proceed
	if ( strlen($Occupation) > 150 ) {
		$html -> not_right($ubbt_lang['OCC_TOO_LONG']);
	}

	// -----------------------------------------------------
	// If location is greater than 200 then we can't proceed
	if ( strlen($Location) > 200 ) {
		$html -> not_right($ubbt_lang['LOC_TOO_LONG']);
	}

	// ----------------------------------------------------
	// If hobbies is greater than 200 then we can't proceed
	if ( strlen($Hobbies) > 200 ) {
		$html -> not_right($ubbt_lang['HOBB_TOO_LONG']);
	}

	// -----------------------------------------------------
	// If homepage is greater than 150 then we can't proceed
	if ( strlen($Homepage) > 150 ) {
		$html -> not_right($ubbt_lang['HOME_TOO_LONG']);
	}

	$lengthcheck = preg_replace("#(\n|\r|<br />)#","",$Signature);

	// -------------------------------------------------------------
	// If signature is greater than the specified size, do not allow
	if ( strlen($lengthcheck) > $userob->check_access("site","SIGNATURE_LENGTH") ) {
		$html -> not_right($ubbt_lang['SIG_TOO_LONG']);
	}

	// Group Images?
	$group_images = "";
	if (is_array($gimages)) {
		$group_images = serialize($gimages);
	}

	// ----------------------------------------------------------
	// If picture doesn't end with gif or jpg then we disallow it
	if ( ($Picture) && ($Picture != "http://") && (!preg_match("/(png|jpg|gif)$/i",$Picture))) {
		$html -> not_right($ubbt_lang['BAD_PIC']);
	}
	if ($picchange == "url" && $userob->check_access("site","REMOTE_AVATARS")) {
		if ( ($Picture) && ($Picture != "http://") && ($Picture != "none") ) {
			if (!preg_match("/^http/",$Picture)) {
				$Picture = "";
				$imagewidth = 0;
				$imageheight = 0;
			}
			else {
				$Picture = preg_replace("/('|\")/","",$Picture);
				$imagehw = getimagesize($Picture);
				$imagewidth = $imagehw[0];
				$imageheight = $imagehw[1];
				if ($config['AVATAR_MAX_WIDTH'] && $config['AVATAR_MAX_HEIGHT']) {
					if ($imagewidth > $config['AVATAR_MAX_WIDTH']) {
						$div = $imagewidth / $config['AVATAR_MAX_WIDTH'];
						$imagewidth = ceil($imagewidth / $div);
						$imageheight = ceil($imageheight / $div);
					}
					if ($imageheight > $config['AVATAR_MAX_HEIGHT']) {
						$div = $imageheight / $config['AVATAR_MAX_HEIGHT'];
						$imageheight = ceil($imageheight / $div);
						$imagewidth = ceil($imageheight / $div);
					}
				} // end if
			}
		}
	}

	// --------------------------------------------------
	// If we have a picture attachment then we handle it here
	if ($picchange == "upload") {
		if (isset($_FILES['userfile'])) {
			if ( (!empty($_FILES['userfile']['name'])) && ($_FILES['userfile']['name'] != "none") ){
				if (!preg_match("/(png|jpg|gif)$/i",$_FILES['userfile']['name'])) {
					$html -> not_right($ubbt_lang['BAD_PIC']);
				}
			}
			if ( ($_FILES['userfile']['size'] > $config['MAX_AVATAR_SIZE']) ) {
				$html -> not_right($html->substitute($ubbt_lang['FILE_TOO_BIG'], array('AVVY_SIZE' => $config['MAX_AVATAR_SIZE'])));
			}
			if ( ($_FILES['userfile']['name'] != "none") && ($_FILES['userfile']['name']) ){

				// -----------------
				// Grab the filetype
				$piece['0'] = "";
				preg_match("/(\.gif|\.png|\.jpg)$/i",$_FILES['userfile']['name'],$piece);
				$type = $piece['1'];
				$Picturefile = "{$user['USER_ID']}$type";
				$Picturefile = strtolower($Picturefile);
				if ( ($_FILES['userfile']['tmp_name'] != "none") && ($_FILES['userfile']['tmp_name']) ){
					move_uploaded_file($_FILES['userfile']['tmp_name'], "{$config['UPLOADED_AVATAR_PATH']}/$Picturefile");
					// Make sure it's a valid image
					$fp = fopen("{$config['UPLOADED_AVATAR_PATH']}/$Picturefile", 'rb');
					if ($fp) {
						$header = fread($fp, 200);
						fclose($fp);
						if (preg_match('#<head|<html|<body|<script#is', $header)) {
							unlink("{$config['UPLOADED_AVATAR_PATH']}/$Picturefile");
							$html -> not_right($ubbt_lang['MALFORMED_PIC']);
						}
					}

					chmod("{$config['UPLOADED_AVATAR_PATH']}/$Picturefile",0666);
				}
				$imagehw = getimagesize("{$config['UPLOADED_AVATAR_PATH']}/$Picturefile");



				$imagewidth = $imagehw[0];
				$imageheight = $imagehw[1];
				if ($config['AVATAR_MAX_WIDTH'] && $config['AVATAR_MAX_HEIGHT']) {
					if ($imagewidth > $config['AVATAR_MAX_WIDTH']) {
						$div = $imagewidth / $config['AVATAR_MAX_WIDTH'];
						$imagewidth = ceil($imagewidth / $div);
						$imageheight = ceil($imageheight / $div);
					}
					if ($imageheight > $config['AVATAR_MAX_HEIGHT']) {
						$div = $imageheight / $config['AVATAR_MAX_HEIGHT'];
						$imageheight = ceil($imageheight / $div);
						$imagewidth = ceil($imageheight / $div);
					}
				} // end if

				$Picture = "{$config['UPLOADED_AVATAR_URL']}/$Picturefile";
			}

			// Make sure we have a width/height
			if (!isset($imagewidth)) { $imagewidth = $config['AVATAR_MAX_WIDTH']; }
			if (!isset($imageheight)) { $imageheight = $config['AVATAR_MAX_HEIGHT']; }

		}
	}

	// -------------------------------------------------------
	// If we are using an avatar then we set the stuff up here
	if ($picchange == "avatar") {
		$Picture = $avurl;
		$imagewidth = $avwidth;
		$imageheight = $avheight;
	}



	// -------------------------------------------
	// Make sure all required fields are filled in
	$query = "
	SELECT REGISTRATION_FIELD
	FROM {$config['TABLE_PREFIX']}REGISTRATION_FIELDS
	WHERE REGISTRATION_REQUIRE_FIELD='1'
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	$regfields = "";
	$regvalues = "";
	while(list($field) = $dbh->fetch_array($sth)) {

		if ($field == "USER_FAKE_EMAIL" && !$Fakeemail) {
			$html->not_right($ubbt_lang['FAKE_REQ']);
		}
		if ($field == "USER_BIRTHDAY" && !$birthday) {
			$html->not_right($ubbt_lang['BIRTHDAY_REQ']);
		}
		if ($field == "USER_SIGNATURE" && !$Signature) {
			$html->not_right($ubbt_lang['SIGNATURE_REQ']);
		}
		if ($field == "USER_HOMEPAGE" && !$Homepage) {
			$html->not_right($ubbt_lang['HOMEPAGE_REQ']);
		}
		if ($field == "USER_OCCUPATION" && !$Occupation) {
			$html->not_right($ubbt_lang['OCCUPATION_REQ']);
		}
		if ($field == "USER_HOBBIES" && !$Hobbies) {
			$html->not_right($ubbt_lang['HOBBIES_REQ']);
		}
		if ($field == "USER_LOCATION" && !$Location) {
			$html->not_right($ubbt_lang['LOCATION_REQ']);
		}
		if ($field == "USER_ICQ" && !$icq) {
			$html->not_right($ubbt_lang['ICQ_REQ']);
		}
		if ($field == "USER_YAHOO" && !$yahoo) {
			$html->not_right($ubbt_lang['YAHOO_REQ']);
		}
		if ($field == "USER_MSN" && !$msn) {
			$html->not_right($ubbt_lang['MSN_REQ']);
		}
		if ($field == "USER_AIM" && !$aim) {
			$html->not_right($ubbt_lang['AIM_REQ']);
		}
		if ($field == "USER_EXTRA_FIELD_1" && !$Extra1 && $Extra1 != "0") {
			$html->not_right($config['CUSTOM_FIELD_1'] . $ubbt_lang['IS_REQ']);
		}
		if ($field == "USER_EXTRA_FIELD_2" && !$Extra2 && $Extra2 != "0") {
			$html->not_right($config['CUSTOM_FIELD_2'] . $ubbt_lang['IS_REQ']);
		}
		if ($field == "USER_EXTRA_FIELD_3" && !$Extra3 && $Extra3 != "0") {
			$html->not_right($config['CUSTOM_FIELD_3'] . $ubbt_lang['IS_REQ']);
		}
		if ($field == "USER_EXTRA_FIELD_4" && !$Extra4 && $Extra4 != "0") {
			$html->not_right($config['CUSTOM_FIELD_4'] . $ubbt_lang['IS_REQ']);
		}
		if ($field == "USER_EXTRA_FIELD_5" && !$Extra5 && $Extra5 != "0") {
			$html->not_right($config['CUSTOM_FIELD_5'] . $ubbt_lang['IS_REQ']);
		}
	}

	// Censor the input?
	if ($config['DO_CENSOR']) {
		$Occupation = $html->do_censor($Occupation);
		$Location = $html->do_censor($Location);
		$Hobbies = $html->do_censor($Hobbies);
		$Homepage = $html->do_censor($Homepage);
		$icq = $html->do_censor($icq);
		$yahoo = $html->do_censor($yahoo);
		$msn = $html->do_censor($msn);
		$aim = $html->do_censor($aim);
		$Signature = $html->do_censor($Signature);
		$Extra1 = $html->do_censor($Extra1);
		$Extra2 = $html->do_censor($Extra2);
		$Extra3 = $html->do_censor($Extra3);
		$Extra4 = $html->do_censor($Extra4);
		$Extra5 = $html->do_censor($Extra5);
	}




	// ------------------------------------------------
	// Strip out all of the <> and change to HTML codes
	$Fakeemail = str_replace("<","&lt;",$Fakeemail);
	$Occupation = str_replace("<","&lt;",$Occupation);
	$Location = str_replace("<","&lt;",$Location);
	$Hobbies = str_replace("<","&lt;",$Hobbies);
	$Homepage = str_replace("<","&lt;",$Homepage);
	$Homepage = str_replace("\"","",$Homepage);
	$Homepage = str_replace("'","",$Homepage);
	$icq = str_replace("<","&lt;",$icq);
	$yahoo = str_replace("<","&lt;",$yahoo);
	$msn = str_replace("<","&lt;",$msn);
	$aim = str_replace("<","&lt;",$aim);
	$Extraone = str_replace("<","&lt;",$Extra1);
	$Extratwo = str_replace("<","&lt;",$Extra2);
	$Extrathr = str_replace("<","&lt;",$Extra3);
	$Extrafou = str_replace("<","&lt;",$Extra4);
	$Extrafiv = str_replace("<","&lt;",$Extra5);
	$Picture = str_replace("<","&lt;",$Picture);

	$Signature = $html->do_markup($Signature,"signature","markup");

	// --------------------------
	// Update the User's profile
	$date = $html->get_date();
	$query_vars = array($Email,$adminemails,$Fakeemail,$birthday,$showbday,$Occupation,$Location,$Hobbies,$Homepage,$Extraone,$Extratwo,
	$Extrathr,$Extrafou,$Extrafiv,$icq,$yahoo,$msn,$aim,$Signature,$default_sig,$group_images);


	// Only change picture if picchange was selected
	$picupdate = "";
	if(($picchange) && ($picchange != "nopic") ) {
		$picupdate = ",USER_AVATAR = ? , USER_AVATAR_WIDTH = ? , USER_AVATAR_HEIGHT = ? ";
		if (!$imagewidth) $imagewidth = "0";
		if (!$imageheight) $imageheight = "0";
		array_push($query_vars,$Picture,$imagewidth,$imageheight);
	}
	elseif ( ($picchange) && ($picchange == "nopic") ) {
		$picupdate = ",USER_AVATAR = '' , USER_AVATAR_WIDTH = '0' , USER_AVATAR_HEIGHT = '0' ";
	}

	// If the custom title has changed then we need to censor it
	// if necessary and also strip out any html
	$titleupdate = "";
	if ($custom_title != $user['USER_CUSTOM_TITLE']) {
		if ($config['DO_CENSOR']) {
			$custom_title = $html->do_censor($custom_title);
		} // end if
		// If you aren't an admin or moderator...no HTML for you!
		if ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && !preg_match("/Moderator/",$user['USER_MEMBERSHIP_LEVEL'])) {
			$custom_title = str_replace("<","&lt;",$custom_title);
		} // end if
		// Check for length restriction
		if (strlen($custom_title) > $userob->check_access("site","CUSTOM_TITLE")) {
			$html->not_right($ubbt_lang['CUSTOM_TITLE_TOO_LONG']);
		} // end if

		$titleupdate = ",USER_CUSTOM_TITLE = ?";
		array_push($query_vars,$custom_title);
	}


	array_push($query_vars,$user['USER_ID']);

	$query  = "
	UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
	set
	USER_REAL_EMAIL = ? ,
	USER_ACCEPT_ADMIN_EMAILS = ? ,
	USER_DISPLAY_EMAIL = ? ,
	USER_BIRTHDAY = ? ,
	USER_PUBLIC_BIRTHDAY = ? ,
	USER_OCCUPATION = ? ,
	USER_LOCATION = ? ,
	USER_HOBBIES = ? ,
	USER_HOMEPAGE = ? ,
	USER_EXTRA_FIELD_1 = ? ,
	USER_EXTRA_FIELD_2 = ? ,
	USER_EXTRA_FIELD_3 = ? ,
	USER_EXTRA_FIELD_4 = ? ,
	USER_EXTRA_FIELD_5 = ? ,
	USER_ICQ = ? ,
	USER_YAHOO = ? ,
	USER_MSN = ? ,
	USER_AIM = ? ,
	USER_SIGNATURE = ? ,
	USER_DEFAULT_SIGNATURE = ?,
	USER_GROUP_IMAGES = ?
	$picupdate
	$titleupdate
	WHERE USER_ID = ?
	";
	$dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

	if ($changedisplay || $changepassword) {
		$query_vars = array();
		$query_string = "";
		if ($changedisplay) {
			$currentname = $displayname;
			$query_string = "USER_DISPLAY_NAME = ? ,";
			array_push($query_vars,$displayname);
		}
		if ($changepassword) {
			$query_string .= "USER_PASSWORD = ? ,";
			array_push($query_vars,$ChosenPassword);
		}
		$query_string = preg_replace("/,$/","",$query_string);
		array_push($query_vars,$user['USER_ID']);
		$query = "
			update	{$config['TABLE_PREFIX']}USERS
			set			$query_string
			where		USER_ID = ?
		";
		$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	} // end if

	$query  = "
	UPDATE {$config['TABLE_PREFIX']}USER_DATA
	SET USER_LAST_VISIT_TIME         = '$date'
	WHERE USER_ID = '{$user['USER_ID']}'
	";
	$dbh -> do_query($query,__LINE__,__FILE__);

	// ------------------------------------------------------
	// If they are always rememberd we need to update the key
	if (( isset(${$config['COOKIE_PREFIX']."ubbt_key"}) && ${$config['COOKIE_PREFIX']."ubbt_key"}) && ($Password != $ChosenPassword)){
		if ($config['COOKIE_LIFETIME'] > 31536000) {
			$config['COOKIE_LIFETIME'] = 31536000;
		}
		$autolog = md5("{$user['USER_ID']}$ChosenPassword");
		$html -> ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_key","$autolog",time()+$config['COOKIE_LIFETIME']);
	}


	// If they've changed their display name, we need to update the main forum
	// list with the new display name
	if ($changedisplay) {
		$query = "
			update {$config['TABLE_PREFIX']}FORUMS
			set FORUM_LAST_POSTER_NAME = ?
			where FORUM_LAST_POSTER_NAME = ?
		";
		$dbh->do_placeholder_query($query,array($displayname,$currentname),__LINE__,__FILE__);
	} // end if

	// If they changed their email, dispatch a verification email to the new
	// email address
	if ($changeemail) {
		$mailer = new mailer();
		$mailer->set_language($user['USER_LANGUAGE']);
		$mailer->set_subject('VER_EMAIL_SUB',array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
		$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $currentname));
		$verification_key = md5("$regedon$newemail");
		$mailer->add_content('VER_EMAIL_CONTENT', array('EMAIL' => $newemail, 'VERIFY_URL' => make_ubb_url("ubb=verifyemail&verify={$user['USER_ID']}-$verification_key&em=1", "", true, true)));
		$mailer->ubbt_mail($newemail);
	} // end if

	rebuild_islands("birthdays");

	// ---------------------------------------------------
	// Send them to their start page with the confirmation
	return array(
		"header" => "",
		"template" => "",
		"data" => "",
		"footer" => false,
		"location" => "editbasic&u=1&e=$changeemail",
	);

}

?>
