<?php

//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_coppaform_gpc () {
	return array(
		"input" => array(),
		"wordlets" => array("coppaform"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_coppaform_gpc

function page_coppaform_run () {

	global $smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$var_start,$var_eq,$var_sep,$var_extra,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$date = date("M/d/Y");

	// Grab the coppainsert file
	$insert = @file("{$config['FULL_PATH']}/includes/coppainsert.php");
	if (!is_array($insert)) {
		$insert = @file("{$config['BASE_URL']}/includes/coppainsert.php");
	}
	$coppainsert = "";
	if ($insert) {
		while (list($linenum,$line) = each($insert)) {
			$coppainsert .= "$line";
		}
	}

	// --------------------------------
	// Grab their info, if there is any
	$coppaid = "";
	if (isset(${$config['COOKIE_PREFIX']."ubbt_coppaid"})) {
		$coppaid = ${$config['COOKIE_PREFIX']."ubbt_coppaid"};
	}
	$query = "
	SELECT t1.USER_DISPLAY_NAME,t2.USER_REAL_EMAIL,t2.USER_BIRTHDAY
	FROM   {$config['TABLE_PREFIX']}USERS as t1,
	{$config['TABLE_PREFIX']}USER_PROFILE as t2
	WHERE  t1.USER_ID = ?
	AND    t1.USER_ID = t2.USER_ID
	";
	$sth = $dbh -> do_placeholder_query($query,array($coppaid),__LINE__,__FILE__);
	list($loginname,$emailaddress,$birthdate) = $dbh -> fetch_array($sth);

	$smarty_data = array(
		"loginname" => $loginname,
		"emailaddress" => $emailaddress,
		"birthdate" => $birthdate,
		"coppainsert" => $coppainsert,
	);

	return array(
		"header" => array (
			"title" => $config['COMMUNITY_TITLE'],
			"refresh" => 0,
			"user" => array(),
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
		),
		"template" => "coppaform",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}
?>