<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_deleteevent_gpc () {
	return array(
		"input" => array(
			"entry" => array("entry","post","int"),
			"month" => array("month","post","int"),
			"year" => array("year","post","int"),
		),
		"wordlets" => array("deleteevent"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_deleteevent_gpc

function page_deleteevent_run () {

	global $user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$var_start,$var_eq,$var_sep,$var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars
	
	$html = new html;

	$query = "
	SELECT USER_ID
	FROM    {$config['TABLE_PREFIX']}CALENDAR_EVENTS
	WHERE  CALENDAR_EVENT_ID = ?
	";
	$sth = $dbh -> do_placeholder_query($query,array($entry),__LINE__,__FILE__);
	list ($owner) = $dbh -> fetch_array($sth);

	if ($owner != $user['USER_ID'] && $user['USER_MEMBERSHIP_LEVEL'] != "Administrator") {
		$html -> not_right("{$ubbt_lang['NO_EDIT']}");
	}

	// ------------------
	// Delete this event
	$query = "
	DELETE FROM {$config['TABLE_PREFIX']}CALENDAR_EVENTS
	WHERE CALENDAR_EVENT_ID = ?
	";
	$dbh -> do_placeholder_query($query,array($entry),__LINE__,__FILE__);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$html->send_redirect(
		array(
			"redirect" =>"calendar&month=$month&year=$year",
			"heading" => $ubbt_lang['HEAD'],
			"body" => $ubbt_lang['BODY'],
			"returnlink" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 {$ubbt_lang['HEAD']}
BREADCRUMB
			,
		)
	);

}
?>
