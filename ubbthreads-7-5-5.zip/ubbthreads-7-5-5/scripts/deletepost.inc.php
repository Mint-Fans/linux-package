<?php

//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_deletepost_gpc () {
	return array(
		"input" => array(
			"Username" => array("Username","post",""),
			"Board" => array("Board","post","alphanum"),
			"what" => array("what","post","alpha"),
			"Number" => array("Number","post","int"),
			"Approved" => array("Approved","post","alpha"),
		),
		"wordlets" => array("deletepost"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_deletepost_gpc

function page_deletepost_run () {
	global $html,$userob, $user, $in, $ubbt_lang, $config, $dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$Username = $user['USER_DISPLAY_NAME'];

	// Get the board this is on
	$query = "
		select	t1.FORUM_ID
		from	{$config['TABLE_PREFIX']}TOPICS as t1,
			{$config['TABLE_PREFIX']}POSTS as t2
		where	t2.POST_ID = ?
		and	t1.TOPIC_ID = t2.TOPIC_ID
	";
	$sth = $dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);
	list($Board) = $dbh->fetch_array($sth);

	// ------------------
	// Get the forum info
	$query = "
	SELECT FORUM_CUSTOM_HEADER,FORUM_STYLE,FORUM_LAST_POST_ID,CATEGORY_ID,FORUM_TITLE,FORUM_PARENT,FORUM_IS_RSS,FORUM_RSS_TITLE
	FROM   {$config['TABLE_PREFIX']}FORUMS
	WHERE  FORUM_ID = ?
	";
	$sth = $dbh -> do_placeholder_query($query,array($Board),__LINE__,__FILE__);
	list ($fheader,$fstyle,$lastnumber,$cat_id,$Title,$parent_id,$is_rss,$rss_title) = $dbh -> fetch_array($sth);

	if (!$is_rss) $rss_title = "";

	// -------------------------------------------------
	// Here we need to figure out what stylesheet to use
	if ($fstyle) {
		$html->set_style($fstyle);
	}

	// -----------------------------------
	// Get the post info from the database
	$query = "
		SELECT t1.USER_ID,t1.POST_SUBJECT,t1.POST_BODY,t1.POST_IS_APPROVED,t1.TOPIC_ID,t1.POST_IS_TOPIC,t1.POST_PARENT_ID,t1.POST_POSTED_TIME
		FROM  {$config['TABLE_PREFIX']}POSTS AS t1,
			{$config['TABLE_PREFIX']}TOPICS as t2
		WHERE t1.POST_ID = ?
		AND	t1.TOPIC_ID = t2.TOPIC_ID
		AND   t2.FORUM_ID  = ?
	";
	$sth = $dbh -> do_placeholder_query($query,array($Number,$Board),__LINE__,__FILE__);

	// -------------------------
	// Assign the retrieved data
	list($Postedby,$Subject,$Body,$Approved,$topic_id,$post_is_topic,$parent_post,$posted_on) = $dbh -> fetch_array($sth);
	$dbh -> finish_sth($sth);


	// ----------------------------------------------------------------------------
	// Check if they moderate this board or they are an admin or they made the post
	if ($user['USER_MEMBERSHIP_LEVEL'] == "GlobalModerator") {
		$modcheck = true;
	}

	if ($user['USER_MEMBERSHIP_LEVEL'] == "Moderator") {
		$query = "
		SELECT USER_ID
		FROM   {$config['TABLE_PREFIX']}MODERATORS
		WHERE  FORUM_ID = ?
		AND    USER_ID = ?
		";
		$sth = $dbh -> do_placeholder_query($query,array($Board,$user['USER_ID']),__LINE__,__FILE__);
		list($modcheck) = $dbh -> fetch_array($sth);
	}

	if ( ($user['USER_ID'] != $Postedby) && ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator") && (!$modcheck) ) {
		$html -> not_right($ubbt_lang['NO_EDIT']);
	}

	$right_now = $html->get_date();
	$del_expired = false;

	if (($right_now - $posted_on) > ($userob->check_access("forum","DELETE_POSTS",$Board) * 60)) {
		$del_expired = true;
	} // end if

	if ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && !$modcheck && $del_expired) {
		$html->not_right($ubbt_lang['DELETE_EXPIRED']);
	} // end if

	$query = "
		select FILE_NAME,FILE_DIR
		from {$config['TABLE_PREFIX']}FILES
		where POST_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);
	while(list($File,$dir) = $dbh->fetch_array($sth)) {
		if (!$dir) {
			unlink("{$config['ATTACHMENTS_PATH']}/$File");
		} else {
			unlink("{$config['FULL_PATH']}/gallery/$dir/full/$File");
			unlink("{$config['FULL_PATH']}/gallery/$dir/medium/$File");
			unlink("{$config['FULL_PATH']}/gallery/$dir/thumbs/$File");
		}
	}

	$query = "
		delete from {$config['TABLE_PREFIX']}FILES
		where POST_ID = ?
	";
	$dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);

	$query = "
	DELETE FROM {$config['TABLE_PREFIX']}POSTS
	WHERE POST_ID = ?
	";
	$dbh -> do_placeholder_query($query,array($Number),__LINE__,__FILE__);

	// Update all replies so their parent is set to this
	// post's parent
	$query = "
		update {$config['TABLE_PREFIX']}POSTS
		set POST_PARENT_ID = ?
		where TOPIC_ID = ?
		and POST_PARENT_ID = ?
	";
	$dbh->do_placeholder_query($query,array($parent_post,$topic_id,$Number),__LINE__,__FILE__);


	// ----------------------------------------------------------
	// If this post is approved then we bump the number down by 1
	if ($Approved == "1"){

		$query = "
			select count(*)
			from {$config['TABLE_PREFIX']}POSTS
			where TOPIC_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($topic_id),__LINE__,__FILE__);
		list ($postcount) = $dbh->fetch_array($sth);
		if (!$postcount) {
			$query = "
				delete from {$config['TABLE_PREFIX']}TOPICS
				where TOPIC_ID = ?
			";
			$dbh->do_placeholder_query($query,array($topic_id),__LINE__,__FILE__);
		} else {
			rebuild_topic_data($topic_id);
		}
		rebuild_forum_data($Board);
	} else {
		rebuild_topic_data($topic_id);
	}


	if ($post_is_topic) {

		// -------------------------------
		// Delete from the favorites table
		$query = "
		DELETE FROM {$config['TABLE_PREFIX']}WATCH_LISTS
		WHERE  WATCH_ID = ?
		AND		 WATCH_TYPE = 't'
		";
		$dbh -> do_placeholder_query($query,array($topic_id),__LINE__,__FILE__);

		// Delete from announcements table
		$query = "
		DELETE FROM {$config['TABLE_PREFIX']}ANNOUNCEMENTS
		WHERE TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query,array($topic_id),__LINE__,__FILE__);
	}

	$query = "
		select POLL_ID
		from {$config['TABLE_PREFIX']}POLL_DATA
		where POST_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);
	while(list($Poll) = $dbh->fetch_array($sth)) {

		$query = "
		DELETE FROM {$config['TABLE_PREFIX']}POLL_DATA
		WHERE  POLL_ID = ?
		";
		$dbh -> do_placeholder_query($query,array($Poll),__LINE__,__FILE__);
		$query = "
		DELETE FROM {$config['TABLE_PREFIX']}POLL_OPTIONS
		WHERE  POLL_ID = ?
		";
		$dbh -> do_placeholder_query($query,array($Poll),__LINE__,__FILE__);
		$query = "
		DELETE FROM {$config['TABLE_PREFIX']}POLL_VOTES
		WHERE  POLL_ID = ?
		";
		$dbh -> do_placeholder_query($query,array($Poll),__LINE__,__FILE__);
	}

	// Rebuild the islands
	rebuild_islands(1);

	// Log this action
	admin_log("DELETE_POST","<a href='" . make_ubb_url("ubb=postlist&Board=$Board", $Title, false) . "' target='_blank'>$Title</a>: $Subject");

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$html->send_redirect(
		array(
			"redirect" => "postlist&Board=$Board",
			"heading" => $ubbt_lang['POST_DEL_HEAD'],
			"body" => "{$ubbt_lang['POST_DEL_HEAD']} {$ubbt_lang['RET_FORUM']}",
			"returnlink" => "",
			"Board" => $Board,
			"Category" => $cat_id,
			"parent_forum" => $parent_id,
			"custom_header_footer" => $fheader,
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
			,
		)
	);

}
?>
