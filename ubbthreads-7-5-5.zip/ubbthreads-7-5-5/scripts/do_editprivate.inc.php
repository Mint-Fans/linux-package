<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_do_editprivate_gpc () {
	return array(
		"input" => array(
			"message" => array("message","post","int"),
			"Body" => array("Body","post",""),
			"submit" => array("submit","post",""),
			"Subject" => array("Subject","post",""),
			"subj" => array("subj","post",""),
		),
		"wordlets" => array("editprivate"),
		"user_fields" => "USER_TEXT_EDITOR",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_do_editprivate_gpc

function page_do_editprivate_run () {

	global $smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$var_start,$var_eq,$var_sep,$var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$html = new html;

	if (!isset($PHPSESSID)) {
		$PHPSESSID = "";
	}

	$DefaultBody = $Body;

	// Make sure they can access this pm
	$query = "
		select 	TOPIC_ID,USER_ID
		from	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
		where	POST_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($message),__LINE__,__FILE__);
	list($topic_id,$poster) = $dbh->fetch_array($sth);

	if ($poster != $user['USER_ID']) {
		$html->not_right($ubbt_lang['NO_PERM']);
	}

	$query = "
		select 	count(*)
		from	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
		where	USER_ID = ?
		and	TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($user['USER_ID'],$topic_id),__LINE__,__FILE__);
	list($perm_check) = $dbh->fetch_array($sth);
	if (!$perm_check) {
		$html->not_right($ubbt_lang['NO_PERM']);
	} // end if

	// Are we deleting this PM?
	if ($submit == $ubbt_lang['DELETE']) {
		$query = "
			delete from {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
			where	POST_ID = ?
		";
		$dbh->do_placeholder_query($query,array($message),__LINE__,__FILE__);
		return array(
			"header" => "",
			"template" => "",
			"footer" => false,
			"location" => "viewmessage&message=$topic_id&PHPSESSID=$PHPSESSID",
		);
		exit;
	}

	if ($config['DO_CENSOR']) {
		$Body = $html->do_censor($Body);
		$Subject = $html->do_censor($Subject);
	}

	// ------------
	// Get the date
	$date = $html -> get_date();

	// -------------------------------------
	// Make sure there is a subject and body
	if ($Body == "" || ($Subject == "" && $subj == 1)) {
		$html -> not_right($ubbt_lang['ALL_FIELDS']);
	}

	// ------------------
	// Markup the Body
	$Body = $html -> do_markup($Body,"post","markup");

	$query = "
		update {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
		set	POST_BODY = ?,
			POST_DEFAULT_BODY = ?
		where	POST_ID = ?
	";
	$dbh -> do_placeholder_query($query,array($Body,$DefaultBody,$message),__LINE__,__FILE__);

	// If this post has a subject (1st post), update it
	if ($subj == 1) {
		$query = "
			UPDATE {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS
			SET TOPIC_SUBJECT = ? 
			WHERE TOPIC_ID = ? 
		";
		$dbh->do_placeholder_query($query,array($Subject,$topic_id),__LINE__,__FILE__);
	}
	// ---------------------------
	// Return to their start page
	return array(
		"header" => "",
		"template" => "",
		"footer" => false,
		"location" => "viewmessage&message=$topic_id&jump=$message#number$message",
	);

}

?>
