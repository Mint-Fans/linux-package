<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;
define('NO_WRAPPER',1);

function page_dochangemood_gpc () {
	return array(
		"input" => array(
			"mood" => array("mood","post",""),
		),
		"wordlets" => array(""),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_dochangemood_gpc

function page_dochangemood_run () {

	global $style_array,$smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$var_start,$var_eq,$var_sep,$var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$smarty_data = array();

	$html = new html;

	// Let's make sure this is a valid mood
        $dir = opendir("{$config['FULL_PATH']}/images/{$style_array['mood']}");
        $i = 0;
	$found = false;
        while( ($file = readdir($dir)) != false) {
		if ($file == $mood) {
			$found = true;
		}
	} // end while


	if (!$found) {
		$mood = "content.gif";
	}

	// Update this person's mood
	$query = "
		update {$config['TABLE_PREFIX']}USER_PROFILE
		set USER_MOOD = ?
		where USER_ID = ?
	";
	$dbh->do_placeholder_query($query,array($mood,$user['USER_ID']),__LINE__,__FILE__);

	$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";
	
	$smarty_data = array(
		"stylesheet" => $stylesheet,
	);

	return array(
		"header" => array (
			"title" => "",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => "",
		),
		"template" => "dochangemood",
		"data" => & $smarty_data,
		"footer" => false,
		"location" => "",
	);

}

?>
