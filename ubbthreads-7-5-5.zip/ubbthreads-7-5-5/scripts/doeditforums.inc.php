<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;


function page_doeditforums_gpc () {
	return array(
		"input" => array(
			"forum" => array("forum","post","int"),
			"email" => array("email","post",array("immediate","none","newtopic"),"none"),
		),
		"wordlets" => array(),
		"user_fields" => "",
		"regonly" => 1,
	);
} // end page_cfrm_gpc


function page_doeditforums_run () {

	global $in,$user,$ubbt_lang,$config,$forumvisit,$visit,$dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	foreach($forum as $forum_id => $value) {

		$forum_id = addslashes($forum_id);
		if ($value == 0) {
			$query = "
				delete from	{$config['TABLE_PREFIX']}WATCH_LISTS
				where	USER_ID = ?
				and	WATCH_ID = ?
				and	WATCH_TYPE = 'f'
			";
			$dbh->do_placeholder_query($query,array($user['USER_ID'],$forum_id),__LINE__,__FILE__);

		} else {
			$watch_lists['f'][$forum_id] = $forum_id;
			$query = "
				select 	count(*)
				from	{$config['TABLE_PREFIX']}WATCH_LISTS
				where	USER_ID = ?
				and	WATCH_ID = ?
				and	WATCH_TYPE = 'f'
			";
			$sth = $dbh->do_placeholder_query($query,array($user['USER_ID'],$forum_id),__LINE__,__FILE__);
			list($check) = $dbh->fetch_array($sth);

			if (!$check) {
				$query = "
					insert into {$config['TABLE_PREFIX']}WATCH_LISTS
					(USER_ID,WATCH_ID,WATCH_TYPE)
					values
					( ? , ? , 'f')
				";
				$dbh->do_placeholder_query($query,array($user['USER_ID'],$forum_id),__LINE__,__FILE__);
			} // end if

		} // end if
	} // end foreach

	foreach($email as $forum_id => $value) {

		$immediate = 0;
		switch ($value) {
			case "immediate":
				$immediate = 1;
				break;
			case "newtopic":
				$immediate = 2;
				break;
			default:
				$immediate = 0;
				break;
		}

		$query_vars = array($immediate,$user['USER_ID'],$forum_id);
		$query = "
			update 	{$config['TABLE_PREFIX']}WATCH_LISTS
			set			WATCH_NOTIFY_IMMEDIATE = ?
			where		USER_ID = ?
			and			WATCH_ID = ?
			and			WATCH_TYPE = 'f'
		";
		$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	} // end foreach

	$_SESSION['watch_lists'] = serialize($watch_lists);

	// ---------------------
	// Return to the profile
	return array(
		"data" => $data,
		"header" => "",
		"template" => "",
		"footer" => false,
		"location" => "myhome&tab=forums",
	);

}

?>
