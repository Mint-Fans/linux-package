<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;


function page_doedittopics_gpc () {
	return array(
		"input" => array(
			"topic" => array("topic","post","int"),
			"email" => array("email","post","alpha"),
		),
		"wordlets" => array(),
		"user_fields" => "",
		"regonly" => 1,
	);
} // end page_cfrm_gpc


function page_doedittopics_run () {
	
	global $in,$user,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$var_start,$var_eq,$var_sep,$var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars
	
	$watch_lists = unserialize($_SESSION['watch_lists']);

	foreach($topic as $topic_id => $value) {
		$query = "
			delete from	{$config['TABLE_PREFIX']}WATCH_LISTS
			where	USER_ID = ?
			and	WATCH_ID = ?
			and	WATCH_TYPE = 't'
		";
		$dbh->do_placeholder_query($query,array($user['USER_ID'],$topic_id),__LINE__,__FILE__);
		unset($watch_lists['t'][$topic_id]);

	} // end foreach

	$_SESSION['watch_lists'] = serialize($watch_lists);
	
	foreach($email as $topic_id => $value) {

		$immediate = 0;
		
		if ($value == "immediate") {
			$immediate = 1;
		} // end if
		
		$query_vars = array($immediate,$user['USER_ID'],$topic_id);
		$query = "
			update 	{$config['TABLE_PREFIX']}WATCH_LISTS
			set	WATCH_NOTIFY_IMMEDIATE = ?
			where	USER_ID = ?
			and	WATCH_ID = ?
			and	WATCH_TYPE = 't'
		";
		$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	} // end foreach


	// ---------------------
	// Return to the profile
	return array(
		"data" => $data,
		"header" => "",
		"template" => "",
		"footer" => false,
		"location" => "myhome&tab=topics",
	);

}

?>
