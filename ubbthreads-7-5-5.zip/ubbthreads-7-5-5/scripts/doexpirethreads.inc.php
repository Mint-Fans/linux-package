<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_doexpirethreads_gpc () {
	return array(
		"input" => array(
			"Keyword"=> array("Keyword","post","int"),
			"Number"=> array("Number","post","int"),
			"view"	=> array("view","post","alpha"),
			"what"	=> array("what","post","alpha"),
			"sb"	=> array("sb","post","int"),
			"o"	=> array("o","post","int"),
			"fpart"	=> array("fpart","post","alphanum"),
		),
		"wordlets" => array("admin/generic","generic"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 1,
	);
} // end page_doexpirethreads_gpc

function page_doexpirethreads_run () {

	global $user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$var_start,$var_eq,$var_sep,$var_extra,$userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$html = new html;
	
	$query = "
		SELECT FORUM_ID,TOPIC_SUBJECT
		FROM {$config['TABLE_PREFIX']}TOPICS
		WHERE TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);
	list($Keyword,$Subject) = $dbh->fetch_array($sth);

	if (!$userob->check_access("forum","DELETE_TOPICS",$Keyword)) exit;
	
	$query = "
		select FORUM_TITLE,CATEGORY_ID,FORUM_PARENT,FORUM_TOPICS,FORUM_POSTS
		from {$config['TABLE_PREFIX']}FORUMS
		where FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($Keyword),__LINE__,__FILE__);
	list($Title,$cat_id,$parent_id,$topics,$posts) = $dbh->fetch_array($sth);
	
	$totalexpired = 0;
	$totalna = 0;

	// ---------------------------------------------------------------------
	// Find out if there are any files to delete and if the post is approved
	$query = "
	SELECT POST_ID,POST_SUBJECT
	FROM  {$config['TABLE_PREFIX']}POSTS
	WHERE TOPIC_ID = ?
	";
	$sti = $dbh -> do_placeholder_query($query,array($Number),__LINE__,__FILE__);
	while ( list($checkee,$subject) = $dbh -> fetch_array($sti)) {
		$query = "
		SELECT FILE_NAME,FILE_DIR
		FROM {$config['TABLE_PREFIX']}FILES
		WHERE POST_ID = ?
		";
		$stk = $dbh -> do_placeholder_query($query,array($checkee),__LINE__,__FILE__);
		while(list($filename,$filedir) = $dbh -> fetch_array($stk)) {
			if (!$filedir) {
				@unlink("{$config['ATTACHMENTS_PATH']}/$filename");
			} else {
				@unlink("{$config['FULL_PATH']}/gallery/$filedir/full/$filename");
				@unlink("{$config['FULL_PATH']}/gallery/$filedir/medium/$filename");
				@unlink("{$config['FULL_PATH']}/gallery/$filedir/thumbs/$filename");
			} // end if

		}
		$query = "
		SELECT POLL_ID
		FROM {$config['TABLE_PREFIX']}POLL_DATA
		WHERE POST_ID = ?
		";
		$stk = $dbh -> do_placeholder_query($query,array($checkee),__LINE__,__FILE__);
		while(list($Poll) = $dbh -> fetch_array($stk)) {

			$query = "
			DELETE FROM {$config['TABLE_PREFIX']}POLL_DATA
			WHERE  POLL_ID = ?
			";
			$dbh -> do_placeholder_query($query,array($Poll),__LINE__,__FILE__);
			$query = "
			DELETE FROM {$config['TABLE_PREFIX']}POLL_OPTIONS
			WHERE  POLL_ID = ?
			";
			$dbh -> do_placeholder_query($query,array($Poll),__LINE__,__FILE__);
			$query = "
			DELETE FROM {$config['TABLE_PREFIX']}POLL_VOTES
			WHERE  POLL_ID = ?
			";
			$dbh -> do_placeholder_query($query,array($Poll),__LINE__,__FILE__);
		}

		if ($Approved == "0") {
			$totalna++;
		}
		$dbh -> finish_sth($sti);
	}

	$query = "
	SELECT COUNT(*) FROM {$config['TABLE_PREFIX']}POSTS
	WHERE  TOPIC_ID = ?
	";
	$stm = $dbh -> do_placeholder_query($query,array($Number),__LINE__,__FILE__);
	list($rc) = $dbh -> fetch_array($stm);
	$dbh -> finish_sth($stm);

	$query = "
	DELETE FROM {$config['TABLE_PREFIX']}WATCH_LISTS
	WHERE  WATCH_ID = ?
	AND		 WATCH_TYPE = 't'
	";
	$dbh -> do_placeholder_query($query,array($Number),__LINE__,__FILE__);

	$query = "
	DELETE FROM {$config['TABLE_PREFIX']}ANNOUNCEMENTS
	WHERE TOPIC_ID = ?
	";
	$dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);

	$query = "
	DELETE FROM {$config['TABLE_PREFIX']}POSTS
	WHERE TOPIC_ID = ?
	";
	$dbh -> do_placeholder_query($query,array($Number),__LINE__,__FILE__);
	$totalexpired = $totalexpired + ($rc - $totalna);
	
	$query = "
		delete from {$config['TABLE_PREFIX']}TOPICS
		where TOPIC_ID = ?
	";
	$dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);


	// --------------------------------------------------------------
	// Need to find out what the new last post is for this board
	$query = "
	SELECT TOPIC_LAST_POSTER_ID,TOPIC_ID,TOPIC_LAST_POST_ID,TOPIC_LAST_REPLY_TIME,TOPIC_LAST_POSTER_NAME
	FROM {$config['TABLE_PREFIX']}TOPICS
	WHERE FORUM_ID = ?
	AND   TOPIC_IS_APPROVED = '1'
	ORDER BY TOPIC_LAST_REPLY_TIME DESC
	LIMIT 1
	";
	$sth = $dbh -> do_placeholder_query($query,array($Keyword),__LINE__,__FILE__);
	list ($lastuser,$lastmain,$lastnumber,$lasttime,$lastname) = $dbh -> fetch_array($sth);
	
	$query = "
		select POST_SUBJECT,POST_ICON
		from {$config['TABLE_PREFIX']}POSTS
		where POST_ID = '$lastnumber'
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	list($lastsubject,$lasticon) = $dbh->fetch_array($sth);

	// ----------------------------------------------
	// Now we update the board to set the total posts
	if (!$lastuser) $lastuser = 0;
	if (!$lastnumber) $lastnumber =0;
	if (!$lastmain) $lastmain = 0;
	if (!$lasttime) $lasttime =0;
	
	$topics = $topics - 1;
	$posts = $posts - $totalexpired;

	if ($topics < 0) $topics = 0;
	if ($posts < 0) $posts = 0;

	rebuild_forum_data($Keyword);

	$extra_bread = "";
	if ($parent_id) {
		$link = make_ubb_url("ubb=postlist&Board=$parent_id", $parent_title, false);
		$extra_bread = <<<EOF
 <a href="{$link}">{$parent_title}</a>
 &raquo;
EOF;
	} // end if

	$query = "
		delete from {$config['TABLE_PREFIX']}CALENDAR_EVENTS
		where TOPIC_ID = ?
	";
	$dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);

        // Log this action
        admin_log("DELETE_THREAD", "<a href='" . make_ubb_url("ubb=postlist&Board=$Keyword", $Title, false) . "' target='_blank'>$Title</a> : $Subject");

        rebuild_islands(0);  
	
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$html->send_redirect(
		array(
			"redirect" => "postlist&Board=$Keyword&",
			"heading" => $ubbt_lang['COM_HEAD'],
			"body" => $ubbt_lang['COM_BODY'],
			"returnlink" => "",
			"Board" => $Keyword,
			"Category" => $cat_id,
			"parent_forum" => $parent_id,
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
			,
		)
	);

}
?>
