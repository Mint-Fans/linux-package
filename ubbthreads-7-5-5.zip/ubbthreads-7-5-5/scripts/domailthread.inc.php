<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_domailthread_gpc () {
	return array(
		"input" => array(
			"Board" => array("Board","post","int"),
			"what" => array("what","post","alpha"),
			"Number" => array("Number","both","int"),
			"fpart" => array("fpart","post","alphanum"),
			"realname" => array("realname","post",""),
			"realemail" => array("realemail","post",""),
			"Email" => array("Email","post",""),
			"Notes" => array("Notes","post",""),
			"sendType" => array("sendType","post",""),
			"PM" => array("PM","get",""),
		),
		"wordlets" => array("domailthread"),
		"user_fields" => "t2.USER_REAL_EMAIL",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_domailthread_gpc

function page_domailthread_run () {
	global $userob,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$var_start,$var_eq,$var_sep,$var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$html = new html;

	if (!$userob->check_access("site","MAIL_POST")) {
		$html -> not_right("DISABLED");
	}

	// linebreak Notes
	$Notes = nl2br($Notes);

	// Must be mailing a thread
	if (!$PM) {

		// -------------------------------------------------------------
		// If we didn't get a board or number then we give them an error
		if (!$Board) {
			$html -> not_right($ubbt_lang['NO_AUTH']);
		}

		// Get the board id from the post # and topic id too and also, the 1st post id :)
		$query = "
			SELECT t.FORUM_ID, t.TOPIC_ID, t.POST_ID
				FROM {$config['TABLE_PREFIX']}TOPICS t,
						 {$config['TABLE_PREFIX']}POSTS p
			WHERE p.POST_ID = ?
				AND t.TOPIC_ID = p.TOPIC_ID
		";
		$sth = $dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);
		list($Board,$TopicID,$FirstPost) = $dbh->fetch_array($sth);

		$query = "
			SELECT FORUM_TITLE, CATEGORY_ID, FORUM_PARENT, FORUM_IS_GALLERY
				FROM {$config['TABLE_PREFIX']}FORUMS
			WHERE FORUM_ID = ?
				AND FORUM_IS_ACTIVE = 1
		";
		$sth = $dbh -> do_placeholder_query($query,array($Board),__LINE__,__FILE__);
		list ($title,$CatNumber,$parent_id,$is_gallery) = $dbh -> fetch_array($sth);

		// ---------------------------------------------------------------
		// If they are a normal user then they can only see approved posts
		$ismod = "no"; // By default they are not a moderator

		$Viewable = "AND p.POST_IS_APPROVED = 1";
		if ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator") {
			$Viewable = "";
		}
		if ($user['USER_MEMBERSHIP_LEVEL'] == "GlobalModerator") {
			$Viewable = "";
		}

		if ($user['USER_MEMBERSHIP_LEVEL'] == "Moderator") {
			// ---------------------------------
			// Check if they moderate this board
			$query = "
			SELECT FORUM_ID
				FROM {$config['TABLE_PREFIX']}MODERATORS
			WHERE  USER_ID = ?
				AND  FORUM_ID = ?
			";
			$sth = $dbh -> do_placeholder_query($query,array($user['USER_ID'],$Board),__LINE__,__FILE__);
			list($check) = $dbh -> fetch_array($sth);

			if ($check) {
				$Viewable = "";
				$ismod    = "yes";
			}
		}

		if (!$userob->check_access("forum","READ_TOPICS",$Board) ){
			$html -> not_right($ubbt_lang['BAD_GROUP']);
		}

		// Grab the posts and limit if only one post. Also force to 1st post, if they want entire thread
		$Limit = "";
		if ($sendType == 'one') {
			$Limit = "LIMIT 1";
		} elseif ($sendType == 'thread') {
			$Number = $FirstPost;
		}

		// Since POST_ID will be ascending in time, we can just get all after
		$query = "
			SELECT p.POST_ID, p.POST_SUBJECT, p.POST_BODY, p.POST_DEFAULT_BODY, p.POST_HAS_FILE, u.USER_DISPLAY_NAME, p.POST_POSTED_TIME
				FROM {$config['TABLE_PREFIX']}POSTS p,
						 {$config['TABLE_PREFIX']}USERS u,
						 {$config['TABLE_PREFIX']}USER_PROFILE up
			WHERE  p.POST_ID >= ?
			$Viewable
				AND p.USER_ID = u.USER_ID
				AND p.USER_ID = up.USER_ID
				AND p.TOPIC_ID = {$TopicID}
			ORDER BY p.POST_ID
			$Limit
		";
		$sth = $dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);

		// Swap board name, with real one, if they want
		$echoname = $user['USER_DISPLAY_NAME'];
		if ($realname) {
			$echoname = $realname;
		}

		// Format this up and send it
		$mailer = new mailer();
		$mailer->set_language($user['USER_LANGUAGE']);
		$mailer->set_salute('EMAIL_SALUTE_GEN');
		$mailer->set_subject('DMT_SUBJECT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
		$mailer->add_content('DMT_CONTENT', array('USERNAME' => $echoname,'BOARD_TITLE' => $config['COMMUNITY_TITLE'],'NOTES' => $Notes));
		$mailer->add_content('DMT_CONTENT1', array('POST_URL' => make_ubb_url("ubb=showflat&Number=$Number#Post$Number", '', true, true)),true);
		$mailer->add_content('DMT_CONTENT2');
	} else {
		// -------------------------------------------------------------------
		// First check if the user is a participant. If not *buzzer* no can do
		$sth = $dbh->do_query("SELECT USER_ID FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS WHERE TOPIC_ID={$Number} AND USER_ID={$user['USER_ID']}");
		list($ok) = $dbh->fetch_array($sth);
		if (!$ok) {
			$html -> not_right($ubbt_lang['NOT_YOURS']);
		}

		// -------------------------------------------------
		// Get the message(s) in this post from the database
		$query = "
			SELECT	p.POST_ID, t.TOPIC_SUBJECT, p.POST_BODY, p.POST_DEFAULT_BODY, 0, u.USER_DISPLAY_NAME, p.POST_TIME
			FROM	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS p,
						{$config['TABLE_PREFIX']}USERS u,
						{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS t
			WHERE	p.TOPIC_ID = ?
				AND	p.TOPIC_ID = t.TOPIC_ID
				AND	p.USER_ID = u.USER_ID
			ORDER BY p.POST_TIME
		";
		$sth = $dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);

		// Format this up and send it
		$mailer = new mailer();
		$mailer->set_language($user['USER_LANGUAGE']);
		$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $echoname));
		$mailer->set_subject('DMP_SUBJECT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
		$mailer->add_content('DMP_CONTENT');
	}
	// ----------------------------
	// Start of common post/pm loop
	$numposts = $dbh->total_rows($sth);
	for ($i=0; $i < $numposts; $i++) {
		list($postid, $tsubject, $hbody, $tbody, $files, $username, $rawtime) = $dbh -> fetch_array($sth);

		// Attachment time, baby! (Need this especially for gallery forums)
		$attacments = array();
		if ($files) {
			$query = "
				SELECT FILE_ID,FILE_NAME,FILE_SIZE,FILE_TYPE,FILE_ORIGINAL_NAME,FILE_DESCRIPTION
					FROM {$config['TABLE_PREFIX']}FILES
				WHERE POST_ID = ?
			";
			$stx = $dbh->do_placeholder_query($query,array($postid),__LINE__,__FILE__);

			$img_array = array("gif","png","jpg");
			$j = 0;
			while(list($file_id,$file_name,$size,$ext,$original,$caption) = $dbh->fetch_array($stx)) {
				if ($is_gallery) {
					$attachments[$j]['inline'] = true;
					$attachments[$j]['url'] = make_ubb_url("ubb=showimage&id=$file_id&type=m", "", true);
				} else {
					$attachments[$j]['url'] = "{$config['ATTACHMENTS_URL']}/$file_name";
					if ($size < $config['INLINE_IMAGE'] && in_array($ext,$img_array)) {
						$attachments[$j]['inline'] = true;
					} else {
						$attachments[$j]['inline'] = false;
					}
				}
				$attachments[$j]['caption'] = $caption;
				$attachments[$j]['original'] = $original;
				$j++;
			}
		}
		$posttime = array($rawtime, $user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT']);
		$mailer->add_post($username, $tsubject, $posttime, $hbody, $tbody, $attachments);
	}
	// ---- End of post loop

	if ($PM) {
		$mailer->ubbt_mail($user['USER_REAL_EMAIL']);
		$Email = $user['USER_REAL_EMAIL'];
	} else {
		$mailer->ubbt_mail($Email,array('email' => $user['USER_REAL_EMAIL'], 'username' => $echoname));
	}

	// ------------
	// Log it to DB
	admin_log("MAIL_THREAD",$html->substitute($ubbt_lang['MAIL_LOG'], array(
		'POST_URL' => make_ubb_url("ubb=showflat&Number=$Number#Post$Number", $tsubject, false),
		'SUBJECT' => $tsubject,
		'USER' => $Email)));

	// --------------------------------------
	// Give confirmation and return to thread
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	if ($PM) {
		$returnurl = "<a href=\"" . make_ubb_url("ubb=viewmessage&message=$Number&gonew=0", "", false) . "\">{$ubbt_lang['FORUM_RETURN']}</a>";
		$redirect = "viewmessage&message=$Number&gonew=0";
	} else {
		$returnurl = "<a href=\"" . make_ubb_url("ubb=$what&Number=$Number&fpart=$fpart", "", false) . "\">{$ubbt_lang['FORUM_RETURN']}</a>";
		$redirect = "$what&Number=$Number&fpart=$fpart";
	}
	$html->send_redirect(
		array(
			"redirect" => $redirect,
			"heading" => $ubbt_lang['EMAIL_SENT'],
			"body" => "{$ubbt_lang['EMAIL_CONFIRM']} $Email.  {$ubbt_lang['RET_FORUM']}",
			"returnlink" => $returnurl,
			"Board" => $Board,
			"Category" => $CatNumber,
			"parent_forum" => $parent_id,
			"breadcrumb" => "<a href=\"{$cfrm}\">{$ubbt_lang['FORUM_TEXT']}</a>",
		)
	);

}

?>
