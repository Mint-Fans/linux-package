<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	You may not distribute "hacks" for UBB without approval from
//	Mindraven
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_domovepost_gpc () {
	return array(
		"input" => array(
			"view" => array("view","post","alpha"),
			"sb" => array("sb","post","int"),
			"o" => array("o","post","int"),
			"Keyword"	=> array("Keyword","post","int"),
			"oldboard" => array("oldboard","post","int"),
			"number" => array("number","post","int"),
			"type" => array("type","post","alpha"),
			"merge" => array("merge","post","int"),
			"sendpm" => array("sendpm","post","int"),
			"reason" => array("reason","post",""),
		),
		"wordlets" => array("domovepost"),
		"user_fields" => "USER_TOPIC_VIEW_TYPE",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 1,
	);
} // end page_domovepost_gpc

function page_domovepost_run () {

	global $user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$var_start,$var_eq,$var_sep,$var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$html = new html;

	// -------------------------------------------------
	// If we didn't get a keyword, then we don't move it
	if ($type == "move") {
		if (!$Keyword) {
			$html -> not_right("{$ubbt_lang['NO_FORUM']}");
		} // end if
		if ($Keyword == "category") {
			$html -> not_right("{$ubbt_lang['NO_CAT']}");
		} // end if
	} // end if
	
	// Right up front, save the pre moved/merged post info, if a PM is required
	if ($sendpm) {
		$query = "
			SELECT POST_SUBJECT,USER_ID
			FROM {$config['TABLE_PREFIX']}POSTS
			WHERE  POST_ID = ?
		";
		$sth = $dbh -> do_placeholder_query($query,array($number),__LINE__,__FILE__);
		list ($pmSubj,$pmWho) = $dbh -> fetch_array($sth);
	}
	
	$merge_topic = "";
	if ($type == "merge") {
		$query = "
			select t2.FORUM_ID,t1.TOPIC_ID
			from {$config['TABLE_PREFIX']}POSTS as t1,
			{$config['TABLE_PREFIX']}TOPICS as t2
			where t1.TOPIC_ID = t2.TOPIC_ID
			and t1.POST_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($merge),__LINE__,__FILE__);
		list($Keyword,$merge_topic) = $dbh->fetch_array($sth);
		if (!$Keyword) {
			$html->not_right($ubbt_lang['NOMERGE']);
		} // end if
	} // end if
	
	$query = "
		select FORUM_TITLE,CATEGORY_ID,FORUM_PARENT
		from {$config['TABLE_PREFIX']}FORUMS
		where FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($Keyword),__LINE__,__FILE__);
	list($Title,$cat_id,$parent_id) = $dbh->fetch_array($sth);

	// ------------------------------------------------------------------
	// Find out the current Main number for this post and current subject
	$query = "
		SELECT t3.FORUM_ID,t3.FORUM_TITLE,t1.TOPIC_ID,t1.POST_SUBJECT,t1.POST_POSTED_TIME,t1.POST_BODY,t1.USER_ID,t1.POST_POSTED_TIME,t2.TOPIC_HAS_POLL,t2.TOPIC_HAS_FILE,t1.POST_ICON,t1.POST_IS_TOPIC
		FROM   {$config['TABLE_PREFIX']}POSTS as t1,
		{$config['TABLE_PREFIX']}TOPICS as t2,
		{$config['TABLE_PREFIX']}FORUMS as t3
		WHERE  t1.POST_ID = ?
		AND t1.TOPIC_ID = t2.TOPIC_ID
		AND t2.FORUM_ID = t3.FORUM_ID
	";
	$sth = $dbh -> do_placeholder_query($query,array($number),__LINE__,__FILE__);
	list($old_board,$old_title,$old_topic_id,$subject,$lastposted,$post_body,$posterid,$post_date,$has_poll,$has_file,$post_icon,$post_is_topic) = $dbh -> fetch_array($sth);


	// ---------------------------------------------------------------------
	// If there are any unapproved posts in this thread then we can't move it
	$query = "
		SELECT POST_IS_APPROVED,POST_POSTED_TIME
		FROM   {$config['TABLE_PREFIX']}POSTS
		WHERE  TOPIC_ID = ?
		ORDER BY POST_ID
	";
	$sth = $dbh -> do_placeholder_query($query,array($old_topic_id),__LINE__,__FILE__);
	$posted_time = 0;
	while ( list($check,$time) = $dbh -> fetch_array($sth)) {
		$posted_time = $time;
		if ($check == "0") {
			$html -> not_right("{$ubbt_lang['UNAPPROVED']}");
		}
	}

	if ($type == "move") {
		// Need to make a new topic in the target forum
		$subject = preg_replace("/^Re:/","",$subject);	

		$query_vars = array($Keyword,$number,$posterid,$subject,$post_date,1,"",0,$posted_time,$has_file,$has_poll,$post_icon);
		$query = "
			insert into {$config['TABLE_PREFIX']}TOPICS
			(FORUM_ID,POST_ID,USER_ID,TOPIC_SUBJECT,TOPIC_CREATED_TIME,TOPIC_IS_APPROVED,TOPIC_STATUS,TOPIC_IS_STICKY,TOPIC_LAST_REPLY_TIME,TOPIC_HAS_FILE,TOPIC_HAS_POLL,TOPIC_ICON)
			values
			( ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? )
		";
		$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

		// Get the topic id
		$query = "
			SELECT last_insert_id()
		";
		$sth = $dbh -> do_query($query,__LINE__,__FILE__);
		list ($new_topic_id) = $dbh -> fetch_array($sth);

		$query_vars = array($new_topic_id,$subject,0,0,1,$number);
		$query = "
			UPDATE {$config['TABLE_PREFIX']}POSTS
			SET    TOPIC_ID   = ? ,
			POST_SUBJECT= ? ,
			POST_PARENT_ID = ? ,
			POST_PARENT_USER_ID = ? ,
			POST_IS_TOPIC  = ?
			WHERE  POST_ID = ?
		";
		$dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	
		// ------------------------------------------------
		// Now we need to change all of the replies as well
		update_replies($number,$number,$new_topic_id);
	
		// Update the old calendar event
		$query = "
			update {$config['TABLE_PREFIX']}CALENDAR_EVENTS
			set TOPIC_ID = ?
			where TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query,array($new_topic_id,$old_topic_id),__LINE__,__FILE__);

		rebuild_topic_data($new_topic_id);

	} // end if

	if ($type == "merge") {
		$query = "
			update {$config['TABLE_PREFIX']}POSTS
			set TOPIC_ID = ?,
			POST_PARENT_ID = ?
			where POST_ID = ?
		";
		$dbh->do_placeholder_query($query,array($merge_topic,$merge,$number),__LINE__,__FILE__);
		update_replies($number,$number,$merge_topic);
		rebuild_topic_data($merge_topic);
	} // end if

	// If this post was the original topic, then we need to delete it
	if ($post_is_topic) {
		$query = "
			delete from {$config['TABLE_PREFIX']}TOPICS
			where TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query,array($old_topic_id),__LINE__,__FILE__);
	} // end if

	rebuild_topic_data($old_topic_id);

	rebuild_forum_data($oldboard);
	rebuild_forum_data($Keyword);

	$mode = "show{$user['USER_TOPIC_VIEW_TYPE']}";	
	// Check if a PM should be sent to the Poster
	if (($sendpm) && ($user['USER_ID'] != $pmWho)) {
		$Subj = ($type == "merge") ? $ubbt_lang['PM_MERGE_SUBJ'] : $ubbt_lang['PM_MOVE_SUBJ'];
 
		if ($reason) {
			$reason = nl2br($html->substitute($ubbt_lang['PM_REASON'], array('REASON' => $reason)));
		}
		$pmMsg = $html->substitute($ubbt_lang['PM_BODY'], array(
			'SUBJECT' => $pmSubj,
			'NEW_ADDY' => make_ubb_url("ubb=showflat&Number=$number#Post$number", $subject, false),
			'IF_REASON' => $reason));
		$html -> send_message ($user['USER_ID'],$pmWho,$Subj,$pmMsg);
	}

	// Setup info for admin log
	$logger = ($type == "merge") ? 'POST_MERGED' : 'POST_MOVED';
	admin_log($logger,"<a href='" . make_ubb_url("ubb=postlist&Board=$old_board", $old_title, false) . "' target='_blank'>$old_title</a> -> <a href='" . make_ubb_url("ubb=showflat&Number=$number#Post$number", $subject, false) . "' target='_blank'>$subject</a>");
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$html->send_redirect(
		array(
			"redirect" => "{$mode}&Number=$number",
			"heading" => $ubbt_lang[$logger],
			"body" => $ubbt_lang['POST_BODY'],
			"returnlink" => "",
			"Board" => $Board,
			"Category" => $cat_id,
			"parent_forum" => $parent_id,
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
			,
		)
	);

}

// ------------------------------------------------------------------
// function for updating any replies in this branch
function update_replies($number="",$moved="",$newmain="") {

	global $dbh, $config;

	// --------------------------------------------------
	// Query to see if there are any replies to this post
	$query = "
		SELECT POST_ID
		FROM   {$config['TABLE_PREFIX']}POSTS
		WHERE  POST_PARENT_ID = ?
	";
	$sth = $dbh -> do_placeholder_query($query,array($number),__LINE__,__FILE__);
	$followups = $dbh -> total_rows($sth);
	if ($followups) {
		for ( $x=0; $x<$followups; $x++) {
			list ($postcheck) = $dbh -> fetch_array($sth);
			if ($postcheck) {
				 update_replies($postcheck,$moved,$newmain);
			}
			if (!preg_match("#$number#",$moved)) {
				$query = "
					UPDATE {$config['TABLE_PREFIX']}POSTS
					SET    TOPIC_ID = ?
					WHERE  POST_ID = ?
				";
				$dbh -> do_placeholder_query($query,array($newmain,$number),__LINE__,__FILE__);
			}
		}
	}
	else {
		if (!preg_match("#$number#",$moved)) {
			$query = "
				UPDATE {$config['TABLE_PREFIX']}POSTS
				SET    TOPIC_ID = ?
				WHERE  POST_ID = ?
			";
			$dbh -> do_placeholder_query($query,array($newmain,$number),__LINE__,__FILE__);
		}
	}

	return;

}

?>
