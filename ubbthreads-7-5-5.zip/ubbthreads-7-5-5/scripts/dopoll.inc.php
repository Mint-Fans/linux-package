<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_dopoll_gpc () {
	return array(
		"input" => array(
			"Poll" => array("Poll","post","int"),
			"Board" => array("Board","post","alphanum"),
			"Number" => array("Number","post","int"),
			"page" => array("page","post","int"),
			"what" => array("what","post","alpha"),
			"fpart" => array("fpart","post","alphanum"),
		),
		"wordlets" => array("dopoll"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_dopoll_gpc

function page_dopoll_run () {

	global $user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html,$userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$voted = "";

	// ------------------------------
	// Make sure this poll isn't over
	$query = "
		SELECT	POLL_STOP_TIME,POLL_BODY,POLL_TYPE
		FROM	{$config['TABLE_PREFIX']}POLL_DATA
		WHERE	POLL_ID = ?
	";
	$sth = $dbh -> do_placeholder_query($query,array($Poll),__LINE__,__FILE__);
	list($pstop,$body,$type) = $dbh -> fetch_array($sth);
	$currtime = $html -> get_date();
	if ($pstop && ($currtime > $pstop)) {
		$html -> not_right($ubbt_lang['STOPPED']);
	}

	// ------------------------
	// Predefine some variables
	if (!isset($PHPSESSID)) {
		$PHPSESSID = "";
	}
	
	$i = 0;

	// -----------------------------------------------------------------------------
	// If we are only allowed registered users to vote, then we need to authenticate
	if (!$userob->check_access("site","POLL_VOTE")) {
		$html -> not_right($ubbt_lang['POLL_REGED']);
	}
	$IP = find_environmental('REMOTE_ADDR');

	// --------------------------------------------------------------------------
	// If we allow all to vote, we check if the IP has voted, otherwise we check
	// for the username
	if (!$userob->is_logged_in) {
		$checker = $IP;
	}
	else {
		$checker = $user['USER_ID'];
	}

	$query = "
	SELECT VOTES_USER_ID_IP
	FROM   {$config['TABLE_PREFIX']}POLL_VOTES
	WHERE  VOTES_USER_ID_IP = ?
	AND    POLL_ID = ?
	";
	$sth = $dbh ->  do_placeholder_query($query,array($checker,$Poll),__LINE__,__FILE__);
	list($check) = $dbh -> fetch_array($sth);
	$dbh -> finish_sth($sth);
	if ($check) {
		if (!$userob->is_logged_in) {
			$html -> not_right($ubbt_lang['POLL_IP']);
		}
		else {
			$html -> not_right($ubbt_lang['POLL_USER']);
		}
	}
	

	// ----------------------------------
	// Grab the options for this question
	$query = "
		SELECT OPTION_ID,OPTION_BODY
		FROM   {$config['TABLE_PREFIX']}POLL_OPTIONS
		WHERE  POLL_ID = ?
	";
	$stj = $dbh -> do_placeholder_query($query,array($Poll),__LINE__,__FILE__);
	$x = 1;
	$totalchecks = 0;
	while(list($optionnum,$option) = $dbh -> fetch_array($stj)) {
		if ($type == "one") {
			$thisoption = "option";
		}
		else {
			$thisoption = "option$x";
		}
		$didvote = get_input("$thisoption","post");
		if ($didvote) {

			// Only 1 vote on radio buttons
			if ($type == "one" && $totalchecks) {
				continue;
			}
				
			$query_vars[$i] = array($didvote,$checker,$Poll);
			$queryarray[$i] = "
				INSERT INTO {$config['TABLE_PREFIX']}POLL_VOTES
				(OPTION_ID,VOTES_USER_ID_IP,POLL_ID)
				VALUES
				(  ? , ? , ? )
			";
			$i++;
			$totalchecks++;
			if ($type == "one") { continue; }
		}
		if ($type != "one" && $type != "many") {
			if ($totalchecks > $type) {
				$html -> not_right("{$ubbt_lang['TOO_MANY']}");
			}
		}
		$x++;
	}


	if (!$i) {
		$html -> not_right($ubbt_lang['NO_VOTE']);
	}
	for ($i=0;$i<sizeof($queryarray);$i++) {
		$dbh -> do_placeholder_query($queryarray[$i],$query_vars[$i],__LINE__,__FILE__);
	}

	return array(
		"header" => "",
		"template" => "",
		"data" => "",
		"footer" => false,
		"location" => "{$what}&Board=$Board&Number=$Number&page=$page&fpart=$fpart",
	);

}

?>
