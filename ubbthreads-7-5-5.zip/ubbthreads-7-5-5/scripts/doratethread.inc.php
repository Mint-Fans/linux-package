<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_doratethread_gpc () {
	return array(
		"input" => array(
			"Ratee" => array("Ratee","post","int"),
			"Board" => array("Board","post","int"),
			"what" => array("what","post","alpha"),
			"Number" => array("Number","post","int"),
			"Main" => array("Main","post","int"),
			"rating" => array("rating","post","int"),
		),
		"wordlets" => array("doratethread"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_doratethread_gpc

function page_doratethread_run () {

	global $user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// -------------------------------
	// Make sure it is between 1 and 5
	if ( ($rating < 1) || ($rating > 5) || (!is_int($rating)) ) {
		$html -> not_right($ubbt_lang['INVALID_RATING']);
	}
	
	$query = "
		select FORUM_TITLE,CATEGORY_ID,FORUM_PARENT
		from {$config['TABLE_PREFIX']}FORUMS
		where FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($Board),__LINE__,__FILE__);
	list($Title,$cat_id,$parent_id) = $dbh->fetch_array($sth);

	// ---------------------------------------------------
	// Let's find out if they have rated this topic already
	$query_vars = array($Main,$user['USER_ID']);
	$query = "
	SELECT RATING_TARGET
	FROM   {$config['TABLE_PREFIX']}RATINGS
	WHERE  RATING_TARGET = ?
	AND    RATING_RATER    = ?
	AND    RATING_TYPE    = 't'
	";
	$sth = $dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	list($check) = $dbh -> fetch_array($sth);

	if (!$check) {

		// ------------------------------
		// Grab the current rating/rates
		$query = "
			select sum(RATING_VALUE) as RATING_SUM, count(*) as RATING_COUNT
			from {$config['TABLE_PREFIX']}RATINGS
			where RATING_TARGET = ?
			and RATING_TYPE = 't'
		";
		$sth = $dbh->do_placeholder_query($query,array($Main),__LINE__,__FILE__);
		list($crating,$crates) = $dbh->fetch_array($sth);
		$crating = $crating + $rating;
		$crates  = $crates + 1;
		$stars = $crating / $crates;
		$stars = intval($stars);

		// ------------------------------------------------------
		// Insert the details into the database
		$query_vars = array($Main,$user['USER_ID'],$rating,'t');
		$query = "
		INSERT INTO {$config['TABLE_PREFIX']}RATINGS
		(RATING_TARGET,RATING_RATER,RATING_VALUE,RATING_TYPE)
		VALUES ( ? , ? , ? , ? )
		";
		$dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
		
		$query = "
		UPDATE {$config['TABLE_PREFIX']}TOPICS
		SET    TOPIC_RATING = ? ,
		TOPIC_TOTAL_RATES = TOPIC_TOTAL_RATES + 1
		where TOPIC_ID = ?
		";
		$dbh -> do_placeholder_query($query,array($stars,$Main),__LINE__,__FILE__);
		
	}
	else {
		// ---------------------
		// Already rated
		$html -> not_right($ubbt_lang['NOMORERATE']);
	}
	
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	
	$html->send_redirect(
		array(
			"redirect" => "$what&Number=$Number",
			"heading" => $ubbt_lang['THANKS'],
			"body" => "{$ubbt_lang['RATED']} {$ubbt_lang['RET_TOPIC']}",
			"returnlink" => "",
			"Board" => $Board,
			"Category" => $cat_id,
			"parent_forum" => $parent_id,
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
			,
		)
	);

}

?>
