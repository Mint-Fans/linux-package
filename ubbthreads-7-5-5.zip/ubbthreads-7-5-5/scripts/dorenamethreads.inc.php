<?php

//  Whoops!  If you see this text in your browser,
//  your web hosting provider has not installed PHP.
//
//  You will be unable to use UBB until PHP has been properly installed.
//
//  You may wish to ask your web hosting provider to install PHP.
//  Both Windows and Unix versions are available on the PHP website,
//  http://www.php.net/
//
//
//
//  Ultimate Bulletin Board
//  Script Version 7.5.5
//
//  Program authors: Rick Baker
//  Copyright (C) 2010 Mindraven.
//
//  You may not distribute this program in any manner, modified or
//  otherwise, without the express, written consent from
//  Mindraven.
//
//  You may make modifications, but only for your own use and
//  within the confines of the UBB License Agreement
//  (see our website for that).
//
//  Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Contributor Comments:
// Renames a thread to the same subject as post #1 of that thread.
//
// Author: Hans Siemons
//         hans@twistedmind.nl
//
//
//
// Oringal framework of this script (C) 2006 Mindraven.


if(!defined("UBB_MAIN_PROGRAM")) exit;

function &page_dorenamethreads_gpc () {
	return array(
		"input" => array(
			"Number" => array("Number","both","int"),
		),
		"wordlets" => array("admin/generic"),
		"user_fields" => "USER_TOPIC_VIEW_TYPE",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 1,
	);
} // end page_dorenamethreads_gpc

function &page_dorenamethreads_run () {

	global $userob,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$var_start,$var_eq,$var_sep,$var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$html = new html;

	if (!$Number) exit;
	
	$query = "
		select FORUM_ID,POST_ID,TOPIC_SUBJECT
		from {$config['TABLE_PREFIX']}TOPICS
		where TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);
	list($Board,$first_post,$Subject) = $dbh->fetch_array($sth);

	// Make sure they can actually do this
	$pass = false;
	if ($userob->check_access("forum","MOVE_ANY",$Board)) {
		$pass = true;
	}
	if ($userob->check_access("forum","DELETE_TOPICS",$Board)) {
		$pass = true;
	}
	if ($userob->check_access("forum","STICKY_ANY",$Board)) {
		$pass = true;
	}
	if ($userob->check_access("forum","ANNOUNCEMENTS",$Board)) {
		$pass = true;
	}
	if ($userob->check_access("forum","LOCK_ANY",$Board)) {
		$pass = true;
	}
	if (!$pass) exit;

	$query = "
		select FORUM_TITLE,CATEGORY_ID,FORUM_PARENT
		from {$config['TABLE_PREFIX']}FORUMS
		where FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($Board),__LINE__,__FILE__);
	list($Title,$cat_id,$parent_id) = $dbh->fetch_array($sth);

	// do our thing
	$Subject="Re: ".$Subject;

	$query = "
	UPDATE {$config['TABLE_PREFIX']}POSTS 
	SET POST_SUBJECT = ?
	WHERE TOPIC_ID = ?
	AND POST_IS_TOPIC = 0
	
	";
	$dbh -> do_placeholder_query($query,array($Subject,$Number),__LINE__,__FILE__);

	// ----------------------------------------------------------------------------
	// Send them a page  ( If they came from a thread we return them to the postlist
	// screen, otherwise we return them to the admin section

	// ---------------
	// Log this action
	admin_log("RENAME_TOPIC", "<a href='{$config['BASE_URL']}/ubbthreads.php?ubb=showflat&Number=$first_post' target='_blank'>$Subject</a>");
	
	$html->send_redirect(
		array(
			"redirect" => "show{$user['USER_TOPIC_VIEW_TYPE']}&Number=$first_post",
			"heading" => $ubbt_lang['COM_HEAD'],
			"body" => $ubbt_lang['COM_BODY'],
			"Board" => $Board,
			"Category" => $cat_id,
			"forum_parent" => $parent_id,
			"returnlink" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$config['BASE_URL']}/ubbthreads.php{$var_start}ubb{$var_eq}cfrm">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
			,
		)
	);
}

?>

