<?php

//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_editbasic_gpc () {
	return array(
		"input" => array(
			"u" => array("u","get","int"),
			"e" => array("e","get","int"),
		),
		"wordlets" => array("editbasic"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_editbasic_gpc

function page_editbasic_run () {

	global $style_array,$smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html,$userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// ------------------------
	// Predefine some variables
	$pictureview = "";
	$acceptno = "";
	$acceptyes = "";
	$CUSTOM_FIELD_1 = "";
	$CUSTOM_FIELD_2 = "";
	$CUSTOM_FIELD_3 = "";
	$CUSTOM_FIELD_4 = "";
	$CUSTOM_FIELD_5 = "";
	$visibleyes = "";
	$visibleno = "";
	$OnlineFormatno = "";
	$OnlineFormatyes = "";
	$privates = "";
	if (!isset($config['MIN_PDN_LENGTH'])) {
		$config['MIN_PDN_LENGTH'] = 3;
	}
	if (!isset($config['MAX_PDN_LENGTH'])) {
		$config['MAX_PDN_LENGTH'] = 16;
	}

	// -----------------
	// Get the user info
	$Username = $user['USER_DISPLAY_NAME'];
	$coppauser = $user['USER_IS_UNDERAGE'];

	$can_custom = $userob->check_access("site","CUSTOM_TITLE");
	if ($can_custom) {
		$ubbt_lang['CUSTOM_TITLE'] = $html->substitute($ubbt_lang['CUSTOM_TITLE'], array('CHARS' => $can_custom)); 
	} // end if

	// ----------------------------------------
	// Get the current profile for this username
	$query = "
		SELECT	t1.USER_LOGIN_NAME,t2.USER_REAL_EMAIL,t2.USER_ACCEPT_ADMIN_EMAILS,t2.USER_BIRTHDAY,t2.USER_PUBLIC_BIRTHDAY,t2.USER_DISPLAY_EMAIL,
			t2.USER_OCCUPATION,t2.USER_LOCATION,t2.USER_HOBBIES,t2.USER_HOMEPAGE,t2.USER_EXTRA_FIELD_1,t2.USER_EXTRA_FIELD_2,t2.USER_EXTRA_FIELD_3,
			t2.USER_EXTRA_FIELD_4,t2.USER_EXTRA_FIELD_5,t2.USER_ICQ,t2.USER_YAHOO,t2.USER_MSN,t2.USER_AIM,t2.USER_DEFAULT_SIGNATURE,
			t2.USER_AVATAR,t2.USER_AVATAR_WIDTH,t2.USER_AVATAR_HEIGHT,t2.USER_CUSTOM_TITLE,t2.USER_UNVERIFIED_EMAIL,t2.USER_GROUP_IMAGES
		FROM	{$config['TABLE_PREFIX']}USERS as t1,
			{$config['TABLE_PREFIX']}USER_PROFILE as t2
		WHERE	t1.USER_ID = ? AND t1.USER_ID = t2.USER_ID
	";
	$sth = $dbh -> do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);

	// --------------------------------
	// Make sure we found this Username
	list($LoginName,$Email,$adminemail,$Birthday,$ShowBday,$Fakeemail,
	$Occupation,$Location,$Hobbies,$Homepage,$CUSTOM_FIELD_1,$CUSTOM_FIELD_2,$CUSTOM_FIELD_3,
	$CUSTOM_FIELD_4,$CUSTOM_FIELD_5,$icq,$yahoo,$msn,$aim,$Signature,
	$Picture,$PicWidth,$PicHeight,$custom_title,$unverified,$s_my_images) = $dbh -> fetch_array($sth);
	$dbh -> finish_sth($sth);

	$myimages = unserialize($s_my_images);

	// What images does this user have access to?
	$gimages = "";
	$gstring = "";
	$query = "
		select GROUP_ID
		from {$config['TABLE_PREFIX']}USER_GROUPS
		where USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
	while (list($gid) = $dbh->fetch_array($sth)) {
		$gstring .= "$gid,";
	} // end while
	$gstring = preg_replace("/,$/","",$gstring);
	$query = "
		select GROUP_ID,GROUP_IMAGE
		from {$config['TABLE_PREFIX']}GROUPS
		where GROUP_ID in ($gstring)
		and GROUP_IMAGE <> ''
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	$x = 0;
	while(list($gid,$gimage) = $dbh->fetch_array($sth)) {
		$selected = "";
		if (in_array($gid,$myimages)) {
			$selected = "checked='checked'";
		} 
		$gimages .= <<<EOF
 <input type="checkbox" name="gimages[$x]" value="$gid" $selected /><img src="{$config['BASE_URL']}/images/groups/$gimage" /> 
EOF;
		$x++;
	} // end while

	// ---------------------------
	// Change the quotes to &quot;
	$ChosenPassword    = "123456789123456789";
	$Email       = str_replace("\"","&quot;",$Email);
	$Fakeemail   = str_replace("\"","&quot;",$Fakeemail);
	$Occupation  = str_replace("\"","&quot;",$Occupation);
	$Location    = str_replace("\"","&quot;",$Location);
	$Hobbies     = str_replace("\"","&quot;",$Hobbies);
	$Homepage    = str_replace("\"","&quot;",$Homepage);
	$CUSTOM_FIELD_1 = str_replace("\"","&quot;",$CUSTOM_FIELD_1);
	$CUSTOM_FIELD_2 = str_replace("\"","&quot;",$CUSTOM_FIELD_2);
	$CUSTOM_FIELD_3 = str_replace("\"","&quot;",$CUSTOM_FIELD_3);
	$CUSTOM_FIELD_4 = str_replace("\"","&quot;",$CUSTOM_FIELD_4);
	$CUSTOM_FIELD_5 = str_replace("\"","&quot;",$CUSTOM_FIELD_5);
	$icq         = str_replace("\"","&quot;",$icq);
	$yahoo         = str_replace("\"","&quot;",$yahoo);
	$msn         = str_replace("\"","&quot;",$msn);
	$aim         = str_replace("\"","&quot;",$aim);
	$Signature   = str_replace("\"","&quot;",$Signature);
	$custom_title = str_replace("\"","&quot;",$custom_title);

	if (!$LoginName){
		$html->not_right($html->substitute($ubbt_lang['NO_PROF'], array('USERNAME' => $Username)));
	}

	$TEXT_AREA_COLUMNS = $config['TEXT_AREA_COLUMNS'];
	$TEXT_AREA_ROWS = $config['TEXT_AREA_ROWS'];

	// --------------------------------
	// Set the default for admin emails
	$optout = "";
	$optin = "";
	if(($adminemail == "Off") || ($adminemail == "")) {
		$optout = "checked=\"checked\"";
	}
	if ($adminemail == "On") {
		$optin = "checked=\"checked\"";
	}

	// ---------------------------------------------------------
	// Ok, we found the profile, now lets put it all onto a page
	$formmethod = "<form method=\"post\" action=\"" . make_ubb_url("", "", false) . "\" name=\"PROFILE\">";

	if ($config['DISPLAY_NAME_CHANGE']) {
		$displaychange = "{$ubbt_lang['DISPLAY_NAME']}";
		if ($config['DISPLAY_NAME_CHANGE'] == "2") {
			$displaychange .= " {$ubbt_lang['DISPLAY_APP']}";
		}
		$displaychange .= "
			({$config['MIN_PDN_LENGTH']} - {$config['MAX_PDN_LENGTH']} {$ubbt_lang['CHARACTERS']})<br />
			<input type=\"text\" name=\"displayname\" class=\"form-input\" value=\"$Username\" size=\"{$config['MAX_PDN_LENGTH']}\" maxlength=\"".max($config['MAX_PDN_LENGTH'],strlen($Username))."\" /><br /><br />
		";
	}
	else {
		$displaychange = "<input type=\"hidden\" name=\"displayname\" value=\"$Username\" />";
	}

	// -----------------------------------------
	// Generate the birthday selection formboxes
	$doshowbday = "";
	if ($ShowBday) {
		$doshowbday = "checked=\"checked\"";
	}
	@list($bmonth,$bday,$byear) = @explode("/",$Birthday);
	$selectmonth = "<select name=\"bmonth\" class=\"form-select\">";
	if (!$bmonth) {
		$selectmonth .= "<option value=\"\"></option>";
	}
	for ($i=1;$i<=12;$i++) {
		$mname = "MONTH$i";
		$mname = $ubbt_lang[$mname];
		$selected = "";
		if ($bmonth == $i) {
			$selected = "selected=\"selected\"";
		}
		$selectmonth .= "<option value=\"$i\" $selected>$mname</option>";
	}
	$selectmonth .= "</select>";

	$selectday = "<select name=\"bday\" class=\"form-select\">";
	if (!$bday) {
		$selectday .= "<option value=\"\" $selected></option>";
	}
	for ($i=1;$i<=31;$i++) {
		$selected = "";
		if ($bday == $i) {
			$selected = "selected=\"selected\"";
		}
		$selectday .= "<option $selected>$i</option>";
	}
	$selectday .= "</select>";

	$selectyear = "<select name=\"byear\" class=\"form-select\">";
	if (!$byear) {
		$selectyear .= "<option value=\"\" $selected></option>";
	}
	$temp = getdate();
	$thisyear  = $temp["year"];
	for ($i=1900;$i<=$thisyear;$i++) {
		$selected = "";
		if ($byear == $i) {
			$selected = "selected=\"selected\"";
		}
		$selectyear .= "<option $selected>$i</option>";
	}
	$selectyear .= "</select>";

	// -----------------------------------------
	// Do we allow them to change their birthday
	if ($config['BIRTHDAYS_IN_CALENDAR']) {
		$bday_text = $ubbt_lang['SHOWBDAY'];
	} else {
		$bday_text = $ubbt_lang['SHOWBDAY_NOCAL'];
	} // end if
	if (!$coppauser) {
		$birthdayfields = <<<EOF
		{$ubbt_lang['BIRTHDAY']}
		<br />
		$selectmonth $selectday $selectyear
		<br />
		<br />
		<input type="checkbox" name="showbday" id="showbday" value="1" $doshowbday class="form-checkbox" />
		<label for="showbday">$bday_text</label>
		<br />
		<br />
EOF;
	}

	// Describes the signature and limitations
	$ubbt_lang['PROF_SIG'] = $html->substitute($ubbt_lang['PROF_SIG'], array(
		'SIG_LEN' => $userob->check_access("site","SIGNATURE_LENGTH"),
		'FAQ_ADDY' => make_ubb_url("ubb=faq#html","",false)));

	$allowpics = "";
	$dimensions = $html->substitute($ubbt_lang['DIMENSIONS'], array(
		'MAX_X' => $config['AVATAR_MAX_WIDTH'],
		'MAX_Y' => $config['AVATAR_MAX_HEIGHT']));

	if ($userob->check_access("site","UPLOAD_AVATARS") && ini_get('file_uploads')) {
		$formmethod = "<form method=\"post\" enctype='multipart/form-data' action=\"" . make_ubb_url("", "", false) . "\" name=\"PROFILE\">";
		$avinfo = $html->substitute($ubbt_lang['UPLOAD_PIC'], array('DIMENSIONS' => $dimensions));
		$pictureview = "
		<input type=\"radio\" name=\"picchange\" id=\"picchange-upload\" value=\"upload\" class=\"form-radio\" />
		<label for=\"picchange-upload\">$avinfo</label><br />
		<input type=\"file\" name=\"userfile\" accept=\"*\" class=\"form-input\" />
		<br /><br />
		";
		$allowpics = 1;
	}

	if ($userob->check_access("site","REMOTE_AVATARS")) {
		if (!$Picture) { $Picture ="http://"; }
		$avinfo = $html->substitute($ubbt_lang['PROF_PIC'], array('DIMENSIONS' => $dimensions));
		$pictureview .= "
		<input type=\"radio\" name=\"picchange\" id=\"picchange-url\" value=\"url\" class=\"form-radio\" />
		<label for=\"picchange-url\">$avinfo</label><br />
		<input type=\"text\" name=\"Picture\" size=\"50\" class=\"form-input\" />
		<br />
		<br />
		";
		$allowpics = 1;
	}
	if (!$allowpics) {
		$pictureview = "<input type=\"hidden\" name=\"Picture\" value=\"$Picture\" />";
	}

	$stockavatar = "";
	if ($userob->check_access("site","STOCK_AVATARS")) {
		$allowpics = 1;
		$stockavatar = <<<EOF
		<input type="radio" name="picchange" id="picchange-avatar" value="avatar" class="form-radio" />
		<label for="picchange-avatar">{$ubbt_lang['PREDEF_PIC']}</label><br />
		<!-- 2 --><img name="avimg" border="1" src="{$config['BASE_URL']}/images/{$style_array['general']}/blank.gif" height="48" width="48" /><!-- 4 -->&nbsp; <a href="javascript:void(0);" onclick="launch_avatar_window();">{$ubbt_lang['PREDEF_CHOOSE']}</a> &nbsp;
		<input type="hidden" name="avurl" value="" />
		<input type="hidden" name="avwidth" value="" />
		<input type="hidden" name="avheight" value="" />
		<br />
		<br />
EOF;
	}

	$picchangetext = "";
	$picchangeclose = "";
	if ($allowpics) {
		if (!$PicWidth) { $PicWidth = $config['AVATAR_MAX_WIDTH']; }
		if (!$PicHeight) { $PicHeight = $config['AVATAR_MAX_HEIGHT']; }
		$picchangetext = '<br /><table width="100%" class="t_standard" cellspacing="0" cellpadding="0" border="0"><tr><td class="tdheader">';
		$picchangetext .= "{$ubbt_lang['PICCHANGE']}<br /></td></tr><tr><td class=\"alt-1\">";
		if ( ($Picture) && ($Picture != "http://") ) {
			$picchangetext .= "{$ubbt_lang['CURRENTIMG']}: <img src=\"$Picture\" width=\"$PicWidth\" height=\"$PicHeight\" alt=\"\" /><br /><br />";
			$picchangetext .= "<input type=\"radio\" name=\"picchange\" id=\"picchange-nopic\" value=\"nopic\" class=\"form-radio\"> <label for=\"picchange-nopic\">{$ubbt_lang['NOPIC']}</label><br /><br />";
		}
		$picchangeclose = '</table><br />';
	}

	$base = make_ubb_url("", "", false);
	$avatarscript = <<<EOF
<script language="JavaScript" type="text/javascript">
//<![CDATA[
var selector = null;
function launch_avatar_window() {
	var avatar_popup_width = 550;
	var avatar_popup_height =  300;
	var Avatarselection = escape(document.PROFILE.avurl.value);
	var avatar_selector_page = "{$base}?ubb=avatar&start_with=0&form=PROFILE";
	selector = window.open(avatar_selector_page + '&avatar_url=' + Avatarselection,'selector','scrollbars=yes,resizable=yes,width=' + avatar_popup_width + ',height=' + avatar_popup_height + ',screenX=50,screenY=50,top=50,left=50');
} // end function
//]]>
</script>
EOF;

	// Handle Custom fields 1 - 5 :)
	for ($i = 1; $i <= 5; $i++) {
		$key = 'CUSTOM_FIELD_' . $i;
		$x = ${$key};
		if ($config[$key]) {
			${$key} = "
				<label for=\"{$key}\">{$config[$key]}</label>
				<br />
				<input type=\"text\" name=\"{$key}\" id=\"{$key}\" value=\"{$x}\" class=\"form-input\" /><br /><br />
			";
		} else {
			${$key} = "
				<input type=\"hidden\" name=\"{$key}\" id=\"{$key}\" value=\"{$x}\" class=\"form-input\" />
			";
		}
	}

	// If they have an unverified email, let them know
	if ($unverified) {
		$unverified = $html->substitute($ubbt_lang['NOT_VERIFIED'],array('UNVERIFIED'=>$unverified));
	}

	// Generate a key for the profile page to make sure the
	// submission is legit
	$rightnow = time();
	list($usec, $sec) = explode(' ', microtime());
	srand((float) $sec + ((float) $usec * 100000));
	$random = rand();
	$profilehash = md5("$rightnow$random");

	$query = "
	UPDATE {$config['TABLE_PREFIX']}USER_DATA
	SET USER_PROFILE_KEY = ?
	WHERE USER_ID = ?
	";
	$dbh->do_placeholder_query($query,array($profilehash,$user['USER_ID']),__LINE__,__FILE__);

	$smarty_data = array(
		"formmethod" => $formmethod,
		"gimages" => $gimages,
		"Username" => $Username,
		"profilehash" => $profilehash,
		"LoginName" => $LoginName,
		"Email" => $Email,
		"optout" => $optout,
		"optin" => $optin,
		"ChosenPassword" => $ChosenPassword,
		"displaychange" => $displaychange,
		"birthdayfields" => $birthdayfields,
		"Fakeemail" => $Fakeemail,
		"Occupation" => $Occupation,
		"Location" => $Location,
		"Hobbies" => $Hobbies,
		"Homepage" => $Homepage,
		"CUSTOM_FIELD_1" => $CUSTOM_FIELD_1,
		"CUSTOM_FIELD_2" => $CUSTOM_FIELD_2,
		"CUSTOM_FIELD_3" => $CUSTOM_FIELD_3,
		"CUSTOM_FIELD_4" => $CUSTOM_FIELD_4,
		"CUSTOM_FIELD_5" => $CUSTOM_FIELD_5,
		"icq" => $icq,
		"yahoo" => $yahoo,
		"msn" => $msn,
		"aim" => $aim,
		"Signature" => $Signature,
		"avatarscript" => $avatarscript,
		"picchangetext" => $picchangetext,
		"pictureview" => $pictureview,
		"stockavatar" => $stockavatar,
		"picchangeclose" => $picchangeclose,
		"u" => $u,
		"can_custom" => $can_custom,
		"custom_title" => $custom_title,
		"mystuff" => $html->mystuff(),
		"e" => $e,
		"unverified" => $unverified,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$profhead = $html->substitute($ubbt_lang['PROF_HEAD'], array('USERNAME' => $Username));

	return array(
		"header" => array (
		"title" => $profhead,
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 $profhead
BREADCRUMB
			,
		),
		"template" => "editbasic",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
