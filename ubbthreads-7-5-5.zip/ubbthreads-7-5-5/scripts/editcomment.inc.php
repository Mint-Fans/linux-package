<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_editcomment_gpc () {
	return array(
		"input" => array(
			"id" => array("id","get","int"),
			"d" => array("d","get","int"),
		),
		"wordlets" => array("editcomment"),
		"user_fields" => "USER_TEXT_EDITOR",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_editpost_gpc

function page_editcomment_run () {

	global $style_array,$html,$userob,$myinfo,$smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// ------------------------
	// Predefine some variables
	$fpart = "";
	$addevent = "";
	$selectmonth = "";
	$selectday = "";
	$selectyear = "";

	$Username = $user['USER_DISPLAY_NAME'];

	$TEXT_AREA_COLUMNS = $config['TEXT_AREA_COLUMNS'];
	$TEXT_AREA_ROWS = $config['TEXT_AREA_ROWS'];

	// -----------------------------------
	// Get the post info from the database
	$query = "
		select USER_ID,COMMENT_DEFAULT_BODY,PROFILE_ID
		from {$config['TABLE_PREFIX']}PROFILE_COMMENTS
		where COMMENT_ID = ?
	";
	$sth = $dbh -> do_placeholder_query($query,array($id),__LINE__,__FILE__);

	// -------------------------
	// Assign the retrieved data
	list($Postedby,$Body,$profile) = $dbh -> fetch_array($sth);

	if ($Postedby != $user['USER_ID'] && $user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && $profile != $user['USER_ID']) {
		$html->not_right($ubbt_lang['NO_EDIT']);
	} // end if

	$Body = htmlspecialchars($Body);

	if ($Postedby == $user['USER_ID'] || $user['USER_MEMBERSHIP_LEVEL'] == "Administrator") {
		$canedit = 1;
	}
		
	$text_editor = $html->create_text_editor("Body","$Body",2,0,0);
	
	$smarty_data = array(
		"id" => $id,
		"text_editor" => & $text_editor,
		"canedit" => $canedit,
	);
		

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array (
			"title" => $ubbt_lang['PEDIT_HEAD'],
			"refresh" => 0,
			"user" => $user,
			"Board" => $Board,
			"Category" => $cat_id,
			"forum_parent" => $parent_id,
			"custom_header_footer" => $fheader,
			"bypass" => 0,
			"rss" => $is_rss,
			"rss_title" => $rss_title,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
			,
			"javascript" => array(
				0 => "standard_text_editor.js",
			),
		),
		"template" => "editcomment",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
	
}

?>
