<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_editdisplay_gpc () {
	return array(
		"input" => array(
			"u" => array("u","get","int"),
		),
		"wordlets" => array("editdisplay"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_editdisplay_gpc

function page_editdisplay_run () {

	global $smarty,$user,$in,$ubbt_lang,$config,$dbh,$html,$userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$Username = $user['USER_DISPLAY_NAME'];
	$Password = $user['USER_PASSWORD'];

	// -----------------------------------------
	// Get the current profile for this username
	$query = "
		SELECT	t1.USER_DISPLAY_NAME,t2.USER_START_VIEW,t2.USER_FAVORITES_TAB,t2.USER_FAVORITES_SORT,t2.USER_TOPIC_VIEW_TYPE,
			t2.USER_TOPICS_PER_PAGE,t2.USER_POSTS_PER_TOPIC,t2.USER_SHOW_AVATARS,t2.USER_SHOW_SIGNATURES,t2.USER_NOTIFY_ON_PM,
			t2.USER_ACCEPT_PM,t2.USER_TIME_OFFSET,t2.USER_TIME_FORMAT,t2.USER_VISIBLE_ONLINE_STATUS,t2.USER_UNAPPROVED_POST_NOTIFY,
			t2.USER_TEXT_EDITOR,t2.USER_HIDE_LEFT_COLUMN,t2.USER_HIDE_RIGHT_COLUMN,t2.USER_STYLE,t2.USER_EMAIL_WATCHLISTS,t2.USER_LANGUAGE,
			t2.USER_REPORT_POST_NOTIFY,USER_RELATIVE_TIME,t2.USER_NOTIFY_NEW_USER,t2.USER_POST_LAYOUT,t2.USER_SHOW_ALL_GRAEMLINS,
			t2.USER_SHOW_LEFT_MYSTUFF,t2.USER_NOTIFY_MULTI
		FROM	{$config['TABLE_PREFIX']}USERS as t1,
			{$config['TABLE_PREFIX']}USER_PROFILE as t2
		WHERE	t1.USER_ID = ? AND t1.USER_ID = t2.USER_ID
	";
	$sth = $dbh -> do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);

	// --------------------------------
	// Make sure we found this Username
	list($Usercheck,$start_view,$default_tab,$default_sort,$Display,
	$PostsPer,$FlatPosts,$ShowAvatars,$sigview,$pm_notify,
	$AcceptPriv,$TimeOffset,$timeformat,$Visible,$unapproved,
	$texteditor,$hide_left,$hide_right,$user_style,$email_watch,$user_language,
	$report_post,$relative,$newuser,$post_layout,$user['USER_SHOW_ALL_GRAEMLINS'],$mystuff_left,$notify_multi) = $dbh -> fetch_array($sth);
	$dbh -> finish_sth($sth);

	if (!$Usercheck){
		$html->not_right($html->substitute($ubbt_lang['NO_PROF'], array('USERNAME' => $Username)));
	}

	// Relative Times?
	if ($user['USER_RELATIVE_TIME'] != '0' && $user['USER_RELATIVE_TIME'] != '1') {
		$user['USER_RELATIVE_TIME'] = $config['RELATIVE_TIME'];
	} // end if
	$relativeno = "checked='checked'";
	$relativeyes = "";
	if ($user['USER_RELATIVE_TIME']) {
		$relativeyes = "checked='checked'";
		$relativeno = "";
	} // end if

	$noshowgraem = "checked='checked'";
	$yesshowgraem = "";
	if ($user['USER_SHOW_ALL_GRAEMLINS']) {
		$yesshowgraem = "checked='checked'";
		$noshowgraem = "";
	} // end if

	// Default language
	if (!$user_language) $user_language = $config['LANGUAGE'];

	// Get available languages
	$query = "
		select LANGUAGE_TYPE,LANGUAGE_DESCRIPTION
		from {$config['TABLE_PREFIX']}LANGUAGES
		where LANGUAGE_IS_ACTIVE = '1'
		order by LANGUAGE_DESCRIPTION
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	$languages = array();
	while(list($l_type,$l_desc) = $dbh->fetch_array($sth)) {
		$languages[$l_type] = $l_desc;
	}

	// Starting view
	$list_selected = "";
	$cfrm_selected = "";
	if ($start_view == "lists") {
		$list_selected = "selected=\"selected\"";
	} else {
		$cfrm_selected = "selected=\"selected\"";
	} // end if

	$email_watches_no = "";
	$email_watches_yes = "";
	if ($email_watch == 1) {
		$email_watches_yes = "checked=\"checked\"";
	} else {
		$email_watches_no = "checked=\"checked\"";
	} // end if

	// Text Editor
	$standard_selected = "";
	$richtext_selected = "";
	if ($texteditor == "standard") {
		$standard_selected = "selected=\"selected\"";
	} else {
		$richtext_selected = "selected=\"selected\"";
	} // end if

	// Default tab
	$topics_tab = "";
	$forums_tab = "";
	$users_tab = "";
	if ($default_tab == "topics") {
		$topics_tab = "selected=\"selected\"";
	} elseif ($default_tab == "users") {
		$users_tab = "selected=\"selected\"";
	} else {
		$forums_tab = "selected=\"selected\"";
	} // end if

	// Default sort
	$sort_reply = "";
	$sort_creation = "";
	$sort_title = "";
	$sort_author = "";
	if ($default_sort == "creation") {
		$sort_creation = "selected=\"selected\"";
	} elseif ($default_sort == "title") {
		$sort_title = "selected=\"selected\"";
	} elseif ($default_sort == "author") {
		$sort_author = "selected=\"selected\"";
	} else {
		$sort_reply = "selected=\"selected\"";
	} // end if

	$unapprovedno = "checked=\"checked\"";
	$unapprovedyes = "";
	if ($unapproved) {
		$unapprovedyes = "checked=\"checked\"";
		$unapprovedno = "";
	}

	$notify_postyes = "";
	$notify_postno = "checked='checked'";
	if ($report_post) {
		$notify_postyes = "checked='checked'";
		$notify_postno = "";
	}

	$newuser_yes = "";
	$newuser_no =  "checked='checked'";
	if ($newuser) {
		$newuser_yes = "checked='checked'";
		$newuser_no = "";
	} // end if


	// --------------------------------------------------
	// Find out if they already have a display preference
	$flat = "";
	$threaded = "";
	if($Display == "flat")     { $flat = "selected=\"selected\""; };
	if($Display == "threaded") { $threaded = "selected=\"selected\""; }

	$side = "";
	$top = "";
	if (!$post_layout) $post_layout = $config['POST_LAYOUT'];
	if ($post_layout == "side") {
		$side = "selected=\"selected\"";
	} else {
		$top = "selected=\"selected\"";
	} // end if

	// Stylesheet pref
	$query = "
		select STYLE_ID,STYLE_NAME
		from {$config['TABLE_PREFIX']}STYLES
		where STYLE_IS_ACTIVE = '1'
		order by STYLE_NAME ASC
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	$style_options="";
	while(list($styleid,$desc) = $dbh->fetch_array($sth)) {
		$extra = "";
		if ($styleid == $user_style) {
			$found = 1;
			$extra = "selected=\"selected\"";
		}
		$style_options .= "<option value=\"$styleid\" $extra>$desc</option>";
	}
	$extra = "";
	if (!$found) {
		$extra = "selected=\"selected\"";
	}
	$style_options = "<option value=\"0\" $extra>{$ubbt_lang['DEFAULT_STYLE']}</option>$style_options";



	// ----------------------------------------------------------------
	// Find out if they have a preference for total flat posts per page
	if (!$FlatPosts) { $FlatPosts = $config['POSTS_PER_PAGE']; }

	// Preference for topics per page.
	if (!$PostsPer) { $PostsPer = $config['TOPICS_PER_PAGE']; }

	// Show user's avatars
	$SHOW_AVATARS_yes = "";
	$SHOW_AVATARS_no = "";
	if ($ShowAvatars) {
		$SHOW_AVATARS_yes = "checked=\"checked\"";
	} else {
		$SHOW_AVATARS_no = "checked=\"checked\"";
	}

	// ----------------------------
	// Set the default for sigview
	$yessigview = "";
	$nosigview = "";
	if ($sigview == "no") {
		$nosigview = "checked=\"checked\"";
	}
	else {
		$yessigview = "checked=\"checked\"";
	}

	// ----------------------------------------------
	// Set the default for accepting private messages
	$acceptyes = "";
	$acceptno = "";
	if ($AcceptPriv == "yes") {
		$acceptyes = "checked=\"checked\"";
	}
	else {
		$acceptno = "checked=\"checked\"";
	}

	// ------------------------------------------------
	// Set the default for private message notification
	$donotify = "";
	$nonotify = "";
	if ($pm_notify == "yes") {
		$donotify = "checked=\"checked\"";
	}
	else {
		$nonotify = "checked=\"checked\"";
	}

	// ------------------------------
	// What time format are we using?
	$time_formats = "";
	if (!$timeformat) { $timeformat = $config['TIME_FORMAT']; }
	foreach($config['TIME_FORMATS'] as $k => $v) {
		$selected = "";
		if ($timeformat == $v) {
			$selected = "selected=\"selected\"";
		}
		$time_formats .= "<option value=\"$k\" $selected>" . $html->convert_time(time(),0,$v,1,0) . "</option>";
	}

	if (!$TimeOffset) { $TimeOffset = 0; }

	// ----------------------------
	// Set the default for visibile
	$hideyes = ""; $hideno = "";
	if ($Visible == "yes") {
		$hideno = "checked =\"checked\"";
	}
	else {
		$hideyes = "checked=\"checked\"";
	}

	$hide_left_no = ""; $hide_left_yes = "";
	$hide_right_no = ""; $hide_right_yes = "";
	if ($hide_left) {
		$hide_left_yes = "checked=\"checked\"";
	} else {
		$hide_left_no = "checked=\"checked\"";
	}
	if ($hide_right) {
		$hide_right_yes = "checked=\"checked\"";
	} else {
		$hide_right_no = "checked=\"checked\"";
	}

	$mystuff_left_yes = ""; $mystuff_left_no = "";
	if ($mystuff_left) {
		$mystuff_left_yes = "checked=\"checked\"";
	} else {
		$mystuff_left_no = "checked=\"checked\"";
	}

	if ($config['LEFT_COLUMN'] && $config['DISABLE_LEFT'] && !$config['LEFT_COLUMN_PORTAL']) {
		$left_column = 1;
	}
	if ($config['RIGHT_COLUMN'] && $config['DISABLE_RIGHT'] && !$config['RIGHT_COLUMN_PORTAL']) {
		$right_column = 1;
	}

	// Topics and Posts per page
	$pagetopics = $html->substitute($ubbt_lang['PROF_POSTS'], array('TOPICS_PER' => $config['TOPICS_PER_PAGE']));
	$pageposts = $html->substitute($ubbt_lang['TOT_FLAT'], array('POSTS_PER' => $config['POSTS_PER_PAGE']));

	// Do they get an option to be notified of users don't multi-account logins
	$multi_option = 0;
	if (!$notify_multi) $notify_multi = 0;
	if ($userob->check_access("cp","EDIT_USERS") || $userob->check_access("cp","FULL_ACCESS")) {
		$multi_option = 1;
		$mutli_on = ""; $multi_off = "";
		if ($notify_multi) {
			$multi_on = "checked='checked'";
		} else {
			$multi_off = "checked='checked'";
		} // end if
	}


	// ---------------------------------------------------------
	// Ok, we found the profile, now lets put it all onto a page


	$date = $html -> get_date();
	$time = $html -> convert_time($date,0,$timeformat,1);

	// Generate a key for the profile page to make sure the
	// submission is legit
	$rightnow = time();
	list($usec, $sec) = explode(' ', microtime());
	srand((float) $sec + ((float) $usec * 100000));
	$random = rand();
	$profilehash = md5("$rightnow$random");

	$query = "
	UPDATE {$config['TABLE_PREFIX']}USER_DATA
	SET USER_PROFILE_KEY = ?
	WHERE USER_ID = ?
	";
	$dbh->do_placeholder_query($query,array($profilehash,$user['USER_ID']),__LINE__,__FILE__);

	$smarty_data = array(
		"email_watches_yes" => $email_watches_yes,
		"email_watches_no" => $email_watches_no,
		"Username" => $Username,
		"Password" => $Password,
		"list_selected" => $list_selected,
		"cfrm_selected" => $cfrm_selected,
		"forums_tab" => $forums_tab,
		"topics_tab" => $topics_tab,
		"users_tab" => $users_tab,
		"sort_reply" => $sort_reply,
		"sort_creation" => $sort_creation,
		"sort_title" => $sort_title,
		"sort_author" => $sort_author,
		"threaded" => $threaded,
		"flat" => $flat,
		"top" => $top,
		"side" => $side,
		"PostsPer" => $PostsPer,
		"FlatPosts" => $FlatPosts,
		"pagetopics" => $pagetopics,
		"pageposts" => $pageposts,
		"SHOW_AVATARS_yes" => $SHOW_AVATARS_yes,
		"SHOW_AVATARS_no" => $SHOW_AVATARS_no,
		"yessigview" => $yessigview,
		"nosigview" => $nosigview,
		"donotify" => $donotify,
		"nonotify" => $nonotify,
		"acceptyes" => $acceptyes,
		"acceptno" => $acceptno,
		"time" => $time,
		"TimeOffset" => $TimeOffset,
		"profilehash" => $profilehash,
		"hideno" => $hideno,
		"hideyes" => $hideyes,
		"style_options" => $style_options,
		"unapprovedyes" => $unapprovedyes,
		"unapprovedno" => $unapprovedno,
		"notify_postyes" => $notify_postyes,
		"notify_postno" => $notify_postno,
		"newuser_yes" => $newuser_yes,
		"newuser_no" => $newuser_no,
		"user_status" => $user['USER_MEMBERSHIP_LEVEL'],
		"standard_selected" => $standard_selected,
		"richtext_selected" => $richtext_selected,
		"time_formats" => $time_formats,
		"hide_left_yes" => $hide_left_yes,
		"hide_left_no" => $hide_left_no,
		"hide_right_yes" => $hide_right_yes,
		"hide_right_no" => $hide_right_no,
		"left_column" => $left_column,
		"right_column" => $right_column,
		"yesshowgraem" => $yesshowgraem,
		"noshowgraem" => $noshowgraem,
		"u" => $u,
		"languages" => $languages,
		"user_language" => $user_language,
		"relativeyes" => $relativeyes,
		"relativeno" => $relativeno,
		"mystuff" => $html->mystuff(),
		"mystuff_left_yes" => $mystuff_left_yes,
		"mystuff_left_no" => $mystuff_left_no,
		"multi_option" => $multi_option,
		"multi_on" => $multi_on,
		"multi_off" => $multi_off,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$disphead = $html->substitute($ubbt_lang['DISP_HEAD'], array('USERNAME' => $Username));
	return array(
		"header" => array (
		"title" => $disphead,
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 $disphead
BREADCRUMB
			,
		),
		"template" => "editdisplay",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
