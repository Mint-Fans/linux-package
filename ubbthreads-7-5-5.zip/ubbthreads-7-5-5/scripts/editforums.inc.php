<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_editforums_gpc () {
	return array(
		"input" => array(),
		"wordlets" => array("editforums"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_editemail_gpc

function page_editforums_run () {

	global $smarty,$userob,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$forum_array = array();
	$forum_data = array();
	$subforums = array();

	$query = "
		select 	c.CATEGORY_TITLE,f.FORUM_ID,f.FORUM_TITLE,fav.WATCH_NOTIFY_IMMEDIATE,fav.WATCH_ID,f.FORUM_PARENT
		from	{$config['TABLE_PREFIX']}CATEGORIES as c,
			{$config['TABLE_PREFIX']}FORUMS as f
		left join {$config['TABLE_PREFIX']}WATCH_LISTS as fav on (f.FORUM_ID = fav.WATCH_ID and fav.USER_ID = ? and fav.WATCH_TYPE = 'f')
		where	f.CATEGORY_ID = c.CATEGORY_ID
		and	f.FORUM_IS_ACTIVE = '1'
		order by c.CATEGORY_SORT_ORDER,f.FORUM_SORT_ORDER
	";
	$sth = $dbh->do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);

	while(list($cat,$id,$title,$immediate,$fav_check,$forum_parent) = $dbh->fetch_array($sth)) {
		if (!$userob->check_access("forum","SEE_FORUM",$id)) {
			continue;
		} // end if

		if ($forum_parent) {
			$subforums[$forum_parent][] = $id;
		}

		$forum_data[$id] = array(
			"CATEGORY" => $cat,
			"ID" => $id,
			"TITLE" => $title,
			"IMMEDIATE" => $immediate,
			"FAVORITE" => $fav_check,
			"PARENT_TITLE" => "",
			"FORUM_PARENT" => $forum_parent,
		);

	} // end while

	$forum_list = array();

	foreach($forum_data as $k => $v) {
		$forum_list[] = $v['ID'];
	}

	$is_checked = ' selected="selected" ';
	$is_not_checked = '';
	$i = 0;

	foreach($forum_list as $v) {
		$email_new_topic = ($forum_data[$v]['IMMEDIATE'] == 2) ? $is_checked : $is_not_checked;
		$email_immediate = ($forum_data[$v]['IMMEDIATE'] == 1) ? $is_checked : $is_not_checked;
		$email_none      = ($email_new_topic || $email_immediate) ? $is_not_checked : $is_checked;

		$is_favorite = "";
		$not_favorite = "";
		if ($forum_data[$v]['FAVORITE']) {
			$is_favorite = "checked=\"checked\"";
		} else {
			$not_favorite = "checked=\"checked\"";
		} // end if
		if ($forum_data[$v]['PARENT_TITLE']) {
			$forum_data[$v]['CATEGORY'] = "{$forum_data[$v]['CATEGORY']} &raquo; {$forum_data[$v]['PARENT_TITLE']}";
		}
		$forum_data[$v]['class'] = ($i&1) ? "alt-topicsubject" : "topicsubject";

		$forum_array[] = array(
			"cat" => $forum_data[$v]['CATEGORY'],
			"id" => $forum_data[$v]['ID'],
			"title" => $forum_data[$v]['TITLE'],
			"class" => $forum_data[$v]['class'],
			"none" => $email_none,
			"immediate" => $email_immediate,
			"newtopic" => $email_new_topic,
			"is_favorite" => $is_favorite,
			"not_favorite" => $not_favorite,
		);
	$i++;
	}

	$smarty_data = array(
		"forum_array" => $forum_array,
		"mystuff" => $html->mystuff(),
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$home = make_ubb_url("ubb=myhome", "", false);
	return array(
		"header" => array (
			"title" => "{$ubbt_lang['EDIT_FAV_FORUMS']}",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 <a href="{$home}">{$ubbt_lang['VIEW_WATCH']}</a>
 &raquo;
 {$ubbt_lang['EDIT_FAV_FORUMS']}
BREADCRUMB
			,
		),
		"template" => "editforums",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
