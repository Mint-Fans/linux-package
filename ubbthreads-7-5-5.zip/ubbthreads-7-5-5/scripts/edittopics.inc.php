<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_edittopics_gpc () {
	return array(
		"input" => array(),
		"wordlets" => array("edittopics"),
		"user_fields" => "t2.USER_TOPIC_VIEW_TYPE",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_edittopics_gpc

function page_edittopics_run () {

	global $smarty,$userob,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$topic_array = array();

	$query = "
		select 	fav.WATCH_ID,t.TOPIC_SUBJECT,t.POST_ID,fav.WATCH_NOTIFY_IMMEDIATE
		from	{$config['TABLE_PREFIX']}WATCH_LISTS as fav,
			{$config['TABLE_PREFIX']}TOPICS as t
		where	fav.USER_ID = ?
		and	fav.WATCH_ID = t.TOPIC_ID
		and	fav.WATCH_TYPE = 't'
	";
	$sth = $dbh->do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
	while(list($id,$title,$pid,$immediate) = $dbh->fetch_array($sth)) {

		$email_none = "checked=\"checked\"";
		$email_immediate = "";

		if ($immediate) {
			$email_immediate = "checked=\"checked\"";
		} // end if

		$topic_array[] = array(
			"id" => $id,
			"title" => $title,
			"pid" => $pid,
			"none" => $email_none,
			"immediate" => $email_immediate,
		);
	} // end while

	$smarty_data = array(
		"topic_array" => $topic_array,
		"user" => $user,
		"mystuff" => $html->mystuff(),
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$home = make_ubb_url("ubb=myhome", "", false);
	return array(
		"header" => array (
			"title" => "{$ubbt_lang['EDIT_FAV_TOPICS']}",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 <a href="{$home}">{$ubbt_lang['VIEW_WATCH']}</a>
 &raquo;
 {$ubbt_lang['EDIT_FAV_TOPICS']}
BREADCRUMB
			,
		),
		"template" => "edittopics",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
