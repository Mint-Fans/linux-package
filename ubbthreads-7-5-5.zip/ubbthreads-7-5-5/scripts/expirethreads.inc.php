<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_expirethreads_gpc () {
	return array(
		"input" => array(
			"Number" => array("Number","both","int"),
			"Board" => array("Board","both","alphanum"),
			"what" => array("what","both","alpha"),
			"fpart" => array("fpart","both","int"),
		),
		"wordlets" => array("expirethreads"),
		"user_fields" => "USER_TEXT_EDITOR",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_expirethreads_gpc


function page_expirethreads_run () {

	global $style_array,$html,$smarty,$user,$in,$myinfo,$ubbt_lang,$config,$forumvisit,$visit,$dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	if (!$Main) { $Main = "$Number"; }

	// ------------------------
	// Predefine some variables
	$extra = "";
	$extra_var = "";
	$DefaultBody = $Body;
	
	$Username = $user['USER_DISPLAY_NAME'];
	$query = "
		select t1.FORUM_ID,t1.TOPIC_REPLIES,t2.POST_IS_TOPIC,POST_POSTED_TIME,t1.TOPIC_SUBJECT
		from {$config['TABLE_PREFIX']}TOPICS as t1,
		{$config['TABLE_PREFIX']}POSTS as t2
		where t1.TOPIC_ID = ?
		and t1.TOPIC_ID = t2.TOPIC_ID
	";
	$sth = $dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);
	list($Board,$replies,$is_topic,$posted_on,$subject) = $dbh->fetch_array($sth);

	if (!$Board) {
		$query = "
			select FORUM_ID
			from {$config['TABLE_PREFIX']}TOPICS
			where TOPIC_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);
		list($Board,$first_post) = $dbh->fetch_array($sth);		
	}
	$hasfile = 0;
	$query = "
		select count(*)
		from {$config['TABLE_PREFIX']}FILES
		where FILE_MD5 = ?
		or POST_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($md5_stamp,$Number),__LINE__,__FILE__);
	list($hasfile) = $dbh->fetch_array($sth);
	if ($hasfile) $hasfile = 1;

	// --------------------------
	// Grab the board information
	$query = "
		SELECT FORUM_CUSTOM_HEADER,FORUM_STYLE,FORUM_TITLE,CATEGORY_ID,FORUM_PARENT,FORUM_IS_RSS,FORUM_RSS_TITLE
		FROM   {$config['TABLE_PREFIX']}FORUMS
		WHERE  FORUM_ID = ?
	";
	$sth = $dbh -> do_placeholder_query($query,array($Board),__LINE__,__FILE__);
	list($fheader,$fstyle,$Title,$cat_id,$parent_id,$is_rss,$rss_title) = $dbh -> fetch_array($sth);
	$dbh -> finish_sth($sth);
	
	// -------------------------------------------------
	// Here we need to figure out what stylesheet to use
	if ($fstyle) {
		$html->set_style($fstyle);
	} // end if

	// Smarty variables needed by a variety of templates
	$smarty_data = array(
		"Board" => $Board,
		"what" => $what,
		"Number" => $Number,
		"Approved" => $Approved,
		"Username" => $Username,
		"Main" => $Main,
		"md5_stamp" => $md5_stamp,
	);

	if (!$user['USER_DISPLAY_NAME']) {
		$html -> not_right ($ubbt_lang['NO_AUTH']);
	}

        admin_log("DELETE_TOPIC","<a href='" . make_ubb_url("ubb=postlist&Board=$Board", $Title, false) . "' target='_blank'>$Title</a>: $subject");

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array (
			"title" => $ubbt_lang['PEDIT_DELETE'],
			"refresh" => 0,
			"user" => $user,
			"Board" => $Board,
			"Category" => $cat_id,
			"forum_parent" => $parent_id,
			"custom_header_footer" => $fheader,
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
		),
		"template" => "modifypost_expire",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
