<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_faq_gpc () {
	return array(
		"input" => array(),
		"wordlets" => array("faq"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_faq_gpc

function page_faq_run () {

	global $smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars


	// ---------------------
	// Send the page to them

	$FULL_URL = $config['FULL_URL'];

	$query = "
	SELECT USER_TITLE_POST_COUNT,USER_TITLE_NAME
	FROM {$config['TABLE_PREFIX']}USER_TITLES
	ORDER BY USER_TITLE_ID ASC
	";
	$sth = $dbh->do_query($query);
	$usertitles = "";
	while(list($posts,$title) = $dbh->fetch_array($sth)) {
		$usertitles .= "$posts\t$title<br />";
	}

	if ($config['CONTACT_LINK_TYPE'] == "url") {
		$ubbt_lang['FAQ_BODY'] .= "<a href=\"{$config['CONTACT_URL']}\">{$config['SITE_EMAIL_TITLE']}</a>.";
	}
	else {
		$ubbt_lang['FAQ_BODY'] .= "<a href=\"mailto:{$config['SITE_EMAIL']}\">{$config['SITE_EMAIL_TITLE']}</a>.";
	}

	$rules = @file_get_contents("{$config['FULL_PATH']}/includes/boardrules.php");
	$smarty_data = array(
		"usertitles" => $usertitles,
		"attach" => $attach,
		"rules" => "$rules",
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array (
			"title" => $ubbt_lang['HEAD'],
			"refresh" => 0,
			"user" => "",
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 {$ubbt_lang['HEAD']}
BREADCRUMB
			,
		),
		"template" => "faq",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
