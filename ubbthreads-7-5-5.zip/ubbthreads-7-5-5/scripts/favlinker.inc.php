<?php

//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function &page_favlinker_gpc () {
	return array(
		"input" => array(
			"Entry" => array("Entry","get","int"),
			"F_Board" => array("F_Board","get","alphanum"),
			"Thread" => array("Thread","get","int"),
			"partnumber" => array("partnumber","get","int"),
			"postmarker" => array("postmarker","get"),
		),
		"wordlets" => array("addfav"),
		"user_fields" => "t2.USER_TOPIC_VIEW_TYPE",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_favlinker_gpc

function &page_favlinker_run () {

	global $user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$var_start,$var_eq,$var_sep,$var_extra;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// ------------------------
	// Predefine some variables
	if (!isset($PHPSESSID)) {
		$PHPSESSID = "";
	}

	$html = new html;

	$Board = $F_Board;


	// ----------------------------------------------------------------------------
	// If display is threaded then we need to link to the proper new post, if there
	// is one
	if ( ($postmarker) && ($user['USER_TOPIC_VIEW_TYPE'] == "threaded") ) {
		$Thread = $postmarker;
	}

	// ---------------------------
	// Now send them to the thread
	return array(
		"header" => "",
		"template" => "",
		"data" => "",
		"footer" => false,
		"location" => "show{$user['USER_TOPIC_VIEW_TYPE']}&Board=$Board&Number=$Thread&fpart=$partnumber$postmarker&PHPSESSID=$PHPSESSID",
	);

}

?>
