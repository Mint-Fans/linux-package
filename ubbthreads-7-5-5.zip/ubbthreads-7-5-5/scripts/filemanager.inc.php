<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	You may not distribute "hacks" for UBB without approval from
//	Mindraven
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;
define('NO_WRAPPER',1);
function page_filemanager_gpc () {
	return array(
		"input" => array(
			"id" => array("id","both","alphanum"),
			"delete" => array("delete","get","int"),
			"post_id" => array("post_id","get","int"),
			"init" => array("init","get","int"),
			"description" => array("description","post",""),
			"g" => array("g","both","int"),
			"f" => array("f","both","int"),
			"addit" => array("addit","post","int"),
		),
		"wordlets" => array("filemanager"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_filemanager_gpc

function page_filemanager_run () {

	global $style_array,$smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html,$userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$smarty_data = array();

	// Let's get rid of any old files in the tmp direcotry that are
	// older than 2 hours
	$dir = opendir("{$config['FULL_PATH']}/tmp");
	while( ($file = readdir($dir)) != false) {
		if ( ($file == ".") || ($file == "..") || ($file == "index.html") ) {
			continue;
		}
		$modified = time() - filemtime("{$config['FULL_PATH']}/tmp/$file");
		if ($modified > 7200) {
			@unlink("{$config['FULL_PATH']}/tmp/$file");
		} // end if
	} // end while

	// Get the maximum file/photo attachment size for this forum.
	if ($g) {
		$attach_size = $userob->check_access("forum","GALLERY_SIZE",$f);
	} else {
		$attach_size = $userob->check_access("forum","FILE_SIZE",$f);
	} // end if


	// Get the max upload size in php.ini
	$max_size = ini_get("upload_max_filesize");
  $multi = 1;
	if (preg_match("/K/",$max_size)) $multi = 1024;
	if (preg_match("/M/",$max_size)) $multi = 1048576;
	if (preg_match("/G/",$max_size)) $multi = 1073741824;
	$max_size_num = preg_replace("/(K|M|G| +)/","",$max_size);
	$max_size_bytes = $max_size_num * $multi;

	if ($attach_size > $max_size_bytes) $attach_size = $max_size_bytes;

	// If this is a gallery upload, include the image library
	// also figure out how many photos we can post.
	$max = 0;
	if (!$g) {
		$max = $userob->check_access("forum","FILE_TOTAL",$f);
		$max_message = $html->substitute($ubbt_lang['MAX_ATTACH'], array('NUM_FILE' => $max));
		$maxsize = $attach_size;
		$maxsize_message = $html->substitute($ubbt_lang['MAX_SIZE'], array('FILE_SIZE' => file_size($maxsize)));
	} else {
		$max = $userob->check_access("forum","GALLERY_TOTAL",$f);
		$max_message = $html->substitute($ubbt_lang['MAX_PHOTO'], array('NUM_PHOTO' => $max));
		$maxsize = $attach_size;
		$maxsize_message = $html->substitute($ubbt_lang['MAX_SIZE'], array('FILE_SIZE' => file_size($maxsize)));
		include("{$config['FULL_PATH']}/libs/image.inc.php");
	} // end if



	$user_clause = "and USER_ID = ?";
	$user_var = $user['USER_ID'];

	if ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator" || preg_match("/Moderator/",$user['USER_MEMBERSHIP_LEVEL'])) {
		$user_clause = "";
		$user_var = "";
	}

	if ($init) {
		if ($user_var) {
			$vars = array($id,$post_id,$user_var);
		} else {
			$vars = array($id,$post_id);
		}

		$query = "
			update {$config['TABLE_PREFIX']}FILES
			set FILE_MD5 = ?
			where POST_ID = ?
			$user_clause
		";
		$dbh->do_placeholder_query($query,$vars,__LINE__,__FILE__);
	} // end if

	if ($delete) {
		if ($user_var) {
			$vars = array($delete,$user_var);
		} else {
			$vars = array($delete);
		}
		$query = "
			select FILE_NAME,FILE_DIR
			from {$config['TABLE_PREFIX']}FILES
			where FILE_ID = ?
			$user_clause
		";
		$sth = $dbh->do_placeholder_query($query,$vars,__LINE__,__FILE__);

		list($name,$filedir) = $dbh->fetch_array($sth);
		@unlink("{$config['FULL_PATH']}/tmp/$name");

		if ($filedir) {
			@unlink("{$config['FULL_PATH']}/gallery/$filedir/thumbs/$name");
			@unlink("{$config['FULL_PATH']}/gallery/$filedir/medium/$name");
			@unlink("{$config['FULL_PATH']}/gallery/$filedir/full/$name");
		} else {
			@unlink("{$config['ATTACHMENTS_PATH']}/$name");
		}
		$query = "
			delete from {$config['TABLE_PREFIX']}FILES
			where FILE_ID = ?
		";
		$dbh->do_placeholder_query($query,array($delete),__LINE__,__FILE__);
		header("Location: {$config['FULL_URL']}/ubbthreads.php?ubb=filemanager&id=$id&g=$g&f=$f&post_id=$post_id");
		exit;
	}

	if ( ( ($_FILES['userfile']['name'] == "none") || (!$_FILES['userfile']['name']) && $addit) ){
		//$html->not_right_bare($ubbt_lang['NO_FILE']);
	} // end if


	// We have a file, deal with it
	// Let's see how many files we already have
	$query = "
		select count(*)
		from {$config['TABLE_PREFIX']}FILES
		where FILE_MD5 = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($id),__LINE__,__FILE__);
	list($filecount) = $dbh->fetch_array($sth);

	if ($filecount >= $max && ($max != $ubbt_lang['UNLIMITED']) && !$post_id) {
		$html->not_right_bare($html->substitute($ubbt_lang['TOO_MANY'], array('NUM_ATTACH' => $max)));
	} // end if

	// --------------------------------------
	// Let's see if we want this type of file
	$hasfile = 0;
	if (isset($_FILES['userfile'])) {
		if ( ($_FILES['userfile']['name'] != "none") && ($_FILES['userfile']['name']) ){
			$hasfile = 1;
			if ((preg_match("/\.(php|php3|php4|cgi|pl|exe|bat|reg)$/i",$_FILES['userfile']['name'])) && !$g) {
				$html -> not_right_bare("{$ubbt_lang['FILESALLOWED']}: {$config['ATTACHMENT_TYPES']}");
			}
			$checkfile = str_replace(",","|",$config['ATTACHMENT_TYPES']);
			// Standard file check
			if ((!preg_match("/($checkfile)$/i",$_FILES['userfile']['name'])) && !$g) {
				$html -> not_right_bare("{$ubbt_lang['FILESALLOWED']}: {$config['ATTACHMENT_TYPES']}");
			}
			// Gallery file check
			if ($g && (!preg_match("/(.gif|.jpg|.png|.jpeg|.jpe)$/i",$_FILES['userfile']['name']))) {
				$html->not_right_bare($ubbt_lang['GALLERYFILES']);
			} // end if
		}

		// Normal file attachment filesize check
		if (!$g && ($_FILES['userfile']['size'] > $attach_size) ) {
			$html -> not_right_bare($html->substitute($ubbt_lang['FILE_TOO_BIG'], array('FILE_SIZE' => file_size($attach_size))));

		}
		if ($g && ($_FILES['userfile']['size'] > $attach_size)) {
			$html->not_right_bare($html->substitute($ubbt_lang['PIC_TOO_BIG'], array('PIC_SIZE' => file_size($attach_size))));
		}

		// No file size at all, exceeded php.ini setting
		if ($_FILES['userfile']['size'] == 0) {
			$html->not_right_bare($html->substitute($ubbt_lang['INI_TOO_BIG'], array('FILE_SIZE' => file_size($attach_size))));
		} // end if


		if ( ($_FILES['userfile']['name'] != "none") && ($_FILES['userfile']['name']) ){

			$ext = explode('.', $_FILES['userfile']['name']);
			$ext = strtolower($ext[count($ext)-1]);

			$query_vars = array(time(), $ext, $_FILES['userfile']['size'], $id, $user['USER_ID'], $description);
			$query = "
				insert into {$config['TABLE_PREFIX']}FILES
				(FILE_ADD_TIME,FILE_TYPE,FILE_SIZE,FILE_MD5,USER_ID,FILE_DESCRIPTION)
				values
				( ? , ? , ? , ? , ? , ? )
			";
			$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
			$query = "
				select last_insert_id()
			";
			$sth = $dbh->do_query($query);
			list($file_id) = $dbh->fetch_array($sth);

			$FileName = "{$_FILES['userfile']['name']}";
			$FileName = htmlspecialchars(stripslashes($FileName));
			$newname = "{$file_id}.{$ext}";

			move_uploaded_file($_FILES['userfile']['tmp_name'], "{$config['FULL_PATH']}/tmp/$newname");
			chmod("{$config['FULL_PATH']}/tmp/$newname",0666);

			// If this is an image, let's make sure it's a valid
			// one
			if (preg_match("#gif|jpg|png|bmp#is",$ext)) {
				$fp = fopen("{$config['FULL_PATH']}/tmp/$newname");
				if ($fp) {
					$header = fread($fp, 200);
					fclose($fp);
					if (preg_match("#<head|<html|<body|<script#is", $header)) {
						unlink("{$config['FULL_PATH']}/tmp/$newname");
						$query = "
							delete from {$config['TABLE_PREFIX']}FILES
							where FILE_ID = ?
						";
						$dbh->do_placeholder_query($query,array($file_id),__LINE__,__FILE__);
						$html->not_right_bare($ubbt_lang['MALFORMED_PIC']);
					} // end if
				} // end if
			} // end if


			// If this is a gallery upload, resize
			if ($g) {
				resize_image("thumb",$newname);
				resize_image("medium",$newname);
				list($newfilename,$width,$height) = resize_image("full",$newname);
				unlink("{$config['FULL_PATH']}/tmp/$newname");
				$file_size = filesize("{$config['FULL_PATH']}/tmp/$newfilename.full");
				$newname = $newfilename;
			}
			if (!$file_size) {
				$file_size = filesize("{$config['FULL_PATH']}/tmp/$newname");
			} // end if

			$query = "
				UPDATE {$config['TABLE_PREFIX']}FILES
				SET    FILE_NAME = ?,
				       FILE_ORIGINAL_NAME = ? ,
				       FILE_WIDTH = ? ,
				       FILE_HEIGHT = ? ,
					   FILE_SIZE = ?
				WHERE  FILE_ID = ?
			";
			$dbh -> do_placeholder_query($query,array($newname,$FileName,$width + 0,$height + 0,$file_size,$file_id),__LINE__,__FILE__);
		}

	}

	$query = "
		select FILE_ID,FILE_ORIGINAL_NAME
		from {$config['TABLE_PREFIX']}FILES
		where FILE_MD5 = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($id),__LINE__,__FILE__);
	$files = array();
	while(list($file_id,$file_name) = $dbh->fetch_array($sth)) {
		$files[] = array(
			"ID" => $file_id,
			"NAME" => $file_name,
		);
	} // end while

	$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";

	$bad_id = false;
	if (!$id) {
		$bad_id = true;
	} // end if



	$totalfiles = sizeof($files);
	if (!sizeof($files)) $files = "";


	$smarty_data = array(
		"stylesheet" => $stylesheet,
		"files" => $files,
		"bad_id" => $bad_id,
		"id" => $id,
		"totalfiles" => $totalfiles,
		"g" => $g,
		"f" => $f,
		"max_message" => $max_message,
		"maxsize_message" => $maxsize_message,
		"post_id" => $post_id,
	);


	return array(
		"header" => array (
			"title" => "",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => "",
		),
		"template" => "filemanager",
		"data" => & $smarty_data,
		"footer" => false,
		"location" => "",
	);

}

?>
