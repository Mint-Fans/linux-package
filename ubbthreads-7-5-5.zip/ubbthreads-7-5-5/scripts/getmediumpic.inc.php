<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;
define('NO_WRAPPER',1);
function page_getmediumpic_gpc () {
	return array(
		"input" => array(
			"id" => array("id","both","int"),
		),
		"wordlets" => array(),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
		"no_session" => 1,
	);
} // end page_getmediumpic_gpc

function page_getmediumpic_run () {

	global $style_array,$smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$query = "
		select FILE_NAME,FILE_ORIGINAL_NAME,FILE_DIR,FILE_WIDTH,FILE_HEIGHT,FILE_DESCRIPTION,FILE_TYPE,FILE_SIZE
		from {$config['TABLE_PREFIX']}FILES
		where FILE_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($id),__LINE__,__FILE__);
	list($name,$name_orig,$dir,$width,$height,$description,$type,$size) = $dbh->fetch_array($sth);
	$description = htmlspecialchars($description);
	if (!$description) {
		$link = $name_orig;
		$description = "&nbsp;";
	} else {
		$link = preg_replace("/ +/","_",$description) . ".$type";
	} // end if

	$link = htmlentities(preg_replace("/</","&lt;",$link));
	
	$description = str_replace("&","&amp;",$description);
	$link = str_replace("&","&amp;",$link);
	

	header('Content-type: text/xml');
	echo "<?xml version=\"1.0\" ?>";
	echo "<imgdata>";
	echo "<imgsrc>{$config['FULL_URL']}/gallery/$dir/medium/$id.$type</imgsrc>";
	echo "<width>$width</width>";
	echo "<height>$height</height>";
	echo "<id>$id</id>";
	echo "<description>$description</description>";
	echo "<thumb>[img]{$config['FULL_URL']}/gallery/{$dir}/thumbs/{$id}.{$type}[/img]</thumb>";
	echo "<medium>[img]{$config['FULL_URL']}/gallery/{$dir}/medium/{$id}.{$type}[/img]</medium>";
	echo "<full>[img]{$config['FULL_URL']}/gallery/{$dir}/full/{$id}.{$type}[/img]</full>";
	echo "<size>" . file_size($size) . "</size>";
	echo "</imgdata>";
	return false;

}

?>
