<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_grabnext_gpc () {
	return array(
		"input" => array(
			"Board" => array("Board","get","alphanum"),
			"dir" => array("dir","get","alpha"),
			"posted" => array("posted","get","int"),
			"sb" => array("sb","get","int"),
			"o" => array("o","get","int"),
			"mode" => array("mode","get","alpha"),
			"sticky" => array("sticky","get","int"),
		),
		"wordlets" => array("grabnext"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_grabnext_gpc

function page_grabnext_run () {

	global $user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars
	
	$number = "";
	
	// Check if this is a gallery forum and get sort order
	$query = "
		select FORUM_IS_GALLERY,FORUM_SORT_FIELD
		from {$config['TABLE_PREFIX']}FORUMS
		where FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($Board),__LINE__,__FILE__);
	list($is_gallery,$sort) = $dbh->fetch_array($sth);

	if ($_SESSION['myprefs']['sort']) {
		$sort = $_SESSION['myprefs']['sort'];
	} // end if

	if (!$sort) $sort = "last";


	// Figure out the sorting options                
	switch($sort) {
		case "subject":
			$sort_by = "t2.TOPIC_SUBJECT";
			break;
		case "starter":
			$sort_by = "t3.USER_DISPLAY_NAME";
			break;     
		case "replies":
			$sort_by = "t2.TOPIC_REPLIES";
			break;
		case "views":
			$sort_by = "t2.TOPIC_VIEWS";
			break;
		case "start":
			$sort_by = "t2.TOPIC_CREATED_TIME";
			break;
		case "last":
			$sort_by = "t2.TOPIC_LAST_REPLY_TIME";
			break;
		default:
			$sort_by = "t2.TOPIC_LAST_REPLY_TIME";
	}

	$sort_by .= " $order";

	// --------------------
	// Grab the next newest
	if ($dir == "old") {
		$number = "";
		if (!$sticky) {

			$query = "
			SELECT t2.POST_ID,t2.TOPIC_IS_STICKY
			FROM {$config['TABLE_PREFIX']}POSTS as t1,
			{$config['TABLE_PREFIX']}TOPICS as t2,
			{$config['TABLE_PREFIX']}USERS as t3
			WHERE t2.FORUM_ID = ?
			AND t2.TOPIC_IS_STICKY='0'
			AND t2.TOPIC_LAST_REPLY_TIME > ?
			AND t1.TOPIC_ID = t2.TOPIC_ID
			AND t2.USER_ID = t3.USER_ID 
			ORDER BY $sort_by
			LIMIT 1
			";
			$sth = $dbh -> do_placeholder_query($query,array($Board,$posted),__LINE__,__FILE__);
			list($number,$newsticky) = $dbh->fetch_array($sth);
		}

		if (($sticky || !$number) && !$is_gallery) {
			$extra = "";
			
			$query_vars = array($Board);
			if ($sticky) {
				$extra = "AND t2.TOPIC_LAST_REPLY_TIME > ? ";
				array_push($query_vars,$posted);
			}
			$query = "
			SELECT t2.POST_ID,t2.TOPIC_IS_STICKY
			FROM {$config['TABLE_PREFIX']}POSTS as t1,
			{$config['TABLE_PREFIX']}TOPICS as t2,
			{$config['TABLE_PREFIX']}USERS as t3,
			{$config['TABLE_PREFIX']}FORUMS as t4
			WHERE ((t2.FORUM_ID = ? AND t2.TOPIC_IS_STICKY='1')
			OR (t2.TOPIC_IS_STICKY='2' AND t4.FORUM_IS_TEASER = '0'))
			$extra
			AND t1.TOPIC_ID = t2.TOPIC_ID
			AND t2.USER_ID = t3.USER_ID
			ORDER BY $sort_by
			LIMIT 1
			";
			$sth = $dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
			list($number,$newsticky) = $dbh->fetch_array($sth);
		}

	}

	// --------------------
	// Grab the next oldest
	if ($dir == "new") {
		$number = "";
		if ($sticky && !$is_gallery) {
			$query = "
			SELECT t2.POST_ID,t2.TOPIC_IS_STICKY
			FROM {$config['TABLE_PREFIX']}POSTS as t1,
			{$config['TABLE_PREFIX']}TOPICS as t2,
			{$config['TABLE_PREFIX']}USERS as t3
			WHERE ((t2.FORUM_ID = ? AND t2.TOPIC_IS_STICKY='1')
			OR t2.TOPIC_IS_STICKY='2')
			AND t2.TOPIC_LAST_REPLY_TIME < ?
			AND t1.TOPIC_ID = t2.TOPIC_ID
			AND t2.USER_ID = t3.USER_ID
			ORDER BY $sort_by desc
			LIMIT 1
			";
			$sth = $dbh -> do_placeholder_query($query,array($Board,$posted),__LINE__,__FILE__);
			list($number,$newsticky) = $dbh->fetch_array($sth);
		}

		if (!$number) {
			$extra = "";
			$query_vars = array($Board);
			if (!$sticky) {
				$extra = "AND t2.TOPIC_LAST_REPLY_TIME < ?";
				array_push($query_vars,$posted);
			}
			$query = "
			SELECT t2.POST_ID,t2.TOPIC_IS_STICKY
			FROM {$config['TABLE_PREFIX']}POSTS as t1,
			{$config['TABLE_PREFIX']}TOPICS as t2,
			{$config['TABLE_PREFIX']}USERS as t3
			WHERE t2.FORUM_ID = ?
			AND t2.TOPIC_IS_STICKY='0'
			$extra
			AND t1.TOPIC_ID = t2.TOPIC_ID
			AND t2.USER_ID = t3.USER_ID
			ORDER BY $sort_by desc
			LIMIT 1
			";
			$sth = $dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
			list($number,$newsticky) = $dbh->fetch_array($sth);
		}
	}

	if (!$number) {
		$html = new html;
		$html->not_right($ubbt_lang['NOMORE']);
	}
	$an = "";
	if ($newsticky == 2) {
		$an = "&an=$Board";
	}
	
	return array(
		"header" => "",
		"template" => "",
		"data" => "",
		"footer" => false,
		"location" => "$mode&Number=$number$an",
	);

}

?>
