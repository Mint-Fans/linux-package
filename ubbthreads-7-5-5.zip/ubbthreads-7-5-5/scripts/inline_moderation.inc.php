<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_inline_moderation_gpc () {
	return array(
		"input" => array(
			"forum" => array("Board","post","int"),
			"topics" => array("check-inline","post",""),
			"do" => array("do","post","alpha"),
			"page" => array("page","post","int"),

			// For topic moving
			"number" => array("number","post","int"),
			"forum_dest" => array("Keyword","post","int"),
			"pointer" => array("pointer","post","int"),
			"reason" => array("reason","post",""),
			"delete" => array("delete","post","int"),
			"days" => array("days","post","int"),
			"type" => array("type","post","alpha"),
			"merge" => array("merge","post","int"),
		),
		"wordlets" => array('inline_moderation',"approvepost","movethread"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 1,
	);
} // end page_download_gpc

function page_inline_moderation_run () {
	global $userob, $user, $in, $ubbt_lang, $config, $dbh, $html, $tree;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$perm_map = array(
		'approve' => 'APPROVE_ANY',
		'stick' => 'STICKY_ANY',
		'announce' => 'MODERATOR_CAN_STICK_POSTS',  //FIXME
		'unstick' => 'STICKY_ANY',
		'close' => 'LOCK_ANY',
		'open' => 'LOCK_ANY',
		'delete' => 'DELETE_TOPICS',
		'dodelete' => 'DELETE_TOPICS',
		'move' => 'MOVE_ANY',
		'domove' => 'MOVE_ANY',
		'edit' => 'EDIT_ANY'
	);

	if ($do == "announce") {
		if (!$userob->check_access("site","ANNOUNCEMENTS")) {
			$html->not_right("You do not have permission to perform that action.");
		}
	} else {
		if (!$userob->check_access("forum",$perm_map[$do],$forum)) {
			$html->not_right("You do not have permission to perform that action.");
		}
	}

	if (!is_array($in['topics'])) {
		$html->not_right("You did not select any topics for moderation");
	}

	foreach ($in['topics'] as $k => $v) {
		if (!is_numeric($v)) {
			unset($in['topics'][$k]);
		}
	}

	// Verify that all of the topics specified are from this forum.
	// This happens to weed out announcements, which I'm ok with.
	$query = "
		SELECT	t.POST_ID
		FROM	{$config['TABLE_PREFIX']}POSTS as p
		LEFT JOIN {$config['TABLE_PREFIX']}TOPICS as t
		ON p.TOPIC_ID = t.TOPIC_ID
		WHERE t.FORUM_ID = ? AND p.POST_ID in ( ? ) and p.POST_IS_TOPIC = '1'
	";

	$sth = $dbh->do_placeholder_query($query, array($in['forum'], $in['topics']), __LINE__, __FILE__);

	$in['topics'] = array();

	while ($result = $dbh->fetch_array($sth)) {
		$in['topics'][] = $result['POST_ID'];
	}

	if (count($in['topics']) == 0) {
		$html->not_right("You did not select any valid topics.");
	}

	$func = sprintf("_inline_%s", $in['do']);
	if (function_exists($func)) {
		return $func();
	}

	$html->not_right("I do not know how to handle that action.");
}

function _inline_move() {
	global $config, $dbh, $ubbt_lang, $html, $in, $userob;



	// Grab some info about the topic so they really know what they're deleting
	$query = "
		SELECT	p.POST_ID, t.TOPIC_ID, f.FORUM_ID, f.FORUM_TITLE, t.TOPIC_SUBJECT, t.TOPIC_REPLIES,
			t.TOPIC_LAST_REPLY_TIME, p.POST_SUBJECT,t.TOPIC_VIEWS
		FROM	{$config['TABLE_PREFIX']}POSTS as p
		LEFT JOIN {$config['TABLE_PREFIX']}TOPICS as t on t.TOPIC_ID = p.TOPIC_ID
		LEFT JOIN {$config['TABLE_PREFIX']}FORUMS as f on f.FORUM_ID = t.FORUM_ID
		WHERE	p.POST_IS_TOPIC = '1' AND p.POST_ID in ( ? )
    AND t.TOPIC_IS_STICKY = '0'
	";

	$topics = array();
	$total_posts = 0;

	$sth = $dbh->do_placeholder_query($query, array($in['topics']), __LINE__, __FILE__);
	while ($result = $dbh->fetch_array($sth)) {
		$total_posts += $result['TOPIC_REPLIES'] + 1;
		$result['TOPIC_REPLIES'] = $html->substitute($ubbt_lang['NUM_POSTS_MOV'], array('POSTS' => $result['TOPIC_REPLIES'] + 1));
		$topics[] = $result;
	}
	$dbh->finish_sth($sth);

	$query = "
		SELECT	FORUM_IS_GALLERY
		FROM	{$config['TABLE_PREFIX']}FORUMS
		WHERE	FORUM_ID = ?
	";

	$sth = $dbh->do_placeholder_query($query, array($in['forum']), __LINE__, __FILE__);
	list($is_gallery) = $dbh->fetch_array($sth);
	$dbh->finish_sth($sth);

	if (!sizeof($tree)) {
		list($tree,$style_cache,$lang_cache) = build_forum_cache();
	}

	$query = "
		select FORUM_ID,FORUM_IS_GALLERY
		from {$config['TABLE_PREFIX']}FORUMS
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	$forum_array = array();

	while($result = $dbh->fetch_array($sth)) {
		$forum_array[$result['FORUM_ID']] = $result['FORUM_IS_GALLERY'];
	}
	$dbh->finish_sth($sth);

	$options = "";
	$category = "";
	$forums = 0;
	foreach($tree['categories'] as $cat => $cat_title) {
		$category = "";
		$forums = 0;
		$category .= "<option value=\"category\">$cat_title ------</option>";
		if (!isset($tree[$cat])) continue;
		foreach($tree[$cat] as $forum_id => $forum_title) {
			if ($is_gallery && $forum_array[$forum_id] == 0) continue;
			if (!$is_gallery && $forum_array[$forum_id] ==1) continue;

			if (!$userob->check_access("forum","SEE_FORUM",$forum_id) || $tree['active'][$forum_id] != 1) { continue; }
			$category .= "<option value=\"$forum_id\">$forum_title</option>";
			$forums++;
		}
		if ($forums) $options .= $category;
	}

	$days = "";
	for ($i=1;$i<32;$i++) {
		$days .= "<option value=\"$i\">$i</option>";
	} // end for

	$smarty_data = array(
		"forums" => & $options,
		"days" => $days,
		'topics' => $topics,
		'Board' => $in['forum'],
		'page' => $in['page'],
		'totalposts' => $total_posts,
		'is_gallery' => $is_gallery,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array (
			"title" => $ubbt_lang['CONFIRM_MOVE'],
			"refresh" => 0,
			"javascript" => array(),
			"bypass" => "",
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> &raquo; {$ubbt_lang['CONFIRM_MOVE']}
BREADCRUMB
			,
		),
		"template" => "inline_move",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

function _inline_domove() {
	global $config, $dbh, $ubbt_lang, $html, $in, $userob;

//	print_r($in);
//	exit;

	if ($in['type'] == "merge") {
		$query = "
			SELECT	FORUM_ID
			FROM	{$config['TABLE_PREFIX']}TOPICS
			WHERE	POST_ID = ?
		";

		$sth = $dbh->do_placeholder_query($query, array($in['number']), __LINE__, __FILE__);
		$result = $dbh->fetch_array($sth, MYSQL_ASSOC);

		if (!$result) {
			$html->not_right($ubbt_lang['INVALID_MERGE_DEST']);
		}

		$in['forum_dest'] = $result['FORUM_ID'];
		$dbh->finish_sth($sth);
	}

	if ((!$in['forum_dest']) || $in['forum_dest'] == "category" || !$userob->check_access("forum","SEE_FORUM",$in['forum_dest'])) {
		$html->not_right($ubbt_lang['INVALID_DEST']);
	}


	$query = "
		SELECT	FORUM_IS_GALLERY, FORUM_ID
		FROM	{$config['TABLE_PREFIX']}FORUMS
		WHERE	FORUM_ID = ? OR FORUM_ID = ?
		LIMIT	2
	";

	$sth = $dbh->do_placeholder_query($query, array($in['forum'], $in['forum_dest']), __LINE__, __FILE__);

	$is_gallery = '';
	$i = 0;
	while ($result = $dbh->fetch_array($sth)) {
		if ($is_gallery != '' && $result['FORUM_IS_GALLERY'] != $is_gallery) {
			$dbh->finish_sth($sth);
			$html->not_right($ubbt_lang['INLINE_FORUM_MIXED_TYPE']);
		}

		$is_gallery = $result['FORUM_IS_GALLERY'];

		$i++;
	}

	//print sprintf("%s|%s|%s", $i, $in['forum'], $in['forum_dest']);

	if ($i !== 2 && $in['type'] == "move") {
		$html->not_right($ubbt_lang['INLINE_INVALID_FORUM']);
	}

	if ($in['type'] == "merge") {
		// Are we merging into a valid post?
		if (in_array($in['number'], $in['topics'])) {
			$html->not_right($ubbt_lang['INVALID_MERGE_DEST']);
		}

		$query = "
			SELECT	COUNT(POST_ID) AS COUNT
			FROM	{$config['TABLE_PREFIX']}POSTS
			WHERE	POST_ID = ?
		";

		$sth = $dbh->do_placeholder_query($query, array($in['number']), __LINE__, __FILE__);
		$tmp = $dbh->fetch_array($sth, MYSQL_ASSOC);


		if ($tmp['COUNT'] == 0) {
			// That post doesn't exist
			$html->not_right($ubbt_lang['INVALID_MERGE_DEST']);
		}
	}

	if ($in['pointer']) {
		// We need to leave a pointer

		// FOREACH $TOPIC:
		//	Create the body of the pointer
		//	INSERT THE POINTER
		//	Grab the TOPIC_ID of the pointer
		//	IF $DELETE:
		//		Add TOPIC_ID to POINTER_DELETE
		//	INSERT THE POINTER BODY
		//	CONNECT POST_ID TO TOPIC_ID

		foreach ($in['topics'] as $topic) {
			$body = "";
			if ($in['type'] == "merge") {
				$body = sprintf('%d-ML-%d-ML-<br /><br />%s', $in['forum_dest'], $topic, $reason);
			} else {
				$body = sprintf('%d-MERGE-%d-MERGE-<br /><br />%s', $in['forum_dest'], $topic, $reason);
			}

			$query = "
				SELECT	TOPIC_LAST_REPLY_TIME, TOPIC_SUBJECT, TOPIC_ICON, USER_ID
				FROM	{$config['TABLE_PREFIX']}TOPICS
				WHERE	POST_ID = ?
			";

			$sth = $dbh->do_placeholder_query($query, array($topic), __LINE__, __FILE__);
			$result = $dbh->fetch_array($sth, MYSQL_ASSOC);
			$dbh->finish_sth($sth);

			$query_vars = array(
				$in['forum_dest'], 0, $result['USER_ID'], $result['TOPIC_SUBJECT'], $result['TOPIC_LAST_REPLY_TIME'],
				1, 'M', 0, $result['TOPIC_LAST_REPLY_TIME'], 0, 0
			);

			$query = "
				INSERT INTO {$config['TABLE_PREFIX']}TOPICS
				(FORUM_ID, POST_ID, USER_ID, TOPIC_SUBJECT, TOPIC_CREATED_TIME, TOPIC_IS_APPROVED, TOPIC_STATUS, TOPIC_IS_STICKY, TOPIC_LAST_REPLY_TIME, TOPIC_HAS_FILE, TOPIC_HAS_POLL)
				VALUES
				( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )
			";

			$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
			$topic_id = $dbh->last_insert_id(__LINE__, __FILE__);

			$query = "
				INSERT INTO {$config['TABLE_PREFIX']}POSTS
				(POST_PARENT_ID, TOPIC_ID, POST_IS_TOPIC, POST_POSTED_TIME, POST_POSTER_IP, POST_SUBJECT, POST_BODY, POST_DEFAULT_BODY, POST_IS_APPROVED, POST_ICON, USER_ID)
				VALUES
				( ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? )
			";

			$query_vars = array(
				0, $topic_id, 1, $result['TOPIC_LAST_REPLY_TIME'], 1, $result['TOPIC_SUBJECT'],
				$body, $body, 1, $result['TOPIC_ICON'], $result['USER_ID']
			);

			$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
			$post_id = $dbh->last_insert_id(__LINE__, __FILE__);

			$query = "
				UPDATE	{$config['TABLE_PREFIX']}TOPICS
				SET	POST_ID = ?
				WHERE	TOPIC_ID = ?
			";
			$dbh->do_placeholder_query($query, array($post_id, $topic_id), __LINE__, __FILE__);

			if ($in['delete']) {
				$date = $html->get_date() + ($in['days'] * 86400);

				$query = "
					INSERT INTO {$config['TABLE_PREFIX']}POINTER_DELETE
					(TOPIC_ID, DELETE_ON)
					VALUES
					( ?, ? )
				";

				$dbh->do_placeholder_query($query, array($topic_id, $date), __LINE__, __FILE__);
			}

			rebuild_topic_data($topic_id);
		}
	} // end if ($in['pointer'])

	// Figure out the topic ids of the posts we're merging from
	// and grab current topic views
	$query = "
		SELECT	TOPIC_ID,TOPIC_VIEWS
		FROM	{$config['TABLE_PREFIX']}TOPICS
		WHERE	POST_ID in ( ? )
	";

	$topics = array();
	$views = 0;
	$sth = $dbh->do_placeholder_query($query, array($in['topics']), __LINE__, __FILE__);
	while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
		$topics[] = $result['TOPIC_ID'];
		$views = $views + $result['TOPIC_VIEWS'];
	}

	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}WATCH_LISTS
		WHERE	WATCH_ID in ( ? ) AND WATCH_TYPE = 't'
	";
	$dbh->do_placeholder_query($query, array($topics), __LINE__, __FILE__);

	if ($in['type'] == "move") {
		$query = "
			UPDATE	{$config['TABLE_PREFIX']}TOPICS
			SET	FORUM_ID = ?
			WHERE	FORUM_ID = ? AND POST_ID in ( ? )
		";

		$dbh->do_placeholder_query($query, array($in['forum_dest'], $in['forum'], $in['topics']), __LINE__, __FILE__);
	} else if ($in['type'] == "merge") {
		// Figure out the topic id of the post we're merging into
		$query = "
			SELECT	t1.TOPIC_ID,t1.TOPIC_VIEWS
			FROM	{$config['TABLE_PREFIX']}POSTS as t2,
			        {$config['TABLE_PREFIX']}TOPICS as t1
			WHERE	t2.POST_ID = ?
			AND     t1.TOPIC_ID = t2.TOPIC_ID
		";

		$sth = $dbh->do_placeholder_query($query, array($in['number']), __LINE__, __FILE__);
		list($topic_id,$c_views) = $dbh->fetch_array($sth, MYSQL_BOTH);
		$views = $views + $c_views;

		$query = "
			update {$config['TABLE_PREFIX']}TOPICS
			set TOPIC_VIEWS = ?
			where TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query,array($views,$topic_id),__LINE__,__FILE__);

		$query = "
			UPDATE	{$config['TABLE_PREFIX']}POSTS
			SET	POST_PARENT_ID = ?,
				POST_IS_TOPIC = 0,
				TOPIC_ID = ?
			WHERE	POST_ID in ( ? )
		";

		$dbh->do_placeholder_query($query, array($in['number'], $topic_id, $in['topics']), __LINE__, __FILE__);

		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}TOPICS
			WHERE	TOPIC_ID in ( ? )
		";

		$dbh->do_placeholder_query($query, array($topics), __LINE__, __FILE__);

		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}ANNOUNCEMENTS
			WHERE	TOPIC_ID in ( ? )
		";

		$dbh->do_placeholder_query($query, array($topics), __LINE__, __FILE__);

		$query = "
			UPDATE	{$config['TABLE_PREFIX']}POSTS
			SET	TOPIC_ID = ?,
			POST_IS_TOPIC = 0
			WHERE	TOPIC_ID in ( ? )
		";

		$dbh->do_placeholder_query($query, array($topic_id, $topics), __LINE__, __FILE__);

		rebuild_topic_data($topic_id);
	} else {
		// WTF CHARLES?!
		$html->not_right("MERGE OR DELETE, YOU MUST PICK ONE!");
	}

	// Rebuild the forums
	if ($in['forum'] != $in['forum_dest']) {
		rebuild_forum_data($in['forum_dest']);
		rebuild_forum_data($in['forum']);
	}

	// Rebuild the islands
	rebuild_islands(0);

	$html->send_redirect(
		array(
			'redirect' => "postlist&Board={$in['forum']}&page={$in['page']}",
			'returnlink' => sprintf('<a href="%s">%s</a>', make_ubb_url("ubb=postlist&Board={$in['forum_dest']}&page=1",'', false), $ubbt_lang['INLINE_RETURN']),
			'heading' => $ubbt_lang['CONFIRMED_GENERIC'],
			'body' => ($in['type'] == "merge") ? $ubbt_lang['CONFIRMED_MERGE'] : $ubbt_lang['CONFIRMED_MOVE'],
		)
	);
}

function _inline_dodelete() {
	global $config, $dbh, $ubbt_lang, $html, $in;

	// Steps:
	//	Delete attachments, including gallery stuff
	//	Delete entries in attachment database
	//	Delete all posts in the topic
	//	Decrement forum counter by # of posts deleted, that were approved
	//	Delete from watch lists
	//	Delete from announcements
	//	Delete from polls


	$topic_ids = array();
	$posts_approved = 0;
	$topics_approved = 0;
	$post_ids = array();



	// Grab the TOPIC_ID of each post that'll be deleted.
	$query = "
		SELECT	TOPIC_ID, TOPIC_IS_APPROVED
		FROM	{$config['TABLE_PREFIX']}TOPICS
		WHERE	POST_ID in ( ? )
	";

	$sth = $dbh->do_placeholder_query($query, array($in['topics']), __LINE__, __FILE__);
	while ($result = $dbh->fetch_array($sth)) {
		if ($result['TOPIC_IS_APPROVED'] == '1') {
			$topics_approved++;
		}

		$topic_ids[] = $result['TOPIC_ID'];
	}

	// Grab the POST_ID of each post that'll be deleted.
	$query = "
		SELECT	p.POST_ID, p.POST_IS_APPROVED, f.FORUM_TITLE, p.POST_SUBJECT
		FROM	{$config['TABLE_PREFIX']}POSTS as p,
			{$config['TABLE_PREFIX']}TOPICS as t,
			{$config['TABLE_PREFIX']}FORUMS as f
		WHERE	t.TOPIC_ID in ( ? ) AND t.FORUM_ID = f.FORUM_ID and t.TOPIC_ID = p.TOPIC_ID
	";


	$sth = $dbh->do_placeholder_query($query, array($topic_ids), __LINE__, __FILE__);
	while ($result = $dbh->fetch_array($sth)) {
		if ($result['POST_IS_APPROVED'] == '1') {
			$posts_approved++;
		}

		admin_log("DELETE_POST","<a href='" . make_ubb_url("ubb=postlist&Board={$in['forum']}", $result['FORUM_TITLE'], false) . "' target='_blank'>{$result['FORUM_TITLE']}</a>: {$result['POST_SUBJECT']}");

		$post_ids[] = $result['POST_ID'];
	}
	$dbh->finish_sth($sth);

	// Remove all attachments related to these posts
	$query = "
		SELECT	FILE_NAME, FILE_DIR
		FROM	{$config['TABLE_PREFIX']}FILES
		WHERE	POST_ID in ( ? )
	";

	$sth = $dbh->do_placeholder_query($query, array($post_ids), __LINE__, __FILE__);
	while ($result = $dbh->fetch_array($sth)) {
		if (!$result['FILE_DIR']) {
			@unlink("{$config['ATTACHMENTS_PATH']}/{$result['FILE_NAME']}");
		} else {
			@unlink("{$config['FULL_PATH']}/gallery/{$result['FILE_DIR']}/full/{$result['FILE_NAME']}");
			@unlink("{$config['FULL_PATH']}/gallery/{$result['FILE_DIR']}/medium/{$result['FILE_NAME']}");
			@unlink("{$config['FULL_PATH']}/gallery/{$result['FILE_DIR']}/thumbs/{$result['FILE_NAME']}");
		}
	}
	$dbh->finish_sth($sth);


	// Remove attachment entries for each post
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}FILES
		WHERE	POST_ID in ( ? )
	";

	$dbh->do_placeholder_query($query, array($post_ids), __LINE__, __FILE__);

	// Delete the posts themselves
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}POSTS
		WHERE	POST_ID in ( ? )
	";

	$dbh->do_placeholder_query($query, array($post_ids), __LINE__, __FILE__);

	// Delete the topics
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}TOPICS
		WHERE	TOPIC_ID in ( ? )
	";

	$dbh->do_placeholder_query($query, array($topic_ids), __LINE__, __FILE__);

	// Delete from watch lists
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}WATCH_LISTS
		WHERE WATCH_ID in ( ? ) AND WATCH_TYPE = 't'
	";

	$dbh->do_placeholder_query($query, array($topic_ids), __LINE__, __FILE__);

	// Delete from announcements
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}ANNOUNCEMENTS
		WHERE TOPIC_ID in ( ? )
	";
	$dbh->do_placeholder_query($query, array($topic_ids), __LINE__, __FILE__);

	// Delete from polls
	$query = "
		SELECT	POLL_ID
		FROM	{$config['TABLE_PREFIX']}POLL_DATA
		WHERE	POST_ID in ( ? )
	";

	$poll_ids = array();

	$sth = $dbh->do_placeholder_query($query, array($post_ids), __LINE__, __FILE__);
	while ($result = $dbh->fetch_array($sth)) {
		$poll_ids[] = $result['POLL_ID'];
	}
	$dbh->finish_sth($sth);

	if (count($poll_ids) > 0) {
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}POLL_DATA
			WHERE POLL_ID in ( ? )
		";

		$dbh->do_placeholder_query($query, array($poll_ids), __LINE__, __FILE__);


		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}POLL_OPTIONS
			WHERE POLL_ID in ( ? )
		";
		$dbh->do_placeholder_query($query, array($poll_ids), __LINE__, __FILE__);


		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}POLL_VOTES
			WHERE POLL_ID in ( ? )
		";
		$dbh->do_placeholder_query($query, array($poll_ids), __LINE__, __FILE__);
	}

	// Rebuild the islands
	rebuild_islands(0);

	// Rebuild the forum
	rebuild_forum_data($in['forum']);

	$html->send_redirect(
		array(
			'redirect' => "postlist&Board={$in['forum']}&page={$in['page']}",
			'returnlink' => sprintf('<a href="%s">%s</a>', make_ubb_url("ubb=postlist&Board={$in['forum']}&page={$in['page']}",'', false), $ubbt_lang['INLINE_RETURN']),
			'heading' => $ubbt_lang['CONFIRMED_GENERIC'],
			'body' => $ubbt_lang['CONFIRMED_DELETE'],
		)
	);
}

function _inline_delete() {
	global $config, $dbh, $ubbt_lang, $html, $in;

	// Grab some info about the topic so they really know what they're deleting
	$query = "
		SELECT	p.POST_ID, t.TOPIC_ID, f.FORUM_ID, f.FORUM_TITLE, t.TOPIC_SUBJECT, t.TOPIC_REPLIES,
			t.TOPIC_LAST_REPLY_TIME, p.POST_SUBJECT
		FROM	{$config['TABLE_PREFIX']}POSTS as p
		LEFT JOIN {$config['TABLE_PREFIX']}TOPICS as t on t.TOPIC_ID = p.TOPIC_ID
		LEFT JOIN {$config['TABLE_PREFIX']}FORUMS as f on f.FORUM_ID = t.FORUM_ID
		WHERE	p.POST_IS_TOPIC = '1' AND p.POST_ID in ( ? )
	";

	$topics = array();
	$total_posts = 0;

	$sth = $dbh->do_placeholder_query($query, array($in['topics']), __LINE__, __FILE__);
	while ($result = $dbh->fetch_array($sth)) {
		$total_posts += $result['TOPIC_REPLIES'] + 1;
		$result['TOPIC_REPLIES'] = $html->substitute($ubbt_lang['NUM_POSTS_DEL'], array('POSTS' => $result['TOPIC_REPLIES'] + 1));
		$topics[] = $result;
	}
	$dbh->finish_sth($sth);

	$smarty_data = array(
		'topics' => $topics,
		'Board' => $in['forum'],
		'page' => $in['page'],
		'totalposts' => $total_posts,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array (
			"title" => $ubbt_lang['CONFIRM_DELETE'],
			"refresh" => 0,
			"user" => $user,
			"javascript" => array(),
			"bypass" => "",
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> &raquo; {$ubbt_lang['CONFIRM_DELETE']}
BREADCRUMB
			,
		),
		"template" => "inline_confirm_delete",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

function _inline_edit() {
	global $config, $dbh, $ubbt_lang, $html, $in;

	$html->not_right("This feature is not enabled yet.");
}

function _inline_approve() {
	global $config, $dbh, $ubbt_lang, $html, $in;

	$query = "
		SELECT	p.USER_ID, p.POST_PARENT_ID, p.POST_SUBJECT, p.POST_BODY, p.TOPIC_ID,
			u.USER_DISPLAY_NAME, p.POST_IS_TOPIC, p.POST_ICON, p.POST_POSTED_TIME,
			p.POST_ID, t.TOPIC_ID, p.POST_DEFAULT_BODY
		FROM	{$config['TABLE_PREFIX']}POSTS AS p,
			{$config['TABLE_PREFIX']}USERS AS u,
			{$config['TABLE_PREFIX']}TOPICS AS t
		WHERE	p.POST_ID IN ( ? ) AND p.USER_ID = u.USER_ID
			AND p.POST_IS_TOPIC = '1' AND t.POST_ID = p.POST_ID
		ORDER BY p.POST_POSTED_TIME DESC
	";

	$topics = array();
	$post_ids = array();
	$topic_ids = array();
	$sth = $dbh->do_placeholder_query($query, array($in['topics']), __LINE__, __FILE__);
	while ($result = $dbh->fetch_array($sth)) {
		$topics[] = $result;
		$post_ids[] = $result['POST_ID'];
		$topic_ids[] = $result['TOPIC_ID'];
	}
	$dbh->finish_sth($sth);

	// Mark the post as approved
	$query = "
		UPDATE	{$config['TABLE_PREFIX']}POSTS
		SET	POST_IS_APPROVED = '1'
		WHERE	POST_ID in ( ? )
	";

	$sth = $dbh->do_placeholder_query($query, array($post_ids), __LINE__, __FILE__);
	$total_posts = $dbh->affected_rows();
	$dbh->finish_sth($sth);

	// Mark it's topic as approved
	$query = "
		UPDATE	{$config['TABLE_PREFIX']}TOPICS
		SET	TOPIC_IS_APPROVED = '1'
		WHERE	TOPIC_ID in ( ? )
	";

	$sth = $dbh->do_placeholder_query($query, array($topic_ids), __LINE__, __FILE__);
	$total_topics = $dbh->affected_rows();
	$dbh->finish_sth($sth);

	// Need to update the last post on this board
	$query = "
		SELECT	TOPIC_ID, TOPIC_LAST_POST_ID, TOPIC_LAST_POSTER_ID, TOPIC_LAST_POSTER_NAME, TOPIC_LAST_REPLY_TIME,
			TOPIC_SUBJECT, TOPIC_ICON
		FROM	{$config['TABLE_PREFIX']}TOPICS
		WHERE	FORUM_ID = ? AND TOPIC_IS_APPROVED = '1'
		ORDER BY TOPIC_LAST_REPLY_TIME DESC
		LIMIT 1
	";
	$sth = $dbh->do_placeholder_query($query, array($in['forum']), __LINE__, __FILE__);
	$recent = $dbh->fetch_array($sth);
	$dbh->finish_sth($sth);

	// Update the forum
	$query = "
		UPDATE	{$config['TABLE_PREFIX']}FORUMS
		SET	FORUM_POSTS = FORUM_POSTS + ?,
			FORUM_LAST_POSTER_ID = ? ,
			FORUM_LAST_POST_TIME = ? ,
			FORUM_LAST_TOPIC_ID = ? ,
			FORUM_LAST_POST_ID = ?,
			FORUM_LAST_POSTER_NAME = ? ,
			FORUM_LAST_POST_SUBJECT = ? ,
			FORUM_LAST_POST_ICON = ?,
			FORUM_TOPICS = FORUM_TOPICS + ?
		WHERE	FORUM_ID = ?
	";

	$queryvars = array(
		$total_posts + 0,
		$recent['LAST_POSTER_ID'],
		$recent['TOPIC_LAST_REPLY_TIME'],
		$recent['TOPIC_ID'],
		$recent['TOPIC_LAST_POST_ID'],
		$recent['TOPIC_LAST_POSTER_NAME'],
		$recent['TOPIC_SUBJECT'],
		$recent['TOPIC_ICON'],
		$total_topics + 0,
		$in['forum']
	);

	$dbh->do_placeholder_query($query, $queryvars, __LINE__, __FILE__);

	$query = "
		SELECT	FORUM_TITLE
		FROM	{$config['TABLE_PREFIX']}FORUMS
		WHERE	FORUM_ID = ?
	";

	$sth = $dbh->do_placeholder_query($query, array($in['forum']), __LINE__, __FILE__);
	$tmp = $dbh->fetch_array($sth);
	$forum_title = $tmp['FORUM_TITLE'];

	foreach ($topics as $topic) {
		// We need to handle each post separately, because
		// it made my head hurt too much to do them together - Ian

		$notify_data = array(
			'EVENT' => 'TOPIC',
			'USER' => $topic['USER_ID'],
			'USERNAME' => $topic['USER_DISPLAY_NAME'],
			'FORUM' => $in['forum'],
			'POST' => $topic['POST_ID'],
			'TOPIC' => $topic['TOPIC_ID'],
			'BODY' => $topic['POST_DEFAULT_BODY'],
			'HTMLBODY' => $topic['POST_BODY'],
			'TITLE' => $topic['POST_SUBJECT'],
			'FORUM_NAME' => $forum_title,
		);

		handle_watchlist_notifications($notify_data);
	}

	$html->send_redirect(
		array(
			'redirect' => "postlist&Board={$in['forum']}&page={$in['page']}",
			'returnlink' => sprintf('<a href="%s">%s</a>', make_ubb_url("ubb=postlist&Board={$in['forum']}&page={$in['page']}",'', false), $ubbt_lang['INLINE_RETURN']),
			'heading' => $ubbt_lang['CONFIRMED_GENERIC'],
			'body' => $ubbt_lang['CONFIRMED_APPROVED'],
		)
	);
}

function _inline_close() {
	global $config, $dbh, $ubbt_lang, $html, $in;

	$query = "
		UPDATE {$config['TABLE_PREFIX']}TOPICS
		SET    TOPIC_STATUS = 'C'
		WHERE  POST_ID in ( ? )
	";
	$dbh -> do_placeholder_query($query,array($in['topics']),__LINE__,__FILE__);

	$html->send_redirect(
		array(
			'redirect' => "postlist&Board={$in['forum']}&page={$in['page']}",
			'returnlink' => sprintf('<a href="%s">%s</a>', make_ubb_url("ubb=postlist&Board={$in['forum']}&page={$in['page']}",'', false), $ubbt_lang['INLINE_RETURN']),
			'heading' => $ubbt_lang['CONFIRMED_GENERIC'],
			'body' => $ubbt_lang['CONFIRMED_CLOSE'],
		)
	);
}

function _inline_open() {
	global $config, $dbh, $ubbt_lang, $html, $in;

	$query = "
		UPDATE {$config['TABLE_PREFIX']}TOPICS
		SET    TOPIC_STATUS = ''
		WHERE  POST_ID in ( ? )
	";
	$dbh->do_placeholder_query($query,array($in['topics']),__LINE__,__FILE__);

	$html->send_redirect(
		array(
			'redirect' => "postlist&Board={$in['forum']}&page={$in['page']}",
			'returnlink' => sprintf('<a href="%s">%s</a>', make_ubb_url("ubb=postlist&Board={$in['forum']}&page={$in['page']}",'', false), $ubbt_lang['INLINE_RETURN']),
			'heading' => $ubbt_lang['CONFIRMED_GENERIC'],
			'body' => $ubbt_lang['CONFIRMED_OPEN'],
		)
	);
}

function _inline_stick() {
	global $config, $dbh, $ubbt_lang, $html, $in;

	$query = "
		SELECT	TOPIC_ID
		FROM	{$config['TABLE_PREFIX']}TOPICS
		WHERE	POST_ID in ( ? )
	";

	$sth = $dbh->do_placeholder_query($query, array($in['topics']), __LINE__, __FILE__);
	$topics = array();
	while ($result = $dbh->fetch_array($sth)) {
		$topics[] = $result['TOPIC_ID'];
	}
	$dbh->finish_sth($sth);

	$query_vars = array(1, $topics, $in['forum']);
	$query = "
		UPDATE {$config['TABLE_PREFIX']}TOPICS
		SET    TOPIC_IS_STICKY = ?
		WHERE  TOPIC_ID in ( ? ) AND FORUM_ID = ?
	";
	$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

	foreach ($topics as $Number) {
		// Also insert this into the announcements table.
		$query_vars = array($Number, $in['forum']);
		$query = "
			REPLACE INTO {$config['TABLE_PREFIX']}ANNOUNCEMENTS
			VALUES ( ? , ? )
		";
		$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	}

	$html->send_redirect(
		array(
			'redirect' => "postlist&Board={$in['forum']}&page={$in['page']}",
			'returnlink' => sprintf('<a href="%s">%s</a>', make_ubb_url("ubb=postlist&Board={$in['forum']}&page={$in['page']}",'', false), $ubbt_lang['INLINE_RETURN']),
			'heading' => $ubbt_lang['CONFIRMED_GENERIC'],
			'body' => $ubbt_lang['CONFIRMED_STICK'],
		)
	);
}

function _inline_unstick() {
	global $config, $dbh, $ubbt_lang, $html, $in;

	$query = "
		SELECT	TOPIC_ID
		FROM	{$config['TABLE_PREFIX']}TOPICS
		WHERE	POST_ID in ( ? ) AND TOPIC_IS_STICKY = 1
	";

	$sth = $dbh->do_placeholder_query($query, array($in['topics']), __LINE__, __FILE__);
	$topics = array();
	while ($result = $dbh->fetch_array($sth)) {
		$topics[] = $result['TOPIC_ID'];
	}
	$dbh->finish_sth($sth);

	$query_vars = array($topics, $in['forum']);
	$query = "
		UPDATE	{$config['TABLE_PREFIX']}TOPICS
		SET	TOPIC_IS_STICKY = 0
		WHERE	TOPIC_ID in ( ? ) AND FORUM_ID = ?
	";
	$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

	$query_vars = array($topics, $in['forum']);
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}ANNOUNCEMENTS
		WHERE	TOPIC_ID in ( ? ) AND FORUM_ID = ?
	";
	$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);


	$html->send_redirect(
		array(
			'redirect' => "postlist&Board={$in['forum']}&page={$in['page']}",
			'returnlink' => sprintf('<a href="%s">%s</a>', make_ubb_url("ubb=postlist&Board={$in['forum']}&page={$in['page']}",'', false), $ubbt_lang['INLINE_RETURN']),
			'heading' => $ubbt_lang['CONFIRMED_GENERIC'],
			'body' => $ubbt_lang['CONFIRMED_UNSTICK'],
		)
	);
}

function _inline_announce() {
	global $config, $dbh, $ubbt_lang, $html, $in;

	$query = "
		SELECT	TOPIC_ID
		FROM	{$config['TABLE_PREFIX']}TOPICS
		WHERE	POST_ID in ( ? )
	";

	$sth = $dbh->do_placeholder_query($query, array($in['topics']), __LINE__, __FILE__);
	$topics = array();
	while ($result = $dbh->fetch_array($sth)) {
		$topics[] = $result['TOPIC_ID'];
	}
	$dbh->finish_sth($sth);

	$query_vars = array(2, $topics, $in['forum']);
	$query = "
		UPDATE {$config['TABLE_PREFIX']}TOPICS
		SET    TOPIC_IS_STICKY = ?
		WHERE  TOPIC_ID in ( ? ) AND FORUM_ID = ?
	";
	$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

	foreach ($topics as $Number) {
		// Also insert this into the announcements table.
		$query_vars = array($Number, $in['forum']);
		$query = "
			REPLACE INTO {$config['TABLE_PREFIX']}ANNOUNCEMENTS
			VALUES ( ? , ? )
		";
		$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	}

	$html->send_redirect(
		array(
			'redirect' => "postlist&Board={$in['forum']}&page={$in['page']}",
			'returnlink' => sprintf('<a href="%s">%s</a>', make_ubb_url("ubb=postlist&Board={$in['forum']}&page={$in['page']}",'', false), $ubbt_lang['INLINE_RETURN']),
			'heading' => $ubbt_lang['CONFIRMED_GENERIC'],
			'body' => $ubbt_lang['CONFIRMED_ANNOUNCE'],
		)
	);
}
?>
