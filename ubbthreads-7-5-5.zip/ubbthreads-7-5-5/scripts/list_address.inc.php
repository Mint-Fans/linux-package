<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;
define('NO_WRAPPER',1);
function page_list_address_gpc () {
	return array(
		"input" => array(
		),
		"wordlets" => array("list_address"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_list_address_gpc

function page_list_address_run () {

	global $style_array,$smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$smarty_data = array();
		
	$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";
	
	// ----------------------------------------------------
	// Grab all entries from the address book for this user

	$query = "
	SELECT t2.USER_DISPLAY_NAME
	FROM  {$config['TABLE_PREFIX']}ADDRESS_BOOK AS t1,
	{$config['TABLE_PREFIX']}USERS AS t2
	WHERE t1.USER_ID = ?
	AND   t1.ADDRESS_ENTRY_USER_ID = t2.USER_ID
	ORDER BY t2.USER_DISPLAY_NAME
	";
	$sth = $dbh -> do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);

	// Lets give the start of the page

	// ----------------------------------------------------------------
	// Cycle through the users
	$color = "alt-1";
	$userrow = array();
	while ($result = $dbh -> fetch_array($sth)){
		$userrow[] = array(
			'Member' => $result['USER_DISPLAY_NAME']
		);
	}
	

	$smarty_data = array(
		"userrow" => $userrow,
		"stylesheet" => $stylesheet,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array (
			"title" => $ubbt_lang['MY_ADDRESS'],
			"refresh" => 0,
			"user" => $user,
			"Board" => $Board,
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 {$ubbt_lang['MY_ADDRESS']}
BREADCRUMB
			,
		),
		"template" => "list_address",
		"data" => & $smarty_data,
		"footer" => false,
		"location" => "",
	);
	
}

?>
