<?php

//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_mailthread_gpc () {
	return array(
		"input" => array(
			"Board" => array("Board","get","int"),
			"Number" => array("Number","get","int"),
			"o" => array("o","get","int"),
			"fpart" => array("fpart","get","alphanum"),
			"what" => array("what","get","alpha"),
		),
		"wordlets" => array("mailthread"),
		"user_fields" => "t2.USER_REAL_EMAIL",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_mailthread_gpc

function page_mailthread_run () {

	global $smarty,$userob,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$Username = $user['USER_DISPLAY_NAME'];

	if (!$userob->check_access("site","MAIL_POST")) {
		$html -> not_right("DISABLED");
	}

        // Get the board id from the post #                 
	$query = "
		select t1.FORUM_ID
		from {$config['TABLE_PREFIX']}TOPICS as t1,
		{$config['TABLE_PREFIX']}POSTS as t2  
		where t2.POST_ID = ?
		and t1.TOPIC_ID = t2.TOPIC_ID
	";
	$sth = $dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);
	list($Board) = $dbh->fetch_array($sth);
	
	// --------------------------------------------
	// Let's find out if they should be here or not
	$query = "
	SELECT FORUM_TITLE,CATEGORY_ID,FORUM_PARENT,FORUM_IS_RSS,FORUM_RSS_TITLE
	FROM   {$config['TABLE_PREFIX']}FORUMS
	WHERE  FORUM_ID = ?
	AND FORUM_IS_ACTIVE='1'
	";
	$sth = $dbh->do_placeholder_query($query,array($Board),__LINE__,__FILE__);
	list($title,$CatNumber,$parent_id,$is_rss,$rss_title) = $dbh->fetch_array($sth);

	$TEXT_AREA_COLUMNS = $config['TEXT_AREA_COLUMNS'];
	$TEXT_AREA_ROWS = $config['TEXT_AREA_ROWS'];

	// -----------------------------------------------------------------------------
	// Once and a while if people try to just put a number into the url,lets trap it
	if (!$Number) {
		$html->not_right("There was a problem looking up the Post in our database.  Please try again.");
	}

	if (!$userob->check_access("forum","SEE_FORUM",$Board)) {
		$html -> not_right($ubbt_lang['BAD_GROUP']);
	}
	
	$smarty_data = array(
		"Board" => $Board,
		"Number" => $Number,
		"what" => $what,
		"fpart" => $fpart,
		"Username" => $Username,
		"TEXT_AREA_COLUMNS" => $TEXT_AREA_COLUMNS,
		"TEXT_AREA_ROWS" => $TEXT_AREA_ROWS,
		"user" => $user,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array (
			"title" => $ubbt_lang['MAIL_FRIEND'],
			"refresh" => 0,
			"user" => $user,
			"Board" => $Board,
			"Category" => $CatNumber,
			"parent_forum" => $parent_id,
			"rss" => $is_rss,
			"rss_title" => $rss_title,
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
			,
		),
		"template" => "mailthread",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
