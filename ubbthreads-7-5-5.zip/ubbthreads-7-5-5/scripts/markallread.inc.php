<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_markallread_gpc () {
	return array(
		"input" => array(
		),
		"wordlets" => array("markallread"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_markallread_gpc

function page_markallread_run () {

	global $smarty,$user,$in,$ubbt_lang,$config,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$Username = $user['USER_DISPLAY_NAME'];


	$smarty_data = array();
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array (
			"title" => $ubbt_lang['MARKALLREAD'],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 {$ubbt_lang['MARKALLREAD']}
BREADCRUMB
			,
		),
		"template" => "markallread",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
