<?php

//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_mess_handler_gpc () {
	return array(
		"input" => array(
			"Number" => array("Number","both","int"),
			"deletemess" => array("deletemess","both","int"),
			"returnstart" => array("returnstart","both",""),
			"replymess" => array("replymess","both",""),
			"page" => array("page","post","int"),
			"q" => array("q","both","int"),
			"id" => array("id","both","int"),
			"CurrentBody" => array("Body","post",""),
			"quickreply" => array("quickreply","both","int"),
		),
		"wordlets" => array("mess_handler"),
		"user_fields" => "t2.USER_TEXT_EDITOR",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_mess_handler_gpc

function page_mess_handler_run () {

	global $smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// ----------------------------------------------------------
	// If they selected to return to start page, execute that sub
	if ($returnstart){
		return array(
			"header" => "",
			"template" => "",
			"data" => "",
			"footer" => false,
			"location" => "viewmessages&page=$page&PHPSESSID=$PHPSESSID",
		);
	}

	if (!$deletemess) {
		$query = "
			select TOPIC_ID
			from {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
			where POST_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($id),__LINE__,__FILE__);
		list ($Number) = $dbh->fetch_array($sth);
	}

	// First let's make sure they are supposed to be here
	$query = "
		select 	count(*)
		from	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
		where	TOPIC_ID = ?
		and	USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($Number,$user['USER_ID']),__LINE__,__FILE__);
	list($perm_check) = $dbh->fetch_array($sth);
	if (!$perm_check) {
		$html->not_right($ubbt_lang['NO_PERM']);
	} // end if


	// --------------------------------------------------------
	// If they selected delete this messages, execute that sub
	if($deletemess){
		return delete_mess($Number,$page);
	}

	// --------------------------------------------------------
	// If they selected reply to this message, execute that sub
	if($replymess || $quickreply){
		return reply_mess($Number,$page,$q,$id,$CurrentBody);
	}



}

// ######################################################################
// delete_mess function - Delete this message
// ######################################################################

function delete_mess($Number="",$page) {

	global $dbh, $config, $ubbt_lang, $PHPSESSID, $user,$html;

	$query = "
		delete from {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
		where	TOPIC_ID = ?
		and	USER_ID = ?
	";
	$dbh->do_placeholder_query($query,array($Number,$user['USER_ID']),__LINE__,__FILE__);

	$query = "
		select	count(*)
		from	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
		where	TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);
	list($count) = $dbh->fetch_array($sth);

	if (!$count) {
		$query = "
		DELETE FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS
		WHERE  TOPIC_ID = ?
		";
		$dbh -> do_placeholder_query($query,array($Number),__LINE__,__FILE__);
		$query = "
		DELETE FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
		WHERE  TOPIC_ID = ?
		";
		$dbh -> do_placeholder_query($query,array($Number),__LINE__,__FILE__);
	} else {
		// Add a note so others know that we are no longer
		// participating in this topic
		$note = "{$user['USER_DISPLAY_NAME']} {$ubbt_lang['REMOVED']}";
		$query_vars = array($Number,$user['USER_ID'],$note,$html->get_date(),$note);
		$query = "
			insert into {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
			(TOPIC_ID,USER_ID,POST_BODY,POST_TIME,POST_DEFAULT_BODY)
			values
			( ? , ? , ? , ? , ? )
		";
		$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	}

	// Check and see if there are any more unread PMs
	$query = "
		select	count(*)
		from	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS as t1,
			{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS as t2
		where	t1.TOPIC_ID = t2.TOPIC_ID
		and	t2.TOPIC_LAST_REPLY_TIME > t1.MESSAGE_LAST_READ
		and	t1.USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
	list($total_unread) = $dbh->fetch_array($sth);

	$query = "
		update	{$config['TABLE_PREFIX']}USER_PROFILE
		set	USER_TOTAL_PM = ?
		where	USER_ID = ?
	";
	$dbh->do_placeholder_query($query,array($total_unread,$user['USER_ID']),__LINE__,__FILE__);

	// -------------------------------
	// Return them to their start page
	return array(
		"header" => "",
		"template" => "",
		"data" => "",
		"footer" => false,
		"location" => "viewmessages",
	);
}

// --------------------------------
// END OF THE DELETE_MESS FUNCTION


// ####################################################################
// reply_mess function - Reply to this message
// ####################################################################

function reply_mess($Number="",$page="",$q="",$id="",$CurrentBody="") {

	global $user, $smarty, $dbh, $config, $ubbt_lang, $userob, $html;

	$query = "
		select count(*)
		from    {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
		where   TOPIC_ID = ?
	";
	$sth = $dbh -> do_placeholder_query($query,array($Number),__LINE__,__FILE__);
	list($total) = $dbh->fetch_array( $sth );

	// What's the PM length limit?
	$mytotal = $userob->check_access("site","PM_LENGTH");
	if ($total >= $mytotal) {
		$html->not_right($html->substitute($ubbt_lang['TOO_LONG'],array('TOTAL' => $mytotal)));
	} // end if     

	// --------------------------------
	// Show them what it is in reply to
	$query = "
		SELECT t1.TOPIC_SUBJECT,t2.POST_DEFAULT_BODY,t3.USER_DISPLAY_NAME,t2.POST_BODY
		FROM   {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS as t1,
		{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS as t2,
		{$config['TABLE_PREFIX']}USERS as t3
		WHERE  t2.POST_ID   = ?
		and t1.TOPIC_ID = t2.TOPIC_ID
		and t2.USER_ID = t3.USER_ID
	";
	$sth = $dbh -> do_placeholder_query($query,array($id),__LINE__,__FILE__);
	list($Subject,$Body,$username,$fullbody) = $dbh -> fetch_array($sth);
	$onsubmit = "";
	if ($q == 1) {
		$QuoteBody = "[quote=$username]$Body [/quote]";
	} else {
		$QuoteBody = "";
	}

	// If we are coming from quick reply, body gets preserved
	if ($CurrentBody) $QuoteBody = $CurrentBody;

	$text_editor = $html->create_text_editor("Body",$QuoteBody,1);

	$smarty_data = array(
		"Number" => $Number,
		"page" => $page,
		"Subject" => $Subject,
		"text_editor" => $text_editor,
		"onsubmit" => $onsubmit,
		"full_body" => $fullbody,
		"username" => $username,
		"mystuff" => $html->mystuff(),
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array (
			"title" => "{$ubbt_lang['REPLY_HEAD']} $Subject",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 {$ubbt_lang['REPLY_HEAD']} $Subject
BREADCRUMB
			,
			"javascript" => array(
				0 => "standard_text_editor.js",
			),
		),
		"template" => "mess_handler",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

// -------------------------------
// END OF THE REPLY_MESS FUNCTION




?>
