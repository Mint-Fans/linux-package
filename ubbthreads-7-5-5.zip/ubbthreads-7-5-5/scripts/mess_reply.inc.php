<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_mess_reply_gpc () {
	return array(
		"input" => array(
			"Number" => array("Number","post","int"),
			"Message" => array("Body","post",""),
			"page" => array("page","post","int"),
		),
		"wordlets" => array("mess_reply"),
		"user_fields" => "USER_TEXT_EDITOR,USER_TOPICS_PER_PAGE,USER_POSTS_PER_TOPIC",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_mess_reply_gpc

function page_mess_reply_run () {

	global $smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html,$userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// Make sure they can access this pm
	$query = "
		select 	count(*)
		from		{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
		where		USER_ID = ?
		and		TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($user['USER_ID'],$Number),__LINE__,__FILE__);
	list($perm_check) = $dbh->fetch_array($sth);
	if (!$perm_check) {
		$html->not_right($ubbt_lang['NO_PERM']);
	} // end if

	// How many posts in this pm?
	$query = "
		select count(*)
		from {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
		where TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);
	list($total) = $dbh->fetch_array($sth);

	// What's the PM length limit?
	$mytotal = $userob->check_access("site","PM_LENGTH");

	if ($total >= $mytotal) {
		$html->not_right($html->substitute($ubbt_lang['TOO_LONG'],array('TOTAL' => $mytotal)));
	} // end if

	$Username = $user['USER_DISPLAY_NAME'];

	$RawMessage = $Message;

	if ($config['DO_CENSOR']) {
		$Message = $html->do_censor($Message);
		$Subject = $html->do_censor($Subject);
	}

	// ------------
	// Get the date
	$date = $html -> get_date();

	// -------------------------------------
	// Make sure there is a subject and body
	if ($Message == "") {
		$html -> not_right($ubbt_lang['ALL_FIELDS']);
	}

	// ------------------
	// Markup the Message and Subject
	$Message = $html -> do_markup($Message,"post","markup");

	// ------------------------------------
	// Insert the message into the database
	$query_vars = array($user['USER_ID'],$date,$Username,$Number);
	$query = "
		update	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS
		set	TOPIC_REPLIES = TOPIC_REPLIES + 1,
			TOPIC_LAST_POSTER_ID = ? ,
			TOPIC_LAST_REPLY_TIME = ? ,
			TOPIC_LAST_POSTER_NAME = ?
		where	TOPIC_ID = ?
	";
	$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

	// Make sure we mark this as read for the sender
	$query_vars = array($date,$Number,$user['USER_ID']);
	$query = "
		update {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
		set	MESSAGE_LAST_READ = ?
		where	TOPIC_ID = ?
		and	USER_ID = ?
	";
	$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

	$query = "
		SELECT	pmu.USER_ID, pmt.TOPIC_SUBJECT
			FROM	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS pmu,
						{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS pmt
		WHERE	pmu.TOPIC_ID = ?
			AND	pmu.USER_ID <> ?
			AND pmu.TOPIC_ID = pmt.TOPIC_ID
	";
	$sth = $dbh->do_placeholder_query($query,array($Number,$user['USER_ID']),__LINE__,__FILE__);

	while(list($sendto,$tsubject) = $dbh->fetch_array($sth)) {

		// ---------------------------------------------------
		// Now lets grab the email address and see if they want
		// to have a notificationthat they received a private message
		$query = "
			SELECT up.USER_REAL_EMAIL, up.USER_NOTIFY_ON_PM, u.USER_DISPLAY_NAME, up.USER_LANGUAGE
				FROM {$config['TABLE_PREFIX']}USER_PROFILE up,
						 {$config['TABLE_PREFIX']}USERS u
			WHERE u.USER_ID = up.USER_ID
				AND	up.USER_ID = ?
		";
		$sti = $dbh -> do_placeholder_query($query,array($sendto),__LINE__,__FILE__);
		list($Email,$Notify,$Username,$Lang) = $dbh -> fetch_array($sti);
		// Check and see if there are any more unread PMs
		$query = "
			select	count(t1.TOPIC_ID)
			from	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS as t1,
				{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS as t2
			where	t1.TOPIC_ID = t2.TOPIC_ID
			and	t2.TOPIC_LAST_REPLY_TIME > t1.MESSAGE_LAST_READ
			and	t1.USER_ID = ?
		";
		$sti = $dbh->do_placeholder_query($query,array($sendto),__LINE__,__FILE__);
		list($total_unread) = $dbh->fetch_array($sti);

		$total_unread = $total_unread + 1;

		$query = "
			update	{$config['TABLE_PREFIX']}USER_PROFILE
			set	USER_TOTAL_PM = ?
			where	USER_ID = ?
		";
		$dbh->do_placeholder_query($query,array($total_unread,$sendto),__LINE__,__FILE__);

		if ($Notify == "yes"){
			$mailer = new mailer();
			$mailer->set_language($Lang);
			$mailer->set_subject('PMN_SUBJECT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
			$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $Username));
			$mailer->add_content('PMN_CONTENT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE'], 'FROMNAME' => $user['USER_DISPLAY_NAME']));
			$mailer->add_content('PMN_CONTENT1', array('PM_URL' => make_ubb_url("ubb=viewmessage&message=$Number&gonew=1" ,"", true, true)), true);
			$mailer->add_content('PMN_CONTENT2', array(), true);
			$mailer->add_post($user['USER_DISPLAY_NAME'],'Re: '.$tsubject,array(),$Message,$RawMessage);
			$mailer->ubbt_mail($Email);
		}
	}

	$query_vars = array($Number,$user['USER_ID'],$Message,$date,$RawMessage);
	$query =  "
		insert into {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
		(TOPIC_ID,USER_ID,POST_BODY,POST_TIME,POST_DEFAULT_BODY)
		values
		( ? , ? , ? , ? , ? )
	";
	$dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

	$query = "
		select last_insert_id()
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	list($post_id) = $dbh->fetch_array($sth);

	$query = "
		select count(*)
		from {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
		where TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);
	list($totalcount) = $dbh->fetch_array($sth);

	$limit = ($user['USER_POSTS_PER_TOPIC'] ? $user['USER_POSTS_PER_TOPIC'] : $config['POSTS_PER_PAGE']);
	$page = intval(($totalcount - 1) / $limit) + 1;

	// ---------------------------
	// Return to their start page
	return array(
		"header" => "",
		"template" => "",
		"footer" => false,
		"location" => "viewmessage&message=$Number&page=$page#Post$post_id",
		"breadcrumb" => "",
	);

}

?>
