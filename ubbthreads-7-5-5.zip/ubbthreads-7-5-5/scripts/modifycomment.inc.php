<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_modifycomment_gpc () {
	return array(
		"input" => array(
			"id" => array("id","post","int"),
			"Body" => array("Body","post",""),
			"delete" => array("delete","post","alpha"),
		),
		"wordlets" => array("modifycomment"),
		"user_fields" => "USER_TEXT_EDITOR",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_modifycomment_gpc


function page_modifycomment_run () {

	global $style_array,$html,$smarty,$user,$in,$myinfo,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$DefaultBody = $Body;

	$query = "
		select PROFILE_ID,USER_ID
		from {$config['TABLE_PREFIX']}PROFILE_COMMENTS
		where COMMENT_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($id),__LINE__,__FILE__);
	list($profile,$poster) = $dbh->fetch_array($sth);

	if ($poster != $user['USER_ID'] && $user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && $profile != $user['USER_ID']) {
		$html->not_right($ubbt_lang['NO_EDIT']);
	} // end if

	// Regular users cannot edit comments in their own profile
	// only delete.
	if ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && $poster != $user['USER_ID'] && !$delete) {
		$html->not_right($ubbt_lang['NO_EDIT']);
	} // end if

	$Body = $html -> do_markup($Body,"post","markup");

	// -----------------------
	// Run the censor filter
	if ($config['DO_CENSOR']) {
		$Body = $html->do_censor($Body);
	}

	if ($delete) {

		$query = "
			delete from {$config['TABLE_PREFIX']}PROFILE_COMMENTS
			where COMMENT_ID = ?
		";
		$dbh -> do_placeholder_query($query,array($id),__LINE__,__FILE__);
	
		// Log it
		admin_log("DELETE_COMMENT", "<a href='" . make_ubb_url("ubb=showprofile&User=$profile", "DELETE_COMMENT", false) . "' target='_blank'>DELETE_COMMENT</a>");

	
		$plink = make_ubb_url("ubb=showprofile&User=$profile", "", false);
		$cfrm = make_ubb_url("ubb=cfrm", "", false);
		$html->send_redirect(
			array(
				"redirect" => "showprofile&User=$profile",
				"heading" => $ubbt_lang['DELETE_HEAD'],
				"body" => "{$ubbt_lang['DELETE_HEAD']} {$ubbt_lang['RET_FORUM']}",
				"Board" => "",
				"Category" => "",
				"forum_parent" => "",
				"custom_header_footer" => "",
				"returnlink" => "<a href=\"{$plink}\">{$ubbt_lang['PROFILE_RETURN']}</a>",
				"breadcrumb" => <<<BREADCRUMB
	<a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
				,
			)
		);

	} else {

		$query = "
			update {$config['TABLE_PREFIX']}PROFILE_COMMENTS
			set COMMENT_BODY = ?,
			COMMENT_DEFAULT_BODY = ?
			where COMMENT_ID = ?
		";
		$dbh -> do_placeholder_query($query,array($Body,$DefaultBody,$id),__LINE__,__FILE__);
	
		// Log it
		admin_log("EDIT_COMMENT", "<a href='" . make_ubb_url("ubb=showprofile&User=$profile", "EDIT_COMMENT", false) . "' target='_blank'>EDIT_COMMENT</a>");

	
		$plink = make_ubb_url("ubb=showprofile&User=$profile", "", false);
		$cfrm = make_ubb_url("ubb=cfrm", "", false);
		$html->send_redirect(
			array(
				"redirect" => "showprofile&User=$profile",
				"heading" => $ubbt_lang['MODIF_HEAD'],
				"body" => "{$ubbt_lang['MODIF_HEAD']} {$ubbt_lang['RET_FORUM']}",
				"Board" => "",
				"Category" => "",
				"forum_parent" => "",
				"custom_header_footer" => "",
				"returnlink" => "<a href=\"{$plink}\">{$ubbt_lang['PROFILE_RETURN']}</a>",
				"breadcrumb" => <<<BREADCRUMB
	<a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
				,
			)
		);
	}	
}

?>
