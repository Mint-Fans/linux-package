<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_movepost_gpc () {
	return array(
		"input" => array(
			"Number" => array("Number","post","int"),
			"Keyword" => array("Keyword","post","int"),
			"view" => array("view","post","alpha"),
			"what" => array("what","post","alpha"),
			"sb" => array("sb","post","int"),
			"o" => array("o","post","int"),
			"fpart" => array("fpart","post","alphanum"),
			"from" => array("from","post","alpha"),
			"movepost" => array("movepost","post",""),
		),
		"wordlets" => array("movepost"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 1,
	);
} // end page_movepost_gpc

function page_movepost_run () {

	global $smarty,$userob,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html,$tree;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$number   = $Number;
	$oldboard = $Keyword;
	
	// --------------------------------------------
	// Let's find out if they should be here or not
	$query = "
	SELECT FORUM_TITLE,CATEGORY_ID,FORUM_PARENT,FORUM_IS_RSS,FORUM_RSS_TITLE
	FROM   {$config['TABLE_PREFIX']}FORUMS
	WHERE  FORUM_ID = ?
	AND FORUM_IS_ACTIVE='1'
	";
	$sth = $dbh -> do_placeholder_query($query,array($Keyword),__LINE__,__FILE__);
	list($FTitle,$cat_id,$parent_id,$is_rss,$rss_title) = $dbh -> fetch_array($sth);

	
	if (!sizeof($tree)) {
		list($tree,$style_cache,$lang_cache) = build_forum_cache();
	}
	
	$options = "";
	$category = "";
	$forums = 0;
	foreach($tree['categories'] as $cat => $cat_title) {
		$category = "";
		$forums = 0;
		$category .= "<option value=\"category\">$cat_title ------</option>";
		if (!isset($tree[$cat])) continue;
		foreach($tree[$cat] as $forum_id => $forum_title) {
			if (!$userob->check_access("forum","SEE_FORUM",$forum_id) || $tree['active'][$forum_id] != 1) { continue; }
			$category .= "<option value=\"f$forum_id\">$forum_title</option>";	
			$forums++;
		}
		if ($forums) $options .= $category;
	}
		

	$smarty_data = array(
		"view" => $view,
		"o" => $o,
		"forums" => & $options,
		"oldboard" => $oldboard,
		"number" => $number,
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array (
			"title" => $ubbt_lang['CHOOSE_HEAD'],
			"refresh" => 0,
			"user" => $user,
			"Board" => $Keyword,
			"Category" => $cat_id,
			"parent_forum" => $parent_id,
			"bypass" => 0,
			"rss" => $is_rss,
			"rss_title" => $rss_title,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
			,
		),
		"template" => "movepost",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
