<?php

//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_movethread_gpc () {
	return array(
		"input" => array(
			"Number" => array("Number","both","int"),
		),
		"wordlets" => array("movethread"),
		"user_fields" => "USER_TOPIC_VIEW_TYPE",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 1,
	);
} // end page_movethread_gpc

function page_movethread_run () {

	global $smarty,$user,$userob,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html,$tree;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$query = "
		select FORUM_ID,POST_ID
		from {$config['TABLE_PREFIX']}TOPICS
		where TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);
	list($Keyword,$first_post) = $dbh->fetch_array($sth);
	
	// Make sure they can move topics	
	if (!$userob->check_access("forum","MOVE_ANY",$Keyword)) {
		$html->not_right($ubbt_lang['NO_PERM_MOVE']);
	} // end if
	
	// --------------------------------------------
	// Let's find out if they should be here or not
	$query = "
	SELECT FORUM_TITLE,CATEGORY_ID,FORUM_PARENT,FORUM_IS_RSS,FORUM_RSS_TITLE,FORUM_IS_GALLERY
	FROM   {$config['TABLE_PREFIX']}FORUMS
	WHERE  FORUM_ID = ?
	AND FORUM_IS_ACTIVE='1'
	";
	$sth = $dbh -> do_placeholder_query($query,array($Keyword),__LINE__,__FILE__);
	list($fTitle,$cat_id,$parent_id,$is_rss,$rss_title,$is_gallery) = $dbh -> fetch_array($sth);

	// ------------------------------------------
	// Make sure this isn't a global announcement
	$query = "
	SELECT TOPIC_IS_STICKY
	FROM {$config['TABLE_PREFIX']}TOPICS
	WHERE TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);
	list($sticky) = $dbh->fetch_array($sth);

	if ($sticky == 2) {
		$html->not_right($ubbt_lang['GLOBAL']);
	}

	// Get the list of gallery/non-gallery forums
	$query = "
		select FORUM_ID,FORUM_IS_GALLERY
		from {$config['TABLE_PREFIX']}FORUMS
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	$forum_array = array();
	while(list($fid,$gal) = $dbh->fetch_array($sth)) {
		$forum_array[$fid] = $gal;
	}

	if (!sizeof($tree)) {
		list($tree,$style_cache,$lang_cache) = build_forum_cache();
	}
	
	$options = "";
	$category = "";
	$forums = 0;
	foreach($tree['categories'] as $cat => $cat_title) {
		$category = "";
		$forums = 0;
		$category .= "<option value=\"category\">$cat_title ------</option>";
		if (!isset($tree[$cat])) continue;
		foreach($tree[$cat] as $forum_id => $forum_title) {
			if ($is_gallery && $forum_array[$forum_id] == 0) continue;
			if (!$is_gallery && $forum_array[$forum_id] ==1) continue;

			if (!$userob->check_access("forum","SEE_FORUM",$forum_id) || $tree['active'][$forum_id] != 1) { continue; }
			$category .= "<option value=\"$forum_id\">$forum_title</option>";	
			$forums++;
		}
		if ($forums) $options .= $category;
	}

	$days = "";
	for ($i=1;$i<32;$i++) {
		$days .= "<option>$i</option>";
	} // end for

	$smarty_data = array(
		"forums" => & $options,
		"Keyword" => $Keyword,
		"Number" => $Number,
		"days" => $days,
		"is_gallery" => $is_gallery,
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	
	return array(
		"header" => array (
			"title" => $ubbt_lang['CHOOSE_HEAD'],
			"refresh" => 0,
			"user" => $user,
			"Board" => $Keyword,
			"Category" => $cat_id,
			"parent_forum" => $parent_id,
			"bypass" => 0,
			"rss" => $is_rss,
			"rss_title" => $rss_title,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
			,
		),
		"template" => "movethread",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}
	
?>
