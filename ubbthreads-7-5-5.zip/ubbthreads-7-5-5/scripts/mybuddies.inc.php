<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function &page_mybuddies_gpc () {
	return array(
		"input" => array(
			"page" => array("page","get","int",0),
			"checked" => array("check-inline","post","int"),
			"deletecheck" => array("deletecheck","post",""),
		),
		"wordlets" => array("mybuddies"),
		"user_fields" => "t2.USER_TOPICS_PER_PAGE",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_list_address_gpc

function &page_mybuddies_run () {
	global $html,$smarty,$user,$in,$ubbt_lang,$config,$dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS);

	// First handle any delete requests
	if ($deletecheck) {
		$in_array = array();
		foreach($checked as $id) {
			$in_array[] = $id;
		}
		if (sizeof($in_array) > 0) {
			$and_in = 'AND ADDRESS_ENTRY_USER_ID IN (' . implode(',',$in_array) . ')';
			$query = "
				DELETE FROM {$config['TABLE_PREFIX']}ADDRESS_BOOK
				WHERE USER_ID = {$user['USER_ID']}
				$and_in
			";
			$sth = $dbh->do_query($query,__LINE__,__FILE__);
		}
	}

	// Setup for possible pagination
	$query = "
		SELECT count(*) FROM {$config['TABLE_PREFIX']}ADDRESS_BOOK WHERE USER_ID = {$user['USER_ID']}
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	list($total) = $dbh->fetch_array($sth);

	$limit = ($user['USER_TOPICS_PER_PAGE'] ? $user['USER_TOPICS_PER_PAGE'] : $config['TOPICS_PER_PAGE']);
	$pages = $html->paginate( $page ? $page : 1, ceil( $total / $limit ), "mybuddies&page=" );
	if( $page > 0 ) {
		$new_page = ( $page - 1 ) * $limit;
	} else {
		$new_page = 0;
	}

	// ----------------------------------------------------
	// Grab all entries from the address book for this user
	$query = "
		SELECT u.USER_DISPLAY_NAME, u.USER_ID, u.USER_MEMBERSHIP_LEVEL, up.USER_NAME_COLOR, up.USER_TOTAL_POSTS
			FROM {$config['TABLE_PREFIX']}ADDRESS_BOOK ab,
					 {$config['TABLE_PREFIX']}USERS u,
					 {$config['TABLE_PREFIX']}USER_PROFILE up
		WHERE ab.USER_ID = {$user['USER_ID']}
			AND ab.ADDRESS_ENTRY_USER_ID = u.USER_ID
			AND u.USER_ID = up.USER_ID
		ORDER BY u.USER_DISPLAY_NAME
		LIMIT $new_page, $limit
	";
	$sth = $dbh -> do_query($query,__LINE__,__FILE__);

	// Cycle through the users
	$x=0;
	$userrow = array();
	while ( list($uName,$UserID,$uLevel,$uColor,$uPosts) = $dbh -> fetch_array($sth)){
		$userrow[$x]['member'] = $html->user_color($uName,$uColor,$uLevel);
		$userrow[$x]['color'] = ($x&1) ? "alt-" : "";
		$userrow[$x]['userid'] = $UserID;
		$userrow[$x]['posts'] = $uPosts;
		$userrow[$x]['number'] = $x;
		$x++;
	}

	$smarty_data = array(
		"userrow" => $userrow,
		"mystuff" => $html->mystuff(),
		"pages" => $pages,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array (
			"title" => $ubbt_lang['MY_BUDDIES'],
			"refresh" => 0,
			"user" => $user,
			"Board" => $Board,
			"bypass" => 0,
			"onload" => "",
			"javascript" => array('inline_moderation.js'),
			"breadcrumb" => "<a href=\"{$cfrm}\">{$ubbt_lang['FORUM_TEXT']}</a> &raquo; {$ubbt_lang['MY_BUDDIES']}",
		),
		"template" => "mybuddies",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
