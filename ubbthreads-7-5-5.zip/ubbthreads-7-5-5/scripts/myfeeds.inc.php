<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

// General setup function, first called to get the ball rolling
function page_myfeeds_gpc () {
	return array(
		"input" => array(
			"sp" => array("sp","get","int"),
			"fp" => array("fp","get","int"),
			"ft" => array("ft","get","int"),
			"show" => array("show","get","int"),
		),
		"wordlets" => array("myfeeds"),
		"user_fields" => "t2.USER_TIME_FORMAT",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
}

// Now determine, based upon the supplied params whether to:
//
// 1. Pump out all the feed info (html) - $show=1
// 2. Pump out an xml stream based upon - $sp=xx
//				where xx is:
//					1 - PM inbox
//					2 - Recent topics
//					3 - Recent posts
// 3. If sp isn't happening then ($fp or $ft)=yy apply as follows:
//						where yy is:
//							FORUM_ID to display recent topics($ft) or posts($fp)
//
// Notes: the default will be setup to fall thru to an XML based error
//				 message, if supplied params don't jive

function page_myfeeds_run () {
	global $smarty, $user, $userob, $tree, $html, $in, $ubbt_lang, $config, $style_array, $dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS);

	// Also must be enabled from Admin Cpanel
	if (!$config['MY_FEEDS']) {
		return $html->not_right($ubbt_lang['NO_MY_FEEDS']);
	}

	// Setup default as error
	$maxRows = 10;
	$sendXML = 1;
	$chanTitle = $ubbt_lang['RSS_ERR_TITLE'];
	$chanDesc = $ubbt_lang['RSS_ERR_DESC'];
	$time = $html->get_date();
	$lastBuild = date("D, d M Y H:i:s T", $time);
	$imgLink = "{$config['FULL_URL']}/ubbthreads.php?ubb=cfrm";
	$itemRows = array();

	// User clicked on 'My Feeds'
	if ($show) {
		$sendXML = 0;

		// Based upon user's permissions, build a list of allowable forums
		$rssForums = array();
		$i = 0;
		foreach($tree['categories'] as $catID => $catTitle) {
			// Assume we have an empty category with no forums
			$forums = 0;
			if (!isset($tree[$catID])) continue;

			foreach($tree[$catID] as $forumID => $forumTitle) {
				// No can peeky
				if ($userob->check_access("forum","READ_TOPICS",$forumID) && $tree['active'][$forumID] == 1) {
					// We have one, so let's add this puppy in
					if ($forums == 0) {
						$rssForums[$i]['iscat'] = 1;
						$rssForums[$i]['title'] = $catTitle;
						$rssForums[$i]['class'] = 'category';
						$i++;
					}
					$forums++;
					$rssForums[$i]['iscat'] = 0;
					$forumTitle = str_repeat("&nbsp;",substr_count($forumTitle,"&nbsp;")-3) . "&nbsp;&raquo;&nbsp;" . str_replace("&nbsp;","",$forumTitle);
					$rssForums[$i]['title'] = $forumTitle;
					$rssForums[$i]['class'] = ($forums&1) ? "alt-2" : "alt-1";
  				$rssForums[$i]['fpfeed']  = "<a href=\"{$config['FULL_URL']}/ubbthreads.php?ubb=myfeeds&fp=$forumID\"><img src=\"{$config['BASE_URL']}/images/{$style_array['general']}/rss_icon.gif\" /></a>";
  				$rssForums[$i]['ftfeed']  = "<a href=\"{$config['FULL_URL']}/ubbthreads.php?ubb=myfeeds&ft=$forumID\"><img src=\"{$config['BASE_URL']}/images/{$style_array['general']}/rss_icon.gif\" /></a>";
  				$i++;
				}
			}
		}

  	// Now lets do the special array (PMs, Active Topics/Posts)
  	$special = array();
  	$numspecial = 3;
  	for ($i=1; $i<$numspecial+1; $i++) {
      $s = "RSS_SP{$i}";
  		$special[$i-1]['desc'] = '&nbsp;' . $ubbt_lang[$s];
  		$special[$i-1]['class'] = ($i&1) ? "alt-2" : "alt-1";
  		$special[$i-1]['feed']  = "<a href=\"{$config['FULL_URL']}/ubbthreads.php?ubb=myfeeds&sp=$i\"><img src=\"{$config['BASE_URL']}/images/{$style_array['general']}/rss_icon.gif\" /></a>";
  	}
  // It's all XML from here on in!
  } elseif ($fp) {                                                  // Forum posts
		$itemRows = getRowData(getIn(array($fp)), "TOPIC_LAST_REPLY_TIME", $maxRows);
		if (count($itemRows) > 0) {
			$chanTitle = htmlspecialchars($itemRows[0]['forumTitle']);
			$chanDesc = $ubbt_lang['RSS_POSTS_R'];
		}
  } elseif ($ft) {
  	$itemRows = getRowData(getIn(array($ft)), "TOPIC_CREATED_TIME", $maxRows);
		if (count($itemRows) > 0) {
			$chanTitle = htmlspecialchars($itemRows[0]['forumTitle']);
			$chanDesc = $ubbt_lang['RSS_TOPICS_R'];
		}
  } elseif ($sp == 1 && !$user['USER_ID']) {                         // Don't do that!
  		return $html->not_right($ubbt_lang['FATAL_NOT_LOGGED']);
  } elseif ($sp) {																									// Special
		switch($sp) {
			case "1":																											// Pm Inbox
				$itemRows = getPMData($maxRows);
				if (count($itemRows) > 0) {
					$chanTitle = "{$ubbt_lang['RSS_SP1']}";
					$chanDesc = $ubbt_lang['RSS_IN_DESC'];
				}
				break;
			case "2":																											// Recent topics all allowed
				$itemRows = getRowData(getIn(), "TOPIC_CREATED_TIME", $maxRows);
				if (count($itemRows) > 0) {
					$chanTitle = "{$ubbt_lang['RSS_SP2']}";
					$chanDesc = "{$ubbt_lang['RSS_ALL_FORUMS']}";
				}
				break;
			default:																											// Recent posts all allowed
				$itemRows = getRowData(getIn(), "TOPIC_LAST_REPLY_TIME", $maxRows);
				if (count($itemRows) > 0) {
					$chanTitle = "{$ubbt_lang['RSS_SP3']}";
					$chanDesc = "{$ubbt_lang['RSS_ALL_FORUMS']}";
				}
		}
  }
  if ($sendXML == 1) {
  	define('NO_WRAPPER',1);
  	header("Content-type: text/xml");
  }

	// Sanitize community title for XML
	$config['COMMUNITY_TITLE'] = htmlspecialchars($config['COMMUNITY_TITLE']);

	// Going to make this smarter!
  $smarty_data = array(
      "special" => $special,
      "rssForums" => $rssForums,
      "fp" => $fp,
      "ft" => $ft,
      "sp" => $sp,
      "itemRows" => $itemRows,
      "show" => $show,
      "chanTitle" => $chanTitle,
      "lastBuild" => $lastBuild,
      "chanDesc" => $chanDesc,
      "imgLink" => $imgLink,
      "mystuff" => $html->mystuff(),
      );

	// Nothing special here, just do vanilla breadcrumbs, grab our tpl and show the footer (only for My Stuff)
  return array(
   	"header" => array (
     	"title" => "{$ubbt_lang['MY_FEEDS']}",
       "refresh" => 0,
       "user" => $user,
       "Board" => "",
       "bypass" => 0,
       "onload" => "",
       "breadcrumb" => "<a href=\"{$imgLink}\">{$ubbt_lang['FORUM_TEXT']}</a> &raquo; {$ubbt_lang['RSS_INFO']}",
		),
    "template" => "myfeeds",
    "data" => & $smarty_data,
    "footer" => true,
    "location" => "",
   );
}

// Helper functions

function getRowData ($inForums, $orderBy, $limit) {
	global $html,$user,$ubbt_lang,$config,$style_array,$dbh,$var_start,$var_eq,$var_sep,$var_extra;

	$lclRows = array();
	$query = "
  		SELECT t.TOPIC_ID, t.TOPIC_SUBJECT,	t.TOPIC_LAST_REPLY_TIME,
  					 p.POST_ID, p.POST_BODY,
  					 u.USER_ID, u.USER_DISPLAY_NAME,
  					 f.FORUM_ID, f.FORUM_TITLE
  		FROM {$config['TABLE_PREFIX']}TOPICS as t,
  				 {$config['TABLE_PREFIX']}POSTS as p,
  				 {$config['TABLE_PREFIX']}USERS as u,
  				 {$config['TABLE_PREFIX']}FORUMS as f
  		WHERE	t.FORUM_ID IN $inForums
  		AND 	p.USER_ID = u.USER_ID
  		AND 	p.POST_ID = t.TOPIC_LAST_POST_ID
  		AND 	p.POST_IS_APPROVED = '1'
  		AND		f.FORUM_ID = t.FORUM_ID
  		ORDER BY t.$orderBy DESC
  		LIMIT $limit
	";
  $sth = $dbh->do_query($query,__LINE__,__FILE__);

  $i = 0;
  while (list($topicID, $topicSubject, $topicReplied, $postID, $postBody, $userID, $userName, $forumID, $forumTitle) = $dbh -> fetch_array($sth)) {
  	$lclRows[$i]['topicID']	= $topicID;
  	$lclRows[$i]['title'] = $topicSubject;
  	$lclRows[$i]['pubDate'] = $html->convert_time($topicReplied,$user['USER_TIME_OFFSET'],"rss");
	$lclRows[$i]['guid'] = make_ubb_url("ubb=showflat&Number={$postID}#Post{$postID}","",true); 
  	$lclRows[$i]['userID'] = $userID;
  	$lclRows[$i]['userName'] = $userName;
  	$lclRows[$i]['forumID']	= $forumID;
  	$lclRows[$i]['forumTitle'] = $forumTitle;
  	$topicReplied = $html->convert_time($topicReplied,$user['USER_TIME_OFFSET'],$user['USER_TIME_FORMAT'],false,true);
  	// Ok, gotta make this description validate w3c
  	$preBody = "{$ubbt_lang['RSS_BY']}<b>{$userName}</b><br /><u>{$ubbt_lang['RSS_ON']}{$topicReplied}</u><br /><br />";
  	$postBody = str_replace("{$config['BASE_URL']}", "{$config['FULL_URL']}",$postBody);
  	$postBody = str_replace("%%GRAEMLIN_URL%%",$style_array['graemlins'],$postBody);
  	$lclRows[$i]['desc'] = $preBody . $postBody;
  	$lclRows[$i]['link'] = $lclRows[$i]['guid'];
  	$i++;
  	}
  	if ($i == 0) {
			$lclRows[0]['title'] = "{$ubbt_lang['RSS_ERR_ITEM_TITLE']}";
			$lclRows[0]['desc'] = "{$ubbt_lang['RSS_ERR_ITEM_DESC']}";
			$lclRows[0]['link'] = make_ubb_url("ubb=cfrm", '', true); 
			}
  	return ($lclRows);
  }

	// Based upon the User (logged in or not), a string of csValues is returned
	// for use by an 'IN (xx,yy,zz)' clause
	//
	// Note: for guests (no valud USER_ID), the guest is used. This allows bots and
	//       anonymous feeders to be able to view feeds that are configured as 'read'
	//       by the board admin.
	//
	// Note: The caller can supply a specific forum too, which adds to the query
	function getIn($forums=array()) {
		global $tree, $userob;

		$inArray = array();
		if (sizeof($forums) > 0) {
			foreach ($forums as $fid) {
				if ($userob->check_access("forum","READ_TOPICS",$fid) && $tree['active'][$fid] == 1) {
					$inArray[] = $fid;
				}
			}
		} else {
			foreach($tree['categories'] as $catID => $catTitle) {
				if (!isset($tree[$catID])) continue;
				foreach($tree[$catID] as $fID => $fTitle) {
					if ($userob->check_access("forum","READ_TOPICS",$fID) && $tree['active'][$fID] == 1) {
						$inArray[] = $fID;
					}
				}
			}
		}

		if (sizeof($inArray) > 0) {
			$inForums = '(' . implode(',',$inArray) . ')';
		} else {
			$inForums = '(0)';
		}
		return $inForums;
	}

	function getPMData($limit) {
		global $html,$user,$ubbt_lang,$config,$style_array,$dbh,$var_start,$var_eq,$var_sep,$var_extra;

		// Force anons to failure in the query
		$u = (!$user['USER_ID']) ? 1 : $user['USER_ID'];

		$lclRows = array();
		$query = "
			SELECT	t.TOPIC_ID, t.TOPIC_SUBJECT, t.TOPIC_LAST_REPLY_TIME,
							p.POST_ID, p.POST_BODY,
							t.TOPIC_LAST_POSTER_ID, t.TOPIC_LAST_POSTER_NAME
			FROM	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS as t,
						{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS as u,
            {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS as p
			WHERE	u.USER_ID = '$u'
			AND		t.TOPIC_ID = u.TOPIC_ID
			AND		p.TOPIC_ID = t.TOPIC_ID
			ORDER BY t.TOPIC_LAST_REPLY_TIME DESC
			LIMIT $limit
		";
  	$sth = $dbh->do_query($query,__LINE__,__FILE__);

  	$i = 0;
  	while (list($topicID, $topicSubject, $topicReplied, $postID, $postBody, $userID, $userName) = $dbh -> fetch_array($sth)) {
  		$lclRows[$i]['topicID']	= $topicID;
  		$lclRows[$i]['title'] = $topicSubject;
  		$lclRows[$i]['pubDate'] = $html->convert_time($topicReplied,$user['USER_TIME_OFFSET'],"rss");
		$lclRows[$i]['guid'] = make_ubb_url("ubb=viewmessage&message={$topicID}&gonew=0","",true); 
  		$lclRows[$i]['userID'] = $userID;
  		$lclRows[$i]['userName'] = $userName;
  		$topicReplied = $html->convert_time($topicReplied,$user['USER_TIME_OFFSET'],$user['USER_TIME_FORMAT'],false,true);
  		// Ok, gotta make this description validate w3c
  		$preBody = "{$ubbt_lang['RSS_BY']}<b>{$userName}</b><br /><u>{$ubbt_lang['RSS_ON']}{$topicReplied}</u><br /><br />";
  		$postBody = str_replace("{$config['BASE_URL']}", "{$config['FULL_URL']}",$postBody);
  		$postBody = str_replace("%%GRAEMLIN_URL%%",$style_array['graemlins'],$postBody);
  		$lclRows[$i]['desc'] = $preBody . $postBody;
  		$lclRows[$i]['link'] = $lclRows[$i]['guid'];
  		$i++;
  		}
  		if ($i == 0) {
				$lclRows[0]['title'] = "{$ubbt_lang['RSS_ERR_ITEM_TITLE']}";
				$lclRows[0]['desc'] = "{$ubbt_lang['RSS_ERR_ITEM_DESC']}";
				$lclRows[0]['link'] = make_ubb_url("ubb=cfrm","",true); 
				}
  		return ($lclRows);
  	}
?>
