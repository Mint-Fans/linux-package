<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_newuser_gpc () {
	return array(
		"input" => array(
			"p" => array("p","get","alpha"),
		),
		"wordlets" => array("editbasic","editdisplay","newuser"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_newuser_gpc

function page_newuser_run () {

	global $smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$var_start,$var_eq,$var_sep,$var_extra,$style_array,$html,$userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// -----------------------------------------------------------------------
	// Make sure we have a minlength and maxlength -- add into lang string too
	if (!isset($config['MIN_PDN_LENGTH'])) { $config['MIN_PDN_LENGTH'] = '3'; }
	if (!isset($config['MIN_PDN_LENGTH'])) { $config['MAX_PDN_LENGTH'] = '3'; }
	$ubbt_lang['DISPLAY_IN'] = $html->substitute($ubbt_lang['DISPLAY_IN'], array(
		'MIN_PDN' => $config['MIN_PDN_LENGTH'],
		'MAX_PDN' => $config['MAX_PDN_LENGTH']));

	// -------------------------------------------------------------------------
	// Security check, make sure install, createtable, altertable files are gone
	$query = "
	SELECT COUNT(USER_DISPLAY_NAME)
	FROM   {$config['TABLE_PREFIX']}USERS
	";
	$sth = $dbh -> do_query($query,__LINE__,__FILE__);
	list($usercheck) = $dbh -> fetch_array($sth);
	if ($usercheck < 2) {
		if (file_exists("install")) {
			$html->not_right("You need to delete the entire install directory before creating your admin user.");
		}
	}

	if (isset($config['SUSPEND_REGISTRATIONS']) && $config['SUSPEND_REGISTRATIONS']) {
		$html->not_right($ubbt_lang['REG_OFF']);
	}

	// ---------------------
	// Grab the tablewrapper
	list($tbopen,$tbclose) = table_wrapper();

	// ------------------------------------------------------
	// If we are checking ages, the we need to do this first
	if ( ($config['DO_AGE_CHECK']) && ($p != "y") ) {

		$currentyear = date("Y");
		if (isset($_COOKIE[$config['COOKIE_PREFIX'] . "ubbt_dob"])) {
			list($month,$day,$year) = preg_split("#/#",$_COOKIE[$config['COOKIE_PREFIX'] . "ubbt_dob"]);
			$months = array('','JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC');
			$formprint = "
			{$ubbt_lang['DOB_EXIST']}
			{$ubbt_lang[$months[$month]]} $day, $year
			<input type=\"hidden\" name=\"month\" value=\"$month\" />
			<input type=\"hidden\" name=\"day\" value=\"$day\" />
			<input type=\"hidden\" name=\"year\" value=\"$year\" />
			";
		}
		else {
			$formprint = "
			{$ubbt_lang['DOB']}<br />
			<select name=\"month\" class=\"form-select\">
			<option value=\"\">{$ubbt_lang['MONTH']}</option>
			<option value=\"1\">{$ubbt_lang['JAN']}</option>
			<option value=\"2\">{$ubbt_lang['FEB']}</option>
			<option value=\"3\">{$ubbt_lang['MAR']}</option>
			<option value=\"4\">{$ubbt_lang['APR']}</option>
			<option value=\"5\">{$ubbt_lang['MAY']}</option>
			<option value=\"6\">{$ubbt_lang['JUN']}</option>
			<option value=\"7\">{$ubbt_lang['JUL']}</option>
			<option value=\"8\">{$ubbt_lang['AUG']}</option>
			<option value=\"9\">{$ubbt_lang['SEP']}</option>
			<option value=\"10\">{$ubbt_lang['OCT']}</option>
			<option value=\"11\">{$ubbt_lang['NOV']}</option>
			<option value=\"12\">{$ubbt_lang['DEC']}</option>
			</select>
			<select name=\"day\" class=\"form-select\">
			<option value=\"\">{$ubbt_lang['DAY']}</option>
			";
			for ($i=1;$i<=31;$i++) {
				$formprint .= "<option value=\"$i\">$i</option>";
			}
			$formprint .= "</select> <select name=\"year\" class=\"form-select\">";
			$formprint .= "<option value=\"\">{$ubbt_lang['YEAR']}</option>";
			for ($i=$currentyear;$i>=($currentyear-100);$i--) {
				$formprint .= "<option value=\"$i\">$i</option>";
			}
			$formprint .= "
			</select>
			";
		}

		$smarty_data['formprint'] = & $formprint;

		return array(
			"header" => array (
				"title" => $ubbt_lang['AGE_VER'],
				"refresh" => 0,
				"user" => "",
				"Board" => "",
				"bypass" => 0,
				"onload" => "",
			),
			"template" => "newuser_checkage",
			"data" => & $smarty_data,
			"footer" => true,
			"location" => "",
		);
		exit;
	}

	// If they haven't accepted the board rules, then they get
	// that page next
	$ocurl = make_ubb_url("ubb=newuser", "", true);

	if (!$_SESSION['rules_accept'] && ($rules = @file_get_contents("{$config['FULL_PATH']}/includes/boardrules.php"))) {
		$smarty_data = array(
			"ocurl" => "$ocurl",
			"rules" => "$rules",
		);

		return array(
			"header" => array (
				"title" => "{$ubbt_lang['BOARD_RULES']}",
				"refresh" => 0,
				"user" => $user,
				"Board" => "",
				"bypass" => 0,
				"onload" => "",
			),
			"template" => "boardrules",
			"data" => & $smarty_data,
			"footer" => true,
			"location" => "",
			"redirect" => "",
		);
		exit;
	} // end if


	$requiredfields = "";
	$optionalfields = "";

	// Grab the registration screen options
	$query = "
	SELECT REGISTRATION_FIELD,REGISTRATION_SHOW_FIELD,REGISTRATION_REQUIRE_FIELD
	FROM {$config['TABLE_PREFIX']}REGISTRATION_FIELDS
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	while(list($field,$show,$require) = $dbh->fetch_array($sth)) {
		if ($show) {
			$regopt[$field]['show'] = $show;
		}
		if ($require) {
			$regopt[$field]['require'] = $require;
		}
	}

	// This whole section below is quite messy, edit at your own risk :)

	// FAKE EMAIL SELECTION
	if (isset($regopt['USER_DISPLAY_EMAIL'])) {
		$thisoption = <<<EOF
		<tr>
		<td class="alt-1" width="50%">
		<label for="USER_DISPLAY_EMAIL">{$ubbt_lang['FAKE_EMAIL']}</label>
		</td>
		<td class="alt-1" width="50%">
		<input type="text" id="USER_DISPLAY_EMAIL" name="USER_DISPLAY_EMAIL" class="form-input" size="40" />
		</td>
		</tr>
EOF;
		if (isset($regopt['USER_DISPLAY_EMAIL']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_DISPLAY_EMAIL']['show'])) {
			$optionalfields .= $thisoption;
		}
	}
	// END FAKE EMAIL SELECTION

	// BIRTHDAY SELECTION
	if ($config['DO_AGE_CHECK']) {
		list($month,$day,$year) = preg_split("#/#",$_COOKIE[$config['COOKIE_PREFIX'] . "ubbt_dob"]);

		// -----------------------------------------
		// Generate the birthday selection formboxes
		$thisoption = "<input type='hidden' name='bmonth' value=\"$month\" />";
		$thisoption .= "<input type='hidden' name='bday' value=\"$day\" />";
		$thisoption .= "<input type='hidden' name='byear' value=\"$year\" />";
		$bday_text = $ubbt_lang['SHOWBDAY'];
		if (!$config['BIRTHDAYS_IN_CALENDAR']) {
			$bday_text = $ubbt_lang['SHOWBDAY_NOCAL'];
		}

		$thisoption .= <<<EOF
		<tr>
		<td class="alt-1" width="50%">
		<label for="USER_PUBLIC_BIRTHDAY">$bday_text</label>
		</td>
		<td class="alt-1" width="50%">
		<input type="checkbox" id="USER_PUBLIC_BIRTHDAY" name="USER_PUBLIC_BIRTHDAY" value="1" class="form-checkbox" />
		</td>
		</tr>
EOF;

		if (isset($regopt['USER_BIRTHDAY']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_BIRTHDAY']['show'])) {
			$optionalfields .= $thisoption;
		}
	} // end if

	if ((isset($regopt['USER_BIRTHDAY'])) && (!$config['DO_AGE_CHECK'])) {
		$thisoption = <<<EOF
		<tr>
		<td class="alt-1" width="50%">
		{$ubbt_lang['BIRTHDAY']}
		</td>
		<td class="alt-1" width="50%">
EOF;

		// -----------------------------------------
		// Generate the birthday selection formboxes
		$thisoption .= "<select name=\"bmonth\" class=\"form-select\">";
		$thisoption .= "<option value=\"\">{$ubbt_lang['MONTH']}</option>";
		for ($i=1;$i<=12;$i++) {
			$mname = "MONTH$i";
			$mname = $ubbt_lang[$mname];
			$thisoption .= "<option value=\"$i\">$mname</option>";
		}
		$thisoption .= "</select>";

		$thisoption .= "<select name=\"bday\" class=\"form-select\">";
		$thisoption .= "<option value=\"\">{$ubbt_lang['DAY']}</option>";
		for ($i=1;$i<=31;$i++) {
			$thisoption .= "<option>$i</option>";
		}
		$thisoption .= "</select>";

		$thisoption .= "<select name=\"byear\" class=\"form-select\">";
		$thisoption .= "<option value=\"\">{$ubbt_lang['YEAR']}</option>";
		$temp = getdate();
		$thisyear  = $temp["year"];
		for ($i=$thisyear;$i>=1900;$i--) {
			$thisoption .= "<option>$i</option>";
		}
		$thisoption .= "</select>";

		$thisoption .= <<<EOF
		</select>
		</td>
		</tr>
EOF;

		$bday_text = $ubbt_lang['SHOWBDAY'];
		if (!$config['BIRTHDAYS_IN_CALENDAR']) {
			$bday_text = $ubbt_lang['SHOWBDAY_NOCAL'];
		}

		$thisoption .= <<<EOF
		<tr>
		<td class="alt-1" width="50%">
		<label for="USER_PUBLIC_BIRTHDAY">$bday_text</label>
		</td>
		<td class="alt-1" width="50%">
		<input type="checkbox" id="USER_PUBLIC_BIRTHDAY" name="USER_PUBLIC_BIRTHDAY" value="1" class="form-checkbox" />
		</td>
		</tr>
EOF;

		if (isset($regopt['USER_BIRTHDAY']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_BIRTHDAY']['show'])) {
			$optionalfields .= $thisoption;
		}
	}
	// END BIRTHDAY SELECTION

	// PICTURE SELECTION

	$allowpics = "";
	if ($userob->check_access("site","UPLOAD_AVATARS")) {
		$pictureview = "
		<input type=\"radio\" name=\"picchange\" id=\"picchange-upload\" value=\"upload\" class=\"form-radio\" />
		<label for=\"picchange-upload\">{$ubbt_lang['UPLOAD_PIC_SHORT']}</label>
		<input type=\"file\" name=\"userfile\" accept=\"*\" class=\"form-input\" />
		<br /><br />
		";
		$allowpics = 1;
	}

	if ($userob->check_access("site","REMOTE_AVATARS")) {
		$Picture ="http://";
		$pictureview .= "
		<input type=\"radio\" name=\"picchange\" id=\"picchange-url\" value=\"url\" class=\"form-radio\" />
		<label for=\"picchange-url\">{$ubbt_lang['PROF_PIC_SHORT']}</label>
		<input type=\"text\" name=\"USER_AVATAR\" size=\"50\" class=\"form-input\" />
		<br />
		<br />
		";
		$allowpics = 1;
	}

	$stockavatar = "";
	if ($userob->check_access("site","STOCK_AVATARS")) {
		$stockavatar = <<<EOF
		<input type="radio" name="picchange" id="picchange-avatar" value="avatar" class="form-radio" />
		<label for="picchange-avatar">{$ubbt_lang['PREDEF_PIC']}</label><br />
		<!-- 2 --><img name="avimg" alt="" border="1" src="{$config['BASE_URL']}/images/{$style_array['general']}/blank.gif" height="48" width="48" /><!-- 4 -->&nbsp; <a href="javascript:launch_avatar_window();">{$ubbt_lang['PREDEF_CHOOSE']}</a> &nbsp;
		<input type="hidden" name="avurl" value="" />
		<input type="hidden" name="avwidth" value="" />
		<input type="hidden" name="avheight" value="" />
		<br />
		<br />
EOF;
		$allowpics = 1;
	}

	$picchangetext = "";
	$picchangeclose = "";
	if ($allowpics) {
		$PicWidth = $config['AVATAR_MAX_WIDTH'];
		$PicHeight = $config['AVATAR_MAX_HEIGHT'];
		$picchangetext .= "<input type=\"radio\" name=\"picchange\" id=\"picchange-nopic\" value=\"nopic\" class=\"form-radio\" checked=\"checked\"> <label for=\"picchange-nopic\">{$ubbt_lang['NONE']}</label><br />";

	}
	$base = make_ubb_url("", "", false);
	$avatarscript = <<<EOF
	<script language="JavaScript" type="text/javascript">
	// <![CDATA[
	function launch_avatar_window() {
		var avatar_popup_width = 550;
		var avatar_popup_height =  300;
		var Avatarselection = escape(document.PROFILE.avurl.value);
		var avatar_selector_page = "{$base}?ubb=avatar&start_with=0&form=PROFILE";
		var selector = window.open(avatar_selector_page + '&avatar_url=' + Avatarselection,'selector','scrollbars=yes,resizable=yes,width=' + avatar_popup_width + ',height=' + avatar_popup_height + ',screenX=50,screenY=50,top=50,left=50');
	} // end function
	// ]]>
	</script>
EOF;

	if (isset($regopt['USER_AVATAR'])) {
		$thisoption = <<<EOF
		<tr>
		<td class="alt-1" width="50%" valign="top">
		{$ubbt_lang['AVATAR']}
		</td>
		<td class="alt-1" width="50%">
		$picchangetext
		$avatarscript
		$pictureview
		$stockavatar
		$picchangeclose
		</td>
		</tr>
EOF;
		if (isset($regopt['USER_AVATAR']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_AVATAR']['show'])) {
			$optionalfields .= $thisoption;
		}
	}
	// END PICTURE SELECTION

	// PRIVATE MESSAGE SELECTION
	if (isset($regopt['USER_ACCEPT_PM'])) {
		$thisoption = <<<EOF
		<tr>
		<td class="alt-1" width="50%">
		<label for="USER_ACCEPT_PM">{$ubbt_lang['PROF_PRIV']}</label>
		</td>
		<td class="alt-1" width="50%">
		<select name="USER_ACCEPT_PM" id="USER_ACCEPT_PM" class="form-select">
		<option value="yes" selected="selected">{$ubbt_lang['TEXT_YES']}</option>
		<option value="no">{$ubbt_lang['TEXT_NO']}</option>
		</select>
		</td>
		</tr>
EOF;
		if (isset($regopt['USER_ACCEPT_PM']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_ACCEPT_PM']['show'])) {
			$optionalfields .= $thisoption;
		}
	}
	// END PRIVATE MESSAGE SELECTION

	// SIGNATURE SELECTION
	if (isset($regopt['USER_SIGNATURE'])) {
		$query = "
			select SIGNATURE_LENGTH
			from {$config['TABLE_PREFIX']}SITE_PERMISSIONS
			where GROUP_ID='4'
		";
		$sth = $dbh->do_query($query,__LINE__,__FILE__);
		list($len) = $dbh->fetch_array($sth);
		$sig_string = $html->substitute($ubbt_lang['PROF_SIG'], array(
		'SIG_LEN' => $len,
		'FAQ_ADDY' => make_ubb_url("ubb=faq#html","",false)));
		$thisoption = <<<EOF
		<tr>
		<td class="alt-1" width="50%" valign="top">
		<label for="USER_SIGNATURE">$sig_string</label>
		</td>
		<td class="alt-1" width="50%">
		<textarea name="USER_SIGNATURE" id="USER_SIGNATURE" class="form-input" rows="3" cols="40" /></textarea>
		</td>
		</tr>
EOF;
		if (isset($regopt['USER_SIGNATURE']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_SIGNATURE']['show'])) {
			$optionalfields .= $thisoption;
		}
	}
	// END SIGNATURE SELECTION

	// HOMEPAGE SELECTION
	if (isset($regopt['USER_HOMEPAGE'])) {
		$thisoption = <<<EOF
		<tr>
		<td class="alt-1" width="50%">
		<label for="USER_HOMEPAGE">{$ubbt_lang['PROF_HOME']}</label>
		</td>
		<td class="alt-1" width="50%">
		<input type="text" name="USER_HOMEPAGE" id="USER_HOMEPAGE" class="form-input" size="40" />
		</td>
		</tr>
EOF;
		if (isset($regopt['USER_HOMEPAGE']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_HOMEPAGE']['show'])) {
			$optionalfields .= $thisoption;
		}
	}
	// END HOMEPAGE SELECTION

	// OCCUPATION SELECTION
	if (isset($regopt['USER_OCCUPATION'])) {
		$thisoption = <<<EOF
		<tr>
		<td class="alt-1" width="50%">
		<label for="USER_OCCUPATION">{$ubbt_lang['PROF_OCC']}</label>
		</td>
		<td class="alt-1" width="50%">
		<input type="text" name="USER_OCCUPATION" id="USER_OCCUPATION" class="form-input" size="40" />
		</td>
		</tr>
EOF;
		if (isset($regopt['USER_OCCUPATION']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_OCCUPATION']['show'])) {
			$optionalfields .= $thisoption;
		}
	}
	// END OCCUPATION SELECTION

	// HOBBIES SELECTION
	if (isset($regopt['USER_HOBBIES'])) {
		$thisoption = <<<EOF
		<tr>
		<td class="alt-1" width="50%">
		<label for="USER_HOBBIES">{$ubbt_lang['PROF_HOBB']}</label>
		</td>
		<td class="alt-1" width="50%">
		<input type="text" name="USER_HOBBIES" id="USER_HOBBIES" class="form-input" size="40"/>
		</td>
		</tr>
EOF;
		if (isset($regopt['USER_HOBBIES']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_HOBBIES']['show'])) {
			$optionalfields .= $thisoption;
		}
	}
	// END HOBBIES SELECTION

	// LOCATION SELECTION
	if (isset($regopt['USER_LOCATION'])) {
		$thisoption = <<<EOF
		<tr>
		<td class="alt-1" width="50%">
		<label for="USER_LOCATION">{$ubbt_lang['PROF_LOC']}</label>
		</td>
		<td class="alt-1" width="50%">
		<input type="text" name="USER_LOCATION" id="USER_LOCATION" class="form-input" size="40" />
		</td>
		</tr>
EOF;
		if (isset($regopt['USER_LOCATION']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_LOCATION']['show'])) {
			$optionalfields .= $thisoption;
		}
	}
	// END LOCATION SELECTION

	// ICQ SELECTION
	if (isset($regopt['USER_ICQ'])) {
		$thisoption = <<<EOF
		<tr>
		<td class="alt-1" width="50%">
		<label for="USER_ICQ">{$ubbt_lang['PROF_ICQ']}</label>
		</td>
		<td class="alt-1" width="50%">
		<input type="text" id="USER_ICQ" name="USER_ICQ" class="form-input" />
		</td>
		</tr>
EOF;
		if (isset($regopt['USER_ICQ']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_ICQ']['show'])) {
			$optionalfields .= $thisoption;
		}
	}
	// END ICQ SELECTION

	// EXTRAS SELECTION
	for ($i = 1; $i <= 5; $i++) {
		$field = 'USER_EXTRA_FIELD_' . $i;
		$config_field = 'CUSTOM_FIELD_' . $i;
		if (isset($regopt[$field])) {
			$thisoption = <<<EOF
			<tr>
			<td class="alt-1" width="50%">
			<label for="$field">{$config[$config_field]}</label>
			</td>
			<td class="alt-1" width="50%">
			<input type="text" name="$field" id="$field" class="form-input" size="40" />
			</td>
			</tr>
EOF;
			if (isset($regopt[$field]['require'])) {
				$requiredfields .= $thisoption;
			}
			elseif (isset($regopt[$field]['show'])) {
				$optionalfields .= $thisoption;
			}
		}
	}
	// END EXTRAS SELECTION


	// VISIBLE SELECTION
	if (isset($regopt['USER_VISIBLE_ONLINE_STATUS'])) {
		$thisoption = <<<EOF
		<tr>
		<td class="alt-1" width="50%">
		<label for="USER_VISIBLE_ONLINE_STATUS">{$ubbt_lang['ONLINE_HIDE']}</label>
		</td>
		<td class="alt-1" width="50%">
		<select name="USER_VISIBLE_ONLINE_STATUS" id="USER_VISIBLE_ONLINE_STATUS">
		<option value="no">{$ubbt_lang['TEXT_YES']}</option>
		<option value="yes" selected="selected">{$ubbt_lang['TEXT_NO']}</option>
		</select>
		</td>
		</tr>
EOF;
		if (isset($regopt['USER_VISIBLE_ONLINE_STATUS']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_VISIBLE_ONLINE_STATUS']['show'])) {
			$optionalfields .= $thisoption;
		}
	}
	// END VISIBLE SELECTION

	// TIMEFORMAT SELECTION
	if (isset($regopt['USER_TIME_FORMAT'])) {

		$thisoption = <<<EOF
		<tr>
		<td class="alt-1" width="50%">
		<label for="USER_TIME_FORMAT">{$ubbt_lang['TIMEFORMAT']}</label>
		</td>
		<td class="alt-1" width="50%">
		<select name="USER_TIME_FORMAT" id="USER_TIME_FORMAT" class="form-select">
EOF;
		if (!$timeformat) { $timeformat = $config['TIME_FORMAT']; }

		foreach($config['TIME_FORMATS'] as $k => $v) {
			$selected = "";
			if ($timeformat == $v) {
				$selected = "selected=\"selected\"";
			}
			$thisoption .= "<option value=\"$k\" $selected>" . $html->convert_time(time(),0,$v,1) . "</option>";
		}
		$thisoption .= "</select>";
		if (isset($regopt['USER_TIME_FORMAT']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_TIME_FORMAT']['show'])) {
			$optionalfields .= $thisoption;
		}
	}
	// END TIMEFORMAT SELECTION

	// TIMEOFFSET SELECTION
	if (isset($regopt['USER_TIME_OFFSET'])) {
		$date = $html -> get_date();
		$time = $html -> convert_time($date,0,$timeformat,1);
		$thisoption = <<<EOF
		<tr>
		<td class="alt-1" width="50%">
		<label for="USER_TIME_OFFSET">{$ubbt_lang['YOUR_OFFSET']}</label><br />
		{$ubbt_lang['CURR_TIME']} $time<br />
		</td>
		<td class="alt-1" width="50%" valign="top">
		<input type="text" name="USER_TIME_OFFSET" id="USER_TIME_OFFSET" class="form-input" size="3" value="0" />
		</td>
		</tr>
EOF;
		if (isset($regopt['USER_TIME_OFFSET']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_TIME_OFFSET']['show'])) {
			$optionalfields .= $thisoption;
		}
	}
	// END TIMEOFFSET SELECTION

	// SHOW SIGS SELECTION
	if (isset($regopt['USER_SHOW_SIGNATURES'])) {
		$thisoption = <<<EOF
		<tr>
		<td class="alt-1" width="50%">
		<label for="USER_SHOW_SIGNATURES">{$ubbt_lang['VIEW_SIGS']}</label>
		</td>
		<td class="alt-1" width="50%">
		<select name="USER_SHOW_SIGNATURES" id="USER_SHOW_SIGNATURES">
		<option value="yes" selected="selected">{$ubbt_lang['TEXT_YES']}</option>
		<option value="no">{$ubbt_lang['TEXT_NO']}</option>
		</select>
		</td>
		</tr>
EOF;
		if (isset($regopt['USER_SHOW_SIGNATURES']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_SHOW_SIGNATURES']['show'])) {
			$optionalfields .= $thisoption;
		}
	}
	// END SHOWSIGS SELECTION

	// DISPLAY SELECTION
	if (isset($regopt['USER_TOPIC_VIEW_TYPE']) && $config['TOPIC_DISPLAY_OPTIONS'] == "both") {

		$thisoption = <<<EOF
		<tr>
		<td class="alt-1" width="50%">
		<label for="USER_TOPIC_VIEW_TYPE">{$ubbt_lang['PROF_DISP']}</label>
		</td>
		<td class="alt-1" width="50%">
		<select name="USER_TOPIC_VIEW_TYPE" id="USER_TOPIC_VIEW_TYPE" class="form-select">
		<option value="threaded">{$ubbt_lang['TEXT_THREAD']}</option>
		<option value="flat" selected="selected">{$ubbt_lang['TEXT_FLAT']}</option>
		</select>
		</td>
		</tr>
EOF;
		if (isset($regopt['USER_TOPIC_VIEW_TYPE']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_TOPIC_VIEW_TYPE']['show'])) {
			$optionalfields .= $thisoption;
		}
	}
	// END DISPLAY SELECTION

	// POSTSPER SELECTION
	if (isset($regopt['USER_TOPICS_PER_PAGE'])) {
		$thisoption = <<<EOF
		<tr>
		<td class="alt-1" width="50%">
		<label for="USER_TOPICS_PER_PAGE">{$ubbt_lang['PROF_POSTS_SHORT']}</label>
		</td>
		<td class="alt-1" width="50%">
		<input type="text" name="USER_TOPICS_PER_PAGE" id="USER_TOPICS_PER_PAGE" class="form-input" value="{$config['TOPICS_PER_PAGE']}" size="3" />
		</td>
		</tr>
EOF;
		if (isset($regopt['USER_TOPICS_PER_PAGE']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_TOPICS_PER_PAGE']['show'])) {
			$optionalfields .= $thisoption;
		}
	}
	// END POSTSPER SELECTION

	// FLATPOSTS SELECTION
	if (isset($regopt['USER_POSTS_PER_TOPIC'])) {
		$thisoption = <<<EOF
		<tr>
		<td class="alt-1" width="50%">
		<label for="USER_POSTS_PER_TOPIC">{$ubbt_lang['TOT_FLAT_SHORT']}</label>
		</td>
		<td class="alt-1" width="50%">
		<input type="text" name="USER_POSTS_PER_TOPIC" id="USER_POSTS_PER_TOPIC" class="form-input" value="{$config['POSTS_PER_PAGE']}" size="3" />
		</td>
		</tr>
EOF;
		if (isset($regopt['USER_POSTS_PER_TOPIC']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_POSTS_PER_TOPIC']['show'])) {
			$optionalfields .= $thisoption;
		}
	}
	// END FLATPOSTS SELECTION

	// ADMIN EMAILS SELECTION
	if (isset($regopt['USER_ACCEPT_ADMIN_EMAILS'])) {
		$thisoption = <<<EOF
		<tr>
		<td class="alt-1" width="50%">
		<label for="USER_ACCEPT_ADMIN_EMAILS">{$ubbt_lang['ADMIN_EMAIL']}</label>
		</td>
		<td class="alt-1" width="50%">
		<select name="USER_ACCEPT_ADMIN_EMAILS" id="USER_ACCEPT_ADMIN_EMAILS">
		<option value="On" selected="selected">{$ubbt_lang['TEXT_YES']}</option>
		<option value="Off">{$ubbt_lang['TEXT_NO']}</option>
		</select>
		</td>
		</tr>
EOF;
		if (isset($regopt['USER_ACCEPT_ADMIN_EMAILS']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_ACCEPT_ADMIN_EMAILS']['show'])) {
			$optionalfields .= $thisoption;
		}
	}
	// END ADMIN EMAILS SELECTION

	// NOTIFY SELECTION
	if (isset($regopt['USER_NOTIFY_ON_PM'])) {
		$thisoption = <<<EOF
		<tr>
		<td class="alt-1" width="50%">
		<label for="USER_NOTIFY_ON_PM">{$ubbt_lang['PROF_NOTIF']}</label>
		</td>
		<td class="alt-1" width="50%">
		<select name="USER_NOTIFY_ON_PM" id="USER_NOTIFY_ON_PM">
		<option value="On" selected="selected">{$ubbt_lang['TEXT_YES']}</option>
		<option value="Off">{$ubbt_lang['TEXT_NO']}</option>
		</select>
		</td>
		</tr>
EOF;
		if (isset($regopt['USER_NOTIFY_ON_PM']['require'])) {
			$requiredfields .= $thisoption;
		}
		elseif (isset($regopt['USER_NOTIFY_ON_PM']['show'])) {
			$optionalfields .= $thisoption;
		}
	}

	if ($optionalfields) {
		$optionalfields = <<<EOF
		$tbopen
		<tr>
		<td class="tdheader" colspan="2">
		{$ubbt_lang['OPTIONAL']}
		</td>
		</tr>
		$optionalfields
		<tr>
		<td align="center" class="alt-2" colspan="2">
		<input type="submit" name="buttsubmit" value="{$ubbt_lang['BUTT_SUBMIT']}" class="form-button" />
		</td>
		</tr>
		$tbclose
EOF;
	}


	// Setup the form type:
	if ( $userob->check_access("site","UPLOAD_AVATARS") &&(ini_get('file_uploads')) ){
		$enctype = "enctype=\"multipart/form-data\"";
	}
	else {
		$enctype = "";
	}


	$smarty_data = array(
		"enctype" => $enctype,
		"p" => $p,
		"requiredfields" => & $requiredfields,
		"optionalfields" => & $optionalfields,
	);

	return array(
		"header" => array (
			"title" => $ubbt_lang['NEW_USER'],
			"refresh" => 0,
			"user" => "",
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"javascript" => array(
				0 => "image.js",
			),
		),
		"template" => "newuser_signup",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
