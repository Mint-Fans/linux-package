<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_online_gpc () {
	return array(
		"input" => array(
		),
		"wordlets" => array("online"),
		"user_fields" => "t2.USER_TIME_FORMAT, t2.USER_TOPIC_VIEW_TYPE",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_online_gpc

function page_online_run () {

	global $smarty,$userob,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// Define any necessary variables
	$anonrow = array();
	$regrow = array();
	$botrow = array();

	$toffset = "";
	isset($user['USER_TIME_OFFSET']) && $toffset = $user['USER_TIME_OFFSET'];
	!isset($user['USER_TIME_FORMAT']) && $user['USER_TIME_FORMAT'] = $config['TIME_FORMAT'];

	// Grab all of the known agents from the database
	$agent_array = get_spider_list();
	$known_agents = array();

	// -------------------------
	// Delete the inactive users
	clear_online();

	// ------------------
	// Send a html header
	$query = "
	SELECT t1.ONLINE_DISPLAY_NAME, t1.ONLINE_LAST_ACTIVITY, t1.ONLINE_SCRIPT_NAME,t1.ONLINE_BROWSING_FORUM,t3.USER_MEMBERSHIP_LEVEL,t2.USER_VISIBLE_ONLINE_STATUS,t2.USER_TITLE,t2.USER_CUSTOM_TITLE,t2.USER_NAME_COLOR,t2.USER_ID,t1.ONLINE_USER_IP,t1.ONLINE_REFERER,t1.ONLINE_AGENT,t2.USER_MOOD,t1.ONLINE_POST_ID,t1.ONLINE_POST_SUBJECT
	FROM   {$config['TABLE_PREFIX']}ONLINE AS t1
	LEFT JOIN {$config['TABLE_PREFIX']}USER_PROFILE AS t2
	ON t1.USER_ID = t2.USER_ID
	LEFT JOIN {$config['TABLE_PREFIX']}USERS as t3
	ON t2.USER_ID = t3.USER_ID
	WHERE  t1.ONLINE_USER_TYPE like '%r%'
	ORDER BY t1.ONLINE_LAST_ACTIVITY DESC
	";
	$reged = $dbh -> do_query($query,__LINE__,__FILE__);
	$regrows = $dbh -> total_rows($reged);

	$color = "alt-1";

	// Array key tracker
	$x = 0;



	while (list($Username,$Last,$RealWhat,$Board,$Status,$Visible,$Title,$CustomTitle,$Color,$Uid,$IP,$referer,$agent,$mood,$post_id,$post_subject) = $dbh -> fetch_array($reged) ) {

		$referer = preg_replace("#<#","&lt;",$referer);
		$agent = preg_replace("#<#","&lt;",$agent);

		$mode = array_get($user, 'USER_TOPIC_VIEW_TYPE', $config['TOPIC_DISPLAY_STYLE']);
		if (!$mode) $mode = "flat";

		// -----------------------------------------------
		// Let's see if we need to block some information
		$Private = 0;
		if ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator") {
			$Private = 1;
		}
		// ------------------------------------------------------
		// Replace their location with something that makes sense
		// FIXME:  Online location is b0rked
		$What = $ubbt_lang[$RealWhat];
		if (!$What) { $What = $ubbt_lang['all_admin']; }


		if ((!$config['DISABLE_ONLINE_INVISIBLE']) && ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator") && ($Visible == "no") ) {
			continue;
		}
		$extra = "";
		if ($Visible == "no" && !$config['DISABLE_ONLINE_INVISIBLE']) {
			$extra = "(I)";
		}
		$regrow[$x]['extra'] = $extra;
		$Last = $html -> convert_time($Last,$toffset,$user['USER_TIME_FORMAT']);
		$EUsername = $Uid;
		$PUsername = $html->user_color($Username, $Color, $Status);

		if ($Status == "Administrator") {
			$Status = $ubbt_lang['USER_ADMIN'];
		}
		if ($Status == "GlobalModerator") {
			$Status = $ubbt_lang['USER_GMOD'];
		}
		if ($Status == "Moderator") {
			$Status = $ubbt_lang['USER_MOD'];
		}
		if ($Status == "User") { $Status = $ubbt_lang['USER_USER']; }

		// Set a default mood
		if (!$mood) $mood = "content.gif";

		$mood_pieces = explode(".",$mood);

		$regrow[$x]['color'] = $color;
		$regrow[$x]['EUsername'] = $EUsername;
		$regrow[$x]['PUsername'] = $PUsername;
		$regrow[$x]['Username'] = $Username;
		$regrow[$x]['referer'] = $referer;
		$regrow[$x]['agent'] = $agent;
		$regrow[$x]['mood'] = $mood;
		$regrow[$x]['mood_alt'] = preg_replace("#.(gif|jpg|png)$#","",$mood);

		$legend = $ubbt_lang['THREAD'];
		if ($Board) {
			if (!isset($Boards[$Board])) {
				$query = "SELECT FORUM_TITLE,FORUM_IS_GALLERY FROM {$config['TABLE_PREFIX']}FORUMS WHERE FORUM_ID='$Board'";
				$sti = $dbh -> do_query($query,__LINE__,__FILE__);
				list($thisboard,$isgallery) = $dbh->fetch_array($sti);
				$Boards[$Board]['title'] = $thisboard;
				$Boards[$Board]['gallery'] = $isgallery;
			} // end if
			if ($Boards[$Board]['gallery']) {
				$What = $ubbt_lang['showgallery'];
				$mode = "gallery";
				$legend = $ubbt_lang['GALLERY'];
			}
			$Extra = "<span class=\"small\"><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{$ubbt_lang['FORUM']} <a href=\"" . make_ubb_url("ubb=postlist&Board=$Board", $Boards[$Board]['title'], false) . "\">{$Boards[$Board]['title']}</a></span>";
		} // end if

		if ($post_id) {
			$Extra .= "<span class=\"small\"><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$legend <a href=\"" . make_ubb_url("ubb=show{$mode}&Number=$post_id#Post$post_id", $post_subject, false) . "\">$post_subject</a></span>";
		} // end if

		if ($Board) {
			if (!$userob->check_access("forum","SEE_FORUM",$Board)) {
				$Extra = "";
			} // end if
		} else {
			$Extra = "";
		} // end if

		if ($CustomTitle && $config['ONLY_CUSTOM']) {
			$Title = "$CustomTitle";
		}
		if ($CustomTitle && !$config['ONLY_CUSTOM']) {
			$Title = "$CustomTitle<br />$Title";
		}

		$regrow[$x]['Status']       = $Status;
		$regrow[$x]['Title']        = $Title;
		$regrow[$x]['Last']         = $Last;
		$regrow[$x]['What']         = $What;
		$regrow[$x]['Extra']        = $Extra;
		$regrow[$x]['IP']           = $IP;

		$color = $html -> switch_colors($color);
		$x++;

	}
	$regsize = 0;
	if (isset($regrow)) {
		$regsize = sizeof($regrow);
	}
	$dbh -> finish_sth($reged);

	// ----------------------------------------
	// Now show the one's that aren't logged in
	$query = "
	SELECT ONLINE_DISPLAY_NAME,ONLINE_LAST_ACTIVITY,ONLINE_SCRIPT_NAME,ONLINE_BROWSING_FORUM,ONLINE_USER_IP,ONLINE_REFERER,ONLINE_AGENT,ONLINE_POST_ID,ONLINE_POST_SUBJECT
	FROM   {$config['TABLE_PREFIX']}ONLINE
	WHERE  ONLINE_USER_TYPE like '%a%'
	ORDER BY ONLINE_LAST_ACTIVITY DESC
	";
	$unreged = $dbh -> do_query($query,__LINE__,__FILE__);
	if ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator" || preg_match("/Moderator/",$user['USER_MEMBERSHIP_LEVEL'])) {
		$column = $ubbt_lang['FROM_IP'];
	}
	else {
		$column = $ubbt_lang['USERNAME_TEXT'];
	}
	$colorAnon = "alt-1";
	$colorBot = "alt-1";

	$What = "";
	$Extra = "";

	// Anonrow array key number
	$a = 0;
	$b = 0;
	while (list($Username,$Last,$RealWhat,$Board,$IP,$referer,$agent,$post_id,$post_subject) = $dbh -> fetch_array($unreged) ) {
		$mode = array_get($user, 'USER_TOPIC_VIEW_TYPE', $config['TOPIC_DISPLAY_STYLE']);
		if (!$mode) $mode = "flat";

		$referer = preg_replace("#<#","&lt;",$referer);
		$agent = preg_replace("#<#","&lt;",$agent);

		$isbot = false;

		$this_agent = $ubbt_lang['ANON_TEXT'];
		if (isset($known_agents[$agent])) {
			$this_agent = "{$known_agents[$agent]}";
			$isbot = true;
		} else {
			foreach ($agent_array as $k => $spidey ) {
				if( preg_match( "#" . preg_quote( $spidey, "#" ) . "#i", $agent ) ) {
					$spiders_cache[$agent] = $k;
					$this_agent = $k;
					$isbot = true;
					break;
				}
			}
		}

		if ($isbot == true) {
			$botrow[$b]['color'] = $colorBot;
			$botrow[$b]['referer'] = $referer;
			$botrow[$b]['agent'] = $agent;
			$botrow[$b]['id'] = $b;
			$botrow[$b]['guestname'] = $this_agent;
			$colorBot = $html -> switch_colors($colorBot);
		} else {
			$anonrow[$a]['color'] = $colorAnon;
			$anonrow[$a]['referer'] = $referer;
			$anonrow[$a]['agent'] = $agent;
			$anonrow[$a]['id'] = $a;
			$anonrow[$a]['guestname'] = $this_agent;
			$colorAnon = $html -> switch_colors($colorAnon);
		} // end if

		$Extra="";


		// ------------------------------------------------------
		// Replace their location with something that makes sense
		$What = $ubbt_lang[$RealWhat];

		if ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && (!preg_match("/Moderator/",$user['USER_MEMBERSHIP_LEVEL']))) {
			if ($isbot == true) {
				$botrow[$b]['IP'] = "";
			} else {
				$anonrow[$a]['IP'] = '';
			} // end if
		}
		else {
			if ($isbot == true) {
				$botrow[$b]['IP'] = $IP;
			} else {
				$anonrow[$a]['IP'] = $IP;
			} // end if
		} // end if

		$Last = $html -> convert_time($Last,$toffset,$user['USER_TIME_FORMAT']);

		// -----------------------------------------------------
		// Here we give more information on what they are doing
		$legend = $ubbt_lang['THREAD'];
		if ($Board){
			if (!isset($Boards[$Board])) {
				$query = "SELECT FORUM_TITLE,FORUM_IS_GALLERY FROM {$config['TABLE_PREFIX']}FORUMS WHERE FORUM_ID='$Board'";
				$sti = $dbh -> do_query($query,__LINE__,__FILE__);
				list($thisboard,$isgallery) = $dbh->fetch_array($sti);
				$Boards[$Board]['title'] = $thisboard;
				$Boards[$Board]['gallery'] = $isgallery;
			}
			if ($Boards[$Board]['gallery']) {
				$What = $ubbt_lang['showgallery'];
				$mode = "gallery";
				$legend = $ubbt_lang['GALLERY'];
			}
			$Extra = "<span class=\"small\"><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{$ubbt_lang['FORUM']} <a href=\"" . make_ubb_url("ubb=postlist&Board=$Board", $Boards[$Board]['title'], false) . "\">{$Boards[$Board]['title']}</a></span>";
		} // end if

		if ($post_id) {
			$Extra .= "<span class=\"small\"><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$legend <a href=\"" . make_ubb_url("ubb=show{$mode}&Number=$post_id#Post$post_id", $post_subject, false) . "\">$post_subject</a></span>";
		} // end if

		if (!$Extra) { $Extra = ""; }

		if ($isbot == true) {
			$botrow[$b]['Username'] = $Username;
			$botrow[$b]['Last']     = $Last;
			$botrow[$b]['What']     = $What;
			$botrow[$b]['Extra']    = $Extra;
			$b++;
		} else {
			$anonrow[$a]['Username'] = $Username;
			$anonrow[$a]['Last']     = $Last;
			$anonrow[$a]['What']     = $What;
			$anonrow[$a]['Extra']    = $Extra;
			$a++;
		} // end if


	}
	rebuild_islands(0,array("online"));

	// Who gets to see the IP?
	$showip = 0;
	if ($userob->check_access("site","EXT_INFO")) $showip = 1;


	$anonrows = sizeof($anonrow);
	$botrows = sizeof($botrow);


	$smarty_data = array(
		"regrows" => $regrows,
		"regrow" => $regrow,
		"anonrows" => $anonrows,
		"anonrow" => $anonrow,
		"column" => $column,
		"showip" => $showip,
		"botrows" => $botrows,
		"botrow" => $botrow,
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array (
			"title" => $ubbt_lang['ONLINE_HEAD'],
			"refresh" => "<meta http-equiv=\"Refresh\" content=\"60;url=" . make_ubb_url("ubb=online", "", false) . "\" />",
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 {$ubbt_lang['ONLINE_HEAD']}
BREADCRUMB
			,
		),
		"template" => "online",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
