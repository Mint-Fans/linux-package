<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;
define('NO_WRAPPER',1);
function page_pollmanager_gpc () {
	return array(
		"input" => array(
			"id" => array("id","both","alphanum"),
			"addpoll" => array("step","post","alphanum"),
			"day" => array("day","post","int"),
			"month" => array("month","post","int"),
			"year" => array("year","post","int"),
			"hour" => array("hour","post","int"),
			"min" => array("min","post","int"),
			"ampm" => array("ampm","post","alpha"),
			"stopday" => array("stopday","post","int"),
			"stopmonth" => array("stopmonth","post","int"),
			"stopyear" => array("stopyear","post","int"),
			"stophour" => array("stophour","post","int"),
			"stopmin" => array("stopmin","post","int"),
			"stopampm" => array("stopampm","post","alpha"),
			"enablestart" => array("enablestart","post","int"),
			"enablestop" => array("enablestop","post","int"),
			"noview" => array("noview","post","int"),
			"mustvote" => array("mustvote","post","int"),
			"delete" => array("delete","get","int"),
		),
		"wordlets" => array("pollmanager"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_pollmanager_gpc

function page_pollmanager_run () {

	global $style_array,$smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$smarty_data = array();

	if (!$startat) { $startat = "0"; }

	if ($delete) {
		$query = "
			delete from {$config['TABLE_PREFIX']}POLL_DATA
			where POLL_ID = ?
		";
		$dbh->do_placeholder_query($query,array($delete),__LINE__,__FILE__);
		$query = "
			delete from {$config['TABLE_PREFIX']}POLL_OPTIONS
			where POLL_ID = ?
		";
		$dbh->do_placeholder_query($query,array($delete),__LINE__,__FILE__);
		header("Location: " . make_ubb_url("ubb=pollmanager&id=$id", "", true));
		exit;
	}
	
	// -----------------
	// No navigation bar
	
		
	$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";
	
	$bad_id = false;
	if (!$id) {
		$bad_id = true;
	} // end if
	
	if ($addpoll == 1 || $addpoll == 2 || $addpoll == 3) {
		$questions = 1;
		return include("libs/addpost_newpoll.inc.php");
	}

	if ($addpoll == "add") {

		$starttime = "0";
		if ($ampm == "AM" && $hour == "12") { $hour = 0; }
		if ($ampm == "PM" && $hour < 12) { $hour = $hour + 12; }
		if ($enablestart) {
			$starttime = mktime($hour,$min,0,$month,$day,$year);
			$validstart = checkdate($month,$day,$year);
			if (!$validstart) {
				$html->not_right_bare("{$ubbt_lang['INVALID_START']}");
			}
		}
		else {
			$starttime = $html->get_date();
		}

		$stoptime = "0";
		if ($enablestop) {
			if ($stopampm == "AM" && $stophour == 12) { $stophour = 0; }
			if ($stopampm == "PM" && $stophour < 12) { $stophour = $stophour + 12; }
			$stoptime = mktime($stophour,$stopmin,0,$stopmonth,$stopday,$stopyear);
			$validstop = checkdate($stopmonth,$stopday,$stopyear);
			if (!$validstop) {
				$html -> not_right_bare("{$ubbt_lang['INVALID_STOP']}");
			}
		}
		if ($noview && !$enablestop) {
			$html -> not_right_bare("{$ubbt_lang['NOVIEWERROR']}");
		}

		// -------------------------
		// Insert the Main Poll info
		if (!$mustvote) $mustvote = 0;
		if (!$noview) $noview = 0;

		$numoptions = get_input("totalchoices","post");
		$pname = get_input("name","post");
		$ptype = get_input("type","post");
		$pmulti = get_input("multi","post");
		if ($ptype == "multi") {
			$ptype = $pmulti;
		}
				
		$query_vars = array($starttime,$stoptime,$mustvote,$noview, $id, time(),$pname,$ptype, $user['USER_ID']);
		$query = "
			INSERT INTO {$config['TABLE_PREFIX']}POLL_DATA
			(POLL_START_TIME,POLL_STOP_TIME,POLL_MUST_VOTE,POLL_HIDE_RESULTS_UNTIL_END,POLL_MD5,POLL_ADD_TIME,POLL_BODY,POLL_TYPE,USER_ID)
			VALUES
			( ? , ? , ? , ? , ? , ? , ? , ? , ? )
		";
		$dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
		$query = "
			SELECT last_insert_id()
		";
		$sth = $dbh -> do_query($query,__LINE__,__FILE__);
		list ($PollId) = $dbh -> fetch_array($sth);


		for ($x=1;$x<=$numoptions;$x++) {
			$option = get_input("option-$x","post");
			
			if (!$option) continue;
			
			$option = $html->do_markup($option, "post", "markup");
		//	$option = addslashes($option);

			// Insert the option
			$query_vars = array($option,$PollId);
			$query = "
				INSERT INTO {$config['TABLE_PREFIX']}POLL_OPTIONS
				(OPTION_BODY,POLL_ID)
				VALUES
				(  ? , ? )
			";
			$dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
		}
	}
	
	// Any polls already added?
	$polls = array();
	$query = "
		select POLL_ID,POLL_BODY
		from {$config['TABLE_PREFIX']}POLL_DATA
		where POLL_MD5 = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($id),__LINE__,__FILE__);
	while(list($poll_id,$poll_body) = $dbh->fetch_array($sth)) {
		$polls[] = array(
			"ID" => $poll_id,
			"BODY" => $poll_body,
		);
	} // end while

	$totalpolls = sizeof($polls);	
	if (!sizeof($polls)) $polls = "";
	
	
	$smarty_data = array(
		"stylesheet" => $stylesheet,
		"polls" => $polls,
		"bad_id" => $bad_id,
		"id" => $id,
		"totalpolls" => $totalpolls,
	);


	return array(
		"header" => array (
			"title" => "",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => "",
		),
		"template" => "pollmanager",
		"data" => & $smarty_data,
		"footer" => false,
		"location" => "",
	);

}

?>
