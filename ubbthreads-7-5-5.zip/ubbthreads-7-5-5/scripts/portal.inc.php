<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_portal_gpc () {
	return array(
		"input" => array(),
		"wordlets" => array("portal"),
		"user_fields" => "t2.USER_TOPIC_VIEW_TYPE",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_portal_gpc


function page_portal_run () {
	
	global $style_array,$myinfo,$userob,$smarty,$in,$ubbt_lang,$config,$visit,$dbh,$html,$user;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	if (!isset($config['NEWS_ITEMS']) || !$config['NEWS_ITEMS']) {
		$config['NEWS_ITEMS'] = 5;
	} // end if

	if (!$config['PORTAL_NEWS_FORUMS']) {
		$config['PORTAL_NEWS_FORUMS'] = "''";
	} // end if

	// Grab the latest news items
	$query = "
		select t1.TOPIC_SUBJECT,t2.USER_ID,t2.USER_DISPLAY_NAME,t1.TOPIC_CREATED_TIME,t3.POST_BODY,t1.POST_ID,t1.TOPIC_VIEWS,t1.TOPIC_REPLIES,t1.TOPIC_NEWS_ICON
		from {$config['TABLE_PREFIX']}TOPICS as t1,
		{$config['TABLE_PREFIX']}USERS as t2,
		{$config['TABLE_PREFIX']}POSTS as t3
		where t1.FORUM_ID in ({$config['PORTAL_NEWS_FORUMS']})
		and t1.USER_ID = t2.USER_ID
		and t1.POST_ID = t3.POST_ID
		and t1.TOPIC_IS_APPROVED = '1'
		and t3.POST_IS_APPROVED = '1'
		and t1.TOPIC_STATUS <> 'M'
		order by TOPIC_CREATED_TIME desc limit {$config['NEWS_ITEMS']}
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	$news = array();
	while(list($subject,$user_id,$poster,$time,$body,$topic_id,$views,$replies,$newsicon) = $dbh->fetch_array($sth)) {
		if ($user_id == 1) {
			$poster = $ubbt_lang['ANON_TEXT'];
		} // end if
		
		$old_len = strlen($body);		
		$body = preg_replace('#\[end_news_blurb\].+$#', '', $body);

		$news[] = array(
			"subject" => $subject,
			"poster" => $poster,
			"time" => 	$html -> convert_time($time,$user['USER_TIME_OFFSET'],$user['USER_TIME_FORMAT']),
			"body" => $body,
			"topic_id" => $topic_id,
			"views" => $views,
			"replies" => $replies,
			"newsicon" => $newsicon,
			"truncated" => (strlen($body) < $old_len),
		);
	} // end while

	$smarty_data = array(
		"news" => $news,
	);
	return array(
		"header" => array (
			"title" => $config['COMMUNITY_TITLE'],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => "",
			"onload" => "",
			"breadcrumb" => "",
			"force_columns" => 1,
		),
		"template" => "portal",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
		"force_columns" => 1,
	);
	
}
	
?>
