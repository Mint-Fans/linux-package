<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_postlist_gpc () {
	return array(
		"input" => array(
			"Board" => array("Board","both","alphanum"),
			"page" => array("page","both","int"),
			"view" => array("view","both","alpha"),
			"o" => array("o","both","alphanum"),
			"sort" => array("sort","both","alphanum"),
			"order" => array("order","both","alpha"),
		),
		"wordlets" => array("postlist","cfrm"),
		"user_fields" => "t2.USER_TOPIC_VIEW_TYPE, t2.USER_TOPICS_PER_PAGE, t2.USER_POSTS_PER_TOPIC",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_postlist_gpc

function page_postlist_run () {

	global $html,$style_array,$tree,$smarty,$userob,$user,$in,$myinfo,$ubbt_lang,$config,$forumvisit,$visit,$dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// Clear out any favorites data from the session
	// we don't want to get sent back to the favorites
	// screen when navigating from here
	$_SESSION['favorites'] = array();

	// Define any necessary variables
	$prints = "";
	$activethread = "";
	$collapsestart = "";
	$collapsestop  = "";
	$d1 = "";
	$d2 = "";
	$w1 = "";
	$w2 = "";
	$w3 = "";
	$m1 = "";
	$m3 = "";
	$m1 = "";
	$m3 = "";
	$m6 = "";
	$y1 = "";
	$allofthem = "";
	$mode = "";
	$usersort = "";
	$userview = "";
	$Username = "";
	$read  = "";
	$unread   = "";
	$makepost = "";
	$PostsPer = "";
	$useractivethread = "";
	$userstatus = "";
	$useroffset = "";
	$newpoststart = "";
	$newpoststop = "";
	$prevstart = "";
	$prevstop = "";
	$nextstart = "";
	$nextstop = "";
	$pagejumpers = "";
	$favoriteboardlink = "";
	$subscribeboardlink = "";
	$postercount = 0;
	$lastposters = "";
	$updatelast = 0;
	$postrow = array();

	// Get this user's last visit time
	$query = "
		select USER_LAST_VISIT_TIME
		from {$config['TABLE_PREFIX']}USER_DATA
		where USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
	list($user['USER_LAST_VISIT_TIME']) = $dbh->fetch_array($sth);

	$Username = $user['USER_DISPLAY_NAME'];
	isset($user['USER_TOPIC_VIEW_TYPE']) && $mode = $user['USER_TOPIC_VIEW_TYPE'];
	isset($user['USER_FORUM_VIEW_TYPE']) && $userview = $user['USER_FORUM_VIEW_TYPE'];
	isset($user['USER_TOPICS_PER_PAGE']) && $PostsPer = $user['USER_TOPICS_PER_PAGE'];
	isset($user['USER_MEMBERSHIP_LEVEL']) && $userstatus = $user['USER_MEMBERSHIP_LEVEL'];
	isset($user['USER_TIME_OFFSET']) && $useroffset = $user['USER_TIME_OFFSET'];
	!isset($user['USER_TIME_FORMAT']) && $user['USER_TIME_FORMAT'] = $config['TIME_FORMAT'];

	$watch_lists = unserialize($_SESSION['watch_lists']);
	if (!isset($watch_lists['t'])) $watch_lists['t'] = array();
	if (!isset($watch_lists['f'])) $watch_lists['f'] = array();

	// --------------------------------
	// Get some default display options
	if (empty($user['USER_POSTS_PER_TOPIC'])) {
		$user['USER_POSTS_PER_TOPIC'] = $config['POSTS_PER_PAGE'];
	}

	// Postrow array key holder
	$z=0;

	// --------------------------------------
	// Do we link to showthreaded or showflat
	if (!$mode) {
		$mode = $config['TOPIC_DISPLAY_STYLE'];
	}
	$mode = "show$mode";


	// ----------------------------------------
	// If $page isn't set then it defaults to 1
	if (empty($page)) {
		$page = $_SESSION['currentpage'];
		if (!$page) {
			$page = 1;
		}
		if ($page < 1) $page = 1;
	}

	// -----------------------------------
	// Store current page in a session var
	$_SESSION['currentpage'] = $page;

	// -------------------
	// Grab the board info
	$query = "
	SELECT FORUM_TITLE,FORUM_LAST_POST_TIME,CATEGORY_ID,FORUM_DEFAULT_TOPIC_AGE,FORUM_CUSTOM_HEADER,FORUM_STYLE,FORUM_TOPICS,FORUM_IS_RSS,FORUM_RSS_TITLE,FORUM_PARENT,FORUM_SHOW_INTRO,FORUM_INTRO_TITLE,FORUM_IS_ACTIVE,FORUM_IS_TEASER,FORUM_IS_GALLERY,FORUM_SORT_FIELD,FORUM_SORT_DIR
	FROM   {$config['TABLE_PREFIX']}FORUMS
	WHERE  FORUM_ID = ?
	";
	$sth = $dbh -> do_placeholder_query($query,array($Board),__LINE__,__FILE__);
	$rows = $dbh -> fetch_array($sth);
	list($Title,$Last,$C,$ThreadAge,$fheader,$fstyle,$totaltopics,$is_rss,$rss_title,$forum_parent,$show_intro,$intro_title,$is_active,$is_teaser,$is_gallery,$sort_field,$sort_dir) = $rows;
	$dbh -> finish_sth($rows);

	if (!$sort_field) $sort_field = "last";
	if (!$sort_dir) {
		$sort_dir = "last";
	} // end if

	if (!$userob->check_access("forum","SEE_FORUM",$Board)) {
		return $html->not_right($ubbt_lang['BAD_GROUP']);
	} // end if

	if (!$is_active) {
		return $html->not_right($ubbt_lang['FORUM_NOT_FOUND']);
	} // end if

	if ($fstyle) {
		$html->set_style($fstyle);
	} // end if



	// If $haskids is set then this forum has subforums.  Let's get some info on those.
	$subforum = array();
	$catrow = array();
	if (isset($tree['kids'][$Board]) && $tree['kids'][$Board]) {
		require("{$config['FULL_PATH']}/libs/functions_forums.inc.php");
		$subforum =& get_forum_display_info($tree['kids'][$Board], "postlist");
		$catrow = array(
			array(
				'display' => '',
				'CATEGORY_ID' => $Board,
			)
		);
	}

	// If this is a visit to a new forum then we need
	// to track any preferences for this forum
	$updatemyprefs = 0;
	if ((!isset($_SESSION['myprefs']['Board'])) || ($_SESSION['myprefs']['Board'] != $Board)) {
		$page = 1;
		$_SESSION['myprefs']['Board'] = $Board;
		$_SESSION['myprefs']['age'] = $ThreadAge;
		$_SESSION['myprefs']['sort'] = $sort_field;
		$_SESSION['myprefs']['order'] = $sort_dir;
		$updatemyprefs = 1;
	} else {
		if (($o) && ($_SESSION['myprefs']['age'] != $o)) {
			$_SESSION['myprefs']['age'] = $o;
			$updatemyprefs = 1;
		}
		if ($sort && ($_SESSION['myprefs']['sort'] != $sort)) {
			$_SESSION['myprefs']['sort'] = $sort;
		}
		if ($order && ($_SESSION['myprefs']['order'] != $order)) {
			$_SESSION['myprefs']['order'] = $order;
		}
	}

	if (!$o) $o = $_SESSION['myprefs']['age'];
	if (!$sort) $sort = $_SESSION['myprefs']['sort'];
	if (!$order) $order = $_SESSION['myprefs']['order'];
	// ----------------------------------
	// Grab all moderators for this board
	$query = "
		SELECT t1.USER_ID,t2.USER_DISPLAY_NAME
		FROM   {$config['TABLE_PREFIX']}MODERATORS AS t1,
		{$config['TABLE_PREFIX']}USERS AS t2
		WHERE  t1.FORUM_ID = ?
		AND  t1.USER_ID = t2.USER_ID
		ORDER BY USER_DISPLAY_NAME
	";
	$sth = $dbh -> do_placeholder_query($query,array($Board),__LINE__,__FILE__);
	$modlist = ",";
	while (list($modid,$modname) = $dbh -> fetch_array($sth)) {
		$moderator[$modid] = $modname;
		$modlist .="$modid,";
	}

	// Hop to popup (or old jump_box) for all allowed forums
	list($jumpbox,$ishopto) = $html->jump_box($Board);

	if ($userob->check_access("forum","USE_MARKUP",$Board)) {
		$ubbcode = "{$ubbt_lang['UBBCODE']} {$ubbt_lang['ENABLED']}";
	}
	else {
		$ubbcode = "{$ubbt_lang['UBBCODE']} {$ubbt_lang['DISABLED']}";
	}

	// ---------------------------------------
	// How old of threads should we be showing
	if (!isset($o)) {
		if (!$o) { $o = $ThreadAge; }
	}
	if ( (!empty($o)) && ($o != "all") ) {
		$time = $html -> get_date();
		$time = $time - ($o * 86400);
		$activethread = "AND t1.TOPIC_LAST_REPLY_TIME > $time";
	}
	if (empty($o)) {
		$o = "";
	}
	if ($o == "1") {
		$d1 = "selected=\"selected\"";
	} elseif ($o == 2) {
		$d2 = "selected=\"selected\"";
	} elseif ($o == 7) {
		$w1 = "selected=\"selected\"";
	} elseif ($o == 14) {
		$w2 = "selected=\"selected\"";
	} elseif ($o == 21) {
		$w3 = "selected=\"selected\"";
	} elseif ($o == 31) {
		$m1 = "selected=\"selected\"";
	} elseif ($o == 93) {
		$m3 = "selected=\"selected\"";
	} elseif ($o == 186) {
		$m6 = "selected=\"selected\"";
	} elseif ($o == 365) {
		$y1 = "selected=\"selected\"";
	} else {
		$allofthem = "selected=\"selected\"";
	}

	$sort_img = ($order == 'asc') ? 'desc' : 'asc';
	$sort_types = array('subject', 'views', 'starter', 'replies', 'start', 'last');
	$sorter = array();
	foreach ($sort_types as $type) {
		$sorter["$type"] = array(
			'selected' => ($sort == $type) ? ' selected="selected" ' : '',
			'start'    => sprintf('<a href="%s">', make_ubb_url("ubb=postlist&Board={$Board}&page={$page}&sort={$type}&order={$sort_img}")),
			'end'      => (($sort == $type) ? sprintf(' <img src="%s" alt="" border="0" />', "{$config['BASE_URL']}/images/{$style_array['general']}/{$sort_img}end.gif") : '') . '</a>',
		);
	}

	// The forumvisit['visit']['boardname'] array holds the real last visit time
	// for each forum
	// The forumvisit['boardname'] array holds the first visit time for each
	// forum for this particular session.
	if (!is_array($_SESSION['forumvisit']['visit'])) {
		$_SESSION['forumvisit']['lastonline'] = $user['USER_LAST_VISIT_TIME'];
		if ($user['USER_ID']) {
			$query = "
				SELECT LAST_VISIT_TIME,FORUM_ID
				FROM {$config['TABLE_PREFIX']}FORUM_LAST_VISIT
				WHERE USER_ID = ?
			";
			$sth = $dbh->do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
			while(list($l_last,$l_board) = $dbh->fetch_array($sth)) {
				$_SESSION['forumvisit']['visit'][$l_board] = $l_last;
			}
		}
	}

	// ------------------------------------------------------------
	// Set up some stuff so we know what the last post they saw was
	// and update this to the current last post of the board
	$rightnow = $html->get_date();
	if (isset($_SESSION['forumvisit'][$Board])) {
		$unread = $_SESSION['forumvisit'][$Board];
	}
	elseif (isset($_SESSION['forumvisit']['visit'][$Board])) {
		$unread = $_SESSION['forumvisit']['visit'][$Board];
		$_SESSION['forumvisit'][$Board] = $_SESSION['forumvisit']['visit'][$Board];
		$updatelast = 1;
	}
	else {
		if ($user['USER_LAST_VISIT_TIME']) {
			$unread = $user['USER_LAST_VISIT_TIME'];
		}
		else {
			$unread = $rightnow;
		}
	}

	// Update their last visit time stamp to this forum for the main forum listing
	$_SESSION['forumvisit']['visit'][$Board] = $html->get_date();

	// ---------------------------------------------------------------------
	// We need to check and see if they have write privileges for this forum
	if ($userob->check_access("forum","CREATE_TOPICS",$Board)) {
		$makepost = 1;
	}

	// -----------------------------------------
	// Find out how many posts to show per  page
	if (!$PostsPer) {
		$PostsPer = $config['TOPICS_PER_PAGE'];
	}

	// If forum is a gallery, then change the new topic text
	// We also set topics per page to 15
	if ($is_gallery) {
		$PostsPer = 15;
	}

	// Figure out the sorting options
	switch($sort) {
		case "subject":
			$sort_by = "t1.TOPIC_SUBJECT";
			break;
		case "starter":
			$sort_by = "t2.USER_DISPLAY_NAME";
			break;
		case "replies":
			$sort_by = "t1.TOPIC_REPLIES";
			break;
		case "views":
			$sort_by = "t1.TOPIC_VIEWS";
			break;
		case "start":
			$sort_by = "t1.TOPIC_CREATED_TIME";
			break;
		case "last":
			$sort_by = "t1.TOPIC_LAST_REPLY_TIME";
			break;
		default:
			$sort_by = "t1.TOPIC_LAST_REPLY_TIME";
	}

	if ($order != "asc" && $order != "desc") $order = "desc";
	$sort_by .= " $order";

	// ---------------------------------------------------------------
	// If they are a normal user then they can only see approved topics
	$t1Viewable = "AND t1.TOPIC_IS_APPROVED = '1'";
	$Viewable = "AND TOPIC_IS_APPROVED = '1'";

	$inline_mod_perms = array();

	if ($userob->check_access("forum","APPROVE_ANY",$Board)) {
		$inline_mod_perms[] = 'approve';
		$Viewable = "";
		$t1Viewable = "";
	}

	if ($userob->check_access("forum","STICKY_ANY",$Board) && !$is_gallery) {
		$inline_mod_perms[] = 'stick';
		$inline_mod_perms[] = 'unstick';
	}

	if ($userob->check_access("site","ANNOUNCEMENTS")) {
		$inline_mod_perms[] = 'announce';
	}

	if ($userob->check_access("forum","LOCK_ANY",$Board)) {
		$inline_mod_perms[] = 'close';
		$inline_mod_perms[] = 'open';
	}

	if ($userob->check_access("forum","DELETE_TOPICS",$Board)) {
		$inline_mod_perms[] = 'delete';
	}

	if ($userob->check_access("forum","MOVE_ANY",$Board)) {
		$inline_mod_perms[] = 'move';
	}

	if ($userob->check_access("forum","EDIT_ANY",$Board)) {
		$inline_mod_perms[] = 'edit';
	}

	$has_inline_mod = (count($inline_mod_perms) > 0);

	// First stop, grab all posts from the announcements table that
	// we need to display in this forum.
	$stickies = array();
	$totalstickies = 0;
	if (!$page || $page == 1 && (!$is_gallery)) {
		$query_vars = array(array($Board,'ubbt_all_forums'));
		$query = "
			SELECT TOPIC_ID
			FROM {$config['TABLE_PREFIX']}ANNOUNCEMENTS
			WHERE FORUM_ID IN ( ? )
		";
		$sth = $dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
		$stickies = array();
		while(list($atopic) = $dbh->fetch_array($sth)) {
			$stickies[] = "$atopic";
		}
	}

	// If we got any stickes then we need to grab them first
	$result = array();
	$totalstickies = 0;
	if (sizeof($stickies)) {
		$query_vars = array($stickies);
		$query = "
			select 	t1.TOPIC_ID,t1.POST_ID,t2.USER_DISPLAY_NAME,t1.TOPIC_CREATED_TIME,t1.TOPIC_LAST_REPLY_TIME,t1.TOPIC_SUBJECT,
			t1.TOPIC_STATUS,t1.TOPIC_IS_APPROVED,t1.TOPIC_ICON,t1.TOPIC_VIEWS,t1.TOPIC_REPLIES,t1.TOPIC_TOTAL_RATES,
	 		t1.TOPIC_RATING,t3.USER_NAME_COLOR,t2.USER_MEMBERSHIP_LEVEL,t1.USER_ID,t1.TOPIC_IS_STICKY,t1.TOPIC_LAST_POSTER_ID,
	 		t1.TOPIC_LAST_POSTER_NAME,t1.TOPIC_LAST_POST_ID,t1.TOPIC_IS_EVENT,t1.TOPIC_HAS_FILE,t1.TOPIC_HAS_POLL,t1.TOPIC_POSTER_NAME,t1.TOPIC_THUMBNAIL,t4.POST_BODY,t3.USER_GROUP_IMAGES
			from {$config['TABLE_PREFIX']}TOPICS as t1
			left join {$config['TABLE_PREFIX']}USERS as t2 on t1.USER_ID = t2.USER_ID
			left join {$config['TABLE_PREFIX']}USER_PROFILE as t3 on t1.USER_ID = t3.USER_ID
			left join {$config['TABLE_PREFIX']}POSTS as t4 on t1.POST_ID = t4.POST_ID
			where t1.TOPIC_ID IN ( ?)
			ORDER BY t1.TOPIC_IS_STICKY DESC, $sort_by
		";
		$sth = $dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
		while($row = $dbh->fetch_array($sth)) {
			$result[] = $row;
		}
		$totalstickies = sizeof($result);
		$dbh->finish_sth($sth);
	}

	// ---------------------------------------------------------------------
	// Now we calculate which posts to grab for this page.  We want to grab
	// one from the previous page and one from the next page so we know what
	// the previous and nexts posts will be
	if ($page == 1) {
		$Totalgrab = $PostsPer;
		$Posts     = $PostsPer + 1;
	}
	else {
		$Startat   = ($page - 1) * $PostsPer;
		$Posts     = $PostsPer + 1;
		if (!is_numeric($Startat)) $Startat = 0;
		$Totalgrab = "$Startat, $Posts";
	}

	// --------------------
	// Setup the limit call
	$endpage = 1;
	$limit = "LIMIT $Totalgrab";

	$query = "
		select 	t1.TOPIC_ID,t1.POST_ID,t2.USER_DISPLAY_NAME,t1.TOPIC_CREATED_TIME,t1.TOPIC_LAST_REPLY_TIME,t1.TOPIC_SUBJECT,
 		t1.TOPIC_STATUS,t1.TOPIC_IS_APPROVED,t1.TOPIC_ICON,t1.TOPIC_VIEWS,t1.TOPIC_REPLIES,t1.TOPIC_TOTAL_RATES,
 		t1.TOPIC_RATING,t3.USER_NAME_COLOR,t2.USER_MEMBERSHIP_LEVEL,t1.USER_ID,t1.TOPIC_IS_STICKY,t1.TOPIC_LAST_POSTER_ID,
 		t1.TOPIC_LAST_POSTER_NAME,t1.TOPIC_LAST_POST_ID,t1.TOPIC_IS_EVENT,t1.TOPIC_HAS_FILE,t1.TOPIC_HAS_POLL,t1.TOPIC_POSTER_NAME,t1.TOPIC_THUMBNAIL,t4.POST_BODY,t3.USER_GROUP_IMAGES
		from {$config['TABLE_PREFIX']}TOPICS as t1
		left join {$config['TABLE_PREFIX']}USERS as t2 on t1.USER_ID = t2.USER_ID
		left join {$config['TABLE_PREFIX']}USER_PROFILE as t3 on t1.USER_ID = t3.USER_ID
		left join {$config['TABLE_PREFIX']}POSTS as t4 on t1.POST_ID = t4.POST_ID
		where t1.FORUM_ID = ?
		and t1.TOPIC_IS_STICKY = '0'
		$activethread
		$t1Viewable
		ORDER BY $sort_by
		$limit
	";
	$sth = $dbh -> do_placeholder_query($query,array($Board),__LINE__,__FILE__);
	while($row = $dbh->fetch_array($sth)) {
		$result[] = $row;
	}
	$nums = $dbh->total_rows($sth);
	$dbh->finish_sth($sth);

	if (array_get($config, 'dateslip', false)){
		$datecolumn = $ubbt_lang['LAST_POST'];
	}
	else {
		$datecolumn = $ubbt_lang['POSTON_TEXT'];
	}

	// ----------------------------
	// List the posts for this page
	$rowcolor = "";
	$counter = 1;

	// Javascript construct for inline moderation
	$javascript_for_inline = '';

	// $has_inline_mod
	if ($has_inline_mod) {
		$javascript_for_inline = 'var topics_for_moderation = Object();';
	}

	for ($i=0; $i<sizeof($result);$i++) {
		$iconfolder = "";
		$specialicon = "blank.gif";
		$statusicon = array();
		// -------------------------------------------------------------
		// We need to break out of here if we are over $PostPer, we just
		// needed to know if there was  a next page or not
		if ($i == (($PostsPer * $endpage)+$totalstickies) ) { break; }
		list($Main,$Post_ID,$Username,$Posted,$Last_Post,$Subject,$Open,$Approved,$icon,$Counter,$Replies,$Rates,$stars,$Color,$PostStatus,
		$posterid,$Sticky,$lastposterid,$lastpostername,$lastpostnum,$calevent,$file,$Poll,$topic_postername,$topic_thumbnail,$PostBody,$groupimages) = $result[$i];

		if ($lastposterid == 1) {
			if (!$lastpostername || $lastpostername == "Anonymous") {
				$lastpostername = $ubbt_lang['ANON_TEXT'];
			} // end if
		} // end if

		// -------------------------
		// Standard icon is the note
		if (!$icon) {
			$icon = "blank.gif";
		}
		else {
			$icon = "$icon";
		}

		if ($has_inline_mod) {
			$javascript_for_inline .= "\ntopics_for_moderation['" . $Post_ID . "'] = '";
		}

		// ----------------------------------------------------------
		// If this post is sticky then we need to add a sticky icon
		if ($Sticky == 2) {
		//	Don't select announcements
		//	if ($has_inline_mod) {
		//		$javascript_for_inline .= 'sticky ';
		//	}
			$statusicon[] = array(
				'img' => "announce.gif",
				'alt' => "{$ubbt_lang['ANNOUNCE']}",
			);
		} elseif ($Sticky == 1) {
			if ($has_inline_mod) {
				$javascript_for_inline .= 'sticky ';
			}
			$statusicon[] = array(
				'img' => "sticky.gif",
				'alt' => "{$ubbt_lang['STICKY']}",
			);
		}

		// -----------------------------------------------------------
		// If there is a file attachment we mark it with the disk icon
		if ($file) {
			if ($has_inline_mod) {
				$javascript_for_inline .= 'attach ';
			}
			$statusicon[] = array(
				'img' => "file.gif",
				'alt' => "{$ubbt_lang['FILE']}",
			);
		}

		// ----------------------------------------------------------
		// If this post is a poll then we need to add a poll icon
		if ($Poll) {
			if ($has_inline_mod) {
				$javascript_for_inline .= 'poll ';
			}
			$statusicon[] = array(
				'img' => "poll.gif",
				'alt' => "{$ubbt_lang['POLL']}",
			);
		}

		// ----------------------------------------------------------------
		// If this post has a calendar event we need to add a calevent icon
		if ($calevent) {
			if ($has_inline_mod) {
				$javascript_for_inline .= 'event ';
			}
			$statusicon[] = array(
				'img' => "calevent.gif",
				'alt' => "{$ubbt_lang['CALEVENT']}",
			);
		}

		// ------------
		// A hot topic?
		if ($Replies >= $config['HOT_REPLIES'] || $Counter >= $config['HOT_VIEWS']) {
			if ($has_inline_mod) {
				$javascript_for_inline .= 'hot ';
			}
			$statusicon[] = array(
				'img' => "hottopic.gif",
				'alt' => $html->substitute($ubbt_lang['HOT_TOPIC'], array(
					'HOT_REPLIES' => $config['HOT_REPLIES'],
					'HOT_VIEWS' => $config['HOT_VIEWS']))
			);
		}

		$time = $html -> convert_time($Last_Post,$useroffset,$user['USER_TIME_FORMAT']);
		$created = $html->convert_time($Posted,$useroffset,$user['USER_TIME_FORMAT']);

		$alt = "";
		$newthread = "";

		if (isset($_SESSION['topicread'][$Main])) {
			$unreadcheck = $_SESSION['topicread'][$Main];
		}
		else {
			$unreadcheck = $unread;
		}

		// Don't mark announcements as new in every forum
		$aread = 0;
		if ( (isset($_SESSION['topicread'][$Main]))  && $Sticky == '2') {
			$aread = 1;
		}

		$newreplies = 0;
		if (($Last_Post > $unreadcheck) && !$aread) {
			$updatelast = 1;
			$isnew = 1;
			$specialicon = "newfolder.gif";
			if ($is_gallery) $specialicon = "newimageposts.gif";
			$alt    = "{$ubbt_lang['NEW_POSTS']}";
			$newthread = $unreadcheck;
			if ($config['NEW_REPLIES']) {
				$query = "
					select count(*)
					from {$config['TABLE_PREFIX']}POSTS
					where TOPIC_ID = ?
					and POST_POSTED_TIME > ?
					and POST_IS_TOPIC = 0
					and POST_IS_APPROVED = 1
				";
				$stx = $dbh->do_placeholder_query($query,array($Main,$unreadcheck),__LINE__,__FILE__);
				list ($newreplies) = $dbh->fetch_array($stx);
			}
		}
		else {
			$isnew = 0;
			$specialicon = "nonewfolder.gif";
			if ($is_gallery) $specialicon = "nonewimageposts.gif";
			$alt    = "{$ubbt_lang['NO_NEW_POSTS']}";
		}

		$topiclock = 0;
		if ($Open == "C") {
			if ($has_inline_mod) {
				$javascript_for_inline .= 'closed ';
			}
			if ($specialicon != "sticky.gif") {
				$topiclock = 1;
				$specialicon = "lock.gif";
				$alt = $ubbt_lang['IS_LOCKED'];
			}
		}
		if ($Open == "M") {
			$specialicon = "moved.gif";
			$alt = $ubbt_lang['IS_MOVED'];
		}

		// -------------------------------------------------------------------
		// If we are doing flat posts or the view is collapsed we need to list
		// the number of replies
		// We also need to do this before printing out the initial folder/icon
		// color so we can let the user know there are new messages in the thread
		$pagejump = 1;
		$postmarker = "";
		$partnumber = "";

		// ------------------------------------------------------
		// If the post isn't approved we show it in the new color
		if ($Approved == "0") {
			if ($has_inline_mod) {
				$javascript_for_inline .= 'unapproved ';
			}
			$Subject = "({$ubbt_lang['NOT_APPROVED']}) $Subject";
		}

		// ----------------------------------------------------------------
		// If we are going to be viewing in flat mode, let's show all pages
		$cleansubject = htmlspecialchars_decode($Subject);

		$pageprint = "";
		if (($mode == "showflat") && ($Replies >= $user['USER_POSTS_PER_TOPIC'])) {
			$pages = ceil(($Replies+1) / $user['USER_POSTS_PER_TOPIC']);

			if ($pages != 1) {
				$pageprint = " <div class=\"small\">( <img style=\"vertical-align: middle;\" src=\"{$config['BASE_URL']}/images/{$style_array['general']}/page.gif\" alt=\"\" /> ";

				if ($pages > 9) {
					for ($iamsam = 1; $iamsam <= 3; $iamsam++) {
						$pageprint .= sprintf('<a href="%s">%s</a> ', make_ubb_url("ubb=showflat&Number=$Post_ID&page=$iamsam", $cleansubject, false), $iamsam);
					}

					$pageprint .= '...';

					for ($iamsam = $pages - 2; $iamsam <= $pages; $iamsam++) {
						$pageprint .= sprintf('<a href="%s">%s</a> ', make_ubb_url("ubb=showflat&Number=$Post_ID&page=$iamsam", $cleansubject, false), $iamsam);
					}
				} else {
					for ($iamsam = 1; $iamsam <= $pages; $iamsam++) {
						$pageprint .= sprintf('<a href="%s">%s</a> ', make_ubb_url("ubb=showflat&Number=$Post_ID&page=$iamsam", $cleansubject, false), $iamsam);
					}
				}

				if ($Replies < 200) {
					$pageprint .= sprintf('<a href="%s">%s</a>', make_ubb_url("ubb=showflat&Number=$Post_ID&page=all", $cleansubject, false), $ubbt_lang['TEXT_ALL']);
				}

				$pageprint .= " )</div>";
			}
		}

		if ($posterid == "1") {
			if (!$topic_postername || $topic_postername == "Anonymous") {
				$topic_postername = $ubbt_lang['ANON_TEXT'];
			}
			$Username = $topic_postername;
			$UserStatus = "";
		}
		else {
			// Colorize as needed
			$PUsername = $html->user_color($Username, $Color, $PostStatus);

			// ---------------------------------------------------------
			// We need to know if this was made by an admin or moderator
			$UserStatus = "";
			$UserStatus = $html->user_status($posterid,$groupimages,$modlist);
			$Username = "<a href=\"" . make_ubb_url("ubb=showprofile&User=$posterid", $Username, false) . "\" rel=\"nofollow\">$PUsername</a>";
		}

		$ThreadRating = "";
		if ($stars && $config['TOPIC_RATINGS']) {
			$ThreadRating = "";
			for ($x=1;$x<=$stars;$x++) {
				$ThreadRating .= "<img src=\"{$config['BASE_URL']}/images/{$style_array['general']}/star.gif\" title= \"$Rates {$ubbt_lang['T_RATES']}\" alt=\"*\" />";
			}
		}

		if ($isnew) {
			$postrow[$z]['color'] = "new-$rowcolor";
		} else {
			$postrow[$z]['color'] = $rowcolor;
		} // end if

		$postrow[$z]['watch'] = 0;
		if (isset($watch_lists['t'][$Main])) {
			$postrow[$z]['watch'] = 1;
		}
		$postrow[$z]['indentsize'] = "0";
		$postrow[$z]['icon']       = $icon;
		$postrow[$z]['iconfolder'] = $iconfolder;
		$postrow[$z]['specialicon'] = $specialicon;
		$postrow[$z]['alt'] = $alt;
		$postrow[$z]['newreplies'] = $newreplies;
		$postrow[$z]['files'] = $file;

		if (!sizeof($statusicon)) {
			$postrow[$z]['statusicon'] = "";
		} else {
			$postrow[$z]['statusicon'] = $statusicon;
		}

		$postrow[$z]['Number']     = $Post_ID;
		$postrow[$z]['goto'] = "#Post{$Post_ID}";
		if ($newthread) {
			$postrow[$z]['goto'] = "&gonew=1#UNREAD";
		} else if($is_gallery) {
			$postrow[$z]['goto'] = "#comments";
		} // end if

		$postrow[$z]['Subject']    = $Subject;
		$postrow[$z]['thumbnail']  = $topic_thumbnail;
		$postrow[$z]['Username']   = $Username;
		$postrow[$z]['UserStatus'] = $UserStatus;
		$postrow[$z]['Views']      = $Counter;
		$postrow[$z]['Replies']    = $Replies;
		$postrow[$z]['time']       = $time;
		$postrow[$z]['created']    = $created;
		$postrow[$z]['pageprint']  = $pageprint;
		$postrow[$z]['Rating']     = $ThreadRating;
		$postrow[$z]['posterid']   = $posterid;
		$postrow[$z]['UserNumber'] = $posterid;
		$postrow[$z]['lastposterid'] = $lastposterid;
		$postrow[$z]['lastpostername'] = $lastpostername;
		$postrow[$z]['lastpostid'] = $lastpostnum;
		$postrow[$z]['announce'] = "0";
		$postrow[$z]['SubjectClean'] = $cleansubject;
		$postrow[$z]['TOPIC_ID'] = $Main;
		if ($Sticky == '2') {
			$postrow[$z]['announce'] = "$Board";
		}
		// Create a tooltip, if allowed/desired
		//
		// Gotta clean out the [ and ], as they are keys to the .js parser. Also need to fix graemlin links
		$postrow[$z]['tooltip'] = "";
		if ($config['TOOLTIP_LENGTH'] && $config['TOOLTIP_LENGTH'] > 0) {
			if (preg_match("#-ML-#",$PostBody)) {
				$PostBody = $ubbt_lang['MOVED'];
			} // end if
			$PostBody = str_replace("]", "&rbr;", str_replace("[", "&lbr;", $PostBody));
			$PostBody = str_replace("<<GRAEMLIN_URL>>", "{$config['BASE_URL']}/images/{$style_array['graemlins']}", $PostBody);
			$PostBody = htmlspecialchars($html->truncate($PostBody, $config['TOOLTIP_LENGTH']));
			$postrow[$z]['tooltip'] = "title=\"header=[{$ubbt_lang['TOOLTIP_HEADER']}] body=[{$PostBody}]\"";
		}
		$z++;

		// --------------------
		// alternate the colors
		if ($rowcolor == "") {
			$rowcolor = "alt-";
		} else {
			$rowcolor = "";
		}

		$javascript_for_inline .= "';";


	}
	$dbh -> finish_sth($sth);

	// -------------------------------------------
	// Here is where we let them jump around pages
	// If this is a moderated board and this user is an admin or moderator
	// then we need to add the total # of unapproved topics to the count
	if ($userob->check_access("forum","APPROVE_ANY",$Board) || $activethread) {
		$query = "
			SELECT COUNT(*)
			FROM   {$config['TABLE_PREFIX']}TOPICS AS t1
			WHERE  t1.FORUM_ID = ?
			$activethread
			AND    t1.TOPIC_IS_STICKY='0'
			$t1Viewable
		";
		$sth = $dbh -> do_placeholder_query($query,array($Board),__LINE__,__FILE__);
		list($totaltopics) = $dbh -> fetch_array($sth);
		$dbh -> finish_sth($sth);
	}
	$TotalP = ceil($totaltopics/$PostsPer);

	if (!$TotalP) $TotalP = 1;

	$pagejumpers1 = $html->paginate($page,$TotalP,"postlist&Board=$Board&page=",$Title);
	$pagejumpers2 = preg_replace('#pagination_\d+#', '', $pagejumpers1);

	// Only give the favorite board and subscribe links to users that have
	// logged in
	if ($user['USER_DISPLAY_NAME']) {
		if (in_array($Board,$watch_lists['f'])) {
			$f_text = $ubbt_lang['NO_FORUM_FAV'];
		} else {
			$f_text = $ubbt_lang['FORUM_FAV'];
		} // end if
		$favoriteboardlink = "<tr><td class=\"popup_menu_content\"><a href=\"" . make_ubb_url("ubb=addfavforum&Board=$Board", "", false) . "\">$f_text</a></td></tr>";
	}

	$postrowsize = "";
	if (isset($postrow)) {
		$postrowsize = sizeof($postrow);
	}

	// Moderators
	$modarray = preg_split("#,#",$modlist);
	$modsize = sizeof($modarray);
	$comma =0;
	$modlist = "";
	for ($i=0;$i<$modsize;$i++) {
		if ($modarray[$i]) {
			if ($comma) { $modlist .= ", "; }
			$modlist .= "<a href=\"" . make_ubb_url("ubb=showprofile&User=$modarray[$i]", $moderator[$modarray[$i]], false) . "\" rel=\"nofollow\">{$moderator[$modarray[$i]]}</a>";
			$comma++;
		}
		else {
			$modlist .= "";
		}
	}

	if ($userob->is_logged_in) {

		$query_vars = array($rightnow,$Board,$user['USER_ID']);
		$query = "
		REPLACE INTO {$config['TABLE_PREFIX']}FORUM_LAST_VISIT
		(LAST_VISIT_TIME,FORUM_ID,USER_ID)
		VALUES
		( ? , ? , ? )
		";
		$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	}

	// Are we showing the community Intro?
	$intro_body = "";
	if ($show_intro && file_exists("{$config['FULL_PATH']}/includes/intro_{$Board}.php")) {
		ob_start();
		include("{$config['FULL_PATH']}/includes/intro_{$Board}.php");
		$intro_body = ob_get_contents();
		ob_end_clean();
	} else {
		$intro_title = "";
	} // end if

	$smarty_data = array(
		"catrow" => array(0=>array('CatId'=>$Board)),
		"Title" => $Title,
		"Board" => $Board,
		"postrow" => & $postrow,
		"mode" => $mode,
		"pagejumpers1" => $pagejumpers1,
		"pagejumpers2" => $pagejumpers2,
		"r" => $r,
		"a" => $a,
		"modlist" => $modlist,
		"favoriteboardlink" => $favoriteboardlink,
		"subscribeboardlink" => $subscribeboardlink,
		"ubbcode" => $ubbcode,
		"datecolumn" => $datecolumn,
		"d1" => $d1,
		"d2" => $d2,
		"w1" => $w1,
		"w2" => $w2,
		"w3" => $w3,
		"m1" => $m1,
		"m3" => $m3,
		"m6" => $m6,
		"y1" => $y1,
		"allofthem" => $allofthem,
		"jumpbox" =>  & $jumpbox,
		"ishopto" => $ishopto,
		"has_subforums" => sizeof($subforum),
		"subforum" => array($subforum),
		"stickies" => sizeof($stickies),
		"is_rss" => $is_rss,
		"rss_title" => $rss_title,
		"intro_body" => & $intro_body,
		"intro_title" => $intro_title,
		"newtopic" => $makepost,
		"sort" => $sort,
		"order" => $order,
		"legend" => &$legend,
		"inline_perms" => &$inline_mod_perms,
		"page" => $page ? $page : '1',
		"sorter" => &$sorter,
		"inline_topic_js" => $javascript_for_inline,
		"catrow" => $catrow,
	);


	if ($is_gallery) {
		$template = "gallerylist";
	} else {
		$template = "postlist";
	}
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$js = array();
	if ($inline_mod_perms) {
		$js[] = "inline_moderation.js";
	}
	if ($config['TOOLTIP_LENGTH'] && $config['TOOLTIP_LENGTH'] > 0) {
		$js[] = "boxover.js";
	}
	return array(
		"header" => array (
			"title" => $Title,
			"refresh" => 0,
			"user" => $user,
			"Board" => $Board,
			"Category" => $C,
			"forum_parent" => $forum_parent,
			"javascript" => $js,
			"bypass" => "",
			"rss" => $is_rss,
			"rss_title" => $rss_title,
			"onload" => "",
			"custom_header_footer" => $fheader,
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
BREADCRUMB
			,
		),
		"template" => "$template",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
