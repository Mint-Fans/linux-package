<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;
define('NO_WRAPPER',1);

function page_previewpost_gpc () {
	return array(
		"input" => array(
			"Body" => array("Body","both",""),
			"convert" => array("convert","post","alpha"),
			"gallery" => array("gallery","post","int"),
		),
		"wordlets" => array(),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
		"no_session" => 1,
	);
} // end page_quickquote_gpc

function page_previewpost_run () {

	global $style_array,$smarty,$userob,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	if (($user['USER_MEMBERSHIP_LEVEL'] == "User") && ($config['MARKUP_HTML_TOGGLE'] == 0) || !$convert ) {
		$convert = "markup";
	}

	if ($gallery) {
		$config['ALLOW_IMAGE_MARKUP'] = 0;
	}

	$convert_vals = array("both","markup","html","none");
	if (!in_array($convert, $convert_vals)) $convert = "none";

	// If this is a user and HTML isn't allowed in the forum, then make sure
	// html isn't selected
	if ($user['USER_MEMBERSHIP_LEVEL'] == "User") {
		if ($convert == "both" || $convert == "html") {
			$convert = "none";
		}
	}

	if ($config['DO_CENSOR']) {	$Body = $html->do_censor($Body); }

	$Body = $html->do_markup($Body,"post",$convert);
	$Body = graemlin_url($Body, $smarty);

	header("Content-Type: text/html; charset=UTF-8");
	echo $Body;

	// Bypass smarty completely
	return false;
}

?>
