<?php

//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_previewsig_gpc () {
	return array(
		"input" => array(
			"sig" => array("sig","post",""),
		),
		"wordlets" => array("previewsig"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
		"no_session" => 1,
	);
}

function page_previewsig_run () {

	global $style_array, $smarty, $user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html,$userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$length = strlen($sig);
	$sig = $html->do_markup($sig,"signature","markup");

	$span = "";
	$extra = "";

	$max = $userob->check_access("site","SIGNATURE_LENGTH");
	if ($length > $max) {
		$span = "standouttext";
		$extra = $ubbt_lang['SHORTEN'];
	}

	$sig = graemlin_url($sig, $smarty);
	$sigpreview = $html->substitute($ubbt_lang['LENGTH'], array(
		'SPAN_CLASS' => $span,
		'ACTUAL' => $length,
		'ALLOWED' => $max));
	echo $sigpreview . " $extra<br /><hr/>$sig";

	return false;

}

?>
