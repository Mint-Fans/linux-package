<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_printthread_gpc () {
	return array(
		"input" => array(
			"Board" => array("Board","get","alphanum"),
			"main" => array("main","get","int"),
			"type" => array("type","get","alpha"),
			"page" => array("page","get","int"),
			"fpart" => array("fpart","get","alphanum"),
		),
		"wordlets" => array("showflat"),
		"user_fields" => "t2.USER_TOPIC_VIEW_TYPE,t2.USER_TOPICS_PER_PAGE,t2.USER_SHOW_AVATARS,t2.USER_POSTS_PER_TOPIC",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_printthread_gpc

function page_printthread_run () {

	global $style_array,$smarty,$userob,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	define('NO_WRAPPER',1);

	!isset($user['USER_TIME_FORMAT']) && $user['USER_TIME_FORMAT'] = $config['TIME_FORMAT'];

	$query = "
		select FORUM_ID
		from {$config['TABLE_PREFIX']}TOPICS
		where TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($main),__LINE__,__FILE__);
	list($Board) = $dbh->fetch_array($sth);

	if (!$userob->check_access("forum","SEE_FORUM",$Board)) {
		$html -> not_right($ubbt_lang['BAD_GROUP']);
	}

	// -------------------------
	// Reassign $main to $Number
	$Number = $main;
	$folder   = "icons";


	// -------------------------------------------------------------
	// If we didn't get a board or number then we give them an error
	if (!$Board) {
		$html -> not_right($ubbt_lang['NO_B_INFO']);
	}

	// Set the default of viewing pictures with posts
	$AVATARS_WITH_POSTS = $user['USER_SHOW_AVATARS'];
	if (!$AVATARS_WITH_POSTS) { $AVATARS_WITH_POSTS  = $config['SHOW_AVATARS']; }

	// --------------------------------------------
	// Let's find out if they should be here or not
	$query = "
	SELECT FORUM_TITLE,CATEGORY_ID
	FROM   {$config['TABLE_PREFIX']}FORUMS
	WHERE  FORUM_ID = ?
	AND FORUM_IS_ACTIVE = '1'
	";
	$sth = $dbh -> do_placeholder_query($query,array($Board),__LINE__,__FILE__);
	list($title,$CatNumber) = $dbh -> fetch_array($sth);


	// ---------------------------------------------------------------
	// If they are a normal user then they can only see approved posts
	$ismod = "no";	// By default they are not a moderator

	$P_Viewable = "And POST_IS_APPROVED = '1'";
	$T_Viewable = "AND TOPIC_IS_APPROVED = '1'";
	if ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator") {
		$P_Viewable = "";
		$T_Viewable = "";
	}
	if ($user['USER_MEMBERSHIP_LEVEL'] == "GlobalModerator") {
		$P_Viewable = "";
		$T_Viewable = "";
	}
	if ($user['USER_MEMBERSHIP_LEVEL'] == "Moderator") {
		// ---------------------------------
		// Check if they moderate this board
		$Board_q    = addslashes($Board);
		$query = "
		SELECT FORUM_ID
		FROM   {$config['TABLE_PREFIX']}MODERATORS
		WHERE  USER_ID = ?
		AND    FORUM_ID = ?
		";
		$sth = $dbh -> do_placeholder_query($query,array($user['USER_ID'],$Board),__LINE__,__FILE__);
		list($check) = $dbh -> fetch_array($sth);
		if ($check) {
			$P_Viewable = "";
			$T_Viewable = "";
			$ismod    = "yes";
		}
	}

	// -----------------------------------------------------------------------------
	// Once and a while if people try to just put a number into the url, lets trap it
	if (!$Number) {
		$html -> not_right($ubbt_lang['POST_PROB']);
	}

	$current = 0;
	$posted = 0;
	// ------------------------------------------
	// Grab the main post number for this thread
	if ($type == "post") {
		$query = "
		SELECT TOPIC_ID,POST_POSTED_TIME
		FROM  {$config['TABLE_PREFIX']}POSTS
		WHERE POST_ID = ?
		$P_Viewable
		";
		$sth = $dbh -> do_placeholder_query($query,array($Number),__LINE__,__FILE__);
		list($current,$posted) = $dbh -> fetch_array($sth);
	} else {
		$query = "
			select TOPIC_ID
			from {$config['TABLE_PREFIX']}TOPICS
			where TOPIC_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);
		list($current) = $dbh->fetch_array($sth);
}
	// -------------------------------------------------------------
	// If we didn't find the main post, then this post doesn't exist
	if (!$current) {
		$html -> not_right("The post you are looking for could not be found");
	}
	$extra = "";
	if ($type == "thread") {
		$query_vars = array($current);
		$extra = "AND TOPIC_ID = ? ";
	}
	else {
		$query_vars = array($Number);
		$extra = "AND POST_ID = ? ";
	}

	// -------------------------------
	// Now cycle through all the posts
	$query = "
	SELECT t1.POST_ID,t1.POST_POSTED_TIME,t2.USER_DISPLAY_NAME,t1.POST_POSTER_IP,t1.POST_SUBJECT,t1.POST_BODY,t1.POST_IS_APPROVED,t3.USER_AVATAR,t3.USER_TITLE,t3.USER_NAME_COLOR,t1.POST_ICON,t1.POST_PARENT_ID,t2.USER_MEMBERSHIP_LEVEL,t1.USER_ID,t3.USER_AVATAR_WIDTH,t3.USER_AVATAR_HEIGHT,t3.USER_GROUP_IMAGES
	FROM  {$config['TABLE_PREFIX']}POSTS AS t1,
	{$config['TABLE_PREFIX']}USERS AS t2,
	{$config['TABLE_PREFIX']}USER_PROFILE as t3
	WHERE t1.USER_ID = t2.USER_ID
	and t1.USER_ID = t3.USER_ID
	$extra
	ORDER BY POST_ID
	";
	$sth = $dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	$totalthread = $dbh -> total_rows($sth);
	$tsubject = "";
	for ( $i = 0;$i< $totalthread;$i++){

		list ($Number,$Posted,$Username,$IP,$Subject,$Body,$Approved,$Picture,$Title,$Color,$Icon,$Parent,$PostStatus,$Posterid,$picwidth,$picheight,$groupimages) = $dbh -> fetch_array($sth);

		$time = $html -> convert_time($Posted,$user['USER_TIME_OFFSET'],$user['USER_TIME_FORMAT'],true);

		$EUsername = $Posterid;
		$PUsername = $html->user_color($Username, $Color, $PostStatus);

		// ---------------------------------------------------------
		// We need to know if this was made by an admin or moderator
		$UserStatus = $html->user_status($Posterid,$groupimages,",$Posterid,");

		// IF it isn't approved we need to mark it
		if ($Approved == "0") {
			$Subject = "({$ubbt_lang['NOT_APPROVED']}) $Subject";
		}

		$folder = "icons";

		$showicon = "";
		if (!$Icon) { $Icon ="blank.gif"; }


		// ---------------------------------------------------------
		// If its an anonymous post, dont' give a link to the profile
		if($Posterid == "1") {
			$Username = $ubbt_lang['ANON_TEXT'];
			$Title = $ubbt_lang['UNREGED_USER'];

		}
		else {
			$Username = "<a href=\"" . make_ubb_url("ubb=showprofile&User=$EUsername", $Username, false) . "\">$PUsername</a>";
		}

		if (!$userob->check_access("site","EXT_INFO")) $IP = "";

		$picture = "";
		if ( ($Picture) && ($Picture != "http://") && ( ($AVATARS_WITH_POSTS) || ($AVATARS_WITH_POSTS == 'on')) ) {
			$picsize = "";
			if ($picwidth && $picheight) {
				$picsize = "width=\"$picwidth\" height=\"$picheight\"";
			}
			else {
				$picsize = "width=\"{$config['AVATAR_MAX_WIDTH']}\" height=\"{$config['AVATAR_MAX_HEIGHT']}\"";
			}
			$picture = "<img src=\"$Picture\" alt=\"\" $picsize />";
		}

		// --------------------------------------------------------------------
		// If there is a poll in this post, we need to include includepoll.php
		// or includepollresults.php depending on if they voted or not
		$postrow[$i]['showpoll'] = "";

		$postrow[$i]['Username'] = $Username;
		$postrow[$i]['UserStatus'] = $UserStatus;
		$postrow[$i]['Title']      = $Title;
		$postrow[$i]['time']       = $time;
		$postrow[$i]['IP']         = $IP;
		$postrow[$i]['fileurl']    = '';
		$postrow[$i]['picture']    = $picture;
		$postrow[$i]['folder']     = $folder;
		$postrow[$i]['Icon']       = $Icon;
		$postrow[$i]['Subject']    = $Subject;
		$postrow[$i]['Body']       = $Body;
	}

	$postrowsize = sizeof($postrow);

	$smarty_data = array(
		"tsubject" => $tsubject,
		"postrow" => $postrow,
	);

	return array(
		"header" => "",
		"template" => "printthread",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
