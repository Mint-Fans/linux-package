<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_profile_comment_gpc () {
	return array(
		"input" => array(
			"Body" => array("Body","post",""),
			"profile" => array("profile","post","int"),
			"md5_stamp" => array("md5_stamp","post","both"),
		),
		"wordlets" => array("profile_comment"),
		"user_fields" => "t2.USER_SIGNATURE,t2.USER_TOPIC_VIEW_TYPE,t2.USER_TOTAL_POSTS,t2.USER_FLOOD_CONTROL_OVERRIDE,t2.USER_TEXT_EDITOR,USER_EMAIL_WATCHLISTS",
		"regonly" => 0,
	);
} // end page_profile_comment_gpc

function page_profile_comment_run () {

	global $style_array,$userob,$smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$var_start,$var_eq,$var_sep,$var_extra,$debug,$myinfo,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$smarty_data = array();

	$DefaultBody = $Body;

	// Make sure this is enabled and they aren't commenting in their own
	// profile
	if (!$config['COMMENTS'] || $user['USER_TOTAL_POSTS'] < $config['COMMENTS_MIN_POST'] || $profile == $user['USER_ID']) exit;

	// Censor the input?
	if ($config['DO_CENSOR']) {
		$Body = $html->do_censor($Body);
	}

	// Add a space to the end of $Body, for auto-url encoding
	$Body .= " ";

	$Username = $user['USER_DISPLAY_NAME'];
	$posterid = $user['USER_ID'];
	$postername = $Username;

	// Get the user's last post time
	$query = "
		select 	USER_LAST_POST_TIME
		from	{$config['TABLE_PREFIX']}USER_DATA
		where	USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
	list($user['USER_LAST_POST_TIME']) = $dbh->fetch_array($sth);

	// -----------------
	// Get the user info
	$IP = find_environmental('REMOTE_ADDR');

/* FLOOD CONTROL FOR PROFILE COMMENTS?
	// Flood control settings
	if ($userob->is_logged_in) {
		$lastposttime = $user['USER_LAST_POST_TIME'];
		if ($user['USER_FLOOD_CONTROL_OVERRIDE'] == "-1") {
			$floodcontrol = $userob->check_access("forum","POST_THROTTLE",$Board);
		}
		else {
			$floodcontrol = $user['USER_FLOOD_CONTROL_OVERRIDE'];
		}
	} else {
		$floodcontrol = $userob->check_access("forum","POST_THROTTLE",$Board);
		$lastposttime = get_input("lastposttime","cookie");
	}

	// ---------------------------------
	// Check if they can make a post yet
	if ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && !preg_match("/Moderator/",$user['USER_MEMBERSHIP_LEVEL'])) {
		if (($html->get_date() - $lastposttime) < $floodcontrol) {
			$html->not_right($html->substitute($ubbt_lang['FLOODCONTROL'],array('FLOOD_LIMIT' => $floodcontrol)));
		}
	}

	// Let's make sure this post doesn't already exist
	if ($md5_stamp) {
		$query = "
			select USER_ID,PROFILE_ID
			from {$config['TABLE_PREFIX']}PROFILE_COMMENTS
			where COMMENT_MD5 = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($md5_stamp),__LINE__,__FILE__);
		while(list($md5_user,$md5_profile) = $dbh->fetch_array($sth)) {
			if ($md5_user == $user['USER_ID'] && $md5_profile == $profile) {
				$html->not_right($ubbt_lang['NO_DUPS']);
			} // end if
		} // end while
	} // end if

*/

	// ------------------
	// Check the referer
	if (!$config['DISABLE_REFERER_CHECK']) {
		$html -> check_refer();
	}


	$Body = $html -> do_markup($Body,"post","markup");

	// --------------------
	// Get the current time
	$date = $html -> get_date();

	// ---------------------------------
	// INSERT THE COMMENT INTO THE DATABASE
	$query = "
		insert into {$config['TABLE_PREFIX']}PROFILE_COMMENTS
		(PROFILE_ID,USER_ID,COMMENT_BODY,COMMENT_DEFAULT_BODY,COMMENT_MD5,COMMENT_TIME)
		values
		( ? , ? , ? , ? , ? , ? )
	";
	$dbh->do_placeholder_query($query,array($profile,$user['USER_ID'],$Body,$DefaultBody,$comment_md5,$date),__LINE__,__FILE__);

	// Get the comment id
	$query = "
		SELECT last_insert_id()
	";
	$sth = $dbh -> do_query($query,__LINE__,__FILE__);
	list ($commentid) = $dbh -> fetch_array($sth);

	$pm_body = $html->substitute($ubbt_lang['NEW_COMMENT_BODY'],array('USER' => $user['USER_DISPLAY_NAME'],'LINK' => "<a href='" . make_ubb_url("ubb=showprofile&User=$profile", $ubbt_lang['YOUR_PROFILE'], false) . "'>{$ubbt_lang['YOUR_PROFILE']}</a>"));

	$html->send_message($config['MAIN_ADMIN_ID'],$profile,$ubbt_lang['NEW_COMMENT'],$pm_body);


	return array(
		"data" => "",
		"header" => "",
		"template" => "",
		"footer" => false,
		"location" => "showprofile&User=$profile&#comment=$commentid",
	);

}

?>
