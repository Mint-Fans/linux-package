<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;
define('NO_WRAPPER',1);

function page_quickquote_gpc () {
	return array(
		"input" => array(
			"post" => array("post","get","int"),
			"pt" => array("pt","get","int"),
		),
		"wordlets" => array(),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
		"no_session" => 1,
	);
} // end page_quickquote_gpc

function page_quickquote_run () {

	global $smarty,$userob,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	if ($pt == "1") {

		$post_body = "";
		$query = "
			select 	t2.POST_DEFAULT_BODY, t3.USER_DISPLAY_NAME
			from	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS as t1,
				{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS as t2,
				{$config['TABLE_PREFIX']}USERS as t3
			where	t2.POST_ID = ?
			and     t1.USER_ID = ?
			and	t3.USER_ID = t2.USER_ID
			and	t2.TOPIC_ID = t1.TOPIC_ID
		";
		$sth = $dbh->do_placeholder_query($query,array($post,$user['USER_ID']),__LINE__,__FILE__);
		list($post_body, $user_name) = $dbh->fetch_array($sth);
		
	} else {
		$query = "
			select t1.FORUM_ID,t2.POST_DEFAULT_BODY, t3.USER_DISPLAY_NAME, t2.USER_ID,t2.POST_POSTER_NAME
			from {$config['TABLE_PREFIX']}TOPICS as t1,
			{$config['TABLE_PREFIX']}POSTS as t2,
			{$config['TABLE_PREFIX']}USERS as t3
			where t2.POST_ID = ? and t3.USER_ID = t2.USER_ID
			and t1.TOPIC_ID = t2.TOPIC_ID
		";

		$sth = $dbh->do_placeholder_query($query,array($post),__LINE__,__FILE__);
		list($Board,$post_body, $user_name, $poster_id,$anon) = $dbh->fetch_array($sth);
		if (!$userob->check_access("forum","SEE_FORUM",$Board)) {
			$post_body = "";
		}
	}

	if ($poster_id == 1) {
		if ($anon) {
			$user_name = $anon;
		} else {
			$user_name = $ubbt_lang['ANON_TEXT'];
		}
	} // end if

	header("Content-Type: text/html; charset={$ubbt_lang['CHARSET']}");
	echo '[quote=' . $user_name . ']' . $post_body . '[/quote]';
	
	// Bypass smarty completely
	return false;


}

?>
