<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_removeignore_gpc () {
	return array(
		"input" => array(
			"User" => array("User","get","int"),
		),
		"wordlets" => array(""),
		"user_fields" => "t2.USER_IGNORE_LIST",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_removeignore_gpc

function page_removeignore_run () {

	global $user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// ------------------------
	// Predefine some variables
	if (!isset($PHPSESSID)) {
		$PHPSESSID = "";
	}
	// -----------------------
	// Let's delete the entry
	$user['USER_IGNORE_LIST'] = str_replace("-$User-","-",$user['USER_IGNORE_LIST']);
	$date = $html -> get_date();
	$query = "
		UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
		SET USER_IGNORE_LIST = ?
		WHERE USER_ID = ?
	";
	$dbh -> do_placeholder_query($query,array($user['USER_IGNORE_LIST'],$user['USER_ID']),__LINE__,__FILE__);
	
	$query = "
		UPDATE {$config['TABLE_PREFIX']}USER_DATA
		SET USER_LAST_VISIT_TIME = ?
		WHERE USER_ID = ?
	";
	$dbh -> do_placeholder_query($query,array($date,$user['USER_ID']),__LINE__,__FILE__);

	// ----------------------
	// Return to the addressbook
	return array(
		"header" => "",
		"template" => "",
		"data" => "",
		"footer" => false,
		"location" => "showaddressbook&PHPSESSID=$PHPSESSID",
	);

}	

?>
