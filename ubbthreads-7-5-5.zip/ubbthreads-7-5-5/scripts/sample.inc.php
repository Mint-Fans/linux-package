<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

// Function name should always be page_scriptname_gpc ()
function page_sample_gpc () {
	return array(
		"input" => array(
			// This is an array of variables that you expect from the user
			// "varname" => array("fieldname","requesttype","vartype");
			// requesttype can be either "get", "post" or "both"
			// vartype can be "int", "alpha", "alphanum" or just blank if it can contain any characters
			"var1" => array("var1","get","int"),
			"var2" => array("var2","get","alphanum"),
		),
		// If you are making a wordlet file to go with your script you specify that here
		"wordlets" => array("sample"),
		// Any special USER_PROFILE fields you require for the script go here
		"user_fields" => "",
		// If this is only available to registered users, set regonly to 1
		"regonly" => 0,
		// If this is only available to admins, set admin_only to 1
		"admin_only" => 0,
		// If this is only available to admins and mods, set admin_or_mod to 1
		"admin_or_mod" => 0,
	);
} // end page_sample_gpc


// This is the meat and bones of the script
// function name should always be page_scriptname_run
function page_sample_run () {

	// Normally, the following global variables are needed.
	global $myinfo,$smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	// Don't change this line, it's always needed
	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars


	// Any variables that you are going to be using in the template for this script need to be defined in this array
	$var1 = $var2 = "Hi! - Ian";
	$smarty_data = array(
		"var1" => $var1,
		"var2" => $var2,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	// This defines some things on how the page is built
	return array(
		"header" => array (
			"title" => "PAGE TITLE", // Title of the page
			"refresh" => 0, // Should the page periodically refresh?
			"user" => "", // You shouldn't need to change
			"Board" => "", // Is this tied to a board?
			"bypass" => 0, // You shouldn't need to change
			"onload" => "", // Any onload properties?
			// Breadcrumb links.
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 {$ubbt_lang['LOGIN_PROMPT']}
BREADCRUMB
			,
		),
		"template" => "sample", // The template that is used for this page
		"data" => & $smarty_data,  // Don't change
		"footer" => true, // Shouldn't need to change
		"location" => "", // This is only used in the case of a redirect
	);

}

?>
