<?php

//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_search_gpc () {
	return array(
		"input" => array(
		),
		"wordlets" => array("search"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_search_gpc

function page_search_run () {

	global $smarty,$userob,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html,$tree;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars


	// -------------------------
	// Predefine a few variables
	$referer = "";
	$board = "";
	$groupquery = "";
	$initialcat = "";
	$options = "";

	if (!$userob->check_access("site","CAN_SEARCH")) {
		$html->not_right($ubbt_lang['NO_SEARCH']);
	}

	// ------------------------------------------------------------------------
	// Let's figure out if they were on a forum, so we can default to searching
	// that forum
	$referer = find_environmental ("HTTP_REFERER");
	if ($referer!="") {
		if (preg_match("#/Board/#",$referer)){
			preg_match("#Board/(.*)#",$referer,$piece);
		}else{
			preg_match("#Board=(.*)#",$referer,$piece);
		}
		if (isset($piece['1'])) {
			$referer = $piece['1'];
			$board = $referer;
			if (stristr($referer,"&")) {
				list ($board,$crap) = preg_split("#&#",$referer);
			}
			if (stristr($referer,"/")) {
				list ($board,$crap) = preg_split("#/#",$referer);
			}
		}
	}




	if (!sizeof($tree)) {
        list($tree,$style_cache,$lang_cache) = build_forum_cache();
	}
		
	$allselected = "selected=\"selected\"";	
	$options = "";
	$category = "";
	$forums = 0;
	foreach($tree['categories'] as $cat => $cat_title) {
		$category = "";
		$forums = 0;
		$category .= "<option value=\"c$cat\">$cat_title ------</option>";
		if (!isset($tree[$cat])) continue;
		foreach($tree[$cat] as $forum_id => $forum_title) {
			$selected = "";
			if ($board == $forum_id) {
				$selected = "selected=\"selected\"";
				$allselected = "";
			}
			if (!$userob->check_access("forum","READ_TOPICS",$forum_id) || $tree['active'][$forum_id] != 1) { continue; }
			$category .= "<option value=\"f$forum_id\" $selected>$forum_title</option>";	
			$forums++;
		}
		if ($forums) $options .= $category;
	}
		
	// What type of range?
	if (!isset($config['MAX_SEARCH_RANGE_TYPE']) || !$config['MAX_SEARCH_RANGE_TYPE']) {
		$config['MAX_SEARCH_RANGE_TYPE'] = "years";
	}
	if (!isset($config['MAX_SEARCH_RANGE_VALUE']) || !$config['MAX_SEARCH_RANGE_VALUE']) {
		$config['MAX_SEARCH_RANGE_VALUE'] = 1;
	}
	$config['MAX_SEARCH_RANGE_TYPE'] = preg_replace("/s$/","",$config['MAX_SEARCH_RANGE_TYPE']);
	$config['MAX_SEARCH_RANGE_TYPE'] = $ubbt_lang[strtoupper($config['MAX_SEARCH_RANGE_TYPE'])];


	$smarty_data = array(
		"allselected" => $allselected,
		"options" => & $options,
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array (
			"title" => $ubbt_lang['TEXT_SEARCH'],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 {$ubbt_lang['TEXT_SEARCH']}
BREADCRUMB
			,
		),
		"template" => "search",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
