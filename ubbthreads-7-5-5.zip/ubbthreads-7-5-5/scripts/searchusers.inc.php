<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_searchusers_gpc () {
	return array(
		"input" => array(
			"searchvalue" => array("searchvalue","post","alphanum"),
		),
		"wordlets" => array("searchusers"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_searchusers_gpc

function page_searchusers_run () {

	global $smarty,$userob,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	if (strlen($searchvalue) < 3) {
		$html->not_right($ubbt_lang['MORE_LETTERS']);
	} // end if

	// Grab our current favorites
	$query = "
		select 	WATCH_ID
		from		{$config['TABLE_PREFIX']}WATCH_LISTS
		where		USER_ID = ?
		and			WATCH_TYPE = 'u'
	";
	$sth = $dbh->do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
	$in_list = "";
	while(list($uid) = $dbh->fetch_array($sth)) {
		$in_list .= "'$uid',";
	} // end while
	$in_list = preg_replace("/,$/","",$in_list);

	if ($in_list) {
		$in_list = "and USER_ID not in ($in_list)";
	}

	$query = "
		select	USER_ID,USER_DISPLAY_NAME
		from		{$config['TABLE_PREFIX']}USERS
		where		USER_DISPLAY_NAME like ?
		and			USER_ID <> '1'
		and			USER_ID <> ?
		$in_list
	";
	$sth = $dbh->do_placeholder_query($query,array("%$searchvalue%",$user['USER_ID']),__LINE__,__FILE__);
	$results = $dbh->total_rows($sth);

	if (!$results) {
		$html->not_right($ubbt_lang['NO_RESULTS'] . $searchvalue);
	}
	if ($results > 100) {
		$html->not_right($ubbt_lang['TOO_MANY'] . $searchvalue);
	}

	$row = 0;
	$user_array = array();
	while(list($user_id,$display_name) = $dbh->fetch_array($sth)) {
		$user_array[$row] = array(
			"id" => $user_id,
			"display_name" => $display_name,
		);
		$row++;
	} // end while

	$smarty_data = array(
		"user_array" => $user_array,
		"mystuff" => $html->mystuff(),
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array (
			"title" => "{$ubbt_lang['HEADER']}",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 {$ubbt_lang['HEADER']}
BREADCRUMB
			,
		),
		"template" => "searchusers",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
