<?php

//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	You may not distribute "hacks" for UBB without approval from
//	Mindraven
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_sendmessage_gpc () {
	return array(
		"input" => array(
			"Sender" => array("Sender","post","int"),
			"Username" => array("Username","post",""),
			"User" => array("User","post",""),
			"AddBook" => array("AddBook","post","int"),
			"AddressBook" => array("AddressBook","post",""),
			"Subject" => array("Subject","post",""),
			"Body" => array("Body","post",""),
			"preview" => array("preview","post","alphanum"),
			"submit" => array("submit","post",""),
			"recips_serial" => array("recips","post",""),
			"fromname" => array("fromname","post",""),
		),
		"wordlets" => array("sendmessage","sendprivate"),
		"user_fields" => "USER_TEXT_EDITOR",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_sendmessage_gpc

function page_sendmessage_run () {

	global $smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html,$userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$recips = unserialize($recips_serial);

	if ($Username || $User) {
		if ($Username) {
			$clause = "t2.USER_DISPLAY_NAME = ?";
			$query_var = $Username;
		} else {
			$clause = "t2.USER_ID = ?";
			$query_var = $User;
		} // end if

		$query = "
			select t1.USER_REAL_EMAIL,t1.USER_NOTIFY_ON_PM,t1.USER_ACCEPT_PM,t1.USER_ID,t1.USER_IGNORE_LIST,t2.USER_MEMBERSHIP_LEVEL,t2.USER_DISPLAY_NAME
			from {$config['TABLE_PREFIX']}USER_PROFILE as t1,
			{$config['TABLE_PREFIX']}USERS as t2
			where $clause
			and t1.USER_ID = t2.USER_ID
		";
		$sth = $dbh->do_placeholder_query($query,array($query_var),__LINE__,__FILE__);

		list($Email,$Notify,$AcceptPriv,$Uid,$Ignored,$ustatus,$Displayname) = $dbh->fetch_array($sth);

		// Make sure the user exists.

		// Check if recipient is overlimit
		$query = "
			select max(t1.PM_TOTAL)
			from {$config['TABLE_PREFIX']}SITE_PERMISSIONS as t1,
			{$config['TABLE_PREFIX']}USER_GROUPS as t2
			where t1.GROUP_ID = t2.GROUP_ID
			and t2.USER_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($Uid),__LINE__,__FILE__);
		list($pm_limit) = $dbh->fetch_array($sth);

		if (!$Uid) {
			$html->not_right($ubbt_lang['NOTFOUND']);
		} // end if

		$query = "
			select count(*)
			from {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
			where USER_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($Uid),__LINE__,__FILE__);
		list($total) = $dbh->fetch_array($sth);
		if ($total >= $pm_limit && $user['USER_MEMBERSHIP_LEVEL'] != "Administrator") {
			$html->not_right($html->substitute($ubbt_lang['OVERLIMIT'],array("USER" => $Displayname)));
		} // end if

		// Check if they want this private message
		if ($AcceptPriv == "no" && $user['USER_MEMBERSHIP_LEVEL'] != "Administrator") {
			$html->not_right($ubbt_lang['NO_PRIVATE']);
		} // end if
		if (preg_match("/-{$user['USER_ID']}-/",$Ignored) && $user['USER_MEMBERSHIP_LEVEL'] != "Administrator") {
			$html->not_right($ubbt_lang['IGNORING_YOU']);
		} // end if
		if ($Uid == $user['USER_ID']) {
			$html->not_right($ubbt_lang['DUH']);
		} // end if

		if (!$Uid) {
			$html->not_right($html->substitute($ubbt_lang['NO_RECORD'], array('USERNAME' => $Username)));
		}

		$recips[] = $Uid;

	} // end if

	if (sizeof($recips) > $userob->check_access("site","PM_INVITES")) {
		$html->not_right($html->substitute($ubbt_lang['TOO_MANY'], array('MAX_IN_PM' => $userob->check_access("site","PM_INVITES"))));
	}

	if ($config['DO_CENSOR']) {
		$Subject = $html->do_censor($Subject);
		$Body = $html->do_censor($Body);
	}

	$RawSubject = $Subject;
	$RawBody    = $Body;
	$Message = $Body;

	// -------------------------------------
	// Make sure there is a subject and body
	if ( (preg_match("/^\s*$/",$Subject)) || ($Message == "") ) {
		$html -> not_right($ubbt_lang['ALL_FIELDS']);
	}

	// ------------
	// Get the time
	$date = $html -> get_date();

	// ------------------------------
	// Get rid of HTML in the subject
	$Subject = htmlspecialchars($Subject);

	// ------------------
	// Markup the Message
	$Message = $html->do_markup($Message,"post","markup");

	// --------------------------
	// Insert it into the database
	$query_vars = array($date,0,$Subject,$user['USER_ID'],$date);
	$query = "
		insert into {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS
		(TOPIC_TIME,TOPIC_REPLIES,TOPIC_SUBJECT,USER_ID,TOPIC_LAST_REPLY_TIME)
		values
		( ? , ? , ? , ? , ? )
	";
	$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	$query = "
		select last_insert_id()
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	list($message_id) = $dbh->fetch_array($sth);

	$query_vars = array($message_id,$user['USER_ID'],$Message,$date,$RawBody);
	$query = "
		INSERT INTO {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
		(TOPIC_ID,USER_ID,POST_BODY,POST_TIME,POST_DEFAULT_BODY)
		values
		( ? , ? , ? , ? , ? )
	";
	$dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	$query = "
		select last_insert_id()
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	list($post_id) = $dbh->fetch_array($sth);

	// Insert the sender into the PM_USERS table with a timestamp
	// so this doesn't look new
	$query_vars = array($message_id,$user['USER_ID'],$date);
	$query = "
		insert into {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
		(TOPIC_ID,USER_ID,MESSAGE_LAST_READ)
		values
		( ? , ? , ? )
	";
	$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

	$sent = array();
	$overlimits = ""; 
	foreach($recips as $k => $User) {

		if ($User == $user['USER_ID']) continue;
		if (in_array($User,$sent)) continue;

		$sent[] = $User;

		$query = "
			SELECT t1.USER_REAL_EMAIL,t1.USER_NOTIFY_ON_PM, t1.USER_ACCEPT_PM,t1.USER_ID,t1.USER_IGNORE_LIST,t2.USER_MEMBERSHIP_LEVEL,t2.USER_DISPLAY_NAME, t1.USER_LANGUAGE
			FROM   {$config['TABLE_PREFIX']}USER_PROFILE as t1,
			{$config['TABLE_PREFIX']}USERS as t2
			WHERE  t1.USER_ID = ?
			AND	t1.USER_ID = t2.USER_ID
		";
		$sth = $dbh -> do_placeholder_query($query,array($User),__LINE__,__FILE__);
		list ($Email,$Notify,$AcceptPriv,$Uid,$Ignored,$ustatus,$Username,$Lang) = $dbh -> fetch_array($sth);


		// ----------------------------------------------
		// Let's grab how many private messages they have
		$query = "
			SELECT COUNT(*)
			FROM   {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS as t1,
            {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS as t2
			WHERE  t1.USER_ID = ?
      AND t1.TOPIC_ID = t2.TOPIC_ID
		";
		$sth = $dbh -> do_placeholder_query($query,array($Uid),__LINE__,__FILE__);
		list($total) = $dbh -> fetch_array($sth);

		// Check if recipient is overlimit
		$query = "
			select max(t1.PM_TOTAL)
			from {$config['TABLE_PREFIX']}SITE_PERMISSIONS as t1,
			{$config['TABLE_PREFIX']}USER_GROUPS as t2
			where t1.GROUP_ID = t2.GROUP_ID
			and t2.USER_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($Uid),__LINE__,__FILE__);
		list($pm_limit) = $dbh->fetch_array($sth);

		if ($total >= $pm_limit && $user['USER_MEMBERSHIP_LEVEL'] != "Administrator") {
			$overlimits .= "$Username, ";
			continue;
		}

		// -------------------------------
		// Check if they want this message
		if ($AcceptPriv == "no" && $user['USER_MEMBERSHIP_LEVEL'] != "Administrator") {
			continue;
		}
		if ( preg_match("/-{$user['USER_ID']}-/",$Ignored)) {
			continue;
		}

		// ----------------------------------------------
		// We didn't find that Username, so let them know
		if (!$Uid){
			continue;
		}

		// Insert the recipient into the PM_USERS table with no timestamp
		// so this is marked new
		$query_vars = array($message_id,$Uid,0);
		$query = "
			insert into {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
			(TOPIC_ID,USER_ID,MESSAGE_LAST_READ)
			values
			( ? , ? , ? )
		";
		$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

		// Check and see if there are any more unread PMs
		$query = "
			select	count(*)
			from	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS as t1,
				{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS as t2
			where	t1.TOPIC_ID = t2.TOPIC_ID
			and	t2.TOPIC_LAST_REPLY_TIME > t1.MESSAGE_LAST_READ
			and	t1.USER_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($Uid),__LINE__,__FILE__);
		list($total_unread) = $dbh->fetch_array($sth);

		$query = "
			update	{$config['TABLE_PREFIX']}USER_PROFILE
			set	USER_TOTAL_PM = ?
			where	USER_ID = ?
		";
		$dbh->do_placeholder_query($query,array($total_unread,$Uid),__LINE__,__FILE__);

		// ---------------------------------------------------------------
		// Now lets let them know they got a private message if they chose
		// to be notified
		if ($Notify == "yes") {
			$mailer = new mailer();
			$mailer->set_language($Lang);
			$mailer->set_subject('PMN_SUBJECT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
			$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $Username));
			$mailer->add_content('PMN_CONTENT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE'], 'FROMNAME' => $fromname));
			$mailer->add_content('PMN_CONTENT1', array('PM_URL' => make_ubb_url("ubb=viewmessage&message=$message_id&gonew=1" ,"", true, true)), true);
			$mailer->add_content('PMN_CONTENT2', array(), true);
			$mailer->add_post($fromname,$Subject,array(),$Message,$RawBody);
			$mailer->ubbt_mail($Email);
		}
	}

	if ($overlimits) {
		$overlimits = preg_replace("/, $/","",$overlimits);
		$over_mess = $html->substitute($ubbt_lang['RECIP_OVER'],array("USERS" => $overlimits));
		$onload = "alert(\"$over_mess\")";
	}

	return array(
		"data" => $data,
		"header" => "",
		"template" => "",
		"footer" => false,
		"location" => "viewmessage&message=$message_id&#post$post_id",
		"onload" => $onload,
	);

}

?>
