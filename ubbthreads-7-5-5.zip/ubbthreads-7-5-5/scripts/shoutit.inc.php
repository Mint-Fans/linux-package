<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;
define('NO_WRAPPER',1);
function page_shoutit_gpc () {
	return array(
		"input" => array(
			"shout" => array("shout","post",""),
		),
		"wordlets" => array(""),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
		"no_session" => 1,
	);
} // end page_shoutit_gpc

function page_shoutit_run () {

	global $smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$user_id = $user['USER_ID'];
	$display_name = $user['USER_DISPLAY_NAME'];
	$text = trim($shout);
	
	$text = htmlspecialchars($text);
	$words = explode(" ", $text);
	foreach ($words as $i =>$w) {
		if (strlen(html_entity_decode($words[$i])) > 20) {
			$words[$i] = $html->utf8_wordwrap($words[$i],20,"<br />", 1);
		} // end if
	} // end if
	$text = implode(" ", $words);

	$time = $html->get_date();
	$ip = find_environmental('REMOTE_ADDR');
	
	$text = $html->do_markup($text,"shoutbox","markup");
	if ($config['DO_CENSOR']) {
		$text = $html->do_censor($text);
	} // end if
	
	$query_vars = array($user_id,$display_name,$text,$time,$ip);
	
	if ($text && $user_id) {
		$query = "
			insert into {$config['TABLE_PREFIX']}SHOUT_BOX
			(USER_ID,SHOUT_DISPLAY_NAME,SHOUT_TEXT,SHOUT_TIME,USER_IP)
			values
			( ? , ? , ? , ? , ? )
		";
		$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	} // end if

	return false;

}

?>
