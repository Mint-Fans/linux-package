<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;
define('NO_WRAPPER',1);
function page_showimage_gpc () {
	return array(
		"input" => array(
			"id" => array("id","get","int"),
			"type" => array("type","get","alpha"),
		),
		"wordlets" => array(),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_showimage_gpc

function page_showimage_run () {

	global $html,$style_array,$smarty,$userob,$user,$in,$myinfo,$ubbt_lang,$config,$forumvisit,$visit,$dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$query = "
		select FILE_NAME,FILE_ORIGINAL_NAME,FILE_DIR,FILE_WIDTH,FILE_HEIGHT,FILE_TYPE
		from {$config['TABLE_PREFIX']}FILES
		where FILE_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($id),__LINE__,__FILE__);
	list($filename,$filename_orig,$filedir,$width,$height,$ext) = $dbh->fetch_array($sth);


        // ---------------------------------------------
        // Now let's update the total # of downloads by 1
        $query = "
        	UPDATE {$config['TABLE_PREFIX']}FILES
        	SET FILE_DOWNLOADS = FILE_DOWNLOADS + 1
        	WHERE FILE_ID = ?
        ";
        $dbh -> do_placeholder_query($query,array($id),__LINE__,__FILE__);


	if ($type == "f") {
		$type = "full";
	} elseif ($type == "m") {
		$type = "medium";
	} elseif ($type == "t") {
		$type = "thumbs";
	} else {
		return false;
	}

	
	if ($ext == "jpg") {
		header("Content-type: image/jpeg");
	} elseif ($ext == "gif") {
		header("Content-type: image/gif");
	} elseif ($ext == "png") {
		header("Content-type: image/png");
	} else {
		return false;
	} // end if
		
	readfile("{$config['FULL_PATH']}/gallery/$filedir/$type/$filename");

	return false;
}

?>
