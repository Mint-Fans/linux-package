<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;
define('NO_WRAPPER',1);
function page_showpic_gpc () {
	return array(
		"input" => array(
			"id" => array("id","get","int"),
		),
		"wordlets" => array(),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_showpic_gpc

function page_showpic_run () {

	global $html,$style_array,$smarty,$userob,$user,$in,$myinfo,$ubbt_lang,$config,$forumvisit,$visit,$dbh;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$query = "
		select FILE_NAME,FILE_ORIGINAL_NAME,FILE_DIR,FILE_WIDTH,FILE_HEIGHT,FILE_TYPE,FILE_DESCRIPTION
		from {$config['TABLE_PREFIX']}FILES
		where FILE_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($id),__LINE__,__FILE__);
	list($filename,$filename_orig,$filedir,$width,$height,$type,$desc) = $dbh->fetch_array($sth);

	if ($desc) {
		$filename = preg_replace("/ +/","_",$desc) . ".$type";
	} else {
		$filename = $filename_orig;
	} // end if 

	$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";

	$smarty_data = array(
		"stylesheet" => $stylesheet,
		"filename" => $filename,
		"img" => "{$config['FULL_URL']}/gallery/$filedir/full/$id.$type",
		"id" => $id,
		"width" => $width,
		"height" => $height,
		"dir" => $filedir,
		"ext" => $type,
	);

	return array(
		"header" => array (
			"title" => "",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => 0,
			"breadcrumb" => "",
		),
		"template" => "showpic",
		"data" => & $smarty_data,
		"footer" => false,
		"location" => "",
	);
}

?>
