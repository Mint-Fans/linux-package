<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_showprofile_gpc () {
	global $config;
	return array(
		"input" => array(
			"User" => array("User","get","int"),
			"page" => array("page","get","int"),
		),
		"wordlets" => array("showprofile"),
		"user_fields" => "t2.USER_SHOW_AVATARS, t2.USER_TIME_FORMAT, t2.USER_IGNORE_LIST,t2.USER_TOTAL_POSTS",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_showprofile_gpc

function page_showprofile_run () {

	global $style_array,$userob,$smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// -------------------------
	// Predefine a few variables
	$CUSTOM_FIELD_1 = "";	$CUSTOM_FIELD_2   = ""; $CUSTOM_FIELD_3   = "";	$CUSTOM_FIELD_4   = "";	$CUSTOM_FIELD_5   = "";
	$privlinkstart = "";$privlinkstop="";$useredit="";$addresslinks="";
	$ignorelinkstart = ""; $ignorelinkstop = ""; $ignoretext = "";
	$addresslink = "";
	$picview = "";
	$toffset = "";

	// Make sure User is numeric
	$User = intval($User);

	isset($user['USER_SHOW_AVATARS']) && $picview = $user['USER_SHOW_AVATARS'];
	isset($user['USER_TIME_OFFSET'])  && $toffset = $user['USER_TIME_OFFSET'];
	!isset($user['USER_TIME_FORMAT']) && $user['USER_TIME_FORMAT'] = $config['TIME_FORMAT'];
	!isset($user['USER_IGNORE_LIST']) && $user['USER_IGNORE_LIST'] = "";

	$Username = $user['USER_DISPLAY_NAME'];

	if (!$userob->check_access("site","MEMBER_PROFILES") && ($user['USER_ID'] != $User)) {
		$html->not_right($ubbt_lang['NO_PROFILES']);
	} // end if

	if ($User == 1) {
		$html -> not_right($ubbt_lang['NO_LONGER']);
	}

	// Main Admin Uid
	$config['MAIN_ADMIN_ID'] = array_get($config, 'MAIN_ADMIN_ID', 2);

	// ------------------------------
	// Grab the profile for this user
	$query = "
	SELECT t1.USER_DISPLAY_NAME,t2.USER_DISPLAY_EMAIL,t2.USER_TOTAL_POSTS,t2.USER_HOMEPAGE,t2.USER_OCCUPATION,t2.USER_HOBBIES,t2.USER_LOCATION,t2.USER_ICQ,t2.USER_EXTRA_FIELD_1,t2.USER_EXTRA_FIELD_2,t2.USER_EXTRA_FIELD_3,t2.USER_EXTRA_FIELD_4,t2.USER_EXTRA_FIELD_5,t1.USER_REGISTERED_ON,t2.USER_AVATAR,t2.USER_TITLE,t2.USER_CUSTOM_TITLE,t1.USER_MEMBERSHIP_LEVEL,t1.USER_ID,t2.USER_TOTAL_RATES,t2.USER_RATING,t2.USER_AVATAR_WIDTH,t2.USER_AVATAR_HEIGHT,t2.USER_BIRTHDAY,t2.USER_PUBLIC_BIRTHDAY,t1.USER_IS_UNDERAGE,t2.USER_ICQ,t2.USER_YAHOO,t2.USER_MSN,t2.USER_AIM,t2.USER_SIGNATURE,t2.USER_MOOD,t2.USER_GROUP_IMAGES
	FROM   {$config['TABLE_PREFIX']}USERS as t1,
	{$config['TABLE_PREFIX']}USER_PROFILE as t2
	WHERE  t1.USER_ID = ?
	AND t1.USER_ID = t2.USER_ID
	";
	$sth = $dbh -> do_placeholder_query($query,array($User),__LINE__,__FILE__);

	// ----------------
	// Assign the stuff
	list ($CheckUser,$Fakeemail,$Totalposts,$Homepage,$Occupation,$Hobbies,$Location,$ICQ,$Extra1,$Extra2,$Extra3,$Extra4,$Extra5,$Registered,$Picture,$Title,$CustomTitle,$Userstatus,$UNumber,$Rates,$Rating,$width,$height,$Birthday,$showbday,$coppauser,$icq,$yahoo,$msn,$aim,$Signature,$mood,$groupimages) = $dbh -> fetch_array($sth);
	$dbh -> finish_sth($sth);

	$profileuser = $CheckUser;


	// ------------------------------------------------
	// If this is a coppa user, we can't show some info
	if ($coppauser) {
		$Fakeemail = "";
		$Homepage = "";
		$Occupation = "";
		$Hobbies = "";
		$Location = "";
		$icq = "";
		$Extra1 = "";
		$Extra2 = "";
		$Extra3 = "";
		$Extra4 = "";
		$Extra5 = "";
		$Picture = "";
	}

	// Set a default mood
	if (!$mood || !$config['ENABLE_MOODS']) {
		$mood = "content.gif";
	} // end if

	$extraquery = "";
	if (!$config['DISABLE_ONLINE_INVISIBLE'] && ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && !preg_match("/Moderator/",$user['USER_MEMBERSHIP_LEVEL']))) {
		$extraquery = "AND t2.USER_VISIBLE_ONLINE_STATUS = 'YES'";	
	}
	$query = "
		SELECT count( t1.USER_ID )
		FROM {$config['TABLE_PREFIX']}ONLINE AS t1, {$config['TABLE_PREFIX']}USER_PROFILE AS t2
		WHERE t1.USER_ID = t2.USER_ID
		AND t1.USER_ID = ?
		$extraquery
	";
	$sth = $dbh->do_placeholder_query($query,array($User),__LINE__,__FILE__);
	list($isonline) = $dbh -> fetch_array($sth);	
	if (!$isonline) {
		$mood = "offline.gif";
		$mood_alt = $ubbt_LANG['OFFLINE'];
	} else {
		$mood_alt = "{$ubbt_LANG['ONLINE']}   ".preg_replace("#.(gif|jpg|png)$#","",$mood);
	} // end if
																															
	$groupimages = $html->user_status($User,$groupimages);

	if (!$config['ENABLE_MOODS']) {
		$mood_alt = "";
	}

	// ----------------------------------
	// Figure out the # of stars they get
	$stars = $Rating;
	$Rating = "";
	if (isset($stars)) {
		for ($x=1;$x<=$stars;$x++) {
			$Rating .= "<img src=\"{$config['BASE_URL']}/images/{$style_array['general']}/star.gif\" title= \"$Rates {$ubbt_lang['T_RATES']}\" alt=\"*\" />";
		}
	}

	// ---------------------------
	// Are user ratings turned on?
	if (!$config['USER_RATINGS']) {
		$Rating = "";
	}

	// ----------------------------------------
	// Let's see if we already rated this user
	$query = "
	SELECT RATING_VALUE
	FROM   {$config['TABLE_PREFIX']}RATINGS
	WHERE  RATING_TARGET = ?
	AND    RATING_RATER   = ?
	AND    RATING_TYPE    = 'u'
	";
	$sti = $dbh -> do_placeholder_query($query,array($UNumber,$user['USER_ID']),__LINE__,__FILE__);
	list($myrating) = $dbh -> fetch_array($sti);

	// ----------------------------------
	// Figure out what we need to display
	$birthday = "";
	if ($showbday) {
		// Need to convert to a date that strtotime() can work with
		// on all servers
		$parts = preg_split("#/#",$Birthday);
		$birthday_stamp = strtotime("2006-{$parts[0]}-{$parts[1]} 00:00:00");
		$month = date("n",$birthday_stamp);
		$day = date("j",$birthday_stamp);
		$year = $parts['2'];
		if (!$config['AGE_WITH_BIRTHDAYS']) {
			$year = "";
		}
		$mstring = "MONTH$month";
		$month = $ubbt_lang[$mstring];
		$birthday = "
		<tr><td class=\"alt-1\" width=\"20%\">
		{$ubbt_lang['BIRTHDAY']}:
		</td><td class=\"alt-2\">
		&nbsp;$month $day $year
		</td></tr>
		";
	}

	$ratinghtml = "";
	if ($config['USER_RATINGS'] == "1") {
		if (!$myrating) {
			$script = make_ubb_url("", "", false);
			$ratinghtml = <<<EOF
			<form method="post" action="$script">
			<input type="hidden" name="ubb" value="dorateuser" />
			<input type="hidden" name="Ratee" value="$UNumber" />
			<label for="rating">{$ubbt_lang['RATE_USER']}</label>
			<select name="rating" id="rating" class="form-select">
			<option value="1">{$ubbt_lang['STAR1']}</option>
			<option value="2">{$ubbt_lang['STAR2']}</option>
			<option value="3">{$ubbt_lang['STAR3']}</option>
			<option value="4">{$ubbt_lang['STAR4']}</option>
			<option value="5">{$ubbt_lang['STAR5']}</option>
			</select>
			<input type="submit" name="dorate" value="{$ubbt_lang['DORATE']}" class="form-button" />
			</form>
EOF;
		} else {
			$ratinghtml = " {$ubbt_lang['YOURATED']} $myrating.";
		}
	}


	// Show where the user is


	// -----------------------
	// You can't rate yourself
	if ($User == $user['USER_ID']) {
		$ratinghtml = "&nbsp;";
	}

	if ($CustomTitle && $config['ONLY_CUSTOM']) {
		$Title = $CustomTitle;
		$CustomTitle="";
	}

	// -----------------------------
	// Show the profile if it exists
	$columns = 2;
	if ($CheckUser) {

		if ($Homepage) {
			$Homepage = str_replace("http://","",$Homepage);
			$Homepage = str_replace("https://","",$Homepage);
			$Homepage = htmlspecialchars($Homepage);
			$Homepage = "<a href=\"http://$Homepage\" target=\"new\">http://$Homepage</a>";
		}

		if ($config['CUSTOM_FIELD_1']) {
			$CUSTOM_FIELD_1 = "
			<tr><td class='alt-1' valign='top'>
			{$config['CUSTOM_FIELD_1']}:
			</td><td valign='top' class='alt-2'>
			&nbsp;$Extra1
			</td></tr>
			";
		}
		if ($config['CUSTOM_FIELD_2']) {
			$CUSTOM_FIELD_2 = "
			<tr><td valign='top' class='alt-1'>
			{$config['CUSTOM_FIELD_2']}:
			</td><td valign='top' class='alt-2'>
			&nbsp;$Extra2
			</td></tr>
			";
		}
		if ($config['CUSTOM_FIELD_3']) {
			$CUSTOM_FIELD_3 = "
			<tr><td valign='top' class='alt-1'>
			{$config['CUSTOM_FIELD_3']}:
			</td><td valign='top' class='alt-2'>
			&nbsp;$Extra3
			</td></tr>
			";
		}
		if ($config['CUSTOM_FIELD_4']) {
			$CUSTOM_FIELD_4 = "
			<tr><td valign='top' class='alt-1'>
			{$config['CUSTOM_FIELD_4']}:
			</td><td valign='top' class='alt-2'>
			&nbsp;$Extra4
			</td></tr>
			";
		}
		if ($config['CUSTOM_FIELD_5']) {
			$CUSTOM_FIELD_5 = "
			<tr><td valign='top' class='alt-1'>
			{$config['CUSTOM_FIELD_5']}:
			</td><td valign='top' class='alt-2'>
			&nbsp;$Extra5
			</td></tr>
			";
		}

		$date = $html -> convert_time($Registered,$toffset,$user['USER_TIME_FORMAT']);

		// --------------------------------------------------------------
		// If this is an admin or moderator they get some special options
		$User = rawurlencode($User);
		$encoded = rawurlencode($User);
		if ($userob->check_access("cp","EDIT_USERS")) {
			// Only the main admin can edit other admin
			if ($user['USER_ID'] == $config['MAIN_ADMIN_ID']) {
				$useredit .= "<a href=\"{$config['BASE_URL']}/admin/showuser.php?uid=$User\">{$ubbt_lang['EDIT_T_U']}</a> | ";
			}
			// Other admins can edit any users not in the admin group
			elseif (($user['USER_MEMBERSHIP_LEVEL'] == "Administrator") && $Userstatus != "Administrator") {
				$useredit .= "<a href=\"{$config['BASE_URL']}/admin/showuser.php?uid=$User\">{$ubbt_lang['EDIT_T_U']}</a> | ";
			}
			// If they aren't an admin, they can only edit regular users
			elseif (($user['USER_MEMBERSHIP_LEVEL'] != "Administrator") && $Userstatus == "User") {

				$useredit .= "<a href=\"{$config['BASE_URL']}/admin/showuser.php?uid=$User\">{$ubbt_lang['EDIT_T_U']}</a> | ";
			}
		}

		// ---------------------------------------------------
		// Only show the address book link for logged in users
		if ($user['USER_DISPLAY_NAME'] && !$coppauser && $User != $user['USER_ID']) {
			$query = "
				SELECT	COUNT(USER_ID) AS COUNT
				FROM	{$config['TABLE_PREFIX']}ADDRESS_BOOK
				WHERE	USER_ID  = ? AND ADDRESS_ENTRY_USER_ID = ?
			";

			$sth = $dbh->do_placeholder_query($query, array($user['USER_ID'], $User), __LINE__, __FILE__);
			$result = $dbh->fetch_array($sth, MYSQL_ASSOC);
			$count = array_get($result, 'COUNT', 0);

			if ($count > 0) {
				$addresslink = " <a href=\"" . make_ubb_url("ubb=removeaddress&User=$User", "", false) . "\">{$ubbt_lang['REMOVE_BOOK']}</a> | ";
			} else {
				$addresslink = " <a href=\"" . make_ubb_url("ubb=addaddress&User=$User", "", false) . "\">{$ubbt_lang['ADD_BOOK']}</a> | ";
			}
		}

		$fav_user_link = "";
		if ($user['USER_DISPLAY_NAME'] && !$coppauser && $User != $user['USER_ID']) {

			// Let's see if this is a favorite user
			$query = "
				select	USER_ID
				from	{$config['TABLE_PREFIX']}WATCH_LISTS
				where	USER_ID = ?
				and	WATCH_ID = ?
				and	WATCH_TYPE = 'u'
			";
			$sth = $dbh->do_placeholder_query($query,array($user['USER_ID'],$User),__LINE__,__FILE__);
			list($fav_check) = $dbh->fetch_array($sth);

			if (!$fav_check) {
				$fav_user_link = " <a href=\"" . make_ubb_url("ubb=addfavuser&User=$User", "", false) . "\">{$ubbt_lang['ADD_FAV_USER']}</a> | ";
			} else {
				$fav_user_link = " <a href=\"" . make_ubb_url("ubb=addfavuser&User=$User", "", false) . "\">{$ubbt_lang['REM_FAV_USER']}</a> | ";
			}
		}

		if (($user['USER_DISPLAY_NAME']) && !$coppauser ){
			$privlinkstart = "<a href=\"" . make_ubb_url("ubb=sendprivate&User=$User", "", false) . "\">";
			$privlinkstop = "</a>";
		}

		// ---------------------------------------------------
		// Only logged in users can ignore / unignore people
		if ($user['USER_DISPLAY_NAME']) {
			if ($Userstatus != "Administrator" && !preg_match("/Moderator/",$user['USER_MEMBERSHIP_LEVEL']) && $user['USER_ID'] != $User) {
				$ignorelinkstart = "<a href=\"" . make_ubb_url("ubb=toggleignore&User=$User", "", false) . "\">";
				$ignorelinkstop = "</a> | ";
				if (preg_match("/-$User-/",$user['USER_IGNORE_LIST'])) {
					$ignoretext = $ubbt_lang['UNIGNORE'];
				}
				else {
					$ignoretext = $ubbt_lang['IGNORE'];
				}
			}
		}

	// ----------------
	// They don't exist
	} else {
		$html -> not_right($ubbt_lang['NO_LONGER']);
	}

	if ($Title && $CustomTitle) {
		$titleline = "$Title<br />&nbsp; $CustomTitle";
	} else {
		$titleline = $Title;
	}


	$stockPicture = "{$config['FULL_URL']}/images/{$style_array['general']}/nopicture.gif";
	$imagehw = getimagesize($stockPicture);
	$stockWidth = $imagehw[0];
	$stockHeight = $imagehw[1];

	if (!$Picture) {
		$Picture = $stockPicture;
		$width = $stockWidth;
		$height = $stockHeight;
	} // end if

	// Get the list of buddies
	$query = "
		select t2.USER_AVATAR,t2.USER_AVATAR_WIDTH,t2.USER_AVATAR_HEIGHT,t3.USER_DISPLAY_NAME,t3.USER_ID,t4.ONLINE_LAST_ACTIVITY,t2.USER_MOOD
		from {$config['TABLE_PREFIX']}ADDRESS_BOOK as t1
		left join {$config['TABLE_PREFIX']}ONLINE as t4 on t4.USER_ID = t1.USER_ID,
		{$config['TABLE_PREFIX']}USER_PROFILE as t2,
		{$config['TABLE_PREFIX']}USERS as t3
		where t1.ADDRESS_ENTRY_USER_ID = ?
		and t1.USER_ID = t2.USER_ID
		and t2.USER_ID = t3.USER_ID
	";
	$sth = $dbh->do_placeholder_query($query,array($User),__LINE__,__FILE__);
	$buddies = array();
	$listed = array();
	while(list($b_avatar,$b_width,$b_height,$b_display,$b_id,$b_online,$b_mood) = $dbh->fetch_array($sth)) {
		if (in_array($b_id,$listed)) continue;
		$listed[] = $b_uid;
		if (!$b_avatar) {
			$b_avatar = $stockPicture;
			$b_width = $stockWidth;
			$b_height = $stockHeight;
		} // end if
		$buddies[] = array(
			"avatar" => $b_avatar,
			"width" => $b_width,
			"height" => $b_height,
			"name" => $b_display,
			"id" => $b_id,
			"online" => $b_online,
			"mood" => $b_mood,
		);
	} // end while

	// Get the texteditor
	$text_editor = $html->create_text_editor("Body","",2,0,0);

	// MD5 for duplicate posts
	$md5_stamp = md5($user['USER_DISPLAY_NAME'] . time());

	$pages = "";
	if ($config['COMMENTS']) {

		if (!$page) $page = 1;

		// Grab total comments
		$query = "
			select count(*)
			from {$config['TABLE_PREFIX']}PROFILE_COMMENTS
			where PROFILE_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($User),__LINE__,__FILE__);
		list ($total) = $dbh->fetch_array($sth);
		if ($total > 10) {
			$pages = $html->paginate( $page, ceil($total/10) , "showprofile&User=$User&page=" );
		}
	
		// Grab any profile comments for this user
		if ($page == 1) {
			$limit = "10";
		} else {
			$limit = ($page - 1) * 10 . ",10";
		} // end if

		$comments = array();
		$query = "
			select t1.COMMENT_ID,t1.USER_ID,t1.COMMENT_BODY,t1.COMMENT_TIME,t2.USER_DISPLAY_NAME,t3.USER_AVATAR,t3.USER_AVATAR_WIDTH,t3.USER_AVATAR_HEIGHT
			from {$config['TABLE_PREFIX']}PROFILE_COMMENTS as t1,
			{$config['TABLE_PREFIX']}USERS as t2,
			{$config['TABLE_PREFIX']}USER_PROFILE as t3
			where t1.PROFILE_ID = ?
			and t1.USER_ID = t2.USER_ID
			and t1.USER_ID = t3.USER_ID
			order by COMMENT_ID desc
			limit $limit
		";
		$sth = $dbh->do_placeholder_query($query,array($User),__LINE__,__FILE__);
		while(list($c_id,$c_uid,$c_body,$c_time,$c_dname,$c_avatar,$c_width,$c_height) = $dbh->fetch_array($sth)) {
	
			if (!$c_avatar) {
				$c_avatar = $stockPicture;
				$c_width = $stockWidth;
				$c_height = $stockHeight;
			}
			if ($width && $height) {
				$picsize = "width=\"$c_width\" height=\"$c_height\"";
			} else {
				$picsize = "width=\"{$config['AVATAR_MAX_WIDTH']}\" height=\"{$config['AVATAR_MAX_HEIGHT']}\"";
			} // end if
	
			$edit = 0;
			if ($c_uid == $user['USER_ID'] || $user['USER_MEMBERSHIP_LEVEL'] == "Administrator") {
				$edit = 1;
			} // end if
			$delete = 0;
			if ($User == $user['USER_ID']) {
				$delete = 1;
			} // end if
	
			$comments[] = array(
				"id" => $c_id,
				"uid" => $c_uid,
				"body" => $c_body,
				"delete" => $delete,
				"edit" => $edit,
				"time" => $html -> convert_time($c_time,$toffset,$user['USER_TIME_FORMAT']),
				"username" => $c_dname,
				"avatar" => $c_avatar,
				"picsize" => $picsize,
			);
		} // end while
	}
	
	// Can they leave comments
	$post_comment = false;
	if ($userob->is_logged_in && $user['USER_ID'] != $User && $user['USER_TOTAL_POSTS'] >= $config['COMMENTS_MIN_POST']) {
		$post_comment = true;
	} // end if

	$smarty_data = array(
		"groupimages" => $groupimages,
		"profileuser" => $profileuser,
		"comments" => $comments,
		"md5" => $md5_stamp,
		"Fakeemail" => $Fakeemail,
		"Picture" => $Picture,
		"width" => $width,
		"height" => $height,
		"User" => $User,
		"Title" => $titleline,
		"Totalposts" => $Totalposts,
		"Rating" => $Rating,
		"birthday" => $birthday,
		"Homepage" => $Homepage,
		"Occupation" => $Occupation,
		"Hobbies" => $Hobbies,
		"Location" => $Location,
		"icq" => $icq,
		"yahoo" => $yahoo,
		"msn" => $msn,
		"aim" => $aim,
		"CUSTOM_FIELD_1" => $CUSTOM_FIELD_1,
		"CUSTOM_FIELD_2" => $CUSTOM_FIELD_2,
		"CUSTOM_FIELD_3" => $CUSTOM_FIELD_3,
		"CUSTOM_FIELD_4" => $CUSTOM_FIELD_4,
		"CUSTOM_FIELD_5" => $CUSTOM_FIELD_5,
		"date" => $date,
		"ratinghtml" => $ratinghtml,
		"privlinkstart" => $privlinkstart,
		"privlinkstop" => $privlinkstop,
		"useredit" => $useredit,
		"addresslink" => $addresslink,
		"ignorelinkstart" => $ignorelinkstart,
		"ignoretext" => $ignoretext,
		"ignorelinkstop" => $ignorelinkstop,
		"fav_user_link" => $fav_user_link,
		"signature" => $Signature,
		"sig_title" => $html->substitute($ubbt_lang['SIGNATURE'], array('USERNAME' => $profileuser)),
		"mood" => $mood,
		"mood_alt" => $mood_alt,
		"buddies" => $buddies,
		"text_editor" => $text_editor,
		"post_comment" => $post_comment,
		"pages" => $pages,
	);
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	return array(
		"header" => array (
			"title" => "{$ubbt_lang['PROF_FOR']} $profileuser",
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 {$ubbt_lang['PROF_FOR']} $profileuser
BREADCRUMB
			,
			"javascript" => array(
				0 => "standard_text_editor.js",
				1 => "image.js",
			),
		),
		"template" => "showprofile",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
