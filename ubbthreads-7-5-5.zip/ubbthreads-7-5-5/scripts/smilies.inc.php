<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;
define('NO_WRAPPER',1);
function page_smilies_gpc () {
	return array(
		"input" => array(
			"name" => array("name","get"),
		),
		"wordlets" => array("smilies"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_smilies_gpc

function page_smilies_run () {

	global $style_array,$user,$in,$ubbt_lang,$config,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$html->get_graemlins();

	$smarty_data = array();
		
	$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";
	
	// --------------------------------------------------
	// We need to grab all of the graemlins out of the db
	$query = "
		SELECT GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE
		FROM {$config['TABLE_PREFIX']}GRAEMLINS
		WHERE GRAEMLIN_IS_ACTIVE='1'
	";
	$sth = $dbh -> do_query($query,__LINE__,__FILE__);
	$i=0;
	$graemlinlist="";
	$altcode = "";
	foreach ($html->graemlins as $graemlin) {
		$code = $graemlin['GRAEMLIN_MARKUP_CODE'];
		$smiley = $graemlin['GRAEMLIN_SMILEY_CODE'];
		$image = $graemlin['GRAEMLIN_IMAGE'];
		if (stristr("$code","$")) {
			@eval("\$code = $code;");
		}
		$code = ":$code:";
		$altcode = "$code";
		if ($smiley) {
			$code = $smiley;
			$altcode .= "     $smiley";
		}
		$graemlinlist .= <<<EOF
			<img onclick="insertAtCaret(goal, ' $code'); goal.focus();" src="{$config['BASE_URL']}/images/{$style_array['graemlins']}/$image" border="0" alt="$altcode" title="$altcode" style="cursor: pointer;" /> 
EOF;
		$i++;

	}
	
	$smarty_data = array(
		"graemlinlist" => $graemlinlist,
		"stylesheet" => $stylesheet,
		"name" => $name,
	);

	return array(
		"header" => array (
			"title" => $ubbt_lang['SMILIES'],
			"refresh" => 0,
			"user" => $user,
			"Board" => $Board,
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => "",
		),
		"template" => "smiley_markup",
		"data" => & $smarty_data,
		"footer" => false,
		"location" => "",
	);
	
}

?>
