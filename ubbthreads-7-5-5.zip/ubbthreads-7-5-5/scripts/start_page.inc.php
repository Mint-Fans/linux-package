<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_start_page_gpc () {
	return array(
		"input" => array(
			"Loginname" => array("Loginname","post",""),
			"Loginpass" => array("Loginpass","post",""),
			"firstlogin" => array("firstlogin","post",""),
			"buttlogin" => array("buttlogin","post",""),
			"Email" => array("Email","post",""),
			"ON_COMPLETION_URL" => array("ON_COMPLETION_URL","post",""),
			"buttforgot" => array("buttforgot","post",""),
			"rememberme" => array("rememberme","post",""),
			"from" => array("from","post",""),
		),
		"wordlets" => array("start_page"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_start_page_gpc

function page_start_page_run () {

	global $user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// -------------------
	// Where are we going?
	$Username = $Loginname;
	$Password = $Loginpass;

	if ($buttforgot) {
		return mail_password($Username,$Email);
	}
	elseif ($buttlogin) {
		return $html -> do_login ($Username,$Password,$rememberme,$from,$in['ON_COMPLETION_URL']);
	}
	else {
		$html -> not_right($ubbt_lang['ALL_FIELDS']);
	}

}

// ########################################################################
// mail_password function - Mails a password to a given email address
// ########################################################################

function mail_password($Username="",$Email="") {

	global $dbh, $config, $ubbt_lang, $html;

	$ip = find_environmental('REMOTE_ADDR');

	$checkemail = $Email;
	$checkname = $Username;

	$x_query = "";
	$query_vars = array();
	if ($Username) {
		$x_query = "and t1.USER_LOGIN_NAME = ?";
		$query_vars = array($Username);
	} elseif ($Email) {
		$x_query = "and t2.USER_REAL_EMAIL = ?";
		$query_vars = array($Email);
	}  else {
		// No input?
	}


	if ($Email || $Username) {
		$query = "
			SELECT t1.USER_LOGIN_NAME, t2.USER_REAL_EMAIL, t1.USER_ID, t1.USER_DISPLAY_NAME, t2.USER_LANGUAGE
				FROM {$config['TABLE_PREFIX']}USERS as t1,
						 {$config['TABLE_PREFIX']}USER_PROFILE as t2
			WHERE t1.USER_ID = t2.USER_ID
			$x_query
		";
		$sth = $dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
		list($Username,$Email,$Uid,$Displayname,$Userlang) = $dbh -> fetch_array($sth);
	}

	// --------------------------------------------------------------
	// If we found an email address then we mail the password to them
	if ($Email) {
		// -------------------
		// Generate a password
		$a = time();
		mt_srand($a);
		$passset = array('a','b','c','d','e','f','g','h','i','j','k','m','n','o','p','q','r','s','t','u','v','x','y','z','A','B','C','D','E','F','G','H','I','J','K','M','N','P','Q','R','S','T','U','V','W','X','Y','Z','2','3','4','5','6','7','8','9');
		$chars = sizeof($passset);
		$pass = "";
		for ($i=0; $i < 6; $i++) {
			$randnum = intval(mt_rand(0,$chars))    ;
			$pass .= $passset[$randnum];
		}

		// ----------------------------
		// Now let's crypt the password
		$crypt = md5($pass);

		// -----------------------------
		// Now let's update the database
		$query = "
		UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
			 SET USER_TEMPORARY_PASSWORD = ?
		WHERE  USER_ID = ?
		";
		$dbh -> do_placeholder_query($query,array($crypt,$Uid),__LINE__,__FILE__);

		// -----------------------
		// Now we mail it to them
		$mailer = new mailer();
		$mailer->set_language($Userlang);
		$mailer->set_subject('PREQ_SUBJECT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
		$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $Displayname));
		$mailer->add_content('PREQ_CONTENT', array('IP_ADDY' => $ip, 'USERNAME' => $Username,	'BOARD_TITLE' => $config['COMMUNITY_TITLE']));
		$mailer->add_content('PREQ_CONTENT1');
		$mailer->add_content('PREQ_CONTENT2', array('PASSWORD' => $pass));
		$mailer->ubbt_mail($Email);

		// ---------------------------
		// Let them know it was mailed
		$cfrm = make_ubb_url("ubb=cfrm", "", false);
		$html->send_redirect(
			array(
				"redirect" => "",
				"heading" => $ubbt_lang['PASS_MAILED'],
				"body" => $ubbt_lang['PASS_MAILED'],
				"returnlink" => "",
				"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 {$ubbt_lang['PASS_MAILED']}
BREADCRUMB
				,
			)
		);
	}
	else {

		// --------------------------------------------------------------
		// We couldn't find the email address so we need to let them know
		if ($Email) {
			$html -> not_right("{$ubbt_lang['NO_EMAIL']} $checkemail");
		} else {
			$html -> not_right("{$ubbt_lang['NO_USERNAME']} $checkname");
		} // end if

	}

}

// END OF THE mail_password function

?>