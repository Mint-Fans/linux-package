<?php

//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_subscription_confirm_gpc () {
	return array(
		"input" => array(
			"id" => array("id","post","int"),
			"method" => array("method","post","alpha"),
			"payment" => array("payment","post","alpha"),
		),
		"wordlets" => array("subscriptions"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_subscription_confirm_gpc

function page_subscription_confirm_run () {

	global $style_array,$smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html,$userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	if (!$payment) {
		$html->not_right($ubbt_lang['NO_METHOD']);
	} // end if

	$query = "
		select SUBSCRIPTION_NAME,SUBSCRIPTION_DESCRIPTION,SUBSCRIPTION_BY_DONATION,SUBSCRIPTION_DONATION_AMOUNT,SUBSCRIPTION_BY_TRIAL,SUBSCRIPTION_TRIAL_AMOUNT,SUBSCRIPTION_TRIAL_DURATION,SUBSCRIPTION_TRIAL_INTERVAL,SUBSCRIPTION_BY_REGULAR,SUBSCRIPTION_REGULAR_AMOUNT,SUBSCRIPTION_REGULAR_DURATION,SUBSCRIPTION_REGULAR_INTERVAL,SUBSCRIPTION_IS_RECURRING,SUBSCRIPTION_REATTEMPT
		from {$config['TABLE_PREFIX']}SUBSCRIPTIONS
		where GROUP_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($id),__LINE__,__FILE__);
	list($name,$desc,$donation,$d_amount,$trial,$trial_amount,$trial_duration,$trial_interval,$regular,$regular_amount,$regular_duration,$regular_interval,$recurr,$reattempt) = $dbh->fetch_array($sth);

	if (!$donation && !$regular) {
		$html->not_right($ubbt_lang['NOT_ENABLED']);
	} // end if

	$donation_amount = "";
	if ($d_amount == "0.00" || $d_amount == "") {
		$d_amount = $html->substitute($ubbt_lang['CONFIRM_D_AMOUNT'], array('CURRENCY' => $ubbt_lang['ANY'],'AMOUNT' => $ubbt_lang['AMOUNT']));
		$donation_amount = "";
	} else {
		$donation_amount = $d_amount;
		$d_amount = $html->substitute($ubbt_lang['CONFIRM_D_AMOUNT'], array('CURRENCY' => $ubbt_lang[$config['CURRENCY']],'AMOUNT' => $d_amount));
	} // end if

	$check_mo = 0;
	if ($config['ALLOW_MAIL'] != "no_check_mo") {
		$check_mo = 1;
		$check_mo_text = $ubbt_lang[strtoupper($config['ALLOW_MAIL'])];
	}

	$start_date = $html->get_date(); 
	$end_date = $html->get_date();

	// If paying by check, we haven't started yet.
	if ($payment == "check") {
		$start_date = 0;
		$end_date = 0;
	}

	$trial_string = "";
	if ($trial && $payment != "check") {
		$period = $trial_duration;
		if ($trial_interval == "D") {
			$end_date = $end_date + (86400 * $trial_duration);
			$period .= " {$ubbt_lang['DAY']}";
		} // end if
		if ($trial_interval == "W") {
			$end_date = $end_date + (86400 * ($trial_duration * 7));
			$period .= " {$ubbt_lang['WEEK']}";
		} // end if
		if ($trial_interval == "M") {
			$end_date = $end_date + (86400 * ($trial_duration * 30));
			$period .= " {$ubbt_lang['MONTH']}";
		} // end if
		if ($trial_interval == "Y") {
			$end_date = $end_date + (86400 * ($trial_duration * 365));
			$period .= " {$ubbt_lang['YEAR']}";
		} // end if
		$trial_string = $html->substitute($ubbt_lang['TRIAL_PERIOD'], array('PERIOD' => $period, 'CURRENCY' => $ubbt_lang[$config['CURRENCY']], 'AMOUNT' => $trial_amount));
	} // end if

		$regular_string = "";
	if ($regular) {
		if ($recurr) $recurring = $ubbt_lang['RECURRING'];
		$period = $regular_duration;
		if (regular_duration == 1) {
			if ($regular_interval == "D") $period .= " {$ubbt_lang['DAY']}";
			if ($regular_interval == "W") $period .= " {$ubbt_lang['WEEK']}";
			if ($regular_interval == "M") $period .= " {$ubbt_lang['MONTH']}";
			if ($regular_interval == "Y") $period .= " {$ubbt_lang['YEAR']}";
		} else {
			if ($regular_interval == "D") $period .= " {$ubbt_lang['DAYS']}";
			if ($regular_interval == "W") $period .= " {$ubbt_lang['WEEKS']}";
			if ($regular_interval == "M") $period .= " {$ubbt_lang['MONTHS']}";
			if ($regular_interval == "Y") $period .= " {$ubbt_lang['YEARS']}";
		} // end if

		$regular_string = $html->substitute($ubbt_lang['REGULAR_PERIOD'], array('CURRENCY' => $ubbt_lang[$config['CURRENCY']],'AMOUNT' => $regular_amount,'PERIOD' => $period,'RECURRING' => $recurring));
	} // end if

	if ($method == "donate") {
		$start_date = $html->get_date();
		$end_date = 0;
		$order_type = $ubbt_lang['DONATION'];
	} else {
		$order_type = $ubbt_lang['BY_SUB'];
	} // end if

	$mystuff = $html->mystuff($user['USER_ID']);

	if ($payment == "paypal") {
		$payment_string = $ubbt_lang['PAYPAL'];
	} else {
		if ($config['ALLOW_MAIL'] == "check") {
			$payment_string = $ubbt_lang['CHECK'];
		} elseif ($config['ALLOW_MAIL'] == "mo") {
			$payment_string = $ubbt_lang['MO'];
		} elseif ($config['ALLOW_MAIL'] == "check_mo") {
			$payment_string = $ubbt_lang['CHECK_MO'];
		} // end if 
	} // end if

	// Insert this into the Subscription Data table as a PENDING
	// transaction
	$custom = md5($user['USER_ID'] . time());
	$query_vars = array($user['USER_ID'],$id,'PENDING',$start_date,$end_date,$custom,$payment,$method,$html->get_date());
	$query = "
		replace into {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA
		(USER_ID,GROUP_ID,SUBSCRIPTION_STATUS,SUBSCRIPTION_START_DATE,SUBSCRIPTION_END_DATE,CUSTOM_ID,SUBSCRIPTION_PAYMENT,SUBSCRIPTION_METHOD,SUBSCRIPTION_CREATED)
		values
		( ? , ? , ? , ? , ? , ? , ? , ? , ? )
	";
	$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

	$invoice = $dbh->last_insert_id(__LINE__,__FILE__);

	$smarty_data = array(
		"id" => $id,
		"name" => $name,
		"desc" => $desc,
		"order_type" => $order_type,
		"donation" => $donation,
		"d_amount" => $d_amount,
		"check_mo" => $check_mo,
		"check_mo_text" => $check_mo_text,
		"regular" => $regular,
		"trial" => $trial,
		"trial_string" => $trial_string,
		"regular_string" => $regular_string,
		"method" => $method,
		"payment" => $payment,
		"mystuff" => $mystuff,
		"payment_string" => $payment_string,
		"trial_interval" => $trial_interval,
		"trial_duration" => $trial_duration,
		"trial_amount" => $trial_amount,
		"regular_interval" => $regular_interval,
		"regular_duration" => $regular_duration,
		"regular_amount" => $regular_amount,
		"recurr" => $recurr,
		"reattempt" => $reattempt,
		"donation_amount" => $donation_amount,
		"invoice" => $invoice,
		"custom" => $custom,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$subs = make_ubb_url("ubb=subscriptions", "", false);

	return array(
		"header" => array (
		"title" => $ubbt_lang['SUB_CONFIRM'],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 <a href="{$subs}">{$ubbt_lang['MY_SUBS']}</a>
 &raquo;
 {$ubbt_lang['SUB_CONFIRM']}
BREADCRUMB
			,
		),
		"template" => "subscription_confirm",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
