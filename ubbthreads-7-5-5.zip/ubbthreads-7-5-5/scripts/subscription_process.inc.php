<?php

//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_subscription_process_gpc () {
	return array(
		"input" => array(
			"id" => array("id","post","int"),
			"method" => array("method","post","alpha"),
			"payment" => array("payment","post","alpha"),
			"cancel" => array("cancel","post",""),
			"invoice" => array("invoice","post","int"),
		),
		"wordlets" => array("subscriptions"),
		"user_fields" => "t1.USER_LOGIN_NAME",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_subscription_process_gpc

function page_subscription_process_run () {

	global $style_array,$smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html,$userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// Cancel this order
	if ($cancel) {

		$query = "
			delete from {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA
			where SUBSCRIPTION_ID = ?
		";
		$dbh->do_placeholder_query($query,array($invoice),__LINE__,__FILE__);

		$html->send_redirect(
			array(
				"redirect" => "subscriptions",
				"heading" => "{$ubbt_lang['CANCEL']}",
				"body" => "{$ubbt_lang['CANCEL_BODY']}",
				"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 {$ubbt_lang['CANCEL']}
BREADCRUMB
				,
			)
		);
		exit;
	} // end if

	// Make sure a payment type is specified
	if (!$payment) {
		$html->not_right($ubbt_lang['NO_METHOD']);
	} // end if

	$query = "
		select SUBSCRIPTION_NAME,SUBSCRIPTION_DESCRIPTION,SUBSCRIPTION_BY_DONATION,SUBSCRIPTION_DONATION_AMOUNT,SUBSCRIPTION_BY_TRIAL,SUBSCRIPTION_TRIAL_AMOUNT,SUBSCRIPTION_TRIAL_DURATION,SUBSCRIPTION_TRIAL_INTERVAL,SUBSCRIPTION_BY_REGULAR,SUBSCRIPTION_REGULAR_AMOUNT,SUBSCRIPTION_REGULAR_DURATION,SUBSCRIPTION_REGULAR_INTERVAL,SUBSCRIPTION_IS_RECURRING
		from {$config['TABLE_PREFIX']}SUBSCRIPTIONS
		where GROUP_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($id),__LINE__,__FILE__);
	list($name,$desc,$donation,$d_amount,$trial,$trial_amount,$trial_duration,$trial_interval,$regular,$regular_amount,$regular_duration,$regular_interval,$recurr) = $dbh->fetch_array($sth);

	// Make sure this group has an active subscription
	if (!$donation && !$regular) {
		$html->not_right($ubbt_lang['NOT_ENABLED']);
	} // end if

	$mystuff = $html->mystuff($user['USER_ID']);

/*
	if ($d_amount == "0.00") {
		$d_amount = $html->substitute($ubbt_lang['D_AMOUNT'], array('CURRENCY' => $ubbt_lang['ANY'],'AMOUNT' => $ubbt_lang['AMOUNT']));
	} else {
		$d_amount = $html->substitute($ubbt_lang['D_AMOUNT'], array('CURRENCY' => $ubbt_lang[$config['CURRENCY']],'AMOUNT' => $d_amount));
	} // end if

	$check_mo = 0;
	if ($config['ALLOW_MAIL'] != "no_check_mo") {
		$check_mo = 1;
		$check_mo_text = $ubbt_lang[strtoupper($config['ALLOW_MAIL'])];
	}

*/

	if ($method == "donate") {
		$order_type = $ubbt_lang['DONATION'];
	} else {
		$order_type = $ubbt_lang['BY_SUB'];
	} // end if

	// Order by Check or Money Order
	if ($payment == "check") {
		if ($config['ALLOW_MAIL'] == "check") {
			$allowed = $ubbt_lang['CHECK'];
		} elseif ($config['ALLOW_MAIL'] == "mo") {
			$allowed = $ubbt_lang['MO'];
		} elseif ($config['ALLOW_MAIL'] == "check_mo") {
			$allowed = $ubbt_lang['CHECK_MO'];
		} // end if

		if ($method == "donate") {
			if ($d_amount == "0.00" || !$d_amount) {
				$ins_string = $html->substitute($ubbt_lang['MAIL_INS_BODY'],array('CURRENCY' => "",'AMOUNT' => "{$ubbt_lang['ANY_AMOUNT']}",'PAYCURRENCY' => $ubbt_lang['PAY' . $config['CURRENCY']],'PAYMENT' => $allowed));
				$order_details = $html->substitute($ubbt_lang['CONFIRM_D_AMOUNT'],array('CURRENCY' => $ubbt_lang[$config['CURRENCY']],'AMOUNT' => '________.__'));
				$payment_amount = $html->substitute($ubbt_lang['PAYMENT_LINE'],array('CURRENCY' => $ubbt_lang[$config['CURRENCY']],'AMOUNT' => '________.__'));
			} else {
				$ins_string = $html->substitute($ubbt_lang['MAIL_INS_BODY'],array('CURRENCY' => $ubbt_lang[$config['CURRENCY']],'AMOUNT' => $d_amount,'PAYCURRENCY' => $ubbt_lang['PAY' . $config['CURRENCY']],'PAYMENT' => $allowed));
				$order_details = $html->substitute($ubbt_lang['CONFIRM_D_AMOUNT'],array('CURRENCY' => $ubbt_lang[$config['CURRENCY']],'AMOUNT' => $d_amount));
				$payment_amount = $html->substitute($ubbt_lang['PAYMENT_LINE'],array('CURRENCY' => $ubbt_lang[$config['CURRENCY']],'AMOUNT' => $d_amount));

			} // end if
		} else {

			$order_details = "";
			if ($trial) {
				$period = $trial_duration;
				if ($trial_interval == "D") $period .= " {$ubbt_lang['DAY']}";
				if ($trial_interval == "W") $period .= " {$ubbt_lang['WEEK']}";
				if ($trial_interval == "M") $period .= " {$ubbt_lang['MONTH']}";
				if ($trial_interval == "Y") $period .= " {$ubbt_lang['YEAR']}";
				$order_details = $html->substitute($ubbt_lang['TRIAL_PERIOD'], array('PERIOD' => $period, 'CURRENCY' => $ubbt_lang[$config['CURRENCY']], 'AMOUNT' => $trial_amount)) . "<br />";
			} // end if
		
			$regular_string = "";
			if ($regular) {
				if ($recurr) $recurring = $ubbt_lang['RECURRING'];
				$period = $regular_duration;
				if (regular_duration == 1) {
					if ($regular_interval == "D") $period .= " {$ubbt_lang['DAY']}";
					if ($regular_interval == "W") $period .= " {$ubbt_lang['WEEK']}";
					if ($regular_interval == "M") $period .= " {$ubbt_lang['MONTH']}";
					if ($regular_interval == "Y") $period .= " {$ubbt_lang['YEAR']}";
				} else {
					if ($regular_interval == "D") $period .= " {$ubbt_lang['DAYS']}";
					if ($regular_interval == "W") $period .= " {$ubbt_lang['WEEKS']}";
					if ($regular_interval == "M") $period .= " {$ubbt_lang['MONTHS']}";
					if ($regular_interval == "Y") $period .= " {$ubbt_lang['YEARS']}";
				} // end if
				$order_details .= $html->substitute($ubbt_lang['REGULAR_PERIOD'], array('CURRENCY' => $ubbt_lang[$config['CURRENCY']],'AMOUNT' => $regular_amount,'PERIOD' => $period,'RECURRING' => ''));
			} // end if

			$total_amount = $trial_amount + $regular_amount;
			$ins_string = $html->substitute($ubbt_lang['MAIL_INS_BODY'],array('CURRENCY' => $ubbt_lang[$config['CURRENCY']],'AMOUNT' => $total_amount,'PAYCURRENCY' => $ubbt_lang['PAY' . $config['CURRENCY']],'PAYMENT' => $allowed));
			$payment_amount = $html->substitute($ubbt_lang['PAYMENT_LINE'],array('CURRENCY' => $ubbt_lang[$config['CURRENCY']],'AMOUNT' => $total_amount));
		} // end if


		$address = nl2br($config['PAYMENT_ADDRESS']);

		if ($method == "donate") {
				$order_type = $ubbt_lang['DONATION'];
		} else {
				$order_type = $ubbt_lang['BY_SUB'];
		} // end if


		$smarty_data = array(
			"ins_string" => $ins_string,
			"mystuff" => $mystuff,
			"address" => $address,
			"login_name" => $user['USER_LOGIN_NAME'],
			"display_name" => $user['USER_DISPLAY_NAME'],
			"sub_name" => $name,
			"order_type" => $order_type,
			"order_details" => $order_details,
			"payment_amount" => $payment_amount,
		);

		$cfrm = make_ubb_url("ubb=cfrm", "", false);
		$subs = make_ubb_url("ubb=subscriptions", "", false);

		return array(
			"header" => array (
			"title" => $ubbt_lang['MAIL_INS'],
				"refresh" => 0,
				"user" => $user,
				"Board" => "",
				"bypass" => 0,
				"onload" => "",
				"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 <a href="{$subs}">{$ubbt_lang['MY_SUBS']}</a>
 &raquo;
 {$ubbt_lang['MAIL_INS']}
BREADCRUMB
				,
			),
			"template" => "subscription_mail",
			"data" => & $smarty_data,
			"footer" => true,
			"location" => "",
		);

	} // end if

/* OLD CODE

	$smarty_data = array(
		"id" => $id,
		"name" => $name,
		"desc" => $desc,
		"order_type" => $order_type,
		"donation" => $donation,
		"d_amount" => $d_amount,
		"check_mo" => $check_mo,
		"check_mo_text" => $check_mo_text,
		"regular" => $regular,
		"trial_string" => $trial_string,
		"regular_string" => $regular_string,
		"method" => $method,
		"payment" => $payment,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	$subs = make_ubb_url("ubb=subscriptions", "", false);

	return array(
		"header" => array (
		"title" => $ubbt_lang['SUB_CONFIRM'],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 <a href="{$subs}">{$ubbt_lang['MY_SUBS']}</a>
 &raquo;
 {$ubbt_lang['SUB_CONFIRM']}
BREADCRUMB
			,
		),
		"template" => "subscription_process",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

*/

}

?>
