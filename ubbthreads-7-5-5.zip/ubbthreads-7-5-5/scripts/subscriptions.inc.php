<?php

//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_subscriptions_gpc () {
	return array(
		"input" => array(),
		"wordlets" => array("subscriptions"),
		"user_fields" => "",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_subscriptions_gpc

function page_subscriptions_run () {

	global $style_array,$smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html,$userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$query = "
		select GROUP_ID,SUBSCRIPTION_NAME,SUBSCRIPTION_DESCRIPTION
		from {$config['TABLE_PREFIX']}SUBSCRIPTIONS
		where SUBSCRIPTION_BY_DONATION='1'
		or SUBSCRIPTION_BY_REGULAR='1'
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	$subs = array();
	$x=0;
	$color = "alt-1";
	while(list($gid,$sub_name,$sub_desc) = $dbh->fetch_array($sth)) {
		$subs[$x]['group'] = $gid;
		$subs[$x]['name'] = $sub_name;
		$subs[$x]['desc'] = $sub_desc;
		$subs[$x]['color'] = $color;
		$x++;
		$color = $html->switch_colors($color);
	} // end while

	if (!sizeof($subs)) {
		$nosubs = 1;
	}

	$query = "
		select t2.SUBSCRIPTION_NAME,t1.SUBSCRIPTION_END_DATE,t1.SUBSCRIPTION_STATUS,t1.SUBSCRIPTION_IS_ACTIVE,t2.SUBSCRIPTION_DONATION_AMOUNT,t2.SUBSCRIPTION_REGULAR_AMOUNT,t1.SUBSCRIPTION_METHOD
		from {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA as t1,
		{$config['TABLE_PREFIX']}SUBSCRIPTIONS as t2
		where USER_ID = ?
		and t1.GROUP_ID = t2.GROUP_ID
		order by SUBSCRIPTION_ID desc
	";
	$sth = $dbh->do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
	$color = "alt-1";
	while(list($sub_name,$sub_end,$sub_status,$sub_active,$d_amount,$r_amount,$method) = $dbh->fetch_array($sth)) {
		if ($sub_active == 1) {
			$sub_active = $ubbt_lang['TEXT_YES'];
		} else {
			$sub_active = $ubbt_lang['TEXT_NO'];
		} // end if

		if (!$sub_end) {
			$sub_end = $ubbt_lang['NO_END'];
		} else {
			$sub_end = $html->convert_time($sub_end);
		} // end if

		$current[] = array(
			"name" => $sub_name,
			"end" => $sub_end,
			"status" => $sub_status,
			"color" => $color,
			"active" => $sub_active,
		);
		$color = $html->switch_colors($color);
	} // end while

	$smarty_data = array(
		"field" => $value,
		"subs" => & $subs,
		"nosubs" => $nosubs,
		"mystuff" => $html->mystuff(),
		"current" => $current,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);

	return array(
		"header" => array (
		"title" => $ubbt_lang['MY_SUBS'],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 {$ubbt_lang['MY_SUBS']} 
BREADCRUMB
			,
		),
		"template" => "subscriptions",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
