<?php
//      Whoops!  If you see this text in your browser,
//      your web hosting provider has not installed PHP.
//
//      You will be unable to use UBB until PHP has been properly installed.
//
//      You may wish to ask your web hosting provider to install PHP.
//      Both Windows and Unix versions are available on the PHP website,
//      http://www.php.net/
//
//
//
//      Ultimate Bulletin Board
//      Script Version 7.5.5
//
//      Program authors: Rick Baker
//      Copyright (C) 2010 Mindraven.
//
//      You may not distribute this program in any manner, modified or
//      otherwise, without the express, written consent from
//      Mindraven.
//
//      You may make modifications, but only for your own use and
//      within the confines of the UBB License Agreement
//      (see our website for that).
//
//      Note: If you modify ANY code within your UBB, we at Mindraven
//  	cannot offer you support -- thus modify at your own peril :)

// 	Special Thanks to Ian Spence for the code/template and language
//	file for this feature.


if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_userposts_gpc () {
	return array(
		"input" => array(
			"view" => array( "view", "get", "alpha" ),
			"id" => array( "id", "get", "int" ),
			"page" => array( "page", "get", "int" ),
		),
		"wordlets" => array("userposts"),
		"user_fields" => "t2.USER_TIME_FORMAT, t2.USER_TOPICS_PER_PAGE",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_userposts_gpc

function page_userposts_run() {
	global $in, $config, $dbh, $ubbt_lang, $html, $userob, $user, $tree;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$config['USER_POSTS_MAX_TITLE'] = 25;

	// First, are we even looking at a valid user?
	$query = "
		SELECT	USER_DISPLAY_NAME, USER_ID
		FROM	{$config['TABLE_PREFIX']}USERS
		WHERE	USER_ID = $id
	";

	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	list($name, $temp_id) = $dbh->fetch_array($sth);

	if( ( $temp_id + 0 ) === 0 ) {
		$html->not_right( $ubbt_lang['INVALID_USER_SPECIFIED'] );
	}

 	if (!$page || $page < 1) $page = 1;
	$PostsPer = array_get($user, 'USER_TOPICS_PER_PAGE', $config['TOPICS_PER_PAGE']);

	// Next, get a list of all the forums they can access
	$userob->get_permissions($user['USER_ID']);
	$ok = array();

	foreach($tree['active'] as $k => $v) {
		if ($userob->check_access("forum","READ_TOPICS",$k)) {
			$ok[] = $k;
		}
	}

	$start = intval($page-1) * $PostsPer;

	// 2 views: All posts & Topics Started
	$query = "";
	$links = array();
	$count = 0;
	$key = "";
	$topics = array();

	switch($view) {
		case "started":
			$query = "
				SELECT COUNT(t1.TOPIC_ID)
				FROM	{$config['TABLE_PREFIX']}TOPICS as t1,
					{$config['TABLE_PREFIX']}FORUMS as t2,
					{$config['TABLE_PREFIX']}POSTS as t3
				WHERE	t1.USER_ID = ? AND t1.FORUM_ID = t2.FORUM_ID AND t2.FORUM_ID in ( ? )
					AND t3.POST_IS_APPROVED = '1' AND t3.POST_ID = t1.POST_ID AND t2.FORUM_IS_ACTIVE = '1'
			";
			$sth = $dbh->do_placeholder_query( $query, array($id, $ok), __LINE__, __FILE__ );
			list( $count ) = $dbh->fetch_array( $sth );

			$query = "
				SELECT	t1.POST_ID, t1.TOPIC_ID, t1.TOPIC_SUBJECT AS TITLE, t1.TOPIC_CREATED_TIME AS TIME, t1.TOPIC_REPLIES,
					t2.FORUM_ID, t2.FORUM_TITLE
				FROM	{$config['TABLE_PREFIX']}TOPICS as t1,
					{$config['TABLE_PREFIX']}FORUMS as t2,
					{$config['TABLE_PREFIX']}POSTS as t3
				WHERE	t1.USER_ID = ? AND t1.FORUM_ID = t2.FORUM_ID AND t2.FORUM_ID in ( ? )
					AND t3.POST_IS_APPROVED = '1' AND t3.POST_ID = t1.POST_ID AND t2.FORUM_IS_ACTIVE = '1'
				ORDER BY t1.TOPIC_CREATED_TIME DESC
				LIMIT $start, $PostsPer
			";

			$links = array(
				$ubbt_lang['TOPIC_CREATED'],
				'<a href="' . make_ubb_url( "ubb=userposts&id=$id&view=posts", false ) . '">' . $ubbt_lang['ALL_POSTS'] . '</a>',
			);

			$key = 'TOPIC_CREATED';

			break;
		default:
			$view = 'posts';
			$query = "
				SELECT	COUNT(t3.POST_ID)
				FROM	{$config['TABLE_PREFIX']}TOPICS as t1,
					{$config['TABLE_PREFIX']}FORUMS as t2,
					{$config['TABLE_PREFIX']}POSTS as t3
				WHERE	t3.USER_ID = ? AND t3.TOPIC_ID = t1.TOPIC_ID
					AND t1.FORUM_ID = t2.FORUM_ID AND t2.FORUM_ID in ( ? )
					AND t3.POST_IS_APPROVED = '1' AND t2.FORUM_IS_ACTIVE = '1'
				ORDER BY t3.POST_POSTED_TIME DESC
			";
			$sth = $dbh->do_placeholder_query( $query, array($id, $ok), __LINE__, __FILE__ );
			list( $count ) = $dbh->fetch_array( $sth );

			$query = "
				SELECT	t3.POST_ID, t1.TOPIC_ID, t3.POST_SUBJECT AS TITLE, t3.POST_POSTED_TIME AS TIME, t1.TOPIC_REPLIES,
					t2.FORUM_ID, t2.FORUM_TITLE
				FROM	{$config['TABLE_PREFIX']}TOPICS as t1,
					{$config['TABLE_PREFIX']}FORUMS as t2,
					{$config['TABLE_PREFIX']}POSTS as t3
				WHERE	t3.USER_ID = ? AND t3.TOPIC_ID = t1.TOPIC_ID
					AND t1.FORUM_ID = t2.FORUM_ID AND t2.FORUM_ID in ( ? )
					AND t3.POST_IS_APPROVED = '1' AND t2.FORUM_IS_ACTIVE = '1'
				ORDER BY t3.POST_POSTED_TIME DESC
				LIMIT $start, $PostsPer
			";

			$links = array(
				'<a href="' . make_ubb_url( "ubb=userposts&view=started&id=$id", false ) . '">' . $ubbt_lang['TOPIC_CREATED'] . '</a>',
				$ubbt_lang['ALL_POSTS'],
			);

			$key = 'ALL_POSTS';
	}

	if( $query != "" ) {
		$sth = $dbh->do_placeholder_query( $query, array($id, $ok), __LINE__, __FILE__ );
		$x = 0;
		while( $result = $dbh->fetch_array( $sth ) ) {
			$x++;
			$result['TIME'] = $html->convert_time( $result['TIME'], $user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT'] );
			if( strlen( $result['TITLE'] ) > $config['USER_POSTS_MAX_TITLE'] ) {
				$result['FULL_SUBJECT'] = $result['TITLE'];
				$result['TOPIC_SUBJECT'] = substr( $result['TITLE'], 0, $config['USER_POSTS_MAX_TITLE'] ) . '...';
			}
			$result['color'] = ($x&1) ? "alt-topicsubject" : "topicsubject";
			$topics[] = $result;
		}
	}

	$title = $html->substitute($ubbt_lang[$key . "_2"],array('NAME' => $name));

	$smarty_data = array(
		"topics" => &$topics,
		"title" =>  $title,
		"links" => implode( ' | ', $links ),
		"pages" => $html->paginate($page, ceil( $count / $PostsPer), "userposts&id=$id&view=$view&page="),
		"error" => $ubbt_lang[$key . "_NO_RESULTS"],
		"mystuff" => $html->mystuff(),
		"itsme" => ($id == $user['USER_ID']) ? 1 : 0,
	);

	$cfrm = make_ubb_url("ubb=cfrm", "", false);

	return array(
		"header" => array (
			"title" => $title,
			"refresh" => 0,
			"user" => "",
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a> &raquo; {$title}
BREADCRUMB
			,
		),
		"template" => "userposts",
		"data" => &$smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>
