<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_verifyemail_gpc () {
	return array(
		"input" => array(
			"verify" => array("verify","get",""),
			"em" => array("em","get",""),
		),
		"wordlets" => array("verifyemail"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_verifyemail_gpc

function page_verifyemail_run () {

	global $smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$mailer  = new mailer;

	// Verifying a new account
	if (!$em) {
		// ------------------------------------
		// Grab their uid and registration time
		$uid = ""; $key = "";
		if (stristr($verify,"-")) {
			list($uid,$key) = explode("-",$verify);
		}

		// ----------------------
		// Now verify the account
		$update = "yes";
		$query = "
		SELECT USER_DISPLAY_NAME,USER_IS_UNDERAGE,USER_REGISTRATION_IP,USER_REGISTRATION_EMAIL
		FROM {$config['TABLE_PREFIX']}USERS
		WHERE  USER_ID = ?
		AND    USER_IS_APPROVED = ?
		";
		$sth = $dbh -> do_placeholder_query($query,array($uid,$key),__LINE__,__FILE__);
		list ($newusername,$coppauser,$regip,$regemail) = $dbh -> fetch_array($sth);
		if (!$newusername) {
			$html -> not_right($ubbt_lang['UNABLE']);
		}
	
		if ($config['NEW_USER_MODERATION'] || $coppauser) {
			$update = 'no';
		}
	
		$query = "
		UPDATE {$config['TABLE_PREFIX']}USERS
		SET    USER_IS_APPROVED = ?
		WHERE  USER_ID = ?
		";
		$dbh -> do_placeholder_query($query,array($update,$uid),__LINE__,__FILE__);
	
		// -------------------------------------------------------------------------
		// Send out an email only to admins who want to receive them for new signups
		$query = "
			SELECT up.USER_REAL_EMAIL, up.USER_NOTIFY_NEW_USER, up.USER_LANGUAGE, u.USER_DISPLAY_NAME
			FROM  {$config['TABLE_PREFIX']}USER_PROFILE up,
						{$config['TABLE_PREFIX']}USERS u
			WHERE	u.USER_MEMBERSHIP_LEVEL = 'Administrator'
				AND	up.USER_ID = u.USER_ID
				AND up.USER_NOTIFY_NEW_USER = '1'
		";
		$sth = $dbh -> do_query($query,__LINE__,__FILE__);
	
		$mailer = new mailer();
		while(list($adminemail,$notify_newuser,$lang,$username) = $dbh -> fetch_array($sth)) {
			if (!$adminemail) continue;
	
			$mailer->set_language($lang);
			$mailer->set_subject('REGN_SUBJECT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
			$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $username));
			$subs = array(
				'EMAIL_ADDY' => $regemail,
				'DISPLAY_NAME' => $newusername,
				'IP_ADDY' => $regip);
			$mailer->add_content('REGN_CONTENT', $subs);
			// Tell them they need to moderate or just be informative
			if ($config['NEW_USER_MODERATION']) {
				$mailer->add_content('REGN_CONTENT1');
				$mailer->add_content('REGN_CONTENT2',array('MANAGE_URL' => "{$config['FULL_URL']}/admin/membermanage.php?returntab=1"),true);
			}
			else {
				$mailer->add_content('REGN_CONTENT3');
			}
			$mailer -> ubbt_mail($adminemail);
		}
	
		// ------------------------
		// Send them a confirmation
		$delay = 2;
		if ($coppauser) {
			$printer = $html->substitute($ubbt_lang['PARENT_FORM'], array('COPPA_URL' => make_ubb_url("ubb=coppaform", "", true)));
		}
		elseif ($config['NEW_USER_MODERATION']) {
			$delay = 10;
			$printer = $ubbt_lang['NEEDAPPROVAL'];
		}
		else {
			$printer = $ubbt_lang['NORMAL'];
		}
		$cfrm = make_ubb_url("ubb=cfrm");
		$html->send_redirect(
			array(
				"redirect" => "login",
				"heading" => $ubbt_lang['VERIFIED'],
				"body" => $printer,
				"returnlink" => "",
				"delay" => $delay,
				"breadcrumb" => <<<BREADCRUMB
	<a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
	&raquo;
	{$ubbt_lang['VERIFIED']}
BREADCRUMB
				,
			)
		);
	} else {

		$uid = ""; $key = "";
		if (stristr($verify,"-")) {
			list($uid,$key) = explode("-",$verify);
		}
		$query = "
			select t1.USER_REGISTERED_ON,t2.USER_UNVERIFIED_EMAIL
			from {$config['TABLE_PREFIX']}USERS as t1,
			{$config['TABLE_PREFIX']}USER_PROFILE as t2
			where t1.USER_ID = ?
			and t1.USER_ID = t2.USER_ID
		";
		$sth=$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
		list($reged,$unverified) = $dbh->fetch_array($sth);
		if (md5("$reged$unverified") != $key) {
			$html->not_right($ubbt_lang['NO_EMAIL']);
			exit;
		}

		$query = "
			update {$config['TABLE_PREFIX']}USER_PROFILE
			set USER_REAL_EMAIL = ?,
			    USER_UNVERIFIED_EMAIL = ''
			where USER_ID = ?
		";
		$dbh->do_placeholder_query($query,array($unverified,$uid),__LINE__,__FILE__);

		// We are verifying a new email
		$html->send_redirect(
			array(
				"redirect" => "cfrm",
				"heading" => $ubbt_lang['VERIFIED'],
				"body" => $html->substitute($ubbt_lang['EMAIL_VERIFIED'],array('EMAIL' => $unverified)),
				"returnlink" => "",
				"delay" => 5,
				"breadcrumb" => <<<BREADCRUMB
	<a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
	&raquo;
	{$ubbt_lang['VERIFIED']}
BREADCRUMB
				,
			)
		);
	} 
}	
?>
