<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_viewmessage_gpc () {
	return array(
		"input" => array(
			"message" => array("message","get","int"),
			"page"    => array("page","get","int"),
			"gonew"	=> array("gonew","get","int"),
			"jump" => array("jump","get","int"),
		),
		"wordlets" => array("viewmessage"),
		"user_fields" => "t2.USER_TIME_FORMAT, t2.USER_IGNORE_LIST, t2.USER_POST_LAYOUT, t2.USER_TOPICS_PER_PAGE, t2.USER_POSTS_PER_TOPIC",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_viewmessage_gpc

function page_viewmessage_run () {

	global $smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html,$style_array,$userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$limit = array_get($user, 'USER_POSTS_PER_TOPIC', $config['POSTS_PER_PAGE']);
	if (!$limit) $limit = 25;

	$post_layout = $user['USER_POST_LAYOUT'];
	if (!$post_layout) $post_layout = $config['POST_LAYOUT'];

	$toffset = "";
	isset($user['USER_TIME_OFFSET']) && $toffset = $user['USER_TIME_OFFSET'];
	!isset($user['USER_TIME_FORMAT']) && $user['USER_TIME_FORMAT'] = $config['TIME_FORMAT'];

	// Make sure they are in this topic
	$query = "
		select	t1.USER_ID,t1.MESSAGE_LAST_READ,t2.USER_DISPLAY_NAME
		from	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS as t1,
			{$config['TABLE_PREFIX']}USERS as t2
		where	t1.TOPIC_ID = ?
		and	t1.USER_ID = t2.USER_ID
	";
	$sth = $dbh->do_placeholder_query($query,array($message),__LINE__,__FILE__);
	$participants = array();
	$last_visit = 0;
	$participant_list = array();
	$found = false;
	while(list($user_id,$last_read,$uname) = $dbh->fetch_array($sth)) {
		if ($user_id == $user['USER_ID']) {
			$mylastread = $last_read;
			$found = true;
		} // end if
		$participant_list[] = array(
			"name" =>$uname,
			"id" => $user_id,
		);
		$participants[$last_read][] = $uname;
		if ($user_id == $user['USER_ID']) {
			$last_visit = $last_read;
		}
	}

	if ($found == false) {
		$html->not_right("{$ubbt_lang['NO_PT']}");
	} // end if

	if (!$page) {
		$page = 1;
	}

	// If jump is set then we need to figure out what page to send them to
	if ($jump) {
		$query = "
			select count(*)
			from {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
			where TOPIC_ID = ?
			and POST_ID < ?
		";
		$sth = $dbh->do_placeholder_query($query,array($message,$jump),__LINE__,__FILE__);
		list($previous) = $dbh->fetch_array($sth);
		$page = intval($previous/ $limit) + 1;
	} // end if

	// If gonew is set we need to figure out what page to send them to
	if ($gonew) {
		$query = "
			select count(*)
			from {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
			where TOPIC_ID = ?
			and POST_TIME < ?
		";
		$sth = $dbh->do_placeholder_query($query,array($message,$mylastread),__LINE__,__FILE__);
		list($previous) = $dbh->fetch_array($sth);
		$page = intval(($previous - 1)/ $limit) + 1;
	}

	$query = "
		select count(*)
		from	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
		where	TOPIC_ID = ?
	";
	$sth = $dbh -> do_placeholder_query($query,array($message),__LINE__,__FILE__);
	list($total) = $dbh->fetch_array( $sth );

    // What's the PM length limit?
	$mytotal = $userob->check_access("site","PM_LENGTH");                      

	$toolong = 0;
	if ($total >= $mytotal) {
		$toolong = $html->substitute($ubbt_lang['TOO_LONG'],array('TOTAL' => $mytotal));
	} // end if


	$pages1 = $html->paginate( $page ? $page : 1, ceil( $total / $limit ), "viewmessage&message=$message&page=" );
	$pages2 = preg_replace('#pagination_\d+#', '', $page1);

	if( $page > 0 ) {
		$new_page = ( $page - 1 ) * $limit;
	} else {
		$new_page = 0;
	}

	$watch_lists = @unserialize($_SESSION['watch_lists']);
	if (!is_array($watch_lists['u'])) $watch_lists['u'] = array();
	if (!is_array($watch_lists['t'])) $watch_lists['t'] = array();

	// -------------------------------------------------
	// Get the message(s) in this post from the database
	$query = "
		SELECT	p.POST_ID, t.TOPIC_SUBJECT, p.USER_ID, p.POST_BODY, p.POST_TIME, u.USER_DISPLAY_NAME,
			up.USER_TITLE, up.USER_RATING, up.USER_AVATAR, up.USER_AVATAR_WIDTH, up.USER_AVATAR_HEIGHT,
			u.USER_REGISTERED_ON, up.USER_TOTAL_POSTS, up.USER_LOCATION, up.USER_SIGNATURE,
			up.USER_CUSTOM_TITLE, up.USER_ACCEPT_PM, up.USER_HOMEPAGE, up.USER_VISIBLE_ONLINE_STATUS,
			up.USER_MOOD, up.USER_NAME_COLOR,u.USER_MEMBERSHIP_LEVEL,up.USER_GROUP_IMAGES
		FROM	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS p,
			{$config['TABLE_PREFIX']}USERS u,
			{$config['TABLE_PREFIX']}USER_PROFILE up,
			{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS t
		WHERE	p.TOPIC_ID = ?
			AND	p.TOPIC_ID = t.TOPIC_ID
			AND	p.USER_ID = u.USER_ID
			AND	u.USER_ID = up.USER_ID
		ORDER BY p.POST_TIME
		LIMIT $new_page, $limit
	";
	$sth = $dbh->do_placeholder_query($query,array($message),__LINE__,__FILE__);

	$postrow = array();
	$i = 0;
	$last_post = 0;

	// Keep track of all users on this page
	$users_in_topic = array();
	$popups = "";

	while(list($post_id,$post_subject,$user_id,$post_body,$post_time,$user_name,$user_title,$stars,$Picture,
						 $picwidth,$picheight,$Registered,$TotalPosts,$Location,$Signature,$CustomTitle,$accept_pm,$homepage,
						 $visible,$mood,$namecolor,$userlevel,$gimages) = $dbh->fetch_array($sth)) {

		// Track this for quick reply;
		$last_post = $post_id;

		$plist = "";
		foreach($participants as $pvisit => $pdata) {
			if ($pvisit < $post_time) {
				foreach($pdata as $k => $pname) {
					$plist .= "$pname, ";
				}
			}
		}
		$plist = preg_replace("/, $/","",$plist);

		$postrow[$i]['plist'] = $plist;
		$postrow[$i]['userid'] = $user_id;

		// Set the mood
		if (!$mood) $mood = "content.gif";
		$mood_alt = preg_replace("#.(gif|jpg|png)$#","",$mood);

		if (!$config['ENABLE_MOODS']) $mood_alt = "";

		$postrow[$i]['mood'] = $mood;
		$postrow[$i]['mood_alt'] = $mood_alt;

		$watch_text = "";
		if ($user_id == 1) {
			$postrow[$i]['Username'] = $ubbt_lang['DELETED'];
		}	else {
			// Colorize username (if it applies)
			$PUsername = $html->user_color($user_name, $namecolor, $userlevel);
			$postrow[$i]['GROUP_IMAGES'] = $html->user_status($user_id,$gimages);

			$postrow[$i]['Username'] = "<span id=\"menu_control_$post_id\"><a href=\"javascript:void(0);\" onclick=\"showHideMenu('menu_control_$post_id','profile_popup_$post_id');\">$PUsername</a></span>";
			$postrow[$i]['printuser'] = $user_name;
			if (is_array($watch_lists['u']) && in_array($user_id,$watch_lists['u'])) {
				$watch_text = $ubbt_lang['REMOVE_WATCH'];
			} else {
				$watch_text = $ubbt_lang['ADD_WATCH'];
			} // end if
		}

		if ($user_id == $user['USER_ID']) {
			if ($i == 0) {
				$postrow[$i]['editlink'] = make_ubb_url("ubb=editprivate&message=$post_id&subj=1", "", false);
			} else {
				$postrow[$i]['editlink'] = make_ubb_url("ubb=editprivate&message=$post_id", "", false);
			}
		} else {
			$postrow[$i]['editlink'] = "";
		}

		$postrow[$i]['replylink'] = make_ubb_url("ubb=mess_handler&replymess=1&Number=$message&id=$post_id", "", false);
		$postrow[$i]['quotelink'] = make_ubb_url("ubb=mess_handler&replymess=1&Number=$message&q=1&id=$post_id", "", false);

		$postrow[$i]['mailpostlink'] = "";
		if ($config['MAIL_POST']) {
			$postrow[$i]['mailpostlink'] = make_ubb_url("ubb=domailthread&PM=1&Number=$message", "", false);
		}

		$picsize = "";
		if ($picwidth && $picheight) {
			$picsize = "width=\"$picwidth\" height=\"$picheight\"";
		}
		elseif ($config['AVATAR_MAX_WIDTH'] && $config['AVATAR_MAX_HEIGHT']) {
			$picsize = "width=\"{$config['AVATAR_MAX_WIDTH']}\" height=\"{$config['AVATAR_MAX_HEIGHT']}\"";
		}
		if ($Picture) {
			$postrow[$i]['Picture'] = "<img src=\"$Picture\" alt=\"\" $picsize />";
		} else {
			$postrow[$i]['Picture'] = "";
		}

		$postrow[$i]['time'] = $html -> convert_time($post_time,$toffset,$user['USER_TIME_FORMAT']);
		if ($i) $post_subject = "Re: $post_subject";
		$postrow[$i]['Subject'] = $post_subject;
		$postrow[$i]['new_marker'] = "";
		$postrow[$i]['Number'] = $post_id;

		// Handle Title vs Custom and how the board is configured
		if ($CustomTitle && $config['ONLY_CUSTOM']) {
			$postrow[$i]['Title'] = $CustomTitle;
			$CustomTitle = "";
		} else {
			$postrow[$i]['Title']    = $user_title;
			$postrow[$i]['CustomTitle'] = $CustomTitle;
		}

		$postrow[$i]['TotalPosts'] = "{$ubbt_lang['TOTAL_POSTS']} $TotalPosts";
		$postrow[$i]['Signature'] = $Signature;
		if (isset($Registered)) {
			$Registered = $html -> convert_time($Registered,$user['USER_TIME_OFFSET'],$user['USER_TIME_FORMAT'],1);
			preg_match("/<span class=\"date\">(.*?)<\/span>/",$Registered,$matches);
			$Registered = trim($matches['1']);
			$postrow[$i]['Registered'] = "{$ubbt_lang['REGED_ON']} $Registered";
		}
		if ($Location) {
			if (strlen($Location) > 30) {
				$TitleText = $Location;
				$Location = substr($Location,0,30);
				$Location = "<span title=\"$TitleText\">$Location... </span>";
			}
			$postrow[$i]['Location'] = "{$ubbt_lang['USER_LOC']} $Location";
		}
		$rateimage = "";
		if ( ($stars) && ($config['USER_RATINGS'] == "1") ) {
			for ($x=1;$x<=$stars;$x++) {
				$rateimage .= "<img src=\"{$config['BASE_URL']}/images/{$style_array['general']}/star.gif\" alt=\"*\" />";
			}
			$postrow[$i]['Rating'] = $rateimage;
		}

		if ($post_time > $last_visit) {
			$postrow[$i]['unread'] = "<a name=\"UNREAD\"></a>";
			$postrow[$i]['newimage'] = "<img src=\"{$config['BASE_URL']}/images/{$style_array['general']}/new.gif\" alt=\"\" />";
		} else {
			$postrow[$i]['newimage'] = "";
			$postrow[$i]['unread'] = "";
		}

		// --------------------------
		// Are we ignoring this user?
		if (stristr($user['USER_IGNORE_LIST'],"-$user_id-")) {
			$postrow[$i]['Body'] = <<<NO_PEEKING
<div align="center">
{$ubbt_lang['IGNORING']}<br />
<a href="javascript:void(0);" onclick="toggleIgnore('body$i');">{$ubbt_lang['IGNORING_TOGGLE']}</a>
</div>
<br />
<div id="body$i" style="display:none">$post_body</div>
NO_PEEKING;
		} else {
			$postrow[$i]['Body'] = "<div id=\"body$i\">$post_body</div>";
		}


		$popups .= "<div id=\"profile_popup_$post_id\" style=\"display: none;\"><table class=\"popup_menu\">";
		$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"" . make_ubb_url("ubb=showprofile&User=$user_id", $user_name, false) . "\" rel=\"nofollow\">{$ubbt_lang['VIEW_PROFILE']}</a></td></tr>";
		if ($accept_pm) {
			$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"" . make_ubb_url("ubb=sendprivate&User=$user_id", "", false) . "\" rel=\"nofollow\">{$ubbt_lang['SEND_PM']}</a></td></tr>";
		} // end if
		if ($homepage) {
			$homepage = "http://$homepage";
			$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"$homepage\" target=\"_blank\">{$ubbt_lang['VIEW_HOME']}</a></td></tr>";
		} // end if
		$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"" . make_ubb_url("ubb=addfavuser&User=$user_id&n=$post_id&p=$page", "", false) . "\" rel=\"nofollow\">$watch_text</a></td></tr>";
		$popups .= "<tr><td class=\"popup_menu_content\"><a href=\"" . make_ubb_url("ubb=userposts&id=$user_id", "", false) . "\" rel=\"nofollow\">{$ubbt_lang['VIEW_POSTS']}</a></td></tr>";
		$popups .= "</table></div>";
		$popups .= "<script type=\"text/javascript\">registerPopup(\"profile_popup_$post_id\"); </script>";

		if (!isset($users_in_topic[$user_id])) {
			$users_in_topic[$user_id] = $visible;
		} // end if


		$i++;

	}


	// Now let's figure out who's online and who isn't
	$inlist = "";
	$online_status = array();
	foreach($users_in_topic as $o_uid => $o_vis) {
		$online_status[$o_uid] = 0;
		if (!$config['DISABLE_ONLINE_INVISIBLE'] && $o_vis == "no" && ($user['USER_MEMBERSHIP_LEVEL'] != "Administrator" && (!preg_match("/Moderator/",$user['USER_MEMBERSHIP_LEVEL'])))) {
			continue;
		} // end if
		$inlist .= "'$o_uid',";
	} // end foreach
	$inlist = preg_replace("#,$#","",$inlist);

	if (!$inlist) $inlist = "''";
	$query = "
		select USER_ID
		from {$config['TABLE_PREFIX']}ONLINE
		where USER_ID in ($inlist)
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	while(list($o_uid) = $dbh->fetch_array($sth)) {
		$online_status[$o_uid] = 1;
	} // end while


	// Get the subject for this topic
	$query = "
		select TOPIC_SUBJECT
		from		{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS
		where		TOPIC_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($message),__LINE__,__FILE__);
	list($topic_subject) = $dbh->fetch_array($sth);

	// Update the last visit to this pt
	$date = $html->get_date();
	$query = "
		update	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
		set	MESSAGE_LAST_READ = ?
		where	USER_ID = ?
		and	TOPIC_ID = ?
	";
	$dbh->do_placeholder_query($query,array($date,$user['USER_ID'],$message),__LINE__,__FILE__);

	// Check and see if there are any more unread PMs
	$query = "
		select	count(*)
		from	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS as t1,
			{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS as t2
		where	t1.TOPIC_ID = t2.TOPIC_ID
		and	t2.TOPIC_LAST_REPLY_TIME > t1.MESSAGE_LAST_READ
		and	t1.USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
	list($total_unread) = $dbh->fetch_array($sth);

	$query = "
		update	{$config['TABLE_PREFIX']}USER_PROFILE
		set	USER_TOTAL_PM = ?
		where	USER_ID = ?
	";
	$dbh->do_placeholder_query($query,array($total_unread,$user['USER_ID']),__LINE__,__FILE__);

	$user['USER_TOTAL_PM'] = $total_unread;

	$smarty_data = array(
		"pages1" => &$pages1,
		"pages2" => &$pages2,
		"title" => $topic_subject,
		"postrow" => & $postrow,
		"message" => $message,
		"participant_list" => $participant_list,
		"id" => $last_post,
		"quickreply" => 1,
		"popups" => $popups,
		"post_layout" => $post_layout,
		"online_status" => $online_status,
		"mystuff" => $html->mystuff(),
		"toolong" => $toolong,
	);
	$cfrm = make_ubb_url("ubb=cfrm");
	$viewmessages = make_ubb_url("ubb=viewmessages", "", false);
	return array(
		"header" => array (
			"title" => $topic_subject,
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"javascript" => array(
				0 => "quickquote.js",
			),
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 <a href="{$viewmessages}">{$ubbt_lang['MY_PRIVATES']}</a>
 &raquo;
 $topic_subject
BREADCRUMB
			,
		),
		"template" => "viewmessage",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
