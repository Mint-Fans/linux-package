<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_viewmessages_gpc () {
	return array(
		"input" => array(
			"page" => array("page","get","int"),
		),
		"wordlets" => array("viewmessages"),
		"user_fields" => "t2.USER_TIME_FORMAT, t2.USER_TOPICS_PER_PAGE, t2.USER_POSTS_PER_TOPIC",
		"regonly" => 1,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_viewmessages_gpc

function page_viewmessages_run () {

	global $smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html, $style_array,$userob;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$toffset = "";

	$limit = ($user['USER_TOPICS_PER_PAGE'] ? $user['USER_TOPICS_PER_PAGE'] : $config['TOPICS_PER_PAGE']);
	if (!$user['USER_POSTS_PER_TOPIC']) {
		$user['USER_POSTS_PER_TOPIC'] = $config['POSTS_PER_PAGE'];
	} // end if

	isset($user['USER_TIME_OFFSET']) && $toffset = $user['USER_TIME_OFFSET'];
	!isset($user['USER_TIME_FORMAT']) && $user['USER_TIME_FORMAT'] = $config['TIME_FORMAT'];

	$query = "
		select 	count(*)
		from	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS as t1,
			{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS as t2,
			{$config['TABLE_PREFIX']}USERS as t3
		where	t2.USER_ID = ?
		and	t1.USER_ID = t3.USER_ID
		and	t1.TOPIC_ID = t2.TOPIC_ID
	";
	$sth = $dbh -> do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
	list( $total ) = $dbh->fetch_array( $sth );

	$page1 = $html->paginate( $page ? $page : 1, ceil( $total / $limit ), "viewmessages&page=" );
	$page2 = preg_replace('#pagination_\d+#', '', $page1);

	if( $page > 0 ) {
		$new_page = ( $page - 1 ) * $limit;
	} else {
		$new_page = 0;
	}

	// -------------------------
	// Get any private messages.
	$query = "
		SELECT 	t.USER_ID, t.TOPIC_SUBJECT, t.TOPIC_TIME, t.TOPIC_ID, t.TOPIC_REPLIES, t.TOPIC_LAST_REPLY_TIME, t.TOPIC_LAST_POSTER_ID,
						pmu.MESSAGE_LAST_READ, u.USER_DISPLAY_NAME, t.TOPIC_LAST_POSTER_NAME, u.USER_MEMBERSHIP_LEVEL, up.USER_NAME_COLOR
			FROM	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS t,
						{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS pmu,
						{$config['TABLE_PREFIX']}USERS u,
						{$config['TABLE_PREFIX']}USER_PROFILE up
		WHERE	pmu.USER_ID = ?
			AND t.USER_ID = u.USER_ID
			AND	t.USER_ID = up.USER_ID
			AND	t.TOPIC_ID = pmu.TOPIC_ID
		ORDER BY t.TOPIC_LAST_REPLY_TIME DESC
		LIMIT $new_page, $limit
	";
	$sth = $dbh->do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);

	$i = 0;
	$total_unread = 0;

	$message = array();
	$repliers = array('1');

	$rowcolor = "";

	while (list($sender, $subject, $when, $number, $replies, $last_reply, $last_poster, $last_read, $sendername, $last_poster_name, $level, $color) = $dbh -> fetch_array($sth)) {

		if ($sender == 1) {
			$sendername = $ubbt_lang['DELETED'];
		}
		$senton = $html -> convert_time($when, $toffset,$user['USER_TIME_FORMAT']);
		$go = "";
		$gonew = 0;
		if ($when > $last_read || $last_reply > $last_read) {
			$total_unread++;
			$type = $ubbt_lang['TEXT_NEW'];
			$go = "#UNREAD";
			$gonew = 1;
			$message[$i]['color'] = "new-$rowcolor";
		} else {
			$type = "&nbsp;";
			$message[$i]['color'] = $rowcolor;
		} // end if

		// Get the list of participants in this topic
		$query = "
			select t1.USER_DISPLAY_NAME
			from {$config['TABLE_PREFIX']}USERS as t1,
			{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS as t2
			where t1.USER_ID = t2.USER_ID
			and t2.TOPIC_ID = ?
		";
		$sti = $dbh->do_placeholder_query($query,array($number),__LINE__,__FILE__);
		$message[$i]['participants'] = "";
		while(list($partic) = $dbh->fetch_array($sti)) {
			$message[$i]['participants'] .= "$partic, ";
		}
		$message[$i]['participants'] = preg_replace("/, $/","",$message[$i]['participants']);

		$pageprint = "";
		if ($replies >= $user['USER_POSTS_PER_TOPIC']) {
			$pages = ceil(($replies + 1) / $user['USER_POSTS_PER_TOPIC']);

			if ($pages != 1) {
				$pageprint = " <div class=\"small\">( <img style=\"vertical-align: middle;\" src=\"{$config['BASE_URL']}/images/{$style_array['general']}/page.gif\" alt=\"\" /> ";

				if ($pages > 9) {
					for ($iamsam = 1; $iamsam <= 3; $iamsam++) {
						$pageprint .= sprintf('<a href="%s">%s</a> ', make_ubb_url("ubb=viewmessage&message=$number&page=$iamsam", $subject, false), $iamsam);
					}

					$pageprint .= '...';

					for ($iamsam = $pages - 2; $iamsam <= $pages; $iamsam++) {
						$pageprint .= sprintf('<a href="%s">%s</a> ', make_ubb_url("ubb=viewmessage&message=$number&page=$iamsam", $subject, false), $iamsam);
					}
				} else {
					for ($iamsam = 1; $iamsam <= $pages; $iamsam++) {
						$pageprint .= sprintf('<a href="%s">%s</a> ', make_ubb_url("ubb=viewmessage&message=$number&page=$iamsam", $subject, false), $iamsam);
					}
				}

				$pageprint .= " )</div>";
			}
		}

		$message[$i]['pageprint'] = $pageprint;
		$message[$i]['type'] = $type;
		$message[$i]['number'] = $number;
		$message[$i]['subject'] = $subject;
		$message[$i]['replies'] = $replies;
		$message[$i]['last_reply'] = "";
		$message[$i]['last_poster'] = "";
		if ($last_reply) {
			$message[$i]['last_reply'] = $html->convert_time($last_reply,$toffset,$user['USER_TIME_FORMAT']);
			$message[$i]['last_poster'] = $last_poster;
			$message[$i]['last_poster_name'] = $last_poster_name;
		}
		$message[$i]['go'] = $go;
		$message[$i]['gonew'] = $gonew;

		if ($sender == 1) {
			$message[$i]['sender'] = $sendername;
		}	else {
			$PUsername = $html->user_color($sendername, $color, $level);
			$message[$i]['sender'] = "<a href=\"" . make_ubb_url("ubb=showprofile&User=$sender", $sendername, false) . "\" rel=\"nofollow\">$PUsername</a>";
		}
		$message[$i]['senton'] = $senton;

		if ($rowcolor == "") {
			$rowcolor = "alt-";
		} else {
			$rowcolor = "";
		}

		$i++;
	}

	$messagesize = "0";
	if (isset($message)) {
		$messagesize = sizeof($message);
	}

	// Check and see if there are any more unread PMs
	$query = "
		select	count(t1.TOPIC_ID)
		from	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS as t1,
			{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS as t2
		where	t1.TOPIC_ID = t2.TOPIC_ID
		and	t2.TOPIC_LAST_REPLY_TIME > t1.MESSAGE_LAST_READ
		and	t1.USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
	list($total_unread) = $dbh->fetch_array($sth);

	$query = "
		update	{$config['TABLE_PREFIX']}USER_PROFILE
		set	USER_TOTAL_PM = ?
		where	USER_ID = ?
	";
	$dbh->do_placeholder_query($query,array($total_unread,$user['USER_ID']),__LINE__,__FILE__);

	// Regular users have a PM limit
	$pm_limit = $userob->check_access("site","PM_TOTAL");
	$divisor = 100 / $pm_limit;
	$used = $total * $divisor;
	$width = 100 - ($total / 2);
	$max = $pm_limit;
	$percent = 100 * $pm_limit;
	$font = ($percent > 90) ? "standouttext" : "";

	$smarty_data = array(
		"used" => $used,
		"total" => $total,
		"width" => $width,
		"pages" => $pages,
		"messagesize" => $messagesize,
		"page1" => $page1,
		"page2" => $page2,
		"message" => $message,
		"max" => $max,
		"font" => $font,
		"mystuff" => $html->mystuff(),
	);
	$cfrm = make_ubb_url("ubb=cfrm");
	return array(
		"header" => array (
			"title" => $ubbt_lang['PT'],
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 {$ubbt_lang['PT']}
BREADCRUMB
			,
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"javascript" => array('inline_moderation.js'),
		),
		"template" => "viewmessages",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
