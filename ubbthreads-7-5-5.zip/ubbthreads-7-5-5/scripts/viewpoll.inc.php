<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;
define('NO_WRAPPER',1);
function page_viewpoll_gpc () {
	return array(
		"input" => array(
			"Poll" => array("Poll","get","int"),
		),
		"wordlets" => array("viewpoll"),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_viewpoll_gpc

function page_viewpoll_run () {

	global $style_array,$smarty,$userob,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	$query = "
		select POST_ID
		from {$config['TABLE_PREFIX']}POLL_DATA
		where POLL_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($Poll),__LINE__,__FILE__);
	list($post) = $dbh->fetch_array($sth);
	

	$query = "
	select	t1.FORUM_ID
	from		{$config['TABLE_PREFIX']}TOPICS as t1,
					{$config['TABLE_PREFIX']}POSTS as t2
	where		t2.POST_ID = ?
	and			t1.TOPIC_ID = t2.TOPIC_ID
	";
	$sth = $dbh->do_placeholder_query($query,array($post),__LINE__,__FILE__);
	list($board) = $dbh->fetch_array($sth);


	if (!$userob->check_access("forum","SEE_FORUM",$board)) {
		$html -> not_right_bare($ubbt_lang['BAD_GROUP']);
	}
	
	$view_results = 1;
	include("libs/includepoll.inc.php");
		
	$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";
	
	$smarty_data['showpoll'] = $showpoll;
	$smarty_data['stylesheet'] = $stylesheet;
	$cfrm = make_ubb_url("ubb=cfrm");
	return array(
		"header" => array (
			"title" => $ubbt_lang['POLL_RES'],
			"refresh" => 0,
			"user" => $user,
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 {$ubbt_lang['POLL_RES']}
BREADCRUMB
			,
		),
		"template" => "viewpoll_popup",
		"data" => & $smarty_data,
		"footer" => false,
		"location" => "",
	);


}

?>
