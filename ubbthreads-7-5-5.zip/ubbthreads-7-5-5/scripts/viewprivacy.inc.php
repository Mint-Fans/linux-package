<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.5
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if(!defined("UBB_MAIN_PROGRAM")) exit;

function page_viewprivacy_gpc () {
	return array(
		"input" => array(
		),
		"wordlets" => array(""),
		"user_fields" => "",
		"regonly" => 0,
		"admin_only" => 0,
		"admin_or_mod" => 0,
	);
} // end page_viewprivacy_gpc

function page_viewprivacy_run () {

	global $smarty,$user,$in,$ubbt_lang,$config,$forumvisit,$visit,$dbh,$html;

	extract($in, EXTR_OVERWRITE | EXTR_REFS); // quick and dirty fix - extract hash values as vars

	// ------------------------
	// Predefine some variables
	$boardprivacy = "";

	$date = date("M/d/Y");

	$privacy = @file("{$config['FULL_PATH']}/includes/privacy.php");
	if (!is_array($privacy)) {
		$privacy = @file("{config['BASE_URL']}/includes/privacy.php");
	}
	if ($privacy) {
		while(list($linenum,$line) = each($privacy)) {
			$boardprivacy .= $line;
		}
	}

	$smarty_data['boardprivacy'] = & $boardprivacy;
	$cfrm = make_ubb_url("ubb=cfrm");
	return array(
		"header" => array (
			"title" => $ubbt_lang['PRIVACY'],
			"refresh" => 0,
			"user" => "",
			"Board" => "",
			"bypass" => 0,
			"onload" => "",
			"breadcrumb" => <<<BREADCRUMB
 <a href="{$cfrm}">{$ubbt_lang['FORUM_TEXT']}</a>
 &raquo;
 {$ubbt_lang['PRIVACY']}
BREADCRUMB
			,
		),
		"template" => "viewprivacy",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);

}

?>
