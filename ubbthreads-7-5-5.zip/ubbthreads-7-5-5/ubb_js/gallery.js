/* Script Version 7.5.5 */

function showFullSize(width,height,id) {
	window.open(script + "?ubb=showpic&id=" + id,'pic','scrollbars=yes,toolbar=yes,status=no,resizable=yes,width=' + width + ',height = ' + height); 
} // end showFullSize

function updateMedium(id) {
	if (is_pending) return;
	is_pending = 1;

	var url = script;
	var ajax = new ubbtAJAX(url,updateMediumPic,'xml');
	ajax.sendData("POST","ubb=getmediumpic&id=" + id);
}

function updateMediumPic(responseXML) {
	retval = responseXML;
	var imageNode = retval.getElementsByTagName("imgsrc")[0];
	if (imageNode.childNodes[0]) {
		var image = imageNode.childNodes[0].nodeValue;
	}
	var widthNode = retval.getElementsByTagName("width")[0];
	if (widthNode.childNodes[0]) {
		var w = widthNode.childNodes[0].nodeValue;
	}
	var heightNode = retval.getElementsByTagName("height")[0];
	if (heightNode.childNodes[0]) {
		var h = heightNode.childNodes[0].nodeValue;
	}
	var idNode = retval.getElementsByTagName("id")[0];
	if (idNode.childNodes[0]) {
		var id = idNode.childNodes[0].nodeValue;
	}
	var descNode = retval.getElementsByTagName("description")[0];
	if (descNode.childNodes[0]) {
		var desc = descNode.childNodes[0].nodeValue;
	}
	var thumbNode = retval.getElementsByTagName("thumb")[0];
	if (thumbNode.childNodes[0]) {
		var thumb = thumbNode.childNodes[0].nodeValue;
	}
	var mediumNode = retval.getElementsByTagName("medium")[0];
	if (mediumNode.childNodes[0]) {
		var medium = mediumNode.childNodes[0].nodeValue;
	}
	var fullNode = retval.getElementsByTagName("full")[0];
	if (fullNode.childNodes[0]) {
		var full = fullNode.childNodes[0].nodeValue;
	}
	var sizeNode = retval.getElementsByTagName("size")[0];
	if (sizeNode.childNodes[0]) {
		var size = sizeNode.childNodes[0].nodeValue;
	}

	obj = get_object('mediumpic');
	obj.src = image; 
	obj.onclick = function(){showFullSize( w,h,id );};
	obj = get_object('mediumpic_desc');
	if (desc != "" && desc != undefined) {
		obj.innerHTML = desc;
	}

	obj = get_object('thumb');
	obj.value = thumb;

	obj = get_object('medium');
	obj.value = medium;

	obj = get_object('full');
	obj.value = full;

	obj = get_object('dimensions');
	obj.innerHTML = w + "x" + h;

	obj = get_object('size');
	obj.innerHTML = size;

	is_pending = 0;
}
