/* Script Version 7.5.5 */

/**
 * Javascript functions for inline moderation
 */

function toggle_moderation(check, row_id, uncheck_all_box) {
	if (!check.checked) {
		var cells = get_object(row_id).getElementsByTagName('td');
		for (var i in cells) {
			if (cells[i].className != null) {
				cells[i].className = cells[i].className.replace(/ inline_selected/, '');
			}
		}
	} else {
		var cells = get_object(row_id).getElementsByTagName('td');
		for (var i in cells) {
			if (cells[i].className != null) {
				cells[i].className += ' inline_selected';
			}
		}
	}
}

function select_topics(option) {

	switch (option) {
		case "invert":
			for (var i=0; i < document.inline_moderation.elements.length; i++) {
				var e = document.inline_moderation.elements[i];
				if (e.type == "checkbox" && e.name.match("check-inline") != null) {
					e.checked = !e.checked;
					toggle_moderation(e, "postrow-inline-" + e.value, false);
				}
			}
			break;
		case "all":
			for (var i=0; i < document.inline_moderation.elements.length; i++) {
				var e = document.inline_moderation.elements[i];
				if (e.type == "checkbox" && e.name.match("check-inline") != null) {
					if (e.checked == true) next;
					e.checked = true;
					toggle_moderation(e, "postrow-inline-" + e.value, false);
				}
			}
			break;
		case "none":
			for (var i=0; i < document.inline_moderation.elements.length; i++) {
				var e = document.inline_moderation.elements[i];
				if (e.type == "checkbox" && e.name.match("check-inline") != null) {
					if (e.checked == false) next;
					e.checked = false;
					toggle_moderation(e, "postrow-inline-" + e.value, false);
				}
			}
			break;
		default:
			for (var i=0; i < document.inline_moderation.elements.length; i++) {
				var e = document.inline_moderation.elements[i];
				if (e.type == "checkbox" && e.name.match("check-inline") != null) {
					if (topics_for_moderation[e.value].match(option)) {
						e.checked = true;
						toggle_moderation(e, "postrow-inline-" + e.value, false);
					} else {
						e.checked = false;
						toggle_moderation(e, "postrow-inline-" + e.value, false);
					}
				}
			}
			break;
	}
}

function init_inline_moderation() {
	var inputs = document.getElementsByTagName('input');

	for (var i in inputs) {
		if (inputs[i].type == "checkbox" && inputs[i].name.match("check-inline") != null) {
			inputs[i].checked = false;
		} else if(inputs[i].name == 'check-all-inline') {
			inputs[i].checked = false;
			inputs[i].disabled = false;
		}
	}
}
