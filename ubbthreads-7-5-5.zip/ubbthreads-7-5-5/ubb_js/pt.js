/* Script Version 7.5.5 */
var count = 0;
var user_array = new Array(0);
var do_submit = 0;
var curr_username = '';

function addUser() {
	document.replier.ubb.value = "sendprivate";
	document.replier.submit();
} // end addUser

function checkArray(value) {

	var i;

	for (i=0; i < user_array.length; i++) {	
		if (user_array[i].toLowerCase() == value.toLowerCase()) {
			return true;
		}
	}

} // end checkArray

function checkTotal() {

	if (user_array.length >= pmLimit) {
		return true;
	}

} // end checkTotal

function checkUser(user) {
	curr_username = user;
	var url = script + "?ubb=checkrecipient&user=" + encodeURIComponent(user);
	var ajax = new ubbtAJAX(url, addRecipient,'xml');
	ajax.sendData("GET");
} // end function checkUser


function updateList(username) {
	dup = checkArray(username);
	if (dup) {
		return alert(dupUser);
	} // end if

	max = checkTotal();
	if (max) {
		return alert(tooMany);
	} // end if
	
	checkUser(username);
	
}

function addRecip(checkval) {
	username = document.replier.User.value;

	if (checkval == 'submit') do_submit = 1;	
	if (do_submit == 1 && !username) {
		document.replier.submit();
	}
	if (!username) return;
	dup = checkArray(username);
	if (dup) {
		return alert(dupUser);
	} // end if

	max = checkTotal();
	if (max) {
		return alert(tooMany);
	} // end if

	return checkUser(username);
	
}

function addRecipient(responseXML) {

	retval = responseXML;

	if (retval.getElementsByTagName("error")[0]) {
		var textNode = retval.getElementsByTagName("error")[0];
		if (textNode.childNodes[0]) {
			is_error = 1;
			var error = textNode.childNodes[0].nodeValue;
			return alert(error);
		}
	}
	var textNode = retval.getElementsByTagName("user")[0];
	if (textNode.childNodes[0]) {
		var username = textNode.childNodes[0].nodeValue;
	}
	username = curr_username;
	
	obj = get_object('recips');
	obj.innerHTML += username + "; "
	document.replier.User.value = "";
	
	obj2 = get_object('hidden_list');
	obj2.innerHTML += "<input type='hidden' name='recip[" + count + "]' value='" +username.replace(/'/g,"&#39;")+ "' />";
	
	user_array[count] = username;
	count = count + 1;

	if (do_submit == 1) {
		document.replier.submit();
	}
	return true;
	
} // end addRecipient
