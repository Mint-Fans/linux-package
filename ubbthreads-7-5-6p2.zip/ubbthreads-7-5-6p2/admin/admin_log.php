<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/admin_log.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","both");
$start_day = get_input("start_day","both","int");
$start_month = get_input("start_month","both","int");
$start_year = get_input("start_year","both","int");
$stop_day = get_input("stop_day","both","int");
$stop_month = get_input("stop_month","both","int");
$stop_year = get_input("stop_year","both","int");
$purge = get_input("purge","post","int");
$purgevalue = get_input("purgevalue","post","int");
$purgetype = get_input("purgetype","post","alpha");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME,USER_TIME_OFFSET,USER_TIME_FORMAT");
$html = new html;

$admin = new Admin;

$admin->doAuth();


// Purge if necessary
if ($purge && $purgevalue) {
	$multi = 1;
	if ($purgetype == "w") $multi = 7;
	if ($purgetype == "m") $multi = 31;
	if ($purgetype == "y") $multi = 365;
	$purgedate = $html->get_date() - ($purgevalue * (86400 * $multi));
	$query = "
		delete from {$config['TABLE_PREFIX']}ADMIN_LOG
		where LOG_DATE <= '$purgedate'
	";
	$dbh->do_query($query,__LINE__,__FILE__);
} // end if
// Get the current date
$currdate = date("d n Y");
list($cday,$cmonth,$cyear) = preg_split("# #",$currdate);

if (!$start_day) $start_day = $cday;
if (!$start_month) $start_month = $cmonth;
if (!$start_year) $start_year = $cyear;

if (!$stop_day) $stop_day = $cday;
if (!$stop_month) $stop_month = $cmonth;
if (!$stop_year) $stop_year = $cyear;

// Which one is older?
if ($start_year < $stop_year) {
	$older = "start";
} elseif ($stop_year < $start_year) {
	$older = "stop";
} elseif ($start_month < $stop_month) {
	$older = "start";
} elseif ($stop_month < $start_month) {
	$older = "stop";
} elseif ($start_day < $stop_day) {
	$older = "start";
} elseif ($stop_day < $start_day) {
	$older = "stop";
} else {
	$older = "start";
}

if ($older == "start") {
	$start = mktime(0,0,0,$start_month,$start_day,$start_year);
	$stop = mktime(23,59,59,$stop_month,$stop_day,$stop_year);
} else {
	$stop = mktime(0,0,0,$start_month,$start_day,$start_year);
	$start = mktime(23,59,59,$stop_month,$stop_day,$stop_year);
} // end if

$query = "
	select count(LOG_DATE)
	from {$config['TABLE_PREFIX']}ADMIN_LOG
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
list($total) = $dbh->fetch_array($sth);

$query = "
	select min(LOG_DATE)
	from {$config['TABLE_PREFIX']}ADMIN_LOG
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
list($min) = $dbh->fetch_array($sth);

$actions = array();
$query = "
	select t1.LOG_DATE,t1.USER_ID,t1.LOG_IP,t1.LOG_ACTION,t1.LOG_INFO,t2.USER_DISPLAY_NAME
	from {$config['TABLE_PREFIX']}ADMIN_LOG as t1,
	{$config['TABLE_PREFIX']}USERS as t2
	where t1.LOG_DATE >= $start
	and t1.USER_ID = t2.USER_ID
	and t1.LOG_DATE <= $stop
	order by t1.LOG_DATE desc
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while(list($date,$userid,$ip,$operation,$description,$username) = $dbh->fetch_array($sth)) {
	$actions[] = array(
		"date" => $html->convert_time($date,$user['USER_TIME_OFFSET'],$user['USER_TIME_FORMAT']),
		"user" => sprintf('<a href="%s">%s</a>', make_ubb_url("ubb=showprofile&User=$userid", $username, false), $username),
		"ip" => $ip,
		"operation" => $operation,
		"description" => $description,
	);
} // end while


$min = $html->convert_time($min,$user['USER_TIME_OFFSET'],$user['USER_TIME_FORMAT']);

$entries = sprintf($ubbt_lang['TOTAL_LOGS'],$total,$min);

$starting_day[$start_day] = "selected='selected'";
$starting_month[$start_month] = "selected='selected'";
$starting_year[$start_year] = "selected='selected'";

for ($i=$cyear;$i>=$cyear-1;$i--) {
	$sel = "";
	if ($i == $start_year) $sel = "selected='selected'";
	$start_years .= "<option value='$i' $sel>$i</option>";

	$sel = "";
	if ($i == $stop_year) $sel = "selected='selected'";
	$stop_years .= "<option value='$i' $sel>$i</option>";
}
$ending_day[$stop_day] = "selected='selected'";
$ending_month[$stop_month] = "selected='selected'";
$ending_year[$stop_year] = "selected='selected'";


$tabs = array(
	"{$ubbt_lang['SQL_HEAD']}" => "{$config['BASE_URL']}/admin/logs.php?returntab=0",
	"{$ubbt_lang['ADMIN_HEAD']}" => "",
	"{$ubbt_lang['REFERER_HEAD']}" => "{$config['BASE_URL']}/admin/referer_log.php?returntab=2"
);

$admin->setCurrentMenu($ubbt_lang['LOGS']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['ADMIN_HEAD']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
include("../templates/default/admin/admin_log.tmpl");

$admin->sendFooter();
?>
