<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if (!defined('GROUP')) {
	exit;
}

require ("../languages/{$config['LANGUAGE']}/admin/changeusergroups.php");


// Grab all non-disabled groups that we can directly change
$group = array();
$query = "
	SELECT GROUP_ID,GROUP_NAME
	FROM {$config['TABLE_PREFIX']}GROUPS
	WHERE GROUP_IS_DISABLED <> '1'
	AND GROUP_ID > '3'
	AND GROUP_ID <> '5'
";
$i=0;
$sth=$dbh->do_query($query,__LINE__,__FILE__);
while(list($gid,$gname) = $dbh->fetch_array($sth)) {
	$group[$i]['id'] = $gid;
	$group[$i]['name'] = $gname;
	$i++;
}


$tabs = array(
	"{$ubbt_lang['CHANGE_GROUPS']}" => ""
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['MEM_MAN']);
$admin->setParentTitle($ubbt_lang['MEM_MAN'],"membermanage.php");
$admin->setPageTitle($ubbt_lang['CHANGE_GROUPS']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/changeusergroups.tmpl");

$admin->sendFooter();

exit;
?>
