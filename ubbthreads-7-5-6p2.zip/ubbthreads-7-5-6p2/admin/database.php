<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/database.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate();

$admin = new Admin;
$admin->doAuth();

// Grab the saved queries
$query = "
	SELECT QUERY_ID,QUERY_SYNTAX,QUERY_DESCRIPTION
	FROM {$config['TABLE_PREFIX']}SAVED_QUERIES
	ORDER BY QUERY_ID
";
$sth=$dbh->do_query($query,__LINE__,__FILE__);
$i=0;
$jsarray = "";
$descarray = "";
$command = array();
while(list($qentry,$qquery,$desc)=$dbh->fetch_array($sth)) {
	$command[$i]['number'] = $qentry;
	$command[$i]['query'] = str_replace("<","&lt;",$qquery);
	$command[$i]['query'] = str_replace("\\n","",nl2br($command[$i]['query']));
	$qquery_q = addslashes($qquery);
	$qquery_q = str_replace("\\\\n","",$qquery_q);
	$qquery_q = preg_replace("/(\n|\r)/","JSLBR",$qquery_q);
	$jsarray .="\"$qquery_q\",";
	$descarray .="\"" . addslashes(html_entity_decode($desc)) ."\",";

	if (!$desc) {
		$desc = "No description";
	}
	$command[$i]['desc'] = $desc;

	$i++;
}
$jsarray = preg_replace("/,$/","",$jsarray);
$descarray = preg_replace("/,$/","",$descarray);

// Get the list of tables
$tables = mysql_list_tables($config['DATABASE_NAME']);


$tabs = array(
	"{$ubbt_lang['INFO']}" => "dbinfo.php?returntab=0",
	"{$ubbt_lang['COMMAND']}" => "",
	"{$ubbt_lang['BACKUP']}" => "dbbackup.php?returntab=2"
);

$admin->setCurrentMenu($ubbt_lang['DATABASE']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['DATABASE']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
include("../templates/default/admin/database.tmpl");

$admin->sendFooter();
?>
