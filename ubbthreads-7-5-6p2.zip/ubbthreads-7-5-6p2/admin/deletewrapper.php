<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/editwrapper.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = 0;
$wrapper = get_input("wrapper","get");


// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

include("{$config['FULL_PATH']}/styles/wrappers.php");

$wrapper_name = $wrappers[$wraper]['name'];

unset($wrappers[$wrapper]);

$wrapper_file = "<?php\n\$wrappers = " . var_export($wrappers,true) . "?>\n";


$check = lock_and_write("{$config['FULL_PATH']}/styles/wrappers.php",$wrapper_file);
if ($check == "no_write") {
	$admin->error($ubbt_lang['NO_WRITE_WRAPPERS']);
} // end if

admin_log("DELETE_WRAPPER","$wrapper_name");

$admin->redirect($ubbt_lang['WRAPPER_DELETED'],"{$config['BASE_URL']}/admin/wrappers.php?returntab=1",$ubbt_lang['WRAPPER_F_LOC']);

?>
