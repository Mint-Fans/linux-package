<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/doaddgraemlin.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info
$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$code = get_input("code","post");
$smiley = get_input("smiley","post");

// Make sure we got a ubbcode
if (!$code) {
	$admin->error($ubbt_lang['NO_CODE']);
}

// -----------------------
// Get the uploaded images
if (empty($_FILES['readpost']['name'])) {
	$admin->error($ubbt_lang['NO_GRAEMLIN']);
}
$graemlin_name = $_FILES['readpost']['name'];
$graemlin_temp = $_FILES['readpost']['tmp_name'];

if (file_exists("{$config['FULL_PATH']}/images/{$style_array['graemlins']}/$graemlin_name")) {
	@unlink($graemlin_temp);
	$admin -> error("{$ubbt_lang['NAME_EXISTS']} $graemlin_name.");
}

$check = @move_uploaded_file($graemlin_temp, "{$config['FULL_PATH']}/images/{$style_array['graemlins']}/$graemlin_name");
@chmod("{$config['FULL_PATH']}/images/{$style_array['graemlins']}/$graemlin_name",0666);
if (!$check) {
	$admin->error("{$ubbt_lang['NO_MOVE']}");
}


$imagehw = @GetImageSize("{$config['FULL_PATH']}/images/{$style_array['graemlins']}/$graemlin_name");
$imagewidth = $imagehw[0];
$imageheight = $imagehw[1];


// --------------------------
// Now add it to the database
$query_vars = array($code,$smiley,$graemlin_name,1,$imageheight,$imagewidth);
$query = "
	INSERT INTO {$config['TABLE_PREFIX']}GRAEMLINS
	(GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH)
	VALUES ( ? , ? , ? , ? , ? , ? )
";
$dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

// ---------------
// Log this action
$src = "<img src='{$config['BASE_URL']}/images/{$style_array['graemlins']}/$graemlin_name'>";
admin_log("ADD_GRAEMLIN", "$src");


$admin->redirect($ubbt_lang['G_ADDED'],"{$config['BASE_URL']}/admin/graemlins_display.php?returntab=1",$ubbt_lang['F_LOC']);

?>
