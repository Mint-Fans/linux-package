<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth(array("APPROVE_POSTS"));

$action = get_input("action","post");
$post_list = "";
while(list($key,$value) = each($action)) {
	$post_list .= " $key, ";
	if ($value == "delete") {
		$query = "
			select TOPIC_ID,POST_IS_TOPIC
			from {$config['TABLE_PREFIX']}POSTS
			where POST_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($key),__LINE__,__FILE__);
		list($topic_id,$is_topic) = $dbh->fetch_array($sth);
		if ($is_topic) {
			$query = "
				delete from {$config['TABLE_PREFIX']}TOPICS
				where TOPIC_ID = ?
			";
			$dbh->do_placeholder_query($query,array($topic_id),__LINE__,__FILE__);
		}
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}POSTS
			WHERE POST_ID = ?
		";
		$dbh->do_placeholder_query($query,array($key),__LINE__,__FILE__);
	}
	if ($value == "approve") {
		$query = "
			SELECT t1.TOPIC_ID,t2.FORUM_ID,t1.POST_IS_TOPIC,t1.POST_POSTED_TIME,t1.USER_ID,t3.USER_DISPLAY_NAME,t1.POST_SUBJECT,t1.POST_ICON,t1.POST_POSTER_NAME,t4.FORUM_TITLE,t1.POST_DEFAULT_BODY,t1.POST_BODY
			FROM	{$config['TABLE_PREFIX']}POSTS as t1,
				{$config['TABLE_PREFIX']}TOPICS as t2,
				{$config['TABLE_PREFIX']}USERS as t3,
				{$config['TABLE_PREFIX']}FORUMS as t4
			WHERE	t1.POST_ID = ? and t1.TOPIC_ID = t2.TOPIC_ID and t1.USER_ID = t3.USER_ID
				AND t4.FORUM_ID = t2.FORUM_ID
		";
		$sth = $dbh->do_placeholder_query($query,array($key),__LINE__,__FILE__);
		list($topic_id,$board,$is_topic,$date,$user_id,$user_display,$Subject,$Icon,$guest_name, $forum_title, $DefaultBody, $htmlbody) = $dbh-> fetch_array($sth);

		$totalthreads = "";
		$totalreplies = "";
		if (!$is_topic) {
			$totalreplies = ",TOPIC_REPLIES = TOPIC_REPLIES + 1";
		} else {
			$totalthreads = ",FORUM_TOPICS = FORUM_TOPICS + 1";
		} // end if

		$query = "
			UPDATE {$config['TABLE_PREFIX']}POSTS
			SET POST_IS_APPROVED='1'
			WHERE POST_ID = ?
		";
		$dbh->do_placeholder_query($query,array($key),__LINE__,__FILE__);

		if ($user_id == 1) $user_display = $guest_name;

		$query_vars = array($date,$key,$user_display,$user_id,$topic_id);
		$query = "
			update {$config['TABLE_PREFIX']}TOPICS
			set TOPIC_LAST_REPLY_TIME = ?,
			TOPIC_IS_APPROVED = '1',
			TOPIC_LAST_POST_ID = ? ,
			TOPIC_LAST_POSTER_NAME = ? ,
			TOPIC_LAST_POSTER_ID = ?
			$totalreplies
			where TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

		$query_vars = array($user_id,$date,$topic_id,$key,$user_display,$Subject,$Icon,$board);
		$query = "
			UPDATE {$config['TABLE_PREFIX']}FORUMS
			SET   FORUM_POSTS = FORUM_POSTS + 1,
			FORUM_LAST_POSTER_ID = ? ,
			FORUM_LAST_POST_TIME = ? ,
			FORUM_LAST_TOPIC_ID = ? ,
			FORUM_LAST_POST_ID = ?,
			FORUM_LAST_POSTER_NAME = ? ,
			FORUM_LAST_POST_SUBJECT = ? ,
			FORUM_LAST_POST_ICON = ?
			$totalthreads
			WHERE FORUM_ID = ?
		";
		$dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

		$notify_data = array(
			'EVENT' => (is_topic ? 'TOPIC' : 'REPLY'),
			'USER' => $user_id,
			'USERNAME' => $user_display,
			'FORUM' => $board,
			'POST' => $key,
			'TOPIC' => $topic_id,
			'BODY' => $DefaultBody,
			'HTMLBODY' => $htmlbody,
			'TITLE' => $Subject,
			'FORUM_NAME' => $forum_title,
		);

		handle_watchlist_notifications($notify_data);
	}
}

admin_log("APPROVE_POSTS",$post_list);

$admin->redirect($ubbt_lang['APPROVE_DONE'],"{$config['BASE_URL']}/admin/approveposts.php",$ubbt_lang['APP_F_LOC']);

?>
