<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	You may not distribute "hacks" for UBB without approval from
//	Mindraven
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$which = get_input("which","post");
$inlist = get_input("inlist","post");

// -----------------
// Get the user info
$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// This may take awhile depending on the number of users we are working with.
set_time_limit(0);

// ---------------
// Log this action
admin_log("MASSGROUPCHANGE", "");

// What groups, if any are we changing?
$action = get_input("action","post");
$isin = "";
$notin = "";
$addto = array();
$removefrom = array();

// Grab all the current group #'s
$query = "
	SELECT GROUP_ID
	FROM {$config['TABLE_PREFIX']}GROUPS
	WHERE GROUP_ID > '3'
	AND GROUP_IS_DISABLED <> '1'
	AND GROUP_ID <> '5'
	ORDER BY GROUP_ID
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while(list($gid) = $dbh->fetch_array($sth)) {
	if ($action[$gid] == "add") {
		if (!$notin) {
			$notin = "AND (GROUP_ID <> '$gid' ";
		}
		else {
			$notin .= " OR GROUP_ID <> '$gid' ";
		}
		$addto[] = $gid;
	}
	if ($action[$gid] == "remove") {
		$isin .= "'$gid',";
		$removefrom[] = $gid;
	}
}

if ($isin) {
	$isin = preg_replace("/,$/","",$isin);
	$isin = "AND GROUP_ID in ($isin) ";
}
if ($notin) {
	$notin .= " ) ";
}

$user_array = array();
if ($which == "selected") {
	$query = "
		select USER_ID,GROUP_ID
		from {$config['TABLE_PREFIX']}USER_GROUPS
		where USER_ID IN ($inlist)
		$isin
		$notin
	";
	$sth = $dbh->do_query($query);
}
else {
	$query = "
		SELECT ADMIN_SEARCH_TERMS,ADMIN_SEARCH_REMOVED_RESULTS
		FROM {$config['TABLE_PREFIX']}ADMIN_SEARCHES
		WHERE USER_ID = ?
		AND ADMIN_SEARCH_TYPE='member'
	";
	$sth = $dbh->do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
	list($aquery,$removed) = $dbh->fetch_array($sth);
	if ($removed) {
		$removed = "AND USER_ID NOT IN ($removed)";
	}
	// Last Online needs to be changed to t2 instead of t3
	$aquery = preg_replace("/GROUP BY t1.USER_ID/","",$aquery);
	$aquery = preg_replace("/t1\./","",$aquery);
	$aquery = "SELECT t1.USER_ID,t4.GROUP_ID FROM {$config['TABLE_PREFIX']}USERS as t1, {$config['TABLE_PREFIX']}USER_GROUPS as t4, {$config['TABLE_PREFIX']}USER_PROFILE as t2, {$config['TABLE_PREFIX']}USER_DATA as t3  WHERE t1.USER_ID <> '1' and t1.USER_ID = t4.USER_ID and t1.USER_ID = t2.USER_ID and t1.USER_ID = t3.USER_ID $removed $aquery";
	$sth = $dbh->do_query($aquery);
}

while(list($uid,$gid) = $dbh->fetch_array($sth)) {
	$user_array[$uid][] = $gid;
}
foreach($user_array as $uid => $values) {
	foreach($addto as $k => $v) {
		if (!in_array($v,$user_array[$uid])) {
			// REPLACE INTO
			$query = "
			replace into {$config['TABLE_PREFIX']}USER_GROUPS
			values
			( ? , ? )
			";
			$dbh->do_placeholder_query($query,array($uid,$v),__LINE__,__FILE__);
			$userob->clear_cached_perms($uid);
		}
	}
	foreach($removefrom as $k => $v) {
		if (in_array($v,$user_array[$uid])) {
			// REMOVE FROM
			$query = "
				delete from {$config['TABLE_PREFIX']}USER_GROUPS
				where USER_ID = ?
				and GROUP_ID = ?
			";
			$dbh->do_placeholder_query($query,array($uid,$v),__LINE__,__FILE__);
			$userob->clear_cached_perms($uid);
		}
	}
}

$admin->redirect($ubbt_lang['GMEMBERS_CHANGED'],"{$config['BASE_URL']}/admin/membersearch.php",$ubbt_lang['GMEMBERS_F_LOC']);

?>

