<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/dodbcommand.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = 0;

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// -------------
// Get the input
$command = get_input("command","post");
$desc    = get_input("description", "post");
$save    = get_input("save","post");
$execute = get_input("execute","post");
$entry   = get_input("entry","get");
$action  = get_input("action","get");

if ($action == "optimize") {
	$table = get_input("table", "get");
	$query = "
		OPTIMIZE TABLE {$table}
	";
	$dbh->do_query($query,__LINE__,__FILE__);
	$admin->redirect($ubbt_lang['OPTIMIZED'],"{$config['BASE_URL']}/admin/dbinfo.php?returntab=0",$ubbt_lang['F_LOC']);
	exit;
}

if ($action == "delete") {
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}SAVED_QUERIES
		WHERE QUERY_ID = ?
	";
	$dbh->do_placeholder_query($query,array($entry),__LINE__,__FILE__);
	$admin->redirect($ubbt_lang['DELETED'],"{$config['BASE_URL']}/admin/database.php?returntab=1",$ubbt_lang['F_LOC']);
	exit;
}

// -------------------------
// Are we saving this query?
if ($save) {
	$command = str_replace("\n","\\n",$command);
	$query = "
		INSERT INTO {$config['TABLE_PREFIX']}SAVED_QUERIES
		(QUERY_SYNTAX, QUERY_DESCRIPTION)
		VALUES
		( ?, ? )
	";
	$dbh->do_placeholder_query($query,array($command, htmlspecialchars($desc)),__LINE__,__FILE__);
	$admin->redirect($ubbt_lang['SAVED'],"{$config['BASE_URL']}/admin/database.php?returntab=1",$ubbt_lang['F_LOC']);
	exit;
}

if (!$command) {
	$admin->error($ubbt_lang['NO_COMMAND']);
}

// ------------------------------------------------------------------
// If it was some type of a select command, we want to display things
// nicely

$sth = $dbh->do_query($command, __LINE__, __FILE__);

if (is_resource($sth)) {
	$numFields = $dbh -> num_fields($sth);
	$results = "<tr><td class=\"stdautorow colored-row\" colspan='$numFields' align='center'><a href='database.php?returntab=1'>{$ubbt_lang['GO_BACK']}</a></td></tr>";
	$results .= "<tr>";
	for ( $i=0; $i<$numFields; $i++) {
		$results .= "<td class=\"autorow-header-1 autoleft autoright autotop autobottom bold\">" . $dbh -> field_name($sth, $i) ."</td>";
	}
	$results .= "</tr>";
	while ( $vals = $dbh -> fetch_array($sth)) {
		$results .= "<tr>";
		$valsize = sizeof($vals);
		for ( $i=0; $i<$numFields; $i++) {
			$results .= "<td valign=\"top\" class=\"stdautorow colored-row autoleft autoright autotop autobottom\">" . htmlspecialchars($vals[$i]) . "</td>";
		}
		$results .= "</tr>";
	}
} else {
	$affected = $dbh->affected_rows();
	$results .= "<tr><td class=\"stdautorow colored-row autoleft autoright autotop autobottom\">$affected {$ubbt_lang['SQL_ROWS']}</td></tr>";
	$results .= "<tr><td class=\"stdautorow colored-row\" align='center'><a href='database.php?returntab=1'>{$ubbt_lang['GO_BACK']}</a></td></tr>";
}

$tabs = array(
	"{$ubbt_lang['INFO']}" => "dbinfo.php?returntab=0",
	"{$ubbt_lang['COMMAND']}" => "database.php?returntab=1",
	"{$ubbt_lang['BACKUP']}" => "dbbackup.php?returntab=2"
);

$admin->setCurrentMenu($ubbt_lang['DATABASE']);
$admin->setReturnTab(1);
$admin->setParentTitle($ubbt_lang['DATABASE'],"database.php?returntab=1");
$admin->setPageTitle($ubbt_lang['SQL_HEAD']);
$admin->sendHeader();
$admin->createTopTabs($tabs,1);




// Include the template
include("../templates/default/admin/dodbcommand.tmpl");

admin_log("DODBCOMMAND", $command);

$admin->sendFooter();
?>
