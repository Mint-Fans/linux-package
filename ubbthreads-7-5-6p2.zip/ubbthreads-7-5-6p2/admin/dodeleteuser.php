<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/dodeleteuser.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Get the input
$delete = get_input("delete","post");
$uid = get_input("uid","post");

if (!$delete) {
	$admin->redirect($ubbt_lang['NO_ACTION'],"{$config['BASE_URL']}/admin/showuser.php?uid=$uid",$ubbt_lang['F_LOC']);
}

// Keeping posts, so update all old posts
$query = "
	SELECT USER_DISPLAY_NAME
	FROM {$config['TABLE_PREFIX']}USERS
	WHERE USER_ID = ?
";
$sth = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
list($uname) = $dbh->fetch_array($sth);

if ($delete == 1) {
	$uname = addslashes($uname);
	// Set all posts to owned by anonymous
	
	$query = "
		update {$config['TABLE_PREFIX']}TOPICS
		set USER_ID='1'
		where USER_ID = ?
	";
	$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
	
	$query = "
		UPDATE {$config['TABLE_PREFIX']}POSTS
		SET USER_ID = '1'
		WHERE USER_ID = ?
	";
	$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
}

if ($delete == 2) {
	
	// ----------------------------------------------
	// Ok, first we grab all posts made by this user
	$query = "
		SELECT t1.POST_ID,t1.TOPIC_ID,t2.FORUM_ID,t1.POST_IS_TOPIC,t1.POST_PARENT_ID
		FROM   {$config['TABLE_PREFIX']}POSTS as t1,
		       {$config['TABLE_PREFIX']}TOPICS as t2
		WHERE  t1.USER_ID = ?
		AND    t1.TOPIC_ID = t2.TOPIC_ID
		ORDER  BY t1.POST_ID
	";
	$sth = $dbh -> do_placeholder_query($query,array($uid),__LINE__,__FILE__);

	while ( list($post_id,$topic_id,$Board,$is_topic,$parent_post) = $dbh -> fetch_array($sth)) {

		// -----------
		// Delete post 
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}POSTS
			WHERE  POST_ID = ?
		";
		$dbh -> do_placeholder_query($query,array($post_id),__LINE__,__FILE__);

		$query = "
			update {$config['TABLE_PREFIX']}POSTS
			set POST_PARENT_ID = ?
			where TOPIC_ID = ?
			and POST_PARENT_ID = ?
		";
		$dbh->do_placeholder_query($query,array($parent_post,$topic_id,$post_id),__LINE__,__FILE__);
				
		if ($is_topic) {
			$query = "
				delete from {$config['TABLE_PREFIX']}TOPICS
				where TOPIC_ID = ?
			";
			$dbh->do_placeholder_query($query,array($topic_id),__LINE__,__FILE__);
		}

		// -------------------------------------
		// Update the total posts for this board
		// If $topic is set to 1 then we decrement the thread total as well
		$extra = "";
		if ($is_topic) {
			$extra = ",FORUM_TOPICS = FORUM_TOPICS - 1";
		}
		$query = "
			UPDATE {$config['TABLE_PREFIX']}FORUMS
			SET    FORUM_POSTS = FORUM_POSTS - 1,
			FORUM_LAST_POST_ID = 0,
			FORUM_LAST_POSTER_ID = 0,
			FORUM_LAST_POSTER_NAME = '',
			FORUM_LAST_POST_SUBJECT = '',
			FORUM_LAST_POST_ICON = ''
			$extra
			WHERE  FORUM_ID = ?
		";
		$dbh -> do_placeholder_query($query,array($Board),__LINE__,__FILE__);

		// -------------------------------------------------------------------
		// Update the main post in this thread if needed to set the proper
		// number of replies
		if (!$is_topic) {
			$query = "
				UPDATE {$config['TABLE_PREFIX']}TOPICS
				SET    TOPIC_REPLIES = TOPIC_REPLIES - 1
				WHERE  TOPIC_ID  = ?
			";
			$dbh -> do_placeholder_query($query,array($topic_id),__LINE__,__FILE__);
		}

	}
}

// Delete from the users table
$query = "
	DELETE FROM {$config['TABLE_PREFIX']}USERS
	WHERE USER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
$query = "
	DELETE FROM {$config['TABLE_PREFIX']}USER_PROFILE
	WHERE USER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
$query = "
	DELETE FROM {$config['TABLE_PREFIX']}USER_DATA
	WHERE USER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
// Delete from the ratings table
$query = "
	DELETE FROM {$config['TABLE_PREFIX']}RATINGS
	WHERE RATING_TARGET = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
// Delete any pending display name changed
$query = "
	DELETE FROM {$config['TABLE_PREFIX']}DISPLAY_NAMES
	WHERE USER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
// Delete all favorites and reminders
$query = "
	DELETE FROM {$config['TABLE_PREFIX']}WATCH_LISTS
	WHERE USER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);

// Delete all file attachments by this user.
$query = "
	select FILE_NAME,FILE_DIR
	from {$config['TABLE_PREFIX']}FILES
	where USER_ID = ?
";
$sth = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
while(list($fname,$fdir) = $dbh->fetch_array($sth)) {
	if (!$fdir) {
		unlink("{$config['ATTACHMENTS_PATH']}/$fname");
	} else {
		unlink("{$config['FULL_PATH']}/gallery/$fdir/full/$fname");
		unlink("{$config['FULL_PATH']}/gallery/$fdir/medium/$fname");
		unlink("{$config['FULL_PATH']}/gallery/$fdir/thumbs/$fname");
	} // end if
} // end while

// Delete entries in FILES table
$query = "
	delete from {$config['TABLE_PREFIX']}FILES
	where USER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);

$users_to_rebuild_pm_count = array();

// Delete profile comments
$query = "
	delete from {$config['TABLE_PREFIX']}PROFILE_COMMENTS
	where USER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);

// Delete private messages for this user
$query = "
	select 	TOPIC_ID
	from 	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
	where	USER_ID = ?
";
$sth = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
while(list($message_id) = $dbh->fetch_array($sth)) {
	$query = "
		delete from {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
		where	USER_ID = ?
		and	TOPIC_ID = ?
	";
	$dbh->do_placeholder_query($query,array($uid,$message_id),__LINE__,__FILE__);
	
	$query = "
		select	count(*)
		from 	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
		where	TOPIC_ID = ? AND USER_ID <> 1
	";
	$sth2 = $dbh->do_placeholder_query($query,array($message_id),__LINE__,__FILE__);
	list($users) = $dbh->fetch_array($sth2);
	if ($users == '0') {
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS
			WHERE TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query,array($message_id),__LINE__,__FILE__);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
			WHERE TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query,array($message_id),__LINE__,__FILE__);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
			WHERE TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query,array($message_id),__LINE__,__FILE__);
	} else {
		$query = "
			SELECT	USER_ID
			FROM	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
			WHERE	TOPIC_ID = ? AND USER_ID <> 1
		";
		
		$sth2 = $dbh->do_placeholder_query($query, array($message_id), __LINE__, __FILE__);
		
		while ($result = $dbh->fetch_array($sth2)) {
			$users_to_rebuild_pm_count[] = $result['USER_ID'];
		}
	}
}

// Rebuild pm count for the users specified.
$users_to_rebuild_pm_count = array_unique($users_to_rebuild_pm_count);

foreach ($users_to_rebuild_pm_count as $user_to_rebuild) {
	rebuild_pm_count($user_to_rebuild);
}

// Delete any calendar events this user made
$query = "
	DELETE FROM {$config['TABLE_PREFIX']}CALENDAR_EVENTS
	WHERE USER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
// Set saved messages to the placeholder user
$query = "
	UPDATE {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
	SET USER_ID='1'
	WHERE USER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);

// Set saved messages to the placeholder user
$query = "
	UPDATE {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS
	SET USER_ID='1'
	WHERE USER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);

// Delete from moderator list
$query = "
	DELETE FROM {$config['TABLE_PREFIX']}MODERATORS
	WHERE USER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
// Update the boards table if they made the last post
$query = "
	UPDATE {$config['TABLE_PREFIX']}FORUMS
	SET FORUM_LAST_POSTER_ID = '1',
	FORUM_LAST_POSTER_NAME = '{$ubbt_lang['ANON_TEXT']}'
	WHERE FORUM_LAST_POSTER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
// Delete all last viewed entries for the user
$query = "
	DELETE FROM {$config['TABLE_PREFIX']}CALENDAR_EVENTS
	WHERE USER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);

// DELETE FROM USER_GROUPS table
$query = "
	delete from {$config['TABLE_PREFIX']}USER_GROUPS
	where USER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);


// ----------------------------------
// Update the newuser/totaluser cache
$sth = $dbh->do_query("SELECT COUNT(*) FROM {$config['TABLE_PREFIX']}USERS WHERE USER_IS_APPROVED='yes'",__LINE__,__FILE__);
list($registered) = $dbh -> fetch_array($sth);
$dbh -> finish_sth($sth);

// ---------------------------------------------------------
// let's grab the name of the most recently registered user
$query = "
	SELECT USER_DISPLAY_NAME,USER_ID
	FROM {$config['TABLE_PREFIX']}USERS
	WHERE USER_IS_APPROVED='yes'
	ORDER BY USER_ID DESC LIMIT 0,1
";
$sth = $dbh -> do_query($query,__LINE__,__FILE__);
list($newusername,$newnumber) =  $dbh -> fetch_array($sth);
$dbh -> finish_sth($sth);

admin_log("DELETE_USER", "$uid: $uname");

rebuild_islands();
rebuild_forum_data("all");
	

$admin->redirect($ubbt_lang['USER_DELETED'],"{$config['BASE_URL']}/admin/login.php",$ubbt_lang['F_LOC_MAIN']);

?>
