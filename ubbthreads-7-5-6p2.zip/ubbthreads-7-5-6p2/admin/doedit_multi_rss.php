<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// -------------
// Get the input
$feed = get_input("feed","post");
$feed_active = get_input("feed_active","post");
$feed_name = get_input("feed_name","post");
$feed_cache = get_input("feed_cache","post");
$type = get_input("type","post");
$feed_body = get_input("feed_body","post");
$items = get_input("items","post");

if (!$feed_cache) $feed_cache = 10;
$feed_cache = $feed_cache * 60;
if (!$items) $items = 10;
if (!$feed_body && $feed_body != '0') $feed_body = 10;

foreach($_POST['source'] as $k => $v) {
	if ($v == "category") {
		unset($_POST['source'][$k]);
	} // end if
} // end foreach
$source = serialize($_POST['source']);

$query_vars = array($feed_active,$feed_name,$feed_cache,$type,$feed_body,$items,$source);

if ($feed) {
	// Update the feed
	array_push($query_vars,$feed);
	$query = "
		update {$config['TABLE_PREFIX']}RSS_FEEDS
		set FEED_IS_ACTIVE = ? ,
		FEED_NAME = ? ,
		FEED_CACHE_TIME = ? ,
		FEED_TYPE = ? ,
		FEED_INCLUDE_BODY = ? ,
		FEED_ITEMS = ? ,
		FEED_FORUM_ARRAY = ?
		where FEED_ID = ?
	";
	$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
} else {
	// Add the feed
	$query = "
		insert into {$config['TABLE_PREFIX']}RSS_FEEDS
		(FEED_IS_ACTIVE,FEED_NAME,FEED_CACHE_TIME,FEED_TYPE,FEED_INCLUDE_BODY,FEED_ITEMS,FEED_FORUM_ARRAY,FEED_IS_MULTI)
		values 
		( ? , ? , ? , ? , ? , ? , ? , 1 )
	";
	$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
} // end if

generate_rss_feeds(1);

$admin->redirect($ubbt_lang['RSS_UPDATED'],"{$config['BASE_URL']}/admin/rss.php?returntab=1",$ubbt_lang['RSS_F_LOC']);

?>
