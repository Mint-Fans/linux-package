<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if (!defined('IS_ADMIN')) exit;

$magic = get_magic_quotes_gpc();

$log_diffs = "";

for ($i=0;$i<sizeof($newconfig);$i++) {

	if(isset($_POST[$newconfig[$i]])) {

		if (($config[$newconfig[$i]] != $_POST[$newconfig[$i]]) && ($newconfig[$i] != "DATABASE_PASSWORD") ) {
			$from = $config[$newconfig[$i]];
			$to = $_POST[$newconfig[$i]];
			if (!$from) $from = '0';
			if (!$to) $to = '0';
			$log_diffs .= sprintf($ubbt_lang['CONFIG_UPDATE'],$newconfig[$i],$from,$to) . "<br />";
		} // end if

		if (!is_array($_POST[$newconfig[$i]])) {
			$config[$newconfig[$i]] = $_POST[$newconfig[$i]];
			if ($magic) {
				$config[$newconfig[$i]] = stripslashes($config[$newconfig[$i]]);
			} else {
				$config[$newconfig[$i]] = str_replace('"','\"',$config[$newconfig[$i]]);
				$config[$newconfig[$i]] = str_replace('\\\"','\"',$config[$newconfig[$i]]);
			}
		} else {
			$config[$newconfig[$i]] = $_POST[$newconfig[$i]];
		}
	}
	else {
		$config[$newconfig[$i]] = "";
	}
}

// ---------------------------------
// Make sure sizes don't have commas
$config['MAX_AVATAR_SIZE'] = str_replace(",","",$config['MAX_AVATAR_SIZE']);


// -------------------------------------
// Check for proper display name lengths
if ($config['MIN_PDN_LENGTH'] < 1) {
	$config['MIN_PDN_LENGTH'] = 1;
}
if ($config['MAX_PDN_LENGTH'] > 64) {
	$config['MAX_PDN_LENGTH'] = 64;
}
if (!$config['MIN_PDN_LENGTH']) {
	$config['MIN_PDN_LENGTH'] = 3;
}
if (!$config['MAX_PDN_LENGTH']) {
	$config['MAX_PDN_LENGTH'] = 16;
}
if ($config['MAX_PDN_LENGTH'] < $config['MIN_PDN_LENGTH']) {
	$admin->error("{$ubbt_lang['DISPLAY']}");
}

// ------------------------------------------
// We need to setup the newusergroup variable
if (isset($newusergroups)) {

	// -------------------------------
	// Now let's get all of the groups
	$query = "
		SELECT GROUP_NAME, GROUP_ID
		FROM   {$config['TABLE_PREFIX']}GROUPS
		WHERE  GROUP_IS_DISABLED <> 1
		AND ( (GROUP_ID > 5) or (GROUP_ID =4) )
	";
	$sth = $dbh -> do_query($query,__LINE__,__FILE__);

	// --------------------------------------------------------------------
	// Now we chug through the groups.  If it was checked, we add them to
	// the group.  If it was unchecked we remove them from it.
	$total = 0;
	$newusergroup = array();
	while ( list($Name,$Id) = $dbh -> fetch_array($sth)) {
		$total++;
		$which = "GROUP$Id";
		if (isset($_POST{$which})) {
			$newusergroup[] = $_POST{$which};
		}
	}
	$config['DEFAULT_USER_GROUPS'] = $newusergroup;
}

// Make sure there is a default language
if ($config['LANGUAGE'] == "") {
	$config['LANGUAGE'] = "english";
}

$newconf = <<<EOF
<?php

EOF;

$newconf .= "\$config = " . var_export($config,true);

$newconf .= "?>";

$check = lock_and_write("{$config['FULL_PATH']}/includes/config.inc.php",$newconf);
if ($check == "no_write") {
	$admin->error($ubbt_lang['NO_WRITE_CONFIG']);
} // end if

if(!defined('INSTALL')) {

	rebuild_islands(1);

} // end if

?>
