<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/doeditgraemlin.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","post");

// -----------------
// Get the user info
$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Get the current graemlin list
$query = "
SELECT GRAEMLIN_ID,GRAEMLIN_IMAGE,GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH,GRAEMLIN_ORDER
FROM   {$config['TABLE_PREFIX']}GRAEMLINS
";
$sth = $dbh -> do_query($query,__LINE__,__FILE__);
$i=0;
while (list($number,$image,$markup,$smiley,$active,$height,$width,$order) = $dbh -> fetch_array($sth)) {
	$graemlins[$i]['entry'] = $number;
	$graemlins[$i]['image'] = $image;
	$graemlins[$i]['markup'] = $markup;
	$graemlins[$i]['smiley'] = $smiley;
	$graemlins[$i]['active'] = $active;
	$graemlins[$i]['height'] = $height;
	$graemlins[$i]['width'] = $width;
	$graemlins[$i]['order'] = $order;
	$i++;
}


$total = get_input("total","post");
for ($i=0;$i<$total;$i++) {
	$delete = get_input("delete-$i","post");
	if ($delete) {
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}GRAEMLINS
			WHERE GRAEMLIN_ID = ?
		";
		$dbh->do_placeholder_query($query,array($delete),__LINE__,__FILE__);
	}
	else {
		$active = get_input("active-$i","post");
		$markup = get_input("markup-$i","post");
		$smiley = get_input("smiley-$i","post");
		$order = get_input("order-$i", "post");
		if (!$active) $active = 0;
		$filename = "file-$i";
		$file = "";
		$file_temp = "";
		if (!empty($_FILES[$filename]['name'])) {
			$file = $_FILES[$filename]['name'];
			$file_temp = $_FILES[$filename]['tmp_name'];
			$check = @move_uploaded_file($file_temp,"{$config['FULL_PATH']}/images/{$style_array['graemlins']}/{$graemlins[$i]['image']}");
			@chmod("{$config['FULL_PATH']}/images/{$style_array['graemlins']}/{$graemlins[$i]['image']}",0666);
			if (!$check) {
				$admin->error("{$config['FULL_PATH']}/images/{$style_array['graemlins']}/{$graemlins[$i]['image']} {$ubbt_lang['NO_OVERW']}");
			}
			$imagehw = @GetImageSize("{$config['FULL_PATH']}/images/{$style_array['graemlins']}/{$graemlins[$i]['image']}");
			$graemlins[$i]['width'] = $imagehw[0];
			$graemlins[$i]['height'] = $imagehw[1];
		}
		if (   ($active != $graemlins[$i]['active'])
			|| ($markup != $graemlins[$i]['markup'])
			|| ($smiley != $graemlins[$i]['smiley'])
			|| ($order != $graemlins[$i]['order']) )
		{

			// Update the graemlin
			$query_vars = array($active,$markup,$smiley,$graemlins[$i]['width'],$graemlins[$i]['height'],$order,$graemlins[$i]['entry']);
			$query = "
				UPDATE {$config['TABLE_PREFIX']}GRAEMLINS
				SET GRAEMLIN_IS_ACTIVE = ? ,
				GRAEMLIN_MARKUP_CODE = ? ,
				GRAEMLIN_SMILEY_CODE = ? ,
				GRAEMLIN_WIDTH = ? ,
				GRAEMLIN_HEIGHT = ?,
				GRAEMLIN_ORDER = ?
				WHERE GRAEMLIN_ID = ? 
			";
			$dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
		}
	}
}

// ---------------
// Log this action
admin_log("EDIT_GRAEMLINS","");

$admin->redirect($ubbt_lang['UPDATED'],"{$config['BASE_URL']}/admin/graemlins_display.php?returntab=1",$ubbt_lang['F_LOC']);

?>
