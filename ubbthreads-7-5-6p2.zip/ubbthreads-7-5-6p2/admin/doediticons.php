<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/doediticons.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

$removedicons = "";

// -------------
// Get the input
$returntab = get_input("returntab","post");

// -----------------
// Get the user info
$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// ------------------
// Remove all checked
$dir = opendir("{$config['FULL_PATH']}/images/{$style_array['icons']}");
$i=0;
while( ($file = readdir($dir)) != false) {
	if ( ($file == ".") || ($file == "..") || ($file == "lock.gif") || ($file == "blank.gif") ) {
		continue;
	}
	list($name,$ext) = preg_split("#\.#",$file);
	$upload = "file-$ext-$name";
	if (isset($_POST[$name])) {
		$filename = "$name.{$_POST[$name]}";
		$test = @unlink("{$config['FULL_PATH']}/images/{$style_array['icons']}/$filename");
		if (!$test) {
			$admin -> error("{$ubbt_lang['NOREMOVE']}");
		}
		$query = "
			UPDATE {$config['TABLE_PREFIX']}POSTS
			SET POST_ICON = 'blank.gif'
			WHERE POST_ICON='$filename'
		";
		$dbh -> do_query($query,__LINE__,__FILE__);

		$query = "
			UPDATE {$config['TABLE_PREFIX']}TOPICS
			SET TOPIC_ICON = 'blank.gif'
			WHERE TOPIC_ICON='$filename'
		";
		$dbh -> do_query($query,__LINE__,__FILE__);

		$query = "
			UPDATE {$config['TABLE_PREFIX']}FORUMS
			SET FORUM_LAST_POST_ICON = 'blank.gif'
			WHERE FORUM_LAST_POST_ICON='$filename'
		";
		$dbh -> do_query($query,__LINE__,__FILE__);
		$removedicons .= "$filename-";
	}
	elseif (!empty($_FILES[$upload]['name'])) {
		echo "here";
		$fileupload = $_FILES[$upload]['name'];
		$file_temp = $_FILES[$upload]['tmp_name'];
		$check = @move_uploaded_file($file_temp,"{$config['FULL_PATH']}/images/{$style_array['icons']}/$file");
		@chmod("{$config['FULL_PATH']}/images/{$style_array['icons']}/$file",0666);
		if (!$check) {
			$admin->error("{$config['FULL_PATH']}/images/{$style_array['icons']}/$file {$ubbt_lang['NO_OVERW']}");
		}
	}
}

// ---------------
// Log this action
admin_log("REMOVE_ICON", $removedicons);

$admin->redirect($ubbt_lang['REMOVED'],"{$config['BASE_URL']}/admin/icons_display.php",$ubbt_lang['F_LOC']);

?>
