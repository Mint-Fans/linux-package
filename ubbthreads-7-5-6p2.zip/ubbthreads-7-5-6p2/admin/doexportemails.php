<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	You may not distribute "hacks" for UBB without approval from
//	Mindraven
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/doexportemails.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_REAL_EMAIL");

$admin = new Admin;

$admin->doAuth();

// get the input
$query = get_input("query","post");
$which = get_input("which","post");
$email = get_input("email","post");
$inlist = get_input("inlist","post");
$export = get_input("export","post");
$format = get_input("format","post");

// Get the query from the db
$tempquery = "
	SELECT ADMIN_SEARCH_TERMS,ADMIN_SEARCH_REMOVED_RESULTS
	FROM {$config['TABLE_PREFIX']}ADMIN_SEARCHES
	WHERE USER_ID = ?
	AND ADMIN_SEARCH_TYPE='member'
";
$sth = $dbh->do_placeholder_query($tempquery,array($user['USER_ID']),__LINE__,__FILE__);
list ($extra,$removed) = $dbh->fetch_array($sth);
$query = preg_replace("/LIMIT(.*)$/","",$query);
if ($inlist) {
	$inlist = "AND t1.USER_ID IN ($inlist)";
}
if ($removed) {
	$removed = "AND t1.USER_ID NOT IN ($removed)";
}

$query = str_replace("WHERE t1.USER_ID <> '1'","WHERE t2.USER_ACCEPT_ADMIN_EMAILS <> 'Off' $extra AND t1.USER_ID <> '1'",$query);

$query = "
	SELECT t2.USER_REAL_EMAIL
	FROM {$config['TABLE_PREFIX']}USERS as t1,
	{$config['TABLE_PREFIX']}USER_PROFILE as t2,
	{$config['TABLE_PREFIX']}USER_DATA as t3,
	{$config['TABLE_PREFIX']}USER_GROUPS as t4
	WHERE t1.USER_ID <>  '1'
	AND t1.USER_ID = t2.USER_ID
	AND t1.USER_ID = t3.USER_ID
	AND t1.USER_ID = t4.USER_ID
	AND t2.USER_ACCEPT_ADMIN_EMAILS <> 'Off'
	$inlist
	$removed
	$extra
";

$message = "";
$emails = "";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while(list($email) = $dbh->fetch_array($sth)) {
	if (!$email) { continue; }
	if ($format == "one_per") {
		$emails .= "$email\n";
	}
	if ($format == "comma") {
		$emails .= "$email,";
	}
	if ($format == "semi") {
		$emails .= "$email;";
	}
}
$emails = preg_replace("/(,|;)$/","",$emails);
$emails = str_replace("\n","<br />",$emails);

if ($export == "browser") {
	$message = "{$ubbt_lang['REQUESTED']}<br /><br />";
	$message .= $emails;
}
if ($export == "email_list") {
	$mailer  = new mailer("../");
	$mailer->set_language($config['LANGUAGE']);
	$mailer->set_subject('DEE_SUBJECT');
	$mailer->set_salute('EMAIL_SALUTE');
	$mailer->add_content('DEE_CONTENT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE'], 'EL_LISTO' => $emails));
	$mailer->ubbt_mail($user['USER_REAL_EMAIL']);
	$message = $ubbt_lang['MAILED'];
}

$tabs = array(
	"{$ubbt_lang['EMAIL_USERS']}" => ""
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['MEM_MAN']);
$admin->setParentTitle($ubbt_lang['MEM_MAN'],"membermanage.php");
$admin->setPageTitle($ubbt_lang['EMAIL_USERS']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

include("../templates/default/admin/doexportemails.tmpl");

admin_log("EXPORT_EMAILS","");

$admin->sendFooter();
?>
