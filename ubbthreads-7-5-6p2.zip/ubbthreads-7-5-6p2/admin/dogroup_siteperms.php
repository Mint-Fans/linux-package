<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$group = get_input("group","post");

// Get the list of site permissions
$perms = array();
$query = "
	select PERMISSION_NAME
	from {$config['TABLE_PREFIX']}PERMISSION_LIST
	where PERMISSION_TYPE='site'
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while(list($name) = $dbh->fetch_array($sth)) {
	$perms[] = $name;
} // end while

$keys = "GROUP_ID,";
$values = "$group,";
foreach($perms as $k => $perm) {
	$keys .= "$perm,";
}
foreach($perms as $k => $perm) {
	$value = $_POST[$perm];
	if (!$value) $value = "0";
	$value = addslashes($value);
	$values .= "'$value',";
}
$keys = preg_replace("/,$/","",$keys);
$values = preg_replace("/,$/","",$values);

$query = "
	replace into {$config['TABLE_PREFIX']}SITE_PERMISSIONS
	($keys)
	values
	($values)
";
$dbh->do_query($query,__LINE__,__FILE__);

admin_log("GROUP_SITE_PERMISSIONS","$group");

$userob->clear_cached_perms();

$admin->redirect($ubbt_lang['GROUP_PERM_UPDATED'],"{$config['BASE_URL']}/admin/group_siteperms.php?returntab=0&edit_group=$group",$ubbt_lang['GROUP_PERM_F_LOC']);

?>
