<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// Large boards may take awhile to delete groups.
@set_time_limit(0);

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Grab the input
$access = $_POST['access'];

// Grab all of the non disabled groups
$query = "
	SELECT GROUP_ID
	FROM {$config['TABLE_PREFIX']}GROUPS
	WHERE GROUP_IS_DISABLED <> '1'
	ORDER BY GROUP_ID
";
$sth = $dbh->do_query($query);
$i=0;
while(list($gid)=$dbh->fetch_array($sth)) {
	$group[$i] = $gid;
	$i++;
}

// grab all of the forums
$query = "
	SELECT FORUM_ID
	FROM {$config['TABLE_PREFIX']}FORUMS
	WHERE FORUM_IS_ACTIVE='1'
	ORDER BY FORUM_SORT_ORDER
";
$stx = $dbh->do_query($query,__LINE__,__FILE__);
while(list($bnum) = $dbh->fetch_array($stx)) {

	for ($i=0;$i<sizeof($group);$i++) {
		$read = 0;
		$topic = 0;
		$reply = 0;
		$gid = $group[$i];
		if ($access[$bnum][$group[$i]] == "read") {
			$read = 1;
		}
		if ($access[$bnum][$group[$i]] == "reply") {
			$read = 1;
			$reply = 1;
		}
		if ($access[$bnum][$group[$i]] == "write") {
			$read = 1;
			$reply = 1;
			$topic = 1;
		}
		
		$query_vars = array($gid,$bnum,$read,$topic,$reply);
		$query = "
			replace into {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
			values
			( ? , ? , ? , ? , ? )
		";
		$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	}
	
}

// Gotta do this now...
$dbh->do_query("truncate table {$config['TABLE_PREFIX']}CACHED_PERMISSIONS");

admin_log("GROUP_PERMISSIONS","");

$admin->redirect($ubbt_lang['G_PERM_UPDATED'],"{$config['BASE_URL']}/admin/groupmanage.php?returntab=1",$ubbt_lang['G_PERM_F_LOC']);

?>
