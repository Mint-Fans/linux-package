<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/dosendemail.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$subject = get_input("subject","post");
$body = nl2br(get_input("body","post"));
$bogus = get_input("bogus","post");
$onebyone = get_input("onebyone","post");
$timestamp = get_input("timestamp","both");
$which = get_input("which","post");
$inlist = get_input("inlist","post");

// -----------------
// Get the user info
$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$mailer = new mailer("../");

$admin = new Admin;

$admin->doAuth();

// If we are only emailing to selected users then we do this part
if ($which == "selected") {
	$finished = 1;
	$sentto = "";
	$query = "
		SELECT	up.USER_REAL_EMAIL, u.USER_DISPLAY_NAME, up.USER_LANGUAGE
			FROM	{$config['TABLE_PREFIX']}USER_PROFILE up,
						{$config['TABLE_PREFIX']}USERS u
		WHERE	up.USER_ID IN ($inlist)
			AND	u.USER_IS_APPROVED = 'yes'
			AND	up.USER_ACCEPT_ADMIN_EMAILS <> 'Off'
			AND	up.USER_ID = u.USER_ID
	";
	$sth = $dbh->do_query($query);
	$emailinfo = array();
	$x=0;
	$bcc = array();
	while(list($email,$username,$lang) = $dbh->fetch_array($sth)) {
		$bcc[] = $email;
		$emailinfo[$x]['email'] = $email;
		$emailinfo[$x]['username'] = $username;
		$emailinfo[$x]['lang'] = $lang;
		$sentto .= " $email,";
		$x++;
	}

	// Send out emails one at a time
	if ($onebyone) {
		// Pump em out!
		for ($i=0; $i<sizeof($emailinfo); $i++) {
			$mailer->set_language($emailinfo[$i]['lang']);
			$mailer->set_subject('DSE_SUBJECT', array('SUBJECT' => $subject));
			$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $emailinfo[$i]['username']));
			$mailer->add_content('DSE_CONTENT', array('CONTENT' => $body));
			$mailer->ubbt_mail($emailinfo[$i]['email']);
		}
	}
	// Send out via bcc
	else {
		$bcc_list = join(",",$bcc);
		$mailer->set_language($config['LANGUAGE']);
		$mailer->set_subject('DSE_SUBJECT', array('SUBJECT' => $subject));
		$mailer->set_salute('EMAIL_SALUTE',array('USERNAME' => ''));
		$mailer->add_content('DSE_CONTENT', array('CONTENT' => $body));
		$mailer->ubbt_mail($bogus,'',false,$bcc);
	}
	$loop = -1;
	$totals = 2;
	$type = "html";
}
else {

	// ----------------------------------------------------------
	// If the timestamps don't match between browser and database
	// then this is a new mail going out.
	if (!$onebyone) $onebyone = 0;
	$query = "
		SELECT MAILER_TIME,MAILER_SUBJECT,MAILER_BODY,MAILER_SAVED_QUERY,MAILER_DEFAULT_EMAIL,MAILER_DO_NOT_BCC,MAILER_CURRENT_CYCLE,MAILER_TYPE
		FROM   {$config['TABLE_PREFIX']}MAILER
		WHERE  MAILER_TIME='$timestamp'
	";
	$sth = $dbh -> do_query($query,__LINE__,__FILE__);
	list ($mtime,$msubject,$mmessage,$mquery,$mbogus,$monebyone,$mloop,$mtype) = $dbh -> fetch_array($sth);
	if (!$mtime) {

		$subject_q = addslashes($subject);
		$body_q = addslashes($body);
		$bogus = addslashes($bogus);
		$onebyone = addslashes($onebyone);
		$loop = 0;
		$type = "plaintext";

		$query = "
			SELECT ADMIN_SEARCH_TERMS,ADMIN_SEARCH_REMOVED_RESULTS
			FROM {$config['TABLE_PREFIX']}ADMIN_SEARCHES
			WHERE USER_ID='{$user['USER_ID']}'
			AND ADMIN_SEARCH_TYPE='member'
		";
		$sth = $dbh->do_query($query,__LINE__,__FILE__);
		list($sterms,$removed) = $dbh->fetch_array($sth);
		if ($removed) {
			$removed = "AND USER_ID NOT IN ($removed)";
		}
		$aquery = "
			select t2.USER_REAL_EMAIL
			from	{$config['TABLE_PREFIX']}USERS as t1,
				{$config['TABLE_PREFIX']}USER_PROFILE as t2,
				{$config['TABLE_PREFIX']}USER_DATA as t3,
				{$config['TABLE_PREFIX']}USER_GROUPS as t4
			where t1.USER_ID <> '1'
			and t2.USER_ACCEPT_ADMIN_EMAILS <> 'Off'
			and	t1.USER_ID = t2.USER_ID
			and	t1.USER_ID = t3.USER_ID
			and	t1.USER_ID = t4.USER_ID
			$removed $sterms
		";
		$aquery_q = addslashes($aquery);
		$timestamp = time();
		if (!$onebyone) $onebyone = 0;
		$query = "
			INSERT INTO {$config['TABLE_PREFIX']}MAILER
			(MAILER_TIME,MAILER_SUBJECT,MAILER_BODY,MAILER_SAVED_QUERY,MAILER_DEFAULT_EMAIL,MAILER_DO_NOT_BCC,MAILER_CURRENT_CYCLE,MAILER_TYPE)
			VALUES
			('$timestamp','$subject_q','$body_q','$aquery_q','$bogus','$onebyone','0','$type')
		";
		$dbh -> do_query($query,__LINE__,__FILE__);
	}
	else {
		$subject = $msubject;
		$aquery = $mquery;
		$body = $mmessage;
		$bogus = $mbogus;
		$onebyone = $monebyone;
		$loop = $mloop;
		$type = $mtype;
	}


	// ------------------------------------------------------------
	// If all required info is not filled in, then we can't proceed
	$bcc = "";
	if((!$subject)||(!$body)){
		$admin->error($ubbt_lang['SUB_BODY']);
	}

	// -------------------------------
	// Grab all of the email addresses
	$mailbody = $body;

	$limit = "";
	if (!$loop) {
		$limit = " LIMIT 25";
	}
	else {
		$start = $loop * 25;
		$limit = " LIMIT $start,25";
	}

	$aquery = str_replace("where t1.USER_ID <> '1'","WHERE t2.USER_ACCEPT_ADMIN_EMAILS <> 'Off' $extra AND t1.USER_ID <> '1'",$aquery);
	$aquery = preg_replace("/(\r|\n)/"," ",$aquery);
	$emailquery = preg_replace("/select(.*?)from/","SELECT t1.USER_DISPLAY_NAME,t2.USER_REAL_EMAIL,t1.USER_ID FROM",$aquery);
	$emailquery .= $limit;
	$countquery = preg_replace("/select(.*?)from/","SELECT COUNT(*) FROM",$aquery);
	$sth = $dbh -> do_query($countquery,__LINE__,__FILE__);
	list($tot_query) = $dbh -> fetch_array($sth);
	$tot = $dbh->total_rows($sth);
	$totals = $tot/25;
	@list($one,$two) = preg_split("#\.#",$totals);
	$totals = intval($totals);
	if ($two) { $totals++; }
	$sth = $dbh -> do_query($emailquery,__LINE__,__FILE__);
	$rows = $dbh -> total_rows($sth);

	$finished = "";
	$switch = "";
	if ( (!$rows) || ($rows < 2) ) {
		// If type is plaintext we need to update the database so we continue
		// onto the HTML loop
		/*
		if ($type == "plaintext") {
			$query = "
				UPDATE {$config['TABLE_PREFIX']}MAILER
				SET    MAILER_CURRENT_CYCLE='0',
				MAILER_TYPE='html'
				WHERE  MAILER_TIME='$timestamp'
			";
			$dbh -> do_query($query,__LINE__,__FILE__);
			$switch = 1;
		}
		*/
		//if ($type == "plaintext") {
			$query = "
				DELETE FROM {$config['TABLE_PREFIX']}MAILER
				WHERE MAILER_TIME = '$timestamp'
			";
			$dbh -> do_query($query,__LINE__,__FILE__);
			$finished = 1;
		//}
	}

	// -------------------------------------
	// Now we need to mail the message
	$from = $config['SITE_EMAIL'];
	$sentto = "";
	$bcc = array();
	while ( list($Display,$Email) = $dbh -> fetch_array($sth)) {
		// --------------------------------------
		// Are we sending via BCC or one a a time
		if ($onebyone) {
			if ( (strcmp($Email,"") != 0) && preg_match("/@/",$Email) ) {
				$sentto .= " $Email,";
				$mailer->set_language($config['LANGUAGE']);
				$mailer->set_subject('DSE_SUBJECT', array('SUBJECT' => $subject));
				$mailer->set_salute('EMAIL_SALUTE',array('USERNAME' => $Display));
				$mailer->add_content('DSE_CONTENT', array('CONTENT' => $mailbody));
				$mailer->ubbt_mail($Email);
			}
		}
		else {
			if ( (strcmp($Email,"") != 0) && preg_match("/@/",$Email) ) {
				if (!in_array($Email,$bcc)) {
					$bcc[] = $Email;
				}
			}
			$sentto .= " $Email,";
		}
	}

	// ---------------------------------------------
	// Update the database so we grab the next batch
	if (!$switch) {
		$updateloop = $loop + 1;
		$query = "
			UPDATE {$config['TABLE_PREFIX']}MAILER
			SET    MAILER_CURRENT_CYCLE = '$updateloop'
			WHERE  MAILER_TIME='$timestamp'
		";
		$dbh -> do_query($query,__LINE__,__FILE__);
	}

	if (sizeof($bcc)) {
		$mailer->set_language($config['LANGUAGE']);
		$mailer->set_subject('DSE_SUBJECT', array('SUBJECT' => $subject));
		$mailer->set_salute('EMAIL_SALUTE',array('USERNAME' => ''));
		$mailer->add_content('DSE_CONTENT', array('CONTENT' => $mailbody));
		$mailer->ubbt_mail($bogus,'',false,$bcc);
	}
	$dbh -> finish_sth($sth);
}

// ---------------
// Log this action
if ($finished) {
	admin_log("SENDEMAIL", "$subject");
}

// ------------------------
// Send them a confirmation
if (!$finished) {
	$sentto = preg_replace("/,$/","",$sentto);

	$printloop = $loop + 1;
	if ($printloop > $totals) {
		$mess = $ubbt_lang['FINISHED_CLEANUP'];
/*
		if ($type == "html") {
			$mess = $ubbt_lang['FINISHED_HTML'];
		}
		else {
			$mess = $ubbt_lang['FINISHED'];
		}
*/
	}
	else {
		$mess = "
			{$ubbt_lang['BATCH']} $printloop {$ubbt_lang['OF']} $totals
			<br /><br />
			$ubbt_lang[$type] {$ubbt_lang['SENT_BODY']} $sentto
		";
	}
	$admin->redirect($mess,"{$config['BASE_URL']}/admin/dosendemail.php?timestamp=$timestamp",$ubbt_lang['F_LOC'],2);
	exit;
}
else {
	if ($totals) { $totals = 1; }
	$sentto = preg_replace("/,$/","",$sentto);

	$printloop = $loop + 1;
	if ($printloop > $totals) {
		$mess = $ubbt_lang['FINISHED_DONE'];
/*
		if ($type == "html") {
			$mess = $ubbt_lang['FINISHED_HTML'];
		}
		else {
			$mess = $ubbt_lang['FINISHED'];
		}
*/
	}
	else {
		if ($which == "selected") {
			$mess = "{$ubbt_lang['CHECKED_SENT']} $sentto.";
		}
		else {
			$mess = "
				{$ubbt_lang['BATCH']} $printloop {$ubbt_lang['OF']} $totals
				<br /><br />
				$ubbt_lang[$type] {$ubbt_lang['SENT_BODY']} $sentto
			";
		}
	}
	$tabs = array(
		"{$ubbt_lang['EMAIL_USERS']}" => ""
	);
	$admin->setCurrentMenu($ubbt_lang['MEM_MAN']);
	$admin->setParentTitle($ubbt_lang['MEM_MAN'],"membermanage.php");
	$admin->setPageTitle($ubbt_lang['EMAIL_USERS']);
	$admin->sendHeader();
	$admin->createTopTabs($tabs);
	include("../templates/default/admin/dosendemail.tmpl");
	$admin->sendFooter();
}

?>
