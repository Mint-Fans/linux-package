<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/dotoggleopen.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Current status
if ($config['BOARD_IS_CLOSED'] == 0) {
	$isclosed = '1';
	$message = $ubbt_lang['NOW_CLOSED'];
}
else {
	$isclosed = '0';
	$message = $ubbt_lang['NOW_OPEN'];
}

// Read in the config file and set the new isclosed status
$file = file("../includes/config.inc.php");
$newconfig = "";
while(list($linenum,$line) = each ($file)) {
	if (preg_match("/'BOARD_IS_CLOSED'/",$line)) {
		$newconfig .= "\t'BOARD_IS_CLOSED' => '$isclosed',\n";
	}
	else {
		$newconfig .= $line;
	}
}

$check = lock_and_write("{$config['FULL_PATH']}/includes/config.inc.php",$newconfig);
if ($check == "no_write") {
	$admin->error($ubbt_lang['NO_OPEN']);
} // end if

admin_log("TOGGLE_OPEN",$message);

$admin->redirect($message,"{$config['BASE_URL']}/admin/login.php","{$ubbt_lang['F_LOC']}");

?>
