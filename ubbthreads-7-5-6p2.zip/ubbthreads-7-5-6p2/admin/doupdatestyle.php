<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/doupdatebanlists.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$returntab = get_input("returntab","post");
$style = get_input("style","post");
$copyfrom = get_input("copyfrom","post");

if ($copyfrom) {
	header("Location: {$config['FULL_URL']}/admin/editstyle.php?style=$style&copyfrom=$copyfrom");
	exit;
}

if (!$_POST['style_name']) {
	$admin->error($ubbt_lang['NO_NAME']);
}

$query = "
	select STYLE_EDITED_TIME,STYLE_NAME
	from {$config['TABLE_PREFIX']}STYLES
	where STYLE_ID = ?
";
$sth = $dbh->do_placeholder_query($query,array($style),__LINE__,__FILE__);
list($real_last_edit,$real_style_name) = $dbh->fetch_array($sth);

$css_file = "";
$style_vars = array();
foreach($_POST as $key => $value) {
	if (preg_match("/(returntab|style|style_name|news_images|general_images|avatar_images|forum_images|markup_images|graemlin_images|icon_images|wrapper|mood_images|valid_post)/",$key)) continue;
	$key = preg_replace("/^_/",".",$key);
	$key = preg_replace("/_a:/"," a:",$key);
	if ($value) {
		if (get_magic_quotes_gpc()) {
			$value = stripslashes($value);
		}
		$style_vars[$key] = $value;
		if ($key == "extra_css") {
			$css_file .= $value;
		} else {
			$css_file .= "$key {\r\n$value\r\n}\r\n";
		}
	}
}

$_POST['style_name'] = preg_replace("/ +/","_",$_POST['style_name']);

$string = $ubbt_lang['STYLE_UPDATED'];

if (!$style) {
	$query = "
		insert into {$config['TABLE_PREFIX']}STYLES
		(STYLE_NAME,STYLE_IS_ACTIVE)
		values
		( ? , ? )
	";
	$dbh->do_placeholder_query($query,array($_POST['style_name'],1),__LINE__,__FILE__);
	$query = "
		select last_insert_id()
	";
	$sth = $dbh->do_query($query);
	list($style) = $dbh->fetch_array($sth);
	$string = $ubbt_lang['STYLE_ADDED'];
} else {
	$style = $_POST['style'];
	unlink("{$config['FULL_PATH']}/styles/{$real_style_name}_{$real_last_edit}.css");
}

$now = time();
$css_name = "{$_POST['style_name']}_{$now}.css";

$new_style_array = <<<THE_YELLOW_BRICK_ROAD
<?php
\$style_array = array(
	"id" => '$style',
	"general" => "general/{$_POST['general_images']}",
	"avatars" => "avatars/{$_POST['avatar_images']}",
	"forumimages" => "forumimages/{$_POST['forum_images']}",
	"graemlins" => "graemlins/{$_POST['graemlin_images']}",
	"icons" => "icons/{$_POST['icon_images']}",
	"markup_panel" => "markup_panel/{$_POST['markup_images']}",
	"news" => "news/{$_POST['news_images']}",
	"mood" => "moods/{$_POST['mood_images']}",
	"wrappers" => {$_POST['wrapper']},
	"css" => "$css_name"
);
?>
THE_YELLOW_BRICK_ROAD;

$img_array = array(
	"general" => "general/{$_POST['general_images']}",
	"avatars" => "avatars/{$_POST['avatar_images']}",
	"forumimages" => "forumimages/{$_POST['forum_images']}",
	"graemlins" => "graemlins/{$_POST['graemlin_images']}",
	"icons" => "icons/{$_POST['icon_images']}",
	"news" => "news/{$_POST['news_images']}",
	"mood" => "moods/{$_POST['mood_images']}",
	"markup_panel" => "markup_panel/{$_POST['markup_images']}"
);

$check = lock_and_write("{$config['FULL_PATH']}/styles/$style.php",$new_style_array);
if ($check == "no_write") {
	$admin->error($ubbt_lang['NO_WRITE_STYLE']);
} // end if
@chmod("{$config['FULL_PATH']}/styles/$style.php",0666); 

$check = lock_and_write("{$config['FULL_PATH']}/styles/$css_name",$css_file);
if ($check == "no_write") {
	$admin->error($ubbt_lang['NO_WRITE_STYLE']);
} // end if
@chmod("{$config['FULL_PATH']}/styles/$css_name",0666); 

$query = "
	update {$config['TABLE_PREFIX']}STYLES
	set STYLE_NAME = ?,
			STYLE_IMG = ?,
			STYLE_EDITED_TIME = ?,
			STYLE_VARS = ?,
			STYLE_WRAPPERS = ?
	where STYLE_ID = ?
";
$dbh->do_placeholder_query($query,array($_POST['style_name'],serialize($img_array),$now,serialize($style_vars),$_POST['wrapper'],$style),__LINE__,__FILE__);

admin_log("UPDATE_STYLE","{$_POST['style_name']}");

build_forum_cache();

$admin->redirect($string,"{$config['BASE_URL']}/admin/styles.php?returntab=0",$ubbt_lang['STYLE_F_LOC']);

?>
