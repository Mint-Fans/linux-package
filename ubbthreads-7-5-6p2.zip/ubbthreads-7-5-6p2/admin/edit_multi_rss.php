<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/edit_multi_rss.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
error_reporting(7);

// -------------
// Get the input
$returntab = get_input("returntab","get");
$feed = get_input("feed","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("");

$admin = new Admin;

$admin->doAuth();

if (!$feed) {
	$tab_title = $ubbt_lang['TAB_TITLE_NEW'];
	$feed_forums = array();
	$button = $ubbt_lang['ADD_FEED'];
	$feed_body = 0;
	$items = 10;
	$feed_cache = 10;
	$feed_active = "checked=\"checked\"";
} else {
	$tab_title = $ubbt_lang['TAB_TITLE_EDIT'];
	$button = $ubbt_lang['UPDATE_FEED'];
	$query = "
		select FEED_IS_ACTIVE,FEED_FORUM_ARRAY,FEED_NAME,FEED_TYPE,FEED_INCLUDE_BODY,FEED_CACHE_TIME,FEED_ITEMS
		from {$config['TABLE_PREFIX']}RSS_FEEDS
		where FEED_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($feed),__LINE__,__FILE__);
	list($active,$source,$feed_name,$feed_type,$feed_body,$feed_cache,$items) = $dbh->fetch_array($sth);
	if (!$feed_cache) $feed_cache = 600;
	$feed_cache = $feed_cache / 60;
	if (!$feed_body) $feed_body = 0;
	if (!$items) $items = 10;
	$feed_forums = unserialize($source);
	if ($active) {
		$feed_active="checked=\"checked\"";
	} // end if
	if ($feed_type == "posts") {
		$posts = "selected=\"selected\"";
	} else {
		$topics = "selected=\"selected\"";
	}
} // end if

$tabs = array(
	"$tab_title" => ""
);

$admin->setCurrentMenu($ubbt_lang['RSS']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['TAB_TITLE']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);


if (in_array("allforums",$feed_forums)) {
	$selected = "selected=\"selected\"";
} // end if
$sourcelist .= "<option value=\"allforums\" $selected>{$ubbt_lang['ALL_FORUMS']}</option>";

include("{$config['FULL_PATH']}/cache/forum_cache.php");
if (!sizeof($tree)) {
	list($tree,$style_cache,$lang_cache) = build_forum_cache();
}
		
$category = "";
$forums = 0;
foreach($tree['categories'] as $cat => $cat_title) {
	$category = "";
	$forums = 0;
	$category .= "<option value=\"category\">$cat_title ------</option>";
	if (!isset($tree[$cat])) continue;
	foreach($tree[$cat] as $forum_id => $forum_title) {
		$selected = "";
		if (in_array($forum_id,$feed_forums)) $selected = "selected=\"selected\"";
		$category .= "<option value=\"$forum_id\" $selected>$forum_title</option>";
		$forums++;
	}
	if ($forums) $sourcelist .= $category;
}
		




// Include the template
include("../templates/default/admin/edit_multi_rss.tmpl");

//$admin->createBottomTabs($bottomtabs,0);

$admin->sendFooter();
?>
