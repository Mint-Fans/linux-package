<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/editwrapper.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = 0;
$wrapper = get_input("wrapper","get","int");
$new = get_input("new","get","int");

// -----------------
// Get the user info
$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$tabs = array(
	"{$ubbt_lang['EDIT_WRAPPER']}" => "",
);

$admin->setCurrentMenu($ubbt_lang['STYLES']);
$admin->setReturnTab(0);
$admin->setPageTitle($ubbt_lang['EDIT_WRAPPER']);
$admin->sendHeader();
$admin->createTopTabs($tabs,0);

$name = "";
$open = "";
$close = "";
// Get the current wrappers
include("{$config['FULL_PATH']}/styles/wrappers.php");
if ($wrapper || $wrapper == "0") {
	$name = $wrappers[$wrapper]['name'];
	$open = $wrappers[$wrapper]['open'];
	$close = $wrappers[$wrapper]['close'];
} // end if

// Include the template
include("../templates/default/admin/editwrapper.tmpl");

$bottomtabs = array(
	"{$ubbt_lang['DELETE_WRAPPER']}" => "javascript:void(0);\" onclick=\"checkDelete($wrapper);"
);
$admin->createBottomTabs($bottomtabs,0);

$admin->sendFooter();
?>
