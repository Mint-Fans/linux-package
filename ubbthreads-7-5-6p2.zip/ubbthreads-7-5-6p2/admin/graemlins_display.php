<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/image_display.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();


// Get the graemlins
$query = "
SELECT GRAEMLIN_ID,GRAEMLIN_IMAGE,GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IS_ACTIVE,GRAEMLIN_ORDER
FROM   {$config['TABLE_PREFIX']}GRAEMLINS
";
$sth = $dbh -> do_query($query,__LINE__,__FILE__);
$i=0;
while (list($number,$image,$markup,$smiley,$active,$order) = $dbh -> fetch_array($sth)) {
	$graemlins[$i]['entry'] = $number;
	$graemlins[$i]['image'] = $image;
	$graemlins[$i]['markup'] = $markup;
	$graemlins[$i]['smiley'] = $smiley;
	$graemlins[$i]['disabled'] = "";
	$graemlins[$i]['hidden'] = "";
	$graemlins[$i]['delete'] = "<input type=\"checkbox\" name=\"delete-$i\" value=\"$number\" />";
	$checked = "";
	if ($active) {
		$checked = "checked=\"checked\"";
	}
	$graemlins[$i]['active'] = "<input type=\"checkbox\" $checked name=\"active-$i\" value=\"1\" />";
	$graemlins[$i]['markup'] = "<input type=\"text\" size=\"35\" name=\"markup-$i\" value=\"$markup\" />";
	$graemlins[$i]['smiley'] = "<input type=\"text\" size=\"3\" name=\"smiley-$i\" value=\"$smiley\" />";
	
	if ($order == '0') {
		$order = $number;
	}
	
	$graemlins[$i]['order'] = "<input type=\"text\" size=\"3\" name=\"order-$i\" value=\"$order\" />";
	$i++;
}

$tabs = array(
	"{$ubbt_lang['ICON_DISP']}" => "{$config['BASE_URL']}/admin/icons_display.php?returntab=0",
	"{$ubbt_lang['GRAEMLIN_DISP']}" => "",
	"{$ubbt_lang['AV_DISP']}" => "{$config['BASE_URL']}/admin/avatars_display.php?returntab=2",
	"{$ubbt_lang['F_IMAGES']}" => "{$config['BASE_URL']}/admin/fimages_display.php?returntab=3",
	"{$ubbt_lang['NEWS_IMAGES']}" => "{$config['BASE_URL']}/admin/newsimages_display.php?returntab=4",
        "{$ubbt_lang['MOOD_DISP']}" => "{$config['BASE_URL']}/admin/mood_display
.php?returntab=5" 
);

$admin->setCurrentMenu($ubbt_lang['IM_IC']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['IM_IC']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
include("../templates/default/admin/graemlins_display.tmpl");

$bottomtabs = array(
	"{$ubbt_lang['NEW_GRAEMLIN']}" => "{$config['BASE_URL']}/admin/addgraemlin.php"
);
$admin->createBottomTabs($bottomtabs,1);


$admin->sendFooter();
?>
