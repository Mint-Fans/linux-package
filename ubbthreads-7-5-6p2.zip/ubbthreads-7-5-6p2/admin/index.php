<html>
<head>
<meta http-equiv="refresh" content="0;URL=login.php" />
</head>
<body>
</body>
</html>
