<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

require("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/languageeditor.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();



// get the input
$returntab = get_input("returntab","post");
$language = get_input("language","both");
$filename = get_input("filename","both");
$searchstring = get_input("searchstring","both");
$searchfilename = get_input("searchfilename","both");
$searchstring = str_replace("/","\\/",$searchstring);
$searchstring = urldecode($searchstring);
// if filename is set then we forward them to the editor for that file
if ($filename) {
	header("Location: {$config['FULL_URL']}/admin/languageeditor2.php?language=$language&filename=$filename");
	exit;
}
if (strlen($searchstring) < 3) {
	$admin->error($ubbt_lang['SEARCH_LEN']);
}

// Now we need to search the language files:
$currlang = $ubbt_lang;
unset($ubbt_lang);
$dir = opendir("../languages/$language");
$matches = array();
$i=0;
while ($file = readdir($dir)) {
	if ($file == "." || $file == ".." || $file == "admin" || $file == "oldadmin" || !preg_match("#php$#", $file)) { continue; }
	if (($searchfilename != "all") && ($searchfilename != $file)) {
		continue;
	}
	@include("../languages/$language/$file");
	if (!is_array($ubbt_lang)) {
		$ubbt_lang = array();
	}
	while(list($key,$value) = each($ubbt_lang)) {
		if (preg_match("/$searchstring/i",$value)) {
			$matches[$i]['key'] = $key;
			$matches[$i]['value'] = $value;
			$matches[$i]['file'] = $file;
			$i++;
		}
	}
	unset($ubbt_lang);
}

$dir = opendir("{$config['FULL_PATH']}/languages/$language/admin");
while ($file = readdir($dir)) {
	if ($file == "." || $file == ".." ) { continue; }
	if (($searchfilename != "all") && ($searchfilename != $file)) {
		continue;
	}
	@include("../languages/$language/admin/$file");
	while(@list($key,$value) = each($ubbt_lang)) {
		if (preg_match("/$searchstring/",$value)) {
			$matches[$i]['key'] = $key;
			$matches[$i]['value'] = $value;
			$matches[$i]['file'] = "admin/$file";
			$i++;
		}
	}
	unset($ubbt_lang);
}

$ubbt_lang = $currlang;

if (!sizeof($matches)) {
	$admin->error($ubbt_lang['NO_MATCHES']);
}
$ubbt_lang = $currlang;

// urlencode the searchstuff if necessary
$searchstring = urlencode($searchstring);
$searchfilename = urlencode($searchfilename);

// Create the Page
$tabs = array(
	"{$ubbt_lang['LANG_EDIT']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['LANGS']);
$admin->setParentTitle($ubbt_lang['LANGS'],"availablelangs.php");
$admin->setPageTitle($ubbt_lang['LANG_EDIT']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/languageeditor.tmpl");

$admin->sendFooter();
?>
