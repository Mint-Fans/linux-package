<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

require("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/languageeditor2.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// get the input
$returntab = 1;
$language = get_input("language","both");
$filename = get_input("filename","both");
$keyhigh = get_input("keyhigh","both");
$searchstring = get_input("searchstring","both");
$searchfilename = get_input("searchfilename","both");

$tempfile = file("{$config['FULL_PATH']}/languages/$language/$filename");

// We need to grab the charset for the language file we are
// going to edit
require ("../languages/$language/generic.php");
$charset = $ubbt_lang['CHARSET'];
require ("../languages/{$config['LANGUAGE']}/generic.php");

// -----------------------------------------------
// We need to each language file entry on one line
$langarray = check_lang_file("{$config['FULL_PATH']}/languages/$language/$filename");

$stringlist = "";
while (list($key,$value) = each($langarray)) {

	if ($key == "searchfilename")  { continue; }
	// -----------------------------------------------------------
	// Let's see how many rows we should have for these text areas
	if (!preg_match("/\n/",$value)) {
		$valuelength = strlen($value);
		$rows = intval($valuelength / 50);

	}
	else {
		$rows = 1;
		$breaks = preg_split("#\n#",$value);
		for ($i=0;$i<sizeof($breaks);$i++) {
			$rows = $rows + 1;
			$valuelength = strlen($breaks[$i]);
			$morerows = intval($valuelength / 50);
			$rows = $rows + $morerows;
		}
	}
	if ($rows < 2) { $rows = 2; }
	$value = htmlspecialchars($value);
	$keyprint = $key;
	if ($keyhigh == $key) {
		$keyprint = sprintf('<span class="msbad">%s</span>', $key);
	}
	$stringlist .= "<tr><td valign=\"top\" class=\"stdautorow colored-row autobottom\"><a name=\"$key\"></a>$keyprint</td><td class=\"stdautorow colored-row autobottom\"><textarea name=\"$key\" rows=\"$rows\" cols=\"50\" class=\"formboxes\">$value</textarea></td></tr>\n";
}

$newstrings = "";

for ($i=0;$i<5;$i++) {
	$newstrings .= "<tr><td valign=\"top\" class=\"stdautorow colored-row autobottom\"><input type=\"text\" name=\"key$i\" class=\"formboxes\"></td><td class=\"stdautorow colored-row autobottom\"><textarea name=\"string$i\" rows=\"3\" cols=\"50\" class=\"formboxes\"></textarea></td></tr>\n";
}

$searchstring = urlencode($searchstring);
$searchfilename = urlencode($searchfilename);


$tabs = array(
	"{$ubbt_lang['LANG_EDIT']}" => ""
);

function check_lang_file($file, $search = "") {
	require($file);
	return $ubbt_lang;
}

// Create the Page
$admin->setCurrentMenu($ubbt_lang['LANGS']);
$admin->setParentTitle($ubbt_lang['LANGS'],"availablelangs.php");
$admin->setPageTitle($ubbt_lang['LANG_EDIT']);
$admin->sendHeader($charset);
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/languageeditor2.tmpl");

$admin->sendFooter();
?>
