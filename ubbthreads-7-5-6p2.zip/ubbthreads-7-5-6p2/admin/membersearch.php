<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/membersearch.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_TIME_OFFSET,USER_TIME_FORMAT,USER_TOPIC_VIEW_TYPE");
$html = new html;

$admin = new Admin;

$admin->doAuth(array("EDIT_USERS"));

$newsearch = get_input("newsearch","both");
$page = get_input("page","both");

$savedsearch = get_input("savedsearch","get");
$deletesearch = get_input("deletesearch","get");

if ($deletesearch) {
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}MEMBER_SEARCHES
		WHERE MEMBER_SEARCH_ID='$deletesearch'
	";
	$dbh->do_query($query,__LINE__,__FILE__);
	$admin->redirect($ubbt_lang['M_DELETED'],"{$config['BASE_URL']}/admin/membermanage.php",$ubbt_lang['F_LOC']);
	exit;
}


$removedlist = "";
if ($newsearch || $savedsearch) {
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}ADMIN_SEARCHES
		WHERE USER_ID = '{$user['USER_ID']}'
		AND ADMIN_SEARCH_TYPE = 'member'
	";
	$dbh -> do_query($query,__LINE__,__FILE__);
}
else {
	$query = "
		SELECT ADMIN_SEARCH_TERMS,ADMIN_SEARCH_REMOVED_RESULTS
		FROM {$config['TABLE_PREFIX']}ADMIN_SEARCHES
		WHERE USER_ID = '{$user['USER_ID']}'
		AND ADMIN_SEARCH_TYPE = 'member'
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	list($extra,$removedresults) = $dbh->fetch_array($sth);
	if ($removedresults) {
		$removedlist = "AND t1.USER_ID NOT IN ($removedresults)";
	}
}

// Executing a saved search?
if ($savedsearch) {
	$query = "
		SELECT MEMBER_SEARCH_QUERY
		FROM {$config['TABLE_PREFIX']}MEMBER_SEARCHES
		WHERE MEMBER_SEARCH_ID='$savedsearch'
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	list($extra) = $dbh->fetch_array($sth);
}

// -------------
// Get the input
$login_name = get_input("login_name","post");
$display_name = get_input("display_name","post");
$email = get_input("email","post");
$user_number = get_input("user_number","post");
$regon = get_input("regon","post");
$regyear = get_input("regyear","post");
$regmonth = get_input("regmonth","post");
$regday = get_input("regday","post");
$isbanned = get_input("isbanned","post");
$hasposts = get_input("hasposts","post");
$postcount = get_input("postcount","post");
$postcount_amount = get_input("postcount_amount","post");
$fieldsearch = get_input("fieldsearch","post");
$under13 = get_input("under13","post");
$regip = get_input("regip","post");
$postip = get_input("postip","post");
$lastposton = get_input("lastposton","post");
$lastpostyear = get_input("lastpostyear","post");
$lastpostmonth = get_input("lastpostmonth","post");
$lastpostday = get_input("lastpostday","post");
$orderby = get_input("orderby","post");
$ascorder = get_input("ascorder","post");
$laston = get_input("laston","post");
$lastyear = get_input("lastyear","post");
$lastmonth = get_input("lastmonth","post");
$lastday = get_input("lastday","post");
$saveit = get_input("saveit","post");
$savetitle = get_input("savetitle","post");

// Setup the limit
if (!$page) {
	$limit = "LIMIT 25";
	$resultstart = 1;
}
else {
	$limit =  "LIMIT " . ($page * 25) . ",26";
	$resultstart = ($page * 25) + 1;
}


if (!$orderby) {
	$orderby = "t1.USER_DISPLAY_NAME";
}
if (!$ascorder) {
	$ascorder = "ASC";
}

$orderby = "$orderby $ascorder";

$nomods = "";
if ($user['USER_MEMBERSHIP_LEVEL'] == "Moderator") {
	$nomods = "and t1.USER_MEMBERSHIP_LEVEL = 'User'";
} // end if

if ($user_number && ($user_number != '1')) {
	$query = "
		SELECT t1.USER_ID
		FROM {$config['TABLE_PREFIX']}USERS as t1
		WHERE t1.USER_ID='$user_number'
		$nomods
	";
	$sth = $dbh -> do_query($query,__LINE__,__FILE__);
	list($num) = $dbh -> fetch_array($sth);
	if ($num) {
		header("Location: {$config['FULL_URL']}/admin/showuser.php?uid=$user_number");
	}
	else {
		$admin->error($ubbt_lang['NO_USER_NUMBER']);
	}
}

if ($newsearch) {
	if ($login_name) {
		$login_name = addslashes($login_name);
		$extra .= " and t1.USER_LOGIN_NAME LIKE '%$login_name%' ";
	}

	if ($display_name) {
		$display_name = addslashes($display_name);
		$extra .= " and t1.USER_DISPLAY_NAME LIKE '%$display_name%' ";
	}

	if ($email) {
		$email = addslashes($email);
		$extra .= " and t2.USER_REAL_EMAIL LIKE '%$email%' ";
	}

	if ($regyear && $regmonth && $regday) {
		if ($regon == "b") {
			$before = mktime(0,0,0,$regmonth,$regday,$regyear);
			$extra = " and t1.USER_REGISTERED_ON < '$before' ";
		}
		if ($regon == "o") {
			$start = mktime(0,0,0,$regmonth,$regday,$regyear);
			$end = mktime(23,59,59,$regmonth,$regday,$regyear);
			$extra = " and t1.USER_REGISTERED_ON > '$start' AND t1.USER_REGISTERED_ON < '$end' ";
		}
		if ($regon == "a") {
			$end = mktime(23,59,59,$regmonth,$regday,$regyear);
			$extra = " and t1.USER_REGISTERED_ON > '$end' ";
		}
	}

	if ($isbanned) {
		if ($isbanned == "y") {
			$extra .= " and t1.USER_IS_BANNED = '1' ";
		}
		else {
			$extra .= " and t1.USER_IS_BANNED = '0' ";
		}
	}

	if ($hasposts) {
		if ($hasposts == "y") {
			$extra .= " and t2.USER_TOTAL_POSTS > '0' ";
		}
		else {
			$extra .= " and t2.USER_TOTAL_POSTS = '0' ";
		}
	}

	if ($postcount) {
		if ($postcount == "m") {
			$extra .= " and t2.USER_TOTAL_POSTS > '$postcount_amount' ";
		}
		elseif ($postcount == "e") {
			$extra .= " and t2.USER_TOTAL_POSTS = '$postcount_amount' ";
		}
		elseif ($postcount == "l") {
			$extra .= " and t2.USER_TOTAL_POSTS < '$postcount_amount' ";
		}
	}

	if ($fieldsearch) {
		$fieldsearch = addslashes($fieldsearch);
		$extra .= " and (t2.USER_OCCUPATION LIKE '%$fieldsearch%' OR t2.USER_LOCATION LIKE '%$fieldsearch%' OR t2.USER_HOBBIES LIKE '%$fieldsearch%' OR t2.USER_EXTRA_FIELD_1 LIKE '%$fieldsearch%' OR t2.USER_EXTRA_FIELD_2 LIKE '%$fieldsearch%'  OR t2.USER_EXTRA_FIELD_3 LIKE '%$fieldsearch%'  OR t2.USER_EXTRA_FIELD_4 LIKE '%$fieldsearch%'  OR t2.USER_EXTRA_FIELD_5 LIKE '%$fieldsearch%') ";
	}

	if ($under13) {
		if ($under13 == "y") {
			$extra .= " and t1.USER_IS_UNDERAGE = '1' ";
		}
		else {
			$extra .= " and t1.USER_IS_UNDERAGE <> '1' ";
		}
	}

	if ($regip) {
		$regip = addslashes($regip);
		$extra .= " and t1.USER_REGISTRATION_IP LIKE '%$regip%' ";
	}

	if ($postip) {
		$regip = addslashes($postip);
		$extra .= " and t3.USER_LAST_IP LIKE '%$postip%' ";
	}

	if ($lastpostyear && $lastpostmonth && $lastpostday) {
		if ($lastposton == "b") {
			$before = mktime(0,0,0,$lastpostmonth,$lastpostday,$lastpostyear);
			$extra = " and t3.USER_LAST_POST_TIME < '$before' ";
		}
		if ($lastposton == "o") {
			$start = mktime(0,0,0,$lastpostmonth,$lastpostday,$lastpostyear);
			$end = mktime(23,59,59,$lastpostmonth,$lastpostday,$lastpostyear);
			$extra = " and t3.USER_LAST_POST_TIME > '$start' AND t3.USER_LAST_POST_TIME < '$end' ";
		}
		if ($lastposton == "a") {
			$end = mktime(23,59,59,$lastpostmonth,$lastpostday,$lastpostyear);
			$extra = " and t3.USER_LAST_POST_TIME > '$end' ";
		}
	}

	if ($lastyear && $lastmonth && $lastday) {
		if ($laston == "b") {
			$before = mktime(0,0,0,$lastmonth,$lastday,$lastyear);
			$extra .= " and t3.USER_LAST_VISIT_TIME < '$before' ";
		}
		if ($laston == "o") {
			$start = mktime(0,0,0,$lastmonth,$lastday,$lastyear);
			$end = mktime(23,59,59,$lastmonth,$lastday,$lastyear);
			$extra .= " and t3.USER_LAST_VISIT_TIME > '$start' AND t3.USER_LAST_VISIT_TIME < '$end' ";
		}
		if ($laston == "a") {
			$end = mktime(23,59,59,$lastmonth,$lastday,$lastyear);
			$extra .= " and t3.USER_LAST_VISIT_TIME > '$end' ";
		}
	}

	// Grab the groups
	$query = "
		SELECT GROUP_ID,GROUP_NAME
		FROM {$config['TABLE_PREFIX']}GROUPS
		ORDER BY GROUP_ID
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	$g_inlist = "";
	while(list($id,$name) = $dbh->fetch_array($sth)) {
		if ($user['USER_MEMBERSHIP_LEVEL'] == "Moderator" && $id < 3) continue;
		$gcheck = "Group-$id";
		if (isset($_POST[$gcheck]) || isset($_GET[$gcheck])) {
			$g_inlist .= "$id,";
		}
	}
	$g_inlist = preg_replace("/,$/","",$g_inlist);
	if ($g_inlist) {
		$extra .= " and t4.GROUP_ID IN ($g_inlist) ";
	}
	$extra .= "GROUP BY t1.USER_ID\nORDER BY $orderby";

}



// Save the query
if ($saveit) {
	$savetitle = addslashes($savetitle);
	$saved = addslashes($extra);
	$insert = "
		INSERT INTO {$config['TABLE_PREFIX']}MEMBER_SEARCHES
		(MEMBER_SEARCH_TITLE,MEMBER_SEARCH_QUERY)
		VALUES
		('$savetitle','$saved')
	";
	$dbh->do_query($insert,__LINE__,__FILE__);
}

$query = "
	select	COUNT(t1.USER_ID)
	from	{$config['TABLE_PREFIX']}USERS as t1,
		{$config['TABLE_PREFIX']}USER_PROFILE as t2,
		{$config['TABLE_PREFIX']}USER_DATA as t3,
		{$config['TABLE_PREFIX']}USER_GROUPS as t4
	WHERE t1.USER_ID <> '1'
	and t1.USER_ID = t2.USER_ID
	and t1.USER_ID = t3.USER_ID
	and t1.USER_ID = t4.USER_ID
	$removedlist
	$nomods
	$extra
";

$sth = $dbh -> do_query($query,__LINE__,__FILE__);
$totalresults = $dbh->total_rows($sth);


$resultstop = $resultstart + 24;
if ($resultstop > $totalresults) {
	$resultstop = $totalresults;
}

$resultprint = sprintf($ubbt_lang['RESULT_SET'],$resultstart,$resultstop,$totalresults);

// Setup the pages
$totalpages = ceil($totalresults/25);
$pageprint = "";
for ($i=0;$i<$totalpages;$i++) {
	if ($i == $page) {
		$pageprint .= ($i + 1) . " ";
	}
	else {
		$pageprint .= "<a href=\"membersearch.php?page=$i\">" . ($i + 1) . "</a> ";
	}
}

// Now do the actual query that we'll loop through
$query = "
	SELECT t1.USER_LOGIN_NAME,t1.USER_MEMBERSHIP_LEVEL,t1.USER_DISPLAY_NAME,t2.USER_REAL_EMAIL,t1.USER_ID,t2.USER_TOTAL_POSTS,t1.USER_REGISTRATION_IP,t1.USER_IS_BANNED,t1.USER_IS_UNDERAGE,t2.USER_BIRTHDAY,t1.USER_REGISTERED_ON,t3.USER_LAST_POST_TIME,t3.USER_LAST_IP,t3.USER_LAST_VISIT_TIME,t3.USER_LAST_POST
	FROM {$config['TABLE_PREFIX']}USERS as t1,
	{$config['TABLE_PREFIX']}USER_PROFILE as t2,
	{$config['TABLE_PREFIX']}USER_DATA as t3,
	{$config['TABLE_PREFIX']}USER_GROUPS as t4
	WHERE t1.USER_ID <> '1'
	and t1.USER_ID = t2.USER_ID
	and t1.USER_ID = t3.USER_ID
	and t1.USER_ID = t4.USER_ID
	$removedlist
	$nomods
	$extra
	$limit
";
$sth = $dbh -> do_query($query,__LINE__,__FILE__);
$results = $dbh->total_rows($sth);
$i=0;

// Save the query for later us
if ($newsearch || $savedsearch) {
	$saved = addslashes($extra);
	$query = "
		REPLACE INTO {$config['TABLE_PREFIX']}ADMIN_SEARCHES
		(USER_ID,ADMIN_SEARCH_TERMS,ADMIN_SEARCH_TYPE)
		VALUES
		('{$user['USER_ID']}','$saved','member')
	";
	$dbh -> do_query($query,__LINE__,__FILE__);
}


// Escape the query if we need to do an action on all results
while(list($lname,$ustatus,$dname,$email,$number,$totalposts,$regip,$banned,$coppauser,$birthday,$registered,$lastposttime,$lastpostip,$laston,$lastpost) = $dbh -> fetch_array($sth)) {

	if ($i % 2) {
		$result[$i]['color'] = "colored-row";
	}
	else {
		$result[$i]['color'] = "";
	}
	$result[$i]['lname'] = $lname;
	$result[$i]['ustatus'] = $ustatus;
	$result[$i]['dname'] = $dname;
	$result[$i]['email'] = $email;
	$result[$i]['number'] = $number;
	$result[$i]['totalposts'] = $totalposts;
	$result[$i]['regip'] = $regip;
	if ($banned) {
		$result[$i]['banned'] = "<span class=\"msbad\">{$ubbt_lang['YES_TEXT']}</span>";
	}
	else {
		$result[$i]['banned'] = "<span class=\"msgood\">{$ubbt_lang['NO_TEXT']}</span>";
	}
	if ($coppauser) {
		$result[$i]['coppauser'] = "<span class=\"msbad\">{$ubbt_lang['YES_TEXT']}</span>";
	}
	else {
		$result[$i]['coppauser'] = "<span class=\"msgood\">{$ubbt_lang['NO_TEXT']}</span>";
	}
	if ($birthday) {
		$result[$i]['birthday'] = $birthday;
	}
	else {
		$result[$i]['birthday'] = "";
	}
	if ($registered) {
		$result[$i]['registered'] = $html->convert_time($registered,$user['USER_TIME_OFFSET'],$user['USER_TIME_FORMAT']);
	}
	else {
		$result[$i]['registered'] = "";
	}
	if (!$laston) {
		$result[$i]['laston'] = "<span class=\"msbad\">{$ubbt_lang['NEVER']}</span>";
	}
	else {
		$laston = $html->convert_time($laston,$user['USER_TIME_OFFSET'],$user['USER_TIME_FORMAT']);
		$result[$i]['laston'] = "$laston";
	}
	if ($lastposttime) {
		$lastposttime = $html->convert_time($lastposttime,$user['USER_TIME_OFFSET'],$user['USER_TIME_FORMAT']);
		$result[$i]['lastposttime'] = "<a href=\"" . make_ubb_url("ubb=show{$user['USER_TOPIC_VIEW_TYPE']}&Number=$lastpost#Post$lastpost", "", false) . "\" target=\"_blank\">$lastposttime</a>";
	}
	else {
		$result[$i]['lastposttime'] = "";
	}
	$result[$i]['lastpostip'] = $lastpostip;
	$i++;

}

$tabs = array(
	"{$ubbt_lang['RESULTS']}" => ""
);


// Include the template
if ($results) {
	$admin->setCurrentMenu($ubbt_lang['MEM_MAN']);
	$admin->setParentTitle($ubbt_lang['MEM_MAN'],"membermanage.php");
	$admin->setPageTitle($ubbt_lang['RESULTS']);
	$admin->sendHeader();
	$admin->createTopTabs($tabs);
	include("../templates/default/admin/membersearch.tmpl");
}
else {
	$admin->redirect($ubbt_lang['NO_RESULTS'],"{$config['BASE_URL']}/admin/membermanage.php",$ubbt_lang['F_LOC']);
}

$admin->sendFooter();
?>
