<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/portal_settings.php");

// Get the input
$returntab = get_input("returntab","both");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$tabs = array(
	"{$ubbt_lang['PORTAL_SETTINGS']}" => "",
);

$main_on = "";
if (isset($config['ENABLE_MAIN_PORTAL']) && $config['ENABLE_MAIN_PORTAL']) {
	$main_on = "checked=\"checked\"";
}


(file_exists("{$config['FULL_PATH']}/cache/forum_cache.php")) ? include("{$config['FULL_PATH']}/cache/forum_cache.php") : $tree = array() ;
if (!sizeof($tree)) {
	list($tree,$style_cache,$lang_cache) = build_forum_cache();
}
		
$sourcelist = "";
$category = "";
$forums = 0;

$chosen = explode(",",$config['PORTAL_NEWS_FORUMS']);
foreach($tree['categories'] as $cat => $cat_title) {
	$category = "";
	$forums = 0;
	$category .= "<option value=\"category\">$cat_title ------</option>";
	if (!isset($tree[$cat])) continue;
	foreach($tree[$cat] as $forum_id => $forum_title) {
		$selected = "";
		if (in_array($forum_id,$chosen)) {
			$selected = "selected=\"selected\"";
		} // end if
		$category .= "<option value=\"$forum_id\" $selected>$forum_title</option>";
		$forums++;
	}
	if ($forums) $sourcelist .= $category;
}

$excludelist = "";
$exclude = explode(",",$config['EXCLUDE_POPULAR']);
foreach($tree['categories'] as $cat => $cat_title) {
	$category = "";
	$forums = 0;
	$category .= "<option value=\"category\">$cat_title ------</option>";
	if (!isset($tree[$cat])) continue;
	foreach($tree[$cat] as $forum_id => $forum_title) {
		$selected = "";
		if (in_array($forum_id,$exclude)) {
			$selected = "selected=\"selected\"";
		} // end if
		$category .= "<option value=\"$forum_id\" $selected>$forum_title</option>";
		$forums++;
	}
	if ($forums) $excludelist .= $category;
}

// Get the cache time for portal boxes
$query = "
	select PORTAL_CACHE,PORTAL_NAME
	from {$config['TABLE_PREFIX']}PORTAL_BOXES
	where PORTAL_CUSTOM = '0'
	order by PORTAL_NAME
";
$sth = $dbh->do_query($query);
while(list($time,$name) = $dbh->fetch_array($sth)) {
	$cache[$name] = $time / 60;
} // end while

$right_on = "";
$left_on = "";
if ($config['DISABLE_LEFT']) {
	$left_on = "checked=\"checked\"";
} // end if

if ($config['DISABLE_RIGHT']) {
	$right_on = "checked=\"checked\"";
} // end if

$right_only = "";
$left_only = "";
if ($config['RIGHT_COLUMN_PORTAL']) {
	$right_portal_only = "checked=\"checked\"";
}
if ($config['LEFT_COLUMN_PORTAL']) {
	$left_portal_only = "checked=\"checked\"";
}

// Create the Page
$admin->setCurrentMenu($ubbt_lang['PORTAL_SETTINGS']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['PORTAL_SETTINGS']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/portal_settings.tmpl");

$admin->sendFooter();
?>
