<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/savemovethreads.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = 0;
$move = get_input("move","post");
$topic = get_input("topic","post");
$handle = get_input("handle","post");
$totalpages = get_input("totalpages","post");
$target = get_input("target","post");
$total = get_input("total","post");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Retrieve removed results from database
$query = "
	SELECT ADMIN_SEARCH_REMOVED_RESULTS
	FROM {$config['TABLE_PREFIX']}ADMIN_SEARCHES
	WHERE ADMIN_SEARCH_TYPE='topicmove'
	AND USER_ID='{$user['USER_ID']}'
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
list ($removed) = $dbh->fetch_array($sth);

if ($removed) {
	$removed = unserialize($removed);
}
else {
	$removed = array();
}

$pagelist = "";
for ($i=1;$i<=$totalpages;$i++) {
	$pagelist .= "<a href=\"{$config['BASE_URL']}/admin/selectmovethreads.php?manual=1&target=$target&handle=$handle&p=$i\">$i</a> ";
}

// Did we remove any topics?
for ($i=0;$i<sizeof($topic);$i++) {
	if (!isset($move[$i])) {
		$removed[$topic[$i]] = '1';
	}
}

// Update the removed results
$removed = addslashes(serialize($removed));
$query = "
	UPDATE {$config['TABLE_PREFIX']}ADMIN_SEARCHES
	SET ADMIN_SEARCH_REMOVED_RESULTS = '$removed'
	WHERE ADMIN_SEARCH_TYPE='topicmove'
	AND USER_ID='{$user['USER_ID']}'
";
$dbh->do_query($query,__LINE__,__FILE__);

$tabs = array(
	"{$ubbt_lang['SELECT']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['MOVE_THREADS']);
$admin->setReturnTab($returntab);
$admin->setParentTitle($ubbt_lang['MOVE_THREADS'],"movethreads.php");
$admin->setPageTitle($ubbt_lang['SELECT']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
include("../templates/default/admin/savemovethreads.tmpl");

$admin->sendFooter();
?>
