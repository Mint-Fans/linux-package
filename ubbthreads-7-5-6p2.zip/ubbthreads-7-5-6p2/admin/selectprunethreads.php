<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/selectprunethreads.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
$html = new html;

// -------------
// Get the input
$returntab = get_input("returntab","both");
$range = get_input("range","post");
$uid = get_input("uid","post");
$manual = get_input("manual","both");
$olderyear = get_input("olderyear","post");
$oldermonth = get_input("oldermonth","post");
$olderday = get_input("olderday","post");
$neweryear = get_input("neweryear","post");
$newermonth = get_input("newermonth","post");
$newerday = get_input("newerday","post");
$source = get_input("source","post");
$firstsearch = get_input("firstsearch","post");
$p = get_input("p","both");
$moved = get_input("moved","post");
$closed = get_input("closed","post");
$reply = get_input("reply","post");
$replyvalue = get_input("replyvalue","post");

if (!$p) { $p = 1; }

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_TIME_FORMAT,USER_TIME_OFFSET");

$admin = new Admin;

$admin->doAuth();

// Build the query if we are coming from the selection page
if ($firstsearch) {

	// Make sure we got a date
	if ((!$olderday || !$oldermonth || !$olderyear) && (!$newerday || !$newermonth || !$neweryear) ){
		$admin->error($ubbt_lang['NO_DATE']);
	}

	$savequery = "
		SELECT t1.TOPIC_ID,t1.POST_ID,t1.TOPIC_SUBJECT,t1.FORUM_ID,t1.TOPIC_CREATED_TIME,t1.TOPIC_LAST_REPLY_TIME,t1.USER_ID,t1.TOPIC_LAST_POSTER_ID,t2.USER_DISPLAY_NAME,t1.TOPIC_LAST_POST_ID
		FROM {$config['TABLE_PREFIX']}TOPICS AS t1,
		{$config['TABLE_PREFIX']}USERS AS t2
		WHERE t1.USER_ID = t2.USER_ID
	";

	// Include moved only
	if ($moved) {
		$savequery .= " AND t1.TOPIC_STATUS = 'M' ";
	}
	// Include closed only
	if ($closed) {
		$savequery .= " AND t1.TOPIC_STATUS = 'C' ";
	}
	// Total # of replies
	if ($reply != "ignore") {
		if ($reply == "more") {
			$savequery .= " AND t1.TOPIC_REPLIES > '$replyvalue' ";
		}
		if ($reply == "exact") {
			$savequery .= " AND t1.TOPIC_REPLIES = '$replyvalue' ";
		}
		if ($reply == "less") {
			$savequery .= " AND t1.TOPIC_REPLIES < '$replyvalue' ";
		}
	}

	// Which forums?
	$inlist = "";
	$all = "";
	for($i=0;$i<sizeof($source);$i++) {
		if ($source[$i] == "allforums") {
			$all = 1;
			break;
		}
		if ($source[$i] == "category") {
			continue;
		}
		$inlist .= "'" . addslashes($source[$i]) ."',";
	}
	if (($inlist) && (!$all)) {
		$inlist = preg_replace("/,$/","",$inlist);
		$inlist = " AND t1.FORUM_ID IN ($inlist) ";
	}
	if ((!$inlist) && (!$all)) {
		$admin->error($ubbt_lang['NO_MATCHES']);
	}
	$savequery .= "$inlist";

	// Specific uid?
	if ($uid) {
		$savequery .= " AND t1.USER_ID = '$uid'";
	}

	// Date range?
	// after, onafter, on, before, onbefore
	$daterange = "";
	$olderthan = "";
	$newerthan = "";
	if ($olderyear && $oldermonth && $olderday) {
		$olderthan = mktime (0,0,0,$oldermonth,$olderday,$olderyear);
		$olderthan = " t1.TOPIC_LAST_REPLY_TIME < '$olderthan' ";
	}
	if ($neweryear && $newermonth && $newerday) {
		$and = "";
		if ($olderthan) { $and = " AND "; }
		$newerthan = mktime (23,59,59,$newermonth,$newerday,$neweryear);
		$newerthan = " $and t1.TOPIC_LAST_REPLY_TIME > '$newerthan' ";
	}
	if ($olderthan || $newerthan) {
		$daterange = " AND ($olderthan $newerthan) ";
	}
	$savequery .= "$daterange";

	// We now need to save this query in the database
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}ADMIN_SEARCHES
		WHERE USER_ID = '{$user['USER_ID']}'
		AND ADMIN_SEARCH_TYPE = 'topicprune'
	";
	$dbh -> do_query($query,__LINE__,__FILE__);

	$query_q = addslashes($savequery);
	$query = "
		INSERT INTO {$config['TABLE_PREFIX']}ADMIN_SEARCHES
		(ADMIN_SEARCH_QUERY,ADMIN_SEARCH_TYPE,USER_ID)
		VALUES
		('$query_q','topicprune','{$user['USER_ID']}')
	";
	$dbh->do_query($query,__LINE__,__FILE__);
	$removed = "";

}
else {
	// Retrieve this query from the database
	$query = "
		SELECT ADMIN_SEARCH_QUERY,ADMIN_SEARCH_REMOVED_RESULTS
		FROM {$config['TABLE_PREFIX']}ADMIN_SEARCHES
		WHERE ADMIN_SEARCH_TYPE='topicprune'
		AND USER_ID='{$user['USER_ID']}'
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	list ($savequery,$removed) = $dbh->fetch_array($sth);
}

// What page are we showing them?
if (!$manual) {

	$savequery = preg_replace("(\n|\r)","",$savequery);
	$savequery = preg_replace("/SELECT (.*?)FROM/","SELECT COUNT(*) FROM",$savequery);
	$sth = $dbh->do_query($savequery,__LINE__,__FILE__);
	list($total) = $dbh->fetch_array($sth);

	if (!$total) {
		$admin->error($ubbt_lang['NO_MATCHES']);
	}

	$directhead = sprintf($ubbt_lang['DIRECT_HEAD'],$total);

	$tabs = array(
		"{$ubbt_lang['SELECT']}" => ""
	);

	$admin->setCurrentMenu($ubbt_lang['PRUNE_THREADS']);
	$admin->setReturnTab($returntab);
	$admin->setParentTitle($ubbt_lang['PRUNE_THREADS'],"prunethreads.php");
	$admin->setPageTitle($ubbt_lang['SELECT']);
	$admin->sendHeader();
	$admin->createTopTabs($tabs,$returntab);

	include("../templates/default/admin/pruneaction.tmpl");

}
else {

	// unserialize removed results
	if ($removed) {
		$removed = unserialize($removed);
	}
	else {
		$removed = array();
	}

	// Grab all forum titles
	$query = "
		SELECT FORUM_ID,FORUM_TITLE
		FROM {$config['TABLE_PREFIX']}FORUMS
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	while(list($key,$btitle) = $dbh->fetch_array($sth)) {
		$titles[$key] = $btitle;
	}
	// Need the total amount of results
	$countquery = preg_replace("(\n|\r)","",$savequery);
	$countquery = preg_replace("/SELECT (.*?)FROM/","SELECT COUNT(*) FROM",$countquery);
	$sth = $dbh->do_query($countquery,__LINE__,__FILE__);
	list($total) = $dbh->fetch_array($sth);
	if (!$total) {
		$admin->error($ubbt_lang['NO_MATCHES']);
	}
	$totalpages = ceil($total/20);
	if (!$totalpages) {
		$totalpages = 1;
	}
	$pages = $ubbt_lang['PAGE'];
	for ($i=1;$i<=$totalpages;$i++) {
		if ($i == $p) {
			$pages .= " $i ";
		}
		else {
			$pages .= " <a href=\"{$config['BASE_URL']}/admin/selectprunethreads.php?manual=1&p=$i\">$i</a> ";
		}
	}

	if ($p == 1) {
		$limit = "LIMIT 20";
	}
	else {
		$start = (($p -1) * 20);
		$limit = "LIMIT $start,20";
	}

	$tabs = array(
		"{$ubbt_lang['SELECT']}" => ""
	);

	// Grab the results for this page
	$savequery .= "ORDER BY t1.TOPIC_LAST_REPLY_TIME DESC $limit";
	$sth = $dbh->do_query($savequery,__LINE__,__FILE__);
	$x=0;
	while(list($number,$postid,$subject,$board,$posted,$lastpost,$posterid,$lastposterid,$username,$lastpostnum) = $dbh->fetch_array($sth)) {
		if ($posterid == '1') {
			$username = $ubbt_lang['ANON_TEXT'];
		}
		if (($lastposterid == "1") || (!$lastposterid)) {
			$lastposterid = 1;
			$lastpostername = $ubbt_lang['ANON_TEXT'];
		}

		$row[$x]['postid'] = $postid;
		$row[$x]['number'] = $number;
		$row[$x]['subject'] = $subject;
		$row[$x]['board'] = $titles[$board];
		$row[$x]['boardid'] = $board;
		$row[$x]['firstpost'] = $html->convert_time($posted,$user['USER_TIME_OFFSET'],$user['USER_TIME_FORMAT']);
		$row[$x]['firstposter'] = $username;
		$row[$x]['firstposterid'] = $posterid;
		$row[$x]['lastpost'] = $html->convert_time($lastpost,$user['USER_TIME_OFFSET'],$user['USER_TIME_FORMAT']);
		$row[$x]['lastposterid'] = $lastposterid;
		if ((!isset($last[$lastposterid])) && ($lastposterid != "1")) {
			$query = "
				SELECT USER_DISPLAY_NAME
				FROM {$config['TABLE_PREFIX']}USERS
				WHERE USER_ID='$lastposterid'
			";
			$stx = $dbh->do_query($query,__LINE__,__FILE__);
			list($lastpostername) = $dbh->fetch_array($stx);
			$last[$lastposterid] = $lastpostername;
		}
		if (!$lastpostername) {
			$lastposterid = 1;
			$lastpostername = $ubbt_lang['ANON_TEXT'];
		}
		$row[$x]['lastposter'] = $lastpostername;
		if (!$lastpostnum) {
			$lastpostnum = $number;
		}
		$row[$x]['lastpostnum'] = $lastpostnum;
		if (!isset($removed[$number])) {
			$row[$x]['checked'] = "checked=\"checked\"";
		}
		else {
			$row[$x]['checked'] = "";
		}
		$x++;
	}
	$admin->setCurrentMenu($ubbt_lang['PRUNE_THREADS']);
	$admin->setReturnTab($returntab);
	$admin->setParentTitle($ubbt_lang['PRUNE_THREADS'],"prunethreads.php");
	$admin->setPageTitle($ubbt_lang['SELECT']);
	$admin->sendHeader();
	$admin->createTopTabs($tabs,$returntab);
	include("../templates/default/admin/selectprunethreads.tmpl");
}

$admin->sendFooter();
?>
