<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/view_subscriptions.php");

// Get the input
$returntab = get_input("returntab","both");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$id = get_input("id","get","int");

$query = "
	select t1.SUBSCRIPTION_ID,t2.USER_DISPLAY_NAME,t3.SUBSCRIPTION_NAME,t1.SUBSCRIPTION_START_DATE,t1.SUBSCRIPTION_END_DATE,SUBSCRIPTION_STATUS,SUBSCRIPTION_IS_ACTIVE,SUBSCRIPTION_PAYMENT,t1.USER_ID,t1.CUSTOM_ID,t3.GROUP_ID
	from {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA as t1,
	{$config['TABLE_PREFIX']}USERS as t2,
	{$config['TABLE_PREFIX']}SUBSCRIPTIONS as t3
	where t1.SUBSCRIPTION_ID = ?
	and t1.USER_ID = t2.USER_ID
	and t1.GROUP_ID = t3.GROUP_ID
";
$sth = $dbh->do_placeholder_query($query,array($id),__LINE__,__FILE__);
list($invoice,$user,$name,$start,$end,$status,$active,$payment,$uid,$custom,$group_id) = $dbh->fetch_array($sth);

if ($active) {
	$active = $ubbt_lang['TEXT_YES'];
} else {
	$active = $ubbt_lang['TEXT_NO'];
} // end if

if (!$end) {
	$end = $ubbt_lang['NO_END'];
} else {
	$end = $html->convert_time($end);
}

if (!$start) {
	$start = $ubbt_lang['NOT_STARTED'];
} else {
	$start = $html->convert_time($start);
} // end if

// Grab the paypal history
if ($payment == "paypal") {
	$query = "
		select *
		from {$config['TABLE_PREFIX']}PAYPAL_DATA
		where CUSTOM_ID = ?
		order by LOG_ID desc
	";
	$sth = $dbh->do_placeholder_query($query,array($custom),__LINE__,__FILE__);
	while($history[] = $dbh->fetch_array($sth,MYSQL_ASSOC)) {
		// Boo!
	} // end while
} elseif ($payment == "check") {
	$query = "
		select *
		from {$config['TABLE_PREFIX']}CHECK_DATA
		where CUSTOM_ID = ?
		order by LOG_ID desc
	";
	$sth = $dbh->do_placeholder_query($query,array($custom),__LINE__,__FILE__);
	while($history[] = $dbh->fetch_array($sth,MYSQL_ASSOC)) {
		// Boo!
	} // end while

	foreach($history as $k => $v) {
		if ($history[$k]) {
			$history[$k]['PAYMENT_DATE'] = $html->convert_time($history[$k]['PAYMENT_DATE']);
		} else {
			unset($history[$k]);
		} // end if
	} // end foreach
} // end if

$tabs = array(
	"{$ubbt_lang['SUB_DETAILS']}" => "",
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['VIEW_SUBS']);
$admin->setReturnTab($returntab);
$admin->setParentTitle($ubbt_lang['VIEW_SUBS'],"view_subscriptions.php");
$admin->setPageTitle($ubbt_lang['SUB_DETAILS']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/sub_history.tmpl");

$admin->sendFooter();
?>
