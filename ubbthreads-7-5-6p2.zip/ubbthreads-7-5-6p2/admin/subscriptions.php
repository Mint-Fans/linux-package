<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/subscriptions.php");

// Get the input
$returntab = get_input("returntab","both");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$tabs = array(
	"{$ubbt_lang['SUB_SETUP']}" => "",
);

$query = "
	select GROUP_ID,GROUP_NAME 
	from {$config['TABLE_PREFIX']}GROUPS
	where GROUP_IS_DISABLED='0'
	and GROUP_ID > 5
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$groups = array();
while(list($gid,$gname) = $dbh->fetch_array($sth)) {
	$groups[$gid] = $gname;
} // end while

$query = "
	select GROUP_ID,SUBSCRIPTION_NAME,SUBSCRIPTION_BY_DONATION,SUBSCRIPTION_BY_TRIAL,SUBSCRIPTION_BY_REGULAR
	from {$config['TABLE_PREFIX']}SUBSCRIPTIONS
";
$subs = array();
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while(list($gid,$sname,$sdon,$str,$sreg) = $dbh->fetch_array($sth)) {
	$subs[$gid]['name'] = $sname;
	if ($sdon || $str || $sreg) {
		$subs[$gid]['active'] = $ubbt_lang['TEXT_YES'];
	} else {
		$subs[$gid]['active'] = $ubbt_lang['TEXT_NO'];
	} // end if
} // end while

if (!sizeof($groups)) {
	$admin->error($ubbt_lang['NO_CUSTOM_GROUPS']);
} // end if


// Create the Page
$admin->setCurrentMenu($ubbt_lang['SUB_SETUP']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['SUB_SETUP']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/subscriptions.tmpl");

$admin->sendFooter();
?>
