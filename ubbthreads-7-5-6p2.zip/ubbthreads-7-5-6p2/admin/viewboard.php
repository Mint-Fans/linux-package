<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/viewboard.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");
$forum = get_input("forum","get");
$what = get_input("what","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate();

$admin = new Admin;

$admin->doAuth();

// -----------------------------------------------
// Grab the board info
$query = "
	SELECT	FORUM_TITLE, FORUM_DESCRIPTION,
		CATEGORY_ID, FORUM_DEFAULT_TOPIC_AGE, FORUM_CUSTOM_HEADER,
		FORUM_STYLE, FORUM_IMAGE, FORUM_IS_ACTIVE, FORUM_PARENT,
		FORUM_ISLAND_INSERT, FORUM_SHOW_INTRO,
		FORUM_INTRO_TITLE, FORUM_IS_TEASER, FORUM_IS_GALLERY,
		FORUM_POSTS_COUNT, FORUM_ACTIVE_POSTS,
		FORUM_SORT_FIELD,FORUM_SORT_DIR
	FROM  {$config['TABLE_PREFIX']}FORUMS
	WHERE FORUM_ID = ?
";
$sth = $dbh -> do_placeholder_query($query,array($forum),__LINE__,__FILE__);

list($Title,$Description,$Catnum,$ThreadAge,$header,$style,$forumimage,$boactive,$forumparent,$island_insert,$show_intro,$forum_intro_title,$is_teaser,$is_gallery, $posts_count, $shows_in_active_topics,$sort_field,$sort_dir) = $dbh -> fetch_array($sth);
$dbh -> finish_sth($sth);
$posts_count = ($posts_count == '1') ? ' checked="checked" ' : '';
$shows_in_active_topics = ($shows_in_active_topics == '1') ? ' checked="checked" ' : '';
$Description = str_replace('&', '&amp;', $Description);

// Grab the RSS Feed info
$query = "
	select FEED_IS_ACTIVE,FEED_NAME,FEED_TYPE,FEED_INCLUDE_BODY,FEED_ITEMS,FEED_CACHE_TIME
	from {$config['TABLE_PREFIX']}RSS_FEEDS
	where FEED_FORUM = ?
";
$sth = $dbh->do_placeholder_query($query,array($forum),__LINE__,__FILE__);
list($is_active,$feed_name,$feed_type,$feed_body,$feed_items,$feed_cache) = $dbh->fetch_array($sth);

$feed_name = htmlspecialchars($feed_name);

if ($is_gallery) {
	$gallery_note = $ubbt_lang['TEXT_YES'];
} else {
	$gallery_note = $ubbt_lang['TEXT_NO'];
} // end if

$intro_checked = "";
if ($show_intro) {
	$intro_checked = "checked=\"checked\"";
} // end if

$rss_active = "";
if ($is_active) {
	$rss_active = "checked=\"checked\"";
} // end if

$teaser_active = "";
if ($is_teaser) {
	$teaser_active = "checked=\"checked\"";
} // end if

$rss_posts = "";
$rss_topics = "";
if ($feed_type == "posts") {
	$rss_posts = "selected=\"selected\"";
} else {
	$rss_topics = "selected=\"selected\"";
} // end if

if (!$feed_items) $feed_items = 10;
if (!$feed_cache) {
	$feed_cache = 5;
} else {
	$feed_cache = $feed_cache / 60;
}

// Grab the special header/footer if there is one
$headerfile ="";
$fd = @file("{$config['FULL_PATH']}/includes/header_$forum.php");
if ($fd) {
	while (list($linenum,$line) = each($fd)) {
		$line = htmlspecialchars($line);
		$headerfile  .= "$line";
	}
}

$footerfile ="";
$fd = @file("{$config['FULL_PATH']}/includes/footer_$forum.php");
if ($fd) {
	while (list($linenum,$line) = each($fd)) {
		$line = htmlspecialchars($line);
		$footerfile  .= "$line";
	}
}

// Grab the forum intro
$intro_body ="";
$fd = @file("{$config['FULL_PATH']}/includes/intro_$forum.php");
if ($fd) {
	while (list($linenum,$line) = each($fd)) {
		$line = htmlspecialchars($line);
		$intro_body  .= "$line";
	}
}


$boactive_checked = "";
if ($boactive) {
	$boactive_checked = "checked=\"checked\"";
}
$height = "";
$width = "";
if (!$forumimage) {
	$forumimage = "{$config['BASE_URL']}/images/{$style_array['forumimages']}/blank.gif";
	$height = "48";
	$width  = "48";
	$avurl = "";
}
else {
	$avurl = "{$config['BASE_URL']}/images/{$style_array['forumimages']}/$forumimage";
	$forumimage = $avurl;
}

$defselected = "";
if ($style == 0) {
	$defselected = "selected=\"selected\"";
}

$uniquedisplay = "display: none;";
$unique = "";
if ($header) {
	$unique = "checked=\"checked\"";
	$uniquedisplay = "";
}


$d1 = ""; $d2 = ""; $w1 = ""; $w2="";$w3="";$m1="";$m3="";$m6="";$y1="";$allofthem="";
if ($ThreadAge == "1") {
	$d1 = "selected=\"selected\"";
} elseif ($ThreadAge == "2") {
	$d2 = "selected=\"selected\"";
} elseif ($ThreadAge == "7") {
	$w1 = "selected=\"selected\"";
} elseif ($ThreadAge == "14") {
	$w2 = "selected=\"selected\"";
} elseif ($ThreadAge == "21") {
	$w3 = "selected=\"selected\"";
} elseif ($ThreadAge == "31") {
	$m1 = "selected=\"selected\"";
} elseif ($ThreadAge == "93") {
	$m3 = "selected=\"selected\"";
} elseif ($ThreadAge == "186") {
	$m6 = "selected=\"selected\"";
} elseif ($ThreadAge == "365") {
	$y1 = "selected=\"selected\"";
} else {
	$allofthem = "selected=\"selected\"";
}

// Set default sort field and direction
if (!$sort_field) $sort_field = "last";
if (!$sort_dir) $sort_dir = "desc";

$subject = ""; $starter = ""; $replies = ""; $views =  ""; $start = ""; $last = ""; $asc = ""; $desc = "";
${$sort_field} = "selected='selected'";
${$sort_dir} = "selected='selected'";

include("{$config['FULL_PATH']}/cache/forum_cache.php");
if (!sizeof($tree)) {
	list($tree,$style_cache,$lang_cache) = build_forum_cache();
}

$catlist = "";
$category = "";
$forums = 0;
foreach($tree['categories'] as $cat => $cat_title) {
	$thisisit = "";
	$category = "";
	$forums = 0;
	if ($cat == $Catnum && !$forumparent) {
		$thisisit = "selected=\"selected\"";
	}
	$category .= "<option value=\"category_$cat\" $thisisit>$cat_title ------</option>";
	if (!isset($tree[$cat])) {
		$catlist .= $category;
		continue;
	}
	foreach($tree[$cat] as $forum_id => $forum_title) {
		$thisisit = "";
		if ($forum == $forum_id) continue;
		if ($forumparent == $forum_id) {
			$thisisit = "selected=\"selected\"";
		} // end if
		$category .= "<option value=\"forum_$forum_id\" $thisisit>$forum_title</option>";
		$forums++;
	}
	$catlist .= $category;
}


// Grab the stylesheets
$stylelist = "";
$query = "
	select STYLE_ID,STYLE_NAME
	from {$config['TABLE_PREFIX']}STYLES
	where STYLE_IS_ACTIVE = '1'
	order by STYLE_NAME
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while(list($styleid,$sname) = $dbh->fetch_array($sth)) {
	$stylenames[$styleid] = $sname;
	$extra = "";
	if ($style == $styleid) {
		$extra = "selected=\"selected\"";
	}
	$stylelist .= "<option value=\"$styleid\" $extra>$sname</option>";
}

// --------------------------
// List out all of the groups
$query = "
	SELECT GROUP_NAME, GROUP_ID
	FROM   {$config['TABLE_PREFIX']}GROUPS
	WHERE  GROUP_IS_DISABLED <> 1
";
$sth = $dbh -> do_query($query,__LINE__,__FILE__);
$grouplist = "";
while (list($Name,$Id) = $dbh -> fetch_array($sth)) {
	$grouplist .= "<tr><td class=\"stdautorow colored-row autotop\">";
	$none = '';
	$read = '';
	$write = '';
	$reply = '';

	if (in_array($Id,$topicperm)) {
		$write = 'checked="checked"';
	}
	elseif (in_array($Id,$replyperm)) {
		$reply = 'checked="checked"';
	}
	elseif (in_array($Id,$readperm)) {
		$read = 'checked="checked"';
	}
	else {
		$none = 'checked="checked"';
	}
	$grouplist .= "<input type=\"radio\" name=\"GROUP$Id\" $none value=\"none\"></td><td class=\"stdautorow colored-row autotop\"> ";
	$grouplist .= "<input type=\"radio\" name=\"GROUP$Id\" $read value=\"read\"></td><td class=\"stdautorow colored-row autotop\"> ";
	$grouplist .= "<input type=\"radio\" name=\"GROUP$Id\" $reply value=\"reply\"></td><td class=\"stdautorow colored-row autotop\"> ";
	$grouplist .= "<input type=\"radio\" name=\"GROUP$Id\" $write value=\"write\"></td> ";
	$grouplist .= "<td class=\"stdautorow colored-row autotop\">$Name</td></tr>";
}

$query = "
	select 	PORTAL_ID,PORTAL_NAME
	from		{$config['TABLE_PREFIX']}PORTAL_BOXES
	where			PORTAL_CUSTOM = '1'
	order by PORTAL_ID
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$island_selection = "<option value=\"0\">{$ubbt_lang['NO_INSERT']}</option>";
while(list($portal_id,$portal_name) = $dbh->fetch_array($sth)) {
	$selected = "";
	if ($portal_id == $island_insert) {
		$selected = "selected=\"selected\"";
	} // end if
	$island_selection .= "<option value=\"$portal_id\" $selected>$portal_name</option>";
} // end while

$tabs = array(
	"{$ubbt_lang['FORUM_BASICS']}" => "",
	"{$ubbt_lang['HEADFOOT']}" => "",
	"{$ubbt_lang['RSS']}" => "",
);

$admin->setCurrentMenu($ubbt_lang['FORUM_SET']);
$admin->setParentTitle($ubbt_lang['FORUM_SET'],"forummanage.php");
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['EDIT_FORUM']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);
$admin->setCommonSubmit($ubbt_lang['SUBMIT_C']);

// Include the template
include("../templates/default/admin/viewboard.tmpl");

$bottomtabs = array(
	"{$ubbt_lang['FORUM_PERMS']}" => "forumperms.php?edit_forum=$forum",
	"{$ubbt_lang['DEL_HEAD']}" => "deleteboard.php?forum=$forum"
);
$admin->createBottomTabs($bottomtabs,0);

$admin->sendFooter();
?>
