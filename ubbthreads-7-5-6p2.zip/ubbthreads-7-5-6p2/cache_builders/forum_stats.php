<?php
//	Whoops!  If you see this text in your browser,
//	your web hosting provider has not installed PHP.
//
//	You will be unable to use UBB until PHP has been properly installed.
//
//	You may wish to ask your web hosting provider to install PHP.
//	Both Windows and Unix versions are available on the PHP website,
//	http://www.php.net/
//
//
//
//	Ultimate Bulletin Board
//	Script Version 7.5.6
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

if (!defined('UBB_MAIN_PROGRAM')) {
	exit;
}

// Yay initialization!
$users = 0;
$topics = 0;
$posts = 0;
$maxonline = 0;
$maxonline = $html->get_date();
$forums = 0;

$query = "
	SELECT	COUNT(USER_ID) AS COUNT
	FROM	{$config['TABLE_PREFIX']}USERS
	WHERE	USER_IS_APPROVED = 'yes' AND USER_ID > 1
";
$sth = $dbh->do_query($query);
$tmp = $dbh->fetch_array($sth, MYSQL_ASSOC);
$users = $tmp['COUNT'];

$query = "
	SELECT	SUM(FORUM_TOPICS) AS TOPICS, SUM(FORUM_POSTS) AS POSTS
	FROM	{$config['TABLE_PREFIX']}FORUMS
	WHERE	FORUM_IS_ACTIVE = '1'
";
$sth = $dbh->do_query($query);
$tmp = $dbh->fetch_array($sth, MYSQL_ASSOC);

$topics = ($tmp['TOPICS'] === null) ? 0 : $tmp['TOPICS'];
$posts = ($tmp['POSTS'] === null) ? 0 : $tmp['POSTS'];

// Grab the max online
$query = "
	select CACHE_FIELD,CACHE_VALUE
	from {$config['TABLE_PREFIX']}CACHE
	where CACHE_FIELD in ('max_online','max_online_timestamp')
";

$cache = array();
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
	$cache[$result['CACHE_FIELD']] = $result['CACHE_VALUE'];
} // end while

$query = "
	SELECT	COUNT(FORUM_ID) AS COUNT
	FROM	{$config['TABLE_PREFIX']}FORUMS
	WHERE	FORUM_IS_ACTIVE = '1'
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$tmp = $dbh->fetch_array($sth);
$forums = $tmp['COUNT'];

$smarty->assign("maxonline", $cache['max_online']);
$smarty->assign("maxonlinetime", $html->convert_time($cache['max_online_timestamp']));
$smarty->assign("users",$users);
$smarty->assign("posts",$posts);
$smarty->assign("topics",$topics);
$smarty->assign("forums",$forums);
$island = $smarty->fetch("island_forum_stats.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/forum_stats.php",$island);

@chmod("{$config['FULL_PATH']}/cache/forum_stats.php",0666);

?>
