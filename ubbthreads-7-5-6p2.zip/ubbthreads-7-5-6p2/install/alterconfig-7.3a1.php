<?php

$newconfigs['IMAGE_LIMIT'] = '10';
$newconfigs['ENABLE_POST_COUNTS'] = '1';
$newconfigs['SHOW_ALL_GRAEMLINS'] = '0';
$newconfigs['SHOW_TEASER_LATEST_POST'] = '0';
$newconfigs['CATEGORY_ONLY_MODE'] = '0';
$newconfigs['DISABLE_ONLINE_INVISIBLE'] = '0';
$newconfigs['SEARCH_FRIENDLY_HTML_EXT'] = '0';
$newconfigs['CALENDAR_START_DAY'] = '0';
$newconfigs['TOTAL_ONLINE'] = '6';

?>
