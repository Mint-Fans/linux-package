<?php
$newstyles['.forum_extras']['copy'] = ".small";
$newstyles['.author-content']['copy'] = ".alt-2";
$newstyles['.alt-newintopic']['copy'] = ".newintopic";
$newstyles['.alt-topicicon']['copy'] = ".topicicon";
$newstyles['.alt-topicsubject']['copy'] = ".topicsubject";
$newstyles['.alt-topicreplies']['copy'] = ".topicreplies";
$newstyles['.alt-topicviews']['copy'] = ".topicviews";
$newstyles['.alt-topictime']['copy'] = ".topictime";
$newstyles['.new-newintopic']['copy'] = ".newintopic";
$newstyles['.new-topicicon']['copy'] = ".topicicon";
$newstyles['.new-topicsubject']['copy'] = ".topicsubject";
$newstyles['.new-topicreplies']['copy'] = ".topicreplies";
$newstyles['.new-topicviews']['copy'] = ".topicviews";
$newstyles['.new-topictime']['copy'] = ".topictime";

?>
