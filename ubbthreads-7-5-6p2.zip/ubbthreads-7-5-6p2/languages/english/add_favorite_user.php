<?php
$ubbt_lang['HEADER'] = "Watch a new user";
$ubbt_lang['INSTRUCTIONS'] = "Type the username (in whole or in part) for which you are searching.";
$ubbt_lang['SEARCH_USERS'] = "Search Users";
?>
