<?php
$ubbt_lang['TAB_HEADER'] = "Change Group Image";
$ubbt_lang['HEADER'] = "Browse to the image on your hard drive that you'd like to use for this group.  These should be small images as they will display next to the username when viewing a list of posts.  Users belonging to this group will be able to select this image to display in their profile.  Leaving the image blank will remove the image for this group.";
$ubbt_lang['GIMAGE'] = "Group Image";
$ubbt_lang['UPDATE'] = "Update Group Image";
?>
