<?php
$ubbt_lang['NO_COPY_FROM'] = "You didn't select a forum to copy the permissions from";
$ubbt_lang['NO_COPY_TO'] = "You didn't select any forums to copy permissions to.";
$ubbt_lang['PERMS_COPIED'] = "Forum Permissions copied to specified forums.";
?>
