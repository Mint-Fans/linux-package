<?php
$ubbt_lang['CAT_HEAD'] = "Create New Category";
$ubbt_lang['CAT_BODY'] = "Enter the name of the category you want to create (up to 120 characters).  You will then be able to add any new or existing forum into the category.";
$ubbt_lang['CAT_TITLE'] = "Category Name:";
$ubbt_lang['CAT_DESC'] = "Category Description:";
$ubbt_lang['ADD_CAT'] = "Add Category";
?>