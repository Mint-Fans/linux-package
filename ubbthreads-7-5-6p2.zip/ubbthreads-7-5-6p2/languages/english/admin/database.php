<?php
$ubbt_lang['COMMAND'] = "SQL Command";
$ubbt_lang['INFO'] = "Information";
$ubbt_lang['BACKUP'] = "Backup Tables";
$ubbt_lang['BACKUP_THIS'] = "Backup Table";
$ubbt_lang['BACKUP_BODY'] = "Please select a table to back up.  You may also choose to back up all tables.  Please be sure to close your forums before running a backup command.";
$ubbt_lang['BACKUP_DIR'] = "Backup Storage Directory";
$ubbt_lang['BACKUP_DIR_1'] = "Please specify a directory outside of your web root.";
$ubbt_lang['BACKUP_ALL'] = "All Tables";
$ubbt_lang['TNAME'] = "Table Name";
$ubbt_lang['TBACKUP'] = "Backup";
$ubbt_lang['SUBMIT'] = "Submit";
$ubbt_lang['QUERY'] = "Query:";
$ubbt_lang['SAVED_QUERY'] = "Saved Queries";
$ubbt_lang['EXECUTE'] = "Execute";
$ubbt_lang['USE'] = "Use";
$ubbt_lang['DELETE'] = "Delete";
$ubbt_lang['SAVE'] = "Save";
$ubbt_lang['QUERY_DESC'] = "Description:";
$ubbt_lang['DROP_TABLE'] = "Add drop table statement";
$ubbt_lang['DROP_TABLE_1'] = "This adds a statement to the backup files to replace existing tables"
?>
