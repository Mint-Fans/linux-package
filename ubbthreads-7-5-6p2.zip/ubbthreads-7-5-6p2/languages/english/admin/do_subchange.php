<?php
$ubbt_lang['ACTIVATE_SUB'] = "Subscription Added";
$ubbt_lang['ACTIVATE_BODY'] = "You have been manually added to the '%%GROUP%%' subscription group.";
$ubbt_lang['EXPIRE_SUB'] = "Subscription Expired";
$ubbt_lang['EXPIRE_BODY'] = "Your subscription to the '%%GROUP%%' subscription group has expired.";
$ubbt_lang['AND_TIME'] = "and End Date changed";
$ubbt_lang['SUB_MODIFIED'] = "Subscription Modified";
