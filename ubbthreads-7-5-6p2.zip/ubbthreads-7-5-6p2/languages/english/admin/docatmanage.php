<?php
$ubbt_lang['NO_DELETE'] = "You may not delete the last category.";
?>
