<?php
$ubbt_lang['F_LOC'] = "the Graemlins screen.";
$ubbt_lang['UPDATED'] = "Graemlins have been updated.";
$ubbt_lang['NO_DELETE'] = "Unable to delete Graemlins from your /images/{$style_array['graemlins']} directory.  Please fix the permissions on this directory and the files within and try again.";
$ubbt_lang['NO_OVERW'] = "is not writeable by the web server.  Please fix the permissions on this file and try again.";
?>
