<?php
$ubbt_lang['F_LOC'] = "the Posting Icons screen.";
$ubbt_lang['NOREMOVE'] = "Unable to remove icon.  Please check permissions on the files in your /images/{$style_array['icons']} directory and try again.";
$ubbt_lang['REMOVED'] = "Icons have been updated/removed.";
$ubbt_lang['NO_OVERW'] = " is not writeable by the web server.  Please fix the permissions on this file and try again.";
?>
