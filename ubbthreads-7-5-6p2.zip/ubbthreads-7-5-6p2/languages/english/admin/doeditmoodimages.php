<?php
$ubbt_lang['F_LOC'] = "the Moods screen.";
$ubbt_lang['NOREMOVE'] = "Unable to remove mood.  Please check permissions on the files in your moods directory and try again.";
$ubbt_lang['REMOVED'] = "Moods have been updated.";
$ubbt_lang['NO_OVERW'] = " is not writeable by the web server.  Please fix the permissions on this file and try again.";
?>
