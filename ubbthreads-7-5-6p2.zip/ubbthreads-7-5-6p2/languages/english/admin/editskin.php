<?php
$ubbt_lang['STYLE'] = "Stylesheet";
$ubbt_lang['CHOOSE_SKIN'] = "Choose the stylesheet to edit.";
$ubbt_lang['SKIN_BODY'] = "The following stylesheets were found in your {$config['FULL_PATH']}/stylesheets directory.  Please choose which one you would like to edit.";
$ubbt_lang['EDIT_THIS'] = "Edit this stylesheet.";
$ubbt_lang['EDIT_STYLE'] = "Edit stylesheet";
$ubbt_lang['ADD_STYLE'] = "Add a stylesheet";
$ubbt_lang['INSTR'] = "You may change any of the stylesheet properties below.";
$ubbt_lang['INSTR_ADD'] = "Fill out the class properties below.";
$ubbt_lang['MY_SKIN'] = "Set this is as my default stylesheet.";
$ubbt_lang['UPDATE_SKIN'] = "Update this stylesheet.";
$ubbt_lang['ADD_SKIN'] = "Add this stylesheet.";
$ubbt_lang['FILENAME'] = "Filename for stylesheet:";
?>
