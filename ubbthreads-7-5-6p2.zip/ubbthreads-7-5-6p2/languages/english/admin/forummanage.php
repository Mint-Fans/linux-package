<?php
$ubbt_lang['NO_FORUMS'] = "You do not have any forums.";
$ubbt_lang['KEYWORD'] = "Keyword";
$ubbt_lang['NAME'] = "Name";
$ubbt_lang['ORDER'] = "Order";
$ubbt_lang['CATEGORY'] = "Category";
$ubbt_lang['VISIBLE'] = "Enabled";
$ubbt_lang['DETAILS'] = "Details";
$ubbt_lang['PERMS'] = "Permissions";
$ubbt_lang['SUBMIT_C'] = "Submit Changes";
$ubbt_lang['ADD_NEW'] = "Add New Forum";
?>
