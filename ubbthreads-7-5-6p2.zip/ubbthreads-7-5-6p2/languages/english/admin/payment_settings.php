<?php
$ubbt_lang['CURRENCY'] = "Currency";
$ubbt_lang['CURRENCY_SET'] = "What currency should amounts be listed as?";
$ubbt_lang['USD'] = "(\$) U.S. Dollars";
$ubbt_lang['CAD'] = "(C \$) Canadian Dollars";
$ubbt_lang['EUR'] = "(&euro;) Euros";
$ubbt_lang['GBP'] = "(&pound;) Pounds Sterling";
$ubbt_lang['JPY'] = "(&yen;) Yen";
$ubbt_lang['PAYPAL'] = "PayPal";
$ubbt_lang['ALLOW_PAYPAL'] = "Allow payment via PayPal?";
$ubbt_lang['PAYPAL_EMAIL'] = "Your PayPal Email Address:";
$ubbt_lang['PAYPAL_EMAIL_1'] = "This email account must be confirmed with PayPal and linked to your Verified Business or Premier account.";
$ubbt_lang['BY_MAIL'] = "Check/Money Order";
$ubbt_lang['ALLOW_MAIL'] = "Allow payment by:";
$ubbt_lang['BY_CHECK'] = "Check";
$ubbt_lang['BY_MO'] = "Money Order";
$ubbt_lang['BY_CHECK_MO'] = "Check or Money Order";
$ubbt_lang['NO_CHECK_MO'] = "Neither.  Disable this option";
$ubbt_lang['PAYMENT_ADDRESS'] = "Payment mailing address:";
?>
