<?php
$ubbt_lang['EXISTING'] = "Check this box if you want to update existing users with these new titles.";
$ubbt_lang['USER_TITLES'] = "Member Titles";
$ubbt_lang['RANK'] = "Rank #";
$ubbt_lang['MIN_POST'] = "Min. Posts:";
$ubbt_lang['U_TITLE'] = "Title:";
$ubbt_lang['SHOW_GROUPS'] = "Show Groups";
$ubbt_lang['UPLOAD_AV_DIR'] = "Avatar Upload Storage Directory:";
$ubbt_lang['UPLOAD_AV_DIR_1'] = "This setting is only needed if members can upload avatar.";
$ubbt_lang['UPLOAD_AV_URL'] = "Full URL to Avatar Upload Storage Directory:";
$ubbt_lang['UPLOAD_AV_URL_1'] = "This setting is only needed if members can upload avatar.";
$ubbt_lang['UPLOAD_AV_SIZE'] = "Maximum file size of uploaded avatars:";
$ubbt_lang['UPLOAD_AV_SIZE_1'] = "This setting is only needed if members can upload avatar.<br />Size in bytes.  1024 is one kilobyte.";
$ubbt_lang['MAX_WIDTH'] = "Maximum Avatar Width: (Pixels)";
$ubbt_lang['MAX_HEIGHT'] = "Maximum Avatar Height: (Pixels)";
$ubbt_lang['AVATARS'] = "Avatars";
$ubbt_lang['UPDATE'] = "Update Profile Settings";
$ubbt_lang['ONLY_CUSTOM'] = "If a user has both a Custom and Post title, only show Custom Title:";
?>
