<?php
$ubbt_lang['SAVED'] = "Your changes have been saved.";
$ubbt_lang['RETURNPAGE'] = "Return to page:";
$ubbt_lang['DONE'] = "I'm done selecting topics.  Begin pruning now.";
$ubbt_lang['SELECT'] = "Select Topics";
?>