<?php
$ubbt_lang['RESULT'] = "Results";
$ubbt_lang['DIRRESULTS'] = "Directory Results";
$ubbt_lang['TEST'] = "Testing";
$ubbt_lang['EXIST'] = "Directory exists";
$ubbt_lang['NOWRITE'] = "but is not writeable.";
$ubbt_lang['CANWRITE'] = "and is writeable.";
$ubbt_lang['NOEXIST'] = "Directory does not exist!";
$ubbt_lang['FAIL'] = "Test failed.  Either the directory was not found or cannot be written to by the web server.";
$ubbt_lang['PASS'] = "Test passed.";
?>
