<?php
$ubbt_lang['HEAD'] = "Post returned to normal.";
$ubbt_lang['BODY'] = "The selected post is no longer sticky.";
$ubbt_lang['ANNOUNCEBODY'] = "The selected post is no longer an announcement.";
?>
