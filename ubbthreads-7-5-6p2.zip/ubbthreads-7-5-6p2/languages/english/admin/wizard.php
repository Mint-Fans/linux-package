<?php
$ubbt_lang['NO_WIZARD'] = "It appears you already have a basic setup for your community.  The wizard is disabled at this point.";
$ubbt_lang['NAME'] = "Community Name";
$ubbt_lang['BOARD_EMAIL'] = "Board Email Address";
$ubbt_lang['BOARD_EMAIL_1'] = "All emails being sent out will come from this address.";
$ubbt_lang['HOMEPAGE'] = "Homepage URL";
$ubbt_lang['HOMEPAGE_TEXT'] = "Text for Homepage URL";
$ubbt_lang['CAT_HEAD'] = "Categories ('General Discussion' Category has already been created)";
$ubbt_lang['CAT_NAME'] = "Category Name (optional)";
$ubbt_lang['CAT_DESC'] = "Category Description";
$ubbt_lang['CHOOSE_FORUMS'] = "You may now setup your forums for each category.";
$ubbt_lang['FORUM_NAME'] = "Forum Name";
$ubbt_lang['FORUM_DESC'] = "Forum Description";
$ubbt_lang['ANON_POST'] = "Anonymous Posting?";
?>