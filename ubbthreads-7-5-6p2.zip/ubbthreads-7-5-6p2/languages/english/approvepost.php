<?php
$ubbt_lang['REPLY_SUB'] = "Reply to your post.";
$ubbt_lang['REPLY_BOD'] = "replied to your post at: %%BOARD_TITLE%%";
$ubbt_lang['APPR_HEAD'] = "Post approved.";
?>