<?php
$ubbt_lang['MAX_RANGE'] = "The specified date range is too wide.  The maximum date range you can search with is %%SEARCH_VALUE%% %%SEARCH_TYPE%%";
$ubbt_lang['NO_MORE'] = "There are no more search results in this direction.";
$ubbt_lang['NO_WORDS'] = "No search words!";
$ubbt_lang['SHORT'] = "All of your search keywords were too short.  Please try again.";
$ubbt_lang['SEARCH_RES'] = "Search results for query: '%%SEARCH_TERMS%%'";
$ubbt_lang['NO_MATCH'] = "There are no results for your query.  Please try a broader range of search criteria.";
$ubbt_lang['TIMELIMIT'] = "You cannot make another search at this time.  Please try again in a few minutes.";
$ubbt_lang['EXCLUDED'] = "Excluded Words: %%EXCLUDED%%"; // Hmmm
$ubbt_lang['GOTOUNREAD'] = "Go to first unread post in topic.";
$ubbt_lang['LASTPOST'] = "Last Post";
$ubbt_lang['NO_SEARCH'] = "You do not have permission to use the search engine.";
$ubbt_lang['TOTAL_SEARCH_RESULTS'] = "Your search for '<strong>%%SEARCH_TERMS%%</strong>' returned %%SEARCH_TOTAL%% results.";
?>