<?php
$ubbt_lang['ADDEVENT'] = "List as event in calendar on ";
$ubbt_lang['ADDSIG'] = "Add signature to this post.";
$ubbt_lang['LOCKED'] = "This thread is locked.  You may not edit your post.";
$ubbt_lang['DOPREVIEW'] = "I want to preview my changes.";
$ubbt_lang['POST_TEXT'] = "Post:";
$ubbt_lang['MOVE_POST'] = "Move/Merge this post and any replies.";
$ubbt_lang['NO_EDIT'] = "You cannot edit this post.";
$ubbt_lang['EDITTIME'] = "This post can no longer be edited because the maximum edit time has expired.";
$ubbt_lang['PEDIT_HEAD'] = "Edit Post";
$ubbt_lang['POST_ICON'] = "Posting Icon:";
$ubbt_lang['MARK_EDIT'] = "Mark as Edited? Reason for edit:";
$ubbt_lang['PEDIT_CHANGE'] = "Change Post";
$ubbt_lang['PEDIT_DELETE'] = "Delete Post";
$ubbt_lang['PEDIT_APPROVE'] = "Approve Post";
$ubbt_lang['MANAGE_THREAD'] = "Manage Topic";
$ubbt_lang['POST_OPTIONS'] = "Post Options";
$ubbt_lang['NEWS_IMAGE'] = "News Image:";
?>