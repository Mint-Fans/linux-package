<?php
$ubbt_lang['NOMORE'] = "There are no more topics in this direction.";
?>