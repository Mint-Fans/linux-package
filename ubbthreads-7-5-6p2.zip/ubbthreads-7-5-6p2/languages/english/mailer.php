<?php
// Common
$ubbt_lang['EMAIL_HEADER_TEXT'] = "No need to reply to this email.<br />-------------------------------<br />";
$ubbt_lang['EMAIL_HEADER_HTML'] = "No need to reply to this email.";
$ubbt_lang['EMAIL_FOOTER_TEXT'] = "This email sent to you because your profile and/or board configuration allows it.<br />You may change your preferences at any time.";
$ubbt_lang['EMAIL_FOOTER_HTML'] = "This email sent to you because your profile and/or board configuration allows it.<br />You may change your preferences at any time.";
$ubbt_lang['EMAIL_SALUTE'] = "Hi %%USERNAME%%,<br /><br />";
$ubbt_lang['EMAIL_SALUTE_GEN'] = "Hello,<br /><br />";
$ubbt_lang['EMAIL_ATTACH'] = "<br /><br />Post attachments or gallery thumbnails:<br /><br />";
$ubbt_lang['EMAIL_ATTACH_DESC'] = "Description: ";
// addpost.php
$ubbt_lang['UAN_SUBJECT'] = "Post moderation required at %%BOARD_TITLE%%";
$ubbt_lang['UAN_CONTENT'] = "A post was made in the forum: '%%FORUM_TITLE%%', where you moderate.<br /><br />It requires your approval and can be viewed";
$ubbt_lang['UAN_CONTENT1_TEXT'] = " here:<br /><br /> %%POST_URL%%";
$ubbt_lang['UAN_CONTENT1_HTML'] = " <a href=\"%%POST_URL%%\">Here</a>";
// adduser.php (merged in verifyemail too)
$ubbt_lang['REG_SUBJECT'] = "Thank you for registering at %%BOARD_TITLE%%";
$ubbt_lang['REG_CONTENT'] = "Thank you for registering at %%BOARD_TITLE%%.<br /><br />For your records, your login information is as follows:<br /><br />";
$ubbt_lang['REG_CONTENT1'] = " Username: %%USERNAME%%<br /> Password: %%PASSWORD%%<br /><br />You can login to the forums by clicking";
$ubbt_lang['REG_CONTENT2_TEXT'] = " the link below:<br /><br /> %%BOARD_URL%%";
$ubbt_lang['REG_CONTENT2_HTML'] = " <a href=\"%%BOARD_URL%%\">this link</a>.";
$ubbt_lang['REG_CONTENT3'] = "<br /><br />To activate this account, you must first click";
$ubbt_lang['REG_CONTENT4_TEXT'] = " the following link:<br /><br /> %%VERIFY_URL%%";
$ubbt_lang['REG_CONTENT4_HTML'] = " <a href=\"%%VERIFY_URL%%\">this link</a>.";
$ubbt_lang['REG_CONTENT5'] = "<br /><br />Your account needs to be approved by an Administrator before you can log in.  You will receive an email once this has been done.";
$ubbt_lang['REGN_SUBJECT'] = "A new user has registered at %%BOARD_TITLE%%";
$ubbt_lang['REGN_CONTENT'] = "Here are the details of the user's profile:<br /><br /> Email Address: %%EMAIL_ADDY%%<br /> Display Name: %%DISPLAY_NAME%%<br /> IP Address: %%IP_ADDY%%";
$ubbt_lang['REGN_CONTENT1'] = "<br /><br />This account can be approved by visiting";
$ubbt_lang['REGN_CONTENT2_TEXT'] = " the following link:<br /><br /> %%MANAGE_URL%%";
$ubbt_lang['REGN_CONTENT2_HTML'] = " <a href=\"%%MANAGE_URL%%\">this link</a>.";
$ubbt_lang['REGN_CONTENT3'] = "<br /><br />There is no approval required, but you have chosen to be notified of all new user sign-ups.";
// watchnotify.php (now obsolete)
$ubbt_lang['WNT_SUBJECT'] = "Watched Topic: %%TITLE%%";
$ubbt_lang['WNF_SUBJECT'] = "Watched Forum: %%FORUM%% : %%TITLE%%";
$ubbt_lang['WNU_SUBJECT'] = "Watched User: %%USER%% : %%TITLE%%";
$ubbt_lang['WNT_CONTENT'] = "%%USERNAME%% created a new topic at %%BOARD_TITLE%%";
$ubbt_lang['WNP_CONTENT'] = "%%USERNAME%% made a new post at %%BOARD_TITLE%%";
$ubbt_lang['WNX_CONTENT'] = "<br /><br />You can view the post by clicking ";
$ubbt_lang['WNX_CONTENT1_TEXT'] = "the following link:<br /><br />%%POST_URL%%<br /><br />The post contents are shown below:<br />----------------------------------<br />";
$ubbt_lang['WNX_CONTENT1_HTML'] = "<a href=\"%%POST_URL%%\">this link</a>. The post contents are shown below:<br />";
// cfrm (called from triggers)
$ubbt_lang['BDAY_SUBJECT'] = "Happy Birthday from %%BOARD_TITLE%%";
$ubbt_lang['BDAY_CONTENT'] = "We at %%BOARD_TITLE%% would like to wish you a Happy Birthday!";
// changebasic
$ubbt_lang['PDN_SUBJECT'] = "Display name change request at %%BOARD_TITLE%%";
$ubbt_lang['PDN_CONTENT'] = "A user has requested a display name change.<br /><br /> Original: %%OLDNAME%%<br /><br /> Desired: %%NEWNAME%%<br /><br />To approve this, please visit ";
$ubbt_lang['PDN_CONTENT1_TEXT'] = "the following link:<br /><br /> %%APPROVE_URL%%";
$ubbt_lang['PDN_CONTENT1_HTML'] = "<a href=\"%%APPROVE_URL%%\">this link</a>.";
// start_page
$ubbt_lang['PREQ_SUBJECT'] = "Request for Password at %%BOARD_TITLE%%";
$ubbt_lang['PREQ_CONTENT'] = "A user from the IP Address: %%IP_ADDY%% has requested a temporary password for the Username: '%%USERNAME%%' at '%%BOARD_TITLE%%'.<br /><br />";
$ubbt_lang['PREQ_CONTENT1'] = "This is a temporary password that can be used if you have forgotten your original password. If you did not request this, please ignore this message.<br /><br />";
$ubbt_lang['PREQ_CONTENT2'] = "Your original password will still work fine.<br /><br />The temporary password for this username is:<br /><br /> %%PASSWORD%%";
// admin/sendpassword
$ubbt_lang['PSND_SUBJECT'] = "Request for Password at %%BOARD_TITLE%%";
$ubbt_lang['PSND_CONTENT'] = "Below you will find the login information for %%BOARD_TITLE%%:<br /><br /> Username: %%USERNAME%%<br /> Temporary Password: %%PASSWORD%%";
// sendmessage (merged in mess_reply too)
$ubbt_lang['PMN_SUBJECT'] = "A new private message for you at %%BOARD_TITLE%%";
$ubbt_lang['PMN_CONTENT'] = "You have received a private message at %%BOARD_TITLE%% from %%FROMNAME%%";
$ubbt_lang['PMN_CONTENT1_TEXT'] = "<br /><br />You can reply to this message at the following link:<br /><br /> %%PM_URL%%<br /><br />";
$ubbt_lang['PMN_CONTENT1_HTML'] = "<br /><br />You can reply to this message by following <a href=\"%%PM_URL%%\">this link</a><br /><br />";
$ubbt_lang['PMN_CONTENT2_TEXT'] = "The private message contents are shown below:<br />---------------------------------------------<br />";
$ubbt_lang['PMN_CONTENT2_HTML'] = "The private message contents are shown below:<br />";
// donotifymod
$ubbt_lang['DNM_SUBJECT'] = "Moderator notification of post in: %%FORUM_TITLE%% about: %%POST_SUBJECT%%";
$ubbt_lang['DNM_CONTENT'] = "%%USERNAME%% has notified you of a post you should look at titled:<br /><br /> '%%POST_SUBJECT%%'<br /><br />";
$ubbt_lang['DNM_CONTENT1'] = "The reason you are being notified is:<br /><br /> %%REASON%%<br /><br />You can view this post by clicking ";
$ubbt_lang['DNM_CONTENT2_TEXT'] = "the following link:<br /><br />%%POST_URL%%<br /><br />The Post contents are shown below:<br />----------------------------------<br />";
$ubbt_lang['DNM_CONTENT2_HTML'] = "<a href=\"%%POST_URL%%\">this link</a> The Post contents are shown below:<br />";
// admin/doapproveusers
$ubbt_lang['DAUV_SUBJECT'] = "Verify email for %%USERNAME%%";
$ubbt_lang['DAUV_CONTENT_TEXT'] = "To activate your account, you need to verify your email address. Please see the following link:<br /><br />%%VERIFY_URL%%";
$ubbt_lang['DAUV_CONTENT_HTML'] = "To activate your account, you need to verify your email address. Please follow <a href=\"%%VERIFY_URL%%\">this link</a>";
$ubbt_lang['DAUA_SUBJECT'] = "Your registration has been approved";
$ubbt_lang['DAUA_CONTENT'] = "Your registration of '%%USERNAME%%' at %%BOARD_TITLE%% has been approved.";
$ubbt_lang['DAUD_SUBJECT'] = "Your registration was denied";
$ubbt_lang['DAUD_CONTENT'] = "Your registration of '%%USERNAME%%' at %%BOARD_TITLE%% has been denied.  The reason for this is below:<br /><br />%%REASON%%";
// admin/doexportemails
$ubbt_lang['DEE_SUBJECT'] = "Email List Request";
$ubbt_lang['DEE_CONTENT'] = "You just created an email list from %%BOARD_TITLE%%.  This list does not include those users that have opted out of Admin emails:<br /><br />%%EL_LISTO%%";
// admin/dosendemail
$ubbt_lang['DSE_SUBJECT'] = "%%SUBJECT%%";
$ubbt_lang['DSE_CONTENT'] = "%%CONTENT%%";
// domailthread
$ubbt_lang['DMT_SUBJECT'] = "Emailed Post(s) from %%BOARD_TITLE%%";
$ubbt_lang['DMT_CONTENT'] = "%%USERNAME%% has forwarded you a post or group of posts from %%BOARD_TITLE%%<br /><br />Included note:<br /><br />%%NOTES%%<br /><br />To read this topic, click ";
$ubbt_lang['DMT_CONTENT1_TEXT'] = "on the following link:<br /><br />%%POST_URL%%<br /><br />";
$ubbt_lang['DMT_CONTENT1_HTML'] = "<a href=\"%%POST_URL%%\">this link</a><br /><br />";
$ubbt_lang['DMT_CONTENT2'] = "The selected thread posts follow:";
$ubbt_lang['DMP_SUBJECT'] = "Emailed Private message from %%BOARD_TITLE%%";
$ubbt_lang['DMP_CONTENT'] = "Contents of your private topic follow:";
$ubbt_lang['VER_EMAIL_SUB'] = "Email Verification for %%BOARD_TITLE%%";
$ubbt_lang['VER_EMAIL_CONTENT'] = "A request has been made to update your email address to %%EMAIL%%.  In order for us to continue with this change, you'll need to visit the link below to validate the email:<br /><br />%%VERIFY_URL%%";

?>
