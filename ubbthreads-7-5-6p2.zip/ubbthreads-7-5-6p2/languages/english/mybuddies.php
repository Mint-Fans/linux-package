<?php
$ubbt_lang['MB_USERNAME'] = "Username (click to send PM)";
$ubbt_lang['MB_PROFILE'] = "Profile";
$ubbt_lang['MB_SELECT'] = "Select";
$ubbt_lang['MB_PMSEL'] = "PM selected users";
$ubbt_lang['MB_DELSEL'] = "Remove selected users";
$ubbt_lang['MB_POSTS'] = "Posts";
$ubbt_lang['MB_VIEW'] = "View";
?>