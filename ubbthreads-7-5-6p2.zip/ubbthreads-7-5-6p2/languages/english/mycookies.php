<?php
$ubbt_lang['COOKIE_INFO_1'] = "Expiring (deleting) the cookies set in your browser by this board may be useful if you suspect that they are damaged or the board is malfunctioning for you.";
$ubbt_lang['COOKIE_INFO_2'] = "Expiring these cookies will do NO harm, but it will log you out of the board.  Once you log in and start using the board again, new cookies will be set automatically.";
$ubbt_lang['COOKIE_CURRENT'] = "Current Cookie Information";
$ubbt_lang['COOKIE_NAME'] = "Cookie Name";
$ubbt_lang['COOKIE_VALUE'] = "Cookie Value";
$ubbt_lang['COOKIE_EXPIRE'] = "Expire Cookies";
?>
