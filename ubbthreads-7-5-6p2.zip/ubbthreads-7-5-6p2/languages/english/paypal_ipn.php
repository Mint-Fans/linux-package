<?php
$ubbt_lang['FREE_TRIAL_SUB'] = "Free trial activated";
$ubbt_lang['FREE_TRIAL'] = "Your free trial has been activated.  You have been added to the '%%GROUP%%' Subscription Group.";
$ubbt_lang['PAYMENT_RECEIVED_SUB'] = "Payment Received";
$ubbt_lang['PAYMENT_RECEIVED'] = "Your subscription payment for the '%%GROUP%%' Subscription Group has been received.";
$ubbt_lang['PAYMENT_FAILED_SUB'] = "Payment Failed";
$ubbt_lang['PAYMENT_FAILED'] = "Your subscription payment has failed.  You have been removed from the '%%GROUP%%' Subscription Group.";
$ubbt_lang['PAYMENT_PENDING_SUB'] = "Payment Pending";
$ubbt_lang['PAYMENT_PENDING'] = "Your subscription payment is pending.  Once it is received you will be added to the '%%GROUP%%' Subscription Group.";
$ubbt_lang['PAYMENT_DENIED_SUB'] = "Payment Denied";
$ubbt_lang['PAYMENT_DENIED'] = "Your subscription payment has been denied.  You have been removed from the '%%GROUP%%' Subscription Group.";
$ubbt_lang['SUBSCRIPTION_EOT_SUB'] = "Subscription End of Term";
$ubbt_lang['SUBSCRIPTION_EOT'] = "Your subscription has reached the end of term.  You have been removed from the '%%GROUP%%' Subscription Group.";
$ubbt_lang['SUBSCRIPTION_EOT_USER'] = "The subscription for '%%USER%%' has reached the end of it's term.  They have been removed from the '%%GROUP%%' Subscription Group.";
$ubbt_lang['SUBSCRIPTION_CANCEL_SUB'] = "Subscription Canceled";
$ubbt_lang['SUBSCRIPTION_CANCEL'] = "Your subscription has been canceled.  You have been removed from the '%%GROUP%%' Subscription Group.";
$ubbt_lang['DONATION_SUB'] = "Donation Received";
$ubbt_lang['DONATION'] = "Thank you for your donation.  You have been added to the '%%GROUP%%' Subscription Group.";
$ubbt_lang['REFUND_SUB'] = "Payment Refund";
$ubbt_lang['REFUND'] = "Your Subscription Group payment has been refunded.  You have been removed from the '%%GROUP%%' Subscription Group.";
$ubbt_lang['REVERSAL_SUB'] = "Payment Reversal";
$ubbt_lang['REVERSAL'] = "Your Subscription Group payment has been reversed.  You have been removed from the '%%GROUP%%' Subscription Group.";
$ubbt_lang['CANCEL_REVERSAL_SUB'] = "Payment Reversal Canceled";
$ubbt_lang['CANCEL_REVERSAL'] = "The reversal of your Subscription Group payment has been canceled.  You have been added to the '%%GROUP%%' Subscription Group.";
$ubbt_lang['SUB_FAILED_SUB'] = "Subscription Failed";
$ubbt_lang['SUB_FAILED'] = "Your subscription has failed.  You have been removed from the '%%GROUP%%' Subscription Group.";
?>
