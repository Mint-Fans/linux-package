<?php
$ubbt_lang['PREVIEW_SIG'] = "Preview of your signature";
$ubbt_lang['LENGTH'] = "You are using <span class='%%SPAN_CLASS%%'>%%ACTUAL%%</span> of the %%ALLOWED%% allowed characters.";
$ubbt_lang['SHORTEN'] = "You must shorten your signature length.";
?>