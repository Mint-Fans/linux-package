<?php
$ubbt_lang['PASS_MAILED'] = "Password Mailed";
$ubbt_lang['NO_EMAIL'] = "Can't find the email address for";
$ubbt_lang['NO_USERNAME'] = "Can't find a login name of";
$ubbt_lang['PASS_REQ_BODY'] = "A user from the IP Address: %%IP_ADDY%% has requested a temporary password for the Username: '%%USERNAME%%' for the website '%%BOARD_TITLE%%'.\n\nThis is a temporary password that can be used if you have forgotten your original password. If you did not request this, please ignore this message - your original password will still work.\n\nThe temporary password for this username is - %%PASSWORD%%";
?>