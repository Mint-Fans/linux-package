<?php
//  Ultimate Bulletin Board
//
//  Program authors: Rick Baker
//  Copyright (C) 2010 Mindraven.
//  Script Version 7.5.6

//  You may not distribute this program in any manner, modified or
//  otherwise, without the express, written consent from
//  Mindraven.
//
//  You may make modifications, but only for your own use and
//  within the confines of the UBB License Agreement
//  (see our website for that).
//
//  Note: If you modify ANY code within your UBB, we at Mindraven
//  cannot offer you support -- thus modify at your own peril :)

class bbcode {
	var $total_images;
	var $image_limit;
	var $convert;
	var $body;
	var $type;
	var $html;
	var $allowed_tags;
	var $allowed_protocols;
	var $allow_magic_urls;
	var $allow_graemlins;

	var $code_highlight_change_success;
	var $highlight;

	var $graemlin_total;
	var $graemlin_limit;

	/**
	 * The constructor.  Not meant to be called, but handled.
	 */
	function bbcode() {
		// Invisible constructor!
		ini_set('highlight.comment', 'bbcodecomment');
		ini_set('highlight.default', 'bbcodedefault');
		ini_set('highlight.keyword', 'bbcodekeyword');
		ini_set('highlight.string',	'bbcodestring');
		ini_set('highlight.html',	'bbcodehtml');

		$this->highlight = array(
			'string'    => ini_get('highlight.string'),
			'comment'   => ini_get('highlight.comment'),
			'keyword'   => ini_get('highlight.keyword'),
			'bg'        => ini_get('highlight.bg'),
			'default'   => ini_get('highlight.default'),
			'html'      => ini_get('highlight.html')
		);

		$this->code_highlight_change_success = false;
		if ($this->highlight['string'] == 'bbcodestring') {
			$this->code_highlight_change_success = true;
		}
	}

	/**
	 * This method is called every time you want to parse something new
	 */
	function init_post($body, $type, $convert, &$html, $image_limit) {
		global $config;

		$this->body = $body;
		$this->convert = $convert;
		$this->type = $type;
		$this->total_images = 0;
		$this->html = $html;
		$this->allow_magic_urls = true;
		$this->allow_graemlins = true;
		$this->set_image_limit($image_limit);
		$this->graemlin_total = 0;
		$this->graemlin_limit = -1;
		$this->nofollow = '';

		if ($type == "signature" && $config['NOFOLLOW_SIG']) {
			$this->nofollow = 'rel="nofollow"';
		} // end if
		if ($type == "post" && $config['NOFOLLOW_SIG']) {
			$this->nofollow = 'rel="nofollow"';
		} // end if

		// We'll allow the user to use these tags
		$this->allowed_tags = array(
			"code", "php", "html", "sql", "url", "img", "image",
			"s", "b", "i", "u", "quote", "post", "color", "size", "font",
			"list", "email", "spoiler", "noparse", "highlight",
			"sup", "sub","custom","align"
		);

		$this->allowed_protocols = array(
			"http", "https", "ftp",
		);
	}

	function allow_tags($tags) {
		if (is_array($tags)) {
			$this->allowed_tags = array_merge($tags, $this->allowed_tags);
		} else {
			$this->allowed_tags[] = $tags;
		}
	}

	function handle_graemlins($body) {
		global $ubbt_lang, $config;
		if ($this->allow_graemlins && $this->graemlin_limit != 0) {
			// Build graemlins if needed
			if (count($this->html->graemlins) == 0) {
				$this->html->get_graemlins();
			}

			foreach ($this->html->graemlins as $graemlin) {
				list($code, $smiley, $image, $height, $width) = $graemlin;
				if (!$height) $height = 15;
				if (!$width) $width = 15;
				$string = "";

				if ((strpos($code, '$ubbt_lang') === 0)) {
					@eval("\$string = $code;");
				} else {
					$string = $code;
				}
				if ($smiley) {
					$old_smiley = htmlspecialchars($code);
					$smiley = preg_quote($smiley,'/-)');
					if ($this->convert == "markup") {
						$smiley = preg_replace("/>/","&gt;",$smiley);
						$smiley = preg_replace("/</","&lt;",$smiley);
					} // end if
					$repl = "<img src=\"<<GRAEMLIN_URL>>/$image\" alt=\"$old_smiley\" title=\"$old_smiley\" height=\"$height\" width=\"$width\" />";
					for($i = 0; $i < 2; $i++) {
						$body = preg_replace("/( |\n|^|\r|\])($smiley)( |$|\.|\?|!|\n|\r|\[)/ie", '\'$1\'.$this->handle_graemlin(\'$2\', \'' . $repl . '\').\'$3\'',$body);
					}
				}

				if ($string) {
					$old_string = htmlspecialchars($string);
					$string = preg_quote($string, '/-');
					$repl = "<img src=\"<<GRAEMLIN_URL>>/$image\" alt=\"$old_string\" title=\"$old_string\" height=\"$height\" width=\"$width\" />";

					$body = preg_replace("#(\[{$string}\])#e", '$this->handle_graemlin(\'$1\', \''.$repl.'\')', $body);
					$body = preg_replace("#(:{$string}:)#e", '$this->handle_graemlin(\'$1\', \''.$repl.'\')', $body);

				}
			}
		}
		return $body;
	}

	function to_html() {
		global $ubbt_lang, $config, $bbcode_tags;

		// We don't want to work with the original in case we parse twice.
		$body = $this->body;

		if ($this->convert == "none") {
			$body = htmlspecialchars($body);
			$body = str_replace(array("\r\n", "\r", "\n"), "<br />", $body);
			return $body;
		}

		if ($this->type == "shoutbox" || !in_array($this->convert, array("both", "markup"))) {
			if ($this->convert == "html") {
				return escape_ampersand($body);
			}

			if ($this->type != "shoutbox") {
				$body = htmlspecialchars($body);
			}
			$body = preg_replace('#&amp;([a-zA-Z0-9]+);#', '&\1;', $body);
			$body = $this->handle_graemlins($body);
			return $body;
		}

		$code_tags = array('noparse', 'code', 'sql', 'html', 'php');
		$code_repls = array();

		foreach ($code_tags as $code_tag) {
			if (!$this->tag_is_allowed($code_tag)) {
				continue;
			}

			$matches = array();
			preg_match_all("#\[{$code_tag}\](.+?)\[/{$code_tag}\]#is", $body, $matches);
			// Allow for [code[:=]lang] type too (in progress)
			//
			// It will be admin cpanel optional
			if ($code_tag == 'code') {}

			$x = count($matches[0]);

			$code_repls[$code_tag] = array();

			for ($i = 0; $i < $x; $i++) {
				$body = str_replace($matches[0][$i], "[{$code_tag}_LOL_eDoC]{$i}[/{$code_tag}_LOL_eDoC]", $body);
				$code_repls[$code_tag][$i] = $matches[1][$i];
			}
		}

		if ($this->convert == "markup") {
			$body = htmlspecialchars($body);
		}

		$body = $this->handle_graemlins($body);

		// Order of conversion is VERY important.

		if ($this->tag_is_allowed("img")) {
			$body = preg_replace('#\[(img|image)\](.+?)\[/\1\]#ie', '$this->handle_img(\'$2\')',$body);
			$body = preg_replace('#\[(img|image)[=:](.+?)\](.+?)\[/\1\]#ie', '$this->handle_img(\'$3\', \'$2\')',$body);
		}

		// Handle custom tags, if they are allowed 
		if ($this->tag_is_allowed("custom")) {
			foreach ($bbcode_tags as $taginfo) {
				$body = preg_replace($taginfo['regex'], $taginfo['markup'], $body);
			}
		} 

		// Handle URLs
		if ($this->tag_is_allowed("url")) {
			$body = preg_replace('#\[url\](.+?)\[/url\]#ies', '$this->handle_url(\'$1\')', $body);
			$body = preg_replace('#\[url[=:](.+?)\](.+?)\[/url\]#ies', '$this->handle_url(\'$1\', \'$2\')', $body);
		}

		if ($this->allow_magic_urls) {
			for ($i = 0; $i < 3; $i++) {
				$body = preg_replace('#(\n|\r|\]|^|\s|\(|&lt;)([a-zA-Z0-9]+?)://(([a-zA-Z0-9\.\-\_\?=\#/&]|&amp;|%20|\+)+)(&gt;|&lt;|\n|\r|$|,(\s|$)|\?(\s|$)|\)|\[|\s|\.(\s|$))#ie', '\'$1\'.$this->handle_url(\'$2://$3\').\'$5\'', $body);
			}
			$body = preg_replace('#(\n|\r|\]|^|\s|&lt;|\()www\.(([a-zA-Z0-9\.\-\_\?&/\#=]|&amp;|%20|\+)+)($|&gt;|\)|,(\s|$)|\?(\s|$)|\)(\s|$)|\s|\[|\.(\s|$))#ie', '\'$1\'.$this->handle_url(\'http://www.$2\',\'www.$2\').\'$4\'', $body);
		}

		if ($this->tag_is_allowed("b")) {
			$body = preg_replace('#\[b\](.+?)\[/b\]#is', '<span style="font-weight: bold">$1</span>',$body);
		}

		if ($this->tag_is_allowed("i")) {
			$body = preg_replace('#\[i\](.+?)\[/i\]#is', '<span style="font-style: italic">$1</span>',$body);
		}

		if ($this->tag_is_allowed("u")) {
			$body = preg_replace('#\[u\](.+?)\[/u\]#is', '<span style="text-decoration: underline">$1</span>',$body);
		}

		if ($this->tag_is_allowed("s")) {
			$body = preg_replace('#\[s\](.+?)\[/s\]#is', '<span style="text-decoration: line-through">$1</span>',$body);
		}

		if ($this->tag_is_allowed("color")) {
			$body = preg_replace('#\[color[=:](.+?)\](.+?)\[/color\]#ies', '$this->handle_color(\'$1\', \'$2\')',$body);
		}

		if ($this->tag_is_allowed("align")) {
			$body = preg_replace('#\[align[=:](.+?)\](.+?)\[/align\]#ies', '$this->handle_align(\'$1\', \'$2\')',$body);
		}

		if ($this->tag_is_allowed("font")) {
			$body = preg_replace('#\[font[=:](.+?)\](.+?)\[/font\]#ies', '$this->handle_fonts(\'$1\', \'$2\')',$body);
		}

		if ($this->tag_is_allowed("size")) {
			$body = preg_replace('#\[size[=:](.+?)\](.+?)\[/size\]#ies', '$this->handle_sizes(\'$1\', \'$2\')',$body);
		}

		if ($this->tag_is_allowed("quote") && $this->type != "shoutbox") {
			for ($i = 0; $i < $config['NESTED_QUOTES']; $i++) {
				$body = preg_replace('#\[quote[=:](.+?)\](.+?)\[/quote\]#ies', '$this->handle_quotes(\'$1\', \'$2\')',$body);
				$body = preg_replace('#\[quote\](.+?)\[/quote\]#ies', '$this->handle_quotes(\'\', \'$1\')',$body);
			}
		}

		if ($this->tag_is_allowed("spoiler")) {
			$body = preg_replace('#\[spoiler[=:](.+?)\](.+?)\[/spoiler\]#ies', '$this->handle_spoilers(\'$1\', \'$2\')',$body);
			$body = preg_replace('#\[spoiler\](.+?)\[/spoiler\]#ies', '$this->handle_spoilers(\'\', \'$1\')',$body);
		}


		if ($this->tag_is_allowed("email")) {
			$body = preg_replace('#\[email[=:](.+?)\](.+?)\[/email\]#ie', '$this->handle_email(\'$1\', \'$2\')',$body);
			$body = preg_replace('#\[email\](.+?)\[/email\]#ie', '$this->handle_email(\'$1\', \'$1\')',$body);
		}

		if ($this->tag_is_allowed("highlight")) {
			$body = preg_replace( "#\[highlight\](.+?)\[/highlight\]#i", '<span class="standouttext">$1</span>',$body);
		}

		if ($this->tag_is_allowed("sup")) {
			$body = preg_replace('#\[sup\](.+?)\[/sup\]#is', '<span style="vertical-align: super; font-size: 12px">$1</span>',$body);
		}

		if ($this->tag_is_allowed("sub")) {
			$body = preg_replace('#\[sub\](.+?)\[/sub\]#is', '<span style="vertical-align: sub; font-size: 12px">$1</span>',$body);
		}


		if ($this->tag_is_allowed("post")) {
			$body = preg_replace('#\[post[=:](\d+)\](.+?)\[/post\]#ies', '$this->handle_url(\'$1\', \'$2\', true)', $body);
		}

		if ($this->tag_is_allowed("list")) {
			$body = $this->handle_lists($body);
		}

		$body = str_replace(array("\r\n", "\r", "\n"), "<br />", $body);

		// Clean up the lists
		if ($this->tag_is_allowed("list")) {
			$body = preg_replace('#(</?(li|ul|ol)>)((<br />)+)(</?(li|ul|ol)>)#', '$1$5', $body);
			$body = preg_replace('#((<br />)+)(</?(li|ul|ol)>)#', '$3', $body);
			$body = preg_replace('#<li>(\s|<br />)*</li>#', '', $body);
			$body = preg_replace('#</li><(ol|ul)#', '<$1', $body);
			$body = preg_replace('#</(ol|ul)><li>#', '</$1></li><li>', $body);
			$body = preg_replace('#</li><li>(<br />)*</div>#', '', $body);
		}

		$body = preg_replace('#&amp;([a-zA-Z0-9]+);#', '&\1;', $body);
		$code_tags = array_reverse($code_tags);
		foreach ($code_tags as $code_tag) {
			if (!$this->tag_is_allowed($code_tag)) {
				continue;
			}

			foreach ($code_repls["$code_tag"] as $i => $match) {
				$body = str_replace("[{$code_tag}_LOL_eDoC]{$i}[/{$code_tag}_LOL_eDoC]", $this->handle_code($code_tag, $match), $body);
			}
		}


		//return '<xmp>' . $body . '</xmp>';
		return $body;
	}

	function set_allowed_tags($tags) {
		$this->allowed_tags = $tags;
	}

	function tag_is_allowed($tag) {
		return in_array($tag, $this->allowed_tags);
	}

	function set_image_limit($limit) {
		if ($limit == 0) {
			$this->disallow_tag("img");
		}

		$this->image_limit = $limit;
	}

	function handle_graemlin($trigger, $img) {
		$trigger = str_replace('\"', '"', $trigger);
		$img = str_replace('\"', '"', $img);
		// $trigger = :)
		// $img = <img src="..." ... />
		if ($this->graemlin_limit != -1 && $this->graemlin_limit <= $this->graemlin_total) {
			return $trigger;
		}

		$this->graemlin_total++;
		return $img;
	}

	function handle_code($tag, $code) {
		global $ubbt_lang;

		$tag = strtolower($tag);

		if ($tag == "noparse") {
			return $code;
		}

		$lang = array(
			'sql' => 'Sql Query',
			'php' => 'Php Code',
			'code' => 'Code',
			'html' => 'Html',
		);

		$class = "";
		$height = 0;
		$width = 0;

		switch ($tag) {
			case "php":
				$code = $this->php_highlight($code);
				break;
			case "html":
				$code = $this->html_highlight($code);
				break;
			case "sql":
				$code = $this->sql_highlight($code);
				break;
			default:
				// Momma always said to have a default for any switch statement.
				$code = htmlspecialchars($code);
		}

//		$lines = explode("\n", trim($code));
//		$code = '<ol><li>' . implode('</li><li>', $lines) . '</li></ol>';

		// FIXME: Figure out height calculation

		$extra = "";
		$style = "";
//		if ($tag != "code") {
//			$extra = sprintf(' name="code" class="%s" ', $class);
//			$style = ' style="padding: 0; margin: 0" ';
//		}
		if ($tag == "code") {
			//$height = (substr_count($code,"\n") * 16) + 16;
			//if ($height > 150) $height = 150;
			//if ($height < 34) $height = 34;
			//$style="style=\"height: {$height}px;\"";
		}

		if ($this->code_highlight_change_success) {
			$code = str_replace('<span style="color: ', '<span class="', $code);
		}


		$pattern = '<div class="ubbcode-block"><div class="ubbcode-header">%s:</div><div class="ubbcode-body ubbcode-pre" %s><pre%s>%s</pre></div></div>';

		return sprintf($pattern, $lang[$tag], $style, $extra, $code);
	}

	function php_highlight($code) {
		$fix = false;
		if( !preg_match( "#^\s*\<\?#", $code ) ) {
			$fix = true;
			$code = '<?php ' . $code . ' ?' . '>';
		} else {
			//$code = trim($code);
		}

		$code = highlight_string($code, true);
		$code = str_replace(
			array( '<font color="',        '</font>', '&nbsp;', '<br />', 'code>', '    ', ),
			array( '<span style="color: ', '</span>', ' ',       "\n",    'pre>', "\t"  ),
			$code
		);

		if( $fix ) {
			$code = preg_replace( "#&lt;\?(.*?)php\s#i", "\\1", $code, 1 );
			$code = preg_replace( "#\?&gt;([^\?]+)$#i", "\\1", $code, 1 );
			$code = preg_replace("#^(.*?)\n#","",$code, 1);
			$code = preg_replace("#\n(.*?)$#","",$code, 1);
		}

		return $code;
	}

	function html_highlight($code) {
		$code = htmlspecialchars($code);

		$code = preg_replace('#&lt;!\-\-(.+?)\-\-&gt;#s', 'XX_UBB_STUPID_PLACHOLDER_HTML_COMMENT_XX\1\2\3XX_UBB_STUPID_PLACHOLDER_HTML_COMMENT_XX', $code);

		$code = preg_replace('#&lt;(.+?)&gt;#es', '$this->handle_html_tag_helper(\'\1\')', $code);
		$code = preg_replace('#&lt;/([a-z0-9\.\:]+)&gt;#', '&lt;/<span style="color: ' . $this->highlight['keyword'] . '">\1</span>&gt;', $code);
		$code = preg_replace('#(&amp;[a-z0-9]+;)#i', '<span style="color: ' . $this->highlight['keyword'] . '">\1</span>', $code);


		$code = preg_replace("#XX_UBB_STUPID_PLACHOLDER_HTML_COMMENT_XX(.+?)XX_UBB_STUPID_PLACHOLDER_HTML_COMMENT_XX#ies", '"<span style=\"color: " . $this->highlight[\'comment\'] . "\">&lt;!--" . $this->strip_tags_special(\'\1\') . "--&gt;</span>"', $code);
		return $code;
	}

	function handle_html_tag_helper($body) {
		$body = str_replace('\"', '"', $body);

		if (strpos($body, '!') === 0) {
			return '<span style="font-style: italic">&lt;' . $body . '&gt;</span>';
		}

		// We currently have something like
		// a href="foo.php" title="moo"
		$body = preg_replace('#^([a-z0-9\.\:]+)#i', '<span style="color: ' . $this->highlight['keyword'] . '">\1</span>', $body);

		$body = preg_replace("#([a-z:]+)(\s*)=(\s*)(&quot;|')(.*?)(?<!\\\\)\\4#i", '<span style="color: ' . $this->highlight['keyword'] . '">\1</span>\2=\3<span style="color: ' . $this->highlight['string'] . '">\4\5\6\4</span>', $body);

		return '&lt;' . $body . '&gt;';
	}

	function sql_highlight($code) {
		$sql_keywords =  'absolute action add after alter as asc at authorization begin bigint ' .
					'binary bit by cascade char character check checkpoint close collate ' .
					'column commit committed connect connection constraint contains continue ' .
					'create cube current current_date current_time cursor database date ' .
					'deallocate dec decimal declare default delete desc distinct double drop ' .
					'dynamic else end end-exec escape except exec execute false fetch first ' .
					'float for force foreign forward free from full function global goto grant ' .
					'group grouping having hour ignore index inner insensitive insert instead ' .
					'int integer intersect into is isolation key last level load local max min ' .
					'minute modify move name national nchar next no numeric of off on only ' .
					'open option order out output partial password precision prepare primary ' .
					'prior privileges procedure public read real references relative repeatable ' .
					'restrict return returns revoke rollback rollup rows rule schema scroll ' .
					'second section select sequence serializable set size smallint static ' .
					'statistics table temp temporary then time timestamp to top transaction ' .
					'translation trigger true truncate uncommitted union unique update values ' .
					'varchar varying view when where with work';

		$sql_functions =	'abs avg case cast coalesce convert count current_timestamp ' .
					'current_user day isnull left lower month nullif replace right ' .
					'session_user space substring sum system_user upper user year';

		$sql_operators =	'all and any between cross in join like not null or outer some';

		$code = str_replace(array('<', '>'), array('&lt;', '&gt;'), $code);

		$code = preg_replace("#(\"|'|`)(.+?)(?<!\\\\)\\1#", '<span style="color: ' . $this->highlight['string'] . '">XX_UBB_STUPID_PLACHOLDER_SQL_STRING_XX' . '\1\2\3\1' . 'XX_EFND_UBB_STUPID_PLACHOLDER_SQL_STRlING_XX</span>', $code);
		$code = preg_replace("#(\b)(" . str_replace(" ", "|", $sql_operators) . ")(\b)#is", '\1<span style="color: ' . $this->highlight['keyword'] . '">\2</span>\3', $code);
		$code = preg_replace("#(\b)(" . str_replace(" ", "|", $sql_keywords ) . ")(\b)#is", '\1<span style="color: ' . $this->highlight['keyword'] . '">\2</span>\3', $code);
		$code = preg_replace("#(\b)(" . str_replace(" ", "|", $sql_functions) . ")(\b)#is", '\1<span style="color: ' . $this->highlight['keyword'] . '">\2</span>\3', $code);

		$code = preg_replace("#XX_UBB_STUPID_PLACHOLDER_SQL_STRING_XX(.+?)XX_EFND_UBB_STUPID_PLACHOLDER_SQL_STRlING_XX#ie", '$this->strip_tags_special(\'\1\')', $code);

		return $code;
	}

	function strip_tags_special($body) {
		$body = str_replace('\"', '"', $body);
		return strip_tags($body);
	}

	/**
	 * Set a single tag to be disabled
	 */
	function disallow_tag($tag) {
		$x = count($this->allowed_tags);
		$found = false;
		$i = 0;
		for ($i = 0; $i < $x; $i++) {
			if ($this->allowed_tags[$i] === $tag) {
				$found = true;
				break;
			}
		}

		if ($found) {
			unset($this->allowed_tags[$i]);
		}
	}

	function handle_url($url, $body = "", $is_post = false) {
		static $protocols = null;

		$body = str_replace('\"', '"', $body);

		if ($protocols == null) {
			$protocols = implode('|', $this->allowed_protocols);
		}

		if ($body == "") {
			$body = $url;
		}

		if (!$is_post && !preg_match("#^({$protocols})#", $url)) {
			return sprintf("[url=%s]%s[/url]", $url, $body);
		}

		if ($is_post && !preg_match('#^\d+$#', $is_post)) {
			return sprintf("[post=%s]%s[/url]", $url, $body);
		}

		// Do we add a title attribute?
		$title = "";

		if ($is_post) {
			$url = make_ubb_url("ubb=showflat&Number=$url", "", true);
		}

		// Occasionally a ., ?, <, or > sneaks through at the end of the url
		$url = preg_replace('#(&lt;|&gt;|\.|\?|\[|\])$#', '', $url);

		// Handle url shortening in this case
		if (strlen($body) > 100 && !preg_match("#(<img src|<span)#",$body)) {
			$title = sprintf('title="%s"', preg_replace('#[^a-zA-Z0-9 ]#', '', strip_tags($body)));
			$body = substr($body, 0, 40) . "..." . substr($body, -15);
		}

		return sprintf('<a href="%s" %s %s target="_blank">%s</a>', $url, $title, $this->nofollow, $body);
	}

	function handle_quotes($user, $body) {
		global $ubbt_lang;
		$body = str_replace('\"', '"', $body);

		$header = $ubbt_lang['IN_REPLY'] . ':';
		if ($user) {
			$header = $ubbt_lang['QUOTE_POSTED'] . ' ' . $user;
		}

		return sprintf('<div class="ubbcode-block"><div class="ubbcode-header">%s</div><div class="ubbcode-body">%s</div></div>', $header, $body);
	}

	function handle_email($addy, $body) {
		$body = str_replace('\"', '"', $body);
		if (!preg_match('#^([\+_a-z0-9\-]+(\.[_a-z0-9\-]+)*@[a-z0-9\-]+(\.[a-z0-9\-]+)*(\.[a-z]{2,4}))$#i', $addy)) {
			if ($addy == $body) {
				return sprintf('[email]%s[/email]', $addy);
			} else {
				return sprintf('[email:%s]%s[/email]', $addy, $body);
			}
		}


		if ($addy == $body) {
			$body = $this->encode_email($body);
		}
		$encoded = $this->encode_email("mailto:" . $addy);

		return sprintf('<a href="%s">%s</a>', $encoded, $body);
	}

	function encode_email($email) {
		$encoded = "";

		for ($i = 0; $i < strlen($email); $i++) {
			if ($i % 3) {
				$encoded .= "&#" . ord(substr($email, $i, 1)) . ";";
			} else {
				$encoded .= substr($email, $i, 1);
			}
		}

		return $encoded;
	}

	function handle_spoilers($spoiler, $body) {
		global $ubbt_lang;
		$body = str_replace('\"', '"', $body);
		$header = $ubbt_lang['SPOILER_WARNING'];
		if ($spoiler) {
			$header .= ' (' . $spoiler . ')';
		}

		return sprintf('<div class="ubbcode-block"><div class="ubbcode-header">%s <input type="button" class="form-button" value="%s" onclick="toggle_spoiler(this, \'%s\', \'%s\')" /></div><div class="ubbcode-body"><div style="display: none;">%s</div></div></div>', $header, $ubbt_lang['SPOILER_SHOW'], $ubbt_lang['SPOILER_HIDE'], $ubbt_lang['SPOILER_SHOW'], $body);
	}

	function handle_img($url, $align="", $bypass_filter = false) {
		if ($this->total_images >= $this->image_limit || (!$bypass_filter && !preg_match('#^[^\[\'"\]]+?\.(gif|png|jpg|jpeg)$#i', $url))) {
			if ($align != "") {
				return sprintf('[img:%s]%s[/img]', $align, $url);
			} else {
				return sprintf('[img]%s[/img]', $url);
			}
		}

		$this->total_images++;

		if ($align != "") {
			$align = "align=\"$align\"";
		}

		return sprintf('<img src="%s" %s alt="" />', $url, $align);
	}

	function handle_color($color, $body) {
		$body = str_replace('\"', '"', $body);
		if (!preg_match('#^((\#[0-9a-fA-F]{6})|([a-zA-Z_]+))$#', $color)) {
			return sprintf('[color:%s]%s[/color]', $color, $body);
		}

		return sprintf('<span style="color: %s">%s</span>', $color, $body);
	}

	function handle_align($align, $body) {
		$body = str_replace('\"', '"', $body);
		if (!in_array($align, array("left","right","center"))) {
			return sprintf('[align:%s]%s[/align]', $align, $body);
		}

		return sprintf('<div style="text-align: %s">%s</div>', $align, $body);
	}

	function set_fonts($fonts) {
		$this->font_faces = $fonts;
	}

	function set_sizes($sizes) {
		$this->font_sizes = $sizes;
	}

	function handle_sizes($size, $body) {
		$body = str_replace('\"', '"', $body);
		if (!in_array($size, $this->font_sizes)) {
			return sprintf('%s %s ',"", $body);
		}

		return sprintf('<span style="font-size: %s">%s</span>', $size, $body);
	}

	function handle_fonts($face, $body) {
		$body = str_replace('\"', '"', $body);
		if (!in_array($face, $this->font_faces)) {
			return sprintf('[font:%s]%s[/font]', $face, $body);
		}

		return sprintf('<span style="font-family: \'%s\'">%s</span>', $face, $body);
	}

	function handle_lists($body) {
		$body = str_replace('\"', '"', $body);
		$find = '([a-zA-Z0-9]+)';
		if (preg_match("#\[list([=:]$find)?\](.+?)\[/list\]#is", $body)) {
			$tokens = preg_split( "#(\[list[=:]?$find?\]|\[/list\])#is", $body, -1, PREG_SPLIT_DELIM_CAPTURE );
			$acc = "";
			$types = array();
			$depth = 0;
			$ignore_next_token = false;
			foreach( $tokens as $toke ) {
				if ($ignore_next_token) {
					$ignore_next_token = false;
					continue;
				}

				if( preg_match( "#\[list[:=]$find\]#i", $toke ) ) {
					$type = preg_replace( "#\[list[:=]($find)\]#i", '$1', $toke );

					$style = "";
					switch ($type) {
						case "disc":
						case "circle":
						case "square":
							$style = $type;
							break;
						case "I":
							$style = "upper-roman";
							break;
						case "i":
							$style = "lower-roman";
							break;
						case "A":
							$style = "upper-alpha";
							break;
						case "a":
							$style = "lower-alpha";
							break;
						default:
							$style = "decimal";
							break;
					}

					array_push($types, $type);
					$ignore_next_token = true;
					$acc .= '<ol style="list-style-type: ' . $style . '">';

					$depth++;
				} else if( preg_match( "#^\[list\]$#i", $toke ) ) {
					array_push( $types, "empty" );
					$ignore_next_token = false;
					$acc .= '<ul style="list-style-type: disc">';
					$depth++;
				} else if( preg_match( "#^\[/list\]$#i", $toke ) ) {
					$type = array_pop( $types );
					if( $type != "empty" && $type ) {
						$acc .= "</ol>";
					} else if( $type ) {
						$acc .= "</ul>";
					}
					$type = "";
					$depth--;
				} else if( $depth ) {
					// We are currently in a list
					$items = explode( '[*]', $toke );
					$acc .='<li>' . implode( '</li><li>', $items ) . '</li>';

				} else {
					$acc .= $toke;
				}
			}

			while (isset($types[0])) {
				$type = array_pop( $types );
				if ($type != "empty" && $type) {
					$acc .= '</ol>';
				} else if ($type) {
					$acc .= '</ul>';
				}
			}
			$body = $acc;
		}
		return $body;
	}
}
?>
