<?php
//	Ultimate Bulletin Board
//
//	Program authors: Rick Baker
//	Copyright (C) 2010 Mindraven.
//	Script Version 7.5.6

//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	Mindraven.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that).
//
//	Note: If you modify ANY code within your UBB, we at Mindraven
//	cannot offer you support -- thus modify at your own peril :)


// #########################################################################
// Database class for mysql functions
// #########################################################################
class sql {
	// #######################################################################
	// Connect to the database
	// #######################################################################
	function connect() {
		global $config, $debug, $querycount;

		$querycount = 0;

		if( ! isset( $this->dbh ) ) {
			$this->debug_output = "";

			if( ! isset( $config['PERSISTENT_DB_CONNECTION'] ) || ! $config['PERSISTENT_DB_CONNECTION'] ) {
				$this->dbh = mysql_connect( $config['DATABASE_SERVER'], $config['DATABASE_USER'], $config['DATABASE_PASSWORD'], 1 );
			} else {
				$this->dbh = mysql_pconnect( $config['DATABASE_SERVER'], $config['DATABASE_USER'], $config['DATABASE_PASSWORD'] );
			}
		}

		if( ! $this->dbh ) {
			$this->not_right( "Unable to connect to the database!" );
		}

		if( ! mysql_select_db( $config['DATABASE_NAME'], $this->dbh ) ) {
			$this->not_right( "Unable to select database!" );
		}
	}

	// #######################################################################
	// Grab the error descriptor
	// #######################################################################
	function graberrordesc() {
		return mysql_error();
	}

	// Determine if the parameter is an integer
	function is_int($x) {
		return preg_match("#^\d+$#", $x);
	}

	// #######################################################################
	// Grab the error number
	// #######################################################################
	function graberrornum() {
		return mysql_errno();
	}

	// #######################################################################
	// Throw an error (Wrapper Function to reduce code)
	// #######################################################################
	function throw_error( $errstr, $is_bare = false ) {
		global $admin, $html;

		if (defined('IS_ADMIN')) {
			$admin->error( $errstr );
		} else if (defined('IS_IMPORT') || defined('IS_UPGRADE')) {
			echo '<b>SQL Error:</b> ' . $errstr;
		} else {
			if (!is_object($html)) {
				$html = new html;
			}

			if (defined('NO_WRAPPERS')) $is_bare = true;

			( $is_bare ? $html->not_right_bare( $errstr ) : $html->not_right( $errstr ) );
		}
	}

	// #######################################################################
	// Do a placeholder query
	// #######################################################################
	function do_placeholder_query( $query="", $subst = array(), $line="", $file="" ) {

		if( !is_array( $subst ) ) {
			$doom = debug_backtrace();
			$this->throw_error( "BUG: do_placeholder_query was called without the replacement array.  Caller: {$doom[0]['file']}:{$doom[0]['line']}" );
		} // end if

		$kaboom = explode( "?", $query );
		$places = sizeof( $kaboom ) - 1;
		$replaces = sizeof( $subst );
		if( $places > $replaces ) {
			// Fewer places than replaces.  Pad the replace array with blanks.
			$subst = array_pad($subst, $places, "");
			$this->throw_error( "Tried to replace $places placeholders with $replaces replaces.  That's bad.  Here's the query: $query" );
		} else if ( $replaces > $places ) {
			// More replaces than places?  That's even worse.  Fatal, in fact.
			// FIXME: Need to cover this up a bit better...
			$this->throw_error( "Tried to replace $places placeholders with $replaces replaces.  That's too many.  Here's the query: $query" );
		} // end if

		// Good, we can actually run now.
		$query = "";
		for($i = 0; $i < $places; $i++) {
			$query .= array_shift( $kaboom );

			// Escape and add quotes to the string if we need to
			$string = array_shift( $subst );

			if( is_array( $string ) ) {
				// If this is an array, join it with commas after escaping
				// Primary use: IN(?) and INSERT INTO tablename(COL, COL, ...) VALUES(?)
				$new_ary = array();


				foreach( $string as $str ) {
					$new_ary[] = $this->is_int( $str ) ? $str : "'" . mysql_real_escape_string($str) . "'";
				} // end foreach

				$string = implode( ", ", $new_ary );
			} else if (!$this->is_int($string) || $string[0] == '0') {
				// Escape the string only if it isn't a plain number or NULL
				$string = "'" . mysql_real_escape_string($string) . "'";
			} # end if
			$query .= $string;
		} // end for
		$query .= $kaboom[0]; // last piece after the last substitution
		return $this->do_query( $query, $line, $file );
	}
	// #######################################################################
	// Do the query
	// #######################################################################
	function do_query( $query, $line="", $file="" ) {
		global $querycount,$debug,$user,$mysqltime,$html,$admin;
		$querycount++;

		$status = array_get($user, 'USER_MEMBERSHIP_LEVEL', null);
		$explain = ($debug &&  ($status == null || $status == 'Administrator'));

		if( $explain ) {
			// If we are in debug mode then we are going to EXPLAIN each
			// query but only to admins

			if( isset( $this->debug ) && ! ( $this->debug = $debug ) ) {
				$this->debug_output = "";
			}

			$sth =  mysql_query( "EXPLAIN $query", $this->dbh );
			$query2 = preg_replace( '#,(\S)#', ', \1', trim( $query ) );
			$query2 = htmlspecialchars($query2);
			$numFields = "";
			if( $sth ) {
				$numFields = $this->num_fields( $sth );
			}

			$extra = "";
			if( ! preg_match( '#\s*SELECT#i', $query2 ) ) {
				$extra = " <i class=\"e\">Non-Select Query</i>";
			}

			$this->debug_output .= "<table>\n<tr class=\"a\"><td colspan=\"$numFields\">Query $extra</td></tr>";
			$this->debug_output .= "\n<tr class=\"d\">\n\t<td colspan=\"$numFields\">\n\t\t<div class=\"tt\">{$query2}\n\t\t</div></td>\n</tr>\n";
			$this->debug_output .= "<tr class=\"b\">";

			for ( $i=0; $i < $numFields; $i++) {
				$this->debug_output .= "\n\t<td>" . $this->field_name( $sth, $i ) . "</td>";
			}

			$this->debug_output .= "\n</tr>";
			while( $results = $this->fetch_array( $sth ) ) {
				$this->debug_output .= "\n<tr class=\"c\">";
				for( $i = 0; $i < $numFields; $i++ ) {
					if( ! isset( $results[$i] ) ) {
						$results[$i] = "&nbsp;";
					}
					$results[$i] = preg_replace( '#,(\S)#', ', \1', $results[$i] );
					$this->debug_output .= "\n\t<td>" . ( isset( $results[$i] ) ? $results[$i] : "&nbsp;" ) . "</td>";
				}
				$this->debug_output .= "\n</tr>";
			}
		}

		$mytimea = getmicrotime();
		$sth = mysql_query( $query, $this->dbh );
		$mytime = round( getmicrotime() - $mytimea, 4 );
		$mysqltime = $mysqltime + $mytime;

		// If in debug mode we will also show the time needed to execute the query.
		if( $explain ) {
			$this->debug_output .= "<tr class=\"a\">\n\t<td colspan=\"$numFields\">Query took a total of $mytime seconds.</td>\n</tr>\n</table><br />";
		}

		if( ! $sth ) {
			if( defined('IS_UPGRADE') || defined('IS_IMPORT') ) {
				echo mysql_error();
			} else {
				define('IS_SQL_ERROR',1);
				$this->not_right( $query, $line, $file );
			}
		}

		return $sth;
	}

	// #######################################################################
	// Fetch the next row in an array
	// #######################################################################
	function fetch_array($sth, $type = MYSQL_BOTH) {
		if (is_resource($sth)) {
			return mysql_fetch_array($sth, $type);
		}
		return false;
	}

	// #######################################################################
	// Get a result row as an enumerated array
	// #######################################################################
	function mysql_fetch_row( $sth ) {
		return mysql_fetch_row( $sth );
	}

	// #######################################################################
	// Finish the statement handler
	// #######################################################################
	function finish_sth( $sth ) {
		if (is_resource($sth)) {
			return mysql_free_result( $sth );
		}
	}

	// #######################################################################
	// Grab the total rows
	// #######################################################################
	function total_rows( $sth ) {
		return mysql_num_rows( $sth );
	}

	function affected_rows() {
		return mysql_affected_rows($this->dbh);
	}

	function last_insert_id($line, $file) {
		$sth = $this->do_query("SELECT last_insert_id()", $line, $file);
		list($id) = $this->fetch_array($sth, MYSQL_BOTH);
		return $id;
	}

	// #######################################################################
	// Grab the number of fields
	// #######################################################################
	function num_fields( $sth ) {
		return mysql_num_fields( $sth );
	}

	// #######################################################################
	// Grab the field name
	// #######################################################################
	function field_name($sth,$i) {
		return mysql_field_name( $sth, $i );
	}


	// #######################################################################
	// Die
	// #######################################################################
	function not_right( $error, $line="", $file="" ) {
		global $user,$config,$html;

		// IF YOU SET THE VARIABLE BELOW TO 1 IT WILL SHOW THE SQL ERRORS TO ALL
		// USERS.  USEFUL IF YOU CANNOT LOG IN AND NEED TO SEE THE SQL ERRORS
		$showerror = 0;
		if (defined('INSTALL')) {
			$showerror = 1;
		}

		$mysql_error = mysql_error();

		$now  = time();
		$time = '';

		if( $config['LOG_SQL_ERRORS'] ) {
			$log_dir = array_get($config, 'SQL_LOG_PATH', false);
			if( $log_dir) {
				$date     = date('Ymd', $now);              // example: '20021018'
				$time     = date('D, M d Y H:i:s O', $now); // example: 'Fri Oct 18 21:50:13 2002 +0200'
				$log_file = "$log_dir/{$date}_mysql.log";
				$who      = array_get($user, 'USER_DISPLAY_NAME', find_environmental('REMOTE_ADDR'));
				@error_log("[ERROR][$time] [$script_name] [$who] Script: $file - Line: $line $error - $mysql_error\n", 3, $log_file);
			}
		}

		$connect_array = array( 2001, 2002, 2003, 2004, 2005, 2006, 2013 );

		if($showerror || defined( 'SHOW_SQL_LOGS' ) || array_get($user, 'USER_MEMBERSHIP_LEVEL', 'User') == 'Administrator') {
			$show_error = "<b>Script:</b> $file<br />";
			$show_error .= "<b>Line#:</b> $line<br />";
			if (in_array(mysql_errno(),$connect_array)) {
				$show_error .= "<b>SQL Error:</b> " . mysql_error() . "<br /><b>Please verify that your MySQL server is running</b><br />";
			} else {
				$show_error .= "<b>SQL Error:</b> " . mysql_error() . "<br />";
			} // end if
			$show_error .= "<b>SQL Error #:</b> " . mysql_errno() . "<br />";
			$show_error .= "<b>Query:</b> <code>$error</code>";
		} else {
			if (in_array(mysql_errno(),$connect_array)) {
				$show_error = "Unable to connect to database server, please try again in a few minutes.";
			} else {
				$show_error = 'Database error only visible to forum administrators';
			}
		}

		$this->throw_error( $show_error, true );
	}
}
?>
