<?php
//	Script Version 7.5.7

require("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/addimage.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$type = get_input("type","get");

if ($type == "icons") {
	$tabtext = $ubbt_lang['NEW_PICON'];
	$formtype = $ubbt_lang['ICON_FORM'];
	$imagetype = $ubbt_lang['P_ICON'];
	$submitname = $ubbt_lang['I_SUBMIT'];
	$returntab = 0;
	$return = "icons_display";
}
elseif ($type == "avatars") {
	$tabtext = $ubbt_lang['NEW_AVATAR'];
	$formtype =  $ubbt_lang['AVATAR_FORM'];
	$imagetype = $ubbt_lang['AVATAR_IMAGE'];
	$submitname = $ubbt_lang['A_SUBMIT'];
	$returntab = 2;
	$return = "avatars_display";
}
elseif ($type == "forumimages") {
	$tabtext = $ubbt_lang['NEW_BIMAGE'];
	$formtype =  $ubbt_lang['BIMAGE_FORM'];
	$imagetype = $ubbt_lang['BIMAGE'];
	$submitname = $ubbt_lang['F_SUBMIT'];
	$returntab = 3;
	$return = "fimages_display";
}
elseif ($type == "news") {
	$tabtext = $ubbt_lang['NEW_NEWSIMAGE'];
	$formtype =  $ubbt_lang['NEWSIMAGE_FORM'];
	$imagetype = $ubbt_lang['NEWS_IMAGE'];
	$submitname = $ubbt_lang['N_SUBMIT'];
	$returntab = 4;
	$return = "newsimages_display";
}
elseif ($type == "mood") {
	$tabtext = $ubbt_lang['NEW_MOOD'];
	$formtype =  $ubbt_lang['MOOD_FORM'];
	$imagetype = $ubbt_lang['MOOD_IMAGE'];
	$submitname = $ubbt_lang['M_SUBMIT'];
	$returntab = 5;
	$return = "mood_display";
}


$tabs = array(
	"$tabtext" => ""
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['IM_IC']);
$admin->setParentTitle($ubbt_lang['IM_IC'],"$return.php?returntab=$returntab");
$admin->setPageTitle($ubbt_lang['NEW_PICON']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/addimage.tmpl");

$admin->sendFooter();
?>
