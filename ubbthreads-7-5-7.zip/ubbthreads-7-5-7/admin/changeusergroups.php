<?php
//	Script Version 7.5.7

if (!defined('GROUP')) {
	exit;
}

require ("../languages/{$config['LANGUAGE']}/admin/changeusergroups.php");


// Grab all non-disabled groups that we can directly change
$group = array();
$query = "
	SELECT GROUP_ID,GROUP_NAME
	FROM {$config['TABLE_PREFIX']}GROUPS
	WHERE GROUP_IS_DISABLED <> '1'
	AND GROUP_ID > '3'
	AND GROUP_ID <> '5'
";
$i=0;
$sth=$dbh->do_query($query,__LINE__,__FILE__);
while(list($gid,$gname) = $dbh->fetch_array($sth)) {
	$group[$i]['id'] = $gid;
	$group[$i]['name'] = $gname;
	$i++;
}


$tabs = array(
	"{$ubbt_lang['CHANGE_GROUPS']}" => ""
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['MEM_MAN']);
$admin->setParentTitle($ubbt_lang['MEM_MAN'],"membermanage.php");
$admin->setPageTitle($ubbt_lang['CHANGE_GROUPS']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/changeusergroups.tmpl");

$admin->sendFooter();

exit;
?>
