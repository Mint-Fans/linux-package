<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/createcat.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$tabs = array(
	"{$ubbt_lang['CAT_HEAD']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['CAT_SET']);
$admin->setParentTitle($ubbt_lang['CAT_SET'],"catmanage.php");
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['CAT_HEAD']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
include("../templates/default/admin/createcat.tmpl");

$admin->sendFooter();
?>
