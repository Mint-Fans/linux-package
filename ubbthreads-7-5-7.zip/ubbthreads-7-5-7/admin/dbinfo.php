<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/dbinfo.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Grab the database info
$search_prefix = str_replace ("_", "\_", $config['TABLE_PREFIX'])."%";
$query = "
	SHOW TABLE STATUS LIKE ?
";
$sth = $dbh->do_placeholder_query($query,array($search_prefix),__LINE__,__FILE__);
$numFields = $dbh -> num_fields($sth);
$results = "<tr>";
$ignore = array();
$dataarray = array();
$indexarray = array();
$totalrows = array();
$rows = 0;
$data = 0;
$indexes = 0;
for ( $i=0; $i<$numFields; $i++) {
	if (!preg_match("/^(name|rows|data_length|index_length)/i",$dbh->field_name($sth,$i))) {
		$ignore[] = $i;
		continue;
	}
	if (preg_match("/^data_length/i",$dbh->field_name($sth,$i))) {
		$dataarray[] = $i;
	}
	if (preg_match("/^index_length/i",$dbh->field_name($sth,$i))) {
		$indexarray[] = $i;
	}
	if (preg_match("/^rows/i",$dbh->field_name($sth,$i))) {
		$totalrows[] = $i;
	}
	$results .= "<td class=\"autorow-header-1 autoleft autoright autotop autobottom bold\">" . $dbh -> field_name($sth, $i) ."</td>";
}
$results .= "<td class=\"autorow-header-1 autoleft autotop autobottom bold\">&nbsp;</td>";
$results .= "</tr>";
while ( $vals = $dbh -> fetch_array($sth)) {
	$results .= "<tr>";
	$valsize = sizeof($vals);
	$name = "";
	for ( $i=0; $i<$numFields; $i++) {
		if (in_array($i,$ignore)) {
			continue;
		}

		if (in_array($i,$dataarray)) {
			$data = $data + $vals[$i];
			$vals[$i] = convertsize($vals[$i]);
		}
		if (in_array($i,$indexarray)) {
			$indexes = $indexes + $vals[$i];
			$vals[$i] = convertsize($vals[$i]);
		}
		if (in_array($i,$totalrows)) {
			$rows = $rows + $vals[$i];
		}
		$results .= "<td valign=\"top\" class=\"stdautorow colored-row autoleft autoright autotop autobottom\">$vals[$i]</td>";
	}
	$results .= "<td valign=\"top\" class=\"stdautorow colored-row autoleft autotop autobottom\"><a href=\"{$config['BASE_URL']}/admin/dodbcommand.php?action=optimize&amp;table={$vals['Name']}\">{$ubbt_lang['OPTIMIZE']}</a></td>";
	$results .= "</tr>";
}

$data = convertsize($data);
$indexes = convertsize($indexes);

// Function for human readable file sizes
function convertsize ($size) {
    $Mult = floor($size = log($size+1) / log(1024));
    return round(pow(1024, $size - $Mult) * 100) / 100 . " " .  substr(" KMGT", $Mult, min(1, $Mult)) . "B";
}

$tabs = array(
	"{$ubbt_lang['INFO']}" => "",
	"{$ubbt_lang['COMMAND']}" => "database.php?returntab=1",
	"{$ubbt_lang['BACKUP']}" => "dbbackup.php?returntab=2"
);

$admin->setCurrentMenu($ubbt_lang['DATABASE']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['DATABASE']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
include("../templates/default/admin/dbinfo.tmpl");

$admin->sendFooter();
?>
