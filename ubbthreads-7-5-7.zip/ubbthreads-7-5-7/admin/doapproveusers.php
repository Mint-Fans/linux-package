<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/doapproveusers.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

// Who can access this page? Admins only or Admins and Moderators
define('ADMINISTRATORS',1);
define('MODERATORS',0);
$admin->doAuth();

$returntab = get_input("returntab","post");
$totals = get_input("totals","post");
$ubbt_admin = get_input("{$config['COOKIE_PREFIX']}ubbt_admin","cookie");

for ($i=0;$i<=$totals;$i++) {
	$field = "action-$i";
	$useraction = get_input($field,"post");
	list($action,$uid) = preg_split("#-#",$useraction);

	if ($action != "none") {
		$query = "
			select	t1.USER_IS_APPROVED,t2.USER_REAL_EMAIL,t1.USER_DISPLAY_NAME
			from	{$config['TABLE_PREFIX']}USERS as t1,
				{$config['TABLE_PREFIX']}USER_PROFILE as t2
			where	t1.USER_ID = ?
			and	t2.USER_ID = t1.USER_ID
		";
		$sth = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
		list($code,$email,$uname) = $dbh->fetch_array($sth);
	}

	// Send the address verification email
	if ($action == "resend") {
		$query = "
			select	t1.USER_IS_APPROVED,t2.USER_REAL_EMAIL,t1.USER_DISPLAY_NAME,t2.USER_LANGUAGE
			from	{$config['TABLE_PREFIX']}USERS as t1,
							{$config['TABLE_PREFIX']}USER_PROFILE as t2
			where	t1.USER_ID = ?
			and	t1.USER_ID = t2.USER_ID
		";
		$sth = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
		list($code,$email,$display_name,$lang) = $dbh->fetch_array($sth);

		// If there is no verify code, we need to generate one
		if ($code == "no") {
			$keyset = array('a','b','c','d','e','f','g','h','i','j','k','m','n','o','p','q','r','s','t','u','v','x','y','z','A','B','C','D','E','F','G','H','I','J','K','M','N','P','Q','R','S','T','U','V','W','X','Y','Z','2','3','4','5','6','7','8','9');
			$chars = sizeof($keyset) - 1;
			$code = "";
			$a = time();
			mt_srand($a);
			for ($i=0; $i < 8; $i++) {
				$randnum = intval(mt_rand(0,$chars));
				$code .= $keyset[$randnum];
			}
			$query = "
				UPDATE {$config['TABLE_PREFIX']}USERS
				SET USER_IS_APPROVED = ?
				WHERE USER_ID = ?
			";
			$dbh->do_placeholder_query($query,array($code,$uid),__LINE__,__FILE__);
		}
		// Send the email with the verification link
		$mailer  = new mailer("../");
		$mailer->set_language($lang);
		$mailer->set_subject('DAUV_SUBJECT', array('USERNAME' => $display_name));
		$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $display_name));
		$mailer->add_content('DAUV_CONTENT', array('VERIFY_URL' => make_ubb_url("ubb=verifyemail&verify=$uid-$code", "", true, true)),true);
		$mailer->ubbt_mail($email);
	}

	// Approve the registration
	if ($action == "approve") {
		$query = "
			UPDATE {$config['TABLE_PREFIX']}USERS
			SET USER_IS_APPROVED='yes'
			WHERE USER_ID = ?
		";
		$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
		$query = "
			SELECT USER_DISPLAY_NAME
				FROM {$config['TABLE_PREFIX']}USERS
			WHERE USER_ID = ?
		";
		$stx = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
		list($appname) = $dbh->fetch_array($stx);
		$mailer  = new mailer("../");
		$mailer->set_language($config['LANGUAGE']);
		$mailer->set_subject('DAUA_SUBJECT');
		$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $appname));
		$mailer->add_content('DAUA_CONTENT', array('USERNAME' => $uname, 'BOARD_TITLE' => $config['COMMUNITY_TITLE']));
		$mailer->ubbt_mail($email);

		admin_log("USER_APPROVED", "<a href='{$config['BASE_URL']}/admin/showuser.php?uid=$uid'>$appname</a>");
	}

	// Delete the registration
	if ($action == "delete") {
		$field = "reason-$i";
		$reason = get_input($field,"post");
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}USERS
			WHERE USER_ID = ?
		";
		$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}USER_PROFILE
			WHERE USER_ID = ?
		";
		$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}USER_DATA
			WHERE USER_ID = ?
		";
		$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}USER_GROUPS
			WHERE USER_ID = ?
		";
		$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);

		admin_log("USER_REG_DENIED", "$uname: $reason");

		// If we have a reason, inform the poor bastard :)
		if ($reason) {
			$mailer  = new mailer("../");
			$mailer->set_language($config['LANGUAGE']);
			$mailer->set_subject('DAUD_SUBJECT');
			$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $uname));
			$mailer->add_content('DAUD_CONTENT', array('USERNAME' => $uname, 'BOARD_TITLE' => $config['COMMUNITY_TITLE'], 'REASON' => $reason));
			$mailer->ubbt_mail($email);
		}
	}
}

// ----------------------------------
// Update the newuser/totaluser cache
$sth = $dbh->do_query("SELECT COUNT(*) FROM {$config['TABLE_PREFIX']}USERS WHERE USER_IS_APPROVED='yes'",__LINE__,__FILE__);
list($registered) = $dbh -> fetch_array($sth);
$dbh -> finish_sth($sth);

// ---------------------------------------------------------
// let's grab the name of the most recently registered user
$query = "
	SELECT USER_DISPLAY_NAME,USER_ID
	FROM {$config['TABLE_PREFIX']}USERS
	WHERE USER_IS_APPROVED='yes'
	ORDER BY USER_ID DESC LIMIT 0,1
";
$sth = $dbh -> do_query($query,__LINE__,__FILE__);
list($newusername,$newnumber) =  $dbh -> fetch_array($sth);
$encnewusername = $newnumber;
$dbh -> finish_sth($sth);

$registered = addslashes($registered);
$newnumber = addslashes($encnewusername);
$newusername = addslashes($newusername);
$cachenow = time();

$ubbt_admin['modq'] = "";
$ubbt_admin = serialize($ubbt_admin);
$html = new html;
$html->ubbt_setcookie("ubbt_admin",$ubbt_admin);


// Generate any content island feeds for total members
rebuild_islands(0,array("new_users"));


$admin->redirect($ubbt_lang['APP_BODY_2'],"{$config['BASE_URL']}/admin/membermanage.php?returntab=$returntab",$ubbt_lang['F_LOC']);

?>
