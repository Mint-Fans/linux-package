<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/docatmanage.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$orders = get_input("order","post");
$titles = get_input("title","post");
$descs= get_input("description","post");

// Grab all current board settings
// Grab all categories
$query = "
	SELECT CATEGORY_TITLE,CATEGORY_ID,CATEGORY_DESCRIPTION,CATEGORY_SORT_ORDER
	FROM {$config['TABLE_PREFIX']}CATEGORIES
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while(list($ctitle,$centry,$cdesc,$cnumb) = $dbh->fetch_array($sth)) {

	$order = $orders[$centry];
	$title = $titles[$centry];
	$desc = $descs[$centry];
	if (($order != $cnumb) || ($title != $ctitle) || ($desc != $cdesc)) {

		$query = "
			SELECT CATEGORY_TITLE
			FROM {$config['TABLE_PREFIX']}CATEGORIES
			WHERE CATEGORY_ID = ?
		";
		$sti = $dbh->do_placeholder_query($query,array($centry),__LINE__,__FILE__);
		list ($oldtitle) = $dbh->fetch_array($sti);
		
		$query_vars = array($title,$desc,$order,$centry);
		$query = "
			UPDATE {$config['TABLE_PREFIX']}CATEGORIES
			SET CATEGORY_TITLE = ? ,
			CATEGORY_DESCRIPTION = ? ,
			CATEGORY_SORT_ORDER = ?
			WHERE CATEGORY_ID = ?
		";
		$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	}
}

admin_log("MANAGE_CATEGORIES","");


$admin->redirect($ubbt_lang['CATS_UPDATED'],"{$config['BASE_URL']}/admin/catmanage.php?returntab=0",$ubbt_lang['CAT_F_LOC']);

?>
