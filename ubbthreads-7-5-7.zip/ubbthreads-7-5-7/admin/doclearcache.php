<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$query = "
	UPDATE {$config['TABLE_PREFIX']}CACHE
	SET CACHE_VALUE = ''
	WHERE CACHE_FIELD not in ('max_online','max_online_timestamp')
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);

// Rebuild the content islands
rebuild_islands(1);

// Rebuild the rss feeds
generate_rss_feeds(1);

build_forum_cache();

// Rebuild any custom tags
build_custom_tag_cache();

$userob->clear_cached_perms();

admin_log("CLEAR_CACHE","");


$admin->redirect($ubbt_lang['CACHE_CLEARED'],"{$config['BASE_URL']}/admin/cache.php",$ubbt_lang['CACHE_F_LOC']);

?>