<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Get the input
$cat = get_input("cat","post");
$newcat = get_input("newcat","post");
$yesdelete = get_input("yesdelete","post");
$nodelete = get_input("nodelete","post");

if ($nodelete) {
	$admin->redirect($ubbt_lang['NO_CAT_DELETED'],"{$config['BASE_URL']}/admin/catmanage.php",$ubbt_lang['CAT_F_LOC']);
}
if ($yesdelete) {

	$query = "
		SELECT CATEGORY_TITLE
		FROM {$config['TABLE_PREFIX']}CATEGORIES
		WHERE CATEGORY_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($newcat),__LINE__,__FILE__);
	list($ctitle) = $dbh->fetch_array($sth);

	$query_vars = array($newcat,$cat);
	$query = "
		UPDATE {$config['TABLE_PREFIX']}FORUMS
		SET CATEGORY_ID = ?
		WHERE CATEGORY_ID = ?
	";
	$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

	$query = "
		SELECT CATEGORY_TITLE
		FROM {$config['TABLE_PREFIX']}CATEGORIES
		WHERE CATEGORY_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($cat),__LINE__,__FILE__);
	list($oldtitle) = $dbh->fetch_array($sth);

	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}CATEGORIES
		WHERE CATEGORY_ID = ?
	";
	$dbh->do_placeholder_query($query,array($cat),__LINE__,__FILE__);


	// Log this action
	admin_log("DELETE_CATEGORY", "$oldtitle");
	build_forum_cache();

	$admin->redirect($ubbt_lang['CAT_DELETED'],"{$config['BASE_URL']}/admin/catmanage.php",$ubbt_lang['CAT_F_LOC']);
}

?>
