<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// -------------
// Get the input
$returntab = get_input("returntab","post");
$isactive = get_input("isactive","post");
$Number = get_input("forum","post");
$Title = get_input("Title","post");
$Description = get_input("Description","post");
$Category = get_input("Category","post");
$ThreadAge = get_input("ThreadAge","post");
$header = get_input("header","post");
$style = get_input("style","post");
$CurrentCat = get_input("CurrentCat","post");
$avurl = get_input("avurl","post");
$subforum = get_input("subforum","post");
$oldparent = get_input("oldparent","post");
$headerfile = get_input("headerfile","post");
$footerfile = get_input("footerfile","post");
$island_insert = get_input("island_insert","post");
$feed_body = get_input("feed_body","post");
$feed_posts = get_input("feed_posts","post");
$feed_type = get_input("feed_type","post");
$feed_cache = get_input("feed_cache","post");
$feed_name = get_input("feed_name","post");
$rss = get_input("rss","post");
$what = get_input("what","post");
$forum_intro = get_input("forum_intro","post");
$intro_title = get_input("intro_title","post");
$intro_body = get_input("intro_body","post");
$stylesheet = get_input("stylesheet","post");
$is_teaser = get_input("is_teaser","post");
$gallery_total = get_input("gallery_total","post");
$posts_count = get_input("postscount","post") ? '1' : '0';
$shows_in_active_topics = get_input("showactivetopics", "post") ? '1' : '0';
$sort_field = get_input("SORT_FIELD", "post");
$sort_dir = get_input("SORT_DIR", "post");

$Description = escape_ampersand($Description);

// Set some defaults
if (!$rss) $rss = 0;
if (!$feed_body) $feed_body = 0;
if (!$feed_posts) $feed_posts = 10;
if (!$feed_cache) $feed_cache = 1;
if (!$feed_name) $feed_name = "RSS Feed for $Title";
if (!$is_gallery) $is_gallery = 0;
if (!$is_teaser) $is_teaser = 0;

// Grab just the imagefile of $avurl
if ($avurl) {
	$av_parts = explode("/",$avurl);
	$avurl = $av_parts[sizeof($av_parts)-1];
}

$feed_cache = $feed_cache * 60;

// Check to see if it has a current parent
$query = "
	select FORUM_PARENT,FORUM_IS_GALLERY
	from {$config['TABLE_PREFIX']}FORUMS
	where FORUM_ID = ?
";
$sth = $dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);
list($current_parent,$is_gallery) = $dbh->fetch_array($sth);

// First let's see if this is going to be a subforum
if (preg_match("/^forum/",$Category)) {
	list($boo,$Parent) = preg_split("#forum_#",$Category);
	$query = "
		select t1.CATEGORY_ID,t2.CATEGORY_TITLE
		from {$config['TABLE_PREFIX']}FORUMS as t1,
		{$config['TABLE_PREFIX']}CATEGORIES as t2
		where t1.FORUM_ID = ?
		and t1.CATEGORY_ID = t2.CATEGORY_ID
	";
	$sth = $dbh->do_placeholder_query($query,array($Parent),__LINE__,__FILE__);
	list($Category) = $dbh->fetch_array($sth);
} else {
	list($boo,$Category) = preg_split("#category_#",$Category);
	$Parent = "0";
	$query = "
		SELECT CATEGORY_TITLE
		FROM   {$config['TABLE_PREFIX']}CATEGORIES
		WHERE  CATEGORY_ID = ?
	";
	$sth = $dbh -> do_placeholder_query($query,array($Category),__LINE__,__FILE__);
	list ($CatName) = $dbh -> fetch_array($sth);
}


// -------------------------------------------
// Grab the category name for the new category

$Catnum = $Category;

// Update the special header if necessary
$oldheader = "";
$fd = @file("{$config['FULL_PATH']}/includes/header_$Number.php");
if ($fd) {
	while (list($linenum,$line) = each($fd)) {
		$oldheader .= "$line";
	}
}
@fclose($fd);
if ($headerfile != $oldheader) {
	$check = lock_and_write("{$config['FULL_PATH']}/includes/header_$Number.php",$headerfile);
	if ($check == "no_write") {
		$admin->error($ubbt_lang['NO_WRITE_FHEADER']);
	} // end if
} // end if

// Update the special footer if necessary
$oldfooter = "";
$fd = @file("{$config['FULL_PATH']}/includes/footer_$Number.php");
if ($fd) {
	while (list($linenum,$line) = each($fd)) {
		$oldfooter .= "$line";
	}
}
@fclose($fd);
if ($footerfile != $oldfooter) {
	$check = lock_and_write("{$config['FULL_PATH']}/includes/footer_$Number.php",$footerfile);
	if ($check == "no_write") {
		$admin->error($ubbt_lang['NO_WRITE_FFOOTER']);
	}
}

// Update the forum intro if necessary
$oldintro = "";
$introfile = @file("{$config['FULL_PATH']}/includes/intro_$Number.php");
if ($introfile) {
	while (list($linenum,$line) = each($introfile)) {
		$oldintro .= "$line";
	}
}

if ($intro_body != $oldintro) {
	$check = lock_and_write("{$config['FULL_PATH']}/includes/intro_$Number.php",$intro_body);
	if ($check == "no_write") {
		$admin->error(sprintf($ubbt_lang['NO_WRITE_FORUM_INTRO'],$Number));
	} // end if
} // end if

if (!$header) { $header = '0'; }
if (!$island_insert) $island_insert = 0;
if (!$forum_intro) $forum_intro = 0;
if (!$style) $style = 0;

if (!$gallery_total) $gallery_total = 0;
if (!$isactive) $isactive = 0;

if ($is_gallery && !$gallery_total) {
	$gallery_total = 1;
}

$Title = htmlspecialchars($Title);

$query_vars = array($Title,$Description,$ThreadAge,$header,$style,$avurl,$isactive,$Parent,$island_insert,$rss,$feed_name,$forum_intro,$intro_title,$stylesheet,$is_teaser,$gallery_total,$posts_count,$shows_in_active_topics,$sort_field,$sort_dir);
// --------------------------
// Make sure we have a Catnum
$extra = "";
if ($Catnum) {
	array_push($query_vars,$Catnum);
	$extra = ",CATEGORY_ID = ? ";
}

array_push($query_vars,$Number);

$query = "
	UPDATE {$config['TABLE_PREFIX']}FORUMS
	SET FORUM_TITLE = ? , 
	FORUM_DESCRIPTION = ? , 
	FORUM_DEFAULT_TOPIC_AGE = ? ,
	FORUM_CUSTOM_HEADER = ? , 
	FORUM_STYLE = ? , 
	FORUM_IMAGE = ? , 
	FORUM_IS_ACTIVE = ? ,
	FORUM_PARENT = ? ,
	FORUM_ISLAND_INSERT = ? ,
	FORUM_IS_RSS = ? ,
	FORUM_RSS_TITLE = ? ,
	FORUM_SHOW_INTRO = ? ,
	FORUM_INTRO_TITLE = ? ,
	FORUM_STYLE = ? ,
	FORUM_IS_TEASER = ? ,
	FORUM_IS_GALLERY = ?,
	FORUM_POSTS_COUNT = ?,
	FORUM_ACTIVE_POSTS = ?,
	FORUM_SORT_FIELD = ?,
	FORUM_SORT_DIR = ?
	$extra
	WHERE FORUM_ID = ?
";
$dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

// Check if the old parent still has kids
$query = "
	select count(*)
	from {$config['TABLE_PREFIX']}FORUMS
	where FORUM_PARENT = ?
";
$sth = $dbh->do_placeholder_query($query,array($current_parent),__LINE__,__FILE__);
list($parent_check) = $dbh->fetch_array($sth);
if ($parent_check > 0) {
	$parent_check = 1;
} else {
	$parent_check = 0;
}

// check if we need to do an insert or an update into rss
$query = "
	select count(*)
	from {$config['TABLE_PREFIX']}RSS_FEEDS
	where FEED_FORUM = ?
";
$sth = $dbh->do_placeholder_query($query,array($Number),__LINE__,__FILE__);
list($count) = $dbh->fetch_array($sth);
if (!$count) {
	// Do an insert
	$query_vars = array($rss,$Number,$feed_name,0,$feed_type,$feed_body,$feed_posts,$feed_cache);
	$query = "
		insert into {$config['TABLE_PREFIX']}RSS_FEEDS
		(FEED_IS_ACTIVE,FEED_FORUM,FEED_NAME,FEED_LAST_BUILD,FEED_TYPE,FEED_INCLUDE_BODY,FEED_ITEMS,FEED_CACHE_TIME)
		values
		( ? , ? , ? , ? , ? , ? , ? , ? )
	";
	$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
	
} else {
	// Do an update
	$query_vars = array($rss,$feed_name,0,$feed_type,$feed_body,$feed_posts,$feed_cache,$Number);
	$query = "
		update {$config['TABLE_PREFIX']}RSS_FEEDS
		set	FEED_IS_ACTIVE = ? ,
				FEED_NAME = ? ,
				FEED_LAST_BUILD = ? ,
				FEED_TYPE = ? ,
				FEED_INCLUDE_BODY = ? ,
				FEED_ITEMS = ? ,
				FEED_CACHE_TIME = ?
		where FEED_FORUM = ?
	";
	$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
} // end if

(file_exists("{$config['FULL_PATH']}/cache/forum_cache.php")) ? include("{$config['FULL_PATH']}/cache/forum_cache.php") : $tree = array() ;	

if (isset($tree['tree'])) {
	foreach ($tree['tree'] as $k => $v) {
		if (in_array($Number,$v)) {
			$query = "
				update {$config['TABLE_PREFIX']}FORUMS
				set CATEGORY_ID = ?
				where FORUM_ID = ?
			";
			$dbh->do_placeholder_query($query,array($Catnum,$k),__LINE__,__FILE__);
		}
	}
}
	


// Gotta do this now...
$dbh->do_query("truncate table {$config['TABLE_PREFIX']}CACHED_PERMISSIONS");

build_forum_cache();

// ---------------
// Log this action
admin_log("EDIT_BOARD", "<a href='{$config['BASE_URL']}/admin/viewboard.php?forum=$Number' target='_blank'>$Title</a>");

if ($what == "rss") {
	$admin->redirect($ubbt_lang['FORUM_UPDATED'],"{$config['BASE_URL']}/admin/rss.php?returntab=0",$ubbt_lang['RSS_F_LOC']);

} else {
	$admin->redirect($ubbt_lang['FORUM_UPDATED'],"{$config['BASE_URL']}/admin/viewboard.php?forum=$Number&returntab=$returntab",$ubbt_lang['FORUM_F_LOC']);
} // end if
?>
