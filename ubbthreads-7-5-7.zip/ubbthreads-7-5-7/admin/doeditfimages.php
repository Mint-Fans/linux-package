<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/doeditfimages.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

$removedimages = "";

// -------------
// Get the input
$returntab = get_input("returntab","post");

// -----------------
// Get the user info
$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// ------------------
// Remove all checked
$dir = opendir("{$config['FULL_PATH']}/images/{$style_array['forumimages']}");
$i=0;
while( ($file = readdir($dir)) != false) {
	if ( ($file == ".") || ($file == "..") || ($file == "index.html") ) {
		continue;
	}
	list($name,$ext) = preg_split("#\.#",$file);
	$upload="file-$ext-$name";
	if (isset($_POST[$name])) {
		$filename = "$name.{$_POST[$name]}";
		$test = @unlink("{$config['FULL_PATH']}/images/{$style_array['forumimages']}/$filename");
		if (!$test) {
			$admin -> error("{$ubbt_lang['NOREMOVE']}");
		}
		$removedimages .= "$filename-";
		$query = "
			UPDATE {$config['TABLE_PREFIX']}FORUMS
			SET FORUM_IMAGE=''
			WHERE FORUM_IMAGE = ?
		";
		$dbh->do_placeholder_query($query,array("{$config['BASE_URL']}/{$style_array['forumimages']}/$filename"),__LINE__,__FILE__);
	}
	elseif (!empty($_FILES[$upload]['name'])) {
		$fileupload = $_FILES[$upload]['name'];
		$file_temp = $_FILES[$upload]['tmp_name'];
		$check = @move_uploaded_file($file_temp,"{$config['FULL_PATH']}/images/{$style_array['forumimages']}/$file");
		@chmod("{$config['FULL_PATH']}/images/{$style_array['forumimages']}/$file",0666);
		if (!$check) {
			$admin->error("{$config['FULL_PATH']}/images/{$style_array['forumimages']}/$file {$ubbt_lang['NO_OVERW']}");
		}
	}
}

// ---------------
// Log this action
admin_log("REMOVE_FORUM_IMAGE", $removedimages);

$admin->redirect($ubbt_lang['REMOVED'],"{$config['BASE_URL']}/admin/fimages_display.php?returntab=3",$ubbt_lang['F_LOC']);

?>
