<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();


$template = get_input("template","post");
$body = get_input("body","post");

// ------------------------
// Predefine some variables
$newbody = "";

// ------------------
// Write out the file
$body = preg_replace("/\r/","",$body);
$bodyparts = preg_split("#\n#",$body);

$size = sizeof($bodyparts);
for ($i=0;$i<$size;$i++) {
	$line = $bodyparts[$i];

	$line = str_replace("&amp;amp;","&amp;",$line);

	// ------------------------------------------------------------
	// Make sure we don't have any spaces after the closing php tag
	if (($i == $size - 1) && !$line) {
		continue;
	} else {
		$line .="\r\n";
		$newbody .= $line;
	}
}

$check = lock_and_write("{$config['FULL_PATH']}/templates/default/$template",$newbody);
if ($check == "no_write") {
	$admin->error("{$config['FULL_PATH']}/templates/default/$template " . $ubbt_lang['NO_WRITE_TEMPLATE']);
}

// ---------------
// Log this action
admin_log("EDIT_TEMPLATE", $template);

$admin->redirect($ubbt_lang['TEMPLATE_UPDATED'],"{$config['BASE_URL']}/admin/edittemplate.php?template=$template",$ubbt_lang['TEMPLATE_F_LOC']);

?>
