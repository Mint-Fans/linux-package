<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/domergeuser.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Get the input
$uid = get_input("uid","post","int");
$merge_id = get_input("merge_id","post","int");
$part = get_input("part","post","int");

$query = "
	select t1.USER_LOGIN_NAME,t1.USER_DISPLAY_NAME,t2.USER_REAL_EMAIL,t2.USER_TOTAL_POSTS
	from {$config['TABLE_PREFIX']}USERS as t1,
	{$config['TABLE_PREFIX']}USER_PROFILE as t2
	where t1.USER_ID = ?
	and t1.USER_ID = t2.USER_ID
";
$sth = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
list($login_name,$display_name,$email,$posts) = $dbh->fetch_array($sth);

$query = "
	select t1.USER_ID,t1.USER_LOGIN_NAME,t1.USER_DISPLAY_NAME,t2.USER_REAL_EMAIL,t2.USER_TOTAL_POSTS
	from {$config['TABLE_PREFIX']}USERS as t1,
	{$config['TABLE_PREFIX']}USER_PROFILE as t2
	where t1.USER_ID = ?
	and t1.USER_ID = t2.USER_ID
";
$sth = $dbh->do_placeholder_query($query,array($merge_id),__LINE__,__FILE__);
list($check,$t_login_name,$t_display_name,$t_email,$t_posts) = $dbh->fetch_array($sth);

if (!$check) {
	$admin->error(sprintf($ubbt_lang['NO_ID'],$merge_id));
	exit;
}

$tabs = array(
	"{$ubbt_lang['MERGE_USER']}: $display_name (#$uid)" => ""
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['MEM_MAN']);
$admin->setParentTitle($ubbt_lang['MEM_MAN'],"membermanage.php");
$admin->setPageTitle($ubbt_lang['MERGE_USER']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/domergeuser.tmpl");

$admin->sendFooter();
?>
