<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

// Who can access this page? Admins only or Admins and Moderators
define('ADMINISTRATORS',1);
define('MODERATORS',0);
$admin->doAuth();

// Get the input
$ismod = get_input("ismod","post");
$lockposts = get_input("lockposts","post");
$moveposts = get_input("moveposts","post");
$deleteposts = get_input("deleteposts","post");
$stickposts = get_input("stickposts","post");
$approveposts = get_input("approveposts","post");
$editposts = get_input("editposts","post");
$editusers = get_input("editusers","post");

// Grab all moderators
$query = "
	SELECT USER_ID
	FROM {$config['TABLE_PREFIX']}USERS
	WHERE USER_MEMBERSHIP_LEVEL='Moderator'
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while(list($number) = $dbh->fetch_array($sth)) {
	if (!isset($ismod[$number])) {
		// Remove mod permissions
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}MODERATORS
			WHERE USER_ID = ?
		";
		$dbh->do_placeholder_query($query,array($number),__LINE__,__FILE__);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}MODERATOR_PERMISSIONS
			WHERE USER_ID = ?
		";
		$dbh->do_placeholder_query($query,array($number),__LINE__,__FILE__);
		$query = "
			UPDATE {$config['TABLE_PREFIX']}USERS
			SET USER_MEMBERSHIP_LEVEL='User'
			WHERE USER_ID = ?
		";
		$dbh->do_placeholder_query($query,array($number),__LINE__,__FILE__);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}USER_GROUPS
			where GROUP_ID = '2'
			and USER_ID = ?
		";
		$dbh->do_placeholder_query($query,array($number),__LINE__,__FILE__);
		continue;
	}
	if (isset($lockposts[$number])) {
		$u_lockposts = 1;
	}
	else {
		$u_lockposts = 0;
	}
	if (isset($moveposts[$number])) {
		$u_moveposts = 1;
	}
	else {
		$u_moveposts = 0;
	}
	if (isset($deleteposts[$number])) {
		$u_deleteposts = 1;
	}
	else {
		$u_deleteposts = 0;
	}
	if (isset($stickposts[$number])) {
		$u_stickposts = 1;
	}
	else {
		$u_stickposts = 0;
	}
	if (isset($approveposts[$number])) {
		$u_approveposts = 1;
	}
	else {
		$u_approveposts = 0;
	}
	if (isset($editposts[$number])) {
		$u_editposts = 1;
	}
	else {
		$u_editposts = 0;
	}
	if (isset($editusers[$number])) {
		$u_editusers = 1;
	}
	else {
		$u_editusers = 0;
	}
	// UPDATE Permissions into permissions table
	$query = "
		REPLACE INTO {$config['TABLE_PREFIX']}MODERATOR_PERMISSIONS
		(USER_ID,MODERATOR_CAN_EDIT_USERS,MODERATOR_CAN_APPROVE_POSTS,MODERATOR_CAN_EDIT_POSTS,MODERATOR_CAN_LOCK_POSTS,MODERATOR_CAN_MOVE_POSTS,MODERATOR_CAN_DELETE_POSTS,MODERATOR_CAN_STICK_POSTS)
		VALUES
		( ? ,'$u_editusers','$u_approveposts','$u_editposts','$u_lockposts','$u_moveposts','$u_deleteposts','$u_stickposts')
	";
	$dbh->do_placeholder_query($query,array($number),__LINE__,__FILE__);

}

// ---------------
// Log this action
admin_log("MODPERMISSIONS", '');

$admin->redirect($ubbt_lang['MOD_PERMS_UPDATED'],"{$config['BASE_URL']}/admin/modmanage.php?returntab=1",$ubbt_lang['F_LOC_MOD_PERMS']);


?>
