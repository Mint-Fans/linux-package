<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/domovethreads.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = 0;
$handle = get_input("handle","get");
$target = get_input("target","get");
$total = get_input("total","get");
$current = get_input("current","get");
$excluded = get_input("excluded","get");

// move 20 topics per page
// Defining this in here instead of making an option since
// too many might result in the max_execution time being exceeded
// and that would be bad.
$movecount = 20;

if (!$current) {
	$current = 0;
}
if (!$excluded) {
	$excluded = 0;
}

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

if ($current < $total) {

	// Retrieve query and removed results from database
	$query = "
		SELECT ADMIN_SEARCH_QUERY,ADMIN_SEARCH_REMOVED_RESULTS,ADMIN_SEARCH_RESULTS
		FROM {$config['TABLE_PREFIX']}ADMIN_SEARCHES
		WHERE ADMIN_SEARCH_TYPE='topicmove'
		AND USER_ID='{$user['USER_ID']}'
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	list ($savedquery,$removed,$results) = $dbh->fetch_array($sth);

	if ($removed) {
		$removed = unserialize($removed);
	}
	else {
		$removed = array();
	}

	// Execute the saved query if this is our first pass
	if (!$current) {
		$savedquery = preg_replace("/(\n|\r)/","",$savedquery);
		$savedquery = preg_replace("/SELECT(.*?)FROM/","SELECT t1.TOPIC_ID FROM",$savedquery);

		$savedquery .= " ORDER BY TOPIC_ID";
		$sth = $dbh->do_query($savedquery,__LINE__,__FILE__);
		$results = array();
		while(list($bnum) = $dbh->fetch_array($sth)) {
			$results[] = $bnum;
		}
		$results_q = addslashes(serialize($results));
		$query = "
			UPDATE {$config['TABLE_PREFIX']}ADMIN_SEARCHES
			SET ADMIN_SEARCH_RESULTS = '$results_q'
			WHERE ADMIN_SEARCH_TYPE='topicmove'
			AND USER_ID='{$user['USER_ID']}'
		";
		$dbh->do_query($query,__LINE__,__FILE__);
		$inlist = "";
		for($i=0;$i<$movecount;$i++) {
			if (isset($results[$i])) {
				$inlist .= "'$results[$i]',";
			}
		}
		$inlist = preg_replace("/,$/","",$inlist);
		$query = "
			SELECT * FROM {$config['TABLE_PREFIX']}TOPICS
			WHERE TOPIC_ID IN ($inlist)
		";
		$sth = $dbh->do_query($query,__LINE__,__FILE__);
	}
	else {
		$inlist = "";
		$results= unserialize($results);
		for ($i=$current;$i<($current+$movecount);$i++) {
			if (isset($results[$i])) {
				$inlist .= "'$results[$i]',";
			}
		}
		$inlist = preg_replace("/,$/","",$inlist);
		$query = "
			SELECT * FROM {$config['TABLE_PREFIX']}TOPICS
			WHERE TOPIC_ID IN ($inlist)
		";
		$sth = $dbh->do_query($query,__LINE__,__FILE__);
	}
	$sources = array();
	$postnum = 0;

	while($postrow = $dbh->fetch_array($sth)) {

		$current++;
		$postnum++;

		if (isset($removed[$postrow['TOPIC_ID']])) {
			$excluded++;
			if ($postnum == $movecount) {
				$mess = sprintf($ubbt_lang['COUNTER'],$current,$total,$excluded);
				$admin->redirect($mess,"{$config['BASE_URL']}/admin/domovethreads.php?handle=$handle&amp;target=$target&amp;total=$total&amp;current=$current&amp;excluded=$excluded",$ubbt_lang['F_LOC'],2);
				exit;
			}
			continue;
		}

		$oldboard_q = addslashes($postrow['FORUM_ID']);
		$sources[] = $postrow['FORUM_ID'];

		// ---------------------------------------------------------------
		// Make sure users still have access to topic in new location if
		// it is a favorite topic
		if ($handle != "none") {
			$query = "
				DELETE FROM {$config['TABLE_PREFIX']}WATCH_LISTS
				WHERE  WATCH_ID = '{$postrow['TOPIC_ID']}'
				AND WATCH_TYPE = 't'
			";
			$dbh -> do_query($query,__LINE__,__FILE__);
		}

		// Insert the topic and all of it's replies into the new location
		if (($handle != "delete") && ($handle != "mark")){
			$postrow['FORUM_ID'] = $target;
			$insert = "";
			$fields = "";
			$size = sizeof($postrow);
			for ($i=0;$i<sizeof($postrow);$i++) {
				unset($postrow[$i]);
			}

			while(list($key,$value) = each($postrow)) {
				if ($key == "TOPIC_ID") {
					continue;
				}
				$insert .= "'" . addslashes($value) . "',";
				$fields .= "$key,";
			}
			$insert = preg_replace("/,$/","",$insert);
			$fields = preg_replace("/,$/","",$fields);
			$query = "
				INSERT INTO {$config['TABLE_PREFIX']}TOPICS
				($fields)
				VALUES
				($insert)
			";
			$dbh->do_query($query,__LINE__,__FILE__);

			// Get the new topic id
			$query = "
				SELECT last_insert_id()
			";
			$stx = $dbh->do_query($query,__LINE__,__FILE__);
			list ($topicid) = $dbh->fetch_array($stx);

			// Grab the replies
			$query = "
				SELECT * FROM {$config['TABLE_PREFIX']}POSTS
				WHERE TOPIC_ID = '{$postrow['TOPIC_ID']}'
				ORDER BY POST_ID
			";
			$stx=$dbh->do_query($query,__LINE__,__FILE__);
			$first= 0;
			while($replyrow = $dbh->fetch_array($stx)) {
				$replyrow['TOPIC_ID'] = $topicid;
				if (isset($parents[$replyrow['POST_PARENT_ID']])) {
					$replyrow['POST_PARENT_ID'] = $parents[$replyrow['POST_PARENT_ID']];
				}
				$insert = "";
				$fields = "";
				$size = sizeof($replyrow);
				for ($i=0;$i<sizeof($replyrow);$i++) {
					unset($replyrow[$i]);
				}
				while(list($key,$value) = each($replyrow)) {
					if ($key == "POST_ID") {
						continue;
					}
					$insert .= "'" . addslashes($value) . "',";
					$fields .= "$key,";
				}
				$insert = preg_replace("/,$/","",$insert);
				$fields = preg_replace("/,$/","",$fields);
				$query = "
					INSERT INTO {$config['TABLE_PREFIX']}POSTS
					($fields)
					VALUES
					($insert)
				";
				$dbh->do_query($query,__LINE__,__FILE__);

				// Grab this new number to update parent ids
				$query = "
					SELECT last_insert_id()
				";
				$sty = $dbh->do_query($query,__LINE__,__FILE__);
				list($parentid) = $dbh->fetch_array($sty);
				$parents[$replyrow['POST_ID']] = $parentid;
				if (!$first) $first = $parentid;
			}
			$query = "
				update {$config['TABLE_PREFIX']}TOPICS
				set POST_ID='$first'
				where TOPIC_ID='$topicid'
			";
			$dbh->do_query($query,__LINE__,__FILE__);
		}

		if ($handle == "none") {
			// Copy the topics, do nothing with original
		}
		elseif ($handle == "close") {
			// Copy the topics, close the original
			$query = "
				UPDATE {$config['TABLE_PREFIX']}TOPICS
				SET TOPIC_STATUS = 'C'
				WHERE TOPIC_ID='{$postrow['TOPIC_ID']}'
			";
			$dbh->do_query($query,__LINE__,__FILE__);
		}
		elseif ($handle == "mark") {

			// Move the topics and delete original
			$query = "
				UPDATE {$config['TABLE_PREFIX']}TOPICS
				SET FORUM_ID='$target'
				WHERE TOPIC_ID='{$postrow['TOPIC_ID']}'
			";
			$dbh->do_query($query,__LINE__,__FILE__);
			

			// Leave a pointer
			$newloc = $target . "-ML-" . $postrow['POST_ID'] ."-ML-";
			$c_body = addslashes($newloc);
			$c_subject = addslashes($postrow['POST_SUBJECT']);
			$c_posted  = addslashes($postrow['POST_POSTED_TIME']);
			$c_lastpost = addslashes($postrow['TOPIC_LAST_REPLY_TIME']);
			$c_icon = addslashes($postrow['POST_ICON']);
			$c_posterid = addslashes($postrow['USER_ID']);
			$c_ip = addslashes($postrow['POST_POSTER_IP']);

			$query = "
				insert into {$config['TABLE_PREFIX']}TOPICS
				(FORUM_ID,TOPIC_SUBJECT,TOPIC_CREATED_TIME,TOPIC_LAST_REPLY_TIME,TOPIC_ICON,USER_ID,TOPIC_STATUS)
				values
				('$oldboard_q','$c_subject','$c_posted,$c_lastpost,$c_icon,$c_posterid,'M')
			";
			$dbh->do_query($query);
			
			$query = "
				SELECT last_insert_id()
			";
			$stx = $dbh -> do_query($query,__LINE__,__FILE__);
			list($topic_id) = $dbh -> fetch_array($stx);
				
			$query = "
				INSERT INTO {$config['TABLE_PREFIX']}POSTS
				(TOPIC_ID,POST_SUBJECT,POST_BODY,POST_DEFAULT_BODY,POST_POSTED_TIME,POST_ICON,USER_ID,POST_IS_TOPIC,POST_POSTER_IP)
				VALUES
				('$topic_id','$c_subject','$c_body','','$c_posted','$c_icon','$c_posterid','1','$c_ip')
			";
			$dbh -> do_query($query,__LINE__,__FILE__);

			$query = "
				SELECT last_insert_id()
			";
			$stx = $dbh -> do_query($query,__LINE__,__FILE__);
			list($post_id) = $dbh -> fetch_array($stx);

			$query = "
				UPDATE {$config['TABLE_PREFIX']}TOPICS
				SET POST_ID = '$post_id'
				WHERE TOPIC_ID = '$topic_id'
			";
			$dbh -> do_query($query,__LINE__,__FILE__);
		}
		elseif ($handle == "delete") {

			// Move the topics and delete original
			$query = "
				UPDATE {$config['TABLE_PREFIX']}TOPICS
				SET FORUM_ID='$target'
				WHERE TOPIC_ID='{$postrow['TOPIC_ID']}'
			";
			$dbh->do_query($query,__LINE__,__FILE__);

		}

		if ($postnum == $movecount) {
			$mess = sprintf($ubbt_lang['COUNTER'],$current,$total,$excluded);
			$admin->redirect($mess,"{$config['BASE_URL']}/admin/domovethreads.php?handle=$handle&amp;target=$target&amp;total=$total&amp;current=$current&amp;excluded=$excluded",$ubbt_lang['F_LOC'],2);
			exit;
		}

	}

}


admin_log("MASSMOVETHREADS", "");

// Find the new last post information on the target
$query = "
	SELECT TOPIC_LAST_POST_ID,TOPIC_LAST_REPLY_TIME,TOPIC_ID,TOPIC_LAST_POSTER_ID,TOPIC_LAST_POSTER_NAME
	FROM {$config['TABLE_PREFIX']}TOPICS
	WHERE FORUM_ID='$target'
	ORDER BY TOPIC_LAST_REPLY_TIME DESC
	LIMIT 1
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);

$query = "
	select t1.TOPIC_ID,count(t2.POST_ID)
	from {$config['TABLE_PREFIX']}TOPICS as t1,
	{$config['TABLE_PREFIX']}POSTS as t2
	where t1.TOPIC_ID = t2.TOPIC_ID
	and   t1.FORUM_ID = '$target'
	and   t2.POST_IS_APPROVED = '1'
	group by t1.TOPIC_ID
";
$totalposts = 0;
$totaltopics = 0;
$stx = $dbh->do_query($query,__LINE__,__FILE__);
while(list($t,$c) = $dbh->fetch_array($stx)) {
	$totaltopics++;
	$totalposts = $totalposts + $c;
}

list($b_post_id,$blast,$b_topic_id,$blastposterid,$blastname,$blastsubject,$blasticon) = $dbh->fetch_array($sth);
$blastname = addslashes($blastname);

$query = "
	select POST_SUBJECT,POST_ICON
	from {$config['TABLE_PREFIX']}POSTS
	where POST_ID = '$b_post_id'
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
list($blastsubject,$blasticon) = $dbh->fetch_array($sth);

$blastsubject = addslashes($blastsubject);
$blasticon = addslashes($blasticon);
$query = "
	UPDATE {$config['TABLE_PREFIX']}FORUMS
	SET FORUM_POSTS = $totalposts,
	FORUM_TOPICS = $totaltopics,
	FORUM_LAST_POST_ID = '$b_post_id',
	FORUM_LAST_TOPIC_ID = '$b_topic_id',
	FORUM_LAST_POSTER_ID = '$blastposterid',
	FORUM_LAST_POST_TIME = '$blast',
	FORUM_LAST_POSTER_NAME = '$blastname',
	FORUM_LAST_POST_SUBJECT = '$blastsubject',
	FORUM_LAST_POST_ICON = '$blasticon'
	WHERE FORUM_ID='$target'
";
$dbh->do_query($query,__LINE__,__FILE__);

// Find the new last post informaton on the sources if necessary
for($i=0;$i<sizeof($sources);$i++) {
	$Keyword_q = addslashes($sources[$i]);
	$query = "
		SELECT TOPIC_LAST_POST_ID,TOPIC_LAST_REPLY_TIME,TOPIC_ID,TOPIC_LAST_POSTER_ID,TOPIC_LAST_POSTER_NAME
		FROM {$config['TABLE_PREFIX']}TOPICS
		WHERE FORUM_ID='$Keyword_q'
		ORDER BY TOPIC_LAST_REPLY_TIME DESC
		LIMIT 1
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	list($bnum,$blast,$blastnum,$blastposterid,$blastname) = $dbh->fetch_array($sth);

	$query = "
	select t1.TOPIC_ID,count(t2.POST_ID)
	from {$config['TABLE_PREFIX']}TOPICS as t1,
	{$config['TABLE_PREFIX']}POSTS as t2
	where t1.TOPIC_ID = t2.TOPIC_ID
	and   t1.FORUM_ID = '$Keyword_q'
	and   t2.POST_IS_APPROVED = '1'
	group by t1.TOPIC_ID
	";
	$stx = $dbh->do_query($query,__LINE__,__FILE__);
	$totalposts = 0;
	$totaltopics = 0;
	while(list($t,$c) = $dbh->fetch_array($stx)) {
		$totaltopics++;
		$totalposts = $totalposts + $c;
	}
	
	$query = "
		select POST_SUBJECT,POST_ICON
		from {$config['TABLE_PREFIX']}POSTS
		where POST_ID = '$bnum'
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	list($blastsubject,$blasticon) = $dbh->fetch_array($sth);

	$blastname = addslashes($blastname);
	$blastsubject = addslashes($blastsubject);
	$blasticon = addslashes($blasticon);
	
	$query = "
		UPDATE {$config['TABLE_PREFIX']}FORUMS
		SET FORUM_POSTS = $totalposts,
		FORUM_TOPICS = $totaltopics,
		FORUM_LAST_POST_ID = '$bnum',
		FORUM_LAST_TOPIC_ID = '$blastnum',
		FORUM_LAST_POSTER_ID = '$blastposterid',
		FORUM_LAST_POST_TIME = '$blast',
		FORUM_LAST_POSTER_NAME = '$blastname',
		FORUM_LAST_POST_SUBJECT = '$blastsubject',
		FORUM_LAST_POST_ICON = '$blasticon'
		WHERE FORUM_ID='$Keyword_q'
	";
	$dbh->do_query($query,__LINE__,__FILE__);
}

$admin->redirect($ubbt_lang['MOVE_DONE'],"{$config['BASE_URL']}/admin/movethreads.php",$ubbt_lang['F_LOC_MAIN']);

?>
