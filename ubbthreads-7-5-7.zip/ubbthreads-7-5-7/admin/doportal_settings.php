<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","post");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$ENABLE_MAIN_PORTAL = get_input("ENABLE_MAIN_PORTAL","post");
$PORTAL_NEWS_FORUMS = get_input("PORTAL_NEWS_FORUMS","post");
$NEWS_ITEMS = get_input("NEWS_ITEMS","post");
$TOP_POSTERS = get_input("TOP_POSTERS","post");
$PUBLIC_CALENDAR = get_input("PUBLIC_CALENDAR","post");
$TOTAL_ONLINE = get_input("TOTAL_ONLINE","post");
$PORTAL_BDAYS = get_input("PORTAL_BDAYS","post");
$EXCLUDE_POPULAR = get_input("EXCLUDE_POPULAR","post");

$news = "";
foreach($PORTAL_NEWS_FORUMS as $k => $v) {
	if ($v == "category") {
		continue;
	} else {
		$news .= "$v,";
	}
}

$exclude = "";
foreach($EXCLUDE_POPULAR as $k => $v) {
	if ($v == "category") {
		continue;
	} else {
		$exclude .= "$v,";
	}
}

if ($ENABLE_MAIN_PORTAL && !$news) {
	$admin->error($ubbt_lang['NO_NEWS_FORUM']);
} // end if

$news = preg_replace("/,$/","",$news);
$exclude = preg_replace("/,$/","",$exclude);


$_POST['PORTAL_NEWS_FORUMS'] = $news;
$_POST['EXCLUDE_POPULAR'] = $exclude;

// What config vars are we updating?
$newconfig = array("ENABLE_MAIN_PORTAL","PORTAL_NEWS_FORUMS","NEWS_ITEMS","TOP_POSTERS","PUBLIC_CALENDAR","DISABLE_LEFT","DISABLE_RIGHT","RIGHT_COLUMN_PORTAL","LEFT_COLUMN_PORTAL","TOTAL_ONLINE","PORTAL_BDAYS","FEATURED_MEMBER","POPULAR_TOPICS","EXCLUDE_POPULAR");

foreach($_POST['cache'] as $name => $time) {
	$time = $time * 60;
	$query = "
		update {$config['TABLE_PREFIX']}PORTAL_BOXES
		set PORTAL_CACHE = ?
		where PORTAL_NAME = ?
	";
	$dbh->do_placeholder_query($query,array($time,$name),__LINE__,__FILE__);
}

// Update the config file
include("doeditconfig.php");

admin_log("PORTAL_SETTINGS","$log_diffs");

$admin->redirect($ubbt_lang['PORTAL_SET_UPDATED'],"{$config['BASE_URL']}/admin/portal_settings.php?returntab=$returntab",$ubbt_lang['PORTAL_SET_F_LOC']);

?>
