<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/external_island.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
error_reporting(7);

// -------------
// Get the input
$returntab = get_input("returntab","get");
$island = get_input("island","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("");

$admin = new Admin;

$admin->doAuth();

$tabs = array(
	"{$ubbt_lang['EXTERNAL']}" => "",
);

$string = <<<EOF
<?php
if (!defined('UBB_MAIN_PROGRAM')) define('UBB_MAIN_PROGRAM',1);
\$style_side="";\$tbopen="";\$tbclose="";
echo "<table width=\"100%\">";
include("{$config['FULL_PATH']}/languages/{$config['LANGUAGE']}/portal_islands.php");
include("{$config['FULL_PATH']}/languages/{$config['LANGUAGE']}/generic.php");
include("{$config['FULL_PATH']}/cache/$island.php");
echo "</table>";
?>
EOF;

$string = highlight_string($string,1);

ob_start();
include("{$config['FULL_PATH']}/cache/$island.php");
$html_string = ob_get_contents();
ob_end_clean();

$html_string = nl2br(htmlspecialchars($html_string));



$admin->setCurrentMenu($ubbt_lang['LAYOUT']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['EXTERNAL']);
$admin->setParentTitle($ubbt_lang['LAYOUT'],"layout.php");
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
include("../templates/default/admin/external_island.tmpl");

//$admin->createBottomTabs($bottomtabs,0);

$admin->sendFooter();

?>
