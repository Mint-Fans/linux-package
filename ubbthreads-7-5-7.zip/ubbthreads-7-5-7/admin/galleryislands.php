<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/postislands.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
error_reporting(7);

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("");

$admin = new Admin;

$admin->doAuth();

$query = "
	select FORUM_ID,FORUM_TITLE
	from {$config['TABLE_PREFIX']}FORUMS
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$forum_titles['allforums'] = $ubbt_lang['ALL_FORUMS'];
while(list($id,$title) = $dbh->fetch_array($sth)) {
	$forum_titles[$id] = $title;
} // end while

$portals = array();
// Grab any post islands from the db, these have a PORTAL_CUSTOM value of 2
$query = "
	select PORTAL_ID,PORTAL_NAME,PORTAL_FORUMS,PORTAL_POST_TYPE,PORTAL_CACHE
	from {$config['TABLE_PREFIX']}PORTAL_BOXES
	where PORTAL_CUSTOM = '3'
	order by PORTAL_ID asc
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while(list($portal_id,$portal_name,$portal_forums,$portal_post_type,$portal_cache) = $dbh->fetch_array($sth)) {
	if (!$portal_name) {$portal_name = $ubbt_lang['UNDEFINED']; } // end if
	if (!$portal_cache) {
		$portal_cache = 5;
	} else {
		$portal_cache = $portal_cache / 60;
	}// end if
	if (!$portal_post_type) $portal_post_type = $ubbt_lang['UNDEFINED']; // end if
	if ($portal_forums && is_array(unserialize($portal_forums))) {
		$portal_forums = unserialize($portal_forums);
		$size = sizeof($portal_forums);
		if ($size > 1) {
			$forums = "<span class='small'>{$ubbt_lang['MULTIPLE']}</span><br>";
		} else {
			$forums = "<span class='small'>{$forum_titles[$portal_forums[0]]}</span><br>";
		} // end foreach
	} else {
		$forums = $ubbt_lang['UNDEFINED'];
	} // end if
	
	if (!$items) $items = 5;
	
	$portals[] = array(
		"ID" => $portal_id,
		"NAME" => $portal_name,
		"FORUMS" => $forums,
		"CACHE" => $portal_cache,
		"TYPE" => $portal_post_type,
	);
} // end while
	

$tabs = array(
	"{$ubbt_lang['GALLERY_ISLANDS']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['GALLERY_ISLANDS']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['GALLERY_ISLANDS']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
include("../templates/default/admin/galleryislands.tmpl");

//$admin->createBottomTabs($bottomtabs,0);

$admin->sendFooter();
?>
