<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/gen_display.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");
$html = new html;

$admin = new Admin;

$admin->doAuth();

// Set the default values
$ischecked = 'checked="checked"';

$newcount = ($config['NEW_COUNT']) ? $ischecked : "";

$newreplies = ($config['NEW_REPLIES']) ? $ischecked : "";

$showage_checked = ($config['AGE_WITH_BIRTHDAYS']) ? $ischecked : "";

$cal_bday_checked = ($config['BIRTHDAYS_IN_CALENDAR']) ? $ischecked: "";

$showmods_checked = ($config['LIST_MODERATORS']) ? $ischecked : "";

$intro_checked = ($config['COMMUNITY_INTRO']) ? $ischecked : "";

$facebook_checked = $config['FACEBOOK'] ? $ischecked : "";
$twitter_checked = $config['TWITTER'] ? $ischecked : "";

$layout_side = $ischecked;
if ($config['POST_LAYOUT'] == "top") {
	$layout_top = $ischecked;
}

// What options exists for captcha?
$gd = true;
$im = true;
if (!function_exists(imagefttext)) {
	    $gd = false;
} // end if
if (!$config['CONVERT_PATH']) {
	    $im = false;
} // end if

$captcha_disabled = "";
$captcha_gd = "";
$captcha_im = "";
if ($config['POST_CAPTCHA'] == "gd" && $gd) {
	    $captcha_gd = "selected=\"selected\"";
} elseif ($config['POST_CAPTCHA'] == "im" && $im) {
	    $captcha_im = "selected=\"selected\"";
} 

$no_captcha = "";
if (!$gd && !$im) {
	    $no_captcha = $ubbt_lang['NO_CAPTCHA'];
} // end if


$display_both="";$display_flat="";$display_threaded="";
if ($config['TOPIC_DISPLAY_OPTIONS'] == "flat") {
	$display_flat = $ischecked;
} elseif ($config['TOPIC_DISPLAY_OPTIONS'] == "threaded") {
	$display_threaded = $ischecked;
} else {
	$display_both = $ischecked;
}

$catonlymode_checked = "";
if ($config['CATEGORY_ONLY_MODE']) {
	$catonlymode_checked = $ischecked;
}

$teaserlatest_checked = "";
if ($config['SHOW_TEASER_LATEST_POST']) {
	$teaserlatest_checked = $ischecked;
}

$enablepostcounts_checked = "";
if ($config['ENABLE_POST_COUNTS']) {
	$enablepostcounts_checked = $ischecked;
}

$showallgraemlins_checked = "";
if ($config['SHOW_ALL_GRAEMLINS']) {
	$showallgraemlins_checked = $ischecked;
}

$days = array(
	$ubbt_lang['SUNDAY_FULL'],
	$ubbt_lang['MONDAY_FULL'],
	$ubbt_lang['TUESDAY_FULL'],
	$ubbt_lang['WEDNESDAY_FULL'],
	$ubbt_lang['THURSDAY_FULL'],
	$ubbt_lang['FRIDAY_FULL'],
	$ubbt_lang['SATURDAY_FULL'],
);

$calendar_week_start = '<select name="CALENDAR_START_DAY" id="cal_startweek">';

for ($i = 0; $i < 7; $i++) {
	if ($i == array_get($config, 'CALENDAR_START_DAY', 0)) {
		$calendar_week_start .= sprintf('<option value="%s" selected="selected">%s</option>', $i, $days[$i]);
	} else {
		$calendar_week_start .= sprintf('<option value="%s">%s</option>', $i, $days[$i]);
	}
}

$calendar_week_start .= "</select>";


$flat_checked = ""; $thread_checked="";
if ($config['TOPIC_DISPLAY_STYLE'] == "flat") {
	$flat_checked = $ischecked;
}
else {
	$thread_checked = $ischecked;
}

$url_link_checked = ""; $email_link_checked="";
if ($config['CONTACT_LINK_TYPE'] == "url") {
	$url_link_checked = $ischecked;
}
else {
	$email_link_checked = $ischecked;
}

$show_avatars_checked = "";
if ($config['SHOW_AVATARS']) {
	$show_avatars_checked = $ischecked;
}

$priv_none_c = ""; $priv_text_c = ""; $priv_url_c = "";
$privacy_checked = "";
if ($config['PRIVACY_STATEMENT'] == "url") {
	$priv_url_c = $ischecked;
}
elseif ($config['PRIVACY_STATEMENT'] == "text") {
	$priv_text_c = $ischecked;
}
else {
	$priv_none_c = $ischecked;
}

$invisible_checked = "";
if ($config['DISABLE_ONLINE_INVISIBLE']) {
	$invisible_checked = $ischecked;
}

// Get search agents
$query = "
	select AGENTS
	from {$config['TABLE_PREFIX']}SEARCH_AGENTS
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
list($search_agents) = $dbh->fetch_array($sth);

// Get the privacy text
$privacy_text = file_get_contents("{$config['FULL_PATH']}/includes/privacy.php");
$privacy_text = htmlspecialchars($privacy_text);

// Get the community intro text
$intro_body = file_get_contents("{$config['FULL_PATH']}/includes/community_intro.php");
$intro_body = htmlspecialchars($intro_body);

$servertime = $html -> convert_time(time(),"","",1);

// Quicky reply enabled?
$quickreply_c = "";
if ($config['ENABLE_QUICK_REPLY']) {
	$quickreply_c = "checked=\"checked\"";
}

// Grab the default header
$headerfile = file_get_contents("{$config['FULL_PATH']}/includes/header.php");
$headerfile = htmlspecialchars($headerfile);

// Grab the default insert
$insertfile = file_get_contents("{$config['FULL_PATH']}/includes/header-insert.php");
$insertfile = htmlspecialchars($insertfile);

// Grab the default footer
$footerfile = file_get_contents("{$config['FULL_PATH']}/includes/footer.php");
$footerfile = htmlspecialchars($footerfile);

$timeformats = join($config['TIME_FORMATS'],"\n");

$relative = "";
if ($config['RELATIVE_TIME']) {
	$relative = "checked='checked'";
} // end if

$tabs = array(
	"{$ubbt_lang['PRIMARY_DISP']}" => "",
	"{$ubbt_lang['DATE_DISP']}" => "",
	"{$ubbt_lang['INCLUDES']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['GENERAL']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['DISPLAY_OPT']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);
$admin->setCommonSubmit($ubbt_lang['UPDATE_GEN']);

foreach($config as $key => $value) {
	$config[$key] = htmlspecialchars($value);
}
// Include the template
include("../templates/default/admin/gen_display.tmpl");

$admin->sendFooter();
?>
