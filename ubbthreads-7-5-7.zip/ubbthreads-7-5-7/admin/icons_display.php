<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/image_display.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();



// Get the current list of available icons
$dir = opendir("{$config['FULL_PATH']}/images/{$style_array['icons']}");
$iconlist = <<<EOF
<table border="0" cellspacing="0" cellpadding="0" width="100%">
<tr>
<td class="autorow-header-1 bold">
{$ubbt_lang['DELETE_TEXT']}
</td>
<td class="autorow-header-1 bold">
{$ubbt_lang['IMAGE']}
</td>
<td class="autorow-header-1 bold">
{$ubbt_lang['CHANGE']}
</td>
</tr>
EOF;

while( ($file = readdir($dir)) != false) {
	if ( ($file == ".") || ($file == "..") || ($file == "lock.gif") || ($file == "blank.gif") || ($file == "blank.gif") || (!preg_match("/(gif|jpg|png)$/",$file))) {
		continue;
	}
	list ($name,$ext) = preg_split("#\.#",$file);
	$iconlist .= "<tr><td class=\"autobottom\" valign=\"bottom\"><input type=\"checkbox\" name=\"$name\" value=\"$ext\" /></td><td class=\"autobottom\" valign=\"bottom\"><img src=\"{$config['BASE_URL']}/images/{$style_array['icons']}/$file\" border=\"0\" /></td><td class=\"autobottom\" valign=\"bottom\"><input type=\"file\" name=\"file-$ext-$name\" /></td></tr>";
}
$iconlist .= "</table>";


$tabs = array(
	"{$ubbt_lang['ICON_DISP']}" => "",
	"{$ubbt_lang['GRAEMLIN_DISP']}" => "{$config['BASE_URL']}/admin/graemlins_display.php?returntab=1",
	"{$ubbt_lang['AV_DISP']}" => "{$config['BASE_URL']}/admin/avatars_display.php?returntab=2",
	"{$ubbt_lang['F_IMAGES']}" => "{$config['BASE_URL']}/admin/fimages_display.php?returntab=3",
	"{$ubbt_lang['NEWS_IMAGES']}" => "{$config['BASE_URL']}/admin/newsimages_display.php?returntab=4",
	"{$ubbt_lang['MOOD_DISP']}" => "{$config['BASE_URL']}/admin/mood_display.php?returntab=5"
);

$admin->setCurrentMenu($ubbt_lang['IM_IC']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['IM_IC']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
include("../templates/default/admin/icons_display.tmpl");

$bottomtabs = array(
	"{$ubbt_lang['NEW_ICON']}" => "{$config['BASE_URL']}/admin/addimage.php?type=icons"
);
$admin->createBottomTabs($bottomtabs,0);

$admin->sendFooter();
?>
