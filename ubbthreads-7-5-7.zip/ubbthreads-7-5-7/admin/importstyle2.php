<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/importstyle.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info
$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$returntab = 0;

// -----------------------
// Get the uploaded style
if (empty($_FILES['style']['name'])) {
	$admin->error($ubbt_lang['NO_STYLE']);
}
$file_name = $_FILES['style']['name'];
$style_temp = $_FILES['style']['tmp_name'];

move_uploaded_file($style_temp,"{$config['FULL_PATH']}/styles/import.file");
$file = file_get_contents("{$config['FULL_PATH']}/styles/import.file");
unlink("{$config['FULL_PATH']}/styles/import.file");

preg_match("/--STYLE_DETAILS--(.*)--END_STYLE_DETAILS--/sm",$file,$content);
$style_details = $content[1];

preg_match("/--STYLE_VARS--(.*)--END_STYLE_VARS--/sm",$file,$content);
$style_vars = $content[1];

preg_match("/--IMAGE_VARS--(.*)--END_IMAGE_VARS--/sm",$file,$content);
$image_vars = $content[1];

preg_match("/--WRAPPER_SET--(.*)--END_WRAPPER_SET--/sm",$file,$content);
$wrapper_set = $content[1];


// No image sets should start with a / or an http, or have an include or require
if (preg_match("/('\/|http|include|require)/",$image_vars)) {
	$admin->error($ubbt_lang['IMAGE_VARS_CONTAMINATED']);
	exit;
}

// We shouldn't see any type of include or require in the style vars
if (preg_match("/(include|require)/",$style_vars)) {
	$admin->error($ubbt_lang['STYLE_VARS_CONTAMINATED']);
	exit;
}

preg_match("/STYLE_NAME:(.*)/",$style_details,$content);
$style_name = trim($content[1]);

preg_match("/WRAPPER_ID:(.*)/",$style_details,$content);
$wrapper_id = trim($content[1]);

preg_match("/EXPORT_VERSION: (.*)$/",$style_details,$content);
$style_version = trim($content[1]);

$style_vars = preg_replace("#FULL_URL#",$config['FULL_URL'],$style_vars);

eval("\$style_array = $style_vars");

// Apply any updates to this style
include("importstyle_changes.php");
$current = false;
$doupdate = false;
foreach($all_versions as $k => $v) {
	if ($v == $style_version) $current = true;
	if ($current === false) continue;
	if ($current === true && $doupdate === false) {
		$doupdate = true;
		continue;
	}
	if (isset($changes[$v])) {
		foreach($changes[$v] as $class => $method) {
			foreach($method as $do => $val) {
				if ($do == "copy") {
					$style_array[$class] = $style_array[$val];
				} // end if
			} // end foreach
		} // end foreach
	} // end if
} // end foreach

$css_file = "";
foreach($style_array as $class => $properties) {
	$css_file .= "$class {\r\n$properties\r\n}\r\n";
}

eval("\$image_array = $image_vars");

if ($wrapper_set) {
	$wrapper_set = preg_replace("#FULL_URL#",$config['FULL_URL'],$wrapper_set);
	eval("\$wrapper_array = $wrapper_set");
	include("{$config['FULL_PATH']}/styles/wrappers.php");
	$wrappers[] = $wrapper_array;
	foreach($wrappers as $key => $value) {
		$wrapper_id = $key;
	}
	
	$wrapper_file = "<?php\n\$wrappers = " . var_export($wrappers,true) . "?>\n";
	$check = lock_and_write("{$config['FULL_PATH']}/styles/wrappers.php",$wrapper_file);
	if ($check == "no_write") {
		$admin->error($ubbt_lang['NO_WRITE_WRAPPERS']);
	} // end if
}

$time = time();
$query = "
	insert into {$config['TABLE_PREFIX']}STYLES
	(STYLE_NAME,STYLE_IMG,STYLE_EDITED_TIME,STYLE_VARS,STYLE_WRAPPERS,STYLE_IS_ACTIVE)
	values
	( ? , ? , ? , ? , ? , ? )
";
$dbh->do_placeholder_query($query,array($style_name,serialize($image_array),$time,serialize($style_array),$wrapper_id,1));

$query = "
	select last_insert_id()
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
list($style_id) = $dbh->fetch_array($sth);

$css_name = "{$style_name}_{$time}.css";

$new_style_array = <<<THE_YELLOW_BRICK_ROAD
<?php
\$style_array = array(
	"id" => '$style_id',
	"general" => "{$image_array['general']}",
	"avatars" => "{$image_array['avatars']}",
	"forumimages" => "{$image_array['forumimages']}",
	"graemlins" => "{$image_array['graemlins']}",
	"icons" => "{$image_array['icons']}",
	"markup_panel" => "{$image_array['markup_panel']}",
	"news" => "{$image_array['news']}",
	"wrappers" => $wrapper_id,
	"css" => "$css_name"
);
?>
THE_YELLOW_BRICK_ROAD;

$check = lock_and_write("{$config['FULL_PATH']}/styles/$style_id.php",$new_style_array);
if ($check == "no_write") {
	$admin->error($ubbt_lang['NO_WRITE_STYLE']);
} // end if

$check = lock_and_write("{$config['FULL_PATH']}/styles/$css_name",$css_file);
if ($check == "no_write") {
	$admin->error($ubbt_lang['NO_WRITE_STYLE']);
} // end if

admin_log("IMPORT_STYLE","{$style_name}");

build_forum_cache();

$admin->redirect($ubbt_lang['STYLE_IMPORTED'],"{$config['BASE_URL']}/admin/editstyle.php?style=$style_id",$ubbt_lang['IMPORT_F_LOC']);


?>
