<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/logs.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","both");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");
$html = new html;

$admin = new Admin;

$admin->doAuth();

$action = get_input("action","get");
$file = get_input("file","get");

if ($action == "remove") {
	@unlink("{$config['SQL_LOG_PATH']}/$file");
	$admin->redirect("$file {$ubbt_lang['REMOVED']}","logs.php",$ubbt_lang['F_LOC']);
	exit;
}


$dir = @opendir("{$config['SQL_LOG_PATH']}");
$i=0;
$log = array();
while( ($filen = @readdir($dir)) != false) {
	if ( ($filen == ".") || ($filen == "..") || (!stristr($filen,"mysql.log") ) ) {
		continue;
	}
	$log[$i]['name'] = $filen;
	$log[$i]['size'] = sprintf("%u", filesize("{$config['SQL_LOG_PATH']}/{$filen}"));
	if ($log[$i]['size'] > 1024) {
		$log[$i]['size'] = intval($log[$i]['size']/ 1024) . "KB";
	} else {
		$log[$i]['size'] .= "B";
	}
	$i++;
}
@closedir($dir);

$view = "";
if ($action=="view") {
//	$view = "<tr><td colspan=\"3\" class=\"stdautorow colored-row\">&nbsp;<br />&nbsp;</td></tr>";
	$view .= "<tr><td colspan=\"2\" class=\"autorow-header-1 bold\">{$ubbt_lang['DETAILS']} <a name=\"show\"></a>$file</td>";
	$view .= "<td colspan=\"2\" class=\"autorow-header-1 bold\" align=\"right\">";
	$view .= "[<a href=\"{$config['BASE_URL']}/admin/logs.php?action=remove&amp;file={$file}\">{$ubbt_lang['REMOVE']}]</a></tr>";
	$entries = file_get_contents("{$config['SQL_LOG_PATH']}/$file");
	$array = explode("[ERROR]", $entries);
	for ($i=0;$i<sizeof($array);$i++) {
		if ($array[$i]) {
			$piece['0'] = "";
			preg_match("/\[(.*?)\] \[(.*?)\] \[(.*?)\]([^\[]+)/",$array[$i],$piece);
			$piece[4] = str_replace("\n","<br />",$piece[4]);
			$view .= "<tr><td class=\"stdautorow colored-row autobottom autotop\" valign=\"top\">$piece[1]<br />$piece[3]</td>";
			$view .= "<td class=\"stdautorow colored-row autobottom autotop\" valign=\"top\" colspan=\"2\">$piece[4]</td>";
			$view .= "</tr>";
		}
	}
}

$Log = get_input("adminlog","both");

// -----------------
// Read the log file
$logfile = "{$config['ADMIN_LOG_PATH']}/admin.log";
if (is_numeric($Log)) {
	$thislogfile = "$logfile.$Log";
} else {
	$thislogfile = $logfile;
}
if (file_exists($thislogfile)) {
	$logrows = file($thislogfile);
}

$logsize = @filesize($thislogfile);
$lines = count($logrows);
$logfilename = basename($logfile);

// Find the other log files
$i = 1;
$selected = ($Log) ? "" : "selected=\"selected\"";
$options = "<option value=\"\" $selected>$logfilename</option>\n";
while(file_exists("$logfile.$i")) {
	$selected = ($i == $Log) ? "selected=\"selected\"" : "";
	$options .= "<option value=\"$i\" $selected>$logfilename.$i</option>\n";
	$i++;
}

for ($i=0; $i<$lines; $i++) {
	@list($Date,$IP,$Operation,$Username,$Usernumber,$Status,$Info) = @preg_split("/(?<!\\\\),/", trim($logrows[$i]), 7);
	if ($Status == "A") {
		$Userstatus = "{$ubbt_lang['ADMIN']}";
	} elseif ($Status == "M") {
		$Userstatus = "{$ubbt_lang['MOD']}";
	} else {
		$Userstatus = "{$ubbt_lang['UNKNOWN']}: $Status";
	}
	$Username = stripcslashes($Username);
	$Info = stripcslashes($Info);
	preg_match_all("#^(\d{4})/(\d{2})/(\d{2}):(\d{2}):(\d{2}):(\d{2})\s(.{4,5})$#", $Date, $d);
	$Date = @mktime($d[4][0],$d[5][0],$d[6][0],$d[2][0],$d[3][0],$d[1][0]);
	$Date = $html -> convert_time($Date);
	$row[$i] = "<tr nowrap=\"nowrap\">
	<td nowrap class=\"stdautorow colored-row autobottom autotop autoleft autoright\">$Date</td><td class=\"stdautorow colored-row autobottom autotop autoleft autoright\">$IP</td><td class=\"stdautorow colored-row autobottom autotop autoleft autoright\">$Operation</td><td class=\"stdautorow colored-row autobottom autotop autoleft autoright\">$Username</td><td class=\"stdautorow colored-row autobottom autotop autoleft autoright\">$Usernumber</td><td class=\"stdautorow colored-row autobottom autotop autoleft autoright\">$Userstatus</td><td class=\"stdautorow colored-row autobottom autotop autoleft autoright\">$Info</td>
	</tr>
	";
}

$tabs = array(
	"{$ubbt_lang['SQL_HEAD']}" => "",
	"{$ubbt_lang['ADMIN_HEAD']}" => "{$config['BASE_URL']}/admin/admin_log.php?returntab=1",
	"{$ubbt_lang['REFERER_HEAD']}" => "{$config['BASE_URL']}/admin/referer_log.php?returntab=2"
);

$admin->setCurrentMenu($ubbt_lang['LOGS']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['SQL_HEAD']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
include("../templates/default/admin/logs.tmpl");

$admin->sendFooter();
?>
