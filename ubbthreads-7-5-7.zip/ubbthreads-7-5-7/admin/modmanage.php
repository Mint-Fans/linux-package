<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/modmanage.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");
$newmods = get_input("newmods","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();


// Grab all the moderators
$query = "
	SELECT t1.USER_DISPLAY_NAME,t2.USER_ID,t2.FORUM_ID
	FROM {$config['TABLE_PREFIX']}MODERATORS AS t2,
	{$config['TABLE_PREFIX']}USERS AS t1
	WHERE t2.USER_ID = t1.USER_ID
	ORDER BY FORUM_ID, USER_DISPLAY_NAME
";
$sth = $dbh->do_query($query);
$oldmodboard = "";
while(list($modusername,$moduid,$modboard) = $dbh->fetch_array($sth)) {
	if (!isset($modtotals[$moduid])) {
		$modtotals[$moduid] = "1";
	}
	else {
		$modtotals[$moduid]++;
	}
	if ($modboard != $oldmodboard) {
		$x=0;
	}
	$oldmodboard = $modboard;
	if (!isset($modarray[$modboard])) {
		$modarray[$modboard] = "-$moduid-";
	}
	else {
		$modarray[$modboard] .= "$moduid-";
	}
	$modlist[$modboard][$x]['uid'] = $moduid;
	$modlist[$modboard][$x]['username'] = $modusername;
	$x++;
}

include("{$config['FULL_PATH']}/cache/forum_cache.php");
if (!sizeof($tree)) {
	list($tree,$style_cache,$lang_cache) = build_forum_cache();
}
$c=0;
foreach($tree['categories'] as $centry => $ctitle) {
	$f = 0;
	if (!isset($tree[$centry])) continue;
	foreach($tree[$centry] as $fnumber => $ftitle) {
	
		$forum[$c][$f]['number'] = $fnumber;
		$forum[$c][$f]['title'] = $ftitle;
		if (isset($modarray[$fnumber])) {
			$forum[$c][$f]['moderators'] = $modarray[$fnumber];
		} else {
			$forum[$c][$f]['moderators'] = "-!";
		}

		$forum[$c][$f]['modstuff'] = "";
		if (isset($modlist[$fnumber])) {
			$m=1;
			for($i=0;$i<sizeof($modlist[$fnumber]);$i++) {
				$forum[$c][$f]['modstuff'] .= <<<EOF
<div id="forum-$fnumber-mod-$m" class="modname">
<b>{$modlist[$fnumber][$i]['username']}</b> (<a href="{$config['BASE_URL']}/admin/showuser.php?uid={$modlist[$fnumber][$i]['uid']}" target="_blank"># {$modlist[$fnumber][$i]['uid']}</a>)
<br />[<a href="javascript:void(remove_moderator($fnumber,'$m'));">{$ubbt_lang['REMOVE']}</a>]
</div>
<script language="JavaScript1.3" type="text/javascript">
mod_list["{$modlist[$fnumber][$i]['uid']}"]++;
</script>

EOF;
				$m++;
			}
			$forum[$c][$f]['modstuff'] .= "<div class=\"modname hidden\" id=\"forum-$fnumber-yank\">{$ubbt_lang['NOMODS']}</div>";
		}
		else {
			$forum[$c][$f]['modstuff'] = "<div class=\"modname\" id=\"forum-$fnumber-yank\">{$ubbt_lang['NOMODS']}</div>";
		}

		$f++;
	}
	if ($f) {
		$cat[$c] = $ctitle;
		$c++;
	}
}

$tabs = array(
	"{$ubbt_lang['MOD_SET']}" => "",
);

$admin->setCurrentMenu($ubbt_lang['MOD_SET']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['MOD_SET']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
include("../templates/default/admin/modmanage.tmpl");

$admin->sendFooter();
?>
