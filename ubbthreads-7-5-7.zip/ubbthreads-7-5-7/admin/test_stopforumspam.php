<?php
//	Script Version 7.5.7

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/primary.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/stop_forum_spam.php");

// Used to send data to SFS
function PostToSFS($data) {
	$fp = fsockopen("www.stopforumspam.com",80);
	fputs($fp, "POST /add.php HTTP/1.1\n" );
	fputs($fp, "Host: www.stopforumspam.com\n" );
	fputs($fp, "Content-type: application/x-www-form-urlencoded\n" );
	fputs($fp, "Content-length: ".strlen($data)."\n" );
	fputs($fp, "Connection: close\n\n" );
	fputs($fp, $data);
	fclose($fp);
	}

// Get the inputs
$op = get_input("op", "both");
$id = get_input("id", "both", "int");

// -----------------
// Get the user info
$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");
$html = new html;

$admin = new Admin;
$admin->doAuth(array("EDIT_USERS"));

// ------------------------
// Check API Status in a popup
if ($op == 'test') {
$xmlResult = @file_get_contents("http://www.stopforumspam.com/api?ip=91.186.18.61");
if($xmlResult != false) {
	$xml = new SimpleXMLElement($xmlResult);
	if($xml->appears == 'no') {
		$SFS_Status_Class = 'sfsgood';
		$SFS_Status = $ubbt_lang['SFS_STAT_GOOD'];
	} else {
		$SFS_Status_Class = 'sfsbad';
		$SFS_Status = $ubbt_lang['SFS_STAT_BAD'];
	}
}

echo <<<UBBTPRINT
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>{$ubbt_lang['SFS_TITLE']}</title>
		<link rel="stylesheet" href="{$config['BASE_URL']}/styles/admin.css" />
	</head>
	<body style="padding:20px">
		<table cellpadding="0" cellspacing="0" width="95%">
			<tr>
				<td class="autorow-header-2 colored-row" style="border-radius:8px 8px 0 0;">{$ubbt_lang['SFS_TITLE']}</td>
			</tr>
			<tr>
				<td class="autorow-header-2 colored-row" style="padding:10px;border-radius:0 0 8px 8px;border-bottom:none;">
					<span class="{$SFS_Status_Class}">{$ubbt_lang['SFS_STAT_DESC']}{$SFS_Status}</span>
				</td>
			</tr>
		</table>
	</body>
</html>
UBBTPRINT;
} elseif ($op == 'info' || $op == 'spammer') {
	// They asked for us to check Email and 2 IPs
	$q = "
		SELECT u.USER_LOGIN_NAME, u.USER_REGISTRATION_EMAIL, u.USER_REGISTRATION_IP, ud.USER_LAST_IP
		FROM {$config['TABLE_PREFIX']}USERS u, {$config['TABLE_PREFIX']}USER_DATA ud
		WHERE u.USER_ID='{$id}'
		AND u.USER_ID = ud.USER_ID
	";
	$sth = $dbh->do_query( $q );
	list($userName, $regEmail, $regIP, $lastIP) = $dbh->fetch_array( $sth );

	// Check Email and regIP first
	list($retStat, $retEmail, $retRegIp) = $userob->sfsCheck($regEmail, $regIP);

	$sfsError = 0;
	if($retStat == 0) {
		if($retEmail == 1){
			$emailStat = '<span class="sfs-bad-stat">' . $ubbt_lang['SFS_BAD_EMAIL'] . '</span>';
		} else {
			$emailStat = '<span class="sfs-good-stat">' . $ubbt_lang['SFS_GOOD_EMAIL'] . '</span>';
		}
		if($retRegIp == 1){
			$ipRegStat = '<span class="sfs-bad-stat">' . $ubbt_lang['SFS_BAD_IP'] . '</span>';
		} else {
			$ipRegStat = '<span class="sfs-good-stat">' . $ubbt_lang['SFS_GOOD_IP'] . '</span>';
		}
	} else {
		$sfsError = 1;
	}

	// Check LastIP next
	$ipLastStat = '';
	if ($lastIP != '') {
		list($retStat, $retEmail, $retLastIp) = $userob->sfsCheck($regEmail, $lastIP);

		$sfsError = 0;
		if($retStat == 0) {
			if($retRegIp == 1){
				$ipLastStat = '<span class="sfs-bad-stat">' . $ubbt_lang['SFS_BAD_IP'] . '</span>';
			} else {
				$ipLastStat = '<span class="sfs-good-stat">' . $ubbt_lang['SFS_GOOD_IP'] . '</span>';
			}
		} else {
			$sfsError = 1;
		}
	}

	echo <<<UBBTPRINT
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>{$ubbt_lang['SFS_TITLE']}</title>
		<link rel="stylesheet" href="{$config['BASE_URL']}/styles/admin.css" />
	</head>
	<body style="padding:20px;">
		<table cellpadding="0" cellspacing="0" width="95%">
			<tr>
				<td colspan="2" class="sfs-header">{$ubbt_lang['SPAM_CHECK']}</td>
			</tr>
			<tr>
				<td class="sfs-info-row" width="50%">
					{$ubbt_lang['SFS_EMAIL_STATUS']}
				</td>
				<td class="sfs-info-row" width="50%">
					{$emailStat}
				</td>
			</tr>
			<tr>
				<td class="sfs-info-row" width="50%">
					{$ubbt_lang['SFS_REG_IP_STATUS']}
				</td>
				<td class="sfs-info-row" width="50%">
					{$ipRegStat}
				</td>
			</tr>
UBBTPRINT;
	if ($ipLastStat != '') {
		echo <<<UBBTPRINT
			<tr>
				<td class="sfs-info-row" width="50%">
					{$ubbt_lang['SFS_LAST_IP_STATUS']}
				</td>
				<td class="sfs-info-row" width="50%">
					{$ipLastStat}
				</td>
			</tr>
UBBTPRINT;
	}
	// Regardless, put a 'Report Spammer' button, but with a lot of language to warn them, if they have a KEY
	if ($config['SFS_KEY'] != '') {
		if ($op == 'spammer') {
			$ubbt_lang['SFS_REPORT_SPAMMER'] = $ubbt_lang['SFS_REPORTED_SPAMMER'];
			$safeEmail = urlencode(iconv('GBK', 'UTF-8', $regEmail));
			$safeName = urlencode(iconv('GBK', 'UTF-8', $userName));
			PostToSFS("username={$safeName}&ip_addr={$regIP}&email={$safeEmail}&api_key={$config['SFS_KEY']}");
		}
		echo <<<UBBTPRINT
			<tr>
				<td class="sfs-instructions" width="50%">
					{$ubbt_lang['SFS_REPORT_INSTRUCTIONS']}
				</td>
				<td class="sfs-instructions" width="50%" valign="bottom" align="right">
					<form method="post" id="spamform" action="{$config['BASE_URL']}/admin/test_stopforumspam.php">
						<input type="hidden" name="valid_post" value="1" />
						<input type="hidden" name="op" value="spammer" />
						<input type="hidden" name="id" value="{$id}" />
						<input type="submit" class="sfs-button" value="{$ubbt_lang['SFS_REPORT_SPAMMER']}" />
					</form>
				</td>
			</tr>
UBBTPRINT;
	}
	echo <<<UBBTPRINT
		</table>
	</body>
</html>
UBBTPRINT;
}
?>
