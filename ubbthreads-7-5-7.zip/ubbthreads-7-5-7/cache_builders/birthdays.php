<?php
//	Script Version 7.5.7

if (!defined('UBB_MAIN_PROGRAM')) {
	exit;
}

$temp = getdate(time());
$month = $temp['mon'];
$mday = $temp['mday'];
$year = $temp['year'];
$users = array();
$i = 0;

$visitlimit = '0';
if ($config['PORTAL_BDAYS'] > 0) {
	$visitlimit = time()-60*60*24*$config['PORTAL_BDAYS'];
}

$query = "
	SELECT t1.USER_DISPLAY_NAME,t2.USER_BIRTHDAY,t1.USER_IS_UNDERAGE,t1.USER_ID,t2.USER_NAME_COLOR,t1.USER_MEMBERSHIP_LEVEL
	FROM   {$config['TABLE_PREFIX']}USERS as t1,
	{$config['TABLE_PREFIX']}USER_PROFILE as t2,
	{$config['TABLE_PREFIX']}USER_DATA as t3
	WHERE  t2.USER_BIRTHDAY LIKE ?
	AND    t1.USER_IS_BANNED != '1'
	AND    t2.USER_PUBLIC_BIRTHDAY = '1'
	AND    t3.USER_LAST_VISIT_TIME >= ?
	AND t1.USER_ID = t2.USER_ID
	AND t1.USER_ID = t3.USER_ID
	ORDER BY t1.USER_DISPLAY_NAME
";
$sth = $dbh -> do_placeholder_query($query,array("$month/$mday/%",$visitlimit),__LINE__,__FILE__);
while(list($uname,$birthday,$coppauser,$uid,$color,$level) = $dbh -> fetch_array($sth)) {
	$age = "";
	@list($bmonth,$bday,$byear) = @preg_split("#/#",$birthday);
	if ($config['AGE_WITH_BIRTHDAYS'] && !$coppauser) {
		$age = $year - $byear;
		$age = "&nbsp;($age)";
	} // end if
	$users[$i]['name'] = $html->user_color($uname,$color,$level);
	$users[$i]['uid'] = $uid;
	$users[$i]['age'] = $age;
	$i++;
} // end while

$smarty->assign("users",$users);
$smarty->assign("bdays",sizeof($users));

$island = $smarty->fetch("island_birthdays.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/birthdays.php",$island);

@chmod("{$config['FULL_PATH']}/cache/birthdays.php",0666);

?>
