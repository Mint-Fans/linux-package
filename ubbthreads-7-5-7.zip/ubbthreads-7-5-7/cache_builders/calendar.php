<?php
//	Script Version 7.5.7

if (!defined('UBB_MAIN_PROGRAM')) {
	exit;
}

$output_text = "<table border=0><tr><th>{$ubbt_lang['CALENDAR']}</th><tr><tr></td></tr></table>";
lock_and_write("{$config['FULL_PATH']}/cache/calendar.php",$output_text);

@chmod("{$config['FULL_PATH']}/cache/calendar.php",0666);

?>
