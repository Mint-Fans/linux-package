<?php
//	Script Version 7.5.7

if (!defined('UBB_MAIN_PROGRAM')) {
	exit;
}

if (!$name) $name = "Gallery Island $portal_id";

$smarty->assign("name",$name);

if (!$forums) return;

$forums = unserialize($forums);

if (!sizeof($forums)) return;
$inlist = "";
if (in_array("allforums",$forums)) {
	$forum_clause = "";
} else {
	foreach($forums as $k => $forum) {
		$inlist .= "'$forum',";
	} // end foreach
	$inlist = preg_replace("/,$/","",$inlist);
	$forum_clause = "and FORUM_ID in  ($inlist)";
}


if (!$items) {
	$items = 5;
} // end if

$html = new html;
	
$query = "
	select TOPIC_ID,POST_ID,TOPIC_THUMBNAIL,TOPIC_SUBJECT
	from {$config['TABLE_PREFIX']}TOPICS
	where TOPIC_IS_APPROVED = '1'
	and TOPIC_STATUS <> 'M'
	$forum_clause
	ORDER BY TOPIC_CREATED_TIME DESC
	limit $items
";

$sth = $dbh->do_query($query,__LINE__,__FILE__);
$items = array();
$latest = 0;
while($posts = $dbh->fetch_array($sth)) {
	$posts['TOPIC_SUBJECT'] = str_replace('"','&quot;',$posts['TOPIC_SUBJECT']);
	$is = getimagesize("{$config['FULL_PATH']}/gallery/{$posts['TOPIC_THUMBNAIL']}");
	$posts['WIDTH_HEIGHT'] = "";
	if ($is[0]) {
		$posts['WIDTH_HEIGHT'] = "width='{$is[0]}' height='{$is[1]}'";
	} // end if
	$items[] = $posts;
} // end while
		
$smarty->assign_by_ref("items",$items);
$smarty->assign("island",$portal_id);
$smarty->assign("type",$type);
$island = $smarty->fetch("gallery_island.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/gallery_island_$portal_id.php",$island);

@chmod("{$config['FULL_PATH']}/cache/gallery_island_$portal_id.php",0666);

?>
