<?php
//	Script Version 7.5.7

if (!defined('UBB_MAIN_PROGRAM')) {
	exit;
}

// Need to move this into the config
$limit = 10;

// Exclude forums? 
$notin = "";
if ($config['EXCLUDE_POPULAR']) {
	$notin = "and f.FORUM_ID not in ({$config['EXCLUDE_POPULAR']})";
} // end if

$query = "
	SELECT t.TOPIC_SUBJECT, t.TOPIC_VIEWS, t.POST_ID
	FROM {$config['TABLE_PREFIX']}TOPICS t,
	{$config['TABLE_PREFIX']}POSTS p,
	{$config['TABLE_PREFIX']}FORUMS f,
	{$config['TABLE_PREFIX']}USERS u
	WHERE t.FORUM_ID = f.FORUM_ID
	AND t.TOPIC_IS_APPROVED = 1
	AND t.TOPIC_LAST_POST_ID = p.POST_ID
	AND t.TOPIC_LAST_POSTER_ID = u.USER_ID
	$notin
	ORDER BY t.TOPIC_VIEWS DESC
	LIMIT $limit
";
$sth = $dbh -> do_query($query,__LINE__,__FILE__);
$topics = array();
$i = 0;
while(list($sub,$views,$pid) = $dbh -> fetch_array($sth)) {
	$topics[$i]['subject'] = $sub;
	$topics[$i]['views'] = $views;
	$topics[$i]['post'] = $pid;
	$i++;
} // end while

$smarty->assign("topics",$topics);

$island = $smarty->fetch("island_popular_topics.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/popular_topics.php",$island);

@chmod("{$config['FULL_PATH']}/cache/popular_topics.php",0666);

?>
