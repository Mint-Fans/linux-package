<?php
//	Script Version 7.5.7

if (!defined('UBB_MAIN_PROGRAM')) {
	exit;
}

$temp = getdate($now);
$month = $temp["mon"];
$year  = $temp["year"];
$thisday   = $temp["mday"];
$today = $thisday;

// Get the weekday the first is on
$temp = getdate(mktime(0,0,0,$month,1,$year));
$first_weekday = $temp["wday"] - $config['CALENDAR_START_DAY'];
$month_number = $temp["mon"];
$month_name = "MONTH$month_number";

if ($first_weekday < 0) {
	$first_weekday += 7;
}



$weekday_array = array(
	'$ubbt_lang["SUNDAY"]',
	'$ubbt_lang["MONDAY"]',
	'$ubbt_lang["TUESDAY"]',
	'$ubbt_lang["WEDNESDAY"]',
	'$ubbt_lang["THURSDAY"]',
	'$ubbt_lang["FRIDAY"]',
	'$ubbt_lang["SATURDAY"]',
);

for ($j = 0; $j < $config['CALENDAR_START_DAY']; $j++) {
	$weekday_array[] = array_shift($weekday_array);
}

// Get the last day of the month
$nextmonth = $month + 1;
$tempyear = $year;
if ($nextmonth == 13) {
	$nextmonth = 1;
	$tempyear = $tempyear + 1;
} // end if

$temp = getdate(mktime(0,0,0,$nextmonth,0,$tempyear));
$lastday = $temp["mday"];
$currentdate = 1;
$firstweek = true;
$weekday = 1;
$currentweek = 1;

$weeks = array();
$day = 1;
$week = 0;
$open_spacer = false;
while($currentdate <= $lastday) {

	if ($firstweek == true && $open_spacer == false) {
		$open_spacer = true;
		for ($i=1;$i<=$first_weekday;$i++) {
			$weeks[$week][$i] = 0;
		} // end for
		$day = $i;
	} // end if

	$weeks[$week][$day] = $currentdate;
	$day++;
	if ($day == 8) {
		$day = 1;
		$week++;
	}
	$currentdate++;
} // end while

if ($day < 8 and $day != 1) {
	for($i=$day;$i<8;$i++) {
		$weeks[$week][$i] = 0;
	} // end for
}// end if

$month = $temp["mon"];
$year  = $temp["year"];
$thisday   = $temp["mday"];
	
// Grab birthdays if necessary
$events = array_fill(0, 32, "");
if (array_get($config, 'BIRTHDAYS_IN_CALENDAR', false)) {
	$query = "
		SELECT t1.USER_DISPLAY_NAME,t2.USER_BIRTHDAY,t1.USER_IS_UNDERAGE
		FROM   {$config['TABLE_PREFIX']}USERS as t1,
			{$config['TABLE_PREFIX']}USER_PROFILE as t2
		WHERE  t2.USER_BIRTHDAY LIKE ?
		AND    t2.USER_PUBLIC_BIRTHDAY = '1'
		AND t1.USER_ID = t2.USER_ID
	";
	$sth = $dbh -> do_placeholder_query($query,array("$month/%"),__LINE__,__FILE__);
	$marray[0] = "";
	while(list($uname,$birthday,$coppauser) = $dbh -> fetch_array($sth)) {
		@list($bmonth,$bday,$byear) = @preg_split("#/#",$birthday);
		$age = "";
		if ($config['AGE_WITH_BIRTHDAYS'] && !$coppauser && $byear) {
			$age = $year - $byear;
			$age = " ($age)";
		} // end if
		
		if (array_get($events, $bday, null) != null) {
			$events[$bday] .= "<?php echo \$ubbt_lang['BDAY'] ?>: $uname $age\n";
		} else {
			$events[$bday] = "<?php echo \$ubbt_lang['BDAY'] ?>: $uname $age\n";
		}
	} // end while
} // end if

	
// ----------------------------------
// Now grab all events for this month
$query_vars = array($month,$year,$month);
$query = "
	SELECT CALENDAR_EVENT_SUBJECT,CALENDAR_EVENT_DAY,CALENDAR_EVENT_MONTH,CALENDAR_EVENT_YEAR,CALENDAR_EVENT_RECURRING
	FROM {$config['TABLE_PREFIX']}CALENDAR_EVENTS
	WHERE ( (CALENDAR_EVENT_MONTH = ? AND CALENDAR_EVENT_YEAR = ? AND CALENDAR_EVENT_RECURRING='never')
	OR   (CALENDAR_EVENT_MONTH = ? AND CALENDAR_EVENT_RECURRING='yearly')
	OR   (CALENDAR_EVENT_RECURRING='monthly') )
	AND ( (CALENDAR_EVENT_TYPE='public') )
";
$sth = $dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

while(list($brief,$eday,$emonth,$eyear,$recurring) = $dbh -> fetch_array($sth)) {
	$brief = preg_replace('#"#','&quot;',$brief);
	
	if (array_get($events, $eday, null) != null) {
		$events[$eday] .= "<?php echo \$ubbt_lang['EVENT'] ?>: $brief\n";
	} else {
		$events[$eday] = "<?php echo \$ubbt_lang['EVENT'] ?>: $brief\n";
	}
} // end while

$smarty->assign("weeks",$weeks);
$smarty->assign("month_name",$month_name);
$smarty->assign("events",$events);
$smarty->assign("today",$today);
$smarty->assign("month",$month);
$smarty->assign("year",$year);
$smarty->assign("weekday_array", $weekday_array);
$island = $smarty->fetch("island_public_calendar.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/public_calendar.php",$island);

@chmod("{$config['FULL_PATH']}/cache/public_calendar.php",0666);

?>
