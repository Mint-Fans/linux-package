<?php

//	Script Version 7.5.7

if (!defined('UBB_MAIN_PROGRAM')) {
	exit;
}

$island = $smarty->fetch("island_shoutbox.tpl");



lock_and_write("{$config['FULL_PATH']}/cache/shoutbox.php",$island);

@chmod("{$config['FULL_PATH']}/cache/shoutbox.php",0666);

?>
