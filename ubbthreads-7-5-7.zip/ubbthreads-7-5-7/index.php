<?php
//	Ultimate Bulletin Board
//	Script Version 7.5.7
//
//	Copyright (C) 2012, 2013 UBB Systems, LLC
//
//	You may not distribute this program in any manner, modified or
//	otherwise, without the express, written consent from
//	UBB Systems, LLC.
//
//	You may make modifications, but only for your own use and
//	within the confines of the UBB License Agreement
//	(see our website for that at http://ubbcentral.com).
//
//	Note: If you modify ANY code within your UBB, we at UBB Systems
//  	cannot offer you support -- thus modify at your own peril :)

include("ubbthreads.php");
?>
