<?php
//	Script Version 7.5.7
include ("altertable.inc.php");

echo "<table border='0' width='70%' align='center'>";

// Check if we need to pick up at a certain step
$query = "
	SELECT LAST_ALTER_STEP
	FROM {$config['TABLE_PREFIX']}VERSION
";
$sth = $dbh->do_query($query);
list($thisstep) = $dbh->fetch_array($sth);

if (!$thisstep) {
	$thisstep = 1;
}

// How many steps in this altertable?
$totalsteps = 5;
for($i=$thisstep;$i<=$totalsteps;$i++) {
	$refresh = 0;
	if (!defined('DIDFAIL')) {
		ob_start();
		step_start($i);
		$whichstep = "";
		$whichstep = "alterstep$i";
		$refresh = $whichstep();
		if ($refresh && !$defined('DIDFAIL')) {
			$currenstep = $i;
			break;
		}

		if (function_exists('ob_flush')) {
			ob_flush();
		}
		else {
			ob_end_flush();
		}
	}
}

if (!defined('DIDFAIL')) {
	step_stop();
}

//  All database updates go here
function alterstep1() {
}

function alterstep2() {
	global $config;
	$query = "
		create table {$config['TABLE_PREFIX']}SUBSCRIPTIONS (
			GROUP_ID int unsigned not null primary key,
			SUBSCRIPTION_NAME varchar(255),
			SUBSCRIPTION_DESCRIPTION text,
			SUBSCRIPTION_BY_DONATION tinyint unsigned,
			SUBSCRIPTION_DONATION_AMOUNT decimal(8,2) not null default '0.00',
			SUBSCRIPTION_BY_TRIAL tinyint unsigned,
			SUBSCRIPTION_TRIAL_AMOUNT decimal(8,2) not null default '0.00',
			SUBSCRIPTION_TRIAL_DURATION int,
			SUBSCRIPTION_TRIAL_INTERVAL varchar(1),
			SUBSCRIPTION_BY_REGULAR tinyint unsigned,
			SUBSCRIPTION_REGULAR_AMOUNT decimal(8,2) not null default '0.00',
			SUBSCRIPTION_REGULAR_DURATION int,
			SUBSCRIPTION_REGULAR_INTERVAL varchar(1),
			SUBSCRIPTION_IS_RECURRING tinyint not null default '0',
			SUBSCRIPTION_REATTEMPT tinyint not null default '0'
		) ENGINE=MyISAM
	";
	$sth = do_query($query,"{$config['TABLE_PREFIX']}SUBSCRIPTIONS table created.");
}

function alterstep3() {
	global $config;
	$query = "
		create table {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA (
			SUBSCRIPTION_ID int not null primary key auto_increment,
			CUSTOM_ID varchar(255) not null default '',
			USER_ID int not null,
			GROUP_ID int not null,
			SUBSCRIPTION_IS_ACTIVE tinyint not null default '0',
			SUBSCRIPTION_METHOD varchar(25),
			SUBSCRIPTION_STATUS varchar(25),
			SUBSCRIPTION_START_DATE int not null,
			SUBSCRIPTION_END_DATE int not null,
			SUBSCRIPTION_PAYMENT varchar(25) not null default '',
			SUBSCRIPTION_CREATED int not null,
			INDEX user_ndx(USER_ID),
			UNIQUE custom_ndx (CUSTOM_ID),
			INDEX payment_ndx(SUBSCRIPTION_PAYMENT),
			INDEX end_ndx(SUBSCRIPTION_END_DATE),
			INDEX created_ndx(SUBSCRIPTION_CREATED)
		) ENGINE=MyISAM
	";
	do_query($query,"Adding new {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA table");
}


function alterstep4() {
	global $config;
	$query = "
		create table {$config['TABLE_PREFIX']}PAYPAL_DATA (
			LOG_ID int not null primary key auto_increment,
			SUBSCR_DATE varchar(255) not null default '',
			PAYMENT_DATE varchar(50) not null default '',
			SUBSCR_EFFECTIVE varchar(255) not null default '',
			ITEM_NAME varchar(255) default NULL,
			BUSINESS varchar(255) not null default '',
			ITEM_NUMBER varchar(50) default NULL,
			PAYMENT_STATUS varchar(15) not null default '',
			MC_GROSS varchar(6) not null default '',
			PAYMENT_CURRENCY varchar(10) not null default '',
			TXN_ID varchar(30) not null default '',
			RECEIVER_EMAIL varchar(255) not null default '',
			RECEIVER_ID varchar(50) not null default '',
			QUANTITY char(3) default null,
			NUM_CART_ITEMS varchar(10) not null default '',
			FIRST_NAME varchar(100) not null default '',
			LAST_NAME varchar(100) not null default '',
			PAYMENT_TYPE varchar(10) not null default '',
			PAYMENT_GROSS varchar(20) not null default '',
			PAYMENT_FEE varchar(20) not null default '',
			SETTLE_AMOUNT varchar(20) not null default '',
			MEMO varchar(255) default null,
			PAYER_EMAIL varchar(255) not null default '',
			TXN_TYPE varchar(20) not null default '',
			PAYER_STATUS varchar(50) not null default '',
			ADDRESS_STREET varchar(100) not null default '',
			ADDRESS_CITY varchar(50) not null default '',
			ADDRESS_STATE char(3) not null default '',
			ADDRESS_ZIP varchar(11) not null default '',
			ADDRESS_COUNTRY varchar(20) not null default '',
			ADDRESS_STATUS varchar(255) not null default '',
			TAX varchar(10) default null,
			OPTION_NAME1 varchar(255) not null default '',
			OPTION_SELECTION1 varchar(255) not null default '',
			OPTION_NAME2 varchar(255) not null default '',
			OPTION_SELECTION2 varchar(255) not null default '',
			INVOICE varchar(25) not null default '',
			CUSTOM_ID varchar(255) not null default '',
			NOTIFY_VERSION varchar(50) not null default '',
			VERIFY_SIGN varchar(255) not null default '',
			PAYER_BUSINESS_NAME varchar(255) not null default '',
			PAYER_ID varchar(50) not null default '',
			MC_CURRENCY varchar(5) not null default '',
			MC_FEE varchar(5) not null default '',
			EXCHANGE_RATE varchar(10) not null default '',
			SETTLE_CURRENCY varchar(10) not null default '',
			PARENT_TXN_ID varchar(50) not null default '',
			PENDING_REASON varchar(10) default null,
			REASON_CODE varchar(20) not null default '',
			SUBSCR_ID varchar(255) not null default '',
			PERIOD1 varchar(255) not null default '',
			PERIOD2 varchar(255) not null default '',
			PERIOD3 varchar(255) not null default '',
			AMOUNT1 varchar(255) not null default '',
			AMOUNT2 varchar(255) not null default '',
			AMOUNT3 varchar(255) not null default '',
			MC_AMOUNT1 varchar(255) not null default '',
			MC_AMOUNT2 varchar(255) not null default '',
			MC_AMOUNT3 varchar(255) not null default '',
			RECURRING varchar(255) not null default '',
			REATTEMPT varchar(255) not null default '',
			RETRY_AT varchar(255) not null default '',
			RECUR_TIMES varchar(255) not null default '',
			USERNAME varchar(255) not null default '',
			PASSWORD varchar(255) not null default '',
			INDEX txn_ndx(TXN_ID),
			INDEX custom_ndx(CUSTOM_ID)
		) ENGINE=MyISAM
	";
	$sth = do_query($query,"Creating {$config['TABLE_PREFIX']}PAYPAL_DATA table");

}


function alterstep5() {
	global $config;
	$query = "
		create table {$config['TABLE_PREFIX']}CHECK_DATA (
			PAYMENT_DATE int,
			LOG_ID int not null primary key auto_increment,
			CUSTOM_ID varchar(255) not null default '',
			CHECK_NUMBER varchar(255),
			PAYMENT_AMOUNT varchar(15),
			INDEX custom_ndx (CUSTOM_ID)
		) ENGINE=MyISAM
	";
	$sth = do_query($query,"Creating {$config['TABLE_PREFIX']}CHECK_DATA table");

}

?>
