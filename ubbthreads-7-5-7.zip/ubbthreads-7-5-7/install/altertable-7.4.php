<?php
//	Script Version 7.5.7
include ("altertable.inc.php");

echo "<table border='0' width='70%' align='center'>";

// Check if we need to pick up at a certain step
$query = "
	SELECT LAST_ALTER_STEP
	FROM {$config['TABLE_PREFIX']}VERSION
";
$sth = $dbh->do_query($query);
list($thisstep) = $dbh->fetch_array($sth);

if (!$thisstep) {
	$thisstep = 1;
}

// How many steps in this altertable?
$totalsteps = 8;
for($i=$thisstep;$i<=$totalsteps;$i++) {
	$refresh = 0;
	if (!defined('DIDFAIL')) {
		ob_start();
		step_start($i);
		$whichstep = "";
		$whichstep = "alterstep$i";
		$refresh = $whichstep();
		if ($refresh && !$defined('DIDFAIL')) {
			$currenstep = $i;
			break;
		}

		if (function_exists('ob_flush')) {
			ob_flush();
		}
		else {
			ob_end_flush();
		}
	}
}

if (!defined('DIDFAIL')) {
	step_stop();
}

//  All database updates go here
function alterstep1() {
}

function alterstep2() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}USER_PROFILE 
		add USER_UNVERIFIED_EMAIL varchar(50) not null default ''
	";
	$sth = do_query($query,"{$config['TABLE_PREFIX']}USER_PROFILE table altered.");
}

function alterstep3() {
	global $config;
	$query = "
		insert into {$config['TABLE_PREFIX']}PORTAL_BOXES
		(PORTAL_NAME,PORTAL_LAST_BUILD,PORTAL_CACHE,PORTAL_LOCK,PORTAL_CUSTOM)
		values
		('top_posters_30',0,300,0,0)
	";
	do_query($query,"Inserting Top Posters Last 30 Days into default Portal Islands.");
}

function alterstep4() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
		add DELETE_TOPICS tinyint not null default '0'
	";
	do_query($query,"Adding Delete Topics Permission to {$config['TABLE_PREFIX']}FORUM_PERMISSIONS table.");
}

function alterstep5() {
	global $config;
	$query = "
		insert into {$config['TABLE_PREFIX']}PERMISSION_LIST
		values
		('DELETE_TOPICS','1','0','forum','65.15')
	";
	do_query($query,"Adding Delete Topics Permission to {$config['TABLE_PREFIX']}PERMISSION_LIST table.");
}

function alterstep6() {
	global $config;
	$query = "
		select FORUM_ID,GROUP_ID,DELETE_ANY
		from {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
	";
	$sth = do_query($query,"Setting default Delete Topics permission to the same as the current Delete Any permission.");
	while(list($fid,$gid,$perm) = mysql_fetch_array($sth)) {
		$query = "
			update {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
			set DELETE_TOPICS = '$perm'
			where FORUM_ID = '$fid'
			and GROUP_ID = '$gid'
		";
		do_query($query);
	} // end while
}

function alterstep7() {
	global $config;
	$query = "
		insert into {$config['TABLE_PREFIX']}PORTAL_BOXES
		(PORTAL_NAME,PORTAL_LAST_BUILD,PORTAL_CACHE,PORTAL_LOCK,PORTAL_CUSTOM)
		values
		('featured_member',0,3600,0,0)
	";
	do_query($query,"Inserting Member of the Moment into default Portal Islands.");
}

function alterstep8() {
	global $config;
	$query = "
		insert into {$config['TABLE_PREFIX']}PORTAL_BOXES
		(PORTAL_NAME,PORTAL_LAST_BUILD,PORTAL_CACHE,PORTAL_LOCK,PORTAL_CUSTOM)
		values
		('birthdays',0,600,0,0)
	";
	do_query($query,"Inserting Today's Birthdays into default Portal Islands.");
}

?>
