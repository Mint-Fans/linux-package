<?php
//	Script Version 7.5.7
include ("altertable.inc.php");

echo "<table border='0' width='70%' align='center'>";

// Check if we need to pick up at a certain step
$query = "
	SELECT LAST_ALTER_STEP
	FROM {$config['TABLE_PREFIX']}VERSION
";
$sth = $dbh->do_query($query);
list($thisstep) = $dbh->fetch_array($sth);

if (!$thisstep) {
	$thisstep = 1;
}

// How many steps in this altertable?
$totalsteps = 12;
for($i=$thisstep;$i<=$totalsteps;$i++) {
	$refresh = 0;
	if (!defined('DIDFAIL')) {
		ob_start();
		step_start($i);
		$whichstep = "";
		$whichstep = "alterstep$i";
		$refresh = $whichstep();
		if ($refresh && !$defined('DIDFAIL')) {
			$currenstep = $i;
			break;
		}

		if (function_exists('ob_flush')) {
			ob_flush();
		}
		else {
			ob_end_flush();
		}
	}
}

if (!defined('DIDFAIL')) {
	step_stop();
}

//  All database updates go here
function alterstep1() {
}

function alterstep2() {
	global $config;
	$query = "
		create table {$config['TABLE_PREFIX']}PROFILE_COMMENTS (
			COMMENT_ID int(11) unsigned not null primary key auto_increment,
			PROFILE_ID int(9) unsigned not null,
			USER_ID int(9) unsigned not null,
			COMMENT_BODY text,
			COMMENT_DEFAULT_BODY text,
			COMMENT_MD5 varchar(32),
			COMMENT_TIME int(11) unsigned,
			INDEX profile_ndx (PROFILE_ID),
			INDEX user_ndx (USER_ID),
			INDEX md5_ndx (COMMENT_MD5)
		) ENGINE=MyISAM
	";
	$sth = do_query($query,"{$config['TABLE_PREFIX']}PROFILE_COMMENTS table created.");
}

function alterstep3() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}FORUMS
		add FORUM_SORT_FIELD varchar(10),
		add FORUM_SORT_DIR varchar(3)
	";
	do_query($query,"Inserting a new field into the Forums table to hold the default sort order.");
}

function alterstep4() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}SITE_PERMISSIONS
		add PM_LENGTH mediumint not null default '100'
	";
	do_query($query,"Adding a Max Private Topic Length Permission to {$config['TABLE_PREFIX']}SITE_PERMISSIONS table.");
}

function alterstep5() {
	global $config;
	$query = "
		insert into {$config['TABLE_PREFIX']}PERMISSION_LIST
		values
		('PM_LENGTH','1','0','site','3.15')
	";
	do_query($query,"Adding Max Private Topic Length Permission to {$config['TABLE_PREFIX']}PERMISSION_LIST table.");
}

function alterstep6() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}GROUPS
		add GROUP_IMAGE varchar(50)
	";
	$sth = do_query($query,"Adding a field to the {$config['TABLE_PREFIX']}GROUPS table store a group image.");
}

function alterstep7() {
	global $config;
	$query = "
		update {$config['TABLE_PREFIX']}GROUPS
		set GROUP_IMAGE = 'adm.gif'
		where GROUP_ID = '1'
	";
	$sth = do_query($query,"Setting the default group images");
	$query = "
		update {$config['TABLE_PREFIX']}GROUPS
		set GROUP_IMAGE = 'mod.gif'
		where GROUP_ID = '2'
	";
	$sth = do_query($query,"");
	$query = "
		update {$config['TABLE_PREFIX']}GROUPS
		set GROUP_IMAGE = 'mod.gif'
		where GROUP_ID = '3'
	";
	$sth = do_query($query,"");
}

function alterstep8() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}USER_PROFILE
		add USER_GROUP_IMAGES varchar(255),
		add USER_NOTIFY_MULTI tinyint(1) unsigned not null default '0'
	";
	do_query($query,"Adding a couple new fields to the {$config['TABLE_PREFIX']}USER_PROFILE table.");
}

function alterstep9() {
	global $config;
	$array[] = 1;
	$sarray = serialize($array);
	$query = "
		select USER_ID
		from {$config['TABLE_PREFIX']}USERS
		where USER_MEMBERSHIP_LEVEL = 'Administrator'
	";
	$sth = do_query($query,"Setting group image for Admins");
	while(list($uid) = mysql_fetch_array($sth)) {
		$query = "
			update {$config['TABLE_PREFIX']}USER_PROFILE
			set USER_GROUP_IMAGES = '$sarray'
			where USER_ID = '$uid'
		";
		do_query($query);
	} // end while
}

function alterstep10() {
	global $config;
	$array[] = 2;
	$sarray = serialize($array);
	$query = "
		select USER_ID
		from {$config['TABLE_PREFIX']}USERS
		where USER_MEMBERSHIP_LEVEL = 'GlobalModerator'
	";
	$sth = do_query($query,"Setting group image for Global Moderators");
	while(list($uid) = mysql_fetch_array($sth)) {
		$query = "
			update {$config['TABLE_PREFIX']}USER_PROFILE
			set USER_GROUP_IMAGES = '$sarray'
			where USER_ID = '$uid'
		";
		do_query($query);
	} // end while
}

function alterstep11() {
	global $config;
	$array[] = 3;
	$sarray = serialize($array);
	$query = "
		select USER_ID
		from {$config['TABLE_PREFIX']}USERS
		where USER_MEMBERSHIP_LEVEL = 'Moderator'
	";
	$sth = do_query($query,"Setting group image for Moderators");
	while(list($uid) = mysql_fetch_array($sth)) {
		$query = "
			update {$config['TABLE_PREFIX']}USER_PROFILE
			set USER_GROUP_IMAGES = '$sarray'
			where USER_ID = '$uid'
		";
		do_query($query);
	} // end while
}

function alterstep12() {
	global $config;
    $query = "
		insert into {$config['TABLE_PREFIX']}PORTAL_BOXES
		(PORTAL_NAME,PORTAL_LAST_BUILD,PORTAL_CACHE,PORTAL_LOCK,PORTAL_CUSTOM)
		values
		('popular_topics',0,300,0,0)
	";
	do_query($query,"Inserting Popular Topics into default Portal Islands.");
}


?>
