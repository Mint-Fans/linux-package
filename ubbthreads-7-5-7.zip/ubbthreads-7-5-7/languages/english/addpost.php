<?php
$ubbt_lang['NOIMAGES'] = "You must attach at least one image since this is a Gallery Forum.";
$ubbt_lang['FLOODCONTROL'] = "You can only make a post every %%FLOOD_LIMIT%% seconds.  Please try again once this time has expired.";
$ubbt_lang['NO_R_ANNOUNCE'] = "You may not make replies to announcements.";
$ubbt_lang['PARENT_DELETED'] = "The post you are replying to has been deleted.";
$ubbt_lang['POST_ICON'] = "Posting Icon";
$ubbt_lang['NAME_TAKEN'] = "The Display Name you are trying to post under has already registered and is being used by someone else.";
$ubbt_lang['BAD_UNAME'] = "You can only have alphanumeric characters in your username.  Special characters are not allowed because this allows users to spoof other usernames.  You may use the _ character to represent a space.";
$ubbt_lang['READ_PERM'] = "You do not have permission to post in this forum.";
$ubbt_lang['LOCKED'] = "Topic locked.";
$ubbt_lang['PREV_POST'] = "Preview Post";
$ubbt_lang['SUB_VOTE'] = "Submit Vote";
$ubbt_lang['POST_BODY'] = "The following is a preview of your post.  If everything looks ok then you can click 'Ok, submit' and your post will be entered.  If not then use the bottom form below to edit your post body.";
$ubbt_lang['EDIT_MORE'] = "Edit More";
$ubbt_lang['POST_TEXT'] = "Post";
$ubbt_lang['DO_EMAIL'] = "Email all replies to my real email address.";
$ubbt_lang['DO_PREVIEW'] = "I want to preview my post";
$ubbt_lang['CAN_ATTACH'] = "and/or attach a file";
$ubbt_lang['NO_DUPS'] = "Post already exists.";
$ubbt_lang['UNREGED_USER'] = "Unregistered";
$ubbt_lang['POST_ENTERED'] = "Your post has been submitted.";
$ubbt_lang['MOD_CONFIRM'] = "This forum is fully moderated so your post will not show up until an Administrator or Moderator reviews and approves it.";
$ubbt_lang['FORUM_RETURN'] = "Return to the forum.";
$ubbt_lang['VIEW_POST'] = "View your post.";
$ubbt_lang['MAX_QUOTE'] = "For readability, you can only quote messages %%QUOTE%% levels deep.  Please edit your message and try again.";
?>
