<?php
$ubbt_lang['DETAILS'] = "Choosing 'Add to' will add any of the members to the group that don't already belong to the group.  Choosing 'Remove from' will remove any of the members from the group that currently belong to the group.";
$ubbt_lang['CHANGE_GROUPS'] = "Make Changes";
$ubbt_lang['GROUP_NAME'] = "Group";
$ubbt_lang['MEMBER_OF'] = "Add to";
$ubbt_lang['NOT_MEMBER_OF'] = "Remove from";
$ubbt_lang['NO_CHANGE'] = "No change";
$ubbt_lang['UPDATE_GROUPS'] = "Update user groups";
?>
