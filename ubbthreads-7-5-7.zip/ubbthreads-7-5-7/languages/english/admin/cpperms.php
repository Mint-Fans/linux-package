<?php
$ubbt_lang['INSTRUCTIONS'] = "All fields require a numeric value.  Enter 0 to disable and 1 to enable, unless otherwise specified. If a user belongs to multiple groups, a <img src='{$config['BASE_URL']}/admin/image_files/up.gif' /> indicates the user will get the highest permission, a <img src='{$config['BASE_URL']}/admin/image_files/down.gif' /> indicates they will get the lowest.<br /><br />If you enter a -1 for any specific permission, then a user will not have that permission even if they belong to other groups that do have it set.";
$ubbt_lang['FULL_ACCESS'] = "Has full access to the control panel";
$ubbt_lang['FULL_ACCESS_1'] = "This allows users in this group to use everything in the control panel.";
$ubbt_lang['EDIT_USERS'] = "Can edit users";
$ubbt_lang['EDIT_USERS_1'] = "Users in this group will be able to edit other users via the control panel.";
$ubbt_lang['UPDATE_PERMS'] = "Update Control Panel Permissions";
$ubbt_lang['UPDATE_GROUP'] = "Update this Group's Permissions";
$ubbt_lang['CURRENT'] = "Currently editing permissions for:";
$ubbt_lang['SWITCH'] = "Switch";
$ubbt_lang['COPY'] = "Copy Permissions from:";
$ubbt_lang['DO_COPY'] = "Copy";
?>
