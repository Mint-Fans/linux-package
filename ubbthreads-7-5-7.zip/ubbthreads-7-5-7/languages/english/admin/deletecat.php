<?php
$ubbt_lang['NO_DELETE'] = "There are forums in this category.  You cannot delete this category until you move the forums into a different category.";
$ubbt_lang['CAT_CONFIRM'] = "The category has been deleted.";
$ubbt_lang['DELETE_CAT'] = "Delete Category";
$ubbt_lang['CONFIRM'] = "When you delete this category, all forums assigned to it will be reassigned to a different category.  Select this category now:";
$ubbt_lang['Y_DELETE'] = "Delete this category";
$ubbt_lang['NEW_CAT'] = "New category:";
$ubbt_lang['N_DELETE'] = "Do not delete this category";
?>
