<?php
$ubbt_lang['I_F_LOC'] = "the Posting Icons screen.";
$ubbt_lang['A_F_LOC'] = "the Avatars screen.";
$ubbt_lang['F_F_LOC'] = "the Forum Images screen.";
$ubbt_lang['N_F_LOC'] = "the News Images screen.";
$ubbt_lang['M_F_LOC'] = "the Mood screen.";
$ubbt_lang['NO_IMAGE'] = "You did not upload anything!";
$ubbt_lang['ICON_EXISTS'] = "There is already an icon in /images/{$style_array['icons']} with the name";
$ubbt_lang['NO_MOVE_I'] = "We could not move the icon into the /images/{$style_array['icons']} directory.  Please fix the permissions on this directory and try again.";
$ubbt_lang['I_ADDED'] = "Posting Icon added.";
$ubbt_lang['FIMAGE_EXISTS'] = "There is already an image in /images/{$style_array['forumimages']} with the name";
$ubbt_lang['NO_MOVE_F'] = "We could not move the icon into the /images/{$style_array['forumimages']} directory.  Please fix the permissions on this directory and try again.";
$ubbt_lang['F_ADDED'] = "Forum Image added.";
$ubbt_lang['AVATAR_EXISTS'] = "There is already an avatar in /images/{$style_array['avatars']} with the name";
$ubbt_lang['NO_MOVE_A'] = "We could not move the avatar into the /images/{$style_array['avatars']} directory.  Please fix the permissions on this directory and try again.";
$ubbt_lang['A_ADDED'] = "Avatar added.";
$ubbt_lang['NIMAGE_EXISTS'] = "There is already an image in /images/{$style_array['news']} with the name";
$ubbt_lang['NO_MOVE_N'] = "We could not move the icon into the /images/{$style_array['news']} directory.  Please fix the permissions on this directory and try again.";
$ubbt_lang['N_ADDED'] = "News Image added.";
$ubbt_lang['MIMAGE_EXISTS'] = "There is already an image in /images/{$style_array['mood']} with the name";
$ubbt_lang['NO_MOVE_M'] = "We could not move the icon into the /images/{$style_array['mood']} directory.  Please fix the permissions on this directory and try again.";
$ubbt_lang['M_ADDED'] = "Mood Image added.";
$ubbt_lang['NOT_IMAGE_FILE'] = "The selected file does not have a valid image extension (png, gif, jpg, jpeg).";
?>
