<?php
$ubbt_lang['F_LOC'] = "the Styles screen.";
$ubbt_lang['SKIN_EXISTS'] = "The chosen filename already exists.  Please choose a different filename.";
$ubbt_lang['NO_WRITE'] = "Unable to write the new stylesheet in /stylesheets.  Please fix the permissions on this directory and try again.";
$ubbt_lang['SKIN_ADDED'] = "New stylesheet has been added.  Before users may select this stylesheet, you must give it a name and activate it.";
?>
