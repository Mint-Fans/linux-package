<?php
$ubbt_lang['F_LOC'] = "the News Images screen.";
$ubbt_lang['NOREMOVE'] = "Unable to remove image.  Please check permissions on the files in your images/news directory and try again.";
$ubbt_lang['REMOVED'] = "News images have been updated.";
$ubbt_lang['NO_OVERW'] = " is not writeable by the web server.  Please fix the permissions on this file and try again.";
?>