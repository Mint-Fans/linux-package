<?php
$ubbt_lang['MOD_GRANT'] = "has given Moderator privileges to \$login (Display name '\$display')";
$ubbt_lang['YOUR_PERMS'] = "You have been granted Moderator privileges.  Please do not abuse this or these privileges may be revoked.";
$ubbt_lang['NEW_MOD'] = "New Moderator";
?>
