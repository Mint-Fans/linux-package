<?php
$ubbt_lang['NO_OPEN'] = "Unable to open config.inc.php for writing.  Please check permissions on the file.";
$ubbt_lang['NOW_CLOSED'] = "Your board is now closed.";
$ubbt_lang['NOW_OPEN'] = "Your board is now open.";
$ubbt_lang['F_LOC'] = "the Control Panel Home.";
?>
