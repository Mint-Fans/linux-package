<?php
$ubbt_lang['EMAIL_USERS'] = "Email members";
$ubbt_lang['OPTIONS'] = "Available Email Options:";
$ubbt_lang['EXPORT'] = "Export list of addresses.";
$ubbt_lang['SEND'] = "Send mail directly to members.";
$ubbt_lang['GENERATE'] = "Generate Emails";
?>