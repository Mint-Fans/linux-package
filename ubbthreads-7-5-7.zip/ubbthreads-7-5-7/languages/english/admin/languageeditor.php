<?php
$ubbt_lang['LANG_EDIT'] = "Language Editor";
$ubbt_lang['EDIT_SEL'] = "Edit Selected Language File";
$ubbt_lang['SEARCH_LEN'] = "Your search string must be at least 3 characters in length.";
$ubbt_lang['NO_MATCHES'] = "No matches found.";
$ubbt_lang['EDIT'] = "Edit";
$ubbt_lang['KEY'] = "Key";
$ubbt_lang['STRING'] = "String";
$ubbt_lang['FILE'] = "File";
?>