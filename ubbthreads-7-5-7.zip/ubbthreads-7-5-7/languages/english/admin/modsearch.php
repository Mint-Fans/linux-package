<?php
$ubbt_lang['TITLE'] = "Moderator Search for";
$ubbt_lang['PROFILE'] = "Profile";
$ubbt_lang['ADD'] = "Add";
$ubbt_lang['CLOSE'] = "Close Window";
$ubbt_lang['FIND_MORE'] = "Find More Profiles";
?>
