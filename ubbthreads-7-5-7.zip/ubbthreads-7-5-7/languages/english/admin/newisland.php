<?php
$ubbt_lang['ADD_ISLAND'] = "Add Content Island";
$ubbt_lang['SELECT'] = "Select New Island Type:";
$ubbt_lang['NEWPOSTS'] = "New posts in one or all forums";
$ubbt_lang['NEWTOPICS'] = "New topics in one or all forums";
$ubbt_lang['VISITORS'] = "Recent visitors for the board";
$ubbt_lang['NEWUSERS'] = "Latest registered and approved users";
$ubbt_lang['NEXT'] = "Next >>";
?>