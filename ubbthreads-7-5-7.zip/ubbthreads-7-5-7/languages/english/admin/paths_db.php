<?php
$ubbt_lang['DB_P_URL'] = "DB, Paths & URLs";
$ubbt_lang['DATABASE_CONFIG'] = "Database Configuration";
$ubbt_lang['PATH_URL'] = "Paths & URLs";
$ubbt_lang['DBSERVER'] = "Database Server Name:";
$ubbt_lang['DBNAME'] = "Database Name:";
$ubbt_lang['DBUSER'] = "Database Username:";
$ubbt_lang['DBPASS'] = "Database Password:";
$ubbt_lang['TBPREFIX'] = "Table Prefix:";
$ubbt_lang['TBPREFIX_1'] = "The prefix was determined during initial installation and may not be changed.";
$ubbt_lang['PERSISTENT'] = "Use Persistent Connections?";
$ubbt_lang['PERSISTENT_1'] = "Only enable after speaking to your web hosting provider and ensuring that they allow PERSISTENT_DB_CONNECTION connections.";
$ubbt_lang['URL'] = "Full URL to Main Directory:";
$ubbt_lang['PATH'] = "Absolute PATH to Main Directory:";
$ubbt_lang['BASE'] = "Relative URL to Main Directory:";
$ubbt_lang['UPDATE'] = "Update Settings";
$ubbt_lang['IMAGE_MAGICK'] = "ImageMagick Settings";
$ubbt_lang['IMAGE_MAGICK_DESC'] = "If you have Imagemagick installed on the server and you fill in the paths below you will have the option to use Imagemagick for some of the image processing functions.";
$ubbt_lang['CONVERT_PATH'] = "Path to Convert:";
$ubbt_lang['MOGRIFY_PATH'] = "Path to Mogrify:";

?>
