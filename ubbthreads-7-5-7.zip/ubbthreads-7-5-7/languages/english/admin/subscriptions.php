<?php
$ubbt_lang['SUB_SETUP'] = "Subscription Groups";
$ubbt_lang['NO_CUSTOM_GROUPS'] = "You do not have any custom groups configured.  You'll need to add a custom group before you can configure any subscriptions.";
$ubbt_lang['SUB_NAME'] = "Subscription Name";
$ubbt_lang['GROUP_NAME'] = "Group Name";
$ubbt_lang['SUB_NUM'] = "Subscribers";
$ubbt_lang['SUB_EDIT'] = "Edit";
$ubbt_lang['SUB_ACTIVE'] = "Is Active?";
?>
