<?php
$ubbt_lang['NO_EDIT'] = "You do not have permission to delete this event.";
$ubbt_lang['HEAD'] = "Event deleted.";
$ubbt_lang['BODY'] = "The event has been deleted from the calendar.  You will be returned to the calendar in a moment.";
?>
