<?php
$ubbt_lang['NO_FORUM'] = "No forum was selected to which to move this topic.";
$ubbt_lang['NO_CAT'] = "You need to choose a forum, not a category.";
$ubbt_lang['UNAPPROVED'] = "You cannot move a branch of a topic that has unapproved posts in it.";
$ubbt_lang['NONUM'] = "Unfortunately we didn't receive a post number to be moved.  Please try again.";
$ubbt_lang['NOMERGE'] = "We cannot find the post # that you specified to merge this topic with.";
$ubbt_lang['PM_MOVE_SUBJ'] = "Your thread has been moved";
$ubbt_lang['PM_MERGE_SUBJ'] = "Your thread has been merged";
$ubbt_lang['PM_BODY'] = "You can now find your thread titled: '%%SUBJECT%%' [<a href=\"%%NEW_ADDY%%\"> Here </a>]%%IF_REASON%%";
$ubbt_lang['PM_REASON'] = "<br /><br />The reason for the change is:<br /><br /> %%REASON%%";
?>