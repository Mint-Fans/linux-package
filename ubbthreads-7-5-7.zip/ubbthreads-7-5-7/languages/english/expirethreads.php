<?php
$ubbt_lang['DELETE_THREAD'] = "Delete this topic.";
$ubbt_lang['PEDIT_DELETE'] = "Delete this topic.";
$ubbt_lang['DELETE_CONF'] = "If you are sure you want to do this, click the button below.";
$ubbt_lang['YES_DELETE'] = "Yes, I want to delete this post.";
?>
