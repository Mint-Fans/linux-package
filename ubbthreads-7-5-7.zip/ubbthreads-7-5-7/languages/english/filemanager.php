<?php
$ubbt_lang['FILE_MANAGE'] = "File Manager";
$ubbt_lang['NO_FILES'] = "You currently have no file for this post";
$ubbt_lang['VALID_ID'] = "This window doesn't have a valid id.  Please close this window and reopen";
$ubbt_lang['ADD_FILE'] = "Add file";
$ubbt_lang['REMOVE_FILE'] = "Remove";
$ubbt_lang['DONE'] = "Done adding files";
$ubbt_lang['FILE_TOO_BIG'] = "Files can be no larger than %%FILE_SIZE%% bytes.";
$ubbt_lang['FILESALLOWED'] = "The files you may upload must have the following extension: ";
$ubbt_lang['DESCRIPTION'] = "File Caption: (255 characters max)";
$ubbt_lang['GALLERYFILES'] = "You may only attach .gif, .jpg, .jpeg or .png images.";
$ubbt_lang['PIC_TOO_BIG'] = "Images can be no larger than %%PIC_SIZE%% bytes.";
$ubbt_lang['MAX_ATTACH'] = "You can attach %%NUM_FILE%% files.";
$ubbt_lang['MAX_PHOTO'] = "You can attach %%NUM_PHOTO%% photos.";
$ubbt_lang['MAX_SIZE'] = "Max. file size is %%FILE_SIZE%%.";
$ubbt_lang['UNLIMITED'] = "unlimited";
$ubbt_lang['TOO_MANY'] = "You have exceeded your limit of %%NUM_ATTACH%% attachments.";
$ubbt_lang['MALFORMED_PIC'] = "The content of the uploaded file does not to appear to be a valid image.";
$ubbt_lang['INI_TOO_BIG'] = "It looks as if your file attachment size exceeded the max size of %%FILE_SIZE%%.";
$ubbt_lang['NO_FILE'] = "No file selected for upload.";
?>
