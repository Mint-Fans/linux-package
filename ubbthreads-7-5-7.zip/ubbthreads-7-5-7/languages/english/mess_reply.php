<?php
$ubbt_lang['EDIT_MORE'] = "Edit more";
$ubbt_lang['PREVIEW_MESS'] = "The following is a preview of your message.  If everything looks ok then you can click 'Continue' and your message will be sent.  If not, then use the bottom form below to edit more.";
$ubbt_lang['MESS_PREVIEW'] = "I want to preview my message.";
$ubbt_lang['NO_PERM'] = "You do not have permission to access this topic.";
$ubbt_lang['PRIV_BODY'] = "You have received a private message at %%BOARD_TITLE%%. The contents of this private message are:\n\n---\n%%RAW_BODY%%\n---\n\nYou can reply to this message at the following link:\n\n%%PM_ADDY%%";
$ubbt_lang['TOO_LONG'] = "This topic has reached it's maximum length of %%TOTAL%% posts.  You cannot add any more posts to this topic.";
?>
