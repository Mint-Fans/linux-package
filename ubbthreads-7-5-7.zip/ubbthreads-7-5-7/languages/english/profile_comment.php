<?php
$ubbt_lang['NEW_COMMENT'] = "New profile comment";
$ubbt_lang['NEW_COMMENT_BODY'] = "%%USER%% has added a new comment to your profile.  Visit your profile to view it.<br /><br />%%LINK%%";
$ubbt_lang['YOUR_PROFILE'] = "Your Profile";
?>
