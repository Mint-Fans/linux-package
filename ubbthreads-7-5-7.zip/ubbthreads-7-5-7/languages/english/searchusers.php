<?php
$ubbt_lang['HEADER'] = "Search Results";
$ubbt_lang['NO_RESULTS'] = "We couldn't find any Display Names containing: ";
$ubbt_lang['TOO_MANY'] = "Please use a more specific search term.  We found over 100 entries containing: ";
$ubbt_lang['MORE_LETTERS'] = "Your search term must be at least 3 characters long.";
$ubbt_lang['ADD'] = "Add";
$ubbt_lang['DISPLAY_NAME'] = "Display Name";
$ubbt_lang['ADD_BUTTON'] = "Add To Watched Users";
?>
