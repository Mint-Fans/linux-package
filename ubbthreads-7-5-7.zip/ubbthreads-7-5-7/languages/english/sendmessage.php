<?php
$ubbt_lang['IGNORING_YOU'] = "This user is ignoring you.  You cannot send them a message.";
$ubbt_lang['TEXT_DELETE'] = "Delete";
$ubbt_lang['NO_PRIVATE'] = "This user is not accepting private messages.";
$ubbt_lang['NO_RECORD'] = "We have no record for the user %%USERNAME%%";
$ubbt_lang['MESS_PREV'] = "Preview private message to";
$ubbt_lang['PREVIEW_MESS'] = "The following is a preview of your message.";
$ubbt_lang['EDIT_MORE'] = "Edit more.";
$ubbt_lang['SEND_TO'] = "Send to";
$ubbt_lang['MESSAGE'] = "Message";
$ubbt_lang['PREVIEW'] = "Preview";
$ubbt_lang['OVERLIMIT'] = "This user is over their Private Topic limit.";
$ubbt_lang['NOTFOUND'] = "User not found";
$ubbt_lang['DUH'] = "You don't need to add yourself!";
$ubbt_lang['TOO_MANY'] = "You can only include %%MAX_IN_PM%% in a private topic.";
$ubbt_lang['PRIV_BODY'] = "You have received a private message at %%BOARD_TITLE%%. The contents of this private message are:\n\n---\n%%RAW_BODY%%\n---\n\nYou can reply to this message at the following link:\n\n%%PM_ADDY%%";
?>
