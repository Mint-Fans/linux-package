<?php
$ubbt_lang['IGNORING_YOU'] = "This user is ignoring you.  You cannot send them a message.";
$ubbt_lang['NOPRIVS'] = "Private messages are disabled.";
$ubbt_lang['MESS_PREVIEW'] = "I want to preview my message.";
$ubbt_lang['ADD_BOOK'] = "Add to UBB Buddies";
$ubbt_lang['NO_LOGGED'] = "You must be logged in to send a private message.";
$ubbt_lang['NO_PRIVATE'] = "This user is not accepting private messages.";
$ubbt_lang['PRIV_BODY2'] = "You may invite up to %%MAX_IN_PM%% people to a private topic.  Click the 'Add' button to add each person.";
$ubbt_lang['TEXT_DELETE'] = "Delete";
$ubbt_lang['SEND_TO'] = "Send to";
$ubbt_lang['OPEN_ADDRESS'] = " or Buddy list";
$ubbt_lang['MESSAGE'] = "Message";
$ubbt_lang['ADD_RECIP'] = "Add Recipient";
$ubbt_lang['ADD'] = "Add";
$ubbt_lang['ALREADY_ADDED'] = "This recipient has already been added.";
$ubbt_lang['TOO_MANY'] = "You have reached your limit of private message participants.";
$ubbt_lang['NOT_FOUND'] = "We could not find the user: ";
$ubbt_lang['OVERLIMIT'] = "%%USER%% is over their Private Topic limit.";
$ubbt_lang['NOTFOUND'] = "User not found";
?>
