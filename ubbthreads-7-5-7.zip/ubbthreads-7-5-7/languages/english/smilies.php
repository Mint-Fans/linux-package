<?php
$ubbt_lang['SMILIES'] = "Smilies";
?>