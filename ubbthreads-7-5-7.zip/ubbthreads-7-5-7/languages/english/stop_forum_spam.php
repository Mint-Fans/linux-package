<?php
$ubbt_lang['SFS_DETECTED'] = "Spammer Detected";
$ubbt_lang['SFS_DETECTED_EMAIL'] = "Your Email address is currently listed in the <a href=\"http://stopforumspam.com/\" target=\"_blank\">Stop Forum Spam</a> database and as such your account cannot be registered.  To proceed you'll need to <a href=\"http://stopforumspam.com/contact\" target=\"_blank\">contact them</a> to clear yourself from their database.";
$ubbt_lang['SFS_DETECTED_INFO_1'] = "At this time your registration can not be continued.  Your IP address has been flagged as that of a known spammer/spambot via the ";
$ubbt_lang['SFS_DETECTED_INFO_2'] = " database.  To proceed you'll need to <a href=\"http://stopforumspam.com/contact\" target=\"_blank\">contact them</a> to clear yourself from their database.";
$ubbt_lang['SFS_ERROR_TITLE'] = "Stop Forum Spam Error";
$ubbt_lang['SFS_ERROR_CONNECTION'] = "Cannot Connect to the Stop Forum Spam API.";
?>