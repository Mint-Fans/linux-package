<?php
$ubbt_lang['UNABLE'] = "We were unable to find the account to verify.  If this account was registered over 24 hours ago then you will need to re-register, as it has been deleted.  Otherwise, please check your confirmation email and make sure you followed the link correctly.";
$ubbt_lang['NEEDAPPROVAL'] = "Thank you for verifying your email. Your account needs to be approved by an Administrator before you can log in.  You will receive an email once this has been done.";
$ubbt_lang['VERIFIED'] = "Email verified.";
$ubbt_lang['NORMAL'] = "Thank you for verifying your email.  Your account has been activated and you may now log in.";
$ubbt_lang['NEWREGBODY'] = "Hello,\n\nA new user has registered at %%BOARD_TITLE%%. Here are the details of the user's profile:\n\n Email Address: %%EMAIL_ADDY%%\n Display Name: %%DISPLAY_NAME%%\n IP Address: %%IP_ADDY%%\n\nTo view the entire profile or approve this account, please visit:\n\n%%MANAGE_URL%%";
$ubbt_lang['EMAIL_VERIFIED'] = "Your %%EMAIL%% email address has been verified.  We will use this for all future emails sent to you.";
$ubbt_lang['NO_EMAIL'] = "We could find no pending email verification for your account.";
?>
