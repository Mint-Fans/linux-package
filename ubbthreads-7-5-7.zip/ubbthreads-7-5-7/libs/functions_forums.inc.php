<?php

//	Script Version 7.5.7

/**
 * Recieves a list of forums and returns everything
 * needed to display the forum on cfrm or postlist
 */

function &get_forum_display_info($forums, $type = "cfrm", $online = null) {
	global $config, $dbh, $ubbt_lang, $in, $userob, $tree, $user, $html;
	
	$subject_max_length = 26;

	$tmp = array_get($_SESSION, 'watch_lists', '');
	if (is_array($tmp)) $_SESSION['watch_lists'] = $tmp = '';
	
	$watch_lists = @unserialize($tmp);
	if (!isset($watch_lists['f'])) $watch_lists['f'] = array();

	if (!isset($_SESSION['forumvisit']['visit']) || !is_array($_SESSION['forumvisit']['visit']) || (!sizeof($_SESSION['forumvisit']['visit']))) {
		$_SESSION['forumvisit']['lastonline'] = $user['USER_LAST_VISIT_TIME'];
		if ($user['USER_ID']) {
			$query = "
				SELECT LAST_VISIT_TIME,FORUM_ID
				FROM {$config['TABLE_PREFIX']}FORUM_LAST_VISIT
				WHERE USER_ID = ?
			";
			$sth = $dbh->do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
			while($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
				$_SESSION['forumvisit']['visit'][$result['FORUM_ID']] = $result['LAST_VISIT_TIME'];
			}
		}
	}

	$clause = '';
	$query_vars = array();
	if ($type == "cfrm" && $in['c'] > 0) {
		$clause = 'WHERE CATEGORY_ID = ?';
		$query_vars[] = $in['c'];
	}
	
	if ($type == "postlist") {
		$clause = "WHERE FORUM_PARENT <> '0'";
	}
	
	$forum_query = "
		SELECT	FORUM_TITLE, FORUM_DESCRIPTION, FORUM_ID, FORUM_POSTS, FORUM_LAST_POST_TIME,
			FORUM_TOPICS, FORUM_SORT_ORDER, FORUM_LAST_POSTER_ID,
			FORUM_LAST_TOPIC_ID, FORUM_LAST_POST_ID, FORUM_LAST_POSTER_NAME, FORUM_LAST_POST_SUBJECT,
			FORUM_LAST_POST_ICON, FORUM_IMAGE, CATEGORY_ID, FORUM_PARENT, FORUM_IS_TEASER,
			FORUM_IS_GALLERY, FORUM_IS_RSS, FORUM_IS_ACTIVE
		FROM	{$config['TABLE_PREFIX']}FORUMS
			$clause
		ORDER BY CATEGORY_ID, FORUM_SORT_ORDER
	";

	// Hold information on every active forum
	$forum_data = array();	
	$forums_to_show = array();

	if (is_array($forums)) {
		$forums_to_show = $forums;
	}
	
	$sth = $dbh->do_placeholder_query($forum_query, $query_vars, __LINE__, __FILE__);
	
	// Map FORUM_ID to index in the $forum_data array.
	$f_index = array();
	$i = 0;
	while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
		$forum_data[$i] = $result;
		$f_index["{$result['FORUM_ID']}"] = $i;
		
		// If passed a wildcard, build the forum id list ourselves
		if ($forums == "*") {
			$forums_to_show[] = $result['FORUM_ID'];
		}
		$i++;
	}
	$dbh->finish_sth($sth);

	// Found out who's online
	$cutoff = $html->get_date() - ($config['ONLINE_TIME'] * 60);
	$query = "
		SELECT	ONLINE_BROWSING_FORUM, COUNT(*) AS COUNT, ONLINE_USER_TYPE
		FROM	{$config['TABLE_PREFIX']}ONLINE
		WHERE	ONLINE_LAST_ACTIVITY > ?
		GROUP BY ONLINE_BROWSING_FORUM, ONLINE_USER_TYPE
	";
	
	$online_local = 0;
	$online_per_forum = array();
	
	$sth = $dbh->do_placeholder_query($query, array($cutoff), __LINE__, __FILE__);
	while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
		$online_local += $result['COUNT'];
		$online_per_forum["{$result['ONLINE_BROWSING_FORUM']}"] = array_get($online_per_forum, "{$result['ONLINE_BROWSING_FORUM']}", 0) + $result['COUNT'];
	}

	if ($online !== null) {
		$online = $online_local;
	}
	
	// Grab moderators
	$moderators = array();
	if ($config['LIST_MODERATORS'] && $forums_to_show) {
		$query = "
			SELECT	m.USER_ID, m.FORUM_ID, u.USER_DISPLAY_NAME
			FROM	{$config['TABLE_PREFIX']}MODERATORS as m
			LEFT JOIN {$config['TABLE_PREFIX']}USERS as u ON u.USER_ID = m.USER_ID
			WHERE	FORUM_ID in ( ? )
			ORDER BY USER_DISPLAY_NAME
		";
		
		$sth = $dbh->do_placeholder_query($query, array($forums_to_show), __LINE__, __FILE__);
		$temp = array();
		while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
			// Just in case there are dups in the moderator table
			if (in_array($result['USER_ID'],$temp[$result['FORUM_ID']])) {
				continue;
			}
			$temp[$result['FORUM_ID']][] = $result['USER_ID'];
			if (!isset($moderators["{$result['FORUM_ID']}"])) {
				$moderators["{$result['FORUM_ID']}"] = array();
			}
			
			$moderators["{$result['FORUM_ID']}"][] = array(
				'USER_ID' => $result['USER_ID'],
				'USER_DISPLAY_NAME' => $result['USER_DISPLAY_NAME'],
			);
		}
		$dbh->finish_sth($sth);
	}
	
	$i = 0;
	$returndata = array();
	foreach ($forums_to_show as $f) {
		if ($forum_data[$f_index["$f"]]['FORUM_PARENT'] && $type == "cfrm") continue;
		if (!$userob->check_access("forum","SEE_FORUM",$f) && !$forum_data[$f_index["$f"]]['FORUM_IS_TEASER']) continue;
		if (!$forum_data[$f_index["$f"]]['FORUM_IS_ACTIVE']) continue;

		$returndata[$i] = $forum_data[$f_index["$f"]];
		
		// Get all children, grandchildren, etc of this forum.
		$subforums = get_subforums($f, array(), $forum_data, $f_index);

		// Create subforum listing
		// This is just of immediate children
		$returndata[$i]['subforum_links'] = array();
		if (isset($tree['kids'][$f]) && is_array($tree['kids'][$f])) {
			foreach ($tree['kids'][$f] as $sub_id) {
				if (!$userob->check_access("forum","SEE_FORUM",$sub_id) && !$forum_data[$f_index["$sub_id"]]['FORUM_IS_TEASER']) continue;
				if (!$forum_data[$f_index["$sub_id"]]['FORUM_IS_ACTIVE']) continue;

				$title = $forum_data[$f_index["$sub_id"]]['FORUM_TITLE'];

				$returndata[$i]['subforum_links']["$sub_id"] = array('', 0);
				$returndata[$i]['subforum_links']["$sub_id"][0] = sprintf('<a href="%s">%s</a>', make_ubb_url("ubb=postlist&Board=$sub_id&page=1", $title, false), $title);
			}
		}
		
		// Loop over subforums, figuring out the latest post, and adding up the total posts & topics
		$returndata[$i]['FORUM_LAST_MODE'] = $returndata[$i]['FORUM_IS_GALLERY'];
		
		// We mark as new if the forum contains a new post.
		$lastvisit = 0;
		$icon_is_new = false;
		if (isset($_SESSION['forumvisit']['visit']["$f"])) {
			$lastvisit = $_SESSION['forumvisit']['visit']["$f"];
		}
		
		if ($lastvisit < $returndata[$i]['FORUM_LAST_POST_TIME']) {
			$icon_is_new = true;
		}	
		
		$returndata[$i]['FORUM_LAST_MODE'] = $returndata[$i]['FORUM_IS_GALLERY'];
		
		$new_post_query = "";
		$new_post_times = array();
		if ($config['NEW_COUNT'] && $userob->is_logged_in) {
			// This is how I'll accumulate the count of the new posts
			$new_post_query = "
				SELECT	COUNT(p.POST_ID) AS POSTS, SUM(p.POST_IS_TOPIC) AS TOPICS, t.FORUM_ID
				FROM	{$config['TABLE_PREFIX']}POSTS as p,
					{$config['TABLE_PREFIX']}TOPICS as t
				WHERE	(t.TOPIC_ID = p.TOPIC_ID) AND p.POST_IS_APPROVED = 1
					AND (0
			";
			
			if ($lastvisit < $returndata[$i]['FORUM_LAST_POST_TIME']) {
				$new_post_times[] = $f;
				$new_post_times[] = $lastvisit;	
				$new_post_query .= ' OR (t.FORUM_ID = ? AND p.POST_POSTED_TIME > ?)';
			}
		}
		
		if ($subforums) {
			foreach ($subforums as $subforum_id) {
				$subforum =& $forum_data[$f_index["$subforum_id"]];
				if ($subforum['FORUM_LAST_POST_TIME'] > $returndata[$i]['FORUM_LAST_POST_TIME']) {
					// The subforum has a more recent post, so steal it's identity
					$returndata[$i]['FORUM_LAST_POST_TIME'] = $subforum['FORUM_LAST_POST_TIME'];
					$returndata[$i]['FORUM_LAST_POST_ID'] = $subforum['FORUM_LAST_POST_ID'];
					$returndata[$i]['FORUM_LAST_TOPIC_ID'] = $subforum['FORUM_LAST_TOPIC_ID'];
					$returndata[$i]['FORUM_LAST_POSTER_ID'] = $subforum['FORUM_LAST_POSTER_ID'];
					$returndata[$i]['FORUM_LAST_POSTER_NAME'] = $subforum['FORUM_LAST_POSTER_NAME'];
					$returndata[$i]['FORUM_LAST_POST_SUBJECT'] = $subforum['FORUM_LAST_POST_SUBJECT'];
					$returndata[$i]['FORUM_LAST_POST_ICON'] = $subforum['FORUM_LAST_POST_ICON'];
				
					// Make sure we treat the link as a gallery
					$returndata[$i]['FORUM_LAST_MODE'] = $subforum['FORUM_IS_GALLERY'];
				}
				
				// We also mark as new if a subforum contains a new post.
				$lastvisit = 0;
				if (isset($_SESSION['forumvisit']['visit']["$subforum_id"])) {
					$lastvisit = $_SESSION['forumvisit']['visit']["$subforum_id"];
				}
				
				if ($lastvisit < $subforum['FORUM_LAST_POST_TIME']) {
					$icon_is_new = true;
				}
				
				if ($config['NEW_COUNT'] && $userob->is_logged_in && $lastvisit < $subforum['FORUM_LAST_POST_TIME']) {
					$new_post_times[] = $subforum_id;
					$new_post_times[] = $lastvisit;
					$new_post_query .= ' OR (t.FORUM_ID = ? AND p.POST_POSTED_TIME > ?)';
				}
				
				$returndata[$i]['FORUM_POSTS'] += $subforum['FORUM_POSTS'];
				$returndata[$i]['FORUM_TOPICS'] += $subforum['FORUM_TOPICS'];
			}
		}
		
		$returndata[$i]['newreplies'] = 0;
		$returndata[$i]['newtopics'] = 0;
		
		if ($config['NEW_COUNT'] && $icon_is_new && $userob->is_logged_in) {
			$new_post_query .= ') GROUP BY t.FORUM_ID';

			$sth = $dbh->do_placeholder_query($new_post_query, $new_post_times, __LINE__, __FILE__);
			
			while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
				if ($result['TOPICS'] === null) $result['TOPICS'] = 0;
			
				if (isset($tree['tree'][$result['FORUM_ID']]) && is_array($tree['tree'][$result['FORUM_ID']])) {
					foreach ($tree['tree'][$result['FORUM_ID']] as $v) {
						if (isset($returndata[$i]['subforum_links']["$v"])) {
							$returndata[$i]['subforum_links']["$v"][1] += $result['POSTS'];
						}
					}
				}
				
				if (isset($returndata[$i]['subforum_links']["{$result['FORUM_ID']}"])) {
					$returndata[$i]['subforum_links']["{$result['FORUM_ID']}"][1] += $result['POSTS'];
				}
				
				$returndata[$i]['newreplies'] += $result['POSTS'];
				$returndata[$i]['newtopics'] += $result['TOPICS'];
			}
			$dbh->finish_sth($sth);
		}
		
		// Now we just build the name of the icon
		$returndata[$i]['BOARDFOLDER'] = "newposts.gif";
		if ($returndata[$i]['FORUM_IS_GALLERY']) {
			$returndata[$i]['BOARDFOLDER'] = "newimages.gif";
		}
		
		$returndata[$i]['DOUBLECLICK'] = "";
		$returndata[$i]['IS_NEW'] = $icon_is_new;
		if ($icon_is_new == false) {
			$returndata[$i]['BOARDFOLDER'] = "no" . $returndata[$i]['BOARDFOLDER'];
		} else {
			// Add the code to mark a forum as read by double clicking the icon
			$returndata[$i]['DOUBLECLICK'] = sprintf('ondblclick="markRead(\'%s\',\'%s\')" style="cursor: pointer" title="%s" ', $f, "no" . $returndata[$i]['BOARDFOLDER'], $ubbt_lang['DOUBLE_CLICK']);
		}
		
		// Does this forum contain any posts? If not, mark it as new.
		$returndata[$i]['FORUM_LAST_POST_TIME_ORIG'] = $returndata[$i]['FORUM_LAST_POST_TIME'];
		if (!$returndata[$i]['FORUM_LAST_POST_TIME']) {
			$returndata[$i]['FORUM_LAST_POST_TIME'] = $ubbt_lang['NEW_BOARD'];
		} else {
			$returndata[$i]['FORUM_LAST_POST_TIME'] = $html->convert_time($returndata[$i]['FORUM_LAST_POST_TIME'], $user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT']);
		}

		// Figure out which icon we show
		if (!$returndata[$i]['FORUM_LAST_POST_ICON']) {
			$returndata[$i]['FORUM_LAST_POST_ICON'] = "blank.gif";
		}
		
		if ($returndata[$i]['FORUM_LAST_MODE']) {
			$returndata[$i]['FORUM_LAST_POST_ICON'] = "image.gif";
		}
		
		// Are we watching this forum?
		$returndata[$i]['FORUM_WATCHED'] = false;
		if (in_array($f, $watch_lists['f'])) {
			$returndata[$i]['FORUM_WATCHED'] = true;
		}
		
		// Create link to the new post
		$returndata[$i]['FORUM_LAST_LINK'] = '';
		$returndata[$i]['FORUM_LAST_POSTER'] = '';
		
		if (!$config['SHOW_TEASER_LATEST_POST'] && ($returndata[$i]['FORUM_IS_TEASER'] && !$userob->check_access("forum","SEE_FORUM",$f))) {
			$returndata[$i]['FORUM_LAST_LINK'] = $ubbt_lang['TEASER_LATEST_POST'];
		} else {
			if ($returndata[$i]['FORUM_LAST_POST_SUBJECT']) {
				$returndata[$i]['FORUM_LAST_POST_SUBJECT_ORIG'] = $returndata[$i]['FORUM_LAST_POST_SUBJECT'];
				if (strlen($returndata[$i]['FORUM_LAST_POST_SUBJECT']) > $subject_max_length) {
					$returndata[$i]['FORUM_LAST_POST_SUBJECT'] = substr($returndata[$i]['FORUM_LAST_POST_SUBJECT'], 0, $subject_max_length);
					$returndata[$i]['FORUM_LAST_POST_SUBJECT'] = preg_replace('#&[^;]*$#', '', $returndata[$i]['FORUM_LAST_POST_SUBJECT']);
					$returndata[$i]['FORUM_LAST_POST_SUBJECT'] .= "...";
				}
				
				// Now we figure out if we go to showflat, showthreaded, or showgallery.
				$mode = '';
				if ($returndata[$i]['FORUM_LAST_MODE']) {
					$mode = 'showgallery';
				} else {
					if ($user['USER_TOPIC_VIEW_TYPE']) {
						$mode = "show" . $user['USER_TOPIC_VIEW_TYPE'];
					} else {
						$mode = "show" . $config['TOPIC_DISPLAY_STYLE'];
					} // end if
				}
				
				// Make sure to escape the " in the subject.
				// ONLY the "
				$returndata[$i]['FORUM_LAST_LINK'] = sprintf('<a href="%s" title="%s">%s</a>', make_ubb_url("ubb=$mode&Number={$returndata[$i]['FORUM_LAST_POST_ID']}#Post{$returndata[$i]['FORUM_LAST_POST_ID']}", $returndata[$i]['FORUM_LAST_POST_SUBJECT_ORIG'], false), str_replace('"', '&quot;', $returndata[$i]['FORUM_LAST_POST_SUBJECT_ORIG']), $returndata[$i]['FORUM_LAST_POST_SUBJECT']);
				
				if (!$returndata[$i]['FORUM_LAST_POSTER_NAME']) {
					 $returndata[$i]['FORUM_LAST_POSTER_NAME'] = $ubbt_lang['ANON_TEXT'];
				}
				$returndata[$i]['FORUM_LAST_POSTER'] = sprintf('(%s)', $returndata[$i]['FORUM_LAST_POSTER_NAME']);
			}
		}
		
		$returndata[$i]['FORUM_MODERATOR_LIST'] = '';		
		if (isset($moderators["$f"]) && is_array($moderators["$f"])) {
			foreach ($moderators["$f"] as $mod) {
				$returndata[$i]['FORUM_MODERATOR_LIST'] .= sprintf('<a href="%s">%s</a>, ', make_ubb_url("ubb=showprofile&User={$mod['USER_ID']}", $mod['USER_DISPLAY_NAME']), $mod['USER_DISPLAY_NAME']);
			}
			$returndata[$i]['FORUM_MODERATOR_LIST'] = preg_replace('#,\s+$#', '', $returndata[$i]['FORUM_MODERATOR_LIST']);
		}
		
		$returndata[$i]['subforums'] = '';
		if (count($returndata[$i]['subforum_links'])) {
			foreach ($returndata[$i]['subforum_links'] as $k => $subforum_moo) {
				$returndata[$i]['subforums'] .= ($subforum_moo[0] . (($subforum_moo[1] > 0) ? sprintf(' <span class="newtotal">(%s)</span>', $subforum_moo[1]) : '') . ', ');
			}
		}
		$returndata[$i]['subforums'] = preg_replace('#,\s+$#', '', $returndata[$i]['subforums']);
		
		
		// How many are online in this forum?
		$returndata[$i]['ONLINE'] = array_get($online_per_forum, "$f", 0);

		$i++;
	}

	//print_r($returndata);
	
	unset($forum_data);

	if ($type == "cfrm") {
		$returndata['ONLINE'] = $online;
	}

	return $returndata;	
}

function get_subforums( $f, $subforums_so_far, &$forum_data, &$f_index) {
	global $tree, $userob;

	if (!isset($tree['kids'][$f]) || !is_array($tree['kids'][$f])) {
		return $subforums_so_far;
	}

	foreach($tree['kids'][$f] as $k => $board_id) {
		if (!$userob->check_access("forum","SEE_FORUM",$board_id) && !$forum_data[$f_index["$board_id"]]['FORUM_IS_TEASER']) {
			continue;
		}

		if (!$forum_data[$f_index["$board_id"]]['FORUM_IS_ACTIVE']) {
			continue;
		}

		$subforums_so_far[] = $board_id;
		if (isset($tree['kids'][$board_id]) && is_array($tree['kids'][$board_id])) {
			$subforums_so_far = get_subforums($board_id, $subforums_so_far);
		} // end if
	} // end foreach
	return $subforums_so_far;
} // end get_subforums
