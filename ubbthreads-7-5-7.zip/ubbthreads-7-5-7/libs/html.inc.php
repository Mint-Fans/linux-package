<?php

//	Script Version 7.5.7

class html {

	var $badwords = array();
	var $replacewords = array();
	var $active_text = array();
	var $active_replace = array();
	var $island_cookies = array();
	var $graemlins = array();
	var $shoutbox_loaded = 0;
	var $colspan = 1;
	var $style_set = 0;
	var $group_images = array();

	function send_column($side="",$force_column=0) {
		global $smarty, $config,$userob,$user,$ubbt_lang,$dbh,$style_array,$wrappers;

		$wrapper_id = $style_array['wrappers'];
		$tbopen = $wrappers[$wrapper_id]['open'];
		$tbclose = $wrappers[$wrapper_id]['close'];
		$side_content = "{$side}_COLUMN_BOXES";
		$side_column = "{$side}_COLUMN";

		if (!$force_column) {
			if (($user['USER_HIDE_LEFT_COLUMN'] && $config['DISABLE_LEFT']) || $config['LEFT_COLUMN_PORTAL']) {
				$config['LEFT_COLUMN'] = 0;
			} // end if
			if (($user['USER_HIDE_RIGHT_COLUMN'] && $config['DISABLE_RIGHT']) || $config['RIGHT_COLUMN_PORTAL']) {
				$config['RIGHT_COLUMN'] = 0;
			} // end if
		} // end if

		if ($config['LEFT_COLUMN'] && !$config['RIGHT_COLUMN']) {
			$left_width="15%";
			$body_width="85%";
			$this->colspan = 2;
		} elseif (!$config['LEFT_COLUMN'] && $config['RIGHT_COLUMN']) {
			$right_width="15%";
			$body_width="85%";
			$this->colspan = 2;
		} elseif ($config['LEFT_COLUMN'] && $config['RIGHT_COLUMN']) {
			$left_width="15%";
			$right_width="15%";
			$body_width="70%";
			$this->colspan = 3;
		} else {
			$body_width="100%";
		}

		$island = "";

		// user list?
		if ($userob->check_access("site","MEMBER_LIST")) {
			$smarty->assign("user_list",1);
		} else {
			$smarty->assign("user_list",0);
		} // end if

		if ($config[$side_column]) {

			$smarty->assign("cp_link",0);
			$smarty->assign("new_user_link",0);
			$smarty->assign("myspace_link",0);
			$smarty->assign("search_link",0);


			// Need to grab calendar events if they are logged in
			if ($userob->is_logged_in && in_array("calendar",$config[$side_content]) && $config['CALENDAR']) {
				$smarty->assign("calendar","private");

				// Get current date
				$current_date = date("j");
				$current_month = date("n");
				$current_year = date("Y");

				// Get date 30 days from now
				$month = time() + 2592000;
				$last_date = date("j",$month);
				$last_month = date("n",$month);
				$last_year = date("Y",$month);

				// Get any private events
				$query_vars = array($current_date,$current_month,$current_year,$user['USER_ID']);
				$query = "
					select 	CALENDAR_EVENT_ID,CALENDAR_EVENT_DAY,CALENDAR_EVENT_MONTH,CALENDAR_EVENT_YEAR,CALENDAR_EVENT_SUBJECT
					from		{$config['TABLE_PREFIX']}CALENDAR_EVENTS
					where		CALENDAR_EVENT_TYPE = 'private'
					and			(CALENDAR_EVENT_DAY >= ? and CALENDAR_EVENT_MONTH >= ? and CALENDAR_EVENT_YEAR >= ? )
					and			USER_ID = ?
					order by CALENDAR_EVENT_YEAR,CALENDAR_EVENT_MONTH,CALENDAR_EVENT_DAY
					limit 10
				";
				$sth = $dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
				$events = array();
				$i = 0;
				while ($result = $dbh->fetch_array($sth)) {
					$events[$i]['id'] = $result['CALENDAR_EVENT_ID'];
					$events[$i]['day'] = $result['CALENDAR_EVENT_DAY'];
					$events[$i]['month'] = $result['CALENDAR_EVENT_MONTH'];
					$events[$i]['year'] = $result['CALENDAR_EVENT_YEAR'];
					$events[$i]['subject'] = $result['CALENDAR_EVENT_SUBJECT'];
					$i++;
				} // end while

				$smarty->assign("events",$events);
				$smarty->assign("side",strtolower($side));
				$calendar_island = $smarty->fetch("island_calendar.tpl");
			} else {
				if (!in_array("calendar",$config["RIGHT_COLUMN_BOXES"]) && !in_array("calendar",$config['LEFT_COLUMN_BOXES']) && $config['CALENDAR']) {
					$smarty->assign("calendar","public");
				}
			}

			$smarty->assign("side",strtolower($side));
			$style_side = strtolower($side);


			// grab all the islands
			foreach($config[$side_content] as $k => $v) {
				if ($v == "public_calendar" && !$config['CALENDAR']) continue;
				if ($v == "calendar" && !$userob->is_logged_in) continue;
				if ($v == "search" && !$userob->check_access("site","CAN_SEARCH")) continue;
				if ($v == "shoutbox") {
					if (!$userob->check_access("site","CAN_SEE_SHOUTS")) continue;
					$this->shoutbox_loaded = 1;
				}
				if ($v == "calendar" && $config['CALENDAR']) {
					$island .= $calendar_island;
				} elseif ($v == "privates") {
					$island .= $privates_island;
				} else {
					ob_start();
					include_once("cache/{$v}.php");
					$island .= ob_get_contents();
					ob_end_clean();
				} // end if

			} // end foreach

		} // end if

		$smarty_data = array(
			"island_data" => & $island,
			"side_column" => $side_column,
			"left_width" => $left_width,
			"right_width" => $right_width,
			"body_width" => $body_width,
		);

		return array(
			"template" => strtolower($side) . "_column",
			"data" => & $smarty_data,
		);


	} // end function send_column


	// Set the current style
	function set_style($force=0) {

		global $config,$style_array,$user,$smarty,$userob;

		if (defined('INSTALL')) return;

		$mystyle = '';
		$this->style_set = 1;
		if ($force && $user['USER_STYLE'] == 0) {
			$mystyle  = $force;
		} else {
			$mystyle = $user['USER_STYLE'];
		}
		if (!$mystyle || !file_exists( "{$config['FULL_PATH']}/styles/{$mystyle}.php" )) {
			$mystyle = $config['DEFAULT_STYLE'];
		}

		if (!$userob->is_logged_in && !$force) {
			$mystyle = $_SESSION['myprefs']['style'];
		} // end if

		$check = @include_once("{$config['FULL_PATH']}/styles/{$mystyle}.php");
		if (!$check) {
			include_once("{$config['FULL_PATH']}/styles/{$config['DEFAULT_STYLE']}.php");
		}

		// 7.1 - Force mood setting if it's not set
		if (!$style_array['mood']) {
			$style_array['mood'] = "moods/default";
		}

		table_wrapper();

		// Load the style array
		$smarty->assign('style_array',$style_array);


	} // end set_style


	// ######################################################################
	// SEND_HEADER FUNCTION
	// Grab the title and send the header
	// ######################################################################
	function send_header($header) {
		global $style_array,$tree, $ubb, $config, $myinfo,$ubbt_lang, $dbh, $smarty, $PHPSESSID, $SID,$debug,$forumvisit,$user, $userob, $VERSION, $admin_closed_message, $closed_message;

		if (!$user['USER_LANGUAGE']) $user['USER_LANGUAGE'] = $config['LANGUAGE'];

		$inputTitle = array_get($header, 'title', '');
		$refresh = array_get($header, 'refresh', '');
		$user = array_get($header, 'user', '');
		$Board = array_get($header, 'Board', '');
		$bypass = array_get($header, 'bypass', '');
		$onload = array_get($header, 'onload', '');
		$onunload = array_get($header, 'onunload', '');
		$breadcrumb = array_get($header, 'breadcrumb', '');
		$javascript = array_get($header, 'javascript', array());
		$rss = array_get($header, 'rss', '');
		$rss_title = array_get($header, 'rss_title', '');
		$category = array_get($header, 'Category', '');
		$forum_parent = array_get($header, 'forum_parent', '');
		$fheader = array_get($header, 'custom_header_footer', '');
		$post_subject = array_get($header, 'post_subject', '');
		$post_id = array_get($header, 'post_id', '');
		$s_priv = $userob->check_access("site","CAN_SHOUT");

		if (!defined('HEADER_SENT')) {
			define('HEADER_SENT',1);
		}

		if (!$refresh) {
			$refresh = "";
		}

		// If board is set we need to do the breadcrumbs
		if ($Board) {
			if (!sizeof($tree)) {
				list($tree,$style_cache,$lang_cache) = build_forum_cache();
			}

			$breadcrumb .=  " &raquo; <a href=\"" . make_ubb_url("ubb=cfrm&c=$category", $tree['categories'][$category], false) . "\">{$tree['categories'][$category]}</a>";

			$more = false;
			$strlen = strlen($config['COMMUNITY_TITLE'] . strip_tags($breadcrumb));

			if (isset($tree['tree'][$Board])) {
				foreach($tree['tree'][$Board] as $key => $forum_id) {
					$more = true;
					$forum_title = preg_replace("/&nbsp;/","",$tree[$category][$forum_id]);
					$strlen = $strlen + strlen($forum_title);
					$breadcrumb .= " &raquo; <a href=\"" . make_ubb_url("ubb=postlist&Board=$forum_id", $forum_title, false) . "\">$forum_title</a>";
					if ($forum_id == $Board) {
						break;
					}
					if ($strlen > 100) {
						$more = false;
						$breadcrumb .= "<br />&nbsp; &nbsp; &nbsp";
						$strlen = 0;
					} // end if
				}
			}
			$forum_title = preg_replace("/&nbsp;/","",$tree[$category][$Board]);
			if ($strlen + strlen($forum_title . $inputTitle) > 100 && $more) {
				$breadcrumb .= "<br />&nbsp; &nbsp; &nbsp";
			}
			$breadcrumb .= " &raquo; <a href=\"" . make_ubb_url("ubb=postlist&Board=$Board&page=1", $forum_title, false) . "\">$forum_title</a>";
			if ($inputTitle != $forum_title) {
				$breadcrumb .= " &raquo; $inputTitle";
			}
		}

		$rss_feed = "";
		$rss_title = htmlspecialchars($rss_title);
		if ($rss) {
			$rss_feed = "<link rel=\"alternate\" type=\"application/rss+xml\" title=\"$rss_title\" href=\"{$config['FULL_URL']}/cache/rss{$Board}.xml\" />";
		} // end if

		if (!$user) {
			$user = array();
		}

		if (isset($user['loggedout'])) {
			$loggedout = $user['loggedout'];
		}

		if (!$ubb) $ubb = "all_admin";
		$What = $ubb;

		// -------------------------------------------------------------------
		// If we don't have a status then they we need to try and authenticate
		if (!isset($user['USER_MEMBERSHIP_LEVEL']) && !defined('IS_BANNED') && !defined('IS_SQL_ERROR') && !defined('ACCEPT_RULES')) {
			$userob = new user;
			$user = $userob -> authenticate();
		}

		// -----------------------------
		// Grab any personal preferences
		$Privates = "";
		$Status    = "";
		if (isset($user['USER_TOTAL_PM'])) {
			$Privates  = $user['USER_TOTAL_PM'];
		}
		if (isset($user['USER_MEMBERSHIP_LEVEL'])) {
			$Status    = $user['USER_MEMBERSHIP_LEVEL'];
		}

		header('Content-Type: text/html; charset=' . $ubbt_lang['CHARSET']);

		$insert = @file("{$config['FULL_PATH']}/includes/header-insert.php");
		if (!is_array($insert)) {
			$insert = @file("{$config['BASE_URL']}/includes/header-insert.php");
		}
		$headerinsert = "";
		if (!empty($insert)) {
			$headerinsert = implode('',$insert);
		}
		$headerinsert .= "<meta name=\"robots\" content=\"index, follow\" />";

		$cfrm_kludge = ($ubb == "cfrm" && $inputTitle == $config['COMMUNITY_TITLE']);

		if ($inputTitle == $config['COMMUNITY_TITLE']) {
			require_once("{$config['FULL_PATH']}/languages/{$user['USER_LANGUAGE']}/online.php");
			$inputTitle = array_get($ubbt_lang, $What, $ubbt_lang['all_admin']);
		}

		$powered = "";

		if ($ubb == "portal" || $cfrm_kludge) {
			$inputTitle = $config['COMMUNITY_TITLE'];
			$powered = $ubbt_lang['POWERED_BY'];
		}

		// how many columns
		$columns = 2;

		// Make sure there is a default mood
		if (!$user['USER_MOOD'] && !empty($user['USER_DISPLAY_NAME'])) {
			$user['USER_MOOD'] = "content.gif";
		}

		// If they aren't logged in, or just logged out, give them the proper message
		if ( (empty($user['USER_DISPLAY_NAME']) || !$userob->is_logged_in) || ($bypass) ) {
			$welcome = "{$ubbt_lang['NOT_LOGGED']} [<a href=\"" . make_ubb_url("ubb=login", "", false) . "\">{$ubbt_lang['BUTT_LOGIN']}</a>]";
		} else {
			$welcome = "{$ubbt_lang['INTRO_SUB2']} {$user['USER_DISPLAY_NAME']}. [<a href = \"" . make_ubb_url("ubb=logout", "", false) . "\">{$ubbt_lang['LOGOUT_TEXT']}</a>]";
		}

		// Update the online table
		if (!defined('IS_ERROR')) {
			if ( (empty($user['USER_DISPLAY_NAME']) || $user['USER_ID'] == 1) || ($bypass) ) {

				// Since we still want to see non logged in users on the online screen
				// we need to track this by IP
				$IP = find_environmental ("REMOTE_ADDR");
				$referer = substr(htmlspecialchars(find_environmental("HTTP_REFERER")),0,255);
				$agent = substr(htmlspecialchars(find_environmental("HTTP_USER_AGENT")),0,255);
				$Last     = $this -> get_date();

				// Try to update first.
				if (!$post_id) $post_id = 0;
				$query_vars = array($Last,$What,$Board,$post_id,$post_subject,"-ANON-$IP");
				$query = "
					update {$config['TABLE_PREFIX']}ONLINE
					set ONLINE_LAST_ACTIVITY = ? ,
					    ONLINE_SCRIPT_NAME = ? ,
					    ONLINE_BROWSING_FORUM = ? ,
					    ONLINE_POST_ID = ? ,
					    ONLINE_POST_SUBJECT = ?
					where ONLINE_DISPLAY_NAME = ?
				";
				$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

				// If no rows affected, this is a new visit
				if (!$dbh->affected_rows()) {

					if (!$post_id) $post_id = 0;
					$query_vars = array(1,"-ANON-$IP",$Last,$What,$Board,'a',$IP,$referer,$agent,$post_id,$post_subject);
					$query = "
						REPLACE INTO {$config['TABLE_PREFIX']}ONLINE
						(USER_ID,ONLINE_DISPLAY_NAME,ONLINE_LAST_ACTIVITY,ONLINE_SCRIPT_NAME,ONLINE_BROWSING_FORUM,ONLINE_USER_TYPE,ONLINE_USER_IP,ONLINE_REFERER,ONLINE_AGENT,ONLINE_POST_ID,ONLINE_POST_SUBJECT)
						VALUES ( ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? )
					";
					$dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__,1);

					// If we have a referer, insert this into the referer_log table
					// But only if referer logging is enabled
					if ($referer && !preg_match("#({$config['REFERERS']})#",$referer) && ($config['LOG_REFERS'] == 1)) {
						$query_vars = array($Last,$referer);
						$query = "
							insert into {$config['TABLE_PREFIX']}REFERER_LOG
							(REFERER_DATE,REFERER_URL)
							values
							( ? , ? )
						";
						$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
					} // end if
				}

			} else {

				// ------------------------------
				// Update the who's online screen
				$Last     = $this -> get_date();

				// we need to track this by IP
				$IP = find_environmental ("REMOTE_ADDR");
				$referer = substr(htmlspecialchars(find_environmental("HTTP_REFERER")),0,255);
				$agent = substr(htmlspecialchars(find_environmental("HTTP_USER_AGENT")),0,255);
				if (!$post_id) $post_id = 0;
				$query_vars = array($user['USER_DISPLAY_NAME'],$user['USER_ID'],$Last,$What,$Board,'r',$IP,$referer,$agent,$post_id,$post_subject);

				$query = "
					REPLACE INTO {$config['TABLE_PREFIX']}ONLINE
					(ONLINE_DISPLAY_NAME,USER_ID,ONLINE_LAST_ACTIVITY,ONLINE_SCRIPT_NAME,ONLINE_BROWSING_FORUM,ONLINE_USER_TYPE,ONLINE_USER_IP,ONLINE_REFERER,ONLINE_AGENT,ONLINE_POST_ID,ONLINE_POST_SUBJECT)
					VALUES ( ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? )
				";
				$dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

			}

		}

		// How many columns does the header need to span?
		if ($config['LEFT_COLUMN'] && $config['RIGHT_COLUMN']) {
			$colspan = 3;
		} elseif ($config['LEFT_COLUMN'] || $config['RIGHT_COLUMN']) {
			$colspan = 2;
		} else {
			$colspan = 1;
		} // end if

		if ($fheader) {
			$file = "header_$Board.php";
		}
		else {
			$file = "header.php";
		}

		ob_start();
		include("{$config['FULL_PATH']}/includes/$file");
		$headerfile = ob_get_contents();
		ob_end_clean();

		if (!is_array($javascript)) {
			$javascript = array();
		}

		$javascript[] = "ubb_jslib.js";

		$javascript = array_reverse($javascript);

		if ($onload && !preg_match("/;$/",$onload)) {
			$onload = "{$onload};";
		} // end if
		if ($config['BODY_ONLOAD']) {
			$onload = "{$onload}{$config['BODY_ONLOAD']}";
		} // end if

		// Which links in the nav menu?
		$cp_link = 0;
		$myspace_link = 0;
		$search_link = 0;
		$new_flasher = "";
		$new_user_link = 0;
		if ($userob->is_logged_in) {
			// Registered Links
			if ($userob->check_access("cp")) {
				$cp_link = 1;
			} // end if

			// Set this up for either a popup menu or left nav link
			$myspace_link = 1;
			if ($user['USER_SHOW_LEFT_MYSTUFF'] == 1) {
				$myspace_link = 2;
			}

			$search_link = 1;
			if ($user['USER_TOTAL_PM']) {
				$lang_string = sprintf($ubbt_lang['UNREAD_PM'],$user['USER_TOTAL_PM']);
				$new_flasher =  "<a href=\"" .  make_ubb_url("ubb=viewmessages", "", false) . "\"><img src= \"{$config['BASE_URL']}/images/{$style_array['general']}/newpm.gif\" border=\"0\" alt=\"$lang_string\" title=\"$lang_string\" /></a>";
			}
		} else {
			// Unregistered links
			$new_user_link = 1;
			if ($userob->check_access("site","CAN_SEARCH")) {
				$search_link = 1;
			}

		} // end if

		$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";

		$now = $this->get_date();
		$today = $this->convert_time($now,$user['USER_TIME_OFFSET'],"j",1,0);
		$realtoday = $this->convert_time($now,0,"d",1,0);
		// A messy little calendar hack......not even going to explain since
		// hopefully I can remove it someday ;)
		if ($today == 1  && $realtoday > 20) {
			$today = $realtoday;
		}

		if ($onunload) {
			$onunload = "onunload='$onunload'";
		}

		$smarty_data = array(
			"onload" => $onload,
			"onunload" => $onunload,
			"headerinsert" => & $headerinsert,
			"refresh" => $refresh,
			"stylesheet" => $stylesheet,
			"inputTitle" => $inputTitle,
			"colspan" => $columns,
			"welcome" => $welcome,
			"breadcrumb" => $breadcrumb,
			"colspan" => $colspan,
			"headerfile" => $headerfile,
			"javascript" => $javascript,
			"rss_feed" => $rss_feed,
			"myid" => $user['USER_ID'],
			"cp_link" => $cp_link,
			"myspace_link" => $myspace_link,
			"search_link" => $search_link,
			"new_flasher" => $new_flasher,
			"new_user_link" => $new_user_link,
			"powered" => $powered,
			"today" => $today,
			"mood" => $user['USER_MOOD'],
			"version" => $VERSION,
			'referrer' => htmlspecialchars(get_current_url()),
			's_priv' => $s_priv,
			'admin_closed_message' => $admin_closed_message,
			'closed_message' => $closed_message,
		);

		return array(
			"template" => "header",
			"data" => & $smarty_data
		);


	}


	// #######################################################################
	// function send_redirect
	// #######################################################################
	function send_redirect($redirect) {

		global $user,$config,$smarty;

		$delay = 2;
		if(isset($redirect['delay'])) { $delay = $redirect['delay']; }

		if ($redirect['redirect']) {
			$meta = "<meta http-equiv=\"Refresh\" content=\"{$delay};url=" . make_ubb_url("ubb={$redirect['redirect']}", "", false) . "\" />";
		} else {
			$meta = "";
		} // end if

		$smarty_data = array(
			"heading" => $redirect['heading'],
			"body" => $redirect['body'],
			"returnlink" => $redirect['returnlink'],
		);

		$data = array(
			"header" => array (
				"title" => array_get($redirect, 'heading', ''),
				"refresh" => $meta,
				"user" => $user,
				"Board" => array_get($redirect, 'Board', ''),
				"Category" => array_get($redirect, 'Category', ''),
				"forum_id" => array_get($redirect, 'forum_id', ''),
				"bypass" => 0,
				"onload" => "",
				"breadcrumb" => array_get($redirect, 'breadcrumb', ''),
			),
			"template" => "send_redirect",
			"data"  => & $smarty_data,
			"footer" => true,
			"location" => ""
		);

		smartyPrepare($data);
		exit;

	} // end send_redirect

	// #############################################################
	// Give the user the board rules, they must accept
	// #############################################################
	function give_rules($view="") {

		global $user,$ubbt_lang,$debug,$smarty,$config;

		define('ACCEPT_RULES',1);

		if (!$this->style_set) {
			$this->set_style();
		} // end if

		$ocurl = htmlspecialchars(get_current_url());
		$rules = file_get_contents("{$config['FULL_PATH']}/includes/boardrules.php");

		$smarty_data = array(
			"ocurl" => "$ocurl",
			"rules" => "$rules",
			"view" => "$view",
		);

		$data = array(
			"header" => array (
				"title" => "{$ubbt_lang['BOARD_RULES']}",
				"refresh" => 0,
				"user" => $user,
				"Board" => "",
				"bypass" => 0,
				"onload" => "",
			),
			"template" => "boardrules",
			"data" => & $smarty_data,
			"footer" => true,
			"location" => "",
			"redirect" => "",
		);
		smartyPrepare($data);
		exit;
	} // end give_rules

	// #######################################################################
	// Not right - something went wrong - UHOH!
	// #######################################################################
	function not_right($error="",$line="",$file="") {

		global $user,$userob,$ubbt_lang,$debug, $smarty;
		if (!is_array($ubbt_lang)) {
			@include_once("languages/{$user['USER_LANGUAGE']}/generic.php");
			$smarty->assign_by_ref('lang',$ubbt_lang);
		}
		if (!$this->style_set) {
			$this->set_style();
		}

		define ('IS_ERROR',1);
		$no_return = true;
		if (defined('NO_RETURN')) {
			$no_return = false;
		}

		@include_once("languages/{$user['USER_LANGUAGE']}/login.php");
		$smarty_data = array(
			"error" => & $error,
			"no_return" => $no_return,
			'not_logged_in' => !(is_object($userob) && $userob->is_logged_in),
			'referrer' => htmlspecialchars(get_current_url()),
		);

		if (defined('INSTALL')) {
			echo "$error<br /><br />";
			return;
		}

		if (!defined('HEADER_SENT')) {
			$data = array(
				"header" => array (
					"title" => "{$ubbt_lang['NO_PROCEED']}",
					"refresh" => 0,
					"user" => $user,
					"Board" => "",
					"bypass" => 0,
					"onload" => "",
				),
				"template" => "notright",
				"data" => & $smarty_data,
				"footer" => true,
				"location" => "",
				"redirect" => "",
			);
		} else {
			$data = array(
				"header" => array (),
				"template" => "notright",
				"data" => & $smarty_data,
				"footer" => true,
				"location" => "",
				"redirect" => "",
			);
		}

		smartyPrepare($data);
		exit;
	}

	// #########################################################
	// Basic not_right function used in popups
	// #########################################################
	function not_right_bare($error="") {
		global $user,$config,$style_array,$smarty,$ubbt_lang;
		define ('IS_ERROR',1);

		@include_once("languages/{$user['USER_LANGUAGE']}/generic.php");
		if (!$this->style_set) {
			$this->set_style();
		}
		if (!$user['USER_LANGUAGE']) $user['USER_LANGUAGE'] = $config['LANGUAGE'];
		if (!is_array($ubbt_lang)) {
			@include_once("languages/{$user['USER_LANGUAGE']}/generic.php");
			$smarty->assign_by_ref('lang',$ubbt_lang);
		}
		$stylesheet = "{$config['BASE_URL']}/styles/{$style_array['css']}";
		$smarty->assign("stylesheet",$stylesheet);
		$smarty->assign("error",$error);
		$smarty->assign("referrer", htmlspecialchars(get_current_url()));
		echo $smarty->fetch("not_right_bare.tpl");
		exit;
	}


	// #######################################################################
	// Check_refer
	// #######################################################################
	function check_refer() {

		global $config,$ubbt_lang;
		$valid = 0;
		$referers = preg_split("#\|#",$config['REFERERS']);
		for ($i=0; $i <= (sizeof($referers)-1); $i++) {
			if (stristr(find_environmental('HTTP_REFERER'),$referers[$i])) {
				$valid++;
			}
		}
		if (!$valid) {
			$this -> not_right($ubbt_lang['NOT_VALID']);
		}
	}


	// #####################################################################
	// ubbt_setcookie
	// #####################################################################
	function ubbt_setcookie($name,$value="",$time=0,$cookiepath="") {

		global $config;
		if (!$cookiepath) {
			$cookiepath = $config['COOKIE_PATH'];
			if ($config['SEARCH_FRIENDLY_URLS'] && !$cookiepath) {
				$cookiepath = "/";
			}
		}

		setcookie("$name","$value",$time,$cookiepath);

		if ($value) {
			$_SESSION[$name] = $value;
		} else {
			unset($_SESSION[$name]);
		}

	}


	// #######################################################################
	// Check for any badwords
	// #######################################################################
	function do_censor($text="") {

		global $config,$dbh;

		$badwords = $this->badwords;
		$replacewords = $this->replacewords;
		if (!sizeof($badwords)) {
			$query = "
				SELECT CENSOR_WORD,CENSOR_REPLACE_WITH
				FROM {$config['TABLE_PREFIX']}CENSOR_LIST
			";
			$sth = $dbh->do_query($query);
			while($result = $dbh->fetch_array($sth)) {
				$word = preg_quote($result['CENSOR_WORD'], "/");
				$word = str_replace("\(\.\*\?\)","(.*?)",$word);
				$badwords[] = "/\b$word\b/i";

				if (!$result['CENSOR_REPLACE_WITH']) {
					$result['CENSOR_REPLACE_WITH'] = $config['REPLACE_WORD'];
				}
				$replacewords[] = $result['CENSOR_REPLACE_WITH'];
			}
			$this->badwords = $badwords;
			$this->replacewords = $replacewords;
		}


		if (is_array($badwords) && is_array($replacewords)) {
			return preg_replace($badwords,$replacewords,$text);
		}
		else {
			return $text;
		}

	}

	function get_graemlins() {
		global $dbh, $config;
		if (count($this->graemlins > 0)) {
			// Do smilies, since there are our only default
			$query = "
				SELECT GRAEMLIN_MARKUP_CODE,GRAEMLIN_SMILEY_CODE,GRAEMLIN_IMAGE,GRAEMLIN_HEIGHT,GRAEMLIN_WIDTH,GRAEMLIN_ORDER
				FROM   {$config['TABLE_PREFIX']}GRAEMLINS
				WHERE GRAEMLIN_IS_ACTIVE='1'
				ORDER BY GRAEMLIN_ORDER ASC
			";
			$sth = $dbh->do_query( $query, __LINE__, __FILE__ );
			while( $result = $dbh->fetch_array( $sth ) ) {
				$this->graemlins[] = $result;
			}
		}
	}

	function active_text($text="") {
		global $config,$dbh;

		$targets = $this->active_text;
		$replacements = $this->active_replace;
		if (!sizeof($targets)) {
			$targets = array();
			$replacements = array();
			foreach($config['ACTIVE_TEXT_LIST'] as $target => $replace) {
				$target = preg_quote($target,"/");
				$targets[] = "/\b$target\b(?!([^\<\>]*\"\>|[^\<\>]*\" \/\>|[^\<]*\<\/[^\<\>]*\>))/iU";
				$replacements[] = "\\1$replace\\2\\3";
			}
		}

		if (is_array($targets) && is_array($replacements)) {
			return preg_replace($targets,$replacements,$text);
		} else {
			return $text;
		}

	}

	// #######################################################################
	// Markup a string
	// Thanks to Ian Spence for writing this function
	// #######################################################################
	function do_markup($body = "", $type = "", $convert = "") {
		global $config,$userob;

		if (!isset($this->bbcode_parser)) {
			$this->bbcode_parser = new bbcode();
		}

		$this->bbcode_parser->init_post($body, $type, $convert, $this, $config['IMAGE_LIMIT']);
		$this->bbcode_parser->set_fonts($config['MARKUP_FONTS']);
		$this->bbcode_parser->set_sizes($config['MARKUP_FONT_SIZES']);

		if ((($type == "signature" && !$userob->check_access("site","SIGNATURE_IMAGES")) || (!$config['ALLOW_IMAGE_MARKUP'] && $type != "signature")) && !defined('IS_IMPORT')) {
			$this->bbcode_parser->disallow_tag("img");
		}
		if ($type == "signature") {
			$this->bbcode_parser->disallow_tag("custom");
		}

		//return $this->bbcode_parser->to_text();
		return $this->bbcode_parser->to_html();
	}


	// #######################################################################
	// Send the footer
	// #######################################################################
	function send_footer($header=array()) {

		global $user,$config, $VERSION, $ubbt_lang, $smarty, $timea,$querycount,$zlib,$Board,$mysqltime,$debugprint,$style_array,$wrappers,$style_cache,$lang_cache,$userob;

		$fheader = array_get($header, 'custom_header_footer', '');
		$Board = array_get($header, 'Board', '');

		$current_url = urlencode(get_current_url());

        if (!sizeof($style_cache)) {
            list($tree,$style_cache,$lang_cache) = build_forum_cache();
        } // end if
        if (!sizeof($lang_cache)) {
            list($tree,$style_cache,$lang_cache) = build_forum_cache();
        } // end if

		if ($userob->is_logged_in) {
			$current_style = $user['USER_STYLE'];
		} else {
			$current_style = $_SESSION['myprefs']['style'];
		} // end if
		if (!$current_style) {
			$current_style = $config['DEFAULT_STYLE'];
		} // end if

		if ($userob->is_logged_in) {
			$current_lang = $user['USER_LANGUAGE'];
		} else {
			$current_lang = $_SESSION['myprefs']['lang'];
		}
		if (!$current_lang) {
			$current_lang = $config['LANGUAGE'];
		} // end if

		// Style Selector
		$style_select = "<select name='style' onchange=\"changePrefs('style',this.form.style.value);\" class='form-input'><optgroup label='{$ubbt_lang['STYLE_CHOOSER']}'>";
		$foundone = 0;
		$style_select .= "<option value='0'>{$ubbt_lang['STYLE_DEFAULT']}</option>";
		foreach($style_cache as $k => $v) {
			$foundone++;
			$selected = "";
			if ($k == $current_style) {
				$style_select .= "<option selected='selected' value='$k'>$v</option>";
			} else {
				$style_select .= "<option value='$k'>$v</option>";
			} // end if
		} // end foreach
		if ($foundone > 1) {
			$style_select .="</optgroup></select>";
		} else {
			$style_select = "";
		}

		// Language Selector
		$lang_select = "<select name='lang' onchange=\"changePrefs('lang',this.form.lang.value);\" class='form-input'><optgroup label='{$ubbt_lang['LANG_CHOOSER']}'>";
		$foundone = 0;
		foreach($lang_cache as $k => $v) {
			$dir = $v['dir'];
			$name = $v['name'];
			$foundone++;
			$selected = "";
			if ($dir == $current_lang) {
				$lang_select .= "<option selected='selected' value='$k'>$name</option>";
			} else {
				$lang_select .= "<option value='$k'>$name</option>";
			} // end if
		} // end foreach
		if ($foundone > 1) {
			$lang_select .="</optgroup></select>";
		} else {
			$lang_select = "";
		}

		if (isset($config['CONTACT_LINK_TYPE']) && $config['CONTACT_LINK_TYPE'] == "url") {
			$contactlink = "<a href=\"{$config['CONTACT_URL']}\">{$config['SITE_EMAIL_TITLE']}</a>";
		}
		else {
			$contactlink = "<a href=\"mailto:{$config['SITE_EMAIL']}\">{$config['SITE_EMAIL_TITLE']}</a>";
		}

		if ($config['PRIVACY_STATEMENT'] == "text") {
			$privacy_statement = "<a href=\"" . make_ubb_url("ubb=viewprivacy", "", false) . "\">{$ubbt_lang['PRIVACY']}</a>";
		}
		elseif ($config['PRIVACY_STATEMENT'] == "url") {
			$privacy_statement = "<a href=\"{$config['PRIVACY_URL']}\">{$ubbt_lang['PRIVACY']}</a>";
		} else {
			$privacy_statement = "";
		}

		$debug = "";

		if (array_get($config, 'ALLOW_DEBUGGING', false)) {
			$timeb = getmicrotime();
			$time = $timeb - $timea;
			$time = round($time,3);

			$debug = sprintf($ubbt_lang['PAGE_DEBUG'], $time, $mysqltime, $querycount, $zlib);
		}

		if ($fheader) {
			$file = "footer_$Board.php";
		}
		else {
			$file = "footer.php";
		}

		ob_start();
		include("{$config['FULL_PATH']}/includes/$file");
		$footerfile = ob_get_contents();
		ob_end_clean();

		$shoutbox = 0;
		if ($this->shoutbox_loaded === 1) {
			$shoutbox = 1;
		} // end if

		$smarty_data = array(
			'contactlink' => $contactlink,
			'privacy_statement' => $privacy_statement,
			'VERSION' => $VERSION,
			'debug' => $debug,
			'footerfile' => $footerfile,
			'shoutbox' => $shoutbox,
			'colspan' => $this->colspan,
			'styles' => $style_select,
			'langs' => $lang_select,
			'current_url' => $current_url,
			'rebuild' => $rebuild,
		);

		return array(
			"template" => "footer",
			"data" => & $smarty_data,
		);

	}


	// #######################################################################
	// get_date
	// #######################################################################
	function get_date() {

		global $config;
		$currtime = time();
		$currtime = $currtime+($config['SERVER_TIME_OFFSET']*3600);
		return $currtime;

	}

	function convert_time($time="",$offset="",$timeformat="",$full=false,$tags=true) {

		global $config, $ubbt_lang, $user;

		if (!$timeformat) {
			$timeformat = $config['TIME_FORMAT'];
		}


		if ((!$config['RELATIVE_TIME'] && !isset($user['USER_RELATIVE_TIME'])) || $user['USER_RELATIVE_TIME'] == '0') {
			$full = true;
		}

		$diff = $this->get_date() - $time;

		if ($offset) {
			$time = $time + ($offset * 3600);
		}
		$origtime = $time;

		if ($timeformat == "rss") {
			return @date("D, d M Y H:i:s T", $time );
		}

		// Grab the time portion of their prefs
		if (strpos( $timeformat, "H" ) !== false ) {
			$time_format = "H:i";
		} elseif ( strpos ( $timeformat, "G") !== false) {
			$time_format = "G:i";
		} else {
			$time_format = "h:i A";
		} // end if

		$parts = array();

		$adj_time = time() + (($config['SERVER_TIME_OFFSET'] + $offset) * 3600);

		$this_hour = date("H", $adj_time);
		$this_min = date("i", $adj_time);
		$this_sec = date("s", $adj_time);

		$midnight = $adj_time - ($this_hour * 3600) - ($this_min * 60) - ($this_sec);

		// Is it today or yesterday?
		if( !$full && ($origtime > ($midnight - 86400)) && $diff > -1) {
			if( $origtime > $midnight ) {
				if ($diff < 3600) {
					$minutes = intval($diff / 60);
					$seconds = $diff - ($minutes * 60);
					if ($seconds == 1) {
						$seconds_print = $this->substitute($ubbt_lang['SECOND_AGO'], array('SEC' => $seconds));
					} else {
						$seconds_print = $this->substitute($ubbt_lang['SECONDS_AGO'], array('SECS' => $seconds));
					}
					$minutes_print = "";
					if ($minutes) {
						if ($minutes == 1) {
							$minutes_print = $this->substitute($ubbt_lang['MINUTE_AGO'], array('MIN' => $minutes)) . " ";
						} else {
							$minutes_print = $this->substitute($ubbt_lang['MINUTES_AGO'], array('MINS' => $minutes)) . " ";
						}
					}
					$parts = array("{$minutes_print}{$seconds_print} {$ubbt_lang['AGO']}");
		 		} else {
					$parts = array( $ubbt_lang['TODAY_AT'], date( "$time_format", $time ) );
				}
			} else {
				$parts = array( $ubbt_lang['YESTERDAY_AT'], date( "$time_format", $time ) );
			}
		}

		if (count($parts) == 0) {
			$parts = explode( '|', @date($timeformat, $time) );
		}

		if( count( $parts ) > 1 ) {
			if( $tags ) {
				return '<span class="date">' . trim( $parts[0] ) . '</span> <span class="time">' . trim( $parts[1] ) . '</span>';
			} else {
				return trim( $parts[0] ) . " " . trim( $parts[1] );
			}
		} else {
			if( $tags ) {
				return '<span class="date">' . trim( $parts[0] ) . '</span>';
			} else {
				return trim( $parts[0] );
			}
		}
	}


	// #######################################################################
	// Switch_colors - This will switch colors between the 2 table colors
	// #######################################################################
	function switch_colors($color="") {
		return ($color == "alt-1") ? "alt-2" : "alt-1";
	}

	function &paginate_logic($current, $total, $border) {
		$pages = array();

		if ($total <= 1) {
			return $pages;
		}

		if ($total < $border * 5) {
			for ($i = 1; $i <= $total; $i++) {
				$pages[] = array("$i", "$i");
			}

			return $pages;
		}

		for ($i = 1; $i <= $border; $i++) {
			$pages[] = array("$i", "$i");
		}

		$bottom = $current + $border;
		$top = $current + $border;

		if ($bottom < ($border + 1) || $top > $total) {
			$pages[] = array("...", round($total / 2));
		}

		if (($bottom > 1) || ($top < $total)) {
			$x = array();

			for ($i = ($border + 1); $i <= $total - $border; $i++) {
				if (abs($current - $i) <= $border) {
					$x[] = array("$i", "$i");
				}
			}

			$start = $x[0][0] + $border;
			$end   = $x[count($x) - 1][0];

			if (($current >= (($border + 1) * 2)) && $pages[count($pages) - 1][0] != "...") {
				$pages[] = array("...", round($start / 2));
			}

			foreach ($x as $y) {
				$pages[] = $y;
			}

			if (($current < $total - (($border * 2) + 1)) && $pages[count($pages) - 1][0] != "...") {
				$pages[] = array("...", $end + round(($total - $end) / 2) - 1);
			}
		}

		for ($i = $total - ($border - 1); $i <= $total; $i++) {
			$pages[] = array("$i", "$i");
		}

		return $pages;
	}

	function paginate($current, $total, $url, $title = "") {
		global $ubbt_lang, $smarty;

		static $paginate_id = 0;

		if ($total <= 1) {
			return '';
		}

		$border = 2;

		if ($current > $total) {
			$current = $total;
		} else if ($current < 1) {
			$current = 1;
		}

		$page_html = $this->substitute($ubbt_lang['PAGE_TEXT'], array('CURRENT' => $current, 'TOTAL' => $total));

		$pages =& $this->paginate_logic($current, $total, $border);

		if ($current > 1) {
			// Add prev link
			array_unshift($pages, array('&lt;', $current - 1));
		}

		if ($current < $total) {
			$pages[] = array('&gt;', ($current + 1));
		}

		$c = count($pages);

		for ($i = 0; $i < $c; $i++) {
			$tmp = $pages[$i];
			$pages[$i] = array($tmp[0], 'ubb=' . $url . $tmp[1], $title, $this->substitute($ubbt_lang['GO_TO_PAGE'], array('PAGE' => $tmp[1])));

			if ($tmp[1] == $current) {
				$pages[$i][1] = "";
			}
		}

		$smarty->assign_by_ref('pages',$pages);
		$smarty->assign_by_ref('page_html',$page_html);
		$smarty->assign('show_jump', $total > ($border * 5));
		$smarty->assign('url',$url);
		$smarty->assign('paginate_id', $paginate_id);

		$paginate_id++;

		// -------------------------------
		// require the pagination template
		return $smarty->fetch('pagination.tpl');
	}

	// Generate a popup menu that allows single click jump to allowed forum(s)
	function jump_box($Board="") {
		global $config, $ubbt_lang, $tree, $userob, $style_cache, $lang_cache;

		// If not configured, show them the old one
		if (!$config['HOPTO_WIDTH']) return $this->hop_to($Board);

		if (!sizeof($tree)) {
			list($tree,$style_cache,$lang_cache) = build_forum_cache();
		}

		$width = $config['HOPTO_WIDTH'];
		$popup = 1;
		$hopTo = '<table class="popup_menu">';
		foreach($tree['categories'] as $cat => $cat_title) {
			$forums = 0;
			$cat_title = (strlen($cat_title) > $width) ? (substr($cat_title,0,$width-3).'...') : $cat_title;
			$url = make_ubb_url("ubb=cfrm&c=$cat", "", false);
			$hopCat = "<tr><td class=\"popup_menu_content\"><a href=\"$url\">$cat_title</a></td></tr>";
			if (!isset($tree[$cat])) continue;
			foreach($tree[$cat] as $forum_id => $forum_title) {
				if (!$userob->check_access("forum","SEE_FORUM",$forum_id) || $tree['active'][$forum_id] != 1) { continue; }
				$level = substr_count($forum_title,"&nbsp;");
				$forum_title = str_replace("&nbsp;","",$forum_title);
				$forum_title = (strlen($forum_title) > $width) ? (substr($forum_title,0,$width-3-$level).'...') : $forum_title;
				if ($level > 0) {
					$forum_title = str_repeat("&nbsp;",$level) . "&raquo;" . $forum_title;
				}
				else {
				$forum_title .= "&raquo;";
				}
				$url = make_ubb_url("ubb=postlist&Board=$forum_id&page=1", "", false);
				$hopCat .= "<tr><td class=\"popup_menu_content\"><a href=\"$url\">$forum_title</a></td></tr>";
				$forums++;
			}
			if ($forums) $hopTo .= $hopCat;
		}

		$hopTo .= '</table>';
		return array($hopTo, $popup);
	}

	// #######################################################################
	// jump box- prints out a jump box to jump to other forums
	// #######################################################################
	function hop_to($Board="") {

		global $userob, $smarty, $dbh, $config, $ubbt_lang, $debug, $tree;

		if (!sizeof($tree)) {
			list($tree,$style_cache,$lang_cache) = build_forum_cache();
		}

		$choices = "";
		$category = "";
		$forums = 0;
		$popup = 0;
		foreach($tree['categories'] as $cat => $cat_title) {
			$category = "";
			$forums = 0;
			$category .= "<option value=\"c:$cat\">$cat_title ------</option>";
			if (!isset($tree[$cat])) continue;
			foreach($tree[$cat] as $forum_id => $forum_title) {
				$selected = "";
				if ($Board == $forum_id) $selected = "selected=\"selected\"";
				if (!$userob->check_access("forum","SEE_FORUM",$forum_id) || $tree['active'][$forum_id] != 1) { continue; }
				$category .= "<option value=\"$forum_id\" $selected>$forum_title</option>";
				$forums++;
			}
			if ($forums) $choices .= $category;
		}

		$smarty->assign('choices',$choices);
		return array($smarty->fetch('jumper.tpl'),$popup);
	}

	// #######################################################################
	// Do login - Logs the user on
	// #######################################################################
	function do_login($Username="",$Password="",$rememberme="",$from="",$oncomplete="") {

		global $userob,$smarty,$config,$dbh, $ubbt_lang, $forumvisit,$debug, $topicread, $myinfo;

		// -----------------------------------------
		// Connect to db and authenticate this user
		$query = "
			select	t1.USER_DISPLAY_NAME, t3.USER_LAST_VISIT_TIME, t1.USER_PASSWORD,t1.USER_ID,t2.USER_TEMPORARY_PASSWORD,t1.USER_IS_APPROVED,t1.USER_IS_BANNED,t1.USER_IS_UNDERAGE
			from	{$config['TABLE_PREFIX']}USERS as t1,
				{$config['TABLE_PREFIX']}USER_PROFILE as t2,
				{$config['TABLE_PREFIX']}USER_DATA as t3
			where	t1.USER_LOGIN_NAME = ?
			and	t1.USER_ID = t2.USER_ID
			and	t1.USER_ID = t3.USER_ID
		";
		$sth = $dbh->do_placeholder_query($query,array($Username),__LINE__,__FILE__);
		$user = $dbh->fetch_array($sth);

		list($CheckUser,$laston,$pass,$Uid,$temppass,$approved,$isbanned,$coppauser) = $user;
		$dbh -> finish_sth($sth);

		$_SESSION['forumvisit']['lastonline'] = $user['USER_LAST_VISIT_TIME'];
		$_SESSION['forumvisit']['visit'] = array();


		if (!$user['USER_DISPLAY_NAME']) {
			$this->not_right($ubbt_lang['NO_AUTH']);
		}

		if ($user['USER_IS_APPROVED'] == "no") {
			if ($user['USER_IS_UNDERAGE']) {
				$this->not_right($this->substitute($ubbt_lang['PARENT_FORM'], array('COPPA_URL' => make_ubb_url("ubb=coppaform", "", true))));
			} else {
				$this->not_right($ubbt_lang['UNAPPROVED']);
			}
		} else if ($user['USER_IS_APPROVED'] != "yes") {
			$this -> not_right($ubbt_lang['UNVERIFIED']);
		}

		// -------------------------------------------------------------
		// We allow them to login if they are using the correct password
		// of if they are using the temporary password
		$bad = "yes";

		if ((crypt($Password,$user['USER_PASSWORD']) != $user['USER_PASSWORD']) && (md5($Password) != $user['USER_PASSWORD'])) {
			$bad = "yes";
		} else {
			$bad = "no";
			$query = "
				update	{$config['TABLE_PREFIX']}USER_PROFILE
				set	USER_TEMPORARY_PASSWORD=''
				where	USER_ID = ?
			";
			$dbh -> do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
		}
		if ($user['USER_TEMPORARY_PASSWORD']) {
			if (md5($Password) == $user['USER_TEMPORARY_PASSWORD']) {
				$bad = "no";
				$query = "
					update	{$config['TABLE_PREFIX']}USERS
					set	USER_PASSWORD = ?
					where	USER_ID = ?
				";
				$dbh -> do_placeholder_query($query,array($user['USER_TEMPORARY_PASSWORD'],$user['USER_ID']),__LINE__,__FILE__);
				$query = "
					update	{$config['TABLE_PREFIX']}USER_PROFILE
					set	USER_TEMPORARY_PASSWORD=''
					where	USER_ID = ?
				";
				$dbh -> do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
			}
		}
		if ($bad == "yes") {
			return array(
				"header" => array (
					"title" => $ubbt_lang['BAD_PASS'],
					"refresh" => "<meta http-equiv=\"refresh\" content=\"5;url=" . make_ubb_url("ubb=login", "", false) . "\" />",
					"user" => "",
					"Board" => "",
					"bypass" => 0,
					"onload" => "",
				),
				"template" => "badlogin",
				"data" => array(),
				"footer" => true,
				"location" => "",
				"redirect" => "",
			);
		}

		// --------------------------------------
		// Set a cookie or register a session var
		srand((double)microtime()*1000000);
		$newsessionid = md5(rand(0,32767));
		$autolog = md5("^^{$config['BOARD_KEY']}^^{$user['USER_ID']}{$user['USER_PASSWORD']}");

		if ($config['COOKIE_LIFETIME'] > 31536000) {
			$config['COOKIE_LIFETIME'] = 31536000;
		}
		// -------------------------------------------------------------------
		// If this is their first visit for this browser session, set a cookie
		if (!$laston) {
			$laston = $this->get_date();
		}

		if ($rememberme || get_input($config['COOKIE_PREFIX'] . "ubbt_hash", "cookie", null) != null) {
			$this->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_myid","{$user['USER_ID']}",time()+$config['COOKIE_LIFETIME']);
			$this->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_hash","$autolog",time()+$config['COOKIE_LIFETIME']);
		} else {
			$this->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_myid","{$user['USER_ID']}","0");
			$this->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_hash","$autolog","0");
		}

		$this->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_mysess","$newsessionid","0");
		$this->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_pass","",time()-3600);
		$this->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_dob","",time()-3600);

		// Check for multiple logins
		$myids = $myinfo['myids'];
		$multiple = false;
		if (empty($myids) && $Uid > 1) {
			$myids .= "-{$Uid}-";
		} // end if
		elseif (!stristr($myids,"-{$Uid}-") && $Uid > 1) {
			$multiple = true;
			$myids .= "-{$Uid}-";
		}
		$this->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_x",$myids,time()+$config['COOKIE_LIFETIME']);

		if ($multiple) {
			$idarray = explode("-",$myids);
			$inlist = "";
			$double_check = 0;
			foreach($idarray as $k => $v) {
				if (!is_numeric($v)) continue;
				$inlist .= "'$v',";
				$double_check++;
			} // end foreach
			$inlist = preg_replace("/,$/","",$inlist);

			// Make sure we have at least 2 identities
			if ($double_check > 1) {
				$profiles = "";
				$query = "
					select USER_ID,USER_DISPLAY_NAME
					from {$config['TABLE_PREFIX']}USERS
					where USER_ID in ($inlist)
				";
				$sth = $dbh->do_query($query,__LINE__,__FILE__);
				$double_check = 0;
				while(list($muid,$mdisplay) = $dbh->fetch_array($sth)) {
					$double_check++;
					$profiles .= "<a href='" . make_ubb_url("ubb=showprofile&User=$muid", $mdisplay, false) . "'>$mdisplay</a>, ";
				} // end while
				$profiles = preg_replace("/, $/","",$profiles);

				if ($double_check > 1) {

					$body = $this->substitute($ubbt_lang['MULTI_LOGIN_BODY'], array('IP' => find_environmental('REMOTE_ADDR'),'ACCOUNTS' => $profiles));

					$query = "
						select USER_ID
						from {$config['TABLE_PREFIX']}USER_PROFILE
						where USER_NOTIFY_MULTI = '1'
					";
					$sth = $dbh->do_query($query,__LINE__,__FILE__);
					while(list($sendto) = $dbh->fetch_array($sth)) {
						$this->send_message($config['MAIN_ADMIN_ID'],$sendto,$ubbt_lang['MULTI_LOGINS'],$body);
					} // end while
				} // end while
			} // end if
		} // end if

		$topicread = "";

		$date = $this->get_date();
		$query = "
			update	{$config['TABLE_PREFIX']}USER_DATA
			set	USER_LAST_VISIT_TIME   = ?
			where	USER_ID = ?
		";
		$dbh->do_placeholder_query($query,array($date,$user['USER_ID']),__LINE__,__FILE__);

		$query = "
			update	{$config['TABLE_PREFIX']}USERS
			set	USER_SESSION_ID = ?
			where	USER_ID = ?
		";
		$dbh -> do_placeholder_query($query,array($newsessionid,$user['USER_ID']),__LINE__,__FILE__);

		// ------------------------------------------
		// Get rid of their IP from the online table
		$ip = "-ANON-" . find_environmental('REMOTE_ADDR');
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}ONLINE
			WHERE  ONLINE_DISPLAY_NAME = ?
		";
		$dbh -> do_placeholder_query($query,array($ip),__LINE__,__FILE__);

		$userob->build_permissions($user['USER_ID']);
		rebuild_pm_count($user['USER_ID']);
		$userob->cache_watch_lists($user['USER_ID']);

		rebuild_islands(0,array("online"));

		// Now send them to the start_page function
		return $this->start_page($user['USER_ID'],$newsessionid,"",0,$from,$oncomplete);

	}

	// #######################################################################
	// Start_page - Sends the user to their start page
	// #######################################################################
	function start_page($myid="",$mysess="",$chosenlanguage="",$myhome="",$from="",$oncomplete="") {
		global $config,$dbh, $ubbt_lang, $myinfo,$debug, $smarty;

		// -----------------------------------------------------
		// Connect to db and get total posts and last logon, etc
		if ($mysess) { $myinfo['session'] = $mysess; }
		if ($myid) { $myinfo['id'] = $myid; }


		$userob = new user;
		$user = $userob->authenticate("USER_START_VIEW");
		list($start_view,$CheckUser,$pass,$sessionid,$status,$privates,$Uid) = $user;

		if ($config['BOARD_IS_CLOSED'] && $user['USER_MEMBERSHIP_LEVEL'] != "Administrator") {
			$insert = @file("{$config['FULL_PATH']}/includes/closedforums.php");
			if (!is_array($insert)) {
				$insert = @file("{$config['BASE_URL']}/includes/closedforums.php");
			}

			if ($insert) {
				$closedforums = implode('',$insert);
				$smarty->assign("closedforums",$closedforums);
			}

			$this->not_right($closedforums);
		}

		// If we don't a UID back then the authentication failed
		if (!$user['USER_ID']) {
			$this->not_right($ubbt_lang['NO_AUTH']);
		}

		if ($start_view == "lists") {
			$main = "myhome&type=lists";
		} else {
			$main = "cfrm";
		}

		if ($from == "cp") {
			$main = "admin/login.php";
		}

		$redirect = "";
		if($oncomplete && oncomplete_validate($oncomplete)) {
			$redirect = $oncomplete;
			$main = "";
		} // end if

		if (strpos($from, "http") !== false) {
			header("Location: " . str_replace('&amp;', '&', $from));
			exit;
		}

		if ($from) {
			$redirect = $from;
			$main = "";
		}


		return array(
			"template" => "",
			"footer" => false,
			"location" => "$main",
			"login" => true,
			"redirect" => "",
			"http_redirect" => "$redirect",
		);
	}

	// #################################
	// Check if a user is still banned
	// ###############################
	function check_ban($uid="",$timeoffset,$timeformat) {

		global $config, $dbh, $ubbt_lang, $smarty;
		require_once("{$config['FULL_PATH']}/libs/triggers.inc.php");
		$expires = trigger_ban_expiration();

		if (isset($expires[$uid])) {
			return;
		}

		$query = "
			select t1.BAN_EXPIRATION,t1.BAN_REASON,t2.USER_LANGUAGE
			from {$config['TABLE_PREFIX']}BANNED_USERS as t1,
			{$config['TABLE_PREFIX']}USER_PROFILE as t2
			where t1.USER_ID = ?
			and t2.USER_ID = t1.USER_ID
		";
		$sth = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
		list ($expires,$reason,$language) = $dbh->fetch_array($sth);
		define ('IS_BANNED',1);
		if (!$language) $language = $config['LANGUAGE'];
		require_once("{$config['FULL_PATH']}/languages/{$language}/generic.php");
		$smarty->assign_by_ref('lang',$ubbt_lang);
		if (!$expires) {
			$extra_text = $ubbt_lang['BAN_PERM'];
		} else {
			$expires = $this->convert_time($expires,$timeoffset,$timeformat);
			$extra_text = $this->substitute($ubbt_lang['BAN_EXPIRES'], array('EXPIRES' => $expires));
		}
		if ($reason) $reason = "<br /><br />$reason";
		$this -> not_right("{$ubbt_lang['YOU_BANNED']} $extra_text{$reason}",0);
	}


	// #######################################################################
	// Create the icon selection list
	// #######################################################################
	function icon_select($icon="") {

		global $smarty, $ubbt_lang, $config,$debug,$style_array;

		if (!$icon) { $icon = "book.gif"; }
		@list($selected,$extra) = @preg_split("#\.#",$icon);
		${$selected} = " checked=\"checked\"";
		$iconlist = "";

		// ------------------------------------------
		// We now load the entire directory of images
		$dir = opendir("{$config['FULL_PATH']}/images/{$style_array['icons']}");
		$i=0;
		while( ($file = readdir($dir)) != false) {
			if ( ($file == ".") || ($file == "..") || ($file == "image.gif") ) {
				continue;
			}
			if (!preg_match("/\.(?:gif|jpg|png)/",$file)) {
				continue;
			}
			$filename = preg_replace("/\.(.*?)$/","",$file);
			if (!isset(${$filename})) {
				${$filename} = "";
			}
			if ($filename == "blank") { continue; }
			$iconlist .= "<input type=\"radio\" name=\"Icon\" id=\"Icon-$file\" value=\"$file\" ${$filename} /><label for=\"Icon-$file\"><img src=\"{$config['BASE_URL']}/images/{$style_array['icons']}/$file\" alt=\"$filename\" title=\"$filename\" /></label>&nbsp;";
			$i++;
			if ($i==12) {
				$iconlist .= "<br />";
				$i=0;
			}
		}
		$selected = "";
		if ($icon == "blank.gif"){
			$selected = " checked=\"checked\"";
		}
		$iconlist .= "<input type=\"radio\" name=\"Icon\" id=\"Icon-blank.gif\" value=\"blank.gif\" $selected /><label for=\"Icon-blank.gif\"><span class=\"small\">{$ubbt_lang['NO_ICON']}</span></label>&nbsp;";

		$smarty->assign('iconlist',$iconlist);

		return $smarty->fetch('icon_select.tpl');
	}


	// #######################################################################
	//  Send_messages
	// #######################################################################
	function send_message($Sender="",$To="",$Subject="",$Mess="",$Group="",$RawBody="") {

		global $ubbt_lang,$dbh, $config;
		$date      = $this -> get_date();

		if (!$RawBody) $RawBody = $Mess;

		$mailer = new mailer();

		// Find out if we are sending to a group of users
		$admin_q = "Administrator";
		$mod_q   = "%Moderator";
		$user_q  = "User";
		$To_q = $To;

		if ($Group == "ADMIN_GROUP") {
			$selector = "AND t1.USER_MEMBERSHIP_LEVEL = '$admin_q'";
		}
		elseif ($Group == "MODERATOR_GROUP") {
			$selector = "AND t1.USER_MEMBERSHIP_LEVEL LIKE '$mod_q'";
		}
		elseif ($Group == "A_M_GROUP") {
			$selector = "AND (t1.USER_MEMBERSHIP_LEVEL = '$admin_q' OR t1.USER_MEMBERSHIP_LEVEL LIKE '$mod_q')";
		}
		elseif ($Group == "ALL_USERS") {
			$selector = "";
		}
		else {
			$selector = "AND t1.USER_ID = '$To_q'";
		}

		// ------------------------------------
		// Grab everyone we are sending this to
		$query = "
			SELECT DISTINCT t1.USER_DISPLAY_NAME, t1.USER_MEMBERSHIP_LEVEL,t1.USER_ID,t2.USER_NOTIFY_ON_PM,t2.USER_REAL_EMAIL,t2.USER_LANGUAGE
			FROM {$config['TABLE_PREFIX']}USERS as t1,
			{$config['TABLE_PREFIX']}USER_PROFILE as t2
			where t1.USER_ID=t2.USER_ID
			$selector
		";
		$sth = $dbh -> do_query($query,__LINE__,__FILE__);
		while (list($To,$Status,$Number,$Notify,$Email,$Lang) = $dbh -> fetch_array($sth)) {

			// Increment the recipients total number of unread pms
			$query = "
				update	{$config['TABLE_PREFIX']}USER_PROFILE
				set	USER_TOTAL_PM = USER_TOTAL_PM + 1
				where	USER_ID = ?
			";
			$dbh -> do_placeholder_query($query,array($Number),__LINE__,__FILE__);

			$query_vars = array($date,0,$Subject,$Sender,$date);
			$query = "
				INSERT INTO {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS
				(TOPIC_TIME,TOPIC_REPLIES,TOPIC_SUBJECT,USER_ID,TOPIC_LAST_REPLY_TIME)
				values
				( ? , ? , ? , ? , ? )
			";
			$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
			$query = "
				select last_insert_id()
			";
			$sth=$dbh->do_query($query,__LINE__,__FILE__);
			list($message_id) = $dbh->fetch_array($sth);

			$query_vars = array($message_id,$Sender,$Mess,$date,$RawBody);
			$query = "
				insert into {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
				(TOPIC_ID,USER_ID,POST_BODY,POST_TIME,POST_DEFAULT_BODY)
				values
				( ? , ? , ? , ? , ?)
			";
			$dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

			$query_vars = array($message_id,$Number, 0);
			$query = "
				insert into {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
				(TOPIC_ID,USER_ID,MESSAGE_LAST_READ)
				values
				( ? , ? , ?)
			";
			$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

			if ($Notify == "yes") {
				$mailer->set_language($Lang);
				$mailer->set_subject('PMN_SUBJECT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
				$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $To));
				$mailer->add_content('PMN_CONTENT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE'], 'FROMNAME' => $ubbt_lang['UBB_SYSTEM']));
				$mailer->add_content('PMN_CONTENT1', array('PM_URL' => make_ubb_url("ubb=viewmessage&message=$message_id&gonew=1" ,"", true, true)), true);
				$mailer->add_content('PMN_CONTENT2', array(), true);
				$mailer->add_post($ubbt_lang['UBB_SYSTEM'],$Subject,array(),$Mess,$RawBody);
				$mailer->ubbt_mail($Email);
			} // end if
		}
		$dbh -> finish_sth($sth);
	}

	function create_text_editor($name="",$value="",$tabindex="",$allow_images=true,$allow_media=true) {
		global $config,$smarty,$ubbt_lang,$user,$dbh, $style_array, $bbcode_tags;

		// --------------------------------------------------
		// We need to grab all of the graemlins out of the db

		if (count($this->graemlins) == 0) {
			$this->get_graemlins();
		}

		$i=0;
		$graemlinlist="";
		$altcode = "";
		$n = 0;
		$more_smilies = false;
		foreach ($this->graemlins as $graemlin) {
			$code = $graemlin['GRAEMLIN_MARKUP_CODE'];
			$smiley = $graemlin['GRAEMLIN_SMILEY_CODE'];
			$image = $graemlin['GRAEMLIN_IMAGE'];

			if (stristr("$code","$")) {
				@eval("\$code = $code;");
			}
			$code = ":$code:";
			$altcode = "$code";
			if ($smiley) {
				$smiley = addslashes($smiley);
				$code = $smiley;
				$altcode .= "     $smiley";
			}

			$graemlinlist .= <<<EOF
<a href="javascript:void(0)" onclick="insertAtCaret(document.replier.{$name}, ' $code'); showHideElement('smileys','hide'); document.replier.{$name}.focus();"><img src="{$config['BASE_URL']}/images/{$style_array['graemlins']}/$image" border="0" alt="$altcode" title="$altcode" /></a>&nbsp;
EOF;
			$n++;
			$i++;
			if ($i == 8) {
				$i=0;
				$graemlinlist .= "<br />";
			}

			if ($config['SHOW_ALL_GRAEMLINS'] != '1' && $user['USER_SHOW_ALL_GRAEMLINS'] != '1') {
				if ($n == 18) {
					$more_smilies = true;
					break;
				}
			}
		}
		$font_families = "";
		foreach($config['MARKUP_FONTS'] as $k => $font) {
			$font_families .= <<<EOF
<div id="font_$k" onmouseover="litSelection(this.id);" onmouseout="unlitSelection(this.id);" class="markup_panel_unselect_text" onmousedown="fontFamily('$font'); " style="cursor: pointer; font-family: $font;">$font</div>
EOF;
		} // end foreach

		$font_sizes = "";
		foreach($config['MARKUP_FONT_SIZES'] as $k => $size) {
			$font_sizes .= <<<EOF
<div id="size_$k" onmouseover="litSelection(this.id);" onmouseout="unlitSelection(this.id);" class="markup_panel_unselect_text" onmousedown="formatText('[size:$size]','[/size]'); " style="cursor: pointer; font-size: $size;">$size</div>
EOF;
		} // end foreach

		include("{$config['FULL_PATH']}/languages/{$user['USER_LANGUAGE']}/standard_text_editor.php");

		// Create the syntax highlighter dropdown
		//
		// Note: we will hardwire certain extensions regardless:
		//
		// css, php, text, html (html4strict), javascript, sql
		$fixed = array(
			'' => 'text',
			':css' => 'css',
			':html' => 'html4strict',
			':php' => 'php',
			':sql' => 'sql',
			':js' => 'javascript'
		);

		$se = "";
		foreach ($fixed as $alias => $ext) {
			$se_drop .= '<div onmouseover="litSelection(this.id);" onmouseout="unlitSelection(this.id);" class="markup_panel_unselect_text"
							onmousedown="formatText(\'[code'.$alias.']\',\'[/code]\');">[code'.$alias.']'.$ubbt_lang['CODE_MENU_CODE'].'[/code]</div>';
		}

		// Now fill up the drop down with additional languages, if any
		$num = 0;
		foreach ($config['SYNTAX_ENGINES'] as $type) {
			if (!in_array($type, $fixed)) {
				if ($num == 0) {
					$se_drop .= '<div class="markup_panel_unselect_text"><hr /></div>';
				}
				$se_drop .= '<div onmouseover="litSelection(this.id);" onmouseout="unlitSelection(this.id);" class="markup_panel_unselect_text"
							onmousedown="formatText(\'[code:'.$type.']\',\'[/code]\');">[code:'.$type.']'.$ubbt_lang['CODE_MENU_CODE'].'[/code]</div>';
				$num++;
			}
		}

		// Do the Custom tag dance and only include those that have the 'show' set to 1
		if (sizeof($bbcode_tags) > 0 && $allow_media == true) {
			$bbcode_drop_nr = 0;
			$bbcode_drop = '<div id="bbcode-drop" class="markup_panel_popup" style="display: none; width:auto; height:200px; font-weight: normal; white-space: nowrap; overflow: auto;">';
			foreach ($bbcode_tags as $k => $type) {
				if ($type['show'] == 1) {
					$bbcode_drop .= <<<BLEH
<div id="bbcode_{$k}" onmouseover="litSelection(this.id);" onmouseout="unlitSelection(this.id);" class="markup_panel_unselect_text" onclick="DoPrompt('bbcode','{$type['prompt']}','{$type['open']}','{$type['close']}');" style="cursor: pointer;">{$type['descrip']}</div>
BLEH;
					$bbcode_drop_nr++;
				}
			}
			$bbcode_drop .= '</div>';
			if (!$bbcode_drop_nr) $bbcode_drop = '';
		} else {
			$bbcode_drop = '';
		}

		$smarty->assign_by_ref("font_families",$font_families);
		$smarty->assign_by_ref("font_sizes",$font_sizes);
		$smarty->assign("bbcode_drop",$bbcode_drop);
		$smarty->assign("name",$name);
		$smarty->assign("value",$value);
		$smarty->assign("tabindex",$tabindex);
		$smarty->assign("allow_images",$allow_images);
		$smarty->assign("more_smilies",$more_smilies);
		$smarty->assign_by_ref("smileys",$graemlinlist);
		$smarty->assign("code_drop",$se_drop);
		$smarty->assign_by_ref("lang",$ubbt_lang);
		$text_editor = $smarty->fetch("standard_text_editor.tpl");

		return $text_editor;

	} // end function

	// Language string replacement utility
	//
	// $html->substitute($ubbt_lang['LANG_IDENTITY'], array('EMAIL_ADDY' => $email, 'BOARD_ADDY' -> $board, etc));
	function substitute($string, $replacements) {
		// Probably not the fastest thing in the world....
		$finds = array();
		foreach(array_keys($replacements) as $str) { $finds[] = "%%{$str}%%"; }

		$string = str_replace($finds, array_values($replacements), $string);

		return $string;
	}

	// Takes a regular username and colorizes it, based upon whethere they have a color
	// defined or they are one of the special ones with a group color
	function user_color($username, $usercolor="", $userlevel) {
		$localname = $username;
		if ($usercolor) {
			$localname = "<span style='color: $usercolor'>$username</span>";
		} else {
			switch ($userlevel) {
				case 'Administrator':
					$localname = "<span class='adminname'>$username</span>";
					break;
				case 'GlobalModerator':
					$localname = "<span class='globalmodname'>$username</span>";
					break;
				case 'Moderator':
					$localname = "<span class='modname'>$username</span>";
					break;
			}
		}
		return $localname;
	}

	// Takes a user's status and returns their status indicator, if applicable
	function user_status($uid,$images,$modcheck) {
		global $config, $style_array, $ubbt_lang, $dbh;
		if (empty($this->group_images)) {
			$query = "
				select GROUP_ID,GROUP_IMAGE
				from {$config['TABLE_PREFIX']}GROUPS
			";
			$sth = $dbh->do_query($query,__LINE__,__FILE__);
			while(list($gid,$gimage) = $dbh->fetch_array($sth)) {
				$this->group_images[$gid] = $gimage;
			} // end while
		} // end if
		$image_array = unserialize($images);
		$src = "";
		foreach($image_array as $k => $v) {
			if ($v == 3 && !strstr($modcheck,",{$uid},")) continue;
			$src .= "<img src='{$config['BASE_URL']}/images/groups/{$this->group_images[$v]}' />";
		} // end foreach

		return $src;
	}

	// Cuts a string to the length of $length and replaces the last characters
	// with the ending if the text is longer than length.
	function truncate($text, $length = 200, $ending = ' (...)', $exact = false, $isHtml = true) {
  	if ($isHtml) {
    	// if the plain text is shorter than the maximum length, return the whole text
      if (strlen(preg_replace('/<.*?>/', '', $text)) <= $length) {
          return $text;
      }

      // splits all html-tags to scanable lines
      preg_match_all('/(<.+?>)?([^<>]*)/s', $text, $lines, PREG_SET_ORDER);

      $total_length = strlen($ending);
      $open_tags = array();
      $truncate = '';

      foreach ($lines as $line_matchings) {
          // if there is any html-tag in this line, handle it and add it (uncounted) to the output
          if (!empty($line_matchings[1])) {
              // if it's an "empty element" with or without xhtml-conform closing slash (f.e. <br/>)
              if (preg_match('/^<(\s*.+?\/\s*|\s*(img|br|input|hr|area|base|basefont|col|frame|isindex|link|meta|param)(\s.+?)?)>$/is', $line_matchings[1])) {
                  // do nothing
              // if tag is a closing tag (f.e. </b>)
              } else if (preg_match('/^<\s*\/([^\s]+?)\s*>$/s', $line_matchings[1], $tag_matchings)) {
                  // delete tag from $open_tags list
                  $pos = array_search($tag_matchings[1], $open_tags);
                  if ($pos !== false) {
                      unset($open_tags[$pos]);
                  }
              // if tag is an opening tag (f.e. <b>)
              } else if (preg_match('/^<\s*([^\s>!]+).*?>$/s', $line_matchings[1], $tag_matchings)) {
                  // add tag to the beginning of $open_tags list
                  array_unshift($open_tags, strtolower($tag_matchings[1]));
              }
              // add html-tag to $truncate'd text
              $truncate .= $line_matchings[1];
          }

          // calculate the length of the plain text part of the line; handle entities as one character
          $content_length = strlen(preg_replace('/&[0-9a-z]{2,8};|&#[0-9]{1,7};|&#x[0-9a-f]{1,6};/i', ' ', $line_matchings[2]));
          if ($total_length+$content_length > $length) {
              // the number of characters which are left
              $left = $length - $total_length;
              $entities_length = 0;
              // search for html entities
              if (preg_match_all('/&[0-9a-z]{2,8};|&#[0-9]{1,7};|&#x[0-9a-f]{1,6};/i', $line_matchings[2], $entities, PREG_OFFSET_CAPTURE)) {
                  // calculate the real length of all entities in the legal range
                  foreach ($entities[0] as $entity) {
                      if ($entity[1]+1-$entities_length <= $left) {
                          $left--;
                          $entities_length += strlen($entity[0]);
                      } else {
                          // no more characters left
                          break;
                      }
                  }
              }
              $truncate .= substr($line_matchings[2], 0, $left+$entities_length);
              // maximum length is reached, so get off the loop
              break;
          } else {
              $truncate .= $line_matchings[2];
              $total_length += $content_length;
          }

          // if the maximum length is reached, get out of loop
          if($total_length >= $length) {
              break;
          }
				}
			} else {
       		if (strlen($text) <= $length) {
                return $text;
            } else {
                $truncate = substr($text, 0, $length - strlen($ending));
            }
        }

    // if the words shouldn't be cut in the middle...
		if (!$exact) {            									// ...search the last occurance of a space...
			$spacepos = strrpos($truncate, ' ');
			if (isset($spacepos)) {		                // ...and cut the text in this position
				$truncate = substr($truncate, 0, $spacepos);
			}
		}

    // add the defined ending to the text
		$truncate .= $ending;

    if($isHtml) {            										// close all unclosed html-tags
    	foreach ($open_tags as $tag) {
      	$truncate .= '</' . $tag . '>';
        }
      }
		return $truncate;
  }

  // Generates the left Nav information for the 'My Stuff' option
  function mystuff() {
		global $config, $user, $dbh, $style_array, $ubbt_lang;

		// Only give them stuff, if their profile wants it
		if ($user['USER_SHOW_LEFT_MYSTUFF'] == 0) {
			$stuff = "";
		} else {

			// Do the Title / CustomTitle dance, then colorize
			if ($user['USER_CUSTOM_TITLE'] && $config['ONLY_CUSTOM']) {
				$upTitle = $user['USER_CUSTOM_TITLE'];
			} else {
				$upTitle = $user['USER_TITLE'] . '<br />' . $user['USER_CUSTOM_TITLE'];
			}
			$uName = $this->user_color($user['USER_DISPLAY_NAME'],$user['USER_NAME_COLOR'],$user['USER_MEMBERSHIP_LEVEL']);
			if ($user['USER_AVATAR']) {
				$upAvatar = "<img src=\"{$user['USER_AVATAR']}\" />";
			} else {
				$upAvatar = '<br /><img border="1" src="' . $config['BASE_URL'] . '/images/' . $style_array['general'] . '/blank.gif" height="64" width="64" /><br />';
			}

			$ulStyle = 'style="padding: 2px 0px 2px 16px;"';

			$stuff = "<center>$uName<br />$upAvatar<br />$upTitle</center><hr />{$ubbt_lang['MY_SPACE']}";

			$stuff .= "<ul $ulStyle><li><a href=\"" . make_ubb_url("ubb=editbasic", "", false) . "\">{$ubbt_lang['EDIT_PROF']}</a></li>";
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=editdisplay", "", false) . "\">{$ubbt_lang['EDIT_DISPLAY']}</a></li>";
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=showprofile&User={$user['USER_ID']}", "", false) . "\">{$ubbt_lang['VIEW_PROF']}</a></li>";
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=userposts&id={$user['USER_ID']}", "", false) . "\">{$ubbt_lang['MY_POSTS']}</a></li>";
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=viewmessages", "", false) . "\">{$ubbt_lang['MY_PRIVATES']}</a></li></ul>";

			$stuff .= "<ul $ulStyle><li><a href=\"" . make_ubb_url("ubb=myhome&tab=forums", "", false) . "\">{$ubbt_lang['MY_WATCH_F']}</a></li>";
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=myhome&tab=topics", "", false) . "\">{$ubbt_lang['MY_WATCH_T']}</a></li>";
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=myhome&tab=users", "", false) . "\">{$ubbt_lang['MY_WATCH_U']}</a></li></ul><ul $ulStyle>";

			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=mybuddies", "", false) . "\">{$ubbt_lang['MY_BUDDIES']}</a></li>";
			if ($config['MY_FEEDS']) {
				$stuff .= "<li><a href=\"" . make_ubb_url("ubb=myfeeds&show=1", "", false) . "\">{$ubbt_lang['MY_FEEDS']}</a></li>";
			}
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=subscriptions", "", false) . "\">{$ubbt_lang['MY_SUBS']}</a></li>";
			$stuff .= "<li><a href=\"" . make_ubb_url("ubb=mycookies", "", false) . "\">{$ubbt_lang['MYCOOKIES']}</a></li></ul>";
		}
		return $stuff;
	}

	function utf8_wordwrap($str, $width, $break, $cut = false) {
		if (!$cut) {
			$regexp = '#^(?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){'.$width.',}\b#U';
		} else {
			$regexp = '#^(?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){'.$width.'}#';
		}
		if (function_exists('mb_strlen')) {
			$str_len = mb_strlen($str,'UTF-8');
		} else {
			$str_len = preg_match_all('/[\x00-\x7F\xC0-\xFD]/', $str, $var_empty);
		}
		$while_what = ceil($str_len / $width);
		$i = 1;
		$return = '';
		while ($i < $while_what) {
			preg_match($regexp, $str,$matches);
			$string = $matches[0];
			$return .= $string.$break;
			$str = substr($str, strlen($string));
			$i++;
		}
		return $return.$str;
	} // end function utf8_wordwrap
}

?>
