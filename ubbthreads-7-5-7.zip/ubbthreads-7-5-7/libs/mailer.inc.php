<?php

//	Script Version 7.5.7

if(!defined("UBB_MAIN_PROGRAM")) exit;

class mailer extends PHPMailer {
	var $lang;
	var $header = array('t' => '', 'h' => '');
	var $salute = array('t' => '', 'h' => '');
	var $content = array('t' => '', 'h' => '');
	var $posts = array('t' => '', 'h' => '');
	var $numposts = 0;
	var $footer = array('t' => '', 'h' => '');
	var $tpl = array('t' => 'email_text.tpl', 'h' => 'email_html.tpl');
	var $graemlins;
	var $style = array();
	var $admin = "";

	// The constructor
	function mailer($dotdot="") {
		global $config,$html,$ubbt_lang,$dbh;

		$this->lang = $config['LANGUAGE'];
		$this->admin = $dotdot;

		if (defined('IS_ADMIN')) $dotdot = "../";

		$test = @include_once("{$dotdot}languages/{$this->lang}/mailer.php");
		// If we didn't find the language file then give an error.
		if (!$test) {
			$err = "FATAL ERROR: Unable to find '{$config['BASE_URL']}/languages/{$this->lang}/mailer.php' language file.  Please notify the administrator.";
			$html->not_right($err);
		} else {
			$this->set_header('EMAIL_HEADER');
			$this->set_footer('EMAIL_FOOTER');
		}
		// Grab the default style crap that we need
		$style_imgs = array();
		$style_vars = array();
		$query = "
			SELECT STYLE_IMG, STYLE_VARS
				FROM {$config['TABLE_PREFIX']}STYLES
			WHERE STYLE_ID = {$config['DEFAULT_STYLE']}
		";
		$sth = $dbh->do_query($query,__LINE__,__FILE__);
		list($imgs, $vars) = $dbh->fetch_array($sth);
		$style_imgs = unserialize($imgs);
		$style_vars = unserialize($vars);

		// Now only grab the crap we want and format the css classes for inline styles
		$this->graemlins = $config['FULL_URL'] . '/images/' . $style_imgs['graemlins'];
		$this->style['body'] = 'style="' . preg_replace('/\s/', ' ', $style_vars['.email-body']) .'" ';
		$this->style['header'] = 'style="' . preg_replace('/\s/', ' ', $style_vars['.email-header']) .'" ';
		$this->style['tdheader'] = 'style="' . preg_replace('/\s/', ' ', $style_vars['.email-tdheader']) .'" ';
		$this->style['tdbody'] = 'style="' . preg_replace('/\s/', ' ', $style_vars['.email-tdbody']) .'" ';
		$this->style['footer'] = 'style="' . preg_replace('/\s/', ' ', $style_vars['.email-footer']) .'" ';
	}

	// Check if new language and if it's different than what we already have, set it and include it.
	function set_language($lang) {
		global $config,$ubbt_lang;

		if ($this->lang != $lang) {
			$test = @include_once("{$this->admin}languages/{$lang}/mailer.php");

			// If we found one, save it. Otherwise, we'll just not error and at least keep the working one.
			if ($test) {
				$this->lang = $lang;
				$this->set_header('EMAIL_HEADER');
				$this->set_footer('EMAIL_FOOTER');
			}
		}
		// Regardless, since we are being called it's a good idea to start fresh with content
		$this->content['t'] = '';
		$this->content['h'] = '';
		$this->numposts = 0;
		$this->posts = array('t' => '', 'h' => '');
	}

	// Local function that substitutes for %%BLABLA%% into the supplied wordlet
	function set_string($langKey, $subs, &$which, $dualmode=false,$append=true) {
		global $ubbt_lang,$html;

		$langT = $dualmode ? $langKey.'_TEXT' : $langKey;
		$langH = $dualmode ? $langKey.'_HTML' : $langKey;

		// Do the substitute(s) and also be very lenient on converting <br /> to newlines. Too many n00b Html'ers
		if ($append) {
			$which['t'] .= preg_replace("/\<br\s*\/?\>/i", "\n", $html->substitute($ubbt_lang[$langT], $subs));
			$which['h'] .= $html->substitute($ubbt_lang[$langH], $subs);
		} else {
			$which['t'] = preg_replace("/\<br\s*\/?\>/i", "\n", $html->substitute($ubbt_lang[$langT], $subs));
			$which['h'] = $html->substitute($ubbt_lang[$langH], $subs);
		}
	}

	// Local function that returns a smarty'd result
	function do_smarty($type) {
		global $smarty;

		$smarty->assign("salute",$this->salute[$type]);
		$smarty->assign("content",$this->content[$type]);
		$smarty->assign("header",$this->header[$type]);
		$smarty->assign("footer",$this->footer[$type]);
		$smarty->assign("stylebody",$this->style['body']);
		$smarty->assign("styleheader",$this->style['header']);
		$smarty->assign("stylefooter",$this->style['footer']);
		$smarty->assign("styletdheader",$this->style['tdheader']);
		$smarty->assign("styletdbody",$this->style['tdbody']);

		if ($this->numposts > 0) {
			$smarty->assign("posts",$this->posts[$type]);
		} else {
			$smarty->assign("posts","");
		}
		return $smarty->fetch($this->tpl[$type]);
	}

	// Set the subject of the email.
	//		note: sets the phpmailer Subject directly
	function set_subject($langKey,$subs) {
		global $html,$ubbt_lang;

		$this->Subject = $html->substitute($ubbt_lang[$langKey],$subs);
	}

	// Salutation. Typically: "Hi username,"
	function set_salute($langKey,$subs) {
		$this->set_string($langKey,$subs,$this->salute,false,false);
	}

	// Content
	function add_content($langKey,$subs,$dualmode=false,$append=true) {
		$this->set_string($langKey,$subs,$this->content,$dualmode,$append);
	}

	// For repeaters (ie: posts and pms)
	function add_post($postername,$subject,$posttime=array(),$htmlbody,$textbody,$attachments=array(),$pm=false) {
		global $config,$ubbt_lang;

		// Top line: poster: subject ----- time
		$this->posts['t'][$this->numposts]['subject'] = $postername . ': ' . $subject;
		$this->posts['h'][$this->numposts]['subject'] = $postername . ': ' . $subject;
		// Check if a time will apply here first
		if (sizeof($posttime) > 0) {
			if ($posttime[1]) {	$posttime[0] = $posttime[0] + ( $posttime[1] * 3600 ); }
			$this->posts['t'][$this->numposts]['time'] = date($posttime[2],$posttime[0]);
			$this->posts['h'][$this->numposts]['time'] = date($posttime[2],$posttime[0]);
		} else {
			$this->posts['t'][$this->numposts]['time'] = '';
			$this->posts['h'][$this->numposts]['time'] = '';
		}

		// Body is something special
		//
		// Need to clean up <<GRAEMLIN_URL>>, ubbcode-*, attachments. Not as much work for
		// 	text based dudes, but some work still the same.
		$body_h = str_replace( "<<GRAEMLIN_URL>>", $this->graemlins, $htmlbody );
		$body_h = str_replace( 'class="ubbcode-block"','', $body_h );
		$body_h = str_replace( 'class="ubbcode-header"', "{$this->style['tdheader']}", $body_h );
		$body_h = str_replace( 'class="ubbcode-body"', "{$this->style['tdbody']}", $body_h );

		$body_t = $textbody;

		// Bang in attachments. Note that gallery attachments are the thumbnails
		if (sizeof($attachments) > 0) {
			$body_h .= $ubbt_lang['EMAIL_ATTACH'];
			$body_t .= preg_replace("/\<br\s*\/?\>/i", "\n", $ubbt_lang['EMAIL_ATTACH']);
			for ($i=0; $i<sizeof($attachments); $i++) {
				if ($attachments[$i]['inline'] == true) {
					$body_h .= "<img src=\"{$attachments[$i]['url']}\" /><br />{$ubbt_lang['EMAIL_ATTACH_DESC']}{$attachments[$i]['caption']}<br />";
				} else {
					$body_h .= "<a href=\"{$attachments[$i]['url']}\" />{$attachments[$i]['original']}</a><br />{$ubbt_lang['EMAIL_ATTACH_DESC']}{$attachments[$i]['caption']}<br />";
				}
				$body_t .= "{$attachments[$i]['url']}\n{$ubbt_lang['EMAIL_ATTACH_DESC']}{$attachments[$i]['caption']}\n";
			}
		}
		$this->posts['h'][$this->numposts]['body'] .= $body_h;
		$this->posts['t'][$this->numposts]['body'] .= $body_t;

		// Let them know we have some posts to include on the backend
		$this->numposts++;
	}

	// Content raw html append
	function add_html_content($html) {
		$this->content['h'] .= $html;
	}

	// Content raw text append
	function add_text_content($text) {
		$this->content['t'] .= $text;
	}

	// The email header. Might be something as simple as 'Do not reply..'
	function set_header($langKey,$subs) {
		$this->set_string($langKey,$subs,$this->header,true);
	}

	// Footer. Typically the disclaimer and other crap to make an email
	// more palatable to the email spam blockers
	function set_footer($langKey,$subs) {
		$this->set_string($langKey,$subs,$this->footer,true);
	}

	// Most of the callers won't need to use this. In the event that there is
	// a special template required, this is here.
	function set_template($tpl) {
		$tpl['h'] = 'email_html_'.$tpl.'.tpl';
		$tpl['t'] = 'email_text_'.$tpl.'.tpl';
	}

	// This baby takes all of what is setup and does the emailing deed.
	//
	// Note: we are building both text and html versions and will send
	// both. The email client will determine which one it wants to view.
	function ubbt_mail($to,$from=array(),$noreply=true,$bcc=array()) {
		global $config;

		if ($to || sizeof($bcc) > 0) {
			$this->AddAddress($to);

			// Either use the site's info or specifically supplied info
			if ($from) {
				$this->From = $from['email'];
				$this->FromName = $from['username'];
			} else {
				$this->From = $config['SITE_EMAIL'];
				$this->FromName = $config['COMMUNITY_TITLE'];
			}

			$this->Sender = $config['SITE_EMAIL'];
			if ($noreply == false) {
				$this->AddReplyTo = $config['SITE_EMAIL'];
			}

			// Are we using an SMTP server?
			if ($config['SMTP']) {
				$this->IsSMTP();
				$this->Host = "{$config['SMTP']}";
			}

			// Create the parallel bodys
			$this->Body = $this->do_smarty('h');
			$this->AltBody = $this->do_smarty('t');

			// Are we pumping out blind copys?
			for($i=0; $i<sizeof($bcc); $i++) {
				$this->AddBCC($bcc[$i]);
			}

			/*if (1) {
				// Just take a peeky locally for quick debug
				$fh = fopen("{$this->admin}libs/email.html", 'w') or die("can't open file");
				fwrite($fh, $this->Body);
				fclose($fh);
				$fh = fopen("{$this->admin}libs/email.txt",'w') or die("can't open file");
				fwrite($fh, $this->AltBody);
				fclose($fh);
			} else*/
			$this->Send();
		}

		// Clean up after ourselves and bail :)
		$this->ClearAddresses();
		$this->ClearAttachments();
	}

}

?>
