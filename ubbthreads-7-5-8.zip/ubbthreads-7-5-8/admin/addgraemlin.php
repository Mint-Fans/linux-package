<?php
//	Script Version 7.5.8

require("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/addgraemlin.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$tabs = array(
	"{$ubbt_lang['ADD_NEW']}" => ""
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['IM_IC']);
$admin->setParentTitle($ubbt_lang['IM_IC'],"graemlins_display.php");
$admin->setPageTitle($ubbt_lang['ADD_NEW']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/addgraemlin.tmpl");

$admin->sendFooter();
?>