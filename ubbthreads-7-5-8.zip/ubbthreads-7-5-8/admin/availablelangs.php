<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/availablelangs.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();


// -------------------------------------------------
// Grab all of the current languages in the database
$query = "
	SELECT LANGUAGE_TYPE,LANGUAGE_DESCRIPTION,LANGUAGE_IS_ACTIVE
	FROM {$config['TABLE_PREFIX']}LANGUAGES
";
$sth = $dbh -> do_query($query,__LINE__,__FILE__);
while (list($language,$description,$active) = $dbh -> fetch_array($sth)) {
	$langarray[$language]['description'] = $description;
	if ($active) {
		$langarray[$language]['active'] = "checked='checked'";
	}
}

$dir = opendir("{$config['FULL_PATH']}/languages");
$i=0;
while ($file = readdir($dir)) {
	if ($file == "." || $file == ".." || $file == "README" || $file == "update" ) { continue; }
	$langs[$i] = $file;
	$i++;
}
sort ($langs);
closedir($dir);
$langsize = sizeof($langs);

$langlist = "";
$langselect = "";
if (!$config['LANGUAGE']) {
	$config['LANGUAGE'] = "english";
}

for ( $i=0; $i<$langsize;$i++) {
	$checked = "";
	$default = "";
	$default2 = "";
	if ($config['LANGUAGE'] == $langs[$i]) {
		$default = "checked=\"checked\"";
		$default2 = "selected=\"selected\"";
	}
	$langselect .= "<option $default2>$langs[$i]</option>";
	$langlist .= "<tr><td class=\"stdautorow autotop colored-row\"><input type=\"radio\" name=\"default\" value=\"{$langs[$i]}\" $default /></td>";
	$langlist .= "<td class=\"stdautorow autotop colored-row\"><input type=\"checkbox\" name=\"active$langs[$i]\" value=\"1\" {$langarray[$langs[$i]]['active']} /></td>";
	$langlist .= "<td class=\"stdautorow autotop colored-row\">$langs[$i]</td>";
	$langlist .= "<td class=\"stdautorow autotop colored-row\"><input type=\"text\" size=\"50\" name=\"desc$langs[$i]\" class=\"formboxes\" value=\"". $langarray[$langs[$i]]['description'] ."\" /></td>";
	$langlist .= "<td class=\"autotop\">&nbsp;</td></tr>";
	unset($langarray[$langs[$i]]);
}

while(list($key,$value) = each($langarray)) {
	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}LANGUAGES
		WHERE LANGUAGE_TYPE = ?
	";
	$dbh -> do_placeholder_query($query,array($key),__LINE__,__FILE__);
}

$filelist = "<option value=\"\"></option>";
$searchfilelist = "<option value=\"all\">{$ubbt_lang['SEARCH_ALL']}</option>";
// ------------------------
// List out the languages
$dir = opendir("../languages/{$config['LANGUAGE']}");
$i=0;
while ($file = readdir($dir)) {
	if ($file == "." || $file == ".." || $file == "admin" ) { continue; }
	$i++;
	$languages[$i] = $file;
}

sort ($languages);
closedir($dir);
$langsize = sizeof($languages);
for ($i=0;$i<$langsize;$i++) {
	$filelist .= "<option>$languages[$i]</option>";
	$searchfilelist .= "<option>$languages[$i]</option>";
}

unset($languages);
$i=0;
$dir = opendir("{$config['FULL_PATH']}/languages/{$config['LANGUAGE']}/admin");
while ($file = readdir($dir)) {
	if ($file == "." || $file == ".." ) { continue; }
	$i++;
	$languages[$i] = "admin/$file";
}
sort ($languages);
closedir($dir);
$langsize = sizeof($languages);
for ($i=0;$i<$langsize;$i++) {
	$filelist .= "<option>$languages[$i]</option>";
	$searchfilelist .= "<option>$languages[$i]</option>";
}


$tabs = array(
	"{$ubbt_lang['LANGS']}" => "",
	"{$ubbt_lang['LANG_EDITOR']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['LANGS']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['LANGS']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
include("../templates/default/admin/availablelangs.tmpl");

$admin->sendFooter();
?>
