<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/catmanage.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Grab all categories
$query = "
	SELECT CATEGORY_ID,CATEGORY_TITLE,CATEGORY_DESCRIPTION,CATEGORY_SORT_ORDER
	FROM {$config['TABLE_PREFIX']}CATEGORIES
	ORDER BY CATEGORY_SORT_ORDER
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$i=0;
while(list($centry,$ctitle,$cdescription,$sort) = $dbh->fetch_array($sth)) {
	$cat[$i]['number'] = $centry;
	$cat[$i]['title'] = ubbchars($ctitle);
	$cat[$i]['description'] = $cdescription;
	$cat[$i]['sort'] = $sort;
	$i++;
}


$tabs = array(
	"{$ubbt_lang['CAT_SET']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['CAT_SET']);
$admin->setPageTitle($ubbt_lang['CAT_SET']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/catmanage.tmpl");

$bottomtabs[$ubbt_lang['ADD_NEW']] = "{$config['BASE_URL']}/admin/createcat.php";

$admin->createBottomTabs($bottomtabs);

$admin->sendFooter();
?>
