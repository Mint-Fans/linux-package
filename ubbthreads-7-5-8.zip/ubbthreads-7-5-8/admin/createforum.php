<?php
//	Script Version 7.5.8

require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/viewboard.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$forumimage = "{$config['BASE_URL']}/images/{$style_array['general']}/blank.gif";
$avurl = "";
// Grab the categories
$query = "
	SELECT CATEGORY_TITLE,CATEGORY_ID FROM {$config['TABLE_PREFIX']}CATEGORIES ORDER BY CATEGORY_ID
";
$sth = $dbh -> do_query($query,__LINE__,__FILE__);
$catlist = "";
while ( list($Catlist,$Catnumlist) = $dbh -> fetch_array($sth)) {
	$thisisit = "";
	$catlist .= "<option value=\"cat_$Catnumlist\">$Catlist</option>";
	$query = "
		select FORUM_TITLE,FORUM_ID
		from {$config['TABLE_PREFIX']}FORUMS
		where (FORUM_PARENT is null or FORUM_PARENT = '')
		and CATEGORY_ID = '$Catnumlist'
		order by FORUM_SORT_ORDER
	";
	$sti = $dbh->do_query($query,__LINE__,__FILE__);
	while(list($forum_title,$forum_id) = $dbh->fetch_array($sti)) {
		$catlist .= "<option value=\"forum_$forum_id\">&nbsp;&nbsp;&nbsp;$forum_title</option>";
	} // end while
	
}
$dbh -> finish_sth($sth);

include("{$config['FULL_PATH']}/cache/forum_cache.php");
if (!sizeof($tree)) {
	list($tree,$style_cache,$lang_cache) = build_forum_cache();
}
		
$catlist = "";
$category = "";
$forums = 0;
foreach($tree['categories'] as $cat => $cat_title) {
	$category = "";
	$category .= "<option value=\"category_$cat\">$cat_title ------</option>";
	if (!isset($tree[$cat])) {
		$catlist .= $category;
		continue;
	} // end if
	foreach($tree[$cat] as $forum_id => $forum_title) {
		$category .= "<option value=\"forum_$forum_id\">$forum_title</option>";
	}
	$catlist .= $category;
}

// What options exists for captcha?
$gd = true;
$im = true;
if (!function_exists(imagefttext)) {
	$gd = false;
} // end if
if (!$config['CONVERT_PATH']) {
	$im = false;
} // end if

$captcha_disabled = "selected=\"selected\"";
$captcha_gd = "";
$captcha_im = "";

$no_captcha = "";
if (!$gd && !$im) {
        $no_captcha = $ubbt_lang['NO_CAPTCHA'];
} // end if


// Grab the stylesheets
$stylelist = "";
$query = "
	select STYLE_ID,STYLE_NAME
	from {$config['TABLE_PREFIX']}STYLES
	where STYLE_IS_ACTIVE='1'
	order by STYLE_NAME
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while(list($style,$desc) = $dbh->fetch_array($sth)) {
	$stylenames[$style] = $desc;
	$stylelist .= "<option value=\"$style\">$desc</option>";
}

$query = "
	select 	PORTAL_ID,PORTAL_NAME
	from		{$config['TABLE_PREFIX']}PORTAL_BOXES
	where			PORTAL_CUSTOM = '1'
	order by PORTAL_ID
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$island_selection = "<option value=\"0\">{$ubbt_lang['NO_INSERT']}</option>";
while(list($portal_id,$portal_name) = $dbh->fetch_array($sth)) {
	$island_selection .= "<option value=\"$portal_id\">$portal_name</option>";
} // end while

$tabs = array(
	"{$ubbt_lang['FORUM_BASICS']}" => "",
	"{$ubbt_lang['HEADFOOT']}" => "",
	"{$ubbt_lang['RSS']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['FORUM_SET']);
$admin->setParentTitle($ubbt_lang['FORUM_SET'],"forummanage.php");
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['ADD_NEW']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);
$admin->setCommonSubmit($ubbt_lang['ADD_NEW']);

// Include the template
include("../templates/default/admin/createforum.tmpl");

$admin->sendFooter();
?>
