<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/doaddimage.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info
$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$returntab = get_input("returntab","post");
$type = get_input("type","post");

// -----------------------
// Get the uploaded images
if (empty($_FILES['readpost']['name'])) {
	$admin->error($ubbt_lang['NO_IMAGE']);
}
// Make sure it's good !
$allowedExtensions = array('png', 'gif', 'jpg', 'jpeg');
if (!in_array(end(explode(".",strtolower($_FILES['readpost']['name']))), $allowedExtensions)) {
		$admin->error($ubbt_lang['NOT_IMAGE_FILE']);
}
$readpost_name = $_FILES['readpost']['name'];
$readpost_temp = $_FILES['readpost']['tmp_name'];

$readpost_name = str_replace(" ","",$readpost_name);

if (file_exists("{$config['FULL_PATH']}/images/{$style_array[$type]}/$readpost_name")) {
	@unlink($readpost_temp);
	if ($type == "icons") {
		$admin -> error("{$ubbt_lang['ICON_EXISTS']}");
	}
	elseif ($type == "avatars") {
		$admin -> error("{$ubbt_lang['AVATAR_EXISTS']}");
	}
	elseif ($type == "forumimages") {
		$admin -> error("{$ubbt_lang['FIMAGE_EXISTS']}");
	}
	elseif ($type == "news") {
		$admin -> error("{$ubbt_lang['N_EXISTS']}");
	}
	elseif ($type == "mood") {
		$admin -> error("{$ubbt_lang['M_EXISTS']}");
	}
}

$check = @move_uploaded_file($readpost_temp, "{$config['FULL_PATH']}/images/{$style_array[$type]}/$readpost_name");
@chmod("{$config['FULL_PATH']}/images/{$style_array[$type]}/$readpost_name",0666);

if (!$check) {
	if ($type == "icons") {
		$admin -> error("{$ubbt_lang['NO_MOVE_I']}");
	}
	elseif ($type == "avatars") {
		$admin -> error("{$ubbt_lang['NO_MOVE_A']}");
	}
	elseif ($type == "forumimages") {
		$admin -> error("{$ubbt_lang['NO_MOVE_F']}");
	}
	elseif ($type == "news") {
		$admin -> error("{$ubbt_lang['NO_MOVE_N']}");
	}
	elseif ($type == "mood") {
		$admin -> error("{$ubbt_lang['NO_MOVE_M']}");
	}
}

$src = "<img src='{$config['BASE_URL']}/images/{$style_array[$type]}/$readpost_name'>";
// ---------------
// Log this action
if ($type == "icons") {
	admin_log("ADD_ICON", $src);
}
elseif ($type == "avatars") {
	admin_log("ADD_AVATAR", $src);
}
elseif ($type == "forumimages") {
	admin_log("ADD_FORUM_IMAGE", $src);
}
elseif ($type == "news") {
	admin_log("ADD_NEWS_IMAGE", $src);
}
elseif ($type == "mood") {
	admin_log("ADD_MOOD_IMAGE", $src);
}

if ($type == "icons") {
	$admin->redirect($ubbt_lang['I_ADDED'],"{$config['BASE_URL']}/admin/icons_display.php?returntab=0",$ubbt_lang['I_F_LOC']);
}
elseif ($type == "avatars") {
	$admin->redirect($ubbt_lang['A_ADDED'],"{$config['BASE_URL']}/admin/avatars_display.php?returntab=2",$ubbt_lang['A_F_LOC']);
}
elseif ($type == "forumimages") {
	$admin->redirect($ubbt_lang['F_ADDED'],"{$config['BASE_URL']}/admin/fimages_display.php?returntab=3",$ubbt_lang['F_F_LOC']);
}
elseif ($type == "news") {
	$admin->redirect($ubbt_lang['N_ADDED'],"{$config['BASE_URL']}/admin/newsimages_display.php?returntab=4",$ubbt_lang['N_F_LOC']);
}
elseif ($type == "mood") {
	$admin->redirect($ubbt_lang['M_ADDED'],"{$config['BASE_URL']}/admin/mood_display.php?returntab=5",$ubbt_lang['M_F_LOC']);
}

?>
