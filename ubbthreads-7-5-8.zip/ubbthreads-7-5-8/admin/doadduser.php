<?php

// Script Version: 7.5.7

require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/doadduser.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// Validate the user
$userob = new user;
$user = $userob->authenticate();

$admin = new Admin;
$admin->doAuth(array("EDIT_USERS"));

// Get the inputs
$name 			= get_input("login_name","post");
$display		= get_input("display_name", "post");
$psw				= get_input("password","post");
$email			= get_input("email","post");
$returntab	= get_input("returntab", "post", int, 4);
$tp_				= $config['TABLE_PREFIX'];

// Make sure user, display, psw and email aren't blank
if (!$name || !$display || !$psw || !$email) {
	$admin->error($ubbt_lang['BLANK_FIELDS']);
} else {
	// Sanity check on our login info
	list($ok,$err) = is_valid_name($name,"login");
	if ($ok === false) { $admin->error($ubbt_lang[$err]); }
	$name = addslashes($name);

	// Validate the PDN
	list($ok, $err) = is_valid_name($display,"display");
	if($ok === false) { $admin->error($ubbt_lang[$err]); }
	$display = addslashes($display);

	// Check the email format
	list($ok, $err) = reg_validate_email($email);
	if($ok === false) { $admin->error($ubbt_lang[$err]); }
	$email = addslashes($email);

	// Make sure the password has been provided properly
	list($ok,$err) = reg_validate_passwd($psw, $psw, $display);
	if($ok === false) { $admin->error($ubbt_lang[$err]); }
	$plainPsw = $psw;
	$psw = md5($psw);

	$date = $html->get_date();

	// Made it this far, we should be smooth sailing
	$q = "
		INSERT INTO {$tp_}USERS
			(USER_LOGIN_NAME, USER_DISPLAY_NAME, USER_PASSWORD, USER_MEMBERSHIP_LEVEL, USER_REGISTERED_ON,
			 USER_REGISTRATION_EMAIL,USER_REGISTRATION_IP,USER_IS_APPROVED,USER_IS_UNDERAGE)
		VALUES
			('$name','$display','$psw','User','$date','$email','127.0.0.1','yes','0')
	";
	$dbh->do_query($q);

	$sth = $dbh->do_query('select last_insert_id()');
	list ($Uid) = $dbh->fetch_array($sth);

	$q = "
		INSERT INTO {$tp_}USER_PROFILE
			(USER_ID, USER_FLOOD_CONTROL_OVERRIDE, USER_REAL_EMAIL, USER_TOTAL_POSTS, USER_TITLE, USER_TOTAL_PM)
		VALUES
			('$Uid','-1','$email',0,'',0)
	";
	$dbh->do_query($q);

	$q = "
		INSERT INTO {$tp_}USER_DATA
			(USER_ID, USER_LAST_VISIT_TIME)
		VALUES
			('$Uid', '$date')
	";
	$dbh->do_query($q);


	foreach($config['DEFAULT_USER_GROUPS'] as $key => $group) {
		$dbh->do_query("INSERT INTO {$tp_}USER_GROUPS VALUES ('$Uid','$group')");
	}
}

// Now we mail it to them
$mailer  = new mailer("../");
$mailer->set_subject('DAUSR_SUBJECT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $display));
$mailer->add_content('DAUSR_CONTENT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE'], 'USERNAME' => $name, 'PASSWORD' => $plainPsw));
$mailer->add_content('DAUSR_CONTENT1', array('LOGIN_URL' => make_ubb_url("ubb=login", '', true, true)), true);
$mailer->ubbt_mail($email);
admin_log("ADDED NEW USER","User: $name, Display: $display, Email: $email");
$admin->redirect($ubbt_lang['USER_ADDED'],"{$config['BASE_URL']}/admin/membermanage.php?returntab=$returntab",$ubbt_lang['F_LOC']);


// Local routines

// Validate an email address
function reg_validate_email ($email) {

	global $dbh, $config, $tp_;

	if (!eregi("^[+_a-z0-9-]+(\.[+_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$", $email)) {
		return array(false, 'BAD_FORMAT');
	}

	// Already banned?
	$Email_q = addslashes($email);
	$sth = $dbh->do_query("SELECT COUNT(*) FROM {$tp_}BANNED_EMAILS WHERE '$Email_q' LIKE BANNED_EMAIL");
	list($etest) = $dbh->fetch_array($sth);
	if ($etest) {
		return array(false, 'BAD_EMAIL');
	}

	// Check for duplicate email addys
	$sth = $dbh->do_query("SELECT USER_REAL_EMAIL FROM {$tp_}USER_PROFILE WHERE USER_REAL_EMAIL = '$Email_q'");
	list($emailcheck) = $dbh -> fetch_array($sth);
	if($emailcheck && $config['REQUIRE_UNIQUE_EMAIL']){
		return array(false, 'NO_MULTI');
	}

	// Check for duplicate email addys
	$sth = $dbh->do_query("SELECT USER_REGISTRATION_EMAIL FROM {$tp_}USERS WHERE USER_REGISTRATION_EMAIL = '$Email_q'");
	list($emailcheck) = $dbh -> fetch_array($sth);
	if($emailcheck && $config['REQUIRE_UNIQUE_EMAIL']){
		return array(false, 'NO_MULTI');
	}

	return array(true, null);
}

// Validate a password
function reg_validate_passwd ($passwd, $verify, $Displayname) {
	if ($passwd != $verify) {
		return array(false, 'PASS_MATCH');
	}
	if((strlen($passwd) > 21) || (strlen($passwd) < 4)) {
		return array(false, 'PASS_TOO_LONG');
	}
	if (preg_match("/^\W+$/",$passwd)) {
		return array(false, 'ILL_PASS');
	}
	if ($passwd == $Displayname) {
		return array(false, 'PASS_USER_MATCH');
	}

	return array(true, false);
}
?>
