<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/doeditavatars.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

$removedavatars = "";

// -------------
// Get the input
$returntab = get_input("returntab","post");

// -----------------
// Get the user info
$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// ------------------
// Remove all checked
$dir = opendir("{$config['FULL_PATH']}/images/{$style_array['avatars']}");
$i=0;
while( ($file = readdir($dir)) != false) {
	if ( ($file == ".") || ($file == "..") || ($file == "index.html") ) {
		continue;
	}
	list($name,$ext) = preg_split("#\.#",$file);
	$upload = "file-$ext-$name";
	if (isset($_POST[$name])) {
		$filename = "$name.{$_POST[$name]}";
		$test = @unlink("{$config['FULL_PATH']}/images/{$style_array['avatars']}/$filename");
		if (!$test) {
			$admin -> error("{$ubbt_lang['NOREMOVE']}");
		}
		$removedavatars .= "$filename-";
	}
	elseif (!empty($_FILES[$upload]['name'])) {
		$fileupload = $_FILES[$upload]['name'];
		$file_temp = $_FILES[$upload]['tmp_name'];
		$check = @move_uploaded_file($file_temp,"{$config['FULL_PATH']}/images/{$style_array['avatars']}/$file");
		@chmod("{$config['FULL_PATH']}/images/{$style_array['avatars']}/$file",0666);
		if (!$check) {
			$admin->error("{$config['FULL_PATH']}/images/{$style_array['avatars']}/$file {$ubbt_lang['NO_OVERW']}");
		}
	}
}

// ---------------
// Log this action
admin_log("REMOVEAVATAR", $removedavatars);

$admin->redirect($ubbt_lang['REMOVED'],"{$config['BASE_URL']}/admin/avatars_display.php?returntab=2",$ubbt_lang['F_LOC']);

?>
