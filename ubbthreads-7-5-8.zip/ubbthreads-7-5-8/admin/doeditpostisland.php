<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","post");
$island = get_input("island","post");
$portal_name = get_input("portal_name","post");
$portal_cache = get_input("portal_cache","post");
$type = get_input("type","post");
$always_build = get_input("always_build","post");
$items = get_input("items","post");


// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

foreach($_POST['source'] as $k => $v) {
	if ($v == "category") {
		unset($_POST['source'][$k]);
	} // end if
} // end foreach

if (!sizeof($_POST['source'])) {
	$admin->error($ubbt_lang['NO_SOURCE']);
} // end if

$portal_cache = $portal_cache * 60;
$query = "
	update 	{$config['TABLE_PREFIX']}PORTAL_BOXES
	set	PORTAL_NAME = ? ,
		PORTAL_CACHE = ? ,
		PORTAL_FORUMS = ? ,
		PORTAL_POST_TYPE = ? ,
		PORTAL_ITEMS = ?
	where	PORTAL_ID = ?
";

$dbh->do_placeholder_query($query,array($portal_name,$portal_cache,serialize($_POST['source']),$type,$items,$island),__LINE__,__FILE__);

if ($always_build && !in_array("post_island_{$island}",$config['BUILD_ISLANDS'])) {
	// put it in
	if (is_array($config['BUILD_ISLANDS'])) {
		array_push($config['BUILD_ISLANDS'],"post_island_{$island}");
	} else {
		$config['BUILD_ISLANDS'][] = "post_island_{$island}";
	} // end if

	$_POST['BUILD_ISLANDS'] = $config['BUILD_ISLANDS'];
	$newconfig = array("BUILD_ISLANDS");
	include("./doeditconfig.php");
	
} else {
	// take it out

	$newarray = array();
	foreach($config['BUILD_ISLANDS'] as $k => $v) {
		if ($v == "post_island_{$island}") continue;
		$newarray[] = $v;
	}

	$_POST['BUILD_ISLANDS'] = $newarray;	
	$newconfig = array("BUILD_ISLANDS");
	include("./doeditconfig.php");
}

admin_log("EDIT_POST_ISLAND","<a href='{$config['BASE_URL']}/admin/editpostisland.php?island=$island&returntab=$returntab' target='_blank'>$portal_name</a>");

$admin->redirect($ubbt_lang['POST_ISL_UPDATED'],"{$config['BASE_URL']}/admin/editpostisland.php?island=$island&returntab=$returntab",$ubbt_lang['POST_ISL_F_LOC']);

?>
