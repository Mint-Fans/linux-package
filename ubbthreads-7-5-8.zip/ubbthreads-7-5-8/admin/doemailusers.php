<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/doemailusers.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();
// get the input
$which = get_input("which","post");
$email = get_input("email","post");
$inlist = get_input("inlist","post");

$tabs = array(
	"{$ubbt_lang['EMAIL_USERS']}" => ""
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['MEM_MAN']);
$admin->setParentTitle($ubbt_lang['MEM_MAN'],"membermanage.php");
$admin->setPageTitle($ubbt_lang['EMAIL_USERS']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
if ($email == "export") {
	include("../templates/default/admin/exportemails.tmpl");
}
else {
	include("../templates/default/admin/doemailusers.tmpl");
}

admin_log("MASS_EMAIL","");

$admin->sendFooter();
?>
