<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","post");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// What config vars are we updating?
$newconfig = array("GRAPHICS_LIBRARY","MAX_THUMB_W_H","MAX_MEDIUM_W_H","MAX_FULL_W_H","THUMB_QUALITY","MEDIUM_QUALITY","FULL_QUALITY");

include("./doeditconfig.php");

admin_log("GALLERY_SETTINGS","$log_diffs");

$admin->redirect($ubbt_lang['SET_UPDATED'],"{$config['BASE_URL']}/admin/gallery.php?returntab=$returntab",$ubbt_lang['GALLERY_F_LOC']);

?>
