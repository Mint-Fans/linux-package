<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/dolayout.php");

// -------------
// Get the input
$returntab = get_input("returntab","post");


// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$left_col = array();
$right_col = array();
$build = array();
$no_collapse = array();
$left_column = 0;
$right_column = 0;

// Set the order of the left column
foreach($_POST['left'] as $key => $value) {
	if (!$value) { continue; } // end if
	if (isset($left_col[$value])) {
		$admin->error($ubbt_lang['DUP_ORDER']);
		exit;
	} // end if
	$left_col[$value] = $key;
	
} // end foreach

// Make sure left column is turned on, if we have any islands in it
if (sizeof($left_col)) {
	$left_column = 1;
} // end if

// Set the order of the right column
foreach($_POST['right'] as $key => $value) {
	if (!$value) { continue; } // end if
	if (isset($right_col[$value])) {
		$admin->error($ubbt_lang['DUP_ORDER']);
		exit;
	} // end if
	$right_col[$value] = $key;
	
} // end foreach

// Make sure left column is turned on, if we have any islands in it
if (sizeof($right_col)) {
	$right_column = 1;
} // end if

// Make sure bottom column is turned on, if we have any islands in it
if (sizeof($bottom_col)) {
	$bottom_column = 1;
} // end if

// Get the always build boxes
if (isset($_POST['build'])) {
	foreach($_POST['build'] as $key => $value) {
		if (!$value) { continue; } // end if
		$build[] = $key;
	} // end foreach
} // end if

ksort($left_col);
ksort($right_col);

$_POST['LEFT_COLUMN_BOXES'] = $left_col;
$_POST['RIGHT_COLUMN_BOXES'] = $right_col;
$_POST['RIGHT_COLUMN'] = $right_column;
$_POST['LEFT_COLUMN'] = $left_column;
$_POST['BUILD_ISLANDS'] = $build;

// What config vars are we updating?
$newconfig = array("LEFT_COLUMN","RIGHT_COLUMN","RIGHT_COLUMN_BOXES","LEFT_COLUMN_BOXES","BUILD_ISLANDS");

include("./doeditconfig.php");

admin_log("UPDATE_LAYOUT",$log_diffs);

$admin->redirect($ubbt_lang['LAYOUT_UPDATED'],"{$config['BASE_URL']}/admin/layout.php?returntab=$returntab",$ubbt_lang['LAYOUT_F_LOC']);

?>
