<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Grab all current moderators for each board
$query = "
	SELECT t1.USER_ID,t1.FORUM_ID,t2.FORUM_ID
	FROM {$config['TABLE_PREFIX']}MODERATORS AS t1,
	{$config['TABLE_PREFIX']}FORUMS AS t2
	WHERE t1.FORUM_ID = t2.FORUM_ID
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$modboards = array();
while(list($moduid,$modboard,$bonum) = $dbh->fetch_array($sth)) {
	$modboards[$bonum][] = $moduid;
}

// Grab all uids that are already moderators or administrators
$query = "
	SELECT USER_ID,USER_MEMBERSHIP_LEVEL
	FROM {$config['TABLE_PREFIX']}USERS
	WHERE USER_MEMBERSHIP_LEVEL LIKE '%Moderator' OR USER_MEMBERSHIP_LEVEL='Administrator'
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while(list($unum,$ustatus) = $dbh->fetch_array($sth)) {
	$users[$unum] = $ustatus;
}

// Grab all forum #'s
$query = "
	SELECT FORUM_ID
	FROM {$config['TABLE_PREFIX']}FORUMS
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$newmods = "";
while(list($bnum) = $dbh->fetch_array($sth)) {
	$fname = "forum_$bnum";
	$modlist = get_input("$fname","post");
	// Split out the results at the -
	$modarray = preg_split("#-#",$modlist);

	// Add any new moderators
	for($i=0;$i<sizeof($modarray);$i++) {
		if (($modarray[$i] == "!") || (!$modarray[$i])) {
			continue;
		}
		// First check to see if this user is already a moderator or admin
		if (!isset($users[$modarray[$i]])) {
			$query = "
				UPDATE {$config['TABLE_PREFIX']}USERS
				SET USER_MEMBERSHIP_LEVEL='Moderator'
				WHERE USER_ID = ?
			";
			$dbh->do_placeholder_query($query,array($modarray[$i]),__LINE__,__FILE__);
			
			// Insert into moderators group
			$query = "
				replace into {$config['TABLE_PREFIX']}USER_GROUPS
				values
				( ? ,'3')
			";
			$dbh->do_placeholder_query($query,array($modarray[$i]),__LINE__,__FILE__);

			// Insert User into Moderator table
			$query = "
				insert INTO {$config['TABLE_PREFIX']}MODERATORS
				(USER_ID,FORUM_ID)
				VALUES
				( ? , ? )
			";
			$dbh->do_placeholder_query($query,array($modarray[$i],$bnum),__LINE__,__FILE__);

			// Update a string that holds the new moderators
			$newmods .= "-{$modarray[$i]}-";

		}
		elseif ($users[$modarray[$i]] == "Moderator") {
			// Make sure they aren't already in the moderator list
			if (is_array($modboards[$bnum])) {
				if (in_array($modarray[$i],$modboards[$bnum])) {
					continue;
				}
			}

			// Insert User into Moderator table
			$query = "
				INSERT INTO {$config['TABLE_PREFIX']}MODERATORS
				(USER_ID,FORUM_ID)
				VALUES
				( ? , ? )
			";
			$dbh->do_placeholder_query($query,array($modarray[$i],$bnum),__LINE__,__FILE__);

		}
		elseif ($users[$modarray[$i]] == "Administrator") {

			// Make sure they aren't already in the moderator list
			if (is_array($modboards[$bnum])) {
				if (in_array($modarray[$i],$modboards[$bnum])) {
					continue;
				}
			}
			// Insert User into Moderator table
			$query = "
				INSERT INTO {$config['TABLE_PREFIX']}MODERATORS
				(USER_ID,FORUM_ID)
				VALUES
				( ? , ? )
			";
			$dbh->do_placeholder_query($query,array($modarray[$i],$bnum),__LINE__,__FILE__);
		}
	}

	// Remove any old moderators
	if (!isset($modboards[$bnum])) {
		continue;
	}

	for ($i=0;$i<sizeof($modboards[$bnum]);$i++) {
		$modcheck = $modboards[$bnum][$i];
		if (!in_array($modcheck,$modarray)) {
			// Remove this moderator from the moderator list
			$query = "
				DELETE FROM {$config['TABLE_PREFIX']}MODERATORS
				WHERE USER_ID = ?
				AND FORUM_ID = ?
			";
			$dbh->do_placeholder_query($query,array($modcheck,$bnum),__LINE__,__FILE__);
		}
	}


}

// ---------------
// Log this action
admin_log("MODMANAGE", '');

if ($newmods) {
	$admin->redirect($ubbt_lang['MODS_UPDATED'],"{$config['BASE_URL']}/admin/modmanage.php?returntab=0&newmods=$newmods",$ubbt_lang['MODS_UP_F_LOC']);
}
else {
	$admin->redirect($ubbt_lang['MODS_UPDATED'],"{$config['BASE_URL']}/admin/modmanage.php?returntab=0",$ubbt_lang['MODS_UP_F_LOC']);
}

?>
