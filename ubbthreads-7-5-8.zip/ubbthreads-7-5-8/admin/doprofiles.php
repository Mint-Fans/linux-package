<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","post");
$existing = get_input("existing","post");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$avPath = get_input("UPLOADED_AVATAR_PATH","post");

if ($avPath && $avPath == $config['ATTACHMENTS_PATH']) {
  $admin->error($ubbt_lang['DUP_PATH']);
  exit;
}

// What config vars are we updating?
$newconfig = array("UPLOADED_AVATAR_PATH","UPLOADED_AVATAR_URL","MAX_AVATAR_SIZE","AVATAR_MAX_WIDTH","AVATAR_MAX_HEIGHT","ONLY_CUSTOM");

// Update the config file
include("doeditconfig.php");

// Grab the current titles
$query = "
	SELECT USER_TITLE_ID,USER_TITLE_POST_COUNT,USER_TITLE_NAME
	FROM {$config['TABLE_PREFIX']}USER_TITLES
	ORDER BY USER_TITLE_ID
";
$sth=$dbh->do_query($query,__LINE__,__FILE__);
while(list($tnum,$tpost,$ttitle) = $dbh->fetch_array($sth)) {
	$tarray[$tnum]['post'] = $tpost;
	$tarray[$tnum]['title'] = $ttitle;
	$maxtnum = $tnum + 1;
}
for ($i=$maxtnum;$i<=20;$i++) {
	$tarray[$i]['post'] = "";
	$tarray[$i]['title'] = "";
}

// Update the user titles
for($i=1;$i<=20;$i++) {
	$field = "post-$i";
	$post = get_input($field,"post");
	$field = "title-$i";
	$title = get_input("$field","post");
	if ( ($post != $tarray[$i]['post']) || ($title != $tarray[$i]['title']) ) {
		$post = addslashes($post);
		$title = addslashes($title);
		if (!$post && !$title) {
			$query = "
				DELETE FROM {$config['TABLE_PREFIX']}USER_TITLES
				WHERE USER_TITLE_ID='$i'	
			";
			$dbh->do_query($query,__LINE__,__FILE__);
		}
		else {
			$query = "
				REPLACE INTO {$config['TABLE_PREFIX']}USER_TITLES
				(USER_TITLE_ID,USER_TITLE_POST_COUNT,USER_TITLE_NAME)
				VALUES
				('$i','$post','$title')
			";
			$dbh->do_query($query,__LINE__,__FILE__);
		}
	}
}

if ($existing) {
	// Grab the new titles
	$query = "
		SELECT USER_TITLE_POST_COUNT,USER_TITLE_NAME
		FROM {$config['TABLE_PREFIX']}USER_TITLES
		ORDER BY USER_TITLE_ID
	";
	$sth=$dbh->do_query($query,__LINE__,__FILE__);
	$i=0;
	$newtitles = array();
	while(list($tpost,$ttitle) = $dbh->fetch_array($sth)) {
		$newtitles[$i]['posts'] = $tpost;
		$newtitles[$i]['title'] = $ttitle;
		$i++;
	}
	for ($i=0;$i<sizeof($newtitles);$i++) {
		$lessthan = "";
		if (isset($newtitles[$i + 1]['posts'])) {
			$lessthan = "USER_TOTAL_POSTS < '{$newtitles[$i + 1]['posts']}'";
		}
		$greaterthan = "";
		if ($i > 0) {
			$greaterthan = "USER_TOTAL_POSTS >= '{$newtitles[$i]['posts']}'";
		}
		$clause = "";
		if ($greaterthan) {
			$clause = "$greaterthan ";
		}
		if ($lessthan) {
			if ($clause) {
				$clause .= " AND ";
			}
			$clause .= " $lessthan ";
		}

		if (!$clause) $clause = "USER_TOTAL_POSTS >= 0";

		$newtitle = addslashes($newtitles[$i]['title']);
		$query = "
			UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
			SET USER_TITLE = '$newtitle'
			WHERE $clause
		";
		$dbh->do_query($query,__LINE__,__FILE__);
	}
}

admin_log("PROFILE_SETTINGS","$log_diffs");

$admin->redirect($ubbt_lang['PROFILES_UPDATED'],"{$config['BASE_URL']}/admin/profiles.php?returntab=$returntab",$ubbt_lang['PROFILES_F_LOC']);

?>
