<?php
//	Script Version 7.5.8
require("../libs/admin.inc.php");
require("../languages/{$config['LANGUAGE']}/admin/generic.php");
require("../languages/{$config['LANGUAGE']}/admin/dorebuildcontent.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$html = new html;

$admin->doAuth();

@include("{$config['FULL_PATH']}/cache/custom_tag_cache.php");

require_once("{$config['FULL_PATH']}/libs/content_rebuild.inc.php");

$mode = get_input("mode", "get");
$start = get_input("start", "get", "int", 0);
$convert = get_input("convert", "get");
$pretotal = get_input("pretotal", "get", "int", 0);

$limits = array(
	"posts" => 200,
	"posts_utf8" => 100,
	"forums" => 100,
	"pruneorphans" => 50,
	"signatures" => 200,
	"topics" => 500,
	"private_messages" => 200,
	"postcounts" => 200,
);

$limit = array_get($limits, $mode, null);

if ($limit == null) {
	$admin->error("Invalid mode specified");
}

$redirect = "";
$message = "";

switch ($mode) {
	case "posts":
		$query = "
			SELECT	COUNT(POST_ID) AS COUNT
			FROM	{$config['TABLE_PREFIX']}POSTS
		";

		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$tmp = $dbh->fetch_array($sth, MYSQL_ASSOC);
		$total = $tmp['COUNT'];

		$query = "
			SELECT	POST_ID
			FROM	{$config['TABLE_PREFIX']}POSTS
			ORDER BY POST_ID ASC
			LIMIT	?, ?
		";

		$posts = array();

		$sth = $dbh->do_placeholder_query($query, array($start, $limit), __LINE__, __FILE__);
		while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
			$posts[] = $result['POST_ID'];
		}
		$dbh->finish_sth($sth);

		if (count($posts) > 0) {
			rebuild_posts($posts);
			$next_start = $start + $limit;

			if ($next_start > $total) {
				$next_start = $total;
			}

			$message = sprintf($ubbt_lang['REBUILDING_POSTS'], $start + 1, $next_start, $total);
			$redirect = "dorebuildcontent.php?mode=posts&amp;start=" . ($start + $limit);
			set_board_is_open(false);
		} else {
			// This is our last page.
			$message = sprintf($ubbt_lang['REBUILD_POSTS_COMPLETE'], $total);
			$redirect = "rebuildcontent.php";
			set_board_is_open(true);
		}

		break;

	// The following option is not shown for a reason.
/*	case "posts_utf8":
		$query = "
			SELECT	COUNT(POST_ID) AS COUNT
			FROM	{$config['TABLE_PREFIX']}POSTS
		";

		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$tmp = $dbh->fetch_array($sth, MYSQL_ASSOC);
		$total = $tmp['COUNT'];

		$query = "
			SELECT	POST_ID, POST_BODY
			FROM	{$config['TABLE_PREFIX']}POSTS
			ORDER BY POST_ID ASC
			LIMIT	?, ?
		";

		$posts = array();

		$sth = $dbh->do_placeholder_query($query, array($start, $limit), __LINE__, __FILE__);
		while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
			$posts[] = $result;
		}
		$dbh->finish_sth($sth);

		$sizeof_posts = count($posts);

		if ($sizeof_posts > 0) {

			for ($i = 0; $i < $sizeof_posts; $i++) {
				if (is_utf8($posts[$i]['POST_BODY'])) {
					$query = "
						UPDATE	{$config['TABLE_PREFIX']}POSTS
						SET	POST_BODY = ?
						WHERE	POST_ID = ?
					";

					$dbh->do_placeholder_query($query, array(utf8_encode($posts[$i]['POST_BODY']), $posts[$i]['POST_ID']), __LINE__, __FILE__);
				}
			}

			$next_start = $start + $limit;

			if ($next_start > $total) {
				$next_start = $total;
			}

			$message = sprintf($ubbt_lang['REBUILDING_POSTS'], $start + 1, $next_start, $total);
			$redirect = "dorebuildcontent.php?mode=posts_utf8&amp;start=" . ($start + $limit);
			set_board_is_open(false);
		} else {
			// This is our last page.
			$message = sprintf($ubbt_lang['REBUILD_POSTS_COMPLETE'], $total);
			$redirect = "rebuildcontent.php";
			set_board_is_open(true);
		}

		break;
*/
	case "signatures":
		$query = "
			SELECT	COUNT(USER_ID) AS COUNT
			FROM	{$config['TABLE_PREFIX']}USER_PROFILE
			WHERE	USER_DEFAULT_SIGNATURE <> ''
		";

		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$tmp = $dbh->fetch_array($sth, MYSQL_ASSOC);
		$total = $tmp['COUNT'];

		$query = "
			SELECT	USER_ID
			FROM	{$config['TABLE_PREFIX']}USER_PROFILE
			WHERE	USER_DEFAULT_SIGNATURE <> ''
			ORDER BY USER_ID ASC
			LIMIT	?, ?
		";

		$posts = array();

		$sth = $dbh->do_placeholder_query($query, array($start, $limit), __LINE__, __FILE__);
		while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
			$posts[] = $result['USER_ID'];
		}
		$dbh->finish_sth($sth);

		if (count($posts) > 0) {
			rebuild_signatures($posts);
			$next_start = $start + $limit;

			if ($next_start > $total) {
				$next_start = $total;
			}

			$message = sprintf($ubbt_lang['REBUILDING_SIGNATURES'], $start + 1, $next_start, $total);
			$redirect = "dorebuildcontent.php?mode=signatures&amp;start=" . ($start + $limit);
			set_board_is_open(false);
		} else {
			// This is our last page.
			$message = sprintf($ubbt_lang['REBUILD_SIGNATURES_COMPLETE'], $total);
			$redirect = "rebuildcontent.php";
			set_board_is_open(true);
		}

		break;

	case "postcounts":
		// Set everybody's count to zero first, then let it rip
		if ($start == 0) {
			$query = "
				UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
				SET USER_TOTAL_POSTS = 0
			";
			$sth = $dbh->do_query($query,__LINE__,__FILE__);
		}

		$query = "
			SELECT	COUNT(USER_ID) AS COUNT
			FROM	{$config['TABLE_PREFIX']}USER_PROFILE
		";

		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$tmp = $dbh->fetch_array($sth, MYSQL_ASSOC);
		$total = $tmp['COUNT'];

		$query = "
			SELECT	USER_ID
			FROM	{$config['TABLE_PREFIX']}USER_PROFILE
			ORDER BY USER_ID ASC
			LIMIT	?, ?
		";

		$posts = array();

		$sth = $dbh->do_placeholder_query($query, array($start, $limit), __LINE__, __FILE__);
		while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
			$posts[] = $result['USER_ID'];
		}
		$dbh->finish_sth($sth);

		if (count($posts) > 0) {
			rebuild_user_postcounts($posts);
			$next_start = $start + $limit;

			if ($next_start > $total) {
				$next_start = $total;
			}

			$message = sprintf($ubbt_lang['REBUILDING_POST_COUNTS'], $start + 1, $next_start, $total);
			$redirect = "dorebuildcontent.php?mode=postcounts&amp;start=" . ($start + $limit);
			set_board_is_open(false);
		} else {
			// This is our last page.
			$message = sprintf($ubbt_lang['REBUILD_POST_COUNTS_COMPLETE'], $total);
			$redirect = "rebuildcontent.php";
			set_board_is_open(true);
		}

		break;

	case "private_messages":
		$query = "
			SELECT	COUNT(POST_ID) AS COUNT
			FROM	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
		";

		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$tmp = $dbh->fetch_array($sth, MYSQL_ASSOC);
		$total = $tmp['COUNT'];

		$query = "
			SELECT	POST_ID
			FROM	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
			ORDER BY POST_ID ASC
			LIMIT	?, ?
		";

		$posts = array();

		$sth = $dbh->do_placeholder_query($query, array($start, $limit), __LINE__, __FILE__);
		while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
			$posts[] = $result['POST_ID'];
		}
		$dbh->finish_sth($sth);

		if (count($posts) > 0) {
			rebuild_private_messages($posts);
			$next_start = $start + $limit;

			if ($next_start > $total) {
				$next_start = $total;
			}

			$message = sprintf($ubbt_lang['REBUILDING_PMS'], $start + 1, $next_start, $total);
			$redirect = "dorebuildcontent.php?mode=private_messages&amp;start=" . ($start + $limit);
			set_board_is_open(false);
		} else {
			// This is our last page.
			$message = sprintf($ubbt_lang['REBUILD_PMS_COMPLETE'], $total);
			$redirect = "rebuildcontent.php";
			set_board_is_open(true);
		}
		break;
	case "topics":
    $query = "
      select FORUM_ID,TOPIC_ID
      from {$config['TABLE_PREFIX']}ANNOUNCEMENTS
    ";
    $sth = $dbh->do_query($query,__LINE__,__FILE__);
    $stickies = array();
    while(list($fid,$tid) = $dbh->fetch_array($sth)) {
      $stickes[$tid] = $fid;
    }
		$query = "
			SELECT	COUNT(TOPIC_ID) AS COUNT
			FROM	{$config['TABLE_PREFIX']}TOPICS
			WHERE	TOPIC_STATUS <> 'M'
		";

		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$tmp = $dbh->fetch_array($sth, MYSQL_ASSOC);
		$total = $tmp['COUNT'];

		$query = "
			SELECT	TOPIC_ID
			FROM	{$config['TABLE_PREFIX']}TOPICS
			WHERE	TOPIC_STATUS <> 'M'
			ORDER BY TOPIC_ID ASC
			LIMIT	?, ?
		";

		$posts = array();

		$sth = $dbh->do_placeholder_query($query, array($start, $limit), __LINE__, __FILE__);
		while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
			$posts[] = $result['TOPIC_ID'];
		}
		$dbh->finish_sth($sth);

		if (count($posts) > 0) {
			rebuild_topics($posts);
			$next_start = $start + $limit;

			if ($next_start > $total) {
				$next_start = $total;
			}

			$message = sprintf($ubbt_lang['REBUILDING_TOPICS'], $start + 1, $next_start, $total);
			$redirect = "dorebuildcontent.php?mode=topics&amp;start=" . ($start + $limit);
			set_board_is_open(false);
		} else {
			// This is our last page.
			$message = sprintf($ubbt_lang['REBUILD_TOPICS_COMPLETE'], $total);
			$redirect = "rebuildcontent.php";
			set_board_is_open(true);
		}
		break;
	case "pruneorphans":
		// Get current number of orphans left (the hard way, because of mysql 4.0 restriction)

		/* For future (4.1+)
				$query = "
					select TOPIC_ID from ubbt_PRIVATE_MESSAGE_USERS
					where TOPIC_ID in (
						select TOPIC_ID
						from ubbt_PRIVATE_MESSAGE_USERS
						where USER_ID = 1
					)
					and TOPIC_ID not in (
						select TOPIC_ID
						from ubbt_PRIVATE_MESSAGE_USERS
						where USER_ID <> 1
					)
				";
		*/
		$query = "
			SELECT TOPIC_ID
			FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
			WHERE USER_ID = 1
		";
		$sth = $dbh->do_query($query,__LINE__, __FILE__);
		$uber_in = array();
		while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
			$uber_in[] = $result['TOPIC_ID'];
		}
		$query = "
			SELECT TOPIC_ID
			FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
			WHERE USER_ID <> 1
		";
		$sth = $dbh->do_query($query,__LINE__, __FILE__);
		$uber_notin = array();
		while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
			$uber_notin[] = $result['TOPIC_ID'];
		}
		// Setup for the IN (xx), but add safety net for empties
		if (count($uber_in) > 0) {
			$in_list = '(' . implode(',',$uber_in) . ')';
		} else {
			$in_list = '(-1)';
		}
		if (count($uber_notin) > 0) {
			$notin_list = '(' . implode(',',$uber_notin) . ')';
		} else {
			$notin_list = '(-1)';
		}

		// Grab an initial count for display purposes
		if ($start == 0) {
			$query = "
				SELECT COUNT(TOPIC_ID) AS COUNT
				FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
				WHERE TOPIC_ID IN $in_list
				AND TOPIC_ID NOT IN $notin_list
			";
			$sth = $dbh->do_query($query, __LINE__, __FILE__);
			$tmp = $dbh->fetch_array($sth, MYSQL_ASSOC);
			$total = $tmp['COUNT'];
		} else {
			$total = $pretotal;
		}

		$query = "
			SELECT TOPIC_ID
			FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
			WHERE TOPIC_ID IN $in_list
			AND TOPIC_ID NOT IN $notin_list
			LIMIT ?
		";
		$sth = $dbh->do_placeholder_query($query, array($limit), __LINE__, __FILE__);
		$topics = array();
		while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
			$topics[] = $result['TOPIC_ID'];
		}
		$dbh->finish_sth($sth);

		if (count($topics) > 0) {
			prune_empty_private_topics($topics);
			$next_start = $start + $limit;

			if ($next_start > $total) {
				$next_start = $total;
			}

			$message = sprintf($ubbt_lang['PRUNING_PRIVATE_TOPICS'], $start + 1, $next_start, $total);
			$redirect = "dorebuildcontent.php?mode=pruneorphans&amp;start=" . ($start + $limit) . "&amp;pretotal=" . $total;
			set_board_is_open(false);
		} else {
			// This is our last page.
			$message = sprintf($ubbt_lang['PRUNE_PRIVATE_TOPICS_COMPLETE'], $total);
			$redirect = "rebuildcontent.php";
			set_board_is_open(true);
		}
		break;
	case "forums":
		$query = "
			SELECT	COUNT(FORUM_ID) AS COUNT
			FROM	{$config['TABLE_PREFIX']}FORUMS
		";

		$sth = $dbh->do_query($query, __LINE__, __FILE__);
		$tmp = $dbh->fetch_array($sth, MYSQL_ASSOC);
		$total = $tmp['COUNT'];

		$query = "
			SELECT	FORUM_ID
			FROM	{$config['TABLE_PREFIX']}FORUMS
			ORDER BY FORUM_ID ASC
			LIMIT	?, ?
		";

		$posts = array();

		$sth = $dbh->do_placeholder_query($query, array($start, $limit), __LINE__, __FILE__);
		while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
			$posts[] = $result['FORUM_ID'];
		}
		$dbh->finish_sth($sth);

		if (count($posts) > 0) {
			rebuild_forums($posts);
			$next_start = $start + $limit;

			if ($next_start > $total) {
				$next_start = $total;
			}

			$message = sprintf($ubbt_lang['REBUILDING_FORUMS'], $start + 1, $next_start, $total);
			$redirect = "dorebuildcontent.php?mode=forums&amp;start=" . ($start + $limit);
			set_board_is_open(false);
		} else {
			// This is our last page.
			$message = sprintf($ubbt_lang['REBUILD_FORUMS_COMPLETE'], $total);
			$redirect = "rebuildcontent.php";
			set_board_is_open(true);
		}
		//exit;
		break;
	default:
		$admin->error("Ian forgot to account for the mode: " . $mode);
}

// I love people who post their code!
function is_utf8($string) {
	// From http://w3.org/International/questions/qa-forms-utf-8.html
        return preg_match('%(?:
		[\xC2-\xDF][\x80-\xBF]
		|\xE0[\xA0-\xBF][\x80-\xBF]
		|[\xE1-\xEC\xEE\xEF][\x80-\xBF]{2}
		|\xED[\x80-\x9F][\x80-\xBF]
		|\xF0[\x90-\xBF][\x80-\xBF]{2}
		|[\xF1-\xF3][\x80-\xBF]{3}
		|\xF4[\x80-\x8F][\x80-\xBF]{2}
	)+%xs', $string);
} // function is_utf8

function set_board_is_open($on = true) {
	require("../includes/config.inc.php");
	$on = $on ? '0' : '1';
	if ($config['BOARD_IS_CLOSED'] != $on) {
		$config['BOARD_IS_CLOSED'] = $on;
		lock_and_write("{$config['FULL_PATH']}/includes/config.inc.php", '<?php $config = ' . var_export($config, true) . '; ?>');
	}
}

$admin->redirect($message, "{$config['BASE_URL']}/admin/" . $redirect, $ubbt_lang['REBUILD_FORWARDED'], 2);

?>
