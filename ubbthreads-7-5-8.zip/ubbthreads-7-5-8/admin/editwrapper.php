<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/editwrapper.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = 0;
$wrapper = get_input("wrapper","get","int");
$new = get_input("new","get","int");

// -----------------
// Get the user info
$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$tabs = array(
	"{$ubbt_lang['EDIT_WRAPPER']}" => "",
);

$admin->setCurrentMenu($ubbt_lang['STYLES']);
$admin->setReturnTab(0);
$admin->setPageTitle($ubbt_lang['EDIT_WRAPPER']);
$admin->sendHeader();
$admin->createTopTabs($tabs,0);

$name = "";
$open = "";
$close = "";
// Get the current wrappers
include("{$config['FULL_PATH']}/styles/wrappers.php");
if ($wrapper || $wrapper == "0") {
	$name = $wrappers[$wrapper]['name'];
	$open = $wrappers[$wrapper]['open'];
	$close = $wrappers[$wrapper]['close'];
} // end if

// Include the template
include("../templates/default/admin/editwrapper.tmpl");

$bottomtabs = array(
	"{$ubbt_lang['DELETE_WRAPPER']}" => "javascript:void(0);\" onclick=\"checkDelete($wrapper);"
);
$admin->createBottomTabs($bottomtabs,0);

$admin->sendFooter();
?>
