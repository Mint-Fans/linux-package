<?php
//	Script Version 7.5.8

if (!defined('EMAIL')) {
	exit;
}

require ("../languages/{$config['LANGUAGE']}/admin/emailusers.php");

$tabs = array(
	"{$ubbt_lang['EMAIL_USERS']}" => ""
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['MEM_MAN']);
$admin->setParentTitle($ubbt_lang['MEM_MAN'],"membermanage.php");
$admin->setPageTitle($ubbt_lang['EMAIL_USERS']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/emailusers.tmpl");

$admin->sendFooter();

exit;
?>
