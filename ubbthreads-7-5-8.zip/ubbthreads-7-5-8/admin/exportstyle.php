<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/styles.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$style = get_input("style","get");
$w = get_input("w","get");

$query = "
	select STYLE_NAME,STYLE_IMG,STYLE_VARS,STYLE_WRAPPERS
	from {$config['TABLE_PREFIX']}STYLES
	where STYLE_ID = ?
";
$sth = $dbh->do_placeholder_query($query,array($style),__LINE__,__FILE__);
list($style_name,$style_img,$style_vars,$style_wrapper) = $dbh->fetch_array($sth);

include("{$config['FULL_PATH']}/styles/wrappers.php");

$extra = "no_wrapper";
if ($w) {
	$extra = "with_wrapper";
}
$html = new html;

header("Content-type: text/plain");
header("Content-Disposition: attachment; filename={$style_name}_{$extra}.txt");
header("Content-Description: PHP Generated Data");
echo "--STYLE_DETAILS--";
echo "\r\n";
echo "STYLE_NAME:$style_name\r\n";
echo "WRAPPER_ID:$style_wrapper\r\n";
echo "EXPORTED_BY:{$user['USER_DISPLAY_NAME']}\r\n";
echo "EXPORT_SITE:" . make_ubb_url("", "", true) . "\r\n";
echo "EXPORT_TIME: " . $html->convert_time(time(),'','',1,false) . "\r\n";
echo "EXPORT_VERSION: {$VERSION}\r\n";
echo "--END_STYLE_DETAILS--";
echo "\r\n\r\n";
echo "--STYLE_VARS--\r\n";

$var_list = unserialize($style_vars);
foreach($var_list as $key => $value) {
	$var_list[$key] = preg_replace("#{$config['FULL_URL']}#","FULL_URL",$value);
}
echo var_export($var_list,true);
echo ";";
echo "\r\n";
echo "--END_STYLE_VARS--";
echo "\r\n\r\n";
echo "--IMAGE_VARS--\r\n";
echo var_export(unserialize($style_img),true);
echo ";";
echo "\r\n";
echo "--END_IMAGE_VARS--";
echo "\r\n\r\n";

if ($w) {
echo "--WRAPPER_SET--\r\n";

$wrapper_set = $wrappers[$style_wrapper];
foreach($wrapper_set as $key => $value) {
	$wrapper_set[$key] = preg_replace("#{$config['FULL_URL']}#","FULL_URL",$value);
}
echo var_export($wrapper_set,true) . ";";
echo "\r\n";
echo "--END_WRAPPER_SET--";
}

?>
