<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/features.php");

// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate();

$admin = new Admin;
$admin->doAuth();

$calendar = "";
if ($config['CALENDAR']) {
	$calendar = "checked='checked'";
} // end if

$comments = "";
if ($config['COMMENTS']) {
	$comments = "checked='checked'";
} // end if

if (!$config['COMMENTS_MIN_POST']) {
	$config['COMMENTS_MIN_POST'] = "0";
} // end if

$b_notice_on = "checked=\"checked\"";
if (!$config['BIRTHDAY_NOTICE']) {
	$b_notice_on = "";
}

$active_on = "";
if ($config['ENABLE_ACTIVE_TEXT']) {
	$active_on = "checked=\"checked\"";
} // end if

$displayname_0_checked="";$displayname_1_checked="";$displayname_2_checked="";
if (!$config['DISPLAY_NAME_CHANGE']) {
	$displayname_0_checked = "checked=\"checked\"";
}
if ($config['DISPLAY_NAME_CHANGE'] == 1) {
	$displayname_1_checked = "checked=\"checked\"";
}
if ($config['DISPLAY_NAME_CHANGE'] == 2) {
	$displayname_2_checked = "checked=\"checked\"";
}

$markupoption_checked = "";
if ($config['MARKUP_HTML_TOGGLE']) {
	$markupoption_checked = "checked=\"checked\"";
}

$uratings_checked = "";
if ($config['USER_RATINGS']) {
	$uratings_checked = "checked=\"checked\"";
}

$mood_checked = "";
if ($config['ENABLE_MOODS']) {
	$mood_checked = "checked=\"checked\"";
} // end if

$tratings_checked = "";
if ($config['TOPIC_RATINGS']) {
	$tratings_checked = "checked=\"checked\"";
}


$allowimages_checked = "";
if ($config['ALLOW_IMAGE_MARKUP']) {
	$allowimages_checked = "checked=\"checked\"";
}

$fulltext = ""; $ubb = "";
if (!$config['SEARCH_METHOD'] || $config['SEARCH_METHOD'] == "fulltext") {
	$fulltext = "selected='selected'";
} else {
	$ubb = "selected='selected'";
} // end if

if (!isset($config['MIN_SEARCH_LENGTH'])) {
	$config['MIN_SEARCH_LENGTH'] = "3";
}

if (!isset($config['MAX_SEARCH_RESULTS'])) {
	$config['MAX_SEARCH_RESULTS'] = "200";
}

if (!isset($config['MAX_SEARCH_RANGE_VALUE'])) {
	$config['MAX_SEARCH_RANGE_VALUE'] = "1";
}

if (!isset($config['MAX_SEARCH_RANGE_TYPE'])) {
	$config['MAX_SEARCH_RANGE_TYPE'] = "years";
}

$rangedays="";$rangeweeks="";$rangemonths="";$rangeyears="";
if ($config['MAX_SEARCH_RANGE_TYPE'] == "days") {
	$rangedays = "selected=\"selected\"";
}
if ($config['MAX_SEARCH_RANGE_TYPE'] == "weeks") {
	$rangeweeks = "selected=\"selected\"";
}
if ($config['MAX_SEARCH_RANGE_TYPE'] == "months") {
	$rangemonths = "selected=\"selected\"";
}
if ($config['MAX_SEARCH_RANGE_TYPE'] == "years") {
	$rangeyears = "selected=\"selected\"";
}

$active_text_list = "";
if (isset($config['ACTIVE_TEXT_LIST'])) {
	foreach($config['ACTIVE_TEXT_LIST'] as $target => $replace) {
		$replace = str_replace('\"','"',$replace);
		$active_text_list .= "$target|$replace\n";
	} // end foreach
}

$markup_font_list = "";
foreach($config['MARKUP_FONTS'] as $k => $font) {
	$markup_font_list .= "$font\n";
} // end foreach

$markup_font_sizes = "";
foreach($config['MARKUP_FONT_SIZES'] as $k => $size) {
	$markup_font_sizes .= "$size\n";
} // end foreach

$tabs = array(
	"{$ubbt_lang['GENERAL']}" => "",
	"{$ubbt_lang['SEARCH_ENGINE']}" => "",
	"{$ubbt_lang['ATTACH']}" => "",
	"{$ubbt_lang['ACTIVE_TEXT']}" => "",
	"{$ubbt_lang['MARKUP_PANEL']}" => "",
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['FEATURES']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['FEATURES']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);
$admin->setCommonSubmit($ubbt_lang['UPDATE']);

// Include the template
include("../templates/default/admin/features.tmpl");

$admin->sendFooter();
?>
