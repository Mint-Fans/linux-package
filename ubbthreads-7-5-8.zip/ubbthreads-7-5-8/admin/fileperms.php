<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/fileperms.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$tabs = array(
	"{$ubbt_lang['FILE_PERMS']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['FILE_PERMS']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['FILE_PERMS']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);


$dirs = array("cache","cache_builders/custom");

$check = @opendir("../gallery/");
while ($file = readdir($check)) {
	if ($file == "." || $file == "..") continue;
	$dirs[] = "gallery/$file/full";
	$dirs[] = "gallery/$file/medium";
	$dirs[] = "gallery/$file/thumbs";
}

$check = @opendir("../images/avatars");
while ($file = readdir($check)) {
	if (!is_dir("../images/avatars/$file")) continue;
	if ($file == "." || $file == "..") continue;
	$dirs[] = "images/avatars/$file";
}

$check = @opendir("../images/forumimages");
while ($file = readdir($check)) {
	if (!is_dir("../images/forumimages/$file")) continue;
	if ($file == "." || $file == "..") continue;
	$dirs[] = "images/forumimages/$file";
}

$check = @opendir("../images/graemlins");
while ($file = readdir($check)) {
	if (!is_dir("../images/graemlins/$file")) continue;
	if ($file == "." || $file == "..") continue;
	$dirs[] = "images/graemlins/$file";
}

$check = @opendir("../images/icons");
while ($file = readdir($check)) {
	if (!is_dir("../images/icons/$file")) continue;
	if ($file == "." || $file == "..") continue;
	$dirs[] = "images/icons/$file";
}

$check = @opendir("../images/markup_panel");
while ($file = readdir($check)) {
	if (!is_dir("../images/markup_panel/$file")) continue;
	if ($file == "." || $file == "..") continue;
	$dirs[] = "images/markup_panel/$file";
}

$check = @opendir("../images/news");
while ($file = readdir($check)) {
	if (!is_dir("../images/news/$file")) continue;
	if ($file == "." || $file == "..") continue;
	$dirs[] = "images/news/$file";
}

$check = @opendir("../images/moods");
while ($file = readdir($check)) {
	if (!is_dir("../images/moods/$file")) continue;
	if ($file == "." || $file == "..") continue;
	$dirs[] = "images/moods/$file";
}

/*
avatars
	forumimages
	graemlins
	icons
*/
	
$dirs[] = "includes";

$check = @opendir("../languages/");
while ($file = readdir($check)) {
	if ($file == "." || $file == "..") continue;
	$dirs[] = "languages/$file";
	$dirs[] = "languages/$file/admin";
}

$dirs[] = "sessions";
$dirs[] = "styles";
$dirs[] = "templates/default";
$dirs[] = "tmp";

$results = array();
foreach ($dirs as $k => $v) {
	$results[$v]['header'] = "<span style='color: green'>OK</span>";
	$results[$v]['checks'] = "";
	$dir = @opendir("../$v");
	while ($file = @readdir($dir)) {
		if ($file == "..") continue;
		if (is_writeable("../$v/$file")) {
			$status = "<span style='color: green'>OK</span>";
		} else {
			$status = "<span style='color: red'>FAIL</span>";
			$results[$v]['header'] = "<span style='color: red'>FAIL</span>";
		}
		if ($file == ".") $file = "Directory Check";
		$results[$v]['checks'] .= "<tr><td>$file</td><td>$status</td></tr>";
	}
}

	
	/*

cache_builders/custom
images
	avatars
	forumimages
	graemlins
	icons
includes
languages
sessions
templates
styles
*/

// Include the template
include("../templates/default/admin/fileperms.tmpl");

$admin->sendFooter();
?>
