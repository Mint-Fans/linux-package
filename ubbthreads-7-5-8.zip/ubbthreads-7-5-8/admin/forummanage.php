<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/forummanage.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Grab all current boards
$query = "
	SELECT t1.FORUM_ID,FORUM_SORT_ORDER
	FROM {$config['TABLE_PREFIX']}FORUMS AS t1,
		{$config['TABLE_PREFIX']}CATEGORIES AS t2
		WHERE t2.CATEGORY_ID = t1.CATEGORY_ID
	ORDER BY t2.CATEGORY_SORT_ORDER, t1.FORUM_SORT_ORDER
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$i=0;
$sorts = array();
while(list($number,$sort) = $dbh->fetch_array($sth)) {
	$sorts[$number] = $sort;
} // end while


include("{$config['FULL_PATH']}/cache/forum_cache.php");
if (!sizeof($tree)) {
	list($tree,$style_cache,$lang_cache) = build_forum_cache();
}
		
$forum = array();
$i = 0;
foreach($tree['categories'] as $cat => $cat_title) {
	$sort = 0;
	if (!isset($tree[$cat])) continue;
	foreach($tree[$cat] as $forum_id => $forum_title) {
		$sort++;
		if ($tree['active'][$forum_id]) {
			$tree['active'][$forum_id] = "checked=\"checked\"";
		} // end if
		$indent = "";
		preg_match_all("/&nbsp;/",$forum_title,$matches);
		for($x=1;$x<sizeof($matches['0']);$x++) {
			$indent .= "&nbsp;";
		}
		$forum_title = preg_replace("/&nbsp;/","",$forum_title);
		$forum[$i] = array(
			"number" => $forum_id,
			"title" => $forum_title,
			"sort" => $sorts[$forum_id],
			"cat" => $cat,
			"active" => $tree['active'][$forum_id],
			"category" => $cat_title,
			"indent" => "$indent",
		);
		$i++;
	}
}

$tabs = array(
	"{$ubbt_lang['FORUM_SET']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['FORUM_SET']);
$admin->setPageTitle($ubbt_lang['FORUM_SET']);
$admin->sendHeader();
$admin->createTopTabs($tabs);


// Include the template
include("../templates/default/admin/forummanage.tmpl");


$bottomtabs[$ubbt_lang['ADD_NEW']] = "{$config['BASE_URL']}/admin/createforum.php";

$admin->createBottomTabs($bottomtabs);

$admin->sendFooter();
?>
