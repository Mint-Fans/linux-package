<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/gallery.php");

// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME,USER_REAL_EMAIL");

$admin = new Admin;

$admin->doAuth();

$tabs = array(
	"{$ubbt_lang['GALLERY']}" => "",
);

// What options do we have for photo manipulation?
$gd = false; $im = false;
$library_options = "";
if (function_exists(imagegd2)) {
	$gd = true;
	if ($config['GRAPHICS_LIBRARY'] == "gd") {
		$selected = "selected='selected'";
	} // end if
	$library_options .= "<option value=\"gd\" $selected>{$ubbt_lang['USE_GD']}</option>";
} // end if

if ($config['CONVERT_PATH']) {
	$im = true;
	$selected = "";
	if ($config['GRAPHICS_LIBRARY'] == "im") {
		$selected = "selected='selected'";
	} // end if
	$library_options .= "<option value=\"im\" $selected>{$ubbt_lang['USE_IM']}</option>";
} // end if

$thumb_quality = "";
$medium_quality = "";
$full_quality = "";
for($i=10;$i>=1;$i--) {
	$thumb_sel = ""; $med_sel = ""; $full_sel = "";
	if ($config['THUMB_QUALITY']/10 == $i) {
		$thumb_sel = "selected='selected'";
	}
	if ($config['MEDIUM_QUALITY']/10 == $i) {
		$med_sel = "selected='selected'";
	}
	if ($config['FULL_QUALITY']/10 == $i) {
		$full_sel = "selected='selected'";
	}
	$val = $i * 10;
	$thumb_quality .= "<option value='$val' $thumb_sel>$i</option>";
	$medium_quality .= "<option value='$val' $med_sel>$i</option>";
	$full_quality .= "<option value='$val' $full_sel>$i</option>";
} // end for

// Create the Page
$admin->setCurrentMenu($ubbt_lang['GALLERY']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['GALLERY']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);
$admin->setCommonSubmit($ubbt_lang['UPDATE']);

// Include the template
include("../templates/default/admin/gallery.tmpl");

$admin->sendFooter();
?>
