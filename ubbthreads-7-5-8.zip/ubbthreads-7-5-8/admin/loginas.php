<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/sendpassword.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info
$uid = get_input("uid","get");

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");
$html = new html;

$admin = new Admin;

$admin->doAuth();

$uid = get_input("uid","get");

// -------------------------
// Grab this password
$query = "
	SELECT USER_ID,USER_SESSION_ID,USER_DISPLAY_NAME
	FROM   {$config['TABLE_PREFIX']}USERS
	WHERE  USER_ID = '$uid'
";
$sth = $dbh -> do_query($query,__LINE__,__FILE__);
list($Uid,$oldsess,$username) = $dbh -> fetch_array($sth);

if (!$config['COOKIE_PATH']) {
	$COOKIE_PATH = "/";
}
else {
	$COOKIE_PATH = $config['COOKIE_PATH'];
}


// ---------------
// Log this action
admin_log("LOGINAS", "$username:$uid");

// --------------------------------------
// Set a cookie or register a session var
// If we have a session id don't generate a new one because it will
// log the real user out if they are logged in
if (!$oldsess) {
	srand((double)microtime()*1000000);
	$sessionid = md5(rand(0,32767));
	$newsess = addslashes($sessionid);
	$query = "
		UPDATE {$config['TABLE_PREFIX']}USERS
		SET USER_SESSION_ID = '$newsess'
		WHERE USER_ID='$uid'
	";
	$dbh -> do_query($query,__LINE__,__FILE__);
}
else {
	$sessionid = $oldsess;
}

// Set a better default cookie expiration ( 1 week )
if (!isset($config['COOKIE_LIFETIME'])) $config['COOKIE_LIFETIME'] = 604800;
if ($config['COOKIE_LIFETIME'] > 604800) $config['COOKIE_LIFETIME'] = 604800;

$html -> ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_hash",0,time()+$config['COOKIE_LIFETIME'],"{$config['COOKIE_PATH']}");
$html -> ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_hash",0,time()-86400,"$COOKIE_PATH");
$html -> ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_myid","$Uid",time()+$config['COOKIE_LIFETIME'],"$COOKIE_PATH");
$html -> ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_mysess","$sessionid","0","$COOKIE_PATH");


if (strpos($_SERVER["SERVER_SOFTWARE"], "Apache") === false || headers_sent()) {
	$cfrm = make_ubb_url("ubb=cfrm", "", false);
	echo <<<EOF
	<html>
	<head>
	<meta http-equiv="Refresh" content="1;url={$cfrm}">
	</head>
	<body>
	</body>
	</html>
EOF;
} else {
	$cfrm = str_replace('&amp;', '&', make_ubb_url("ubb=cfrm", "", false));
	header("Location: $cfrm");
	exit;
}


?>
