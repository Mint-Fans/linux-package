<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/membermanage.php");
require ("../languages/{$config['LANGUAGE']}/admin/stop_forum_spam.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_TIME_FORMAT,USER_TIME_OFFSET");
$html = new html;


$admin = new Admin;

$admin->doAuth(array("EDIT_USERS"));

// Expire any old bans
trigger_ban_expiration();

if (!isset($config['MINIMUM_AGE']) || !$config['MINIMUM_AGE']) {
	$config['MINIMUM_AGE'] = 13;
}

// Grab the available groups we can search in
$groupselection = '<table border="0" width="100%">';
$query = "
	SELECT GROUP_ID,GROUP_NAME
	FROM {$config['TABLE_PREFIX']}GROUPS
	WHERE GROUP_IS_DISABLED <> '1'
	ORDER BY GROUP_ID
";
$sth = $dbh -> do_query($query,__LINE__,__FILE__);
$row = 0;
while(list($id,$name) = $dbh -> fetch_array($sth)) {
	if ($user['USER_MEMBERSHIP_LEVEL'] == "Moderator" && $id < 3) continue;
	if ($row == 0) {
		$groupselection .= "<tr>";
	}
	$row++;
	$groupselection .= <<<EOF
<td width="50%" class="stdautorow colored-row">
<input type="checkbox" name="Group-$id" value="$id" id="Group-$id" />
 <label class="radio" for="Group-$id">$name</label>
</td>
EOF;
	if ($row == 2) {
		$groupselection .= "</tr>";
		$row = 0;
	}
}

if ($row > 0) {
	for ( $i=0; $i<(2-$row); $i++) {
		$groupselection .= "<td width=\"50%\">&nbsp;</TD>";
	}
	$groupselection .= "</tr>";
}
$groupselection .= "</table>";

// Setup the date selection options
$monthoptions = <<<EOF
<option value="0">{$ubbt_lang['MONTH']}</option>
<option value="1">{$ubbt_lang['JAN']}</option>
<option value="2">{$ubbt_lang['FEB']}</option>
<option value="3">{$ubbt_lang['MAR']}</option>
<option value="4">{$ubbt_lang['APR']}</option>
<option value="5">{$ubbt_lang['MAY']}</option>
<option value="6">{$ubbt_lang['JUN']}</option>
<option value="7">{$ubbt_lang['JUL']}</option>
<option value="8">{$ubbt_lang['AUG']}</option>
<option value="9">{$ubbt_lang['SEP']}</option>
<option value="10">{$ubbt_lang['OCT']}</option>
<option value="11">{$ubbt_lang['NOV']}</option>
<option value="12">{$ubbt_lang['DEC']}</option>
EOF;

$dayoptions = "<option value=\"0\">{$ubbt_lang['DAY']}</option>";
for($i=1;$i<=31;$i++) {
	$dayoptions .= "<option>$i</option>";
}
$temp = getdate();
$thisyear = $temp["year"];

$regon = <<<EOF
<select name="regon">
<option value="b">{$ubbt_lang['BEFORE']}</option>
<option value="o" selected="selected">{$ubbt_lang['ON']}</option>
<option value="a">{$ubbt_lang['AFTER']}</option>
</select>
EOF;

$regyear = "<select name=\"regyear\">";
$regyear .= "<option value=\"\">{$ubbt_lang['YEAR']}</option>";
for ($i=$thisyear;$i>1990;$i--) {
	$regyear .= "<option>$i</option>";
}
$regyear .= "</select>";
$i=0;

$regmonth = "<select name=\"regmonth\">$monthoptions</select>";
$regday = "<select name=\"regday\">$dayoptions</select>";

$lastposton = <<<EOF
<select name="lastposton">
<option value="b">{$ubbt_lang['BEFORE']}</option>
<option value="o" selected="selected">{$ubbt_lang['ON']}</option>
<option value="a">{$ubbt_lang['AFTER']}</option>
</select>
EOF;
$lastpostyear = "<select name=\"lastpostyear\">";
$lastpostyear .= "<option value=\"\">{$ubbt_lang['YEAR']}</option>";
for ($i=$thisyear;$i>1990;$i--) {
	$lastpostyear .= "<option>$i</option>";
}
$i=0;
$lastpostyear .= "</select>";
$lastpostmonth = "<select name=\"lastpostmonth\">$monthoptions</select>";
$lastpostday = "<select name=\"lastpostday\">$dayoptions</select>";

$laston = <<<EOF
<select name="laston">
<option value="b">{$ubbt_lang['BEFORE']}</option>
<option value="o" selected="selected">{$ubbt_lang['ON']}</option>
<option value="a">{$ubbt_lang['AFTER']}</option>
</select>
EOF;
$lastyear = "<select name=\"lastyear\">";
$lastyear .= "<option value=\"\">{$ubbt_lang['YEAR']}</option>";
for ($i=$thisyear;$i>1990;$i--) {
	$lastyear .= "<option>$i</option>";
}
$i=0;
$lastyear .= "</select>";
$lastmonth = "<select name=\"lastmonth\">$monthoptions</select>";
$lastday = "<select name=\"lastday\">$dayoptions</select>";

// Get the list of users awaiting registration approval
// or that have not verified their email address
$query = "
	SELECT t1.USER_LOGIN_NAME,t1.USER_DISPLAY_NAME,t2.USER_REAL_EMAIL,t1.USER_REGISTRATION_IP,t1.USER_ID,t1.USER_IS_UNDERAGE,t1.USER_IS_APPROVED,t1.USER_REGISTERED_ON
	FROM   {$config['TABLE_PREFIX']}USERS as t1,
	{$config['TABLE_PREFIX']}USER_PROFILE as t2
	WHERE  (t1.USER_IS_APPROVED = 'no'
	OR (t1.USER_IS_APPROVED <> 'no' AND t1.USER_IS_APPROVED <> 'yes'))
	AND t1.USER_ID <> '1'
	AND t1.USER_ID = t2.USER_ID
	ORDER BY t1.USER_ID
";
$sth = $dbh -> do_query($query,__LINE__,__FILE__);
$i=0;
$que = array();
while(list($lname,$uname,$uemail,$uip,$unum,$ucoppa,$uapproved,$ureged) = $dbh->fetch_array($sth)) {
	$que[$i]['lname'] = $lname;
	$que[$i]['uname'] = $uname;
	$que[$i]['email'] = $uemail;
	$que[$i]['ip'] = $uip;
	$que[$i]['num'] = $unum;
	$que[$i]['reged'] = $html->convert_time($ureged,$user['USER_TIME_OFFSET'],$user['USER_TIME_FORMAT']);
	if ($ucoppa) {
		$que[$i]['coppa'] = "<span class=\"msbad\">{$ubbt_lang['TEXT_YES']}</span>";
	}
	else {
		$que[$i]['coppa'] = "<span class=\"msgood\">{$ubbt_lang['TEXT_NO']}</span>";
	}
	if ($config['EMAIL_VERIFICATION']) {
		if ($uapproved == "no") {
			$que[$i]['verified'] = "{$ubbt_lang['IS_VER']} <span class=\"msgood\">{$ubbt_lang['TEXT_YES']}</span><br />";
		}
		else {
			$que[$i]['verified'] = "{$ubbt_lang['IS_VER']} <span class=\"msbad\">{$ubbt_lang['TEXT_NO']}</span><br />";
		}
	}
	else {
		$que[$i]['verified'] = "";
	}
	$i++;
}

$totals = $i-1;

// Grab any display name changes waiting for approval
$query = "
	SELECT t1.DISPLAY_NAME_ID,t1.USER_ID,t1.DISPLAY_NAME_REQUEST,t2.USER_LOGIN_NAME,t2.USER_DISPLAY_NAME
	FROM {$config['TABLE_PREFIX']}DISPLAY_NAMES AS t1,
	{$config['TABLE_PREFIX']}USERS AS t2
	WHERE t1.USER_ID = t2.USER_ID
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$i=0;
$dsp = array();
while(list($entry,$uid,$displayname,$loginname,$username) = $dbh->fetch_array($sth)) {
	$dsp[$i]['entry'] = $entry;
	$dsp[$i]['uid'] = $uid;
	$dsp[$i]['displayname'] = $displayname;
	$dsp[$i]['loginname'] = $loginname;
	$dsp[$i]['username'] = $username;
	$i++;
}

$totaldsp = $i-1;

// Grab any banned IPs
$query = "
	SELECT BANNED_HOST
	FROM {$config['TABLE_PREFIX']}BANNED_HOSTS
	WHERE BANNED_HOST IS NOT NULL AND BANNED_HOST <> ''
	ORDER BY BANNED_HOST
";
$sth = $dbh->do_query($query);
$iplist = "";
while(list($ip) = $dbh->fetch_array($sth)) {
	if ($ip == "NULL" || $ip == "") {
		continue;
	}
	$iplist .= "$ip\n";
}

// Grab any banned IPs
$query = "
	SELECT BANNED_EMAIL
	FROM {$config['TABLE_PREFIX']}BANNED_EMAILS
	ORDER BY BANNED_EMAIL
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$emailist = "";
while(list($email) = $dbh->fetch_array($sth)) {
	$emailist .= "$email\n";
}

// Grab any predefined member searches
$query = "
	SELECT MEMBER_SEARCH_ID,MEMBER_SEARCH_TITLE
	FROM {$config['TABLE_PREFIX']}MEMBER_SEARCHES
	ORDER BY MEMBER_SEARCH_TITLE
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$savedsearches = array();
$i=0;
while(list($mnumber,$mtitle) = $dbh->fetch_array($sth)) {
	$savedsearches[$i]['mnumber'] = $mnumber;
	$savedsearches[$i]['mtitle'] = $mtitle;
	$i++;
}

if ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator") {
	$tabs = array(
		"{$ubbt_lang['VIEW']}" => "",
		"{$ubbt_lang['REG_QUE']}" => "",
		"{$ubbt_lang['DISP_QUE']}" => "",
		"{$ubbt_lang['BAN_LIST']}" => "",
		"{$ubbt_lang['ADD_USER']}" => "",
	);
} else {
	$tabs = array(
		"{$ubbt_lang['VIEW']}" => "",
	);
}

$admin->setCurrentMenu($ubbt_lang['MEM_MAN']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['MEM_MAN']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);


// Include the template
include("../templates/default/admin/membermanage.tmpl");

$admin->sendFooter();
?>
