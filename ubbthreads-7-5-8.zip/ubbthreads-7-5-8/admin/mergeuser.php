<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/mergeuser.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Get the input
$uid = get_input("uid","both");

// -----------------------------
// Grab this user's display name
$query = "
	select	t1.USER_DISPLAY_NAME,t2.USER_TOTAL_POSTS
	from		{$config['TABLE_PREFIX']}USERS as t1,
					{$config['TABLE_PREFIX']}USER_PROFILE as t2
	where		t1.USER_ID = ?
	and			t1.USER_ID = t2.USER_ID
";
$sth = $dbh -> do_placeholder_query($query,array($uid),__LINE__,__FILE__);
list($dname,$posts) = $dbh -> fetch_array($sth);
if (!$posts) { $posts = 0; }

$tabs = array(
	"{$ubbt_lang['MERGE_USER']}: $dname (#$uid)" => ""
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['MEM_MAN']);
$admin->setParentTitle($ubbt_lang['MEM_MAN'],"membermanage.php");
$admin->setPageTitle($ubbt_lang['MERGE_USER']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/mergeuser.tmpl");

$admin->sendFooter();
?>
