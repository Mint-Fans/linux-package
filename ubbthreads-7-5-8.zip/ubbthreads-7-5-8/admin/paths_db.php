<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/paths_db.php");

// Get the input
$returntab = get_input("returntab","both");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate();

$admin = new Admin;
$admin->doAuth();

$tabs = array(
	"{$ubbt_lang['DATABASE_CONFIG']}" => "",
	"{$ubbt_lang['PATH_URL']}" => ""
);

// Default settings
if (!isset($config['TABLE_PREFIX'])) { $config['TABLE_PREFIX'] = "ubbt_"; }
$PERSISTENT_DB_CONNECTION = "";
if ($config['PERSISTENT_DB_CONNECTION']) {
	$PERSISTENT_DB_CONNECTION = "checked=\"checked\"";
}

// Create the Page
$admin->setCurrentMenu($ubbt_lang['DB_P_URL']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['DB_P_URL']);
$admin->sendHeader();
$admin->createTopTabs($tabs);
$admin->setCommonSubmit($ubbt_lang['UPDATE']);

// Include the template
include("../templates/default/admin/paths_db.tmpl");

$admin->sendFooter();
?>
