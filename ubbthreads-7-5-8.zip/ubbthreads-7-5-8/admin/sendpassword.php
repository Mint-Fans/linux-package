<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/sendpassword.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$uid = get_input("uid","get");

$query = "
	SELECT u.USER_LOGIN_NAME, up.USER_REAL_EMAIL, up.USER_LANGUAGE, u.USER_DISPLAY_NAME
		FROM {$config['TABLE_PREFIX']}USERS u,
				 {$config['TABLE_PREFIX']}USER_PROFILE up
	WHERE u.USER_ID = ?
		AND	u.USER_ID = up.USER_ID
";
$sth = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
list($Username,$email,$lang,$Displayname) = $dbh->fetch_array($sth);

// -------------------
// Generate a password
$a = time();
mt_srand($a);
$passset = array('a','b','c','d','e','f','g','h','i','j','k','m','n','o','p','q','r','s','t','u','v','x','y','z','A','B','C','D','E','F','G','H','I','J','K','M','N','P','Q','R','S','T','U','V','W','X','Y','Z','2','3','4','5','6','7','8','9');
$chars = sizeof($passset);
$pass = "";
for ($i=0; $i < 6; $i++) {
	$randnum = intval(mt_rand(0,$chars));
	$pass .= $passset[$randnum];
}

// ----------------------------
// Now let's crypt the password
$crypt = md5($pass);

// -----------------------------
// Now let's update the database
$query = "
	UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
	SET 	 USER_TEMPORARY_PASSWORD = ?
	WHERE  USER_ID = ?
";
$dbh -> do_placeholder_query($query,array($crypt,$uid),__LINE__,__FILE__);

// -----------------------
// Now we mail it to them

$mailer  = new mailer("../");
$mailer->set_language($lang);
$mailer->set_subject('PSND_SUBJECT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE']));
$mailer->set_salute('EMAIL_SALUTE', array('USERNAME' => $Displayname));
$mailer->add_content('PSND_CONTENT', array('BOARD_TITLE' => $config['COMMUNITY_TITLE'], 'USERNAME' => $Username, 'PASSWORD' => $pass));
$mailer->ubbt_mail($email);

$admin->redirect($ubbt_lang['PASS_SENT'],"{$config['BASE_URL']}/admin/showuser.php?uid=$uid",$ubbt_lang['F_LOC']);

?>