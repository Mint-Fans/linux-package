<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/styles.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();


// Setup the defaults
$StyleSheet = $config['DEFAULT_STYLE'];
$stylelist = "";
$query = "
	select STYLE_ID,STYLE_NAME,STYLE_IS_ACTIVE
	from {$config['TABLE_PREFIX']}STYLES
	order by STYLE_NAME
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$available = "";
while(list($style,$desc,$active) = $dbh->fetch_array($sth)) {
	$checked = "";
	$default = "";
	if ($active) {
		$checked = "checked=\"checked\"";
	}
	if ($config['DEFAULT_STYLE'] == $style) {
		$default = "checked=\"checked\"";
	}
	$available .= "<tr><td class=\"autobottom stdautorow\"><input type=\"radio\" name=\"DEFAULT_STYLE\" value=\"$style\" $default /></td>";
	$available .= "<td class=\"autobottom stdautorow\"><input type=\"checkbox\" name=\"active[$style]\" value=\"1\" $checked /></td>";
	$available .= "<td class=\"autobottom stdautorow\">$desc</td>";
	$available .= "<td class=\"autobottom stdautorow\">[<a href=\"javascript:void(0)\" onclick=\"javascript:window.open('" . make_ubb_url("ubb=previewskin&skin=$style", "", false) . "','_blank','scrollbars=yes,toolbar=no,menubar=no,location=no,directories=no,status=no,width=800,height=600');\">{$ubbt_lang['PREVIEW_IT']}</a>]&nbsp;&middot;&nbsp;[<a href=\"{$config['BASE_URL']}/admin/editstyle.php?style=$style\">{$ubbt_lang['EDIT_IT']}</a>]&nbsp;&middot;&nbsp;[<a href=\"{$config['BASE_URL']}/admin/exportstyle.php?style=$style&w=1\">{$ubbt_lang['EXPORT_WRAPPER']}</a>]&nbsp;&middot;&nbsp;[<a href=\"{$config['BASE_URL']}/admin/exportstyle.php?style=$style\">{$ubbt_lang['EXPORT']}</a>]&nbsp;&middot;&nbsp;[<a href=\"javascript:void(0);\" onclick=\"confirm_delete('$style')\">{$ubbt_lang['DELETE']}</a>]</td></tr>";
}

$tabs = array(
	"{$ubbt_lang['PRIMARY_S']}" => "",
	"{$ubbt_lang['WRAPPERS']}" => "{$config['BASE_URL']}/admin/wrappers.php",
);

$admin->setCurrentMenu($ubbt_lang['STYLES']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['STYLES']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
include("../templates/default/admin/styles.tmpl");

$bottomtabs = array(
	"{$ubbt_lang['ADD_S']}" => "{$config['BASE_URL']}/admin/editstyle.php",
	"{$ubbt_lang['IMPORT_STYLE']}" => "{$config['BASE_URL']}/admin/importstyle.php",
);
$admin->createBottomTabs($bottomtabs,0);

$admin->sendFooter();
?>
