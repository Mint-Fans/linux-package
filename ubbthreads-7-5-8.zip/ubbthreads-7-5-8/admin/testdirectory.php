<?php
//	Script Version 7.5.8

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/testdirectory.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$type = get_input("type","get");
$dirname = get_input("dirname","get");

// -----------------
// Get the user info
$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");
$html = new html;

$admin = new Admin;

$admin->doAuth();



// -----------------------------
// Make sure they should be here
if ($user['USER_MEMBERSHIP_LEVEL'] != 'Administrator'){
	$html -> not_right ("{$ubbt_lang['ADMIN_ONLY']}");
}

// ------------------------
// Send them a confirmation
$results = "";
if (file_exists($dirname)) {
	$results .= "{$ubbt_lang['EXIST']} ";
	$check = @fopen("$dirname/test.file","w");
	if (!$check) {
		$results .= sprintf('<span style="color: #F00;">%s</span>', $ubbt_lang['NOWRITE']);
		$error = 1;
	}
	else {
		$results .= sprintf('<span style="color: #0F0;">%s</span>', $ubbt_lang['CANWRITE']);
	}
}
else {
	$results .= sprintf('<span style="color: #F00;">%s</span>', $ubbt_lang['NOEXIST']);
	$error = 1;
}

if (isset($error)) {
	$results .= "<br />{$ubbt_lang['FAIL']}";
	if ($type=="sess") {
		$results .= " {$ubbt_lang['SESS']}";
	}
}
else {
	$results .= "<br /><br />{$ubbt_lang['PASS']}";
}
include("../templates/default/admin/testdirectory.tmpl");
?>
