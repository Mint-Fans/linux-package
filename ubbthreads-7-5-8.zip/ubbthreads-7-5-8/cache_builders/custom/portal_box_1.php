<?php
/* PHP CODE HERE */

/* BODY HERE */
$body = <<<EOF
EOF;

?>