<?php
//	Script Version 7.5.8

if (!defined('UBB_MAIN_PROGRAM')) {
	exit;
}

// Activity clause?
$thisclause = "";
if ($config['FEATURED_MEMBER']) {
	$now = $html->get_date();
	$date = $now - $config['FEATURED_MEMBER'] * 86400;
	$thisclause = "AND t3.USER_LAST_POST_TIME > $date";
}

$query = "
	SELECT t1.USER_DISPLAY_NAME,t1.USER_ID,t2.USER_NAME_COLOR,t1.USER_MEMBERSHIP_LEVEL,t2.USER_AVATAR,t1.USER_REGISTERED_ON,t2.USER_TOTAL_POSTS,t2.USER_AVATAR_WIDTH,t2.USER_AVATAR_HEIGHT
	FROM   {$config['TABLE_PREFIX']}USERS as t1,
		   {$config['TABLE_PREFIX']}USER_PROFILE as t2,
		   {$config['TABLE_PREFIX']}USER_DATA as t3
	WHERE  t1.USER_ID = t2.USER_ID
	AND	   t1.USER_ID = t3.USER_ID
	AND    t1.USER_IS_BANNED != '1'
	AND	   t1.USER_ID > 1
	$thisclause
	ORDER BY rand() limit 1 
";
$sth = $dbh -> do_query($query,__LINE__,__FILE__);
list($uname,$uid,$color,$level,$avatar,$reged_on,$posts,$width,$height) = $dbh -> fetch_array($sth);

if (!$avatar) {
  if (!$style_array['general']) {
    $style_array['general'] = "general/default";
  }

	$avatar = "{$config['FULL_URL']}/images/{$style_array['general']}/nopicture.gif";
	$imagehw = getimagesize($avatar);
	$width = $imagehw[0];
	$height = $imagehw[1];
} // end if

$picsize = "";
if ($width && $height) {
	$picsize = "width='$width' height='$height'";
} else {
	if ($config['AVATAR_MAX_WIDTH'] && $config['AVATAR_MAX_HEIGHT']) {
		$picsize = "width=\"{$config['AVATAR_MAX_WIDTH']}\" height=\"{$config['AVATAR_MAX_HEIGHT']}\"";
	} // end if
} // end if


$uncolored = $uname;
$username = $html->user_color($uname,$color,$level);
$reg_date = $html->convert_time($reged_on);
preg_match("/<span class=\"date\">(.*?)<\/span>/",$reg_date,$matches);
$reg_date = trim($matches['1']);

$smarty->assign("avatar",$avatar);
$smarty->assign("username",$username);
$smarty->assign("uid",$uid);
$smarty->assign("reg",$reg_date);
$smarty->assign("uncolored",$uncolored);
$smarty->assign("posts",$posts);
$smarty->assign("picsize",$picsize);

$island = $smarty->fetch("island_featured_member.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/featured_member.php",$island);

@chmod("{$config['FULL_PATH']}/cache/featured_member.php",0666);

?>
