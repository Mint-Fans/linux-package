<?php
//	Script Version 7.5.8

if (!defined('UBB_MAIN_PROGRAM')) {
	exit;
}

if (!$name) $name = "Portal Box $portal_id";

include("{$config['FULL_PATH']}/cache_builders/custom/portal_box_$portal_id.php");

$smarty->assign("name",$name);
$smarty->assign("body",$body);

$island = $smarty->fetch("portal_box_custom.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/portal_box_$portal_id.php",$island);

@chmod("{$config['FULL_PATH']}/cache/portal_box_$portal_id.php",0666);

?>
