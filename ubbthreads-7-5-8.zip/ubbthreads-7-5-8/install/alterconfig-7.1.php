<?php

$newconfigs['MAX_DELETE_TIME'] = 60;
$newconfigs['RELATIVE_TIME'] = 1;
$newconfigs['CUSTOM_TITLE_MAX'] = 25;

?>
