<?php
$newconfigs['DEFAULT_USER_GROUPS'] = array(4);
?>
