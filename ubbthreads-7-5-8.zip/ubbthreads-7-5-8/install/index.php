<?php
//	Script Version 7.5.8
// Require the library
$metarefresh = "";
$step_navigation = "";
require("install_header.tmpl");
echo "<table border='0' width='95%' align='center'>";
echo "<tr><td class=\"stdautorow\">";
echo "If you are doing an initial install of UBB.threads&trade;, <a href='install.php'>Go here</a>.<br /><br />";
echo "If you are upgrading UBB.threads&trade; from a previous version, <a href='upgrade.php'>Go here</a>.";
echo "</td></tr>";
echo "</table>";
require("install_footer.tmpl");

?>
