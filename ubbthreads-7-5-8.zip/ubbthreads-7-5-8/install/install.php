<?php
/*
//	Script Version 7.5.8
*/

$thisversion = "XXXXXXXXXXX";
error_reporting(1);

@include("../includes/config.inc.php");
if (file_exists("../cache/forum_cache.php")) {
	basic_header();
	echo "Already installed.";
	basic_footer();
	exit;
}

// -------------
// Get the input
$step = get_input("step");
$sessiondir = get_input("sessiondir");
$dbserver = get_input("dbserver");
$dbname = get_input("dbname");
$dbuser = get_input("dbuser");
$dbpass = get_input("dbpass");
$servererror = get_input("servererror");
$nameerror = get_input("nameerror");
$usererror = get_input("usererror");
$passerror = get_input("passerror");
$TABLE_PREFIX = get_input("TABLE_PREFIX");
$COOKIE_PREFIX = get_input("COOKIE_PREFIX");
$FULL_URL = get_input("FULL_URL");
$path = get_input("path");
$referer = get_input("referer");
$FULL_URLerror = get_input("FULL_URLerror");
$patherror = get_input("patherror");
$referererror = get_input("referererror");
$display_name = get_input("display_name");
$email = get_input("email");
$login_name = get_input("login_name");
$password = get_input("password");
$verify_password = get_input("verify_password");
$option = get_input("option");

$step_navigation = "";

// Go to the first step
if ( (!$step) || ($option == "Check again") ){
	$step = 1;
	step1($sessiondir);
}
if ($option == "Verify url/path settings") {
	$step = 4;
}
if ($step == 2) {
	if (!$TABLE_PREFIX) { $TABLE_PREFIX = "ubbt_"; }
	step2($step,$dbserver,$dbname,$dbuser,$dbpass,$servererror,$nameerror,$usererror,$passerror,$TABLE_PREFIX,$COOKIE_PREFIX,$sessiondir);
}
if ($step == 3) {
	step3($step,$dbserver,$dbname,$dbuser,$dbpass,$TABLE_PREFIX,$COOKIE_PREFIX,$sessiondir);
}
if ($step == 4) {
	step4($step,$dbserver,$dbname,$dbuser,$dbpass,$FULL_URL,$path,$referer,$FULL_URLerror,$patherror,$referererror,$TABLE_PREFIX,$COOKIE_PREFIX,$sessiondir);
}
if ($step == 5) {
	step5($step,$dbserver,$dbname,$dbuser,$dbpass,$FULL_URL,$path,$referer,$TABLE_PREFIX,$COOKIE_PREFIX,$sessiondir);
}
if ($step == 6) {
	step6($step,$dbserver,$dbname,$dbuser,$dbpass,$FULL_URL,$path,$referer,$TABLE_PREFIX,$COOKIE_PREFIX,$sessiondir);
}
if ($step == 7) {
	step7($display_name,$email,$login_name,$password,$verify_password);
}
if ($step == 8) {
	step8($display_name,$email,$login_name,$password,$verify_password);
}

// Print out the header
function basic_header($step="") {
	$metarefresh="";
	$step_navigation = "";

	$step_array=array(1,2,3,4,5,6,7,8);
	$step_instructions = array(
		1 => "Permissions",
		2 => "Database Info",
		3 => "Database Check",
		4 => "Paths/URLs",
		5 => "Paths/URLs Check",
		6 => "Config Creation",
		7 => "Admin Creation",
		8 => "Table Creation",
	);

	foreach ($step_array as $k => $v) {
		$font_open = "";
		$font_close = "";
		$mid_dot = "&nbsp; ";
		if ($step == $v) {
			$mid_dot = " <b>&middot;</b>";
			$font_open = "<font color='green'>";
			$font_close = "</font>";
		} // end if
		$step_navigation .= " $mid_dot $font_open{$step_instructions[$v]}$font_close<br />";
	}
	include("install_header.tmpl");
	echo "<p align='center'>";
	echo "<b>Step $step</b>";
	echo "</p><p align='center'>";
}

// Print out the footer
function basic_footer() {
	include("install_footer.tmpl");
}

// ----------------------------------------------------------------------
// STEP 1
function step1($sessiondir) {
	$step = 1;
	$scriptname = find_environmental('PHP_SELF');
	basic_header($step);
	echo "
	<table width=600 border=1>
	<tr>
	<td class=stdautorow colspan=2>
	In order to automate the installation procedure, we first need to make sure all of the proper files have write access.  If any of these checks fail you will need to change the permissions on these files.  (CHMOD 666 or 664 on Linux and granting write access to the files/directories on Windows.  Any directories listed should have wide permissions such as 775 or 777.)
	</td>
	</tr>
	<tr>
	<td align=center colspan=2 class=stdautorow>
	<br>
	<span class=HEADER>Main Directory</span>
	</td>
	</tr>
	<tr>
	<td width=30% class=stdautorow>
	<b>includes/*</b>
	</td>
	";

	$check = @fopen("../includes/index.html","w");
	@chmod("../includes/index.html",0666);
	if (!$check) {
		@chmod("../includes",0775);
	}

	$dir = opendir("../includes");
	while ($file = readdir($dir)) {
		$check = "";
		if (!preg_match("#.php#",$file) ) { continue; }
		$check = @fopen("../includes/$file","a");
		if (!$check) {
			@chmod("../includes/$file",0666);
			$check = @fopen("../includes/$file","a");
		}
		if (!$check) {
			break;
		}
	}
	if ( (!$check) && ($file) ) {
		echo "<td class=stdautorow><font color=red>FAILED ($file)</font></td>";
		$nocrit = 1;
	} else {
		echo "<td class=stdautorow><font color=green>PASSED</green></td>";
	}

	echo "
	</td>
	</tr>
	<tr>
	<td width=30% class=stdautorow>
	<b>sessions/</b>
	</td>
	";

	$check = @fopen("../sessions/index.html","w");
	@chmod("../sessions/index.html",0666);
	if (!$check) {
		@chmod("../sessions",0775);
		$check = @fopen("../sessions/index.html","w");
		@chmod("../sessions/index.html",0666);
	}
	if (!$check) {
		echo "<td class=stdautorow><font color=red>FAILED</font></td>";
		$fail = 1;
	} else {
		echo "<td class=stdautorow><font color=green>PASSED</green></td>";
	}


	echo "
	</tr>
	<tr>
	<td width=30% class=stdautorow>
	<b>templates/compile/</b>
	</td>
	";

	$check = @fopen("../templates/compile/index.html","w");
	@chmod("../templates/compile/index.html",0666);
	if (!$check) {
		@chmod("../templates/compile",0775);
		$check = @fopen("../templates/compile/index.html","w");
		@chmod("../sessions/index.html",0666);
	}
	if (!$tfail) {
		if (!$check) {
			echo "<td class=stdautorow><font color=red>FAILED (templates/compile)</font></td>";
			$fail = 1;
		} else {
			echo "<td class=stdautorow><font color=green>PASSED</green></td>";
		}
	}

	echo "
	</tr>
	<tr>
	<td width=30% class=stdautorow>
	<b>cache/</b>
	</td>
	";

	$check = @fopen("../cache/index.html","w");
	@chmod("../cache/index.html",0666);
	if (!$check) {
		@chmod("../cache",0775);
		$check = @fopen("../cache/index.html","w");
		@chmod("../cache/index.html",0666);
	}
	if (!$check) {
		echo "<td class=stdautorow><font color=red>FAILED</font></td>";
		$fail = 1;
	} else {
		echo "<td class=stdautorow><font color=green>PASSED</green></td>";
	}

	echo "
	</tr>
	<tr>
	<td width=30% class=stdautorow>
	<b>cache_builders/custom/*</b>
	</td>
	";

	$check = @fopen("../cache_builders/custom/index.html","w");
	@chmod("../cache/index.html",0666);
	if (!$check) {
		@chmod("../cache",0775);
		$check = @fopen("../cache_builders/custom/index.html","w");
		@chmod("../cache_builders/custom/index.html",0666);
	}
	if (!$check) {
		echo "<td class=stdautorow><font color=red>FAILED</font></td>";
		$fail = 1;
	}  else {

		$dir = opendir("../cache_builders/custom");
		while ($file = readdir($dir)) {
			$check = "";
			if (!preg_match("#.php#",$file) ) { continue; }
			if (!preg_match("#portal_box#",$file)) { continue; }
			$check = @fopen("../cache_builders/custom/$file","a");
			if (!$check) {
				@chmod("../cache_builders/custom/$file",0666);
				$check = @fopen("../cache_builders/custom/$file","a");
				if (!$check) {
					break;
				}
			}
		}
		if ( (!$check) && ($file) ) {
			echo "<td class=stdautorow><font color=red>FAILED ($file)</font></td>";
			$nocrit = 1;
		} else {
			echo "<td class=stdautorow><font color=green>PASSED</green></td>";
		}
	}

	// STYLES
	echo "
	</tr>
	<tr>
	<td width=30% class=stdautorow>
	<b>styles/*</b>
	</td>
	";

	$check = @fopen("../styles/index.html","w");
	@chmod("../styles/index.html",0666);
	if (!$check) {
		@chmod("../styles",0775);
		$check = @fopen("../styles/index.html","w");
		@chmod("../styles/index.html",0666);
	}
	if (!$check) {
		echo "<td class=stdautorow><font color=red>FAILED (Can't create new file)</font></td>";
		$fail = 1;
		$sfail = 1;
	}

	$dir = opendir("../styles");
	while ($file = readdir($dir)) {
		if ($file == "images" || $file == "." || $file == "..") { continue; }
		$check = @fopen("../styles/$file","a");
		if (!$check) {
			@chmod("../styles/$file",0666);
			$check = @fopen("../styles/$file","a");
			if (!$check) {
				break;
			}
		}
	}
	if (!$sfail) {
		if ( (!$check) && ($file) ) {
			echo "<td class=stdautorow><font color=red>FAILED ($file)</font></td>";
		} else {
			echo "<td class=stdautorow><font color=green>PASSED</green></td>";
		}
	}

	// TMP DIR
	echo "
	</tr>
	<tr>
	<td width=30% class=stdautorow>
	<b>tmp/</b>
	</td>
	";

	$check = @fopen("../tmp/index.html","w");
	@chmod("../tmp/index.html",0666);
	if (!$check) {
		@chmod("../tmp",0775);
		$check = @fopen("../tmp/index.html","w");
		@chmod("../tmp/index.html",0666);
	}
	if (!$check) {
		echo "<td class=stdautorow><font color=red>FAILED (Can't create new file)</font></td>";
		$fail = 1;
	} else {
		echo "<td class=stdautorow><font color=green>PASSED</font></td>";
	} // end if


	// GALLERY
	echo "
	</tr>
	<tr>
	<td width=30% class=stdautorow>
	<b>gallery/*</b>
	</td>
	";

	$check = @fopen("../gallery/index.html","w");
	@chmod("../gallery/index.html",0666);
	if (!$check) {
		@chmod("../gallery",0775);
		$check = @fopen("../gallery/index.html","w");
		@chmod("../gallery/index.html",0666);
	}
	if (!$check) {
		echo "<td class=stdautorow><font color=red>FAILED (Can't create new file)</font></td>";
		$fail = 1;
		$sfail = 1;
	}

	$dir = opendir("../gallery/default");
	while ($file = readdir($dir)) {
		if ($file == "index.html" || $file == "." || $file == "..") { continue; }
		$check = @fopen("../gallery/default/$file/index.html","w");
		if (!$check) {
			$file = "Can't create file in gallery/default/$file/";
			break;
		} // end if

	}
	if (!$sfail) {
		if ( (!$check) && ($file) ) {
			echo "<td class=stdautorow><font color=red>FAILED ($file)</font></td>";
		} else {
			echo "<td class=stdautorow><font color=green>PASSED</green></td>";
		}
	}

	echo "
	</tr>
	<tr>
	<form method=post action=\"$scriptname\">
	<td colspan=2 class=stdautorow>
	";

	if ($fail) {
		echo "One or more of the above files does not  have write permissions.  Please correct this and click the button below to try again.<br>
		<input type=hidden name=step value=1>
		<input type=hidden name=sessiondir value=$sessiondir>
		<input type=submit name=option value=\"Check again\">
		";
	} elseif ($nocrit) {
		echo "Some of the non-critical files do not have write permissions.  You can try to correct these now and check again or you can worry about these later and continue with the installation. NOTE: Permissions will need to be changed on these files in order to use some of the admin functions.<br>
		<input type=hidden name=step value=2>
		<input type=hidden name=sessiondir value=$sessiondir>
		<input type=submit name=option value=\"Check again\">
		<input type=submit value=\"Proceed to next step\">
		";

	} else {
		echo "All checks passed.<br>
		<input type=hidden name=step value=2>
		<input type=hidden name=sessiondir value=$sessiondir>
		<input type=submit value=\"Proceed to next step\">
		";
	}

	echo "
	</td></form></tr>
	</table>
	";
	basic_footer();
}


// -------------------------------------------------------------------------
// STEP 2
function step2($step="",$dbserver,$dbname,$dbuser,$dbpass,$servererror,$nameerror,$usererror,$passerror,$TABLE_PREFIX,$COOKIE_PREFIX,$sessiondir) {

	if (!$dbserver) { $dbserver = "localhost"; }
	basic_header($step);
	$scriptname = find_environmental('PHP_SELF');
	echo "
	<table border=1 width=600>
	<tr>
	<td colspan=2 class=stdautorow>
	This next step consists of gathering the database information.  You will need to know the server the mysql engine is running on, the database name, the username, and the password if necessary.
	</td>
	</tr>
	<FORM METHOD=POST ACTION=\"$scriptname\">
	<input type=hidden name=step value=3>
	<input type=hidden name=sessiondir value=$sessiondir>
	<tr>
	<td width=30% class=stdautorow>
	<b>Database server</b>
	</td><td class=stdautorow>
	<input type=text name=dbserver value=\"$dbserver\"> $servererror
	</td>
	</tr>
	<tr>
	<td width=30% class=stdautorow>
	<b>Database name</b>
	</td><td class=stdautorow>
	<input type=text name=dbname value=\"$dbname\"> $nameerror
	</td>
	</tr>
	<tr>
	<td width=30% class=stdautorow>
	<b>Database user</b>
	</td><td class=stdautorow>
	<input type=text name=dbuser value=\"$dbuser\"> $usererror
	</td>
	</tr>
	<tr>
	<td width=30% class=stdautorow>
	<b>Database password</b>
	</td><td class=stdautorow>
	<input type=password name=dbpass value=\"$dbpass\"> $passerror
	</td>
	</tr>
	<tr>
	<td width=30% class=stdautorow>
	<b>Tablename prefix (no spaces)</b>
	</td><td class=stdautorow>
	<input type=text name=TABLE_PREFIX value=\"$TABLE_PREFIX\">
	<tr><td colspan=2 class=stdautorow>
	<INPUT TYPE=SUBMIT VALUE=\"Check database settings\">
	</FORM>
	</table>
	";
	basic_footer();
}



// ----------------------------------------------------------------------
// STEP 3
function step3($step="",$dbserver="",$dbname="",$dbuser="",$dbpass="",$TABLE_PREFIX="",$COOKIE_PREFIX="",$sessiondir="") {
	$scriptname = find_environmental('PHP_SELF');
	$TABLE_PREFIX = str_replace(" ","",$TABLE_PREFIX);
	if (!$TABLE_PREFIX) { $TABLE_PREFIX = "ubbt_"; }

	basic_header($step);
	echo "
	<table width=600 border=1>
	<tr>
	<td colspan=2 class=stdautorow>
	Here we are checking your database connectivity and permissions.  If any of these checks fail you will need to correct the errors in order to proceed.
	</td>
	</tr>
	<tr>
	<td width=30% valign=top class=stdautorow>
	<b>Connecting to server</b>
	</td><td class=stdautorow>
	";
	$check = mysql_connect($dbserver,$dbuser,$dbpass);
	if (!$check) {
		echo "<font color=red>FAILED</font></td>";
		$servererror="<font color=red>?<font>";
		$usererror="<font color=red>?<font>";
		$passworderror="<font color=red>?<font>";
		$fail = 1;
	} else {
		echo "<font color=green>PASSED</green></td>";
	}

	echo "
	</tr>
	<tr>
	<td width=30% class=stdautorow>
	<b>Connecting to database</b>
	</td><td class=stdautorow>
	";
	if (!$fail) {
		$check2 = mysql_select_db($dbname,$check);
	}
	if ( ($fail) || (!$check2) ) {
		echo "<font color=red>FAILED</font></td>";
		$nameerror = "<font color=red>?<font>";
		$fail = 1;
	} else {
		echo "<font color=green>PASSED</green></td>";
	}

	if ($fail) {
		echo "
		</tr>
		<tr>
		<form method=post action=\"$scriptname\">
		<td colspan=2 class=stdautorow>
		<input type=hidden name=step value=2>
		<input type=hidden name=sessiondir value=\"$sessiondir\">
		<input type=hidden name=servererror value=\"$servererror\">
		<input type=hidden name=nameerror value=\"$nameerror\">
		<input type=hidden name=usererror value=\"$usererror\">
		<input type=hidden name=passerror value=\"$passerror\">
		<input type=hidden name=dbserver value=\"$dbserver\">
		<input type=hidden name=dbname value=\"$dbname\">
		<input type=hidden name=dbuser value=\"$dbuser\">
		<input type=hidden name=dbpass value=\"$dbpass\">
		<input type=hidden name=TABLE_PREFIX value=\"$TABLE_PREFIX\">
		One or more of the above checks failed.  Click the button below to return to the previous screen to verify your settings.<br>
		<input type=submit value=\"Verify Settings\">
		";
	} else {
		echo "
		</tr><tr>
		<td class=stdautorow>
		<b>Creating a table</b>
		</td>
		<td class=stdautorow>
		";

		$query = "CREATE TABLE UBBT_TEST(TEST text)";
		$sth = mysql_query($query,$check);
		if (!$sth) {
			echo "<font color=red>FAILED</font>";
			$nocreate=1;
		}
		else {
			echo "<font color=green>PASSED</font>";
		}
		echo "
		</td>
		</tr><tr>
		<td class=stdautorow>
		<b>Dropping a table</b>
		</td>
		<td class=stdautorow>
		";

		$query = "DROP TABLE UBBT_TEST";
		$sth = mysql_query($query,$check);
		if (!$sth) {
			echo "<font color=red>FAILED</font>";
			$nodrop=1;
		}
		else {
			echo "<font color=green>PASSED</font>";
		}

		if ( ($nocreate) || ($nodrop) ) {
			echo "
			</td></tr>
			<tr><td colspan=2 class=stdautorow>
			You do not have all of the necessary permissions to this database.  You need to make sure that the supplied username/password combination gives you full control to the specified database.
			<p>You may run the tests again if you have cleared this problem up, or you may return to the previous screen to change your database variables.<br>
			<form method=post action=\"$scriptname\">
			<input type=hidden name=step value=2>
			<input type=submit value=\"Return to previous step\">
			</form>
			<form method=post action=\"$scriptname\">
			<input type=hidden name=step value=3>
			<input type=hidden name=sessiondir value=\"$sessiondir\">
			<input type=hidden name=dbserver value=\"$dbserver\">
			<input type=hidden name=dbname value=\"$dbname\">
			<input type=hidden name=dbuser value=\"$dbuser\">
			<input type=hidden name=dbpass value=\"$dbpass\">
			<input type=hidden name=TABLE_PREFIX value=\"$TABLE_PREFIX\">
			<input type=submit value=\"Run tests again\">
			</form>
			";
		}
		else {
			echo "</td></tr>
			<form method=post action=\"$scriptname\">
			<tr><td colspan=2 class=stdautorow>
			<input type=hidden name=step value=4>
			<input type=hidden name=sessiondir value=\"$sessiondir\">
			<input type=hidden name=dbserver value=\"$dbserver\">
			<input type=hidden name=dbname value=\"$dbname\">
			<input type=hidden name=dbuser value=\"$dbuser\">
			<input type=hidden name=dbpass value=\"$dbpass\">
			<input type=hidden name=TABLE_PREFIX value=\"$TABLE_PREFIX\">
			All test passed<br>
			<input type=submit value=\"Next step\">
			</form>
			";
		}
	}
	echo "
	</td></form></tr>
	</table>
	";
	basic_footer();
}



// ----------------------------------------------------------------------
// STEP 4
function step4($step="",$dbserver="",$dbname="",$dbuser="",$dbpass="",$FULL_URL="",$path="",$referer="",$FULL_URLerror="",$patherror="",$referererror="",$TABLE_PREFIX="",$COOKIE_PREFIX="",$sessiondir="") {
	$scriptname = find_environmental('PHP_SELF');
	basic_header($step);

	if (!$FULL_URL) {
		$What = find_environmental('REQUEST_URI');
		$script['0'] = "";
		preg_match("/(.*)\/(.*)\.php/",$What,$script);
		$url = $script['1'];
		$url = str_replace("/install","",$url);
		$FULL_URL = $url;
	}
	if (!$FULL_URL) {
		$What = find_environmental('SCRIPT_NAME');
		$script['0'] = "";
		preg_match("/(.*)\/(.*)\.php/",$What,$script);
		$url = $script['1'];
		$url = str_replace("/install","",$url);
		$FULL_URL = $url;
	}

	if (!$path) {
		$path = find_environmental('SCRIPT_FILENAME');
		$script['0'] = "";
		preg_match("/(.*)\/(.*)\.php/",$path,$script);
		$path = $script['1'];
		$path = str_replace("/install","",$path);
	}
	if (!$path) {
		$translated = find_environmental('PATH_TRANSLATED');
		list($path,$junk) = preg_split("#install#",$translated);
		$path = str_replace("\\","/",$path);
		$path = preg_replace("#/$#","",$path);
	}
	if (!$path) {
		$translated = find_environmental('ORIG_PATH_TRANSLATED');
		list($path,$junk) = preg_split("#install#",$translated);
		$path = str_replace("\\","/",$path);
		$path = preg_replace("#/$#","",$path);
	}
	if (!$referer) {
		$referer = "http://" . find_environmental('HTTP_HOST');
	}

	echo "
	<table width=600 border=1>
	<tr>
	<td colspan=2 class=stdautorow>
	Next we need to gather information on the paths and url of your installation.  Some of these values are pre-filled but may not be correct depending on your system.  Please change if necessary.
	</td>
	</tr>
	<form method=post action=\"$scriptname\">
	<tr>
	<td class=stdautorow><br>
	<b>The domain UBB.threads will be run on</b><br>
	<input name=referer type=text size=50 value=\"$referer\"> $referererror
	</td>
	</tr>
	<tr>
	<td class=stdautorow><br>
	<b>Base URL to the UBB.threads install</b><br>
	<input name=FULL_URL type=text size=50 value=\"$FULL_URL\"> $FULL_URLerror
	</td>
	</tr>
	<tr>
	<td class=stdautorow><br>
	<b>Path to your UBB.threads install</b><br>
	<input name=path type=text size=50 value=\"$path\"> $patherror
	</td>
	</tr>
	<tr>
	<td class=stdautorow><br>
	<b>Custom cookie prefix</b> (Can be left blank. Useful if you have 2 installs and don't want cookies from one causing problems with the other)<br>
	<input name=COOKIE_PREFIX type=text value=\"$COOKIE_PREFIX\">
	</td>
	</tr>

	<input type=hidden name=step value=5>
	<input type=hidden name=sessiondir value=\"$sessiondir\">
	<input type=hidden name=dbserver value=\"$dbserver\">
	<input type=hidden name=dbname value=\"$dbname\">
	<input type=hidden name=dbuser value=\"$dbuser\">
	<input type=hidden name=dbpass value=\"$dbpass\">
	<input type=hidden name=TABLE_PREFIX value=\"$TABLE_PREFIX\">
	<tr><td class=stdautorow>
	<input type=submit value=\"Check settings\"></td></tr>
	</form>
	";

	echo "</table>";
	basic_footer();
}




// ----------------------------------------------------------------------
// STEP 5
function step5($step="",$dbserver="",$dbname="",$dbuser="",$dbpass="",$FULL_URL="",$path="",$referer="",$TABLE_PREFIX="",$COOKIE_PREFIX="",$sessiondir="") {

	$scriptname = find_environmental('PHP_SELF');

	basic_header($step);
	echo "
	<table width=600 border=1>
	<tr>
	<td colspan=2 class=stdautorow>
	Checking all path/url information.  Please make sure you have all files uploaded, or you will get false reporing. NOTE: The first 3 might fail if PHP is unable to open files via a URL.  If that is the case you may continue to the next step.<br>
	</td>
	</tr>
	";

	echo "
	<tr><td width=30% class=stdautorow>
	<b>FULL_URL</b>
	</td><td class=stdautorow>($referer{$FULL_URL})
	";

	// FIX: Windows/FastCGI totally crashes on this
	//$check = fopen("$referer{$FULL_URL}/INSTALL.html","r");
	$check = 1;
	if (!$check) {
		echo "<font color=red>UNABLE TO OPEN</font>";
		$nocrit=1;
		$FULL_URLerror="<font color=red>?</font>";
	}
	else {
		echo "<font color=green>PASSED</font>";
	}
	echo "</td></tr>";

	echo "
	<tr><td width=30% class=stdautorow>
	<b>path</b>
	</td><td class=stdautorow>($path)
	";
	$check = @fopen("$path/index.php","r");
	if (!$check) {
		echo "<font color=red>FAILED</font>";
		$fail = 1;
		$patherror="<font color=red>?</font>";
	}
	else {
		echo "<font color=green>PASSED</font>";
	}
	echo "</td></tr>";

	if ( ($fail) || ($nocrit) ) {
		echo "<tr><td colspan=2 class=stdautorow><br>One or more of the above checks have failed.  You might need to go back and verify your settings.<form method=post action=\"$scriptname\">
		<input type=hidden name=step value=6>
		<input type=hidden name=sessiondir value=\"$sessiondir\">
		<input type=hidden name=dbserver value=\"$dbserver\">
		<input type=hidden name=dbname value=\"$dbname\">
		<input type=hidden name=dbuser value=\"$dbuser\">
		<input type=hidden name=dbpass value=\"$dbpass\">
		<input type=hidden name=FULL_URL value=\"$FULL_URL\">
		<input type=hidden name=path value=\"$path\">
		<input type=hidden name=COOKIE_PREFIX value=\"$COOKIE_PREFIX\">
		<input type=hidden name=referer value=\"$referer\">
		<input type=hidden name=FULL_URLerror value=\"$FULL_URLerror\">
		<input type=hidden name=patherror value=\"$patherror\">
		<input type=hidden name=referererror value=\"$referererror\">
		<input type=hidden name=TABLE_PREFIX value=\"$TABLE_PREFIX\">
		<input type=submit name=option value=\"Verify url/path settings\">
		<input type=submit name=option value=\"Proceed to next step\">
		";
	}
	else {
		echo "<tr><td colspan=2 class=stdautorow><br>
		All checks passed.
		<form method=post action=\"$scriptname\">
		<input type=hidden name=step value=6>
		<input type=hidden name=sessiondir value=\"$sessiondir\">
		<input type=hidden name=dbserver value=\"$dbserver\">
		<input type=hidden name=dbname value=\"$dbname\">
		<input type=hidden name=dbuser value=\"$dbuser\">
		<input type=hidden name=dbpass value=\"$dbpass\">
		<input type=hidden name=FULL_URL value=\"$FULL_URL\">
		<input type=hidden name=path value=\"$path\">
		<input type=hidden name=COOKIE_PREFIX value=\"$COOKIE_PREFIX\">
		<input type=hidden name=referer value=\"$referer\">
		<input type=hidden name=TABLE_PREFIX value=\"$TABLE_PREFIX\">
		<input type=submit value=\"Next Step\">
		";
	}

	echo "</td></tr>";

	echo "</table>";

	basic_footer();
}




// ----------------------------------------------------------------------
// STEP 6
function step6($step="",$dbserver="",$dbname="",$dbuser="",$dbpass="",$FULL_URL="",$path="",$referer="",$TABLE_PREFIX="",$COOKIE_PREFIX="",$sessiondir="") {

	global $thisversion;
	$scriptname = find_environmental('PHP_SELF');
	$referer = preg_replace("/\/$/","",$referer);

	$full_url = "$referer{$FULL_URL}";
	$base_url = "$FULL_URL";

	if ($FULL_URL == "/") {
		$full_url = "$referer";
	}

	// -------------------------------------
	// Let's print out the basic config file
	$boardkey = uniqid();
	$newconfig = <<<EOF
<?php

		\$VERSION = "";

		\$config['DATABASE_SERVER']= "$dbserver";
		\$config['DATABASE_USER'] = "$dbuser";
		\$config['DATABASE_PASSWORD'] =  "$dbpass";
		\$config['DATABASE_NAME'] = "$dbname";
		\$config['TABLE_PREFIX'] = "$TABLE_PREFIX";
		\$config['MAIN_ADMIN_ID'] = "2";
   \$config['MARKUP_FONTS'] =
  array (
  	0 => 'Arial',
  	1 => 'Arial Black',
  	2 => 'Book Antiqua',
  	3 => 'Century Gothic',
  	4 => 'Comic Sans MS',
  	5 => 'Courier New',
  	6 => 'Fixedsys',
  	7 => 'Georgia',
  	8 => 'Impact',
  	9 => 'Lucida Console',
  	10 => 'Microsoft Sans Serif',
  	11 => 'System',
  	12 => 'Times New Roman',
  	13 => 'Verdana',
  );
  \$config['TIME_FORMATS'] =
  array (
		0 => "d/m/y | h:i A",
		1 => "y/m/d | h:i A",
		2 => "d/m/Y | H:i",
		3 => "D M d Y | h:i A",
		4 => "m/d/y | h:i A",
		5 => "Y-m-d | H:i:s",
  );
	\$config['TIME_FORMAT'] = "m/d/y | h:i A";
  \$config['MARKUP_FONT_SIZES'] =
  array (
  	0 => "8pt",
  	1 => "11pt",
  	2 => "14pt",
  	3 => "17pt",
  	4 => "20pt",
  	5 => "23pt",
  	6 => "26pt",
  );
  \$config['SYNTAX_ENGINES'] =
	array (
	0 => 'text',
	1 => 'php',
	2 => 'css',
	3 => 'javascript',
	4 => 'sql',
	5 => 'html4strict',
	6 => 'xml',
	);
	\$config['SE_TAB_WIDTH'] = '2';
	\$config['SE_NTH_LINE'] = '2';
	\$config['SE_LINENUMBERS'] = '1';
	\$config['BUILD_ISLANDS'] = array();
	\$config['NO_COLLAPSE_ISLANDS'] = array();
	\$config['MAX_SEARCH_RANGE_TYPE'] = "years";
	\$config['MAX_SEARCH_RANGE_VALUE'] = 1;
	\$config['MAX_SEARCH_RESULTS'] = 200;
	\$config['MIN_SEARCH_LENGTH'] = 3;
	\$config['ENABLE_ACTIVE_TEXT'] = 0;
	\$config['AVATAR_MAX_WIDTH'] = "80";
	\$config['AVATAR_MAX_HEIGHT'] = "80";
	\$config['TOPIC_DISPLAY_STYLE'] = "flat";
	\$config['SHOW_AVATARS'] = "1";
	\$config['POSTS_PER_PAGE'] = "10";
	\$config['COMMUNITY_INTRO'] = "";
	\$config['COMMUNITY_INTRO_TITLE'] = "";
	\$config['BODY_ONLOAD'] = "";
	\$config['TABLE_WIDTH'] = "100%";
		\$config['TOPICS_PER_PAGE'] = "10";
		\$config['TEXT_AREA_COLUMNS'] = "65";
		\$config['TEXT_AREA_ROWS'] = "10";
		\$config['FULL_URL'] = "$full_url";
		\$config['BASE_URL'] = "$base_url";
		\$config['FULL_PATH'] = "$path";
		\$config['SESSION_PATH'] = "$path/sessions";
		\$config['REFERERS'] = "$referer";
		\$config['ATTACHMENTS_PATH'] = "$path/uploads";
		\$config['ATTACHMENTS_URL'] = "$full_url/uploads";
		\$config['MULTI_URL'] = '0';
		\$config['COOKIE_PATH'] = "/";
		\$config['COOKIE_PREFIX'] = "$COOKIE_PREFIX";
		\$config['LANGUAGE'] = "english";
		\$config['ONLINE_TIME'] = "10";
		\$config['NEWS_ITEMS'] = "5";
		\$config['TOP_POSTERS'] = "5";
		\$config['DEFAULT_STYLE'] = "1";
		\$config['REQUIRE_UNIQUE_EMAIL'] = "1";
		\$config['DEFAULT_USER_GROUPS'] = array("4");
		\$config['COMMUNITY_TITLE'] = "Your new forums";
		\$config['HOMEPAGE_URL'] = "http://www.example.com";
		\$config['INLINE_IMAGE'] = '2000';
		\$config['MAX_WIDTH_IMAGE'] = "400";
		\$config['HOMEPAGE_TITLE']= "Title for link";
		\$config['SITE_EMAIL']= "";
		\$config['SITE_EMAIL_TITLE']= "Contact Us";
		\$config['PRIVACY_STATEMENT'] = "none";
		\$config['MAX_AVATAR_SIZE'] = '100000';
		\$config['BOARD_IS_CLOSED'] = 0;
		\$config['MARKUP_HTML_TOGGLE'] = 0;
		\$config['DO_AGE_CHECK']= 0;
		\$config['MINIMUM_AGE'] = 13;
		\$config['SPECIAL_CHARACTERS']= 1;
		\$config['LANGUAGE']=  "english";
		\$config['SUBJECT_LENGTH']= "50";
		\$config['COOKIE_LIFETIME']= "604800";
		\$config['SERVER_TIME_OFFSET']= "0";
		\$config['ATTACHMENT_TYPES'] = ".gif,.jpg,.txt,.zip,.png";
		\$config['LIST_MODERATORS'] = 1;
		\$config['CUSTOM_TTILE_MAX'] = 100;
		\$config['CUSTOM_FIELD_1'] = "";
		\$config['CUSTOM_FIELD_2'] = "";
		\$config['CUSTOM_FIELD_3'] = "";
		\$config['CUSTOM_FIELD_4'] = "";
		\$config['CUSTOM_FIELD_5'] = "";
		\$config['MIN_PDN_LENGTH'] = 3;
		\$config['MAX_PDN_LENGTH'] = 16;
		\$config['DISABLE_LEFT'] = 0;
		\$config['DISABLE_RIGHT'] = 0;
  		\$config['LEFT_COLUMN'] = 0;
 		\$config['LEFT_COLUMN_BOXES'] = array(
 		);
 		\$config['RIGHT_COLUMN_BOXES'] = array(
 		);
 		\$config['RIGHT_COLUMN'] = 0;
 		\$config['SEARCH_FRIENDLY_URLS'] = '0';
		\$config['FULL_TEXT'] = "POST_DEFAULT_BODY";
 		\$config['HOT_REPLIES'] = '25';
 		\$config['HOT_VIEWS'] = '150';
 		\$config['DISPLAY_NAME_CHANGE'] ='0';
 		\$config['CONTACT_LINK_TYPE'] = 'email';
 		\$config['USER_RATINGS'] = '0';
 		\$config['TOPIC_RATINGS'] = '0';
 		\$config['LOG_SQL_ERRORS'] = '0';
 		\$config['EMAIL_VERIFICATION'] = '0';
 		\$config['PERSISTENT_DB_CONNECTION'] = '0';
 		\$config['ZLIB_COMPRESSION'] = '0';
 		\$config['DO_CENSOR'] = '0';
 		\$config['DISABLE_REFERER_CHECK'] = '1';
 		\$config['REPLACE_WORD'] = '[censored]';
 		\$config['ALLOW_DEBUGGING'] = '1';
 		\$config['ALLOW_IMAGE_MARKUP'] = '1';
 		\$config['AGE_WITH_BIRTHDAYS'] = '0';
 		\$config['ENABLE_QUICK_REPLY'] = '1';
 		\$config['SUSPEND_REGISTRATIONS'] = '0';
 		\$config['ALLOW_UNDER_13'] = '0';
 		\$config['NEW_USER_MODERATION'] = '0';
 		\$config['TOPIC_DISPLAY_OPTIONS'] = 'both';
 		\$config['SQL_LOG_PATH'] = '';
  		\$config['CUSTOM_TITLE_MAX'] = '100';
  		\$config['NEW_COUNT'] = '1';
  		\$config['NEW_REPLIES'] = '1';
		\$config['MAX_THUMB_W_H'] = 125;
		\$config['MAX_MEDIUM_W_H'] = 450;
		\$config['MAX_FULL_W_H'] = 1200;
		\$config['THUMB_QUALITY'] = 60;
		\$config['MEDIUM_QUALITY'] = 70;
		\$config['FULL_QUALITY'] = 80;
		\$config['POST_LAYOUT'] = 'side';
		\$config['ENABLE_MOODS'] = 1;
		\$config['BIRTHDAY_NOTICE'] = 1;
		\$config['IMAGE_LIMIT'] = 10;
		\$config['ENABLE_POST_COUNTS'] = '1';
		\$config['SHOW_ALL_GRAEMLINS'] = 0;
		\$config['SHOW_TEASER_LATEST_POST'] = '0';
		\$config['CATEGORY_ONLY_MODE'] = '0';
		\$config['DISABLE_ONLINE_INVISIBLE'] = '0';
		\$config['SEARCH_FRIENDLY_HTML_EXT'] = '0';
		\$config['CALENDAR_START_DAY'] = '0';
		\$config['LOG_REFERS'] = '1';
		\$config['CALENDAR'] = '1';
		\$config['NOFOLLOW_POST'] = '1';
		\$config['NOFOLLOW_SIG'] = '1';
		\$config['NESTED_QUOTES'] = '4';
		\$config['COMMENTS'] = '1';
		\$config['COMMENTS_MIN_POST'] = '25';
		\$config['SFS_ENABLE'] = '0';
		\$config['SFS_LEVEL'] = '1';
		\$config['SFS_KEY'] = '';
		\$config['BOARD_KEY'] = "$boardkey";
?>
EOF;

	// --------------------
	// Write the new config

	$fd = fopen("../includes/config.inc.php","w");
	fwrite($fd,$newconfig);
	fclose($fd);

	$step = 6;

	basic_header($step);

	echo "
	<table width=600 border=1>
	<tr>
	<td colspan=2 class=stdautorow>
	All config files have been created.  You now have 2 options.<br /><br />You may now proceed to <a href=\"install.php?step=7\">creating your admin user</a> at this time.
	<br /><br />
	If are upgrading from UBB.classic or UBB.threads 6.5.x or you don't want to create your admin user now, you may proceed to <a href=\"createtable.php\">Creating your tables</a> at this time.
	</td>
	</tr>
	</table>
	";
	basic_footer();

}

function step7($display_name="",$email="",$login_name="",$password="",$verify_password="") {

echo 'hi';
	$step = 7;

	basic_header($step);

	echo <<<EOF
	<table width=600 border=1>
	<form method="post" action="install.php">
	<input type="hidden" name="step" value="8">
	<tr>
	<td colspan=2 class=stdautorow>
	You now need to create your main admin user.  This user will allow you to administrate your community.  Please enter the following information.
	</td>
	</tr>

	<tr>
	<td class="stdautorow">
	<b>Username</b>
	</td>
	<td>
	<input type="text" name="login_name" size="30" value="$login_name" />
	</td>
	</tr>

	<tr>
	<td class="stdautorow">
	<b>Display Name</b>
	</td>
	<td>
	<input type="text" name="display_name" size="30" value="$display_name" />
	</td>
	</tr>

	<tr>
	<td class="stdautorow">
	<b>Email Address</b>
	</td>
	<td>
	<input type="text" name="email" size="30" value="$email" />
	</td>
	</tr>

	<tr>
	<td class="stdautorow">
	<b>Password</b>
	</td>
	<td>
	<input type="password" name="password" size="30" />
	</td>
	</tr>

	<tr>
	<td class="stdautorow">
	<b>Verify Password</b>
	</td>
	<td>
	<input type="password" name="verify_password" size="30" />
	</td>
	</tr>

	<tr>
	<td class="autorow" colspan="2">
	<input type="submit" name="submit" value="Submit Admin User Info" />
	</form>
	</td>
	</tr>


	</table>
EOF;
	basic_footer();
}

function step8($display_name="",$email="",$login_name="",$password="",$verify_password="") {

	$step = 8;

	$error = 0;
	$error_msg = "";
	// Make sure display name is between 3 and 16 characters
	if ( (strlen($display_name) < 3)  || (strlen($display_name) > 16)) {
		$error = 1;
		$error_msg = "Display Name must be between 3 and 16 characters long.";
	} // end if

	// Make sure login name is between 3 and 16 characters
	if ( (strlen($login_name) < 3)  || (strlen($login_name) > 16)) {
		$error = 1;
		$error_msg = "Login Name must be between 3 and 16 characters long.";
	} // end if

	// Make sure we have a valid email format
	if ( !$error && (!preg_match("#^[+_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$#", $email))) {
		$error = 1;
		$error_msg = "Email address specified is not a valid email address.";
	} // end if

	// Make sure password is proper length
	$password = trim($password);
	$verify_password = trim($verify_password);
	if (!$error && ((strlen($password) < 4) || (strlen($password) > 21))) {
		$error = 1;
		$error_msg = "Password must be between 4 and 21 characters long.";
	} // end if

	// Make sure password and verify_password match
	if (!$error && ($password != $verify_password)) {
		$error = 1;
		$error_msg = "Password and Verify Password fields do not match.";
	} // end if

	if ($error) {

		basic_header($step);

		echo <<<EOF
		<table width=600 border=1>
		<form method="post" action="install.php">
		<input type="hidden" name="step" value="7">
		<input type="hidden" name="display_name" value="$display_name" />
		<input type="hidden" name="email" value="$email" />
		<input type="hidden" name="login_name" value="$login_name" />
		<tr><td class="autorow">
		$error_msg
		<br /><br />
		<input type="submit" name="submit" value="Return to previous screen" />
		</td></tr></table>
EOF;

		basic_footer();

		exit;
	} // end if

	// Everything checks out, pass this information on to createtable.
	$password = md5($password);

	basic_header($step);

	echo <<<EOF
	<table width=600 border=1>
	<form method="post" action="createtable.php">
	<input type="hidden" name="display_name" value="$display_name" />
	<input type="hidden" name="email" value="$email" />
	<input type="hidden" name="password" value="$password" />
	<input type="hidden" name="login_name" value="$login_name" />
	<tr><td class="autorow">
	You may now proceed to the next step to create all of the necessary database tables.
	<br /><br />
	<input type="submit" name="submit" value="Proceed to next step" />
	</td></tr></table>
EOF;

	basic_footer();

}


function find_environmental ($name) {

	global $HTTP_SERVER_VARS;

	$thisvar = "";

	// Regular way
	if(getenv($name) != '') {
		$thisvar = getenv("$name");
	} // end if

	// Irregular way
	if(($thisvar == '') && ($HTTP_SERVER_VARS["$name"] != '')) {
		$thisvar = $HTTP_SERVER_VARS["$name"];
	} // end if

	// 4.1 way
	if(($thisvar == '') && ($_ENV["$name"] != '')) {
		$thisvar = $_ENV["$name"];
	} // end if

	return $thisvar;
} // end func

function get_input ($name="",$type="") {

	global $HTTP_POST_VARS, $HTTP_GET_VARS;
	global $_POST, $_GET, $_COOKIE, $_SESSION;

	$thisvar = "";

	if (isset($_GET["$name"])) {
		$thisvar = $_GET["$name"];
		return $thisvar;
	}
	elseif (isset($HTTP_GET_VARS["$name"])) {
		$thisvar = $HTTP_GET_VARS["$name"];
		return $thisvar;
	}

	if (isset($_POST["$name"]))   {
		$thisvar = $_POST["$name"];
		return $thisvar;
	}
	elseif (isset($HTTP_POST_VARS["$name"])) {
		$thisvar = $HTTP_POST_VARS["$name"];
		return $thisvar;
	}
}


?>
