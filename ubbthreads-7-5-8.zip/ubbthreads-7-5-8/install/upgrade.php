<?php
//	Script Version 7.5.8

error_reporting(7);
ini_set("display_errors", true);

// We need PHP 4.3 or higher
if(!version_compare(phpversion(), "4.3.0", ">=")) {
	print "UBB requires PHP 4.3.0 or higher.  Your PHP version: ";
	print phpversion();
	exit;
} // end if

// We always want to work from the directory this script is in
chdir(dirname(__FILE__));

// We'll want to buffer everything...
$config = array();
ob_start();

// Nothing runs without this.
define('UBB_MAIN_PROGRAM', 1);
define('IS_UPGRADE',1);

// Setup the smarty class
require('../libs/smarty/Smarty.class.php');
$smarty = new Smarty();

$smarty->template_dir = 'templates/default';
$smarty->compile_dir = 'templates/compile';

// include all of the required libraries
require_once("../libs/phpmailer/class.phpmailer.php");
require_once("../includes/config.inc.php");
require_once("../libs/mysql.inc.php");
require_once("../libs/ubbthreads.inc.php");
require_once("../libs/html.inc.php");
$html = new html;

if(!$config['FULL_PATH']) {
	upgrade_header();
	print "Looks like an unconfigured board.  You probably want a new install instead.";
	upgrade_footer();
	exit;
} // end if

$step = get_input("step","both");
$list = get_input("list","get");
$hand = get_input("hand","both");
$update = get_input("update","both");
$thislanguage = get_input("thislanguage","both");

// An array for what versions run what altertable
$alters = array(
	"7.0.0b4" => "",
	"7.0.0b5" => "altertable-7.0.0b5.php",
	"7.0.0rc1" => "altertable-7.0.0b5.php",
	"7.0" => "altertable-7.0.0b5.php",
	"7.0.1" => "altertable-7.0.0b5.php",
	"7.0.2" => "altertable-7.0.0b5.php",
	"7.1b1" => "altertable-7.1.php",
	"7.1b2" => "altertable-7.1.php",
	"7.1b3" => "altertable-7.1.php",
	"7.1b4" => "altertable-7.1.php",
	"7.1b5" => "altertable-7.1.php",
	"7.1" => "altertable-7.1.php",
	"7.1.1" => "altertable-7.1.php",
	"7.2b1" => "altertable-7.2.php",
	"7.2b2" => "altertable-7.2.php",
	"7.2b3" => "altertable-7.2.php",
	"7.2b4" => "altertable-7.2.php",
	"7.2b5" => "altertable-7.2.php",
	"7.2" => "altertable-7.2.php",
	"7.3a1" => "altertable-7.3a1.php",
	"7.3a2" => "altertable-7.3a2.php",
	"7.3a3" => "altertable-7.3a3.php",
	"7.3b1" => "altertable-7.3b1.php",
	"7.3b2" => "altertable-7.3b2.php",
	"7.3b3" => "altertable-7.3b2.php",
	"7.3b4" => "altertable-7.3b2.php",
	"7.3b5" => "altertable-7.3b2.php",
	"7.3" => "altertable-7.3b2.php",
	"7.4b1" => "altertable-7.4.php",
	"7.4b2" => "altertable-7.4.php",
	"7.4" => "altertable-7.4.php",
	"7.5b1" => "altertable-7.5.php",
	"7.5b2" => "altertable-7.5.php",
	"7.5" => "altertable-7.5.php",
	"7.5.1" => "altertable-7.5.1.php",
);

// Any config file updates necessary?
$configs = array(
	"7.0.2" => "alterconfig-7.0.2.php",
	"7.1" => "alterconfig-7.1.php",
	"7.2b1" => "alterconfig-7.2.php",
	"7.3a1" => "alterconfig-7.3a1.php",
	"7.3a3" => "alterconfig-7.3a3.php",
	"7.4b1" => "alterconfig-7.4.php",
	"7.5b1" => "alterconfig-7.5.php",
);

// Any stylesheet updates necessary?
$styles = array(
	"7.2b1" => "alterstyles-7.2b1.php",
	"7.3a1" => "alterstyles-7.3a1.php",
	"7.3a2" => "alterstyles-7.3a2.php",
	"7.3a3" => "alterstyles-7.3a3.php",
);

// Directory structure changes?
$dirs = array(
	"7.2b1" => "alterdirs-7.2.php",
	"7.5b1" => "alterdirs-7.5.php",
);

// Grab their current version # from the database
$query = "
	select SCRIPT_VERSION,DB_VERSION,LAST_ALTER_STEP,IS_RUNNING
	from {$config['TABLE_PREFIX']}VERSION
";
$sth = $dbh -> do_query($query);
list($c_version,$db_version,$alterstep,$running) = $dbh -> fetch_array($sth);

if ($db_version == 1) {
	$c_version = "7.0.0b1";
}
$trap = 0;
$thisversion = "";
$currentversion = "";
for($i=0;$i<sizeof($all_versions);$i++) {
	if ($trap) {
		if (!$thisversion) {
			$thisversion = $all_versions[$i];
		}
		else {
			$thisversion .= "|$all_versions[$i]";
		}
	}
	if ($c_version == $all_versions[$i]) {
		if ($alterstep) {
			$thisversion = "$c_version";
		}
		$trap = 1;
	}
	$currentversion = $all_versions[$i];
}

if (!$thisversion) {
	$thisversion = $currentversion;
}

// print "!$currentversion!";

if (($c_version == $currentversion) && !$alterstep) {
	require("upgrade_header.tmpl");
	echo "<table border='0' width='95%' align='center'>";
	echo "<tr><td class=stdautrow>";
	echo "This upgrade has been completed.  Please remove the entire install directory<br /><br /><a href=\"{$config['FULL_URL']}/ubbthreads.php\">Return to your forums</a>";
	echo "</td></tr></table>";
	require("upgrade_footer.tmpl");
	exit;
}
$thisversion = "($thisversion)";
$username = get_input("username","post");
$password = get_input("password","post");
if ($username && $password) {
	do_auth($username,$password);
}
if (!$username) {
	if (isset($_COOKIE['ubbt_username'])) {
		$username = $_COOKIE['ubbt_username'];
	}
	if (isset($_COOKIE['ubbt_password'])) {
		$password = $_COOKIE['ubbt_password'];
	}
	if ($username && $password) {
		do_auth($username,$password);
	}
}
if (!$username) {
	get_auth();
}


if ($hand) {
	step7();
	exit;
}
if ($update) {
	step6();
	exit;
}

if (!$step) {
	$step = "1";
}

if ($step == "1") {
	step1();
	exit;
}
if ($step == "2") {
	step2($list);
	exit;
}
if ($step == "3") {
	step3();
	exit;
}
if ($step == "4") {
	step4();
	exit;
}
if ($step == "5") {
	step5($list);
	exit;
}
if ($step == "6") {
	step6();
	exit;
}
if ($step == "7") {
	step7();
	exit;
}
if ($step == "instructions") {
	instructions();
	exit;
}
if ($step == "config") {
	configs();
}
if ($step == "styles") {
	styles();
}
if ($step == "dirs") {
	dirs();
}

if ($step == "altertable") {
	altertable();
}

function instructions() {

	global $ubbt_lang,$config,$thisversion,$currentversion,$c_version,$html;
	$upgradefile = file("UPGRADE_INSTRUCTIONS.txt");
	echo "<html><body>";
	while (list($linenum,$line) = each($upgradefile)) {
		echo "$line<br>";
	}

	echo "</body></html>";
}

// Step Number 1
// Give the Welcome screen
function step1() {

	global $ubbt_lang,$config,$thisversion,$currentversion,$configdir,$html;

	require ("upgrade_header.tmpl");

	echo "<table width='100%' border='0' align='center'><tr><td align='center' class='stdautorow'><b>Upgrade Notes</b><br />";
	echo "<iframe width=500 height=100 src='upgrade.php?step=instructions'></iframe>";
	echo "</td></tr></table>";
	echo "<table border='0' width='95%' align='center'><p>&nbsp;</p>";
	echo "<tr><td class='stdautorow'>";
	echo "The first step in upgrading your board is checking to make sure you have all the proper files uploaded.  You can find the list of files in the boxes below.  Once you have all new files uploaded you can verify this by clicking the 'Check Files' button below.<br /><br />";
	echo "</td></tr></table>";
	echo "<table width='100%' border='0' align='center'><tr><td align='center' class='stdautorow'><b>Changed Files</b><br />";
	echo "<iframe width=500 height=100 src='upgrade.php?step=2&list=changed'></iframe>";
	echo "</td></tr></table>";
	echo "<table width='100%' border='0' align='center'><tr><td align='center' class='stdautorow'><b>New Files</b><br />";
	echo "<iframe width=500 height=100 src='upgrade.php?step=2&list=new'></iframe>";
	echo "</td></tr></table>";
	echo "<table width='100%' border='0' align='center'><tr><td align='center' class='stdautorow'><b>Removed Files</b><br />";
	echo "<iframe width=500 height=100 src='upgrade.php?step=2&list=removed'></iframe>";
	echo "</td></tr></table>";
	echo "<div align='center'>";
	echo "<form method='post' action='{$config['FULL_URL']}/install/upgrade.php'>";
	echo "<input type='hidden' name='step' value='3'>";
	echo "<input type='submit' value='Check Files'>";
	echo "</form>";
	require ("upgrade_footer.tmpl");

}

function step2($list="") {

	global $ubbt_lang,$config,$thisversion,$currentversion,$html;

	$changefile = file("UPGRADE_CHANGES.txt");
	echo "<html><body>";
	$changed = array();
	$new = array();
	$removed = array();

	$thisversion = str_replace(".","\.",$thisversion);
	while (list($linenum,$line) = each($changefile)) {

		$line=preg_replace("/\n/","",$line);
		if (!$line) { continue; }

		if (preg_match("/VERSION-$thisversion:REMOVED:/",$line) ) {
			$script = preg_replace("/VERSION-$thisversion:REMOVED: /","",$line);
			if (!in_array($script,$removed)) {
				$removed[] = $script;
			}
		}
		if (preg_match("/VERSION-$thisversion:NEW:/",$line)) {
			$script = preg_replace("/VERSION-$thisversion:NEW: /","",$line);
			if (!in_array($script,$new)) {
				$new[] = $script;
			}
		}
		if (preg_match("/VERSION-$thisversion:CHANGED:/",$line)) {
			$script = preg_replace("/VERSION-$thisversion:CHANGED: /","",$line);
			if (!in_array($script,$changed)) {
				$changed[] = $script;
			}
		}
	}

	if ($list == "changed") {
		for ($i=0;$i<sizeof($changed);$i++) {
			if (!in_array($changed[$i],$removed)) {
				echo "$changed[$i]<br>";
			}
		}
	}
	if ($list == "new") {
		for ($i=0;$i<sizeof($new);$i++) {
			if (!in_array($new[$i],$removed)) {
				echo "$new[$i]<br>";
			}
		}
	}
	if ($list == "removed") {
		for ($i=0;$i<sizeof($removed);$i++) {
			echo "$removed[$i]<br>";
		}
	}
	echo "</body></html>";

}

function step3() {

	global $ubbt_lang,$config,$thisversion,$currentversion,$html;
	require ("upgrade_header.tmpl");

	// ---------------------------------------------
	// Open up the file to see what we need to check

	$changefile = file("UPGRADE_CHANGES.txt");
	$changed = array();
	$new = array();
	$removed = array();

	$thisversion = str_replace(".","\.",$thisversion);
	while (list($linenum,$line) = each($changefile)) {
		$line=preg_replace("/\n/","",$line);
		if (!$line) { continue; }
		if (preg_match("/VERSION-$thisversion:REMOVED:/",$line) ) {
			$script = preg_replace("/VERSION-$thisversion:REMOVED: /","",$line);
			if (!in_array($script,$removed)) {
				$removed[] = $script;
			}
		}
		if (preg_match("/VERSION-$thisversion:NEW:/",$line)) {
			$script = preg_replace("/VERSION-$thisversion:NEW: /","",$line);
			if (!in_array($script,$new)) {
				$new[] = $script;
			}
		}
		if (preg_match("/VERSION-$thisversion:CHANGED:/",$line)) {
			$script = preg_replace("/VERSION-$thisversion:CHANGED: /","",$line);
			if (!in_array($script,$changed)) {
				$changed[] = $script;
			}
		}
	}

	$changefile = file("UPGRADE_CHANGES.txt");
	$noremoved = array();
	$nonew = array();
	$nochanged = array();
	$already_passed = array();

	while (list($linenum,$line) = each($changefile)) {
		$line=preg_replace("/(\r|\n)/","",$line);
		$matches = array();
		if (preg_match("/VERSION-$thisversion:REMOVED:/",$line)) {
			$script = preg_replace("/VERSION-$thisversion:REMOVED: /","",$line);
			if (file_exists("{$config['FULL_PATH']}/$script")) {
				$test = @unlink("{$config['FULL_PATH']}/$script");
				if (!$est) {
					$noremoved[] = "$script";
				}
			}
		}
		if (preg_match("/VERSION-$thisversion:NEW:/",$line)) {
			$script = preg_replace("/VERSION-$thisversion:NEW: /","",$line);
			if (!file_exists("{$config['FULL_PATH']}/$script")) {
				if (!in_array($script,$removed)) {
					$nonew[] = "$script";
				}
			}
		}
		if (preg_match("/VERSION-$thisversion:CHANGED:/",$line,$matches)) {
			$checkversion = $matches['1'];
			$script = preg_replace("/VERSION-$thisversion:CHANGED: /","",$line);
			if (!in_array($script,$removed) && !isset($already_passed[$script])) {
				$checkfile = @file("{$config['FULL_PATH']}/$script");
				if (!$checkfile) {
					$nonew[] = "$script";
					continue;
				}
				$pass = 0;
				$matches = array();
				while(list($linenum2,$line2) = each($checkfile)) {
					if (preg_match("/Script Version $thisversion/",$line2,$matches)) {
						if ($matches[1] == $checkversion || $matches[1] > $checkversion) {
							$pass = 1;
							//continue;
						}
						$thisnob = preg_split("/b|d/", $matches[1]);
						$checknob = preg_split("/b|d/", $checkversion);

						if ( (preg_match("/b/",$matches[1]) && preg_match("/d/",$checkversion)) || ( !preg_match("/b|d/", $matches[1]) && preg_match("/b|d/", $checkversion) && ($thisnob[0] = $checknob[0]) ) ) {
							$pass = 1;
							//continue;
						}
						if (cc_checkversion($matches[1], $checkversion)) {
							$pass = 1;
							//continue;
						}
					}
				}
				if (!$pass) {
					$nochanged[] = "$script";
				} else {
					$already_passed[$script] = 1;
				} // end if
			}
		}
	}

	echo "<br /><br />";
	echo "<table border='0' width='95%' align='center'>";
	echo "<tr><td align='left' class='stdautorow'>";
	echo "<b>The following files do not exist in your install</b>";
	echo "<br />(Make sure these are uploaded)";
	echo "<hr width='50%'>";
	$size=sizeof($nonew);
	if (!$size) {
		echo "All files uploaded.";
	}
	else {
		for ($i=0;$i<$size;$i++) {
			echo "$nonew[$i]<br />";
		}
	}
	echo "<br /><br />";
	echo "<b>The following files are reporting a wrong version #</b>";
	echo "<br />(Make sure you updated these files)";
	echo "<hr width='50%'>";
	$size=sizeof($nochanged);
	if (!$size) {
		echo "All files report proper version #.";
	}
	else {
		for ($i=0;$i<$size;$i++) {
			echo "$nochanged[$i]<br />";
		}
	}

	echo "<br /><br />";
	echo "<b>The following files need to be removed</b>";
	echo "<hr width='50%'>";
	$size=sizeof($noremoved);
	if (!$size) {
		echo "All files tagged for removal have been removed.";
	}
	else {
		for ($i=0;$i<$size;$i++) {
			echo "$noremoved[$i]<br />";
		}
	}
	echo "</td></tr></table>";

	if (sizeof($nonew) || sizeof($nochanged) || sizeof($noremoved)) {
		echo "<div align='center'>";
		echo "<form method='post' action='{$config['FULL_URL']}/install/upgrade.php'>";
		echo "<input type='hidden' name='step' value='3'>";
		echo "<input type='submit' value='Check Files Again'>";
		echo "</form>";
	}
	else {
		echo "<div align='center'>";
		echo "<form method='post' action='{$config['FULL_URL']}/install/upgrade.php'>";
		echo "<input type='hidden' name='step' value='4'>";
		echo "<input type='submit' value='Proceed to next step'>";
		echo "</form>";
	}

	require ("upgrade_footer.tmpl");
}

function step4() {

	global $ubbt_lang,$config,$thisversion,$currentversion,$html;
	require ("upgrade_header.tmpl");

	echo "<table border='0' width='95%' align='center'><p>&nbsp;</p>";
	echo "Here we need to check and see what language strings need to be updated/changed. You can find the list of changes in the boxes below.  If your language files are writeable by the webserver we can automate this step, if not you will need to make these changes by hand.<br /><br />";

	$dir = opendir("{$config['FULL_PATH']}/languages");
	$count = 0;
	while( ($file = readdir($dir)) != false) {
		if ( ($file == ".") || ($file == ".svn") || ($file == ".svn/admin") || ($file == "..") || ($file == "README") || !is_dir("{$config['FULL_PATH']}/languages/$file")) {
			continue;
		}
		$count++;
	}

	echo "You have a total of $count language directories in your languages directory.  If you have any languages installed that you no longer need or want to support please remove those directories at this time.<br><br>";
	echo "</td></tr></table>";
	echo "<table width='100%' border='0' align='center'><tr><td align='center' class='stdautorow'><b>New Language Strings</b><br />";
	echo "<iframe width=500 height=100 src='upgrade.php?step=5&list=new'></iframe>";
	echo "</td></tr></table>";
	echo "<table width='100%' border='0' align='center'><tr><td align='center' class='stdautorow'><b>Changed Language Strings</b><br />";
	echo "<iframe width=500 height=100 src='upgrade.php?step=5&list=changed'></iframe>";
	echo "</td></tr></table>";
	echo "<table width='100%' border='0' align='center'><tr><td align='center' class='stdautorow'><b>Removed Language Strings</b><br />";
	echo "<iframe width=500 height=100 src='upgrade.php?step=5&list=removed'></iframe>";
	echo "</td></tr></table>";
	echo "<table width='100%' border='0' align='center'><tr><td align='center' class='stdautorow'><b>Removed Language Files</b><br />";
	echo "<iframe width=500 height=100 src='upgrade.php?step=5&list=deleted'></iframe>";
	echo "</td></tr></table>";
	echo "<div align='center'>";
	echo "<form method='post' action='{$config['FULL_URL']}/install/upgrade.php'>";
	echo "<input type='submit' name='update' value='Update my language files'>";
	echo "<input type='submit' name='hand' value='I have updated my language files by hand'>";
	echo "</form>";
	require ("upgrade_footer.tmpl");

}

function step5($list="") {

	global $ubbt_lang,$config,$thisversion,$currentversion,$html;
	$changefile = file("LANGUAGE_CHANGES.txt");
	echo "<html><body>";

	$removed = array();
	$changed = array();
	$changedkey = array();
	$deleted = array();
	$new = array();
	$newkey = array();

	$thisversion = str_replace(".","\.",$thisversion);
	while (list($linenum,$line) = each($changefile)) {
		$line=preg_replace("/\n/","",$line);
		if (!$line) { continue; }
		if (preg_match("/VERSION-$thisversion:REMOVED:/",$line)) {
			$script = preg_replace("/VERSION-$thisversion:REMOVED:FILE-/","",$line);
			$script = preg_replace("/KEY-/","",$script);
			$removed[] = $script;
		}
		if (preg_match("/VERSION-$thisversion:REMOVED-FILE:/",$line)) {
			$script = preg_replace("/VERSION-$thisversion:REMOVED-FILE:/","",$line);
			$deleted[] = $script;
		}
		if (preg_match("/VERSION-$thisversion:NEW:/",$line)) {
			$script = preg_replace("/VERSION-$thisversion:NEW:FILE-/","",$line);
			$script = preg_replace("/KEY-/","",$script);
			$script = preg_replace("/:VALUE-/"," = ",$script);
			$new[] = $script;
			list($key,$value) = preg_split("# = #",$script);
			$newkey[] = $key;
		}
		if (preg_match("/VERSION-$thisversion:CHANGED:/",$line)) {
			$script = preg_replace("/VERSION-$thisversion:CHANGED:FILE-/","",$line);
			$script = preg_replace("/KEY-/","",$script);
			$script = preg_replace("/:VALUE-/"," = ",$script);
			$changed[] = $script;
			list($key,$value) = preg_split("# = #",$script);
			$changedkey[] = $key;
		}
	}

	for ($i=0;$i<sizeof($changed);$i++) {
		if (!in_array($changedkey[$i],$removed)) {
			if ($list == "changed") {
				echo "$changed[$i]<br>";
			}
		}
	}
	for ($i=0;$i<sizeof($new);$i++) {
		if (!in_array($newkey[$i],$removed)) {
			if ($list == "new") {
				echo "$new[$i]<br>";
			}
		}
	}
	for ($i=0;$i<sizeof($removed);$i++) {
		if ($list == "removed") {
			echo "$removed[$i]<br>";
		}
	}
	for ($i=0;$i<sizeof($deleted);$i++) {
		if ($list == "deleted") {
			echo "$deleted[$i]<br>";
		}
	}

	echo "</body></html>";

}

function step6() {

	global $ubbt_lang,$config,$thisversion,$currentversion,$thislanguage,$html;

	$dir = opendir("{$config['FULL_PATH']}/languages");
	$error = array();
	$passed = 0;
	while( ($file = readdir($dir)) != false) {
		if ( ($file == ".") || ($file == "..") || ($file == ".svn") || ($file == ".svn/admin") || ($file == "README") || !is_dir("{$config['FULL_PATH']}/languages/$file") ) {
			continue;
		}
		if (!$thislanguage) {
			$thislanguage = $file;
			$nextlanguage = "";
		}
		if ($thislanguage == $file) {
			$passed = 1;
		}
		if ($thislanguage != $file) {
			if ($passed == 1) {
				if (!$nextlanguage) {
					$nextlanguage = $file;
				}
			}
			continue;
		}
		$fd = @fopen("{$config['FULL_PATH']}/languages/$file/testfile","w");
		if (!$fd) {
			$error[] = "Cannot create file in {$config['FULL_PATH']}/languages/$file";
		}
		@fwrite($fd,"test");
		@fclose($fd);
		@unlink ("{$config['FULL_PATH']}/languages/$file/testfile");

		$fd = @fopen("{$config['FULL_PATH']}/languages/$file/admin/testfile","w");
		if (!$fd) {
			$error[] = "Cannot create file in {$config['FULL_PATH']}/languages/$file/admin";
		}
		@fwrite($fd,"test");
		@fclose($fd);
		@unlink ("{$config['FULL_PATH']}/languages/$file/admin/testfile");

		$langdir = opendir("{$config['FULL_PATH']}/languages/$file");
		$newdir = 0;
		while( ($langfile = readdir($langdir)) != false) {
			if ( ($langfile == ".") || ($langfile == "..") || (!preg_match("/\.php$/",$langfile)) || ($langfile == "README")  || !is_dir("{$config['FULL_PATH']}/languages/$file")) {
				continue;
			}
			if (!is_writeable("{$config['FULL_PATH']}/languages/$file/$langfile")) {
				$error[] = "Cannot add to files in {$config['FULL_PATH']}/languages/$file";
				$newdir = 1;
			}
		}
		$langdir = opendir("{$config['FULL_PATH']}/languages/$file/admin");
		$newdir = 0;
		while( ($langfile = readdir($langdir)) != false) {
			if ( ($langfile == ".") || ($langfile == "..") || (!preg_match("/\.php/",$langfile)) || ($langfile == "README")  || !is_dir("{$config['FULL_PATH']}/languages/admin/$file")) {
				continue;
			}
			if (!is_writeable("{$config['FULL_PATH']}/languages/$file/admin/$langfile") && !$newdir) {
				$error[] = "Cannot add to files in {$config['FULL_PATH']}/languages/$file/admin";
				$newdir = 1;
			}
		}

	}

	if (sizeof($error)) {
		require("upgrade_header.tmpl");

		echo "<table border='0' width='95%' align='center'>";
		echo "<tr><td class='stdautorow'>";
		echo "Unable to proceed with language file updates.  Please correct the following errors and check again at the bottom of this screen.  If you are unable to correct the permissions please return to the <a href=\"{$config['FULL_URL']}/install/upgrade.php?step=4&thislanguage=$thislanguage\">previous step</a>.  You will need to add the new strings by hand.<br /><br /><span class='small'>";

		for ($i=0;$i<sizeof($error);$i++) {
			echo "$error[$i]<br>";
		}

		echo "</span></td></tr></table>";
		echo "<div align='center'>";
		echo "<form method='post' action='{$config['FULL_URL']}/install/upgrade.php'>";
		echo "<input type='hidden' name='update' value='1'>";
		echo "<input type='hidden' name='step' value='6'>";
		echo "<input type='hidden' name='thislanguage' value='$thislanguage'>";
		echo "<input type='submit' value='Check Permissions again'>";
		echo "</form>";

		require("upgrade_footer.tmpl");
		exit;
	}

	// Figure out what we need to update in each file.
	$removedfile = array();
	$removed = array();
	$changed = array();
	$changedkey = array();
	$new = array();
	$newkey = array();
	$removedfile = array();
	$removedkey = array();
	$scripttrack = array();

	$changefile = file("LANGUAGE_CHANGES.txt");
	$thisversion = str_replace(".","\.",$thisversion);
	while (list($linenum,$line) = each($changefile)) {
		$line=preg_replace("/\n/","",$line);
		if (!$line) { continue; }
		if (preg_match("/VERSION-$thisversion:REMOVED-FILE:/",$line)) {
			$script = preg_replace("/VERSION-$thisversion:REMOVED-FILE:/","",$line);
			$removedfile[] = $script;
		}
		if (preg_match("/VERSION-$thisversion:REMOVED:/",$line)) {
			$script = preg_replace("/VERSION-$thisversion:REMOVED:/","",$line);
			$script = str_replace("FILE-","",$script);
			$removed[] = $script;
			list($one,$rkey) = preg_split("#:KEY-#",$script);
			$removedkey[] = $rkey;
		}
		if (preg_match("/VERSION-$thisversion:NEW:/",$line)) {
			$script = preg_replace("/VERSION-$thisversion:NEW:/","",$line);
			$script = str_replace("FILE-","",$script);
			$new[] = $script;
			list($crap,$key) = preg_split("#:KEY-#",$script);
			list($key,$crap) = preg_split("#:VALUE-#",$key);
			if (!in_array($key,$removedkey)) {
				$new[] = $script;
				$newkey[] = $key;
			}
		}
		if (preg_match("/VERSION-$thisversion:CHANGED:/",$line)) {
			$script = preg_replace("/VERSION-$thisversion:CHANGED:/","",$line);
			$script = str_replace("FILE-","",$script);
			list($crap,$key) = preg_split("#:KEY-#",$script);
			$sname = preg_replace("#\.php#","",$crap);
			list($key,$crap) = preg_split("#:VALUE-#",$key);
			if (!in_array($key,$scripttrack[$sname])) {
				if (!in_array($script,$removedfile)) {
					if (!in_array($key,$removedkey)) {
						$changed[] = $script;
						$changedkey[] = $key;
						$scripttrack[$sname][] = $key;
					}
				}
			}
		}
	}

	$dir = opendir("{$config['FULL_PATH']}/languages");
	$error = array();
	while( ($file = readdir($dir)) != false) {
		if ( ($file == ".") || ($file == "..") || ($file == ".svn") || ($file == ".svn/admin") || ($file == "README") || !is_dir("{$config['FULL_PATH']}/languages/$file") ) {
			continue;
		}
		for ($i=0;$i<sizeof($removedfile);$i++) {
			@unlink("{$config['FULL_PATH']}/languages/$file/$removedfile[$i]");
		}
		for ($i=0;$i<sizeof($new);$i++) {
			if (!in_array($newkey[$i],$removed)) {
				list($langfile,$line) = preg_split("#:KEY-#",$new[$i]);
				list($key,$value) = preg_split("#:VALUE-#",$line);
				$changefile = @file("{$config['FULL_PATH']}/languages/$file/$langfile");
				$dowrite = 0;
				if (!$changefile) {
					$newfile = "<?\n$key = $value\n?>";
					$dowrite = 1;
				}
				else {
					$newfile = "";
					$found = 0;
					while (list($linenum,$line) = each($changefile)) {
						if (strstr($line,$key)) {
							$found = 1;
						}
					}
					if (!$found) {
						$changefile = @file("{$config['FULL_PATH']}/languages/$file/$langfile");
						while (list($linenum,$line) = each($changefile)) {
							if (strstr($line,"?>")) {
								$newfile .= "$key = $value\n?>";
							}
							else {
								$newfile .= $line;
							}
						}
						$dowrite = 1;
					}
				}
				if ($dowrite && $newfile) {
					$fd = @fopen("{$config['FULL_PATH']}/languages/$file/$langfile","w");
					@fwrite($fd,"$newfile");
					@fclose($fd);
				}
			}
		}
		for ($i=0;$i<sizeof($changed);$i++) {
			if (!in_array($changedkey[$i],$removed)) {
				list($langfile,$line) = preg_split("#:KEY-#",$changed[$i]);
				list($key,$value) = preg_split("#:VALUE-#",$line);
				$changefile = file("{$config['FULL_PATH']}/languages/$file/$langfile");
				$newfile = "";
				$found = 0;
				$keyexists = 0;
				while (list($linenum,$line) = each($changefile)) {
					if (strstr($line,"$key = $value")) {
						$found = 1;
					}
					if (strstr($line,$key)) {
						$keyexists = 1;
					}
				}
				if (!$found) {
					$changefile = file("{$config['FULL_PATH']}/languages/$file/$langfile");
					if ($keyexists) {
						while (list($linenum,$line) = each($changefile)) {
							if (strstr($line,$key)) {
								$newfile .= "$key = $value\n";
							}
							else {
								$newfile .= $line;
							}
						}
					}
					else {
						while (list($linenum,$line) = each($changefile)) {
							if (strstr($line,"?>")) {
								$newfile .= "$key = $value\n?>";
							}
							else {
								$newfile .= $line;
							}
						}
					}
					if ($newfile) {
						$fd = @fopen("{$config['FULL_PATH']}/languages/$file/$langfile","w");
						fwrite($fd,"$newfile");
						fclose($fd);
					}
				}

			}
		}
		for ($i=0;$i<sizeof($removed);$i++) {
			list($langfile,$line) = preg_split("#:KEY-#",$removed[$i]);
			list($key,$value) = preg_split("#:VALUE-#",$line);
			$changefile = file("{$config['FULL_PATH']}/languages/$file/$langfile");
			$newfile = "";
			while (list($linenum,$line) = each($changefile)) {
				if (!strstr($line,$key)) {
					$newfile .= $line;
				}
			}
			if ($newfile) {
				$fd = @fopen("{$config['FULL_PATH']}/languages/$file/$langfile","w");
				@fwrite($fd,"$newfile");
				@fclose($fd);
			}

		}
	}

	if ($nextlanguage) {
		$metarefresh = "<meta http-equiv=\"refresh\" content=\"2;URL={$config['FULL_URL']}/install/upgrade.php?update=1&step=6&thislanguage=$nextlanguage\" />";
		require('upgrade_header.tmpl');
		echo "<table border='0' width='95%' align='center'>";
		echo "<tr><td align=\"middle\" class='stdautorow'>";
		echo "$thislanguage language files have been updated.";
		echo "</td></tr></table>";
		require('upgrade_footer.tmpl');
	}
	else {
		require('upgrade_header.tmpl');
		echo "<table border='0' width='95%' align='center'>";
		echo "<tr><td class='stdautorow'>";
		echo "Finished updating all language files.  Next we need to verify that all files were updated successfully.<br /><br />";

		for ($i=0;$i<sizeof($error);$i++) {
			echo "$error[$i]<br>";
		}

		echo "</span></td></tr></table>";
		echo "<div align='center'>";
		echo "<form method='post' action='{$config['FULL_URL']}/install/upgrade.php'>";
		echo "<input type='hidden' name='step' value='7'>";
		echo "<input type='submit' value='Verify Language File Changes'>";
		echo "</form>";

		require("upgrade_footer.tmpl");
		exit;
	}

}

function step7() {

	global $ubbt_lang,$config,$thisversion,$currentversion,$html;

	// Figure out what we need to update in each file.
	$removed = array();
	$changed = array();
	$changedkey = array();
	$removedfile = array();
	$new = array();
	$newkey = array();
	$removedkey = array();
	$changefile = file("LANGUAGE_CHANGES.txt");
	$thisversion = str_replace(".","\.",$thisversion);
	while (list($linenum,$line) = each($changefile)) {
		$line=preg_replace("/\n/","",$line);
		if (!$line) { continue; }
		if (preg_match("/VERSION-$thisversion:REMOVED-FILE:/",$line)) {
			$script = preg_replace("/VERSION-$thisversion:REMOVED-FILE:/","",$line);
			$removedfile[] = $script;
		}
		if (preg_match("/VERSION-$thisversion:REMOVED:/",$line)) {
			$script = preg_replace("/VERSION-$thisversion:REMOVED:FILE-/","",$line);
			$removed[] = $script;
			list($one,$rkey) = preg_split("#:KEY-#",$script);
			$removedkey[] = $rkey;
		}
		if (preg_match("/VERSION-$thisversion:NEW:/",$line)) {
			$script = preg_replace("/VERSION-$thisversion:NEW:FILE-/","",$line);
			if (!in_array($script,$removedfile)) {
				list($crap,$key) = preg_split("#:KEY-#",$script);
				list($key,$crap) = preg_split("#:VALUE-#",$key);
				if (!in_array($key,$removedkey)) {
					$new[] = $script;
					$newkey[] = $key;
				}
			}
		}
		if (preg_match("/VERSION-$thisversion:CHANGED:/",$line)) {
			$script = preg_replace("/VERSION-$thisversion:CHANGED:FILE-/","",$line);
			list($crap,$key) = preg_split("#:KEY-#",$script);
			list($key,$crap) = preg_split("#:VALUE-#",$key);
			if (!in_array($key,$changedkey)) {
				if (!in_array($script,$removedfile)) {
					if (!in_array($key,$removedkey)) {
						$changed[] = $script;
						$changedkey[] = $key;
					}
				}
			}
		}
	}
	$dir = opendir("{$config['FULL_PATH']}/languages");
	$error = array();
	while( ($file = readdir($dir)) != false) {
		if ( ($file == ".") || ($file == "..") || ($file == ".svn") || ($file == ".svn/admin") || ($file == "README")  || !is_dir("{$config['FULL_PATH']}/languages/$file")) {
			continue;
		}
		for ($i=0;$i<sizeof($new);$i++) {
			$found = "";
			list($langfile,$line) = preg_split("#:KEY-#",$new[$i]);
			list($key,$value) = preg_split("#:VALUE-#",$line);
			$changefile = @file("{$config['FULL_PATH']}/languages/$file/$langfile");
			while (list($linenum,$line) = each($changefile)) {
				if (strstr($line,$key)) {
					$found = 1;
				}
			}
			if (!$found && !in_array("$file/$langfile",$error)) {
				$error[] = "$file/$langfile";
			}
			if (!$found) {
				$scripterror["$file/$langfile"][] = "Missing string: $key = $value";
			}
		}
		for ($i=0;$i<sizeof($changed);$i++) {
			if (!in_array($changedkey[$i],$removed)) {
				$found = "";
				list($langfile,$line) = preg_split("#:KEY-#",$changed[$i]);
				list($key,$value) = preg_split("#:VALUE-#",$line);
				$changefile = file("{$config['FULL_PATH']}/languages/$file/$langfile");
				while (list($linenum,$line) = each($changefile)) {
					if (strstr($line,"$key = $value")) {
						$found = 1;
					} else {
					}
				}
				if (!$found && !in_array("$file/$langfile",$error)) {
					$error[] = "$file/$langfile";
				}
				if (!$found) {
					$scripterror["$file/$langfile"][] = "String not updated: $key = $value";
				}
			}
		}
		for ($i=0;$i<sizeof($removed);$i++) {
			list($langfile,$line) = preg_split("#:KEY-#",$removed[$i]);
			list($key,$value) = preg_split("#:VALUE-#",$line);
			$changefile = file("{$config['FULL_PATH']}/languages/$file/$langfile");
			$newfile = "";
			$found = "";
			while (list($linenum,$line) = each($changefile)) {
				if (strstr($line,$key)) {
					$found = 1;
				}
			}
			if ($found && !in_array("$file/$langfile",$error)) {
				$error[] = "$file/$langfile";
			}
			if ($found) {
				$scripterror["$file/$langfile"][] = "Key not removed: $key";
			}
		}
	}

	if (sizeof($error)) {
		require("upgrade_header.tmpl");
		echo "<table border='0' width='95%' align='center'>";
		echo "<tr><td align=\"middle\" class='stdautorow'>Not all language files have been updated properly.  Below you will find a list of files that have not been updated.  You can manually add these or return to the previous step to try and add them automatically.<br /><br />";
		echo "If  you want to add them by hand, please do so now and then <a href=\"{$config['FULL_URL']}/install/upgrade.php?step=7\">test again</a><br /><br />";
		echo "If you want to try and automatically add them, <a href=\"{$config['FULL_URL']}/install/upgrade.php?step=6\">run this script</a><br /><br />";
		echo "<span class='small'>";
		for ($i=0;$i<sizeof($error);$i++) {
			echo "$error[$i]<br>";
			for ($x=0;$x<sizeof($scripterror[$error[$i]]);$x++) {
				echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{$scripterror[$error[$i]][$x]}<br />";
			}
			echo "<br />";
		}
		echo "</td></tr></table>";
		require("upgrade_footer.tmpl");
		exit;
	}
	else {
		require("upgrade_header.tmpl");
		echo "<table border='0' width='95%' align='center'><tr><td class='stdautorow'>";
		echo "All language files have been updated properly.<br /><br />";
		echo "<form method='post' action='{$config['FULL_URL']}/install/upgrade.php'>";
		echo "<input type='hidden' name='step' value='config'>";
		echo "<input type='submit' value='Proceed to next step'>";
		echo "</form>";
		echo "</td></tr></table>";
		require("upgrade_footer.tmpl");
	}
}

function configs() {

	define ('UPGRADE',1);

	global $ubbt_lang,$config,$thisversion,$currentversion,$dbh,$alterstep,$starttime,$stoptime,$c_version,$alters,$configs,$config,$html;

	$newconfigs = array();

	$thisversion = preg_replace("/(\(|\))/","",$thisversion);
	$updates = preg_split("#\|#",$thisversion);

	foreach($updates as $k => $vnum) {
		if ($configs[$vnum]) {
			if (file_exists($configs[$vnum])) {
				include($configs[$vnum]);
			}
		}
	}

	if (sizeof($newconfigs)) {
		foreach($newconfigs as $k => $v) {
			$config[$k] = $v;
		}

		$newconf = "<?php\n";
		$newconf .= "\$config = " . var_export($config,true);
		$newconf .= "?>";

		$check = lock_and_write("{$config['FULL_PATH']}/includes/config.inc.php",$newconf);
		if ($check == "no_write") {
			require("upgrade_header.tmpl");
			echo "<table border='0' width='95%' align='center'>";
			echo "<tr><td align='center' class='stdautorow'>Unable to write to config.inc.php.  Please check the permissions on this file and reload this page.";
			echo "</td></tr></table>";
			require("upgrade_footer.tmpl");
			exit;
		}
	}

	require("upgrade_header.tmpl");
	echo "<table border='0' width='95%' align='center'>";
	echo "<tr><td align='center' class='stdautorow'>Config file Updated<br /><br />Continue to <a href='upgrade.php?step=styles'>the next step</a>.";
	echo "</td></tr></table>";
	require("upgrade_footer.tmpl");
}

function styles() {

	define ('UPGRADE',1);

	global $ubbt_lang,$config,$thisversion,$currentversion,$dbh,$alterstep,$starttime,$stoptime,$c_version,$alters,$styles,$config,$html;

	$newstyles = array();

	$thisversion = preg_replace("/(\(|\))/","",$thisversion);
	$updates = preg_split("#\|#",$thisversion);

	// Get the style updates
	foreach($updates as $k => $vnum) {
		if ($styles[$vnum]) {
			if (file_exists($styles[$vnum])) {
				include($styles[$vnum]);
			} // end if
		} // end if
	} // end foreach

	if (sizeof($newstyles)) {
		// Load in the current styles
		$query = "
			select STYLE_ID,STYLE_NAME,STYLE_VARS,STYLE_EDITED_TIME
			from {$config['TABLE_PREFIX']}STYLES
		";
		$sth = $dbh->do_query($query,__LINE__,__FILE__);
		while(list($id,$name,$vars,$edited) = $dbh->fetch_array($sth)) {

			$current = unserialize($vars);

			foreach($newstyles as $key => $method) {
				foreach($method as $do => $val) {
					if ($do == "copy") {
						$current[$key] = $current[$val];
					} // end if
					if ($do == "set") {
						$current[$key] = $val;
					} // end if
				} // end foreach
			} // end foreach

			$now = time();
			$new_name = "{$name}_{$now}.css";

			include("{$config['FULL_PATH']}/styles/$id.php");

			$new_style_array = <<<THE_YELLOW_BRICK_ROAD
<?php
\$style_array = array(
	"id" => '$id',
       	"general" => "{$style_array['general']}",
       	"avatars" => "{$style_array['avatars']}",
       	"forumimages" => "{$style_array['forumimages']}",
       	"graemlins" => "{$style_array['graemlins']}",
       	"icons" => "{$style_array['icons']}",
        "markup_panel" => "{$style_array['markup_panel']}",
        "news" => "{$style_array['news']}",
        "mood" => "{$style_array['mood']}",
        "wrappers" => "{$style_array['wrappers']}",
        "css" => "$new_name"
);
?>
THE_YELLOW_BRICK_ROAD;

			$cssfile = "";
			foreach($current as $class => $prop) {
				if ($class == "extra_css") {
					$cssfile .= $prop;
				} else {
					$cssfile .= <<<STYLE_PROPS
$class {
$prop
}

STYLE_PROPS;
				} // end if
			} // end foreach


			$check = lock_and_write("{$config['FULL_PATH']}/styles/$id.php",$new_style_array);
			if ($check == "no_write"){
				error("{$config['FULL_PATH']}/styles/$id.php is not writeable.  Please fix permissions and refresh this page.");
			}

			unlink("{$config['FULL_PATH']}/styles/{$name}_{$edited}.css");

			$check = lock_and_write("{$config['FULL_PATH']}/styles/$new_name",$cssfile);
			if ($check == "no_write") {
				error("{$config['FULL_PATH']}/styles/$new_name.php is not writeable.  Please fix permissions and refresh this page.");
			} // end if

			$query = "
				update {$config['TABLE_PREFIX']}STYLES
				set STYLE_VARS = ?,
				STYLE_EDITED_TIME = ?
				where STYLE_ID = ?
			";
			$dbh->do_placeholder_query($query,array(serialize($current),$now,$id),__LINE__,__FILE__);

			$msg .= "Updating Stylesheet $name<br>";

		} // end while
	} else {
		$msg = "No Stylesheet updates needed.";
	} // end if

	require("upgrade_header.tmpl");
	echo "<table border='0' width='95%' align='center'>";
	echo "<tr><td align='center' class='stdautorow'>$msg <br /><br />Continue to <a href='upgrade.php?step=dirs'>the next step</a>.";
	echo "</td></tr></table>";
	require("upgrade_footer.tmpl");

	exit;
}


function dirs() {

	define ('UPGRADE',1);

	global $ubbt_lang,$config,$thisversion,$currentversion,$dbh,$alterstep,$starttime,$stoptime,$c_version,$alters,$dirs,$config,$html;

	$newdirs = array();

	$thisversion = preg_replace("/(\(|\))/","",$thisversion);
	$updates = preg_split("#\|#",$thisversion);

	foreach($updates as $k => $vnum) {
		if ($dirs[$vnum]) {
			if (file_exists($dirs[$vnum])) {
				include($dirs[$vnum]);
			}
		}
	}
	require("upgrade_header.tmpl");
	echo "<table border='0' width='95%' align='center'>";
	echo "<tr><td align='left' class='stdautorow'>";
	$fail =  false;
	if (sizeof($newdirs)) {
		foreach($newdirs as $k => $v) {
			echo "Checking permission on {$config['FULL_PATH']}/$v";
			$check = @fopen("{$config['FULL_PATH']}/$v/index.html","w");
			@chmod("{$config['FULL_PATH']}/$v/index.html","0666");
			if (!$check) {
				echo "<br>&nbsp; &nbsp; <font color=red>Cannot create new files.  Please fix permissions and <a href='upgrade.php?step=dirs'>Click Here to try again</a>.</font><br />";
				$fail = true;
				break;
			} else {
				 echo " ...... <font color=green>OK</font><br />";
			} // end if
		} // end foreach
	} else {
		echo "No new directories added.";
	} // end if

	// Clear out old compiled templates
	echo "<br /><br/>Purging old compiled templates.";
	$thisdir = opendir("{$config['FULL_PATH']}/templates/compile");
	while(($thisfile = readdir($thisdir)) != false) {
		if ( ($thisfile == "." || $thisfile == ".." || $thisfile == "index.html")) continue;
		@unlink("{$config['FULL_PATH']}/templates/compile/$thisfile");
	} // end while

	if (!$fail) {
		echo "<br /><br />The next step is doing any necessary updates to the database.  Depending on the size of your forum, this could take a while to finish. Continue to <a href='upgrade.php?step=altertable'>the next step</a>.";
	} // end if
	echo "</td></tr></table>";
	require("upgrade_footer.tmpl");
}


function error($error) {

	require("upgrade_header.tmpl");

	echo "<table border='0' width='95%' align='center'>";
	echo "<tr><td class='stdautorow'>";
	echo "$error";
	echo "</td></tr></table>";

	require("upgrade_footer.tmpl");
	exit;
} // end error

function altertable() {

	define('UPGRADE',1);

	global $ubbt_lang,$config,$thisversion,$currentversion,$dbh,$alterstep,$starttime,$stoptime,$c_version,$alters,$html;

	$thisversion = preg_replace("/(\(|\))/","",$thisversion);
	@list($vnum,$garbage) = @preg_split("#\|#",$thisversion);

	$alterfile = "";
	if ($alters[$vnum]) {
		if ($alterstep) {
			$alterfile = $alters[$c_version];
			$vnum = $c_version;
		} else {
			$ran = 0;
			$match = 0;
			foreach($alters as $row => $value) {

				if ($row == $vnum) {
					$match = 1;
				}
				if ($value == $alters[$vnum] && !$match && !$alterstep) {
					$ran = 1;
				}
				if ($match && $value == $alters[$vnum]) {
					$alterfile = $value;
					$vnum = $row;
				}
			}
			if (!$ran) {
				$alterfile = $alters[$vnum];
				if (!file_exists($alterfile)) {
					$alterfile = "";
				}
			}
			else {
				$alterfile = "";
			}
		}

	}

	require("upgrade_header.tmpl");

	echo "<table border='0' width='95%' align='center'>";
	echo "<tr><td align='center' class='stdautorow'><b>Updating database to version: $vnum</b><br />If at any time this step times out you may just refresh this screen and it will continue.";
	echo "</td></tr></table>";
	echo "<br />";

	if (function_exists('ob_flush')) {
		ob_flush();
	}
	else {
		ob_end_flush();
	}

	$refresh = 0;
	if ($alterfile) {
		include($alterfile);
	}
	elseif ($vnum || $c_version) {
		include ("update-version.php");
	}
	else {
		echo "<table border='0' width='95%' align='center'>";
		echo "<tr><td class='stdautorow'>Serious Error: I am unable to figure out what to do.  Please contact UBB Support with the following information:";
		echo "<br /><br />";
		echo "<b>Upgrading From:</b> c_version<br />";
		echo "<b>Upgrading To:</b> $currentversion<br />";
		echo "<b>Upgrade Step:</b> $vnum<br />";
		echo "</td></tr></table>";
	}

	if ($refresh) {
		$currentstep++;
		step_refresh($currentstep);

		echo <<<EOF
</table>
<br /><br />
<tr><td class='stdautrow'>Refreshing page to prevent timeout during database upgrade.  If you are not automatically redirected in a couple seconds, you can <a href="upgrade.php?step=altertable">click this link</a> to refresh manually.
</td></tr></table>
<script language="JavaScript">
<!--
var sURL = unescape(window.location.pathname) + "?step=altertable";

setTimeout( "refresh()", 2*1000 );

function refresh()
{
	window.location.href = sURL;
}
//-->
</script>
EOF;
	}

	if (defined('DIDFAIL')) {
		echo "<br /><br />";
		echo "<table border='0' width='95%' align='center'>";
		echo "<tr><td class='stdautorow'>The above step has failed.  You may try to run this step again by returning to <a href=\"upgrade.php?step=altertable\">this link</a>.  If you are unable to resolve this issue please contact UBB Support with the above information.";
		echo "</td></tr></table>";
	} elseif ($refresh) {
		echo "<br /><br />";
		echo "<table border='0' width='95%' align='center'>";
		echo "<tr><td class='stdautorow' align='center'>";
		echo " <a href=\"upgrade.php?step=altertable\">Manually refresh to next step</a>";
		echo "</td></tr></table>";
	} else {
		echo "<br /><br />";
		echo "<table border='0' width='95%' align='center'>";
		echo "<tr><td class='stdautorow' align='center'>";
		echo "<br />Finished updating to version $vnum.";
		echo " <a href=\"upgrade.php?step=altertable\">Continue to next step</a>";
		echo "</td></tr></table>";
	}
	require("upgrade_footer.tmpl");
}
function get_auth() {

	global $ubbt_lang,$config,$thisversion,$currentversion,$step,$html;

	$metarefresh = "";
	require ("upgrade_header.tmpl");
	echo "<form method='post' action='upgrade.php'>";
	echo "<input type='hidden' name='login' value='1'>";
	echo "<input type='hidden' name='step' value='$step'>";
	echo "<table border='0' width='95%' align='center'><tr><td align='center' class='stdautorow'>";
	echo "To upgrade this board, please authenticate first.";
	echo "<p><b>Username</b>:";
	echo "<input type='text' name='username'>";
	echo "<p><b>Password</b>:";
	echo "<input type='password' name='password'>";
	echo "<p><input type='submit' value='Authenticate'>";
	echo "</td></tr></table>";
	require ("upgrade_footer.tmpl");
	exit;
}

function do_auth($username="",$password="") {

	global $dbh,$config,$html;
	$username_q = addslashes($username);
	$query = "
		SELECT USER_PASSWORD
		FROM {$config['TABLE_PREFIX']}USERS
		WHERE USER_LOGIN_NAME='$username_q'
	";
	$sth = $dbh -> do_query($query);
	list($dbpass) = $dbh -> fetch_array($sth);
	if ($dbpass) {
		if (($password == $dbpass) || (md5($password) == $dbpass) || ($dbpass == crypt($password,$dbpass))) {
			setcookie("ubbt_username","$username",0,"/");
			setcookie("ubbt_password",$dbpass,0,"/");
		}
		else {
			get_auth();
		}
	} else {
		get_auth();
	}

}

function cc_checkversion($old, $new) {

	$left = explode(".", $old);
	$right = explode(".", $new);

	while(sizeof($left) != sizeof($right)) {
		if(sizeof($left) < sizeof($right)) {
			$left[] = 0;
		} else {
			$right[] = 0;
		} // end if
	} // end while

	$older = join("", $left);
	$newer = join("", $right);

	// print "!$older!$newer!<br />";

	return $newer >= $older;

} // end cc_checkversion

?>
