<?php
$ubbt_lang['FORUM'] = 'Forum';
$ubbt_lang['POSTED'] = 'Posted';
$ubbt_lang['JUMP_NEW'] = 'Jump to new posts';
$ubbt_lang['SPOILER_CONTENT'] = 'Spoiler Content';
$ubbt_lang['NO_RESULTS_FOUND'] = 'No results were found.';
$ubbt_lang['VIEWS_REPLIES'] = 'Views: %%VIEWS%% Replies: %%REPLIES%%';
$ubbt_lang['TOPIC_START_TIME'] = 'Topic Created';
?>