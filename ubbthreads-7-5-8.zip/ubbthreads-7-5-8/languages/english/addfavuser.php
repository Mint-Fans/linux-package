<?php
$ubbt_lang['REMOVED'] = "User Removed";
$ubbt_lang['REMOVED_BODY'] = "This user has been removed from your Watched Users list";
$ubbt_lang['ADDED'] = "User Added";
$ubbt_lang['ADDED_BODY'] = "This user has been added to your Watched Users list";
$ubbt_lang['RETURN'] = "Return now";
?>