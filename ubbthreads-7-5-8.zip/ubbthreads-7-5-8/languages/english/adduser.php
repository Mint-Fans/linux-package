<?php
$ubbt_lang['EMAIL_NO_MATCH'] = "The email address you supplied does not match in both fields.  Please carefully re-type your email address.";
$ubbt_lang['BAD_LNAME'] = "You can only have alphanumeric characters (A-Z, 0-9 and underscores) in your username.";
$ubbt_lang['BAD_UNAME'] = "You can only have alphanumeric characters (A-Z, 0-9) in your Display Name.  Special characters are not allowed because this allows users to spoof other display names.  You may use the _ character to represent a space.";
$ubbt_lang['VERIFY'] = "You need to verify your email to activate this account.  You will receive an email shortly with instructions for verifying your email.  If this account isn't verified within 24 hours it will be deleted.";
$ubbt_lang['BAD_FORMAT'] = "The email address you provided has invalid formatting.  Please make sure you're entering a valid email address (username@domain.com).  A valid email address address is required in order to email your password.";
$ubbt_lang['NEEDAPPROVAL'] = "Your account needs to be approved by an Administrator before you can log in.  You will receive an email once this has been done.";
$ubbt_lang['APPROVED'] = "Your account for %%USERNAME%% at %%BOARD_TITLE%% has been approved.";
$ubbt_lang['INVALID_DATE'] = "The date you have chosen is an invalid date.";
$ubbt_lang['UNDERAGE'] = "Sorry, we do not allow children of your age to register.";
$ubbt_lang['BAD_EMAIL'] = "This email address has been banned.";
$ubbt_lang['NO_MULTI'] = "The email address you have chosen is already in use by another user. Please use a different email address.";
$ubbt_lang['PASS_USER_MATCH'] = "Your password cannot be the same as your display name.";
$ubbt_lang['PASS_MATCH'] = "The passwords you have entered do not match. Please carefully re-type your password.";
$ubbt_lang['PASS_TOO_LONG'] = "Your password needs to be between 4 and 20 characters.";
$ubbt_lang['ILL_PASS'] = "The password you entered contains illegal characters.  Please use only alphanumeric characters.";
$ubbt_lang['WEL_MSG'] = "Welcome to our forums!  Please take a moment to review and update your profile and preferences to take full advantage of our features.  You can do this by clicking on \"Edit Profile\" and \"Edit Preferences\" in the My Stuff dropdown.<br /><br />Please do not reply to this message as this is just an automated welcome message to thank you for joining our community.";
$ubbt_lang['NEW_CONFIRM'] = "User has been registered.";
$ubbt_lang['NEW_BODY'] = "Your account has been created.  Thank you for registering on our forums.";
$ubbt_lang['NEW_BODY_WITH_PASS'] = "Your account has been created.  Thank you for registering on our forums.  You should be receiving an email shortly with your password.";
$ubbt_lang['IS_RESERVED'] = "The username you have chosen is registered.  Please choose a different username.";
$ubbt_lang['NOW_LOGIN'] = "You may now login to our community.";
?>
