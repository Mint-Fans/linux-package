<?php
$ubbt_lang['NEW_DONATION'] = "Your donation has been received.  You have been added to the '%%GROUP%%' subscription group.";
$ubbt_lang['ONGOING_DONATION'] = "Your donation has been received.  Thank you for your continued support.";
$ubbt_lang['NEW_SUB'] = "Your payment has been received.  You have been added to the '%%GROUP%%' subscription group.";
$ubbt_lang['ONGOING_SUB'] = "Your payment for the '%%GROUP%%' subscription group has been received.";
$ubbt_lang['DONATION_SUBJECT'] = "Donation Received";
$ubbt_lang['PAYMENT_SUBJECT'] = "Payment Received";
?>

