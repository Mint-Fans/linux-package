<?php
$ubbt_lang['INTRO'] = "Certain information is cached to improve performance.  Click the button below to clear the cached information.  This is not something you normally need to do.";
$ubbt_lang['CLEAR_IT'] = "Clear Cache";
?>