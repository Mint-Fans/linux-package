<?php
$ubbt_lang['NAME'] = "Name";
$ubbt_lang['ORDER'] = "Order";
$ubbt_lang['DESCRIPTION'] = "Description";
$ubbt_lang['SUBMIT_C'] = "Submit Changes";
$ubbt_lang['ADD_NEW'] = "Add New Category";
$ubbt_lang['DELETE'] = "Delete";
?>