<?php
$ubbt_lang['BLANK_FIELDS'] = "Not all required fields filled out!";
$ubbt_lang['LONG_NAME'] = "The Display Name you have chosen is not the proper length.";
$ubbt_lang['LONG_LNAME'] = "The Username you have chosen is not the proper length.";
$ubbt_lang['USER_EXISTS'] = "This Display Name is already in use.  Please choose a different Display Name.";
$ubbt_lang['LOGIN_EXISTS'] = "This Username is already in use.  Please choose a different Username.";
$ubbt_lang['BAD_LNAME'] = "Only have alphanumeric characters (A-Z, 0-9 and underscores) in the username.";
$ubbt_lang['BAD_UNAME'] = "Only have alphanumeric characters (A-Z, 0-9) in the Display Name.";
$ubbt_lang['BAD_FORMAT'] = "The email address you provided has invalid formatting.  Please make sure you're entering a valid email address (username@domain.com).  A valid email address address is required in order to email your password.";
$ubbt_lang['BAD_EMAIL'] = "This email address has been banned.";
$ubbt_lang['NO_MULTI'] = "Email address is already in use by another user. Please use a different email address.";
$ubbt_lang['PASS_USER_MATCH'] = "Password cannot be the same as display name.";
$ubbt_lang['PASS_MATCH'] = "The passwords you have entered do not match. Please carefully re-type your password.";
$ubbt_lang['PASS_TOO_LONG'] = "Password needs to be between 6 and 20 characters.";
$ubbt_lang['ILL_PASS'] = "The password entered contains illegal characters.  Please use only alphanumeric characters.";
$ubbt_lang['USER_ADDED'] = "New user added to your Forums";
$ubbt_lang['F_LOC'] = "the Member Management screen.";
?>
