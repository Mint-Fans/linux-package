<?php
$ubbt_lang['EMAIL_USERS'] = "Email Members";
$ubbt_lang['RETURN'] = "Return to search results.";
$ubbt_lang['REQUESTED'] = "Here is the requested list of email addresses.  This list excludes those users that have opted out of Admin emails:";
$ubbt_lang['MAILED'] = "The requested list of addresses has been mailed to your profile email address.";
?>
