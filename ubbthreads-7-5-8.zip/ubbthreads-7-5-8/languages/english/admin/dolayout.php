<?php

$ubbt_lang['DUP_ORDER'] = "You have 2 islands in the same column with the same placement order.  Please go back and fix this.";
$ubbt_lang['NO_LEFT'] = "You have content islands turned on for the left column, although the left column isn't active.  Please return and fix this.";
$ubbt_lang['NO_RIGHT'] = "You have content islands turned on for the right column, although the right column isn't active.  Please return and fix this.";
?>