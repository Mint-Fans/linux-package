<?php
$ubbt_lang['NO_FORUM'] = "You must select a target forum for the move.";
$ubbt_lang['NO_CAT'] = "You must to choose a forum, not a category.";
$ubbt_lang['UNAPPROVED'] = "You cannot move a branch of a thread that has unapproved posts in it.";
$ubbt_lang['NONUM'] = "Unfortunately we didn't receive a post number to be moved.";
$ubbt_lang['COUNTER'] = "%s out of a total %s topics have been moved at this point.  %s topics that were not selected to be moved have been excluded.";
$ubbt_lang['F_LOC'] = "the next step.";
$ubbt_lang['F_LOC_MAIN'] = "the Move Topics screen.";
?>
