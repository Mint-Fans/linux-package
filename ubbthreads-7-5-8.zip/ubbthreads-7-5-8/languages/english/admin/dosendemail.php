<?php
$ubbt_lang['NOT_SPAM'] = "You have received this email because you have set your preferences to receive email from Administrators of {$config['COMMUNITY_TITLE']}. You may change your preference, and prevent future emails from this site's Administrators, by updating your email settings at {$config['FULL_URL']}";
$ubbt_lang['SUB_BODY'] = "You must provide both a subject and a body.";
$ubbt_lang['SENT'] = "Email Sent";
$ubbt_lang['SENT_BODY'] = "email has been sent to";
$ubbt_lang['html'] = "HTML";
$ubbt_lang['plaintext'] = "Plain Text";
$ubbt_lang['BATCH'] = "Sent to Batch";
$ubbt_lang['OF'] = "of";
$ubbt_lang['FINISHED'] = "Finished sending plain text emails.  HTML formatted emails are next.";
$ubbt_lang['FINISHED_HTML'] = "Finished sending all emails.";
$ubbt_lang['EMAIL_USERS'] = "Email Members";
$ubbt_lang['RETURN'] = "Return to search results.";
$ubbt_lang['CHECKED_SENT'] = "Email has been sent to";
$ubbt_lang['F_LOC'] = "the next step.";
$ubbt_lang['FINISHED_CLEANUP'] = "Now cleaning up.";
$ubbt_lang['FINISHED_DONE'] = "Finished sending all emails.";
?>
