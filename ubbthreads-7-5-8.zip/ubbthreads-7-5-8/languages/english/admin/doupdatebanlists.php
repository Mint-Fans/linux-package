<?php
$ubbt_lang['UPDATED'] = "Ban lists updated.";
$ubbt_lang['F_LOC'] = "the Member Management screen.";
?>
