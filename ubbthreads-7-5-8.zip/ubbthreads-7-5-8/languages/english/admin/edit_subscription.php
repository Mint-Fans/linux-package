<?php
$ubbt_lang['TITLE'] = "Edit Subscription Group";
$ubbt_lang['THIS_GROUP'] = "This subscription will allow users to join the <b>%%GROUP_TITLE%%</b> group.";
$ubbt_lang['SUB_NAME'] = "Subscription Name:";
$ubbt_lang['SUB_DESC'] = "Subscription Description:";
$ubbt_lang['SUB_DESC_1'] = "This field can be used to inform people what they get with this description, special features, access, etc.";
$ubbt_lang['DONATION'] = "Donation Settings";
$ubbt_lang['BY_DONATION'] = "Allow access by donation:";
$ubbt_lang['DONATION'] = "Donation Amount:";
$ubbt_lang['DONATION_1'] = "If this is left blank, the user will be able to fill in whatever amount they wish to donate.";
$ubbt_lang['TRIAL'] = "Trial Settings";
$ubbt_lang['BY_TRIAL'] = "Allow a trial period:";
$ubbt_lang['TRIAL_AMOUNT'] = "Trial Amount:";
$ubbt_lang['TRIAL_PERIOD'] = "Trial Period:";
$ubbt_lang['D'] = "days";
$ubbt_lang['W'] = "weeks";
$ubbt_lang['M'] = "months";
$ubbt_lang['Y'] = "years";
$ubbt_lang['USD'] = "\$";
$ubbt_lang['CAD'] = "C \$";
$ubbt_lang['EUR'] = "&euro;";
$ubbt_lang['GBP'] = "&pound;";
$ubbt_lang['JPY'] = "&yen;";
$ubbt_lang['SUBS'] = "Subscription Settings";
$ubbt_lang['BY_REG'] = "Allow access by subscription";
$ubbt_lang['SUB_AMOUNT'] = "Subscription Rate:";
$ubbt_lang['SUB_PERIOD'] = "Subscription billing cycle:";
$ubbt_lang['RECURRING'] = "Recurring Subscription:";
$ubbt_lang['RECURRING_1'] = "Subscribers will be automatically billed when the current billing cycle is completed.";
$ubbt_lang['REATTEMPT'] = "Reattempt on Failed Transactions.";
$ubbt_lang['REATTEMPT_1'] = "If the initial transaction fails, we will reattempt billing 3 days later and then 5 days after that before finally cancelling the subscription.";
$ubbt_lang['UPDATE_SUB'] = "Update Subscription Group";

?>
