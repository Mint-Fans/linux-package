<?php
$ubbt_lang['AVATAR'] = "Choose an image.";
$ubbt_lang['SELECT_AV'] = "Use this image.";
$ubbt_lang['NO_AV'] = "No image.";
$ubbt_lang['CANCEL'] = "Cancel";
?>
