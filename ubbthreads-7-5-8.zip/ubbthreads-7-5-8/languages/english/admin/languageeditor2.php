<?php
$ubbt_lang['LANG_EDIT'] = "Language Editor";
$ubbt_lang['KEY'] = "Key";
$ubbt_lang['STRING'] = "String";
$ubbt_lang['NEW_STRINGS'] = "You can add new language strings below.  Each new string must have a unique new name.";
$ubbt_lang['UPDATE_FILE'] = "Update Language File.";
?>