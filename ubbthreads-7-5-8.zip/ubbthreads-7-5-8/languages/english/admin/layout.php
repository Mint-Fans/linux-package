<?php
$ubbt_lang['LAYOUT_DESC'] = "Here you can decide on your main layout, how many columns and what island gets displayed in each column.<br /><br />If you have an island that you want to use somewhere on your site, but not on the portal check the 'Always Build' option.  Otherwise the island will not be built if it isn't in your portal setting.<br /><i>Note: The Private Calendar is not available outside of the portal.</i>";
$ubbt_lang['UPDATE_LAYOUT'] = "Update Layout";
$ubbt_lang['ISLAND'] = "Island";
$ubbt_lang['ORDER'] = "Order";

$ubbt_lang['LEFT_COL'] = "Left Column";
$ubbt_lang['RIGHT_COL'] = "Right Column";
$ubbt_lang['ALWAYS_BUILD'] = "Always Build";
$ubbt_lang['EXTERNAL'] = "External Use";

$ubbt_lang['online_now'] = "Who's Online";
$ubbt_lang['new_users'] = "Newest Members";
$ubbt_lang['calendar'] = "Private Calendar";
$ubbt_lang['search'] = "Search";
$ubbt_lang['shoutbox'] = "Shout Box";
$ubbt_lang['popular_topics'] = "Popular Topics";
$ubbt_lang['top_posters'] = "Top Posters";
$ubbt_lang['top_posters_30'] = "Top Posters (last 30 days)";
$ubbt_lang['forum_stats'] = "Forum Stats";
$ubbt_lang['birthdays'] = "Todays' Birthdays";
$ubbt_lang['public_calendar'] = "Public Calendar";
$ubbt_lang['portal_box'] = "Custom Island #";
$ubbt_lang['post_island'] = "Post Island #";
$ubbt_lang['gallery_island'] = "Gallery Island #";
$ubbt_lang['featured_member'] = "Featured Member";

$ubbt_lang['DUP_ORDER'] = "You have 2 islands in the same column with the same placement order.  Please go back and fix this.";

$ubbt_lang['HIDE_ISLAND'] = "Hide";

?>
