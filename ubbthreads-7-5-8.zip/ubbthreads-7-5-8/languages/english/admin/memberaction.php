<?php
$ubbt_lang['NO_ACTION'] = "You did not select an action to perform.";
$ubbt_lang['F_LOC'] = "the search results screen.";
$ubbt_lang['PERFORMED'] = "The specified action has been performed on the selected members.";
?>
