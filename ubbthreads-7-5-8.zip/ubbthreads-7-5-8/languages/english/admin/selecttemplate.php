<?php
$ubbt_lang['HEAD'] = "Choose a template to edit.";
$ubbt_lang['BODY'] = "Select the template you wish to edit:";
$ubbt_lang['EDIT'] = "Edit Selected Template";
$ubbt_lang['CHOOSE_TEMP'] = "Choose Template:";
$ubbt_lang['TEMPLATE_EDIT'] = "Template Editor";
?>