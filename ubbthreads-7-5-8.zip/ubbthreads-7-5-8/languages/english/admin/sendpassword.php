<?php
$ubbt_lang['F_LOC'] = "this member's profile.";
$ubbt_lang['PASS_SENT'] = "A temporary password has been sent to this user.";
?>
