<?php
$ubbt_lang['FORUMS'] = "Forums";
$ubbt_lang['THREADS'] = "Threads";
$ubbt_lang['POSTS'] = "Posts";
$ubbt_lang['LASTPOST'] = "Last Post";

$ubbt_lang['SUBJECT_POSTER'] = "Subject / Poster";
$ubbt_lang['REPLIES'] = "Replies";
$ubbt_lang['VIEWS'] = "Views";
$ubbt_lang['POSTEDON'] = "Posted On";
?>
