<?php
$ubbt_lang['AVATAR'] = "Choose an avatar.";
$ubbt_lang['SELECT_AV'] = "Use this Avatar.";
$ubbt_lang['NO_AV'] = "No avatar";
$ubbt_lang['CANCEL'] = "Cancel";
?>