<?php
$ubbt_lang['POSTS_PER'] = "Your selection for Posts Per Page is invalid.";
$ubbt_lang['FLAT_BAD'] = "Flat Posts Per Page field must be set between 1 and 99.";
?>