<?php
$ubbt_lang['MY_MOOD'] = "My Mood";
$ubbt_lang['UPDATE_MOOD'] = "Update My Mood";
?>