<?php
$ubbt_lang['EDIT_FAV_FORUMS'] = "Edit your watched forums.";
$ubbt_lang['REMOVE'] = "Remove";
$ubbt_lang['FORUM'] = "Forum";
$ubbt_lang['EMAIL'] = "Email Notification";
$ubbt_lang['DAILY_EMAIL'] = "Daily";
$ubbt_lang['IMMEDIATE_EMAIL'] = "Immediately";
$ubbt_lang['REMOVE_BUTTON'] = "Update Watched Forums";
$ubbt_lang['FAVORITE'] = "Watched";
$ubbt_lang['NO'] = "No";
$ubbt_lang['YES'] = "Yes";
$ubbt_lang['NO_EMAIL'] = "Never";
$ubbt_lang['EMAIL_ON_NEW_TOPIC'] = "When a new topic is created";
$ubbt_lang['EMAIL_ON_NEW_POST'] = "Where a new post is created";

?>