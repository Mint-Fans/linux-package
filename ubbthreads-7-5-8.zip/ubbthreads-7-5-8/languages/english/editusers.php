<?php
$ubbt_lang['EDIT_FAV_USERS'] = "Edit your Watched Users.";
$ubbt_lang['REMOVE'] = "Remove";
$ubbt_lang['USER'] = "User";
$ubbt_lang['EMAIL'] = "Email Notification";
$ubbt_lang['IMMEDIATE_EMAIL'] = "Immediately";
$ubbt_lang['REMOVE_BUTTON_USERS'] = "Update Watched Users";
$ubbt_lang['ADD_FAVORITE'] = "Add a user to your list.";

$ubbt_lang['EDIT_FAV_TOPICS'] = "Edit your Watched Topics.";
$ubbt_lang['TOPIC'] = "Topic";
$ubbt_lang['REMOVE_BUTTON_TOPICS'] = "Update Watched Topics";

$ubbt_lang['EDIT_FAV_FORUMS'] = "Edit your watched forums.";
$ubbt_lang['REMOVE_BUTTON_FORUMS'] = "Update Watched Forums";
$ubbt_lang['FORUM'] = "Forum";

$ubbt_lang['YES'] = "Yes";
$ubbt_lang['NO'] = "No";

$ubbt_lang['VIEW_WATCH'] = "Watch Lists";
$ubbt_lang['WATCH_IT_FORUM'] = "Watch this forum";
$ubbt_lang['EMAIL_ON_NEW_TOPIC'] = "When a new topic is created";
$ubbt_lang['EMAIL_ON_NEW_POST'] = "Where a new post is created";
?>