<?php
$ubbt_lang['CONFIRM_DELETE'] = "Are you sure you wish to delete the selected topics?";
$ubbt_lang['NUM_POSTS_DEL'] = "<b>%%POSTS%%</b> posts will be deleted with this topic.";
$ubbt_lang['NUM_POSTS_MOV'] = "<b>%%POSTS%%</b> posts will be moved with this topic.";
$ubbt_lang['FORUM'] = "Forum";
$ubbt_lang['THREAD'] = "Thread";
$ubbt_lang['CONFIRMED_STICK'] = "The selected topics have been made sticky.<br />Please wait while we return you to the forum page.";
$ubbt_lang['CONFIRMED_UNSTICK'] = "The selected topics are no longer sticky.<br />Please wait while we return you to the forum page.";
$ubbt_lang['CONFIRMED_CLOSE'] = "The selected topics have been closed.<br />Please wait while we return you to the forum page.";
$ubbt_lang['CONFIRMED_OPEN'] = "The selected topics have been opened.<br />Please wait while we return you to the forum page.";
$ubbt_lang['CONFIRMED_DELETE'] = "The selected topics have been deleted.<br />Please wait while we return you to the forum page.";
$ubbt_lang['CONFIRMED_ANNOUNCE'] = "The selected topics have been made global announcements.<br />Please wait while we return you to the forum page.";
$ubbt_lang['CONFIRMED_APPROVED'] = "The selected topics have been approved.<br />Please wait while we return you to the forum page.";
$ubbt_lang['CONFIRM_MOVE'] = "Are you sure you wish to move/merge the selected topics?";
$ubbt_lang['CONFIRMED_GENERIC'] = "Inline Moderation Complete!";
$ubbt_lang['INLINE_RETURN'] = "Return to the forum page now.";
$ubbt_lang['INLINE_FORUM_MIXED_TYPE'] = "You may only move topics from to a forum of the same type as the original forum. (For example, a gallery forum to a gallery forum)";
$ubbt_lang['INLINE_INVALID_FORUM'] = "There was a problem using the forum you selected.  This often occurs when a forum has recently been deleted.<br />Please use your back button to return to the previous page, and select a different forum.";
$ubbt_lang['MOVE_TOPICS'] = "Move Topics";
$ubbt_lang['TOPICS_TO_BE_MOVED'] = "Topics To Be Moved";
$ubbt_lang['NO_ACCESS_DEST'] = "You cannot move a post to a forum for which you do not have access.";
$ubbt_lang['INVALID_DEST'] = "You must have a <b>forum</b> to move the threads into.  This forum must be accessible by you.";
$ubbt_lang['INVALID_MERGE_DEST'] = "You are not allowed to merge a topic into itself, or to merge the topic into a topic not accessible by you.";
?>
