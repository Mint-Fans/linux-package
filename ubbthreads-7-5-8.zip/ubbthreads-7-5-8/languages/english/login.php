<?php
$ubbt_lang['FORGOT_PASS'] = "Forget your password?";
$ubbt_lang['FORGOT_ENTER'] = "Enter the email address or your Username to have a temporary password mailed to you.";
$ubbt_lang['REMEMBER_ME'] = "Remember me on each visit.";
$ubbt_lang['LOGIN_PROMPT'] = "Please log in.";
$ubbt_lang['LOGIN_PROMPT2'] = "Enter your Username and Password to log in.  If you have not yet registered, you can";
$ubbt_lang['REG_ONE'] = "register here";
$ubbt_lang['PASSWORD_TEXT'] = "Password";
$ubbt_lang['BUTT_FORGOT'] = "I forgot my password";
$ubbt_lang['TEXT_LOGIN'] = "Username";
$ubbt_lang['LOGOUT_HEADER'] = "Logout";
$ubbt_lang['LOGOUT_BODY'] = "Logging you out...";
$ubbt_lang['TEXT_OR'] = " -or- ";
?>
