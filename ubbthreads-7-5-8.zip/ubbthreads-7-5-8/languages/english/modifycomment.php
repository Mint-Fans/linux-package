<?php
$ubbt_lang['NO_EDIT'] = "You cannot edit this post.";
$ubbt_lang['MODIF_HEAD'] = "Comment Modified.";
$ubbt_lang['RET_FORUM'] = "You will now be returned to this user's profile.";
$ubbt_lang['PROFILE_RETURN'] = "Return to profile.";
$ubbt_lang['DELETE_HEAD'] = "Comment Deleted.";
?>
