<?php
$ubbt_lang['CHOOSE_HEAD'] = "Move post &amp; replies";
$ubbt_lang['MOVE_TO'] = "Move post &amp; replies to:";
$ubbt_lang['MERGE_WITH'] = "Merge post &amp; replies with Post#:";
$ubbt_lang['REASON'] = "Reason for moving? (Will be included, if a PM is sent)";
$ubbt_lang['SEND_PM'] = "Should a PM be sent to the topic starter?";
$ubbt_lang['SUBMIT'] = "Submit";
?>