<?php
$ubbt_lang['NO_NOTIFY'] = "The Moderator has already been notified about this post.";
$ubbt_lang['NOTIFY_MOD'] = "Notify Moderator";
$ubbt_lang['SEND_IT'] = "Yes, notify Moderators of this post!";
$ubbt_lang['NO_POST'] = "There was a problem looking up this post in our database.";
$ubbt_lang['REASON_FOR_NOTIFY'] = "Reason you are notifying:";
?>
