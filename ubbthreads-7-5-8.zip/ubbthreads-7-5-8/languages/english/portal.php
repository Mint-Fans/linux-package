<?php
$ubbt_lang['POSTED_BY'] = "by";
$ubbt_lang['POSTED_ON'] = "Posted:";
$ubbt_lang['VIEWS'] = "Views";
$ubbt_lang['REPLIES'] = "Comments";
?>