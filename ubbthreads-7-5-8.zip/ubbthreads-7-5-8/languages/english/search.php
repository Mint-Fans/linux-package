<?php
$ubbt_lang['SEARCH_INFO'] = "Enter the criteria by which you wish to search in the form below.";
$ubbt_lang['SEARCH_FORUM'] = "Forum(s) to search";
$ubbt_lang['SEARCH_FORUM2'] = "Multiple forums may be selected.  If a category is chosen, all forums within that category will be searched.";
$ubbt_lang['ALL_FORUMS'] = "All Forums";
$ubbt_lang['SEARCH_WORDS'] = "Keyword Search Terms";
$ubbt_lang['IN_SUBJECT'] = "in subject";
$ubbt_lang['IN_SUB_BODY'] = "in subject and body";
$ubbt_lang['TIPS'] = "Advanced Search Tips";
$ubbt_lang['SEARCH_NAME'] = "Display Name Search";
$ubbt_lang['SEARCH_USER'] = "By Display Name";
$ubbt_lang['SEARCH_DATE'] = "Date Range";
$ubbt_lang['MAX_RANGE'] = "Maximum date range is";
$ubbt_lang['NEWER'] = "Newer than";
$ubbt_lang['OLDER'] = "Older than";
$ubbt_lang['RANGE'] = "Search posts within the following range";
$ubbt_lang['RESULT_FORMAT'] = "Result format";
$ubbt_lang['SEARCH_NUM'] = "results to show per page.";
$ubbt_lang['PREVIEW_BODY'] = "Show a preview of post body with results.";
$ubbt_lang['NO_SEARCH'] = "You do not have permission to use the search engine.";
$ubbt_lang['IN_BODY'] = "in body";
?>
