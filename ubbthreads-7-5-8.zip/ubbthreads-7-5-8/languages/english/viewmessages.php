<?php
$ubbt_lang['NOLIMIT'] = "unlimited";
$ubbt_lang['QUOTA'] = "Quota: ";
$ubbt_lang['PT'] = "Your Private Messages";
$ubbt_lang['USERNAME'] = "Display Name";
$ubbt_lang['REPLIES'] = "Replies";
$ubbt_lang['LAST_POST'] = "Last Post";
$ubbt_lang['BY'] = "by";
$ubbt_lang['SEND_NEW'] = "New private message";
$ubbt_lang['VIEW_ADDRESS'] = "View UBB Buddies";
$ubbt_lang['PARTICIPANTS'] = "Participants: ";
$ubbt_lang['PT_SELECT'] = "Select";
?>