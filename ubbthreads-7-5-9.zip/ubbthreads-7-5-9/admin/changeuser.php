<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/changeuser.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");


// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$myuid = $user['USER_ID'];
$mystatus = $user['USER_MEMBERSHIP_LEVEL'];


$admin->doAuth(array("EDIT_USERS"));

// -------------
// Get the input
$returntab = get_input("returntab","post");
$uid = get_input("uid","post");
$icq = get_input("icq","post");
$yahoo = get_input("yahoo","post");
$msn = get_input("msn","post");
$aim = get_input("aim","post");
$CUSTOM_FIELD_1 = get_input("CUSTOM_FIELD_1","post");
$CUSTOM_FIELD_2 = get_input("CUSTOM_FIELD_2","post");
$CUSTOM_FIELD_3 = get_input("CUSTOM_FIELD_3","post");
$CUSTOM_FIELD_4 = get_input("CUSTOM_FIELD_4","post");
$CUSTOM_FIELD_5 = get_input("CUSTOM_FIELD_5","post");

$display_name = trim(get_input("display_name","post"));
$usertitle = get_input("usertitle","post");
$namecolor = get_input("namecolor","post");
$email = get_input("email","post");
$fakeemail = get_input("fakeemail","post");
$isbanned = get_input("isbanned","post");
$status = get_input("status","post");
$under13 = get_input("under13","post");
$location = get_input("location","post");
$occupation = get_input("occupation","post");
$hobbies = get_input("hobbies","post");
$homepage = get_input("homepage","post");
$sig = get_input("sig","post");
$avatar = get_input("avatar","post");
$avatarurl = get_input("avatarurl","post");
$avurl = get_input("avurl","post");
$avwidth = get_input("avwidth","post");
$avheight = get_input("avheight","post");
$showbday = get_input("showbday","post");
$timeoffset = get_input("timeoffset","post");
$timeformat = get_input("timeformat","post");
$threadage = get_input("threadage","post");
$sort = get_input("sort","post");
$display = get_input("display","post");
$postsper = get_input("postsper","post");
$flatposts = get_input("flatposts","post");
$showsigs = get_input("showsigs","post");
$visible = get_input("visible","post");
$acceptpriv = get_input("acceptpriv","post");
$notify = get_input("notify","post");
$ereplies = get_input("ereplies","post");
$notes = get_input("notes","post");
$caneditu = get_input("caneditu","post");
$canapprovep = get_input("canapprovep","post");
$caneditp = get_input("caneditp","post");
$canlockp = get_input("canlockp","post");
$canmovep = get_input("canmovep","post");
$candeletep = get_input("candeletep","post");
$canstickp = get_input("canstickp","post");
$floodcontrol = get_input("floodcontrol","post");
$grouparr_size = get_input("grouparr_size","post");
$expires = get_input("expires","post");
$reason = get_input("reason","post");

if (preg_match("/Moderator/",$user['USER_MEMBERSHIP_LEVEL'])) {
	$usertitle = preg_replace("#<#","&lt;",$usertitle);
}

// Get some info on the user we are editing
$query = "
	select t1.USER_MEMBERSHIP_LEVEL,t2.USER_GROUP_IMAGES
	from {$config['TABLE_PREFIX']}USERS as t1,
	{$config['TABLE_PREFIX']}USER_PROFILE as t2
	where t1.USER_ID = ?
	and t2.USER_ID = t1.USER_ID
";
$sth = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
list($this_status,$gimages) = $dbh->fetch_array($sth);

// Moderators can only edit users with the USER status
if (preg_match("/Moderator/",$mystatus) && (preg_match("/Moderator/",$this_status) || $this_status == "Administrator")) {
	$admin->error("Moderators cannot edit Moderators or Administrators");
	exit;
}

// Moderators cannot promote anyone to moderator or admin
if (preg_match("/Moderator/",$mystatus) && (preg_match("/Moderator/",$status) || $status == "Administrator")) {
	$admin->error("Moderators cannot promote anyone to moderators or administrators");
	exit;
}


if (!$caneditu) $caneditu = 0;
if (!$canapprovep) $canapprovep = 0;
if (!$caneditp) $caneditp = 0;
if (!$canlockp) $canlockp = 0;
if (!$canmovep) $canmovep = 0;
if (!$candeletep) $candeletep = 0;
if (!$canstickp) $canstickp = 0;

if ($status == "Administrator") {
	$isadmin = 1;
	$ismod = 0;
	$isgmod = 0;
}
if ($status == "Moderator") {
	$ismod = 1;
	$isadmin = 0;
	$isgmod = 0;
}
if ($status == "GlobalModerator") {
	$isgmod = 1;
	$isadmin = 0;
	$ismod = 0;
}
if (!$floodcontrol && $floodcontrol != '0') {
	$floodcontrol = -1;
}
if ($showsigs) {
	$showsigs = "yes";
}
else {
	$showsigs = "no";
}

if ($visible) {
	$visible = "yes";
}
else {
	$visible = "no";
}

if ($acceptpriv) {
	$acceptpriv = "yes";
}
else {
	$acceptpriv = "no";
}

if ($notify) {
	$notify = "On";
}
else {
	$notify = "Off";
}

if ($ereplies) {
	$ereplies = "On";
}
else {
	$ereplies = "Off";
}

$default_sig = $sig;

// Update $avatar
$picupdate = "";
$picture = "";
$imagewidth = "";
$imageheight = "";
if ($avatar == "none") {
	$picture = "";
	$imagewidth = "0";
	$imageheight = "0";
	$picupdate = 1;
}
if ($avatar == "url") {
	$picture = $avatarurl;
	$imagehw = GetImageSize($picture);
	$imagewidth = $imagehw[0];
	$imageheight = $imagehw[1];
	if ($config['AVATAR_MAX_WIDTH'] && $config['AVATAR_MAX_HEIGHT']) {
		if ($imagewidth > $config['AVATAR_MAX_WIDTH']) {
			$div = $imagewidth / $config['AVATAR_MAX_WIDTH'];
			$imagewidth = ceil($imagewidth / $div);
			$imageheight = ceil($imageheight / $div);
		}
		if ($imageheight > $config['AVATAR_MAX_HEIGHT']) {
			$div = $imageheight / $config['AVATAR_MAX_HEIGHT'];
			$imageheight = ceil($imageheight / $div);
			$imagewidth = ceil($imageheight / $div);
		}
	}

	$picupdate = 1;
}
if ($avatar == "stock") {
	$picture = $avurl;
	$imagewidth = $avwidth;
	$imageheight = $avheight;
	$picupdate = 1;
}

// Check the homepage url
if ($homepage) {
	$homepage = str_replace("http://","",$homepage);
}

// Markup $sig
$sig = $html->do_markup($sig,"signature","markup");

// Make sure $display_name isn't already taken
$query = "
	SELECT USER_DISPLAY_NAME
	FROM {$config['TABLE_PREFIX']}USERS
	WHERE USER_DISPLAY_NAME = ?
	AND   USER_ID <> ?
";
$sth = $dbh->do_placeholder_query($query,array($display_name,$uid),__LINE__,__FILE__);
list($check) = $dbh->fetch_array($sth);
if ($check) {
	$admin->error($ubbt_lang['NAME_TAKEN']);
}

if ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator") {
	// Moderating which forums?
	$moderated = array();
	if ($isadmin) {
		if (isset($_POST['adminforums'])) {
			for($i=0;$i<sizeof($_POST['adminforums']);$i++) {
				if ($_POST['adminforums'][$i] == "category") {
					continue;
				}
				$moderated[] = $_POST['adminforums'][$i];
			}
		}
		$ismod = "0";
		$isgmod = 0;
		$newstatus = "Administrator";
	}
	elseif ($isgmod) {
		if (isset($_POST['modforums'])) {
			for($i=0;$i<sizeof($_POST['modforums']);$i++) {
				if ($_POST['modforums'][$i] == "category") {
					continue;
				}
				$moderated[] = $_POST['modforums'][$i];
			}
		}
		$newstatus = "GlobalModerator";
	}
	elseif ($ismod) {
		if (isset($_POST['modforums'])) {
			for($i=0;$i<sizeof($_POST['modforums']);$i++) {
				if ($_POST['modforums'][$i] == "category") {
					continue;
				}
				$moderated[] = $_POST['modforums'][$i];
			}
		}
		$newstatus = "Moderator";
	}
	else {
		$newstatus = "User";
	}
}

$newgroups = array();
if ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator") {
	// Groups need to be adjusted for $isadmin
	if (!$isadmin && ($uid == $user['USER_ID'])) {
		$admin->error($ubbt_lang['NO_R_ADMIN']);
	}
	if ($isadmin) {
		$newgroups[] = 1;
	}
	if ($isgmod) {
		$newgroups[] = 2;
		$newgroups[] = 3;
	}
	if ($ismod) {
		$newgroups[] = 3;
	}
}

// Coppa needs to be set by $under13
if (!$under13) {
	$under13 = "0";
}

// New groups?
if (!isset($_POST['group'])) {
	$_POST['group'] = array();
}
for($i=0;$i<$grouparr_size;$i++) {
	if (isset($_POST['group'][$i])) {
		$newgroups[] =$_POST['group'][$i];
	}
}

// Make sure they belong to at least 1 group
if (!sizeof($newgroups)) {
	$admin->error($ubbt_lang['NO_GROUPS']);
}


$query = "
	UPDATE {$config['TABLE_PREFIX']}USERS
	SET USER_DISPLAY_NAME = ?
	WHERE USER_ID = ?
";
$dbh->do_placeholder_query($query,array($display_name,$uid),__LINE__,__FILE__);

if (!$showbday) $showbday = 0;

$query_vars = array($CUSTOM_FIELD_1,$CUSTOM_FIELD_2,$CUSTOM_FIELD_3,$CUSTOM_FIELD_4,$CUSTOM_FIELD_5,
$usertitle,$namecolor,$email,$fakeemail,$location,$occupation,$hobbies,$homepage,$sig,$default_sig,
$icq,$yahoo,$msn,$aim,$showbday,$config['TIME_FORMATS'][$timeformat],$timeoffset,
$display,$postsper,$flatposts,$showsigs,$visible,$acceptpriv,$notify,$floodcontrol,$new_images);

// Do we need to update their picture?
if ($picupdate) {
	$picupdate = ", USER_AVATAR = ?,USER_AVATAR_WIDTH= ? ,USER_AVATAR_HEIGHT= ? ";
	array_push($query_vars,$picture,$imagewidth,$imageheight);
}
if ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator") {
	$query = "
		update {$config['TABLE_PREFIX']}USERS
		set USER_MEMBERSHIP_LEVEL = ?
		where USER_ID = ?
	";
	$dbh->do_placeholder_query($query,array($newstatus,$uid),__LINE__,__FILE__);
}

array_push($query_vars,$uid);

$query = "
	UPDATE {$config['TABLE_PREFIX']}USER_PROFILE
	SET USER_EXTRA_FIELD_1 = ? ,
	USER_EXTRA_FIELD_2 = ?,
	USER_EXTRA_FIELD_3 = ? ,
	USER_EXTRA_FIELD_4 = ? ,
	USER_EXTRA_FIELD_5 = ? ,
	USER_CUSTOM_TITLE = ? ,
	USER_NAME_COLOR = ? ,
	USER_REAL_EMAIL = ? ,
	USER_DISPLAY_EMAIL = ? ,
	USER_LOCATION = ? ,
	USER_OCCUPATION = ? ,
	USER_HOBBIES = ? ,
	USER_HOMEPAGE = ? ,
	USER_SIGNATURE = ? ,
	USER_DEFAULT_SIGNATURE = ? ,
	USER_ICQ = ? ,
	USER_YAHOO = ? ,
	USER_MSN = ? ,
	USER_AIM = ? ,
	USER_PUBLIC_BIRTHDAY = ? ,
	USER_TIME_FORMAT = ? ,
	USER_TIME_OFFSET = ? ,
	USER_TOPIC_VIEW_TYPE = ? ,
	USER_TOPICS_PER_PAGE = ? ,
	USER_POSTS_PER_TOPIC = ? ,
	USER_SHOW_SIGNATURES = ? ,
	USER_VISIBLE_ONLINE_STATUS = ? ,
	USER_ACCEPT_PM = ? ,
	USER_NOTIFY_ON_PM = ? ,
	USER_FLOOD_CONTROL_OVERRIDE = ?,
	USER_GROUP_IMAGES = ?
	$picupdate
	WHERE USER_ID = ?
";
$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

if (!$isbanned) $isbanned = "0";
$query = "
	update {$config['TABLE_PREFIX']}USERS
	set 	USER_IS_BANNED = ? ,
	USER_IS_UNDERAGE = ?
	where USER_ID = ?
";
$dbh->do_placeholder_query($query,array($isbanned,$under13,$uid),__LINE__,__FILE__);

// If user is banned, insert into BANNED_USERS table
if ($isbanned) {
	$query = "
		select BAN_EXPIRATION from {$config['TABLE_PREFIX']}BANNED_USERS
		where USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
	list ($c_expire) = $dbh->fetch_array($sth);

	if (!$c_expire && $c_expire != '0') {
		if ($expires) {
			$expires = $html->get_date() + ($expires * 86400);
		}
		$query = "
			insert into {$config['TABLE_PREFIX']}BANNED_USERS
			(USER_ID,BAN_EXPIRATION,BAN_REASON)
			values
			( ? , ? , ? )
		";
		$dbh->do_placeholder_query($query,array($uid,$expires,$reason),__LINE__,__FILE__);
	} else {
		if ($expires == "change") {
			$expires = $c_expire;
		} else {
			if ($expires) {
				$expires = $html->get_date() + ($expires * 86400);
			}
		}
		$query = "
			update {$config['TABLE_PREFIX']}BANNED_USERS
			set BAN_EXPIRATION = ?,
			BAN_REASON = ?
			where USER_ID = ?
		";
		$dbh->do_placeholder_query($query,array($expires,$reason,$uid),__LINE__,__FILE__);
	}
} else {
	$query = "
		delete from {$config['TABLE_PREFIX']}BANNED_USERS
		where USER_ID = ?
	";
	$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
}

// Now update their groups if necessary
// First grab their current groups
$query = "
	select GROUP_ID
	from {$config['TABLE_PREFIX']}USER_GROUPS
	where USER_ID = ?
";
$sth = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
$old_groups = array();
$group_images = unserialize($gimages);
while(list($gid) = $dbh->fetch_array($sth)) {
	$old_groups[] = $gid;
	if (!in_array($gid,$newgroups)) {
		// Delete
		$query = "
			delete from {$config['TABLE_PREFIX']}USER_GROUPS
			where USER_ID = ?
			and GROUP_ID = ?
		";
		$dbh->do_placeholder_query($query,array($uid,$gid),__LINE__,__FILE__);
		$userob->clear_cached_perms($uid);
		unset($group_images[$gid]);
	}
}

$new_images = array();
foreach($group_images as $k => $v) {
	if ($v) {
		$new_images[] = $v;
	}
}


for($i=0;$i<sizeof($newgroups);$i++) {
	if ($newgroups[$i] && !in_array($newgroups[$i],$old_groups)) {
		// add
		$query = "
			insert into {$config['TABLE_PREFIX']}USER_GROUPS
			values
			( ? , ? )
		";
		$dbh->do_placeholder_query($query,array($uid,$newgroups[$i]),__LINE__,__FILE__);
		$userob->clear_cached_perms($uid);
	}
}

if ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator") {
	// Update their moderated formum using $moderated array
	// Get their current moderated forums
	$query = "
		SELECT FORUM_ID
		FROM {$config['TABLE_PREFIX']}MODERATORS
		WHERE USER_ID = ?
	";
	$sth = $dbh -> do_placeholder_query($query,array($uid),__LINE__,__FILE__);
	$currentmodlist = array();
	while(list($mod_board) = $dbh -> fetch_array($sth)) {
		if (!in_array($mod_board,$moderated)) {
			$query = "
				DELETE FROM {$config['TABLE_PREFIX']}MODERATORS
				WHERE USER_ID = ?
				AND FORUM_ID = ?
			";
			$dbh->do_placeholder_query($query,array($uid,$mod_board),__LINE__,__FILE__);
		}
		else {
			$currentmodlist[] = $mod_board;
		}
	}
	for ($i=0;$i<sizeof($moderated);$i++) {
		if (!in_array($moderated[$i],$currentmodlist)) {
			$query = "
				INSERT INTO {$config['TABLE_PREFIX']}MODERATORS
				(USER_ID,FORUM_ID)
				VALUES
				( ? , ? )
			";
			$dbh -> do_placeholder_query($query,array($uid,$moderated[$i]),__LINE__,__FILE__);
		}
	}
}

// Update the notes
$query = "
	REPLACE INTO {$config['TABLE_PREFIX']}USER_NOTES
	(USER_ID,NOTE_TEXT)
	VALUES
	( ? , ? )
";
$dbh -> do_placeholder_query($query,array($uid,$notes),__LINE__,__FILE__);

// Delete the cached permissions so they are rebuilt
$query = "
	delete from {$config['TABLE_PREFIX']}CACHED_PERMISSIONS
	where USER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);

// ---------------
// Log this action
admin_log("CHANGE_USER", "$uid:$display_name");

$admin->redirect($ubbt_lang['USER_UPDATED'],"{$config['BASE_URL']}/admin/showuser.php?uid=$uid&returntab=$returntab",$ubbt_lang['F_LOC']);

?>
