<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/copy_forumperms.php");

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$copy_from = get_input("copy_from","post");
$copy_to = get_input("copyto","post");


if (!$copy_from && $copy_from != 0) {
	$admin->error($ubbt_lang['NO_COPY_FROM']);
}

if (!sizeof($copy_to) || !is_array($copy_to)) {
	$admin->error($ubbt_lang['NO_COPY_TO']);
}

// Grab current permission set of the $copy_from forum
$result = array();
$perms = array();
$query = "
	select * from {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
	where FORUM_ID = ?
";
$sth = $dbh->do_placeholder_query($query,array($copy_from),__LINE__,__FILE__);
while($row = $dbh->fetch_array($sth,MYSQL_ASSOC)) {
	$this_group = 0;
	foreach($row as $k => $v) {
		$result[$k] = $v;
		if ($k == "GROUP_ID") {
			$this_group = $v;
		}
	}
	$perms[$this_group] = $result;
} // end while

$forum_list = "";
foreach($copy_to as $k => $forum_id) {
	$forum_list .= "$forum_id:";
	foreach($perms as $group_id => $perm_array) {
		$query = "
			select count(*)
			from {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
			where GROUP_ID = ?
			and FORUM_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($group_id,$forum_id),__LINE__,__FILE__);
		list ($check) = $dbh->fetch_array($sth);
		if (!$check) {
			// INSERT
			$keys = "";
			$holders = "";
			$values = array();
			$group = 0;
			foreach($perm_array as $perm => $value) {
				if ($perm == "FORUM_ID") {
					$value = $forum_id;
				}
				$keys .= "$perm, ";
				$holders .= "? , ";
				$values[] = $value;
			}

			$keys = preg_replace("/, $/","",$keys);
			$holders = preg_replace("/, $/","",$holders);
			$query = "
				insert into {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
				($keys)
				values
				($holders)
			";
			$dbh->do_placeholder_query($query,$values,__LINE__,__FILE__);
		} else {
			// UPDATE
			$inserts = "";
			$values = array();
			$group = 0;
			foreach($perm_array as $perm => $value) {
				if ($perm == "FORUM_ID") {
					$value = $forum_id;
				}
				$inserts .= "$perm = ?,";
				$values[] = $value;
			}

			$inserts = preg_replace("/,$/","",$inserts);
			$values[] = $group_id;
			$values[] = $forum_id;
			$query = "
				update {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
				set $inserts
				where GROUP_ID = ?
				and FORUM_ID = ?
			";
			$dbh->do_placeholder_query($query,$values,__LINE__,__FILE__);
		}
	}
}

admin_log("COPY_FORUM_PERMISSIONS","$copy_from => $forum_list");

$userob->clear_cached_perms();

$admin->redirect($ubbt_lang['PERMS_COPIED'],"{$config['BASE_URL']}/admin/forumperms.php?returntab=1",$ubbt_lang['FORUM_PERM_F_LOC']);

?>
