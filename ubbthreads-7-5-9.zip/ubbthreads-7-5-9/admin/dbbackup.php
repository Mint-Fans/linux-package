<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/database.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$returntab = get_input("returntab","both");


$tables = mysql_list_tables($config['DATABASE_NAME']);

if (!empty($config['dumpdir'])) {
	$backupdir = $config['dumpdir'];
}
else {
	$backupdir = "";
}


$tabs = array(
	"{$ubbt_lang['INFO']}" => "dbinfo.php?returntab=0",
	"{$ubbt_lang['COMMAND']}" => "database.php?returntab=1",
	"{$ubbt_lang['BACKUP']}" => ""
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['DATABASE']);
$admin->setPageTitle($ubbt_lang['BACKUP']);
$admin->setReturnTab($returntab);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
include("../templates/default/admin/dbbackup.tmpl");

$admin->sendFooter();
?>
