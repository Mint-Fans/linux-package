<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/deleteboard.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Get the input
$returntab = 0;
$forum = get_input("forum","get");

// Grab the title of this forum
$query = "
	SELECT FORUM_TITLE
	FROM {$config['TABLE_PREFIX']}FORUMS
	WHERE FORUM_ID = ?
";
$sth = $dbh->do_placeholder_query($query,array($forum),__LINE__,__FILE__);
list($title) = $dbh->fetch_array($sth);

$confirm = sprintf($ubbt_lang['CONFIRM'],$title);

$tabs = array(
	"{$ubbt_lang['DELETE_FORUM']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['FORUM_SET']);
$admin->setParentTitle($ubbt_lang['FORUM_SET'],"forummanage.php");
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['DELETE_FORUM']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
include("../templates/default/admin/deleteboard.tmpl");

$admin->sendFooter();
?>
