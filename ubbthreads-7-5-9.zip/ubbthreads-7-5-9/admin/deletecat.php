<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/deletecat.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Get the input
$returntab = 0;
$cat = get_input("cat","get");

// Grab the title of this forum
$query = "
	SELECT CATEGORY_TITLE
	FROM {$config['TABLE_PREFIX']}CATEGORIES
	WHERE CATEGORY_ID = ?
";
$sth = $dbh->do_placeholder_query($query,array($cat),__LINE__,__FILE__);
list($title) = $dbh->fetch_array($sth);

// Grab all of the categories
$query = "
	SELECT CATEGORY_TITLE,CATEGORY_ID
	FROM {$config['TABLE_PREFIX']}CATEGORIES
	WHERE CATEGORY_ID <> ?
	ORDER BY CATEGORY_SORT_ORDER
";
$sth = $dbh->do_placeholder_query($query,array($cat),__LINE__,__FILE__);
$catlist = "";
$cat_total = 0;
while(list($ct,$ce) = $dbh->fetch_array($sth)) {
	$catlist .= "<option value=\"$ce\">$ct</option>";
	$cat_total++;
}

if ($cat_total < 1) {
	$admin->redirect($ubbt_lang['CANT_DELETE_LAST_CAT'],"{$config['BASE_URL']}/admin/catmanage.php",$ubbt_lang['CAT_F_LOC']);
}

$confirm = sprintf($ubbt_lang['CONFIRM'],$title);

$tabs = array(
	"{$ubbt_lang['DELETE_CAT']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['CAT_SET']);
$admin->setParentTitle($ubbt_lang['CAT_SET'],"catmanage.php");
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['DELETE_CAT']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
include("../templates/default/admin/deletecat.tmpl");

$admin->sendFooter();
?>
