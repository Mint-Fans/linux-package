<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/do_subchange.php");

// Get the input
$returntab = get_input("returntab","both");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;
$admin->doAuth();
$html = new html;

$id = get_input("id","post","int");
$custom = get_input("custom","post","");
$status = get_input("status","post","");
$month = get_input("month","post","");
$day = get_input("day","post","");
$year = get_input("year","post","");


// Grab the current info on this subscription
$query = "
	select t1.USER_ID,t1.GROUP_ID,t2.SUBSCRIPTION_NAME
	from {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA as t1,
	{$config['TABLE_PREFIX']}SUBSCRIPTIONS as t2
	where t1.CUSTOM_ID = ?
	and t1.GROUP_ID = t2.GROUP_ID
";
$sth = $dbh->do_placeholder_query($query,array($custom),__LINE__,__FILE__);
list($uid,$group,$name) = $dbh->fetch_array($sth);

if ($status == "delete") {
	$query = "
		delete from {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA
		where CUSTOM_ID = ?
	";
	$dbh->do_placeholder_query($query,array($custom),__LINE__,__FILE__);

	$query = "
		delete from {$config['TABLE_PREFIX']}CHECK_DATA
		where CUSTOM_ID = ?
	";
	$dbh->do_placeholder_query($query,array($custom),__LINE__,__FILE__);

	// Remove User from Group
	$query = "
		delete from {$config['TABLE_PREFIX']}USER_GROUPS
		where USER_ID = ?
		and GROUP_ID = ?
	";
	$dbh->do_placeholder_query($query,array($uid,$group),__LINE__,__FILE__);

	// Send user a confirmation PM
	$message = $html->substitute($ubbt_lang['EXPIRE_BODY'],array('GROUP' => $name));

	$html->send_message($config['MAIN_ADMIN_ID'],$uid,$ubbt_lang['EXPIRE_SUB'],$message);

	// Log it
	admin_log("DELETE_SUB","$uid - $group");

}


if ($status == "activate") {

	// Add this user to the group
	$query = "
		replace into {$config['TABLE_PREFIX']}USER_GROUPS
		(USER_ID,GROUP_ID)
		values
		( ? , ? )
	";
	$dbh->do_placeholder_query($query,array($uid,$group),__LINE__,__FILE__);

	// Update the SUBSCRIPTION_DATA table
	$query = "
		update {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA
		set SUBSCRIPTION_STATUS = ? ,
			SUBSCRIPTION_IS_ACTIVE = 1
		where CUSTOM_ID = ?
	";
	$dbh->do_placeholder_query($query,array("MANUAL ACTIVATION",$custom),__LINE__,__FILE__);

	// Send user a confirmation PM
	$message = $html->substitute($ubbt_lang['ACTIVATE_BODY'],array('GROUP' => $name));

	$html->send_message($config['MAIN_ADMIN_ID'],$uid,$ubbt_lang['ACTIVATE_SUB'],$message);

	// Log it
	admin_log("ACTIVATE_SUB","$uid - $group");

}

if ($status == "expire") {

	// Remove User from Group
	$query = "
		delete from {$config['TABLE_PREFIX']}USER_GROUPS
		where USER_ID = ?
		and GROUP_ID = ?
	";
	$dbh->do_placeholder_query($query,array($uid,$group),__LINE__,__FILE__);

	// Update the SUBSCRIPTION_DATA table
	$query = "
		update {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA
		set SUBSCRIPTION_STATUS = ? ,
			SUBSCRIPTION_IS_ACTIVE = 0
		where CUSTOM_ID = ?
	";
	$dbh->do_placeholder_query($query,array("MANUAL EXPIRATION",$custom),__LINE__,__FILE__);

	// Send user a confirmation PM
	$message = $html->substitute($ubbt_lang['EXPIRE_BODY'],array('GROUP' => $name));

	$html->send_message($config['MAIN_ADMIN_ID'],$uid,$ubbt_lang['EXPIRE_SUB'],$message);


	// Log it
	admin_log("EXPIRE_SUB","$uid - $group");

}


// Modify End Date?
if ($day && $month && $year) {
	$newtime = strtotime("{$ubbt_lang['MONTH' . $month]} $day $year");

	// Update the SUBSCRIPTION_DATA table
	$query = "
		update {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA
		set SUBSCRIPTION_END_DATE = ?
		where CUSTOM_ID = ?
	";
	$dbh->do_placeholder_query($query,array($newtime,$custom),__LINE__,__FILE__);
}

$admin->redirect($ubbt_lang['SUB_MODIFIED'],"{$config['BASE_URL']}/admin/sub_history.php?id=$id",$ubbt_lang['USER_SUB_F_LOC']);


?>
