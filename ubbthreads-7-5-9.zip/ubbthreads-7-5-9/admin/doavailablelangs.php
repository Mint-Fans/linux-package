<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","post");
$default = get_input("default","post");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;


$admin->doAuth();

// -------------------------------------------------
// Grab all of the current languages in the database
$query = "
	SELECT LANGUAGE_TYPE,LANGUAGE_DESCRIPTION
	FROM {$config['TABLE_PREFIX']}LANGUAGES
";
$sth = $dbh -> do_query($query,__LINE__,__FILE__);
while (list($language,$description) = $dbh -> fetch_array($sth)) {
	$langarray[$language]['database'] = 1;
	$langarray[$language]['description'] = $description;
}

$dir = opendir("{$config['FULL_PATH']}/languages");
$i=0;
while ($file = readdir($dir)) {
	if ($file == "." || $file == ".." || $file == "README" || $file == "update" ) { continue; }
	$langs[$i] = $file;
	$i++;
}
sort ($langs);
closedir($dir);
$langsize = sizeof($langs);

// -----------------------
// Now update the database
for ( $i=0; $i<$langsize;$i++) {
	if (!isset($langarray[$langs[$i]]['database'])) {
		$dstring = "desc$langs[$i]";
		$descstring   = $_POST[$dstring];
		$astring = "active$langs[$i]";
		$active_string = $_POST[$astring];
		if (!$active_string) $active_string = 0;

		$query = "
			INSERT INTO {$config['TABLE_PREFIX']}LANGUAGES
			(LANGUAGE_TYPE,LANGUAGE_DESCRIPTION,LANGUAGE_IS_ACTIVE)
			VALUES
			( ? , ? , ? )
		";
		$dbh -> do_placeholder_query($query,array($langs[$i],$descstring,$active_string),__LINE__,__FILE__);
	}
	else {
		$dstring = "desc$langs[$i]";
		$astring = "active$langs[$i]";
		$activestring = get_input($astring,"post");
		$descstring   = get_input($dstring,"post");
		if (!$activestring) $activestring = 0;
		$query = "
			UPDATE {$config['TABLE_PREFIX']}LANGUAGES
			SET   LANGUAGE_DESCRIPTION = ? ,
			LANGUAGE_IS_ACTIVE = ?
			WHERE  LANGUAGE_TYPE = ?
		";
		$dbh -> do_placeholder_query($query,array($descstring,$activestring,$langs[$i]),__LINE__,__FILE__);
	}

}

$_POST['LANGUAGE'] = $default;

$newconfig = array("LANGUAGE");

// Update the config file
include("doeditconfig.php");

build_forum_cache();

$admin->redirect($ubbt_lang['LANGS_UPDATED'],"{$config['BASE_URL']}/admin/availablelangs.php?returntab=$returntab",$ubbt_lang['LANG_SET_F_LOC']);

?>
