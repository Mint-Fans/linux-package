<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/dochangegroupimage.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info
$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$returntab = get_input("returntab","post");
$group = get_input("group","post");

// -----------------------
// Get the uploaded images
if (!empty($_FILES['readpost']['name'])) {
	$readpost_name = $_FILES['readpost']['name'];
	$readpost_temp = $_FILES['readpost']['tmp_name'];

	$readpost_name = str_replace(" ","",$readpost_name);

	if (file_exists("{$config['FULL_PATH']}/images/groups/$readpost_name")) {
		@unlink($readpost_temp);
		$admin -> error("{$ubbt_lang['ICON_EXISTS']}");
	}

	$check = @move_uploaded_file($readpost_temp, "{$config['FULL_PATH']}/images/groups/$readpost_name");
	@chmod("{$config['FULL_PATH']}/images/groups/$readpost_name",0666);

	if (!$check) {
		$admin -> error("{$ubbt_lang['NO_MOVE']}");
	}
}

$query = "
	select GROUP_IMAGE
	from {$config['TABLE_PREFIX']}GROUPS
	where GROUP_ID = ?
";
$sth = $dbh->do_placeholder_query($query,array($group),__LINE__,__FILE__);
list($oldimage) = $dbh->fetch_array($sth);
if ($oldimage) {
	@unlink("{$config['FULL_PATH']}/images/groups/$oldimage");
}

if (!$readpost_name) $readpost_name = "";
$query = "
	update {$config['TABLE_PREFIX']}GROUPS
	set GROUP_IMAGE = ?
	where GROUP_ID = ?
";
$dbh->do_placeholder_query($query,array($readpost_name,$group),__LINE__,__FILE__);

$src = "<img src='{$config['BASE_URL']}/images/groups/$readpost_name'>";
// ---------------
// Log this action
admin_log("GROUP_IMAGE", $src);
$admin->redirect($ubbt_lang['G_ADDED'],"{$config['BASE_URL']}/admin/groupmanage.php?returntab=0",$ubbt_lang['G_PERM_F_LOC']);

?>
