<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$title = get_input("title","post");
$desc = get_input("desc","post");

// Get the max sort order
$query = "
	select max(CATEGORY_SORT_ORDER)
	from {$config['TABLE_PREFIX']}CATEGORIES
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
list($max_sort) = $dbh->fetch_array($sth);
if (!$max_sort) $max_sort = 0;


$query_vars = array($title,$desc,$max_sort + 1);
$query = "
	INSERT INTO {$config['TABLE_PREFIX']}CATEGORIES
	(CATEGORY_TITLE,CATEGORY_DESCRIPTION,CATEGORY_SORT_ORDER)
	VALUES
	( ? , ? , ? )
";
$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

build_forum_cache();
// ---------------
// Log this action
admin_log("ADD_CATEGORY", $title);

$admin->redirect($ubbt_lang['CAT_ADDED'],"{$config['BASE_URL']}/admin/catmanage.php",$ubbt_lang['CAT_F_LOC']);

?>
