<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// -------------
// Get the input
$returntab = get_input("returntab","post");
$isactive = get_input("isactive","post");
$Number = get_input("forum","post");
$Title = get_input("Title","post");
$Description = get_input("Description","post");
$Category = get_input("Category","post");
$ThreadAge = get_input("ThreadAge","post");
$header = get_input("header","post");
$style = get_input("style","post");
$CurrentCat = get_input("CurrentCat","post");
$avurl = get_input("avurl","post");
$subforum = get_input("subforum","post");
$oldparent = get_input("oldparent","post");
$headerfile = get_input("headerfile","post");
$footerfile = get_input("footerfile","post");
$island_insert = get_input("island_insert","post");
$feed_body = get_input("feed_body","post");
$feed_posts = get_input("feed_posts","post");
$feed_type = get_input("feed_type","post");
$feed_cache = get_input("feed_cache","post");
$feed_name = get_input("feed_name","post");
$rss = get_input("rss","post");
$forum_intro = get_input("forum_intro","post");
$intro_title = get_input("intro_title","post");
$intro_body = get_input("intro_body","post");
$is_teaser = get_input("is_teaser","post");
$is_gallery = get_input("is_gallery","post");
$posts_count = get_input("postscount","post") ? '1' : '0';
$sort_field = get_input("SORT_FIELD", "post");
$sort_dir = get_input("SORT_DIR", "post");

// Set some defaults
if (!$rss) $rss = 0;
if (!$feed_body) $feed_body = 0;
if (!$feed_posts) $feed_posts = 10;
if (!$feed_cache) $feed_cache = 1;
if (!$feed_name) $feed_name = "RSS Feed for $Title";
if (!$forum_intro) $forum_intro = 0;
if (!$is_gallery) $is_gallery = 0;
if (!$is_teaser) $is_teaser = 0;

$feed_cache = $feed_cache * 60;

$Description = escape_ampersand($Description);

// Lets see if the Parent is a category or a forum
if (preg_match("/^forum/",$Category)) {
	$forum_parent = preg_replace("/forum_/","",$Category);
	$query = "
		select CATEGORY_ID,FORUM_TITLE
		from {$config['TABLE_PREFIX']}FORUMS
		where FORUM_ID = '$forum_parent'
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	list($Category) = $dbh->fetch_array($sth);
} else {
	$Category = preg_replace("/category_/","",$Category);
	$forum_parent = '0';
}

// -------------------------------------------
// Grab the category name for the new category
$query = "
	SELECT CATEGORY_TITLE
	FROM   {$config['TABLE_PREFIX']}CATEGORIES
	WHERE  CATEGORY_ID = ?
";
$sth = $dbh -> do_placeholder_query($query,array($Category),__LINE__,__FILE__);
list ($CatName) = $dbh -> fetch_array($sth);
$Catnum = $Category;

$time = $html->get_date();

if (!$header) { $header = 0; }
if (!$island_insert) $island_insert = 0;
if (!$style) $style = 0;
if (!$gallery) $gallery = 0;
if (!$isactive) $isactive = 0;

// Grab just the imagefile of $avurl
if ($avurl) {
        $av_parts = explode("/",$avurl);
        $avurl = $av_parts[sizeof($av_parts)-1];
}

$Title = ubbchars($Title);

$query_vars = array($Title,$Description,$ThreadAge,$header,$style,$avurl,$isactive,$Catnum,0,0,$time,0,0,0,$forum_parent,$island_insert,$rss,$feed_name,$forum_intro,$intro_title,$is_teaser,$is_gallery,$posts_count,$sort_field,$sort_dir);
$query = "
	INSERT INTO {$config['TABLE_PREFIX']}FORUMS
	(FORUM_TITLE,FORUM_DESCRIPTION,FORUM_DEFAULT_TOPIC_AGE,FORUM_CUSTOM_HEADER,FORUM_STYLE,FORUM_IMAGE,FORUM_IS_ACTIVE,CATEGORY_ID,FORUM_POSTS,FORUM_TOPICS,FORUM_CREATED_ON,FORUM_LAST_POST_TIME,FORUM_LAST_POSTER_ID,FORUM_LAST_POST_ID,FORUM_PARENT,FORUM_ISLAND_INSERT,FORUM_IS_RSS,FORUM_RSS_TITLE,FORUM_SHOW_INTRO,FORUM_INTRO_TITLE,FORUM_IS_TEASER,FORUM_IS_GALLERY,FORUM_POSTS_COUNT,FORUM_SORT_FIELD,FORUM_SORT_DIR)
	VALUES
	( ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?)
";
$dbh -> do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

$query = "
	SELECT last_insert_id()
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
list($Number) = $dbh->fetch_array($sth);

// Insert RSS info
$query_vars = array($rss,$Number,$feed_name,0,$feed_type,$feed_body,$feed_posts,$feed_cache);
$query = "
	insert into {$config['TABLE_PREFIX']}RSS_FEEDS
	(FEED_IS_ACTIVE,FEED_FORUM,FEED_NAME,FEED_LAST_BUILD,FEED_TYPE,FEED_INCLUDE_BODY,FEED_ITEMS,FEED_CACHE_TIME)
	values
	( ? , ? , ? , ? , ? , ? , ? , ? )
";
$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

// Update the special header if necessary
if ($headerfile) {
	$check = lock_and_write("{$config['FULL_PATH']}/includes/header_$Number.php",$headerfile);
	if ($check == "no_write") {
		$admin->error($ubbt_lang['NO_WRITE_FHEADER']);
	}
}

if ($footerfile) {
	$check = lock_and_write("{$config['FULL_PATH']}/includes/footer_$Number.php",$footerfile);
	if ($check == "no_write") {
		$admin->error($ubbt_lang['NO_WRITE_FFOOTER']);
	}
}

// Update the forum intro if necessary
if ($intro_body) {
	$check = lock_and_write("{$config['FULL_PATH']}/includes/intro_$Number.php",$intro_body);
	if ($check == "no_write") {
		$admin->error(sprintf($ubbt_lang['NO_WRITE_FORUM_INTRO'],$Number));
	}
}

// If this is a gallery forum, create the directory structure
if ($is_gallery && !ini_get('safe_mode')) {
	mkdir("{$config['FULL_PATH']}/gallery/$Number",0777);
	chmod("{$config['FULL_PATH']}/gallery/$Number",0777);
	mkdir("{$config['FULL_PATH']}/gallery/$Number/full",0777);
	chmod("{$config['FULL_PATH']}/gallery/$Number/full",0777);
	mkdir("{$config['FULL_PATH']}/gallery/$Number/medium",0777);
	chmod("{$config['FULL_PATH']}/gallery/$Number/medium",0777);
	mkdir("{$config['FULL_PATH']}/gallery/$Number/thumbs",0777);
	chmod("{$config['FULL_PATH']}/gallery/$Number/thumbs",0777);
	lock_and_write("{$config['FULL_PATH']}/gallery/$Number/index.html"," ");
	chmod("{$config['FULL_PATH']}/gallery/$Number/index.html",0666);
	lock_and_write("{$config['FULL_PATH']}/gallery/$Number/full/index.html"," ");
	chmod("{$config['FULL_PATH']}/gallery/$Number/full/index.html",0666);
	lock_and_write("{$config['FULL_PATH']}/gallery/$Board/medium/index.html"," ");
	chmod("{$config['FULL_PATH']}/gallery/$Board/medium/index.html",0666);
	lock_and_write("{$config['FULL_PATH']}/gallery/$Board/thumb/index.html"," ");
	chmod("{$config['FULL_PATH']}/gallery/$Board/thumb/index.html",0666);
}

// Gotta do this now...
$dbh->do_query("truncate table {$config['TABLE_PREFIX']}CACHED_PERMISSIONS");

build_forum_cache();

// ---------------
// Log this action
admin_log("ADD_BOARD", $Title);
$admin->redirect($ubbt_lang['FORUM_ADDED'],"{$config['BASE_URL']}/admin/forumperms.php?edit_forum=$Number&amp;copy_forum=0",$ubbt_lang['F_ADDED_F_LOC']);

?>
