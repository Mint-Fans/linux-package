<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/docreategroup.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");


// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// get input
$name = get_input("name","post");

// Make sure the group name doesn't already exist
$query = "
	SELECT GROUP_NAME
	FROM {$config['TABLE_PREFIX']}GROUPS
	WHERE GROUP_NAME = ?
";
$sth = $dbh->do_placeholder_query($query,array($name),__LINE__,__FILE__);
list($check) = $dbh->fetch_array($sth);
if ($check) {
	$admin->error($ubbt_lang['DUP_GROUP']);
}

// See if we have a disabled group that we can use
$query = "
	SELECT GROUP_ID
	FROM {$config['TABLE_PREFIX']}GROUPS
	WHERE GROUP_IS_DISABLED = '1'
	LIMIT 1
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
list($gid) = $dbh->fetch_array($sth);
if ($gid) {
	$query = "
		UPDATE {$config['TABLE_PREFIX']}GROUPS
		SET GROUP_NAME = ? ,
		GROUP_IS_DISABLED='0'
		WHERE GROUP_ID = ?
	";
	$dbh->do_placeholder_query($query,array($name,$gid),__LINE__,__FILE__);
} else {

	// Add the group
	$query = "
		INSERT INTO {$config['TABLE_PREFIX']}GROUPS
		(GROUP_NAME,GROUP_IS_DISABLED)
		VALUES
		( ? ,'0')
	";
	$dbh->do_placeholder_query($query,array($name),__LINE__,__FILE__);
	// Get the group #
	$query = "
		SELECT last_insert_id()
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	list($gid) = $dbh->fetch_array($sth);
}

admin_log("ADD_GROUP",$name);

$admin->redirect($ubbt_lang['G_ADDED'],"{$config['BASE_URL']}/admin/groupmanage.php?returntab=0",$ubbt_lang['F_LOC']);

?>
