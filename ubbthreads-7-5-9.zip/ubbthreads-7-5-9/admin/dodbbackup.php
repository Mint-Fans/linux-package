<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/dodbbackup.php");

// -------------
// Get the input
$ctable = get_input("ctable","both");
$crow = get_input("crow","both");
$table = get_input("table","both");
$dumpdir = get_input("dumpdir","post");
$returntab = get_input("returntab","both");
$droptables = get_input("droptables","both");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

if (empty($config['dumpdir']) || !isset($config['dumpdir'])) {
	$config['dumpdir'] = "";
}
if ((!empty($dumpdir)) && ($dumpdir != $config['dumpdir'])) {
	// What config vars are we updating?
	$newconfig = array("dumpdir");

	// Update the config file
	include("doeditconfig.php");
	$admin->redirect($ubbt_lang['DUMPDIR'],"{$config['BASE_URL']}/admin/dbbackup.php?returntab=2",$ubbt_lang['F_LOC']);
	exit;
}

$tabs = array(
	"{$ubbt_lang['INFO']}" => "dbinfo.php?returntab=0",
	"{$ubbt_lang['COMMAND']}" => "database.php?returntab=1",
	"{$ubbt_lang['BACKUP']}" => ""
);

$tables = mysql_list_tables($config['DATABASE_NAME']);

$catch = 0;
$currtable = $ctable;


if ($ctable && !$crow && !$table) {
	while(list($gtable) = $dbh->fetch_array($tables)) {
		if ($catch == 1) {
			$ctable = $gtable;
			break;
		}
		if ($gtable == $ctable) {
			$catch = 1;
		}
	}
}

$end = 0;

if ( ($currtable == $ctable) && $ctable && !$crow) {
	$end = 1;
}

if (!$table && !$ctable) {
	while(list($gtable) = $dbh->fetch_array($tables)) {
		if (!$ctable) {
			$ctable = $gtable;
			$catch = 1;
			break;
		}
		if ($catch == 1) {
			$ctable = $gtable;
			break;
		}
		$catch = 1;
	}
}
if (!$ctable && $table) {
	$ctable = $table;
}

$backuptext = "";
$statustext = "";
$append = 1;
if (!$crow) {
	$dump_file = "{$config['dumpdir']}/$ctable.sql";
	$query = "
		SHOW CREATE TABLE $ctable
	";
	$sth = $dbh->do_query($query);
	list($result,$backuptext) = $dbh->fetch_array($sth);
	if ($droptables) {
		$backuptext = "DROP TABLE IF EXISTS $ctable;\n".$backuptext;
	}
	$backuptext .= ";\n\n";
	$append = 0;
}
else {
	$dump_file = "{$config['dumpdir']}/$ctable.sql";
}

$statustext .= "{$ubbt_lang['DATA']} $ctable<br />";
// Figure out what rows to grab
if (!$crow) { $crow = 0; }
$query = "
	SELECT * FROM $ctable
	LIMIT $crow,501
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$numFields = $dbh->num_fields($sth);
$x=1;
$more = 0;

while($vals=$dbh->fetch_array($sth)) {
	if ($x == '501') {
		$more = 1;
		break;
	}
	$backuptext .="INSERT INTO $ctable VALUES (";
	for ( $i=0; $i<$numFields; $i++) {
		$vals[$i] = addslashes($vals[$i]);
		$backuptext .= "'$vals[$i]',";
	}
	$backuptext = preg_replace("/,$/","",$backuptext);
	$backuptext .= ");\n";
	$x++;
}

if ($more) {
	$crow = $crow + 500;
}
else {
	if ($table) {
		$end = 1;
	}
	$crow = 0;
}
// Create the Page
$admin->setCurrentMenu($ubbt_lang['DATABASE']);
$admin->setPageTitle($ubbt_lang['BACKUP']);
$admin->setReturnTab($returntab);
if (!$end) {
	$admin->setRedirect("{$config['BASE_URL']}/admin/dodbbackup.php?returntab=2&crow=$crow&ctable=$ctable&table=$table&droptables=$droptables");
	$admin->setRedirectTime(2);
	$admin->sendHeader();
}
else {
	admin_log("DB_BACKUP","");
	$admin->setRedirect("{$config['BASE_URL']}/admin/dbbackup.php?returntab=2");
	$admin->setRedirectTime(5);
	$statustext .= $ubbt_lang['COMPLETE'];
	$statustext .= "<br /><br /><b>&raquo; <a href=\"{$config['BASE_URL']}/admin/dbbackup.php?returntab=2\">{$ubbt_lang['REDIR']}</a>";
	$admin->sendHeader();
}


$admin->createTopTabs($tabs,$returntab);

// Now grab the data
include("../templates/default/admin/dodbbackup.tmpl");

// Write out the file
$check = lock_and_write($dump_file,$backuptext,$append);


$admin->sendFooter();
?>
