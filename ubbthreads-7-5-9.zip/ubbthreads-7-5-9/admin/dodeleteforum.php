<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Get the input
$forum = get_input("forum","post");
$yesdelete = get_input("yesdelete","post");
$nodelete = get_input("nodelete","post");

if ($nodelete) {
	$admin->redirect($ubbt_lang['NO_FORUM_DELETED'],"{$config['BASE_URL']}/admin/viewboard.php?forum=$forum",$ubbt_lang['NO_FORUM_F_LOC']);
}
if ($yesdelete) {

	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}FORUMS
		WHERE FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($forum),__LINE__,__FILE__);

	$query = "
		delete from {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
		where FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($forum),__LINE__,__FILE__);

	$query = "
		select TOPIC_ID,TOPIC_HAS_FILE
		from {$config['TABLE_PREFIX']}TOPICS
		where FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($forum),__LINE__,__FILE__);
	while(list($tid,$has_file) = $dbh->fetch_array($sth)) {
		if ($has_file) {
			$query = "
				select t2.FILE_NAME,t2.FILE_DIR
				from {$config['TABLE_PREFIX']}POSTS as t1,
				{$config['TABLE_PREFIX']}FILES as t2
				where t1.TOPIC_ID = ?
				and t1.POST_HAS_FILE > 0
				and t1.POST_ID = t2.POST_ID
			";
			$stx = $dbh->do_placeholder_query($query,array($tid),__LINE__,__FILE__);
			while(list($filename,$dir) = $dbh->fetch_array($stx)) {
				if (!$dir) {
					unlink("{$config['ATTACHMENTS_PATH']}/$filename");
				} else {
					unlink("{$config['FULL_PATH']}/gallery/$dir/full/$filename");
					unlink("{$config['FULL_PATH']}/gallery/$dir/medium/$filename");
					unlink("{$config['FULL_PATH']}/gallery/$dir/thumbs/$filename");
				}
			} // end while
		}


		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}POSTS
			WHERE TOPIC_ID = ?
		";
		$dbh->do_placeholder_query($query,array($tid),__LINE__,__FILE__);
	}

	// Remove gallery directory if there is one
	unlink("{$config['FULL_PATH']}/gallery/$forum/full/index.html");
	unlink("{$config['FULL_PATH']}/gallery/$forum/medium/index.html");
	unlink("{$config['FULL_PATH']}/gallery/$forum/thumbs/index.html");
	unlink("{$config['FULL_PATH']}/gallery/$forum/index.html");
	rmdir("{$config['FULL_PATH']}/gallery/$forum/full");
	rmdir("{$config['FULL_PATH']}/gallery/$forum/medium");
	rmdir("{$config['FULL_PATH']}/gallery/$forum/thumbs");
	rmdir("{$config['FULL_PATH']}/gallery/$forum");


	$query = "
		select FORUM_TITLE
		from {$config['TABLE_PREFIX']}FORUMS
		where FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($forum),__LINE__,__FILE__);
	list($ftitle) = $dbh->fetch_array($sth);

	$query = "
		delete from {$config['TABLE_PREFIX']}TOPICS
		where FORUM_ID = ?
	";
	$dbh->do_placeholder_query($query,array($forum),__LINE__,__FILE__);

	$query = "
		DELETE FROM {$config['TABLE_PREFIX']}MODERATORS
		WHERE FORUM_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($forum),__LINE__,__FILE__);

	@unlink("{$config['FULL_PATH']}/includes/header_$forum.php");
	@unlink("{$config['FULL_PATH']}/includes/footer_$forum.php");
	@unlink("{$config['FULL_PATH']}/includes/intro_$forum.php");

	// Log this action
	admin_log("DELETE_BOARD", $ftitle);

	build_forum_cache();

	$admin->redirect($ubbt_lang['FORUM_DELETED'],"{$config['BASE_URL']}/admin/forummanage.php",$ubbt_lang['F_DELETED_F_LOC']);
}

?>
