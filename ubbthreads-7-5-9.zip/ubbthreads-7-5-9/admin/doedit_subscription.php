<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// -------------
// Get the input
$returntab = get_input("returntab","post");
$group = get_input("group","post");
$name = get_input("name","post");
$desc = get_input("desc","post");
$donation = get_input("donation","post") ? '1' : '0';
$donation_dollar = get_input("donation_dollar","post");
$donation_cent = get_input("donation_cent","post");
$trial = get_input("trial","post") ? '1' : '0';
$trial_dollar = get_input("trial_dollar","post");
$trial_cent = get_input("trial_cent","post");
$trial_period = get_input("trial_period","post");
$trial_interval = get_input("trial_interval","post");
$subscription = get_input("subscription","post") ? '1' : '0';
$sub_dollar = get_input("sub_dollar","post");
$sub_cent = get_input("sub_cent","post");
$sub_period = get_input("sub_period","post");
$sub_interval = get_input("sub_interval","post");
$recurring = get_input("recurring","post") ? '1' : '0';
$reattempt = get_input("reattempt","post") ? '1' : '0';

$donation_amount = "$donation_dollar.$donation_cent";
$trial_amount = "$trial_dollar.$trial_cent";
$sub_amount = "$sub_dollar.$sub_cent";

$query_vars = array($group,$name,$desc,$donation,$donation_amount,$trial,$trial_amount,$trial_period,$trial_interval,$subscription,$sub_amount,$sub_period,$sub_interval,$recurring,$reattempt);

$query = "
	replace into {$config['TABLE_PREFIX']}SUBSCRIPTIONS
	(GROUP_ID,SUBSCRIPTION_NAME,SUBSCRIPTION_DESCRIPTION,SUBSCRIPTION_BY_DONATION,SUBSCRIPTION_DONATION_AMOUNT,SUBSCRIPTION_BY_TRIAL,SUBSCRIPTION_TRIAL_AMOUNT,SUBSCRIPTION_TRIAL_DURATION,SUBSCRIPTION_TRIAL_INTERVAL,SUBSCRIPTION_BY_REGULAR,SUBSCRIPTION_REGULAR_AMOUNT,SUBSCRIPTION_REGULAR_DURATION,SUBSCRIPTION_REGULAR_INTERVAL,SUBSCRIPTION_IS_RECURRING,SUBSCRIPTION_REATTEMPT)
	values
	( ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? )
";
$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

// ---------------
// Log this action
admin_log("UPDATE_SUBSCRIPTION", $name);
$admin->redirect($ubbt_lang['SUB_UPDATED'],"{$config['BASE_URL']}/admin/subscriptions.php",$ubbt_lang['SUB_F_LOC']);

?>
