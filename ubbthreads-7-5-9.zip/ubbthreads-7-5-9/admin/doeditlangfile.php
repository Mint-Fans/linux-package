<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// -------------
// Get the input
$langfile = get_input("filename","post");
$langdir  = get_input("language","post");
$keyhigh = get_input("keyhigh","post");
$searchstring = get_input("searchstring","post");
$searchlangfile = get_input("searchlangfile","post");
$searchfilename = get_input("searchfilename","post");

$excluded = array("valid_post","returntab","language","filename","keyhigh","searchstring","searchfilename");
$fileprint = "<?php\n";
foreach ($_POST as $key => $value) {
	if (get_magic_quotes_gpc()) {
		$value = stripslashes($value);
	}

	// Exclude certain keys
	if ((in_array($key,$excluded)) || preg_match("/^(key|string)/",$key)) {
		continue;
	}
	$value = str_replace("\'","'",$value);
	$value = str_replace('\"','"',$value);
	$value = str_replace('"','\"',$value);
	$value = str_replace("\\$","\$",$value);

	$fileprint .= sprintf('$ubbt_lang[\'%s\'] = "%s";', $key, $value) . "\n";
}

	for ($i=0;$i<5;$i++) {
		$key = "key$i";
		$string = "string$i";
		if ($_POST[$key]) {
			$_POST[$string] = str_replace("\'","'",$_POST[$string]);
			if (get_magic_quotes_gpc) {
				$_POST[$string] = stripslashes($_POST[$string]);
			}
			$fileprint .= "\$ubbt_lang['$_POST[$key]'] = \"$_POST[$string]\";\n";
		}
	}
$fileprint .= "?". ">";

$check = lock_and_write("{$config['FULL_PATH']}/languages/$langdir/$langfile",$fileprint);
if ($check == "no_write") {
	$admin->error("{$config['FULL_PATH']}/languages/$langdir/$langfile " .$ubbt_lang['NO_WRITE_LANG']);
}

rebuild_islands();

// ---------------
// Log this action
admin_log("EDIT_LANG_FILE", "$langdir/$langfile");
if ($searchfilename) {
	$langfile = "";
	$text = $ubbt_lang['LANG2_F_LOC'];
} else {
	$text = $ubbt_lang['LANG_F_LOC'];
}
$admin->redirect($ubbt_lang['LANG_FILE_UPDATED'],"{$config['BASE_URL']}/admin/languageeditor.php?filename=$langfile&searchstring=$searchstring&searchfilename=$searchfilename&language=$langdir",$text);

?>
