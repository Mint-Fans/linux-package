<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/editwrapper.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = 0;
$wrapper = get_input("wrapper","post");
$name = get_input("name","post");
$open = get_input("open","post");
$close = get_input("close","post");


// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

include("{$config['FULL_PATH']}/styles/wrappers.php");

if (isset($wrappers[$wrapper])) {
	$wrappers[$wrapper] = array(
		"name" => $name,
		"open" => $open,
		"close" => $close,
	);
} else {
	$wrappers[] = array(
		"name" => $name,
		"open" => $open,
		"close" => $close,
	);
}

$wrapper_file = "<?php\n\$wrappers = " . var_export($wrappers,true) . "?>\n";


$check = lock_and_write("{$config['FULL_PATH']}/styles/wrappers.php",$wrapper_file);
if ($check == "no_write") {
	$admin->error($ubbt_lang['NO_WRITE_WRAPPERS']);
}


admin_log("EDIT_WRAPPER",$name);
$admin->redirect($ubbt_lang['WRAPPER_UPDATED'],"{$config['BASE_URL']}/admin/wrappers.php?returntab=1",$ubbt_lang['WRAPPER_F_LOC']);

?>
