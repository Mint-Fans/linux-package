<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","post");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate();

$admin = new Admin;
$admin->doAuth();

$atPath = get_input("ATTACHMENTS_PATH","post");

if ($atPath && $atPath == $config['UPLOADED_AVATAR_PATH']) {
    $admin->error($ubbt_lang['DUP_PATH']);
      exit;
}


$ACTIVE_TEXT_LIST = $_POST['ACTIVE_TEXT_LIST'];

if (get_magic_quotes_gpc()) {
	$ACTIVE_TEXT_LIST = stripslashes($ACTIVE_TEXT_LIST);
}

$active_array = preg_split("/(\r\n|\n)/",$ACTIVE_TEXT_LIST);

$ACTIVE_TEXT_LIST = array();
foreach($active_array as $line => $value) {
	if (!$value) continue;
	list($target,$replace) = preg_split("#\|#",$value);
	$target = trim($target);
	$replace = trim($replace);
	$replace = str_replace('\"',"",$replace);
	$ACTIVE_TEXT_LIST[$target] = $replace;
}

$markup_fonts = array();
$font_list = preg_split("/(\r\n|\n)/",$_POST['MARKUP_FONTS']);
foreach($font_list as $line => $font) {
	$font = trim($font);
	if (!$font) continue;
	$markup_fonts[] = $font;
}

$markup_sizes = array();
$size_list = preg_split("/(\r\n|\n)/",$_POST['MARKUP_FONT_SIZES']);
foreach($size_list as $line => $size) {
	$size = trim($size);
	if (!$size) continue;
	$markup_sizes[] = $size;
}

$_POST['ACTIVE_TEXT_LIST'] = $ACTIVE_TEXT_LIST;
$_POST['MARKUP_FONTS'] = $markup_fonts;
$_POST['MARKUP_FONT_SIZES'] = $markup_sizes;

// What config vars are we updating?
$newconfig = array("DISPLAY_NAME_CHANGE","MARKUP_HTML_TOGGLE","USER_RATINGS","TOPIC_RATINGS","ALLOW_IMAGE_MARKUP","ATTACHMENTS_PATH","ATTACHMENTS_URL","ATTACHMENT_TYPES","ENABLE_ACTIVE_TEXT","MIN_SEARCH_LENGTH","MAX_SEARCH_RESULTS","MAX_SEARCH_RANGE_VALUE","MAX_SEARCH_RANGE_TYPE","ACTIVE_TEXT_LIST","MARKUP_FONTS","MARKUP_FONT_SIZES","ENABLE_MOODS","BIRTHDAY_NOTICE","MAX_WIDTH_IMAGE","SEARCH_METHOD","CALENDAR","COMMENTS","COMMENTS_MIN_POST");

// Update the config file
include("doeditconfig.php");

admin_log("UPDATE_FEATURES",$log_diffs);

$admin->redirect($ubbt_lang['FEATURES_UPDATED'],"{$config['BASE_URL']}/admin/features.php?returntab=$returntab",$ubbt_lang['FEATURES_F_LOC']);

?>
