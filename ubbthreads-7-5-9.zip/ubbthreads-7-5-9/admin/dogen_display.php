<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","post");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();


$topic_disp = get_input("topic_disp","post");
if ($topic_disp == "threaded") {
	$_POST['TOPIC_DISPLAY_STYLE'] = "threaded";
}
else {
	$_POST['TOPIC_DISPLAY_STYLE'] = "flat";
}

if ($_POST['TOPIC_DISPLAY_OPTIONS'] == "flat") {
	$_POST['TOPIC_DISPLAY_STYLE'] = "flat";
}
if ($_POST['TOPIC_DISPLAY_OPTIONS'] == "threaded") {
	$_POST['TOPIC_DISPLAY_STYLE'] = "threaded";
}


$time_formats = $_POST['TIME_FORMATS'];

$formats_array = preg_split("/(\r\n|\n)/",$time_formats);

$TIME_FORMATS= array();
foreach($formats_array as $line => $value) {
	if (!$value) continue;
	$value = trim($value);
	$TIME_FORMATS[] = $value;
}
$_POST['TIME_FORMATS'] = $TIME_FORMATS;

// What config vars are we updating?
$newconfig = array("HOMEPAGE_URL","HOMEPAGE_TITLE","SITE_EMAIL_TITLE","PRIVACY_STATEMENT","ONLINE_TIME","AGE_WITH_BIRTHDAYS",
									 "BIRTHDAYS_IN_CALENDAR","LIST_MODERATORS","HOT_VIEWS","HOT_REPLIES","SUBJECT_LENGTH",
									 "SERVER_TIME_OFFSET","ENABLE_QUICK_REPLY","CONTACT_LINK_TYPE","CONTACT_URL","PRIVACY_URL",
									 "TOPIC_DISPLAY_OPTIONS","TABLE_WIDTH","TOPICS_PER_PAGE","POSTS_PER_PAGE","SHOW_AVATARS","TOPIC_DISPLAY_STYLE",
									 "TEXT_AREA_COLUMNS","TEXT_AREA_ROWS","TIME_FORMAT","INLINE_IMAGE","BODY_ONLOAD","COMMUNITY_INTRO","COMMUNITY_INTRO_TITLE",
									 "TIME_FORMATS","NEW_COUNT","NEW_REPLIES","RELATIVE_TIME","POST_LAYOUT","DISABLE_ONLINE_INVISIBLE",
									 "CALENDAR_START_DAY","IMAGE_LIMIT","ENABLE_POST_COUNTS","CATEGORY_ONLY_MODE","SHOW_TEASER_LATEST_POST",
									 "TOOLTIP_LENGTH","HOPTO_WIDTH","POST_CAPTCHA","SHOW_ALL_GRAEMLINS","NESTED_QUOTES","FACEBOOK","TWITTER","YOUR_TWITTER",
									 "SHAREAHOLIC");

// Update the config file
include("doeditconfig.php");

// Update the privacy text if necessary
// Update the board rules file if necessary
$oldprivacy = "";
$privacyfile = file("{$config['FULL_PATH']}/includes/privacy.php");
while (list($linenum,$line) = each($privacyfile)) {
	    $oldprivacy .= "$line";
}
$privacy_text = get_input("privacy_text","post");
if ($privacy_text != $oldprivacy) {
	$check = lock_and_write("{$config['FULL_PATH']}/includes/privacy.php",$privacy_text);
	if ($check == "no_write") {
		$admin->error($ubbt_lang['NO_WRITE_PRIVACY']);
	}
}

// Update community intro if necessary
$oldintro = @file_get_contents("{$config['FULL_PATH']}/includes/community_intro.php");

$intro_text = get_input("intro_body","post");
if ($intro_text != $oldintro) {
	$check = lock_and_write("{$config['FULL_PATH']}/includes/community_intro.php",$intro_text);
	if ($check == "no_write") {
		$admin->error($ubbt_lang['NO_WRITE_INTRO']);
	}
}

// Update the header file if necessary
$oldfile = "";
$fd = file("{$config['FULL_PATH']}/includes/header.php");
while (list($linenum,$line) = each($fd)) {
	$oldfile .= "$line";
}
$headerfile = get_input("headerfile","post");
if ($headerfile!= $oldfile) {

	$check = lock_and_write("{$config['FULL_PATH']}/includes/header.php",$headerfile);
	if ($check == "no_write") {
		$admin->error($ubbt_lang['NO_WRITE_HEADER']);
	}
}

// Update the footer file if necessary
$oldfile = "";
$fd = file("{$config['FULL_PATH']}/includes/footer.php");
while (list($linenum,$line) = each($fd)) {
	$oldfile .= "$line";
}
$footerfile = get_input("footerfile","post");
if ($footerfile!= $oldfile) {
	$check = lock_and_write("{$config['FULL_PATH']}/includes/footer.php",$footerfile);
	if ($check == "no_write") {
		$admin->error($ubbt_lang['NO_WRITE_FOOTER']);
	}
}

// Update the common insert file if necessary
$oldfile = "";
$fd = file("{$config['FULL_PATH']}/includes/header-insert.php");
while (list($linenum,$line) = each($fd)) {
	$oldfile .= "$line";
}
$insertfile = get_input("insertfile","post");
if ($insertfile!= $oldfile) {
	$check = lock_and_write("{$config['FULL_PATH']}/includes/header-insert.php",$insertfile);
	if ($check == "no_write") {
		$admin->error($ubbt_lang['NO_WRITE_INSERT']);
	}
}
// Update the insert file if necessary
$oldfile = "";
$fd = file("{$config['FULL_PATH']}/includes/header-insert-descrip.php");
while (list($linenum,$line) = each($fd)) {
	$oldfile .= "$line";
}
$descripinsertfile = get_input("descripinsertfile","post");
if ($descripinsertfile!= $oldfile) {
	$check = lock_and_write("{$config['FULL_PATH']}/includes/header-insert-descrip.php",$descripinsertfile);
	if ($check == "no_write") {
		$admin->error($ubbt_lang['NO_WRITE_INSERT']);
	}
}
// Update the shareaholic file if necessary
$oldfile = "";
$fd = file("{$config['FULL_PATH']}/includes/header-shareaholic.php");
while (list($linenum,$line) = each($fd)) {
	$oldfile .= "$line";
}
$shareaholicfile = get_input("shareaholicfile","post");
if ($shareaholicfile!= $oldfile) {
	$check = lock_and_write("{$config['FULL_PATH']}/includes/header-shareaholic.php",$shareaholicfile);
	if ($check == "no_write") {
		$admin->error($ubbt_lang['NO_WRITE_INSERT']);
	}
}

$search_agents = get_input("search_agents","post");
$query = "
	update {$config['TABLE_PREFIX']}SEARCH_AGENTS
	set AGENTS = ?
";
$dbh->do_placeholder_query($query,array($search_agents),__LINE__,__FILE__);

$spiders =& get_spider_list(true);

admin_log("UPDATE_DISPLAY","$log_diffs");


$admin->redirect($ubbt_lang['DISPLAY_UPDATED'],"{$config['BASE_URL']}/admin/gen_display.php?returntab=$returntab",$ubbt_lang['DISPLAY_F_LOC']);

?>
