<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/dogroupmanage.php");

// Large boards may take awhile to delete groups.
@set_time_limit(0);

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$delete = get_input("delete","post");
$name = get_input("name","post");
$post = get_input("post","post");

// Let's check to make sure nobody is in a group that is going to be deleted
// We need the total # in this group
// And the total # that are in another group as well
if (sizeof($delete)) {
	foreach($delete as $k => $v) {

		// Make sure this isn't the default group
		if (in_array($k,$config['DEFAULT_USER_GROUPS'])) {
			$query = "
				select GROUP_NAME
				from {$config['TABLE_PREFIX']}GROUPS
				where GROUP_ID = ?
			";
			$sth = $dbh->do_placeholder_query($query,array($k),__LINE__,__FILE__);
			list ($gname) = $dbh->fetch_array($sth);
			$admin->error($html->substitute($ubbt_lang['DEFAULT_GROUP'],array('GROUP' => $gname)));
		}

		// How many users are in this group and another group
    $query = "
        select COUNT(USER_ID)
        from {$config['TABLE_PREFIX']}USER_GROUPS
        where GROUP_ID = ?
        and USER_ID IN
        (select distinct USER_ID
        from {$config['TABLE_PREFIX']}USER_GROUPS
        where GROUP_ID <> ?)
    ";
    $sth = $dbh->do_placeholder_query($query,array($k,$k),__LINE__,__FILE__);
    list($in_other) = $dbh->fetch_array($sth);

		// How many users are in this group
		$query = "
			select count(*)
			from {$config['TABLE_PREFIX']}USER_GROUPS
			where GROUP_ID = ?
		";
		$sth = $dbh->do_placeholder_query($query,array($k),__LINE__,__FILE__);
		list ($in_group) = $dbh->fetch_array($sth);

		$total = $in_group - $in_other; // Hopefully this is 0

		if ($total > 0) {

			$query = "
				select GROUP_NAME
				from {$config['TABLE_PREFIX']}GROUPS
				where GROUP_ID = ?
			";
			$sth = $dbh->do_placeholder_query($query,array($k),__LINE__,__FILE__);
			list ($gname) = $dbh->fetch_array($sth);
			$admin->error($html->substitute($ubbt_lang['NODELETE'],array('TOTAL' => $total, 'GROUP' => $gname)));
		}

	}
}

// Grab all current groups
$query = "
	SELECT GROUP_ID,GROUP_NAME,GROUP_POST_COUNT_JOIN
	FROM {$config['TABLE_PREFIX']}GROUPS
	WHERE (GROUP_ID > '5' OR GROUP_ID='4')
	AND GROUP_IS_DISABLED <> '1'
	ORDER BY GROUP_ID
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while(list($gid,$gname,$gpost) = $dbh->fetch_array($sth)) {
	if (isset($delete[$gid])) {
		// Disable group
		$query = "
			UPDATE {$config['TABLE_PREFIX']}GROUPS
			SET GROUP_IS_DISABLED='1',
			GROUP_POST_COUNT_JOIN = '0',
			GROUP_NAME=''
			WHERE GROUP_ID = ?
		";
		$dbh->do_placeholder_query($query,array($gid),__LINE__,__FILE__);

		// Delete from forum access list
		$query = "
			delete from {$config['TABLE_PREFIX']}FORUM_PERMISSIONS
			where GROUP_ID = ?
		";
		$dbh->do_placeholder_query($query,array($gid),__LINE__,__FILE__);

		// Delete from site access list
		$query = "
			delete from {$config['TABLE_PREFIX']}SITE_PERMISSIONS
			where GROUP_ID = ?
		";
		$dbh->do_placeholder_query($query,array($gid),__LINE__,__FILE__);

		// Delete from cp access list
		$query = "
			delete from {$config['TABLE_PREFIX']}CP_PERMISSIONS
			where GROUP_ID = ?
		";
		$dbh->do_placeholder_query($query,array($gid),__LINE__,__FILE__);

		// Delete from user's groups
		$query = "
			delete from {$config['TABLE_PREFIX']}USER_GROUPS
			where GROUP_ID = ?
		";
		$dbh->do_placeholder_query($query,array($gid),__LINE__,__FILE__);
	}
	if ($gname != $name[$gid] || $gpost != $post[$gid]) {
		if ($gid == 4) $name[$gid] = "Users";
		$query = "
			UPDATE {$config['TABLE_PREFIX']}GROUPS
			SET GROUP_NAME = ?,
			GROUP_POST_COUNT_JOIN = ?
			WHERE GROUP_ID = ?
		";
		$dbh->do_placeholder_query($query,array($name[$gid],$post[$gid],$gid),__LINE__,__FILE__);
	}

}

admin_log("GROUP_MAMAGE","");

$admin->redirect($ubbt_lang['G_SET_UPDATED'],"{$config['BASE_URL']}/admin/groupmanage.php?returntab=0",$ubbt_lang['G_PERM_F_LOC']);

?>
