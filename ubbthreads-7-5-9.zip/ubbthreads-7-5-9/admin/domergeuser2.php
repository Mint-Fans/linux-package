<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/domergeuser.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Get the input
$uid = get_input("uid","post","int");
$merge_uid = get_input("merge_uid","post","int");
$wrong = get_input("wrong","post");

if ($wrong) {
	header("Location: {$config['FULL_URL']}/admin/mergeuser.php?uid=$uid");
	exit;
}
$query = "
	select t1.USER_DISPLAY_NAME,USER_TOTAL_POSTS
	from {$config['TABLE_PREFIX']}USERS as t1,
	{$config['TABLE_PREFIX']}USER_PROFILE as t2
	where t1.USER_ID = ?
	and t1.USER_ID = t2.USER_ID
";
$sth = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
list($display_name,$total_posts) = $dbh->fetch_array($sth);

$query = "
	select USER_DISPLAY_NAME
	from {$config['TABLE_PREFIX']}USERS
	where USER_ID = ?
";
$sth = $dbh->do_placeholder_query($query,array($merge_uid),__LINE__,__FILE__);
list($t_display_name) = $dbh->fetch_array($sth);

$query = "
	update {$config['TABLE_PREFIX']}USER_PROFILE
	set USER_TOTAL_POSTS = USER_TOTAL_POSTS + $total_posts
	where USER_ID = ?
";
$dbh->do_placeholder_query($query,array($merge_uid),__LINE__,__FILE__);



$query = "
	update {$config['TABLE_PREFIX']}TOPICS
	set USER_ID = ?
	where USER_ID = ?
";
$dbh->do_placeholder_query($query,array($merge_uid,$uid),__LINE__,__FILE__);

$query = "
	update {$config['TABLE_PREFIX']}POSTS
	set USER_ID = ?
	where USER_ID = ?
";
$dbh->do_placeholder_query($query,array($merge_uid,$uid),__LINE__,__FILE__);

$query = "
	update {$config['TABLE_PREFIX']}FILES
	set USER_ID = ?
	where USER_ID = ?
";
$dbh->do_placeholder_query($query,array($merge_uid,$uid),__LINE__,__FILE__);

$query = "
	update {$config['TABLE_PREFIX']}POLL_DATA
	set USER_ID = ?
	where USER_ID = ?
";
$dbh->do_placeholder_query($query,array($merge_uid,$uid),__LINE__,__FILE__);


$query = "
	update {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS
	set USER_ID = ?
	where USER_ID = ?
";
$dbh->do_placeholder_query($query,array($merge_uid,$uid),__LINE__,__FILE__);


$query = "
	update {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
	set USER_ID = ?
	where USER_ID = ?
";
$dbh->do_placeholder_query($query,array($merge_uid,$uid),__LINE__,__FILE__);

$query = "
	update {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
	set USER_ID = ?
	where USER_ID = ?
";
$dbh->do_placeholder_query($query,array($merge_uid,$uid),__LINE__,__FILE__);

$query = "
	update {$config['TABLE_PREFIX']}SHOUT_BOX
	set USER_ID = ?
	where USER_ID = ?
";
$dbh->do_placeholder_query($query,array($merge_uid,$uid),__LINE__,__FILE__);


$query = "
	delete from {$config['TABLE_PREFIX']}USERS
	where USER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);

$query = "
	delete from {$config['TABLE_PREFIX']}USER_PROFILE
	where USER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);

$query = "
	delete from {$config['TABLE_PREFIX']}USER_DATA
	where USER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);

$query = "
	delete from {$config['TABLE_PREFIX']}USER_GROUPS
	where USER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);

$query = "
	delete from {$config['TABLE_PREFIX']}FORUM_LAST_VISIT
	where USER_ID = ?
";
$dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);


// Log this action
admin_log("MERGEUSER", "$display_name:$uid -> $t_display_name:$merge_uid");

rebuild_islands();

$admin->redirect(sprintf($ubbt_lang['USER_MERGED'],"$display_name ($uid)","$t_display_name ($merge_uid)"),"{$config['BASE_URL']}/admin/membermanage.php",$ubbt_lang['MEM_MAN']);
?>
