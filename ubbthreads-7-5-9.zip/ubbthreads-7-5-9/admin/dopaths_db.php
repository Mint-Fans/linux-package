<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","post");

// -----------------
// Get the user info

$userob = new user;
$user = $userob->authenticate();

$admin = new Admin;
$admin->doAuth();


// What config vars are we updating?
$newconfig = array("DATABASE_SERVER","DATABASE_NAME","DATABASE_USER","DATABASE_PASSWORD","PERSISTENT_DB_CONNECTION","FULL_URL","BASE_URL","FULL_PATH","CONVERT_PATH","MOGRIFY_PATH");

// Update the config file
include("doeditconfig.php");

admin_log("PATHS_DB","$log_diffs");

$admin->redirect($ubbt_lang['SET_UPDATED'],"{$config['BASE_URL']}/admin/paths_db.php?returntab=$returntab",$ubbt_lang['DB_F_LOC']);

?>