<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","post");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// What config vars are we updating?
$newconfig = array("MAIN_ADMIN_ID","COMMUNITY_TITLE","BOARD_IS_CLOSED","DISABLE_REFERER_CHECK","ZLIB_COMPRESSION","COOKIE_PATH","COOKIE_PREFIX","COOKIE_LIFETIME","LOG_SQL_ERRORS","SQL_LOG_PATH","DO_CENSOR","REPLACE_WORD","SEARCH_FRIENDLY_URLS","SITE_EMAIL","ALLOW_DEBUGGING","REFERERS","SMTP","SEARCH_FRIENDLY_HTML_EXT","MULTI_URL","LOG_REFERS","NOFOLLOW_POST","NOFOLLOW_SIG","SFS_ENABLE","SFS_LEVEL","SFS_KEY","BOARD_KEY");

include("./doeditconfig.php");

// Update the board rules file if necessary
$oldclosed = "";
$closedfile = file("{$config['FULL_PATH']}/includes/closedforums.php");
while (list($linenum,$line) = each($closedfile)) {
	$oldclosed .= "$line";
}
$closedmessage = get_input("closedmessage","post");
if ($closedmessage != $oldclosed) {

	$check = lock_and_write("{$config['FULL_PATH']}/includes/closedforums.php",$closedmessage);
	if ($check == "no_write") {
		$admin->error($ubbt_lang['NO_WRITE_CLOSED']);
	}
}

// Get current censor list
$badwords = get_input("censorwords","post");
$query = "
SELECT CENSOR_WORD,CENSOR_REPLACE_WITH
FROM {$config['TABLE_PREFIX']}CENSOR_LIST
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$currwords = array();
while(list($word,$replace) = $dbh->fetch_array($sth)) {
	if ($replace) {
		$currwords[] = "$word=$replace";
	}
	else {
		$currwords[] = $word;
	}
}
$badwords = preg_replace("/ +/","",$badwords);
$badwords = str_replace("\r","",$badwords);
$newwords = preg_split("#\n#",$badwords);

// Update the IP List
for($i=0;$i<sizeof($newwords);$i++) {
	if (!in_array($newwords[$i],$currwords)) {
		@list($word,$replace) = @preg_split("#=#",$newwords[$i]);
		$word_q = addslashes($word);
		$replace_q = addslashes($replace);
		if ($word_q) {
			$query = "
				INSERT INTO {$config['TABLE_PREFIX']}CENSOR_LIST
				VALUES
				('$word_q','$replace_q')
			";
			$dbh->do_query($query,__LINE__,__FILE__);
		}
	}
}

for($i=0;$i<sizeof($currwords);$i++) {
	if (!in_array($currwords[$i],$newwords)) {
		@list($word,$replace) = @preg_split("#=#",$currwords[$i]);
		$word_q = addslashes($word);
		$replace_q = addslashes($replace);
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}CENSOR_LIST
			WHERE  CENSOR_WORD='$word_q'
			AND CENSOR_REPLACE_WITH='$replace_q'
		";
		$dbh->do_query($query,__LINE__,__FILE__);
	}
}

admin_log("PRIMARY_SETTINGS",$log_diffs);

$admin->redirect($ubbt_lang['SET_UPDATED'],"{$config['BASE_URL']}/admin/primary.php?returntab=$returntab",$ubbt_lang['PRIMARY_F_LOC']);

?>
