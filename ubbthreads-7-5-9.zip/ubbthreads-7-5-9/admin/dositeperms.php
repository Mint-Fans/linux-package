<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// Get the list of site permissions
$perms = array();
$query = "
	select PERMISSION_NAME
	from {$config['TABLE_PREFIX']}PERMISSION_LIST
	where PERMISSION_TYPE='site'
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while(list($name) = $dbh->fetch_array($sth)) {
	$perms[] = $name;
} // end while

// Get list of groups
$query = "
	select GROUP_ID
	from {$config['TABLE_PREFIX']}GROUPS
	order by GROUP_ID
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while(list($gid) = $dbh->fetch_array($sth)) {
	$groups[] = $gid;
}

foreach($groups as $k => $gid) {
	$keys = "GROUP_ID,";
	$values = "$gid,";
	foreach($perms as $k => $perm) {
		$keys .= "$perm,";
	}
	foreach($perms as $k => $perm) {
		$value = $_POST[$perm][$gid];
		if (!$value) $value = "0";
		$value = addslashes($value);
		$values .= "'$value',";
	}
	$keys = preg_replace("/,$/","",$keys);
	$values = preg_replace("/,$/","",$values);

	$query = "
		replace into {$config['TABLE_PREFIX']}SITE_PERMISSIONS
		($keys)
		values
		($values)
	";
	$dbh->do_query($query,__LINE__,__FILE__);

}
admin_log("SITE_PERMISSIONS","");

$userob->clear_cached_perms();

$admin->redirect($ubbt_lang['SITE_PERM_UPDATED'],"{$config['BASE_URL']}/admin/siteperms.php?returntab=0",$ubbt_lang['SITE_PERM_F_LOC']);

?>
