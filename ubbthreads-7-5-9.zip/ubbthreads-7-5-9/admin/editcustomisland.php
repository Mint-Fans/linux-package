<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/editcustomisland.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
error_reporting(7);

// -------------
// Get the input
$returntab = get_input("returntab","get");
$island = get_input("island","get");
$num = get_input("num","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("");

$admin = new Admin;

$admin->doAuth();

$query = "
	select 	PORTAL_ID,PORTAL_NAME,PORTAL_BODY,PORTAL_CACHE
	from	{$config['TABLE_PREFIX']}PORTAL_BOXES
	where PORTAL_ID = '$island'
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
list($portal_id,$portal_name,$portal_body,$portal_cache) = $dbh->fetch_array($sth);

if ($portal_cache) {
	$portal_cache = $portal_cache / 60;
}

if (!$portal_name) {
	$query = "
		select count(*)
		from {$config['TABLE_PREFIX']}PORTAL_BOXES
		where PORTAL_CUSTOM = '1'
		and PORTAL_ID < '$island'
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	list ($count) = $dbh->fetch_array($sth);
	$portal_name = "{$ubbt_lang['CUSTOM_BOX']} $count";
}

$portal_name = ubbchars($portal_name);


$boxfd = file("{$config['FULL_PATH']}/cache_builders/custom/portal_box_$portal_id.php");
$portal_body = "";
$eof_found = false;
while (list($linenum,$line) = each($boxfd)) {
	$line = rtrim($line);
	if ($line == "<?php") continue;
	if ($line == "?>" && $eof_found) continue;
	if ($line == "EOF;") $eof_found = true;
	$line = ubbchars($line);
	$portal_body .= "$line\n";
}

$portal_body = trim($portal_body);


if (!$portal_cache) {
	$portal_cache = '0';
}

if (!$portal_body) {
	$portal_body = $ubbt_lang['EXAMPLE'];
}

$always_build = "";
if (in_array("portal_box_{$portal_id}",$config['BUILD_ISLANDS'])) {
	$always_build = "checked=\"checked\"";
}

$tabs = array(
	"{$ubbt_lang['TAB_TITLE']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['CUSTOM_ISLANDS']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['TAB_TITLE']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);


// Include the template
include("../templates/default/admin/editcustomisland.tmpl");

//$admin->createBottomTabs($bottomtabs,0);

$admin->sendFooter();
?>
