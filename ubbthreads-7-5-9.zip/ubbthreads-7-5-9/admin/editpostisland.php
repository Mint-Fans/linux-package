<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/editpostisland.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
error_reporting(7);

// -------------
// Get the input
$returntab = get_input("returntab","get");
$island = get_input("island","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("");

$admin = new Admin;

$admin->doAuth();

$tabs = array(
	"{$ubbt_lang['TAB_TITLE']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['POST_ISLANDS']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['TAB_TITLE']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

$query = "
	select 	PORTAL_ID,PORTAL_NAME,PORTAL_POST_TYPE,PORTAL_FORUMS,PORTAL_CACHE,PORTAL_ITEMS
	from		{$config['TABLE_PREFIX']}PORTAL_BOXES
	where PORTAL_ID = '$island'
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
list($portal_id,$portal_name,$portal_type,$portal_forums,$portal_cache,$items) = $dbh->fetch_array($sth);

$posts = "";
$topics = "";
if ($portal_type == "posts") {
	$posts = "selected=\"selected\"";
} else {
	$topics = "selected=\"selected\"";
}

if ($portal_cache) {
	$portal_cache = $portal_cache / 60;
} else {
	$portal_cache = 5;
}

if (!$items) {
	$items = 5;
}

$always_build = "";
if (in_array("post_island_{$portal_id}",$config['BUILD_ISLANDS'])) {
	$always_build = "checked=\"checked\"";
}

$portal_forums = unserialize($portal_forums);

if (!is_array($portal_forums)) $portal_forums = array();

// Get the list of forums
$query = "
	SELECT t1.FORUM_TITLE,t1.CATEGORY_ID,t1.FORUM_SORT_ORDER,t2.CATEGORY_TITLE,t1.FORUM_ID,t1.FORUM_PARENT,t1.FORUM_IS_GALLERY
	FROM {$config['TABLE_PREFIX']}FORUMS AS t1,
	{$config['TABLE_PREFIX']}CATEGORIES AS t2
	WHERE t1.CATEGORY_ID = t2.CATEGORY_ID
	ORDER BY t2.CATEGORY_SORT_ORDER,t1.FORUM_SORT_ORDER
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);

$selected = "";
if (in_array("allforums",$portal_forums)) {
	$selected = "selected=\"selected\"";
}
$sourcelist .= "<option value=\"allforums\" $selected>{$ubbt_lang['ALL_FORUMS']}</option>";
$initialcat = "";

$subforums = array();
$forum_data = array();
while ( list($Title,$Catnum,$Sorter,$Name,$Number,$Parent,$gallery) = $dbh -> fetch_array($sth))  {
	$indent = "";
	if ($Parent) {
		$subforums[$Parent][] = $Number;
		$indent = "&nbsp;&nbsp;&nbsp;";
	}

	$forum_data[$Number] = array(
		"TITLE" => $Title,
		"CAT_ID" => $Catnum,
		"SORT" => $Sorter,
		"CAT_NAME" => $Name,
		"ID" => $Number,
		"INDENT" => $indent,
		"gallery" => $gallery,
	);
} // end while

$forum_list = array();

foreach($forum_data as $k => $v) {
	if ($v['INDENT']) continue;
	if ($v['gallery']) continue;

	$forum_list[] = $v['ID'];

	if (isset($subforums[$v['ID']])) {
		foreach($subforums[$v['ID']] as $key => $sub) {
			$forum_list[] = $forum_data[$sub]['ID'];
		}
	}

}

foreach($forum_list as $k => $v) {

	if ($forum_data[$v]['gallery']) continue;
	if ($initialcat != $forum_data[$v]['CAT_NAME']) {
		$sourcelist .= "<option value=\"category\">*{$forum_data[$v]['CAT_NAME']} -----</option>";
		$initialcat = $forum_data[$v]['CAT_NAME'];
	}
	$selected = "";
	if (in_array($forum_data[$v]['ID'],$portal_forums)) {
		$selected = "selected=\"selected\"";
	}
	$sourcelist .= "<option value=\"{$forum_data[$v]['ID']}\" $selected>&nbsp;&nbsp;&nbsp;{$forum_data[$v]['INDENT']}{$forum_data[$v]['TITLE']}</option>";
}


include("{$config['FULL_PATH']}/cache/forum_cache.php");
if (!sizeof($tree)) {
	list($tree,$style_cache,$lang_cache) = build_forum_cache();
}

$selected = "";
if (in_array("allforums",$portal_forums)) {
	$selected = "selected=\"selected\"";
}
$sourcelist = "<option value=\"allforums\" $selected>{$ubbt_lang['ALL_FORUMS']}</option>";

$category = "";
$forums = 0;
foreach($tree['categories'] as $cat => $cat_title) {
	$category = "";
	$forums = 0;
	$category .= "<option value=\"category\">$cat_title ------</option>";
	if (!isset($tree[$cat])) {
		continue;
	}
	foreach($tree[$cat] as $forum_id => $forum_title) {
		if ($forum_data[$forum_id]['gallery']) continue;
		$selected = "";
		if (in_array($forum_id,$portal_forums)) $selected = "selected=\"selected\"";
		$category .= "<option value=\"$forum_id\" $selected>$forum_title</option>";
		$forums++;
	}
	if ($forums) $sourcelist .= $category;
}


// Include the template
include("../templates/default/admin/editpostisland.tmpl");

//$admin->createBottomTabs($bottomtabs,0);

$admin->sendFooter();
?>
