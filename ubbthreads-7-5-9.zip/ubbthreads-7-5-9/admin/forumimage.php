<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/forumimage.php");

// -------------
// Get the input
$startat = get_input("startat","get");
if (!$startat) { $startat = "0"; }

$html = new html;

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");
$html = new html;

$admin = new Admin;

$admin->doAuth();

// --------------------------------
// Let's grab all the avatar images
$avatarlist = "";
$dir = opendir("{$config['FULL_PATH']}/images/{$style_array['forumimages']}");
$i=0;
$currentwidth = 0;
$prevpage = "";
$nextpage = "";
if ($startat > 0) {
	$start = $startat - 10;
	$prevpage = "<a href=\"{$config['BASE_URL']}/admin/forumimage.php?startat=$start\"><<</a>";
}

while( ($file = readdir($dir)) != false) {
	if ( ($file == ".") || ($file == "..") || ($file == "index.html") ) {
		continue;
	}
	if ($i < $startat) {
		$i++;
		continue;
	}
	$imagehw = @GetImageSize("{$config['FULL_PATH']}/images/{$style_array['forumimages']}/$file");
	$iw = $imagehw[0];
	$ih = $imagehw[1];
	if (!$iw) { $iw = "48"; }
	if (!$ih) { $ih = "48"; }

	$currentwidth = $currentwidth + $iw;
	if ($currentwidth > 250) {
		$currentwidth = $iw;
		$avatarlist .= "<br />";
	}
	if ($i == $startat + 10) {
		$start = $startat + 10;
		$nextpage = "<a href=\"{$config['BASE_URL']}/admin/forumimage.php?startat=$start\">>></a>";
		$prevpage = "&nbsp; &nbsp; &nbsp; $prevpage";
		break;
	}
	$avatarlist .= "<a href=\"javascript:void(0);\" onclick=\"javascript:preview('$file','$iw','$ih');\"><img border=\"1\" src=\"{$config['BASE_URL']}/images/{$style_array['forumimages']}/$file\"/></a> ";
	$i++;
}

echo <<<UBBTPRINT
<html>
<head>
<link rel="stylesheet" href="{$config['BASE_URL']}/admin/cp_style.css" />
<SCRIPT TYPE="text/javascript" LANGUAGE="Javascript1.1">
<!-- hide javascript from older browsers

function preview(avatar,width,height) {
	document.images['selected_avatar'].src = '{$config['BASE_URL']}/images/{$style_array['forumimages']}/' + avatar;
	document.images['selected_avatar'].width = width;
	document.images['selected_avatar'].height = height;
	}// end function

	function noavatar() {
		parent.opener.document.images['avimg'].src = '{$config['BASE_URL']}/images/{$style_array['general']}/blank.gif';
		parent.opener.document.images['avimg'].width = document.images['selected_avatar'].width;
		parent.opener.document.images['avimg'].height = document.images['selected_avatar'].height;
		parent.opener.document.pageform.avurl.value = '';
		self.close();
	}// end function

	function changeparent() {
		parent.opener.document.images['avimg'].src = document.images['selected_avatar'].src;
		parent.opener.document.pageform.avurl.value = document.images['selected_avatar'].src;
		self.close();
	}// end function
// end javascript hiding -->
</SCRIPT>
</hed>
<body>


<form name="avatar_select_form">
<input type="hidden" name="valid_post" value="1" />
<table border="0" width="100%">
<tr>
<td valign="top" class="alt-2" width="100">
<img name="selected_avatar" src="{$config['BASE_URL']}/images/{$style_array['general']}/blank.gif" border="1" width="48" height="48" />
<br />
<br />
<input type="button" name="select_avatar" value="{$ubbt_lang['SELECT_AV']}" onclick="changeparent()" class="buttons" />
<br />
<br />
<input type="button" name="no_avatar" value="{$ubbt_lang['NO_AV']}" onclick="noavatar();" class="buttons" />
<br />
<br />
<input type="reset" name="cancel" value="{$ubbt_lang['CANCEL']}" onclick="self.close()" class="buttons" />
</td>
<td class="alt-1" valign="top" align="center">
$avatarlist
<br />
<p align="center">
$prevpage
$nextpage
</p>
</table>
</body>
</html>
UBBTPRINT;
?>
