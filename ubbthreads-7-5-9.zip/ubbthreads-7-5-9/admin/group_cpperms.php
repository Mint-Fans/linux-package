<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/cpperms.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");
$edit_group = get_input("edit_group","both");
$copy_group = get_input("copy_group","both");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$perm_list = array();
$query = "
	select PERMISSION_NAME,PERMISSION_IS_HIGH,PERMISSION_IS_LOW
	from {$config['TABLE_PREFIX']}PERMISSION_LIST
	where PERMISSION_TYPE='cp'
	order by PERMISSION_ORDER
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while($row = $dbh->fetch_array($sth)) {
	$perm_list[] = $row;
} // end while

$gselect = $edit_group;

if ($copy_group) {
	$gselect = $copy_group;
}

$perms = array();
$query = "
	select *
	from {$config['TABLE_PREFIX']}CP_PERMISSIONS
	where GROUP_ID = ?
";
$sth = $dbh->do_placeholder_query($query,array($gselect),__LINE__,__FILE__);
while($row = $dbh->fetch_array($sth,MYSQL_ASSOC)) {
	foreach($row as $k => $v) {
		if ($k == "GROUP_ID") continue;
		$perms[$k] = $v;
	}
}


// Now grab all groups
$groups = array();
$query = "
	select GROUP_ID,GROUP_NAME
	from {$config['TABLE_PREFIX']}GROUPS
	order by GROUP_ID
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
while(list($gid,$gname) = $dbh->fetch_array($sth)) {
	$groups[$gid] = $gname;
} // end while



$tabs = array(
	"{$ubbt_lang['CP_PERMS']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['GROUP_SET']);
$admin->setParentTitle($ubbt_lang['GROUP_SET'],"groupmanage.php");
$admin->setPageTitle($ubbt_lang['CP_PERMS']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);

// Include the template
include("../templates/default/admin/group_cpperms.tmpl");

$admin->sendFooter();
?>
