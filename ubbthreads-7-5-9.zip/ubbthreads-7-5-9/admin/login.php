<?php

//	Script Version 7.5.9

// Require the library
require_once("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/login.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;
$html = new html;

$admin->doAuth(array("EDIT_USERS","APPROVE_POSTS"));

// First thing.  Get rid of any unverified email accounts that
// are over 24 hours old
$deldate = $html->get_date() - 86400;

// We store some info in an admin cookie so we don't have to requery for some stuff
$ubbt_admin = get_input("{$config['COOKIE_PREFIX']}ubbt_admin","cookie");
$rightnow = time();

if ($ubbt_admin) {
	$ubbt_admin = unserialize($ubbt_admin);
}

// suhosin Check by VNC Web Services (http://www.virtualnightclub.net/)
if(extension_loaded("suhosin") && ini_get("suhosin.get.max_value_length")) {
	if(ini_get("suhosin.get.max_value_length") <= 2048) {
		$suhosin = "You may experience issues with a blank configuration file if you continue, please see <a href=\"http://www.ubbwiki.com/article/view/16/issues-with-suhosin.html\" target=\"_blank\">UBB.Wiki: Issues with suhosin</a>; this issue pertains to the settings of the suhosin module with your webhost.  Your current suhousin length is: ". ini_get("suhosin.get.max_value_length") .".";
	} else {
		$suhosin = "";
	}
}

// We only want to do some of these queries every 5 minutes so
// as not to slow things down if they keep hitting the login screen.

// ------------------
// Grab total members
$query = "
	SELECT count(*)
	FROM {$config['TABLE_PREFIX']}USERS
	where USER_ID > 1
	and USER_IS_APPROVED = 'yes'
";
$sth = $dbh -> do_query($query,__LINE__,__FILE__);
list($totalmembers) = $dbh -> fetch_array($sth);

// -----------------
// Grab total forums
$query = "
	SELECT COUNT(*)
	FROM {$config['TABLE_PREFIX']}FORUMS
	WHERE FORUM_IS_ACTIVE = '1'
";
$sth = $dbh -> do_query($query,__LINE__,__FILE__);
list($totalforums) = $dbh -> fetch_array($sth);


// -----------------
// Grab total topics
$query = "
	SELECT SUM(FORUM_TOPICS)
	FROM {$config['TABLE_PREFIX']}FORUMS
	WHERE FORUM_IS_ACTIVE='1'
";
$sth = $dbh -> do_query($query,__LINE__,__FILE__);
list($totaltopics) = $dbh -> fetch_array($sth);

// -----------------
// Grab total forums
$query = "
	SELECT SUM(FORUM_POSTS)
	FROM {$config['TABLE_PREFIX']}FORUMS
	WHERE FORUM_IS_ACTIVE='1'
";
$sth = $dbh -> do_query($query,__LINE__,__FILE__);
list($totalposts) = $dbh -> fetch_array($sth);

if ($config['BOARD_IS_CLOSED']) {
	$open = $ubbt_lang['IS_CLOSED'];
	$dotoggle = $ubbt_lang['OPEN_BOARD'];
}
else {
	$open = $ubbt_lang['IS_OPEN'];
	$dotoggle = $ubbt_lang['CLOSE_BOARD'];
}

// Grab new members in time periods
if (!isset($ubbt_admin['newmembers1'])) {
	$query = "
		SELECT COUNT(USER_ID)
		FROM {$config['TABLE_PREFIX']}USERS
		WHERE USER_REGISTERED_ON > (UNIX_TIMESTAMP() - (86400))
		AND USER_IS_APPROVED = 'yes'
	";
	$sth = $dbh->do_query($query);
	list($newmembers1) = $dbh->fetch_array($sth);
	$ubbt_admin['newmembers1'] = $newmembers1;

	$query = "
		SELECT COUNT(USER_ID)
		FROM {$config['TABLE_PREFIX']}USERS
		WHERE USER_REGISTERED_ON > (UNIX_TIMESTAMP() - (86400 * 7))
		AND USER_IS_APPROVED = 'yes'
	";
	$sth = $dbh->do_query($query);
	list($newmembers7) = $dbh->fetch_array($sth);
	$ubbt_admin['newmembers7'] = $newmembers7;

	$query = "
		SELECT COUNT(USER_ID)
		FROM {$config['TABLE_PREFIX']}USERS
		WHERE USER_REGISTERED_ON > (UNIX_TIMESTAMP() - (86400 * 31))
		AND USER_IS_APPROVED = 'yes'
	";
	$sth = $dbh->do_query($query);
	list($newmembers31) = $dbh->fetch_array($sth);
	$ubbt_admin['newmembers31'] = $newmembers31;
}
else {
	$newmembers1 = $ubbt_admin['newmembers1'];
	$newmembers7 = $ubbt_admin['newmembers7'];
	$newmembers31 = $ubbt_admin['newmembers31'];
}


$sqllog = $ubbt_lang['NOT_ENABLED'];
$adminlog = $ubbt_lang['NOT_ENABLED'];

if ($config['LOG_SQL_ERRORS']) {
	//$sql_error = filectime ();
	$i=0;
	$size = 0;
	if (file_exists($config['SQL_LOG_PATH'])) {
		$dir=@opendir($config['SQL_LOG_PATH']);

		while ($file = readdir($dir)) {
			if ($file == "." || $file == ".." || (!stristr($file,"mysql.log"))) { continue; }
			$size = $size + filesize("{$config['SQL_LOG_PATH']}/$file");
			$i++;
		}
	}
    $Mult = Floor($size = Log($size+1) / Log(1024));
    $printsize = Round(Pow(1024, $size - $Mult) * 100) / 100 . " " .  SubStr(" KMGT", $Mult, Min(1, $Mult)) . "B";

	$sqllog = " {$ubbt_lang['FILE_COUNT']} = $i ({$ubbt_lang['LOG_SIZE']} $printsize)";
}
if ($config['LOG_ADMIN_ACTIVITY']) {
	$i=0;
	$size = 0;
	if (file_exists($config['ADMIN_LOG_PATH'])) {
		$dir=@opendir($config['ADMIN_LOG_PATH']);

		while ($file = readdir($dir)) {
			if ($file == "." || $file == "..") { continue; }
			$size = $size + filesize("{$config['ADMIN_LOG_PATH']}/$file");
			$i++;
		}
	}
    $Mult = Floor($size = Log($size+1) / Log(1024));
    $printsize = Round(Pow(1024, $size - $Mult) * 100) / 100 . " " .  SubStr(" KMGT", $Mult, Min(1, $Mult)) . "B";
	$adminlog = " {$ubbt_lang['FILE_COUNT']} = $i ({$ubbt_lang['LOG_SIZE']} $printsize)";
}

$loginfo = "";

if ($config['LOG_ADMIN_ACTIVITY'] || $config['LOG_SQL_ERRORS']) {
	$loginfo = <<<EOF
<br /><strong>{$ubbt_lang['LOGS']}</strong>
<br />
EOF;
	if ($config['LOG_SQL_ERRORS']) {
		$loginfo .= <<<EOF
&nbsp; &nbsp;<a href="{$config['BASE_URL']}/admin/logs.php?returntab=0">{$ubbt_lang['SQL_ERRORS']}</a>: <b>$sqllog</b><br />
EOF;
	}
}

// Any posts waiting for approval?
$pa_link = "";
$dc_link = "";
$modq_link = "";

$inlist = "";
if ($user['USER_MEMBERSHIP_LEVEL'] == "Moderator") {

	$query = "
		select FORUM_ID
		from {$config['TABLE_PREFIX']}MODERATORS
		where USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
	while(list($forum_id) = $dbh->fetch_array($sth)) {
		$inlist .= "$forum_id,";
	} // end while
	$inlist = preg_replace("/,$/","",$inlist);
	if ($inlist) {
		$inlist = "AND t2.FORUM_ID in ($inlist)";
	}

}

$query = "
	SELECT COUNT(t1.POST_ID)
	FROM {$config['TABLE_PREFIX']}POSTS as t1,
	{$config['TABLE_PREFIX']}TOPICS as t2
	WHERE t1.POST_IS_APPROVED = '0'
	and t1.TOPIC_ID = t2.TOPIC_ID
	$inlist
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
list($p) = $dbh->fetch_array($sth);
if ($p) {
	$ubbt_lang['APP_POSTS'] = sprintf($ubbt_lang['APP_POSTS'],$p);
	$pa_link = "<a href=\"{$config['BASE_URL']}/admin/approveposts.php\">{$ubbt_lang['APP_POSTS']}</a><br />";
}

// Any registration que users?
if (!isset($ubbt_admin['modq']) || ($ubbt_admin['timestamp'] < ($rightnow - 300))) {
	$query = "
		SELECT COUNT(USER_ID)
		FROM {$config['TABLE_PREFIX']}USERS
		WHERE USER_IS_APPROVED <> 'yes'
		AND USER_ID <> '1'
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	list($modq) = $dbh->fetch_array($sth);
	$ubbt_admin['modq'] = $modq;
}
else {
	$modq = $ubbt_admin['modq'];
}

if ($modq) {
	$ubbt_lang['MODQ'] = sprintf($ubbt_lang['MODQ'],$modq);
	$modq_link = "<a href=\"{$config['BASE_URL']}/admin/membermanage.php?returntab=1\">{$ubbt_lang['MODQ']}</a><br />";
}

// Any display name changes?
$query = "
	SELECT COUNT(*)
	FROM {$config['TABLE_PREFIX']}DISPLAY_NAMES
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
list($totaldc) = $dbh->fetch_array($sth);

if ($totaldc) {
	$ubbt_lang['DISPLAY_CHANGES'] = sprintf($ubbt_lang['DISPLAY_CHANGES'],$totaldc);
	$modq_link .= "<a href=\"{$config['BASE_URL']}/admin/membermanage.php?returntab=2\">{$ubbt_lang['DISPLAY_CHANGES']}</a><br />";
}
// Get Server Stats
$php_os = PHP_OS;
$php_version = phpversion();
list( $server_software, $junk ) = preg_split("# #",$_SERVER['SERVER_SOFTWARE']);
$sth = $dbh->do_query( "select VERSION()" );
list( $mysql_version ) = $dbh->fetch_array( $sth );

// Get database size
$dbsize = 0;
$sth = $dbh->do_query("SHOW TABLE STATUS LIKE '{$db->p}%'" );
while($row = $dbh->fetch_array($sth)) {
	$dbsize += $row['Data_length'] + $row['Index_length'];
}
$dbsize = file_size($dbsize);

// Can we get the System Load Average
$load = array();
if (!preg_match("#^win#i",PHP_OS)) {
  if (function_exists('sys_getloadavg')) {
    $load = sys_getloadavg();
  }
  if (file_exists("/proc/loadavg")) {
    $load = explode(chr(32),file_get_contents("/proc/loadavg"));
  }
}

if ($ubbt_admin['timestamp'] < ($rightnow - 1800)) {
	$ubbt_admin['timestamp'] = $rightnow;
}


$ubbt_admin = serialize($ubbt_admin);
$html->ubbt_setcookie("{$config['COOKIE_PREFIX']}ubbt_admin",$ubbt_admin);

$tabs = array(
	"{$ubbt_lang['HOME']}" => "",
);

// Create the Page
$admin->setPageTitle("Home");
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/login.tmpl");

$admin->sendFooter();
?>
