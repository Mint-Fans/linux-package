<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/primary.php");
require ("../languages/{$config['LANGUAGE']}/admin/stop_forum_spam.php");

// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME,USER_REAL_EMAIL");

$admin = new Admin;
$admin->doAuth();

// Generate a random key, if it doesn't yet exist
if ($config['BOARD_KEY'] == '') {
	$config['BOARD_KEY'] = uniqid();
}

// Set the default values
$isclosed_checked = "";
if ($config['BOARD_IS_CLOSED']) {
	$isclosed_checked = "checked=\"checked\"";
}

$MULTI_URL_checked = "";
if ($config['MULTI_URL']) {
	$MULTI_URL_checked = "checked=\"checked\"";
}
$ubbt_lang['ALLOW_MULTI_URL_1'] = $html->substitute($ubbt_lang['ALLOW_MULTI_URL_1'],array("FULL_URL" => $config['FULL_URL']));

$usezlib_checked = "";
if ($config['ZLIB_COMPRESSION']) {
	$usezlib_checked = "checked=\"checked\"";
}

$log_mysql_checked = "";
if ($config['LOG_SQL_ERRORS']) {
	$log_mysql_checked = "checked=\"checked\"";
}

$log_refer_checked = "";
if ($config['LOG_REFERS']) {
	$log_refer_checked = "checked=\"checked\"";
}

$DO_CENSOR_checked = "";
if ($config['DO_CENSOR']) {
	$DO_CENSOR_checked = "checked=\"checked\"";
}

$nofollow_post_checked = "";
$nofollow_sig_checked = "";
if ($config['NOFOLLOW_POST']) {
	$nofollow_post_checked = "checked=\"checked\"";
}
if ($config['NOFOLLOW_SIG']) {
	$nofollow_sig_checked = "checked=\"checked\"";
}

$DISABLE_REFERER_CHECK_checked = "";
if ($config['DISABLE_REFERER_CHECK']) {
	$DISABLE_REFERER_CHECK_checked = "checked=\"checked\"";
}

$search_urls_checked = "";
if ($config['SEARCH_FRIENDLY_URLS']) {
	$search_urls_checked = "checked=\"checked\"";
}

$search_html_ext_checked = "";
if ($config['SEARCH_FRIENDLY_HTML_EXT']) {
	$search_html_ext_checked = "checked=\"checked\"";
}

if (!$config['REPLACE_WORD']) {
	$config['REPLACE_WORD'] = "[censored]";
}

$debugging_checked = "";
if ($config['ALLOW_DEBUGGING']) {
	$debugging_checked = "checked=\"checked\"";
}

// Grab the current closed forum message
$closedmessage ="";
$closedfile = file("{$config['FULL_PATH']}/includes/closedforums.php");
while (list($linenum,$line) = each($closedfile)) {
	$closedmessage  .= "$line";
}

// Grab the censored words
$censorlist ="";
$query = "
	SELECT CENSOR_WORD,CENSOR_REPLACE_WITH
	FROM {$config['TABLE_PREFIX']}CENSOR_LIST
	ORDER BY CENSOR_WORD
";
$sth = $dbh->do_query($query);
while(list($cword,$creplace) = $dbh->fetch_array($sth)) {
	if ($creplace) {
		$censorlist .= "$cword=$creplace\n";
	}
	else {
		$censorlist .= "$cword\n";
	}
}

// Default board email address
if (!$config['SITE_EMAIL']) {
	$config['SITE_EMAIL'] = $user['USER_REAL_EMAIL'];
}

// Stop Forum Spam section
//
$SFS_Enable_checked = ($config['SFS_ENABLE'] == '1') ? 'checked' : '';
$SFS_Level_1_checked = ($config['SFS_LEVEL'] == 1) ? 'checked' : '';
$SFS_Level_2_checked = ($config['SFS_LEVEL'] == 2) ? 'checked' : '';
$SFS_Level_3_checked = ($config['SFS_LEVEL'] == 3) ? 'checked' : '';
$SFS_Level_4_checked = ($config['SFS_LEVEL'] == 4) ? 'checked' : '';

$tabs = array(
	"{$ubbt_lang['GENERAL']}" => "",
	"{$ubbt_lang['LOG_BACK']}" => "",
	"{$ubbt_lang['CENSOR']}" => "",
	"{$ubbt_lang['SF_SPAM']}" => "",
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['PRIMARY']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['PRIMARY']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);
$admin->setCommonSubmit($ubbt_lang['UPDATE']);

// Include the template
include("../templates/default/admin/primary.tmpl");

$admin->sendFooter();
?>
