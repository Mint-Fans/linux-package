<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/profiles.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","get");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;


// Only custom titles?
$only_custom = "";
if ($config['ONLY_CUSTOM']) {
	$only_custom = "checked=\"checked\"";
}


$admin->doAuth();

// Grab the current title list
$query = "
	SELECT USER_TITLE_ID,USER_TITLE_POST_COUNT,USER_TITLE_NAME
	FROM {$config['TABLE_PREFIX']}USER_TITLES
	ORDER BY USER_TITLE_ID
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$tarray = array();
while(list($tnum,$tpost,$ttitle) = $dbh->fetch_array($sth)) {
	$tarray[$tnum]['post'] = $tpost;
	$tarray[$tnum]['title'] = ubbchars($ttitle);
	$maxnum = $tnum + 1;
}
for ($i=$maxnum;$i<=20;$i++) {
	$tarray[$i]['post'] = "";
	$tarray[$i]['title'] = "";
}

$tabs = array(
	"{$ubbt_lang['AVATARS']}" => "",
	"{$ubbt_lang['USER_TITLES']}" => ""
);

$admin->setCurrentMenu($ubbt_lang['PROF_SET']);
$admin->setReturnTab($returntab);
$admin->setPageTitle($ubbt_lang['PROF_SET']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);
$admin->setCommonSubmit($ubbt_lang['UPDATE']);

// Include the template
include("../templates/default/admin/profiles.tmpl");

$admin->sendFooter();
?>
