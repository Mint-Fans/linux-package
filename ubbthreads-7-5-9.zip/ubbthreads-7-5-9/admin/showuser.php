<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
include ("../languages/{$config['LANGUAGE']}/admin/generic.php");
include ("../languages/{$config['LANGUAGE']}/admin/showuser.php");
include ("../languages/{$config['LANGUAGE']}/admin/stop_forum_spam.php");

// -----------------
// Get the user info

// Expire any old bans
trigger_ban_expiration();

$userob = new user;
$user = $userob -> authenticate("USER_TIME_OFFSET,USER_TIME_FORMAT");
$html = new html;

$admin = new Admin;
$admin->doAuth(array("EDIT_USERS"));

// Get the input
$uid = get_input("uid","both");
$returntab = get_input("returntab","both");

if ($uid == "1") {
	$admin->error($ubbt_lang['NO_EDIT_ANON']);
}

include("{$config['FULL_PATH']}/cache/forum_cache.php");
if (!sizeof($tree)) {
	list($tree,$style_cache,$lang_cache) = build_forum_cache();
}


// If this is a moderator, let's see what groups they belong to
$my_group_list = array();
if ($user['USER_MEMBERSHIP_LEVEL'] == "Moderator") {
	$query = "
		select GROUP_ID
		from {$config['TABLE_PREFIX']}USER_GROUPS
		where USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($user['USER_ID']),__LINE__,__FILE__);
	while(list($gid) = $dbh->fetch_array($sth)) {
		$my_group_list[] = $gid;
	} // end while
}
// Grab all of the current information on this user
$query = "
	SELECT t1.USER_LOGIN_NAME,t1.USER_DISPLAY_NAME,t2.USER_REAL_EMAIL,t2.USER_DISPLAY_EMAIL,t2.USER_DEFAULT_SIGNATURE,t2.USER_HOMEPAGE,
	t2.USER_OCCUPATION,t2.USER_HOBBIES,t2.USER_LOCATION,t2.USER_ICQ,t2.USER_YAHOO,t2.USER_MSN,t2.USER_AIM,t2.USER_EXTRA_FIELD_1,
	t2.USER_EXTRA_FIELD_2,t2.USER_EXTRA_FIELD_3,t2.USER_EXTRA_FIELD_4,t2.USER_EXTRA_FIELD_5,t2.USER_AVATAR,t2.USER_VISIBLE_ONLINE_STATUS,
	t2.USER_ACCEPT_PM,t2.USER_BIRTHDAY,t2.USER_PUBLIC_BIRTHDAY,t2.USER_AVATAR_WIDTH,t2.USER_AVATAR_HEIGHT,
	t2.USER_TOPIC_VIEW_TYPE,t2.USER_TOPICS_PER_PAGE,t2.USER_SHOW_AVATARS,t2.USER_POSTS_PER_TOPIC,t2.USER_TIME_OFFSET,t2.USER_SHOW_SIGNATURES,
	t2.USER_TIME_FORMAT,t2.USER_NOTIFY_ON_PM,t2.USER_ACCEPT_ADMIN_EMAILS,t1.USER_REGISTERED_ON,t1.USER_REGISTRATION_IP,
	t3.USER_LAST_POST_TIME,t3.USER_LAST_IP,t2.USER_RATING,t2.USER_CUSTOM_TITLE,t2.USER_NAME_COLOR,t1.USER_MEMBERSHIP_LEVEL,
	t1.USER_IS_BANNED,t1.USER_IS_UNDERAGE,t2.USER_FLOOD_CONTROL_OVERRIDE,t1.USER_REGISTRATION_EMAIL
	FROM {$config['TABLE_PREFIX']}USERS as t1,
	{$config['TABLE_PREFIX']}USER_PROFILE as t2,
	{$config['TABLE_PREFIX']}USER_DATA as t3
	WHERE t1.USER_ID = ?
	and t1.USER_ID = t2.USER_ID
	and t1.USER_ID = t3.USER_ID
";
$sth = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
list($lname,$dname,$email,$femail,$sig,$homepage,
$occ,$hobbies,$loc,$icq,$yahoo,$msn,$aim,$CUSTOM_FIELD_1,
$CUSTOM_FIELD_2,$CUSTOM_FIELD_3,$CUSTOM_FIELD_4,$CUSTOM_FIELD_5,$picture,$visible,
$acceptpriv,$birthday,$showbday,$picwidth,$picheight,
$display,$postsper,$SHOW_AVATARS,$flatposts,$timeoffset,$showsigs,$timeformat,$notify,$adminemails,
$regdate,$regip,$lastpost,$lastpostip,$rating,$usertitle,$namecolor,$status,$banned,$coppa,$floodcontrol,$regemail)=$dbh->fetch_array($sth);

$usertitle = ubbchars($usertitle);

$bandisplay = "display: none";
$expires = "";
$reason = "";
$ban_text = $ubbt_lang['EXPIRES'];
if ($banned) {
	$bandisplay = "";
	$query = "
		select BAN_EXPIRATION,BAN_REASON
		from {$config['TABLE_PREFIX']}BANNED_USERS
		where USER_ID = ?
	";
	$sth = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
	list ($expires,$reason) = $dbh->fetch_array($sth);
	$ban_text = $ubbt_lang['EXPIRES_ON'];
	if ($expires) {
		$expires_on = $html->convert_time($expires,$user['USER_TIME_OFFSET'],$user['USER_TIME_FORMAT']);
	}
	if ($expires == 0) {
		$expires_on = $ubbt_lang['NEVER_EXPIRE'];
	}
}


// Moderators cannot edit admins or other moderators
if (($user['USER_MEMBERSHIP_LEVEL'] == "Moderator") && ($status == "Moderator" || $status == "Administrator")) {
	$admin->error($ubbt_lang['NO_ADMOD_EDIT']);
}

// Default flood control
if ((!$floodcontrol && $floodcontrol != "0") || ($floodcontrol == "-1")){
	$floodcontrol = '';
}

// Grab user's groups
$query = "
	select GROUP_ID
	from {$config['TABLE_PREFIX']}USER_GROUPS
	where USER_ID = ?
";
$sth = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
$user_groups = array();
while(list($gid) = $dbh->fetch_array($sth)) {
	$user_groups[] = $gid;
}

// Grab any notes about this user
$query = "
	SELECT NOTE_TEXT
	FROM {$config['TABLE_PREFIX']}USER_NOTES
	WHERE USER_ID = ?
";
$sth = $dbh -> do_placeholder_query($query,array($uid),__LINE__,__FILE__);
list($notes) = $dbh -> fetch_array($sth);
// Setup the default values
if (strlen($regdate) < 8) {
	$regdate = $ubbt_lang['UNAVAIL'];
}
else {
	$regdate = $html->convert_time($regdate,$user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT']);
}

if ($lastpost) {
	$lastpost = $html->convert_time($lastpost,$user['USER_TIME_OFFSET'], $user['USER_TIME_FORMAT']);
}

$stars = $rating;
$rating = "";
for($x=1;$x<=$stars;$x++) {
	$rating .= "<img src=\"{$config['BASE_URL']}/images/{$style_array['general']}/star.gif\" title=\"*\" alt=\"*\" />";
}
if (!$rating) {
	$rating = $ubbt_lang['NOT_RATED'];
}

// Does user have access rights?
$ban_checked = "";
if ($banned) {
	$ban_checked = "checked=\"checked\"";
}

// Get all active groups
$query = "
	SELECT GROUP_NAME,GROUP_ID
	FROM {$config['TABLE_PREFIX']}GROUPS
	WHERE GROUP_IS_DISABLED <> 1
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);

// Create a table to hold the group selections
$groupselection = "<table border=\"0\" width=\"100%\">";
$row =0;
$i=0;
$gparraysize = 0;
while ( list($Name,$Id) = $dbh -> fetch_array($sth)) {
	if ( ($Id < 4) || ($Id == 5)) { continue; }
	if ($row == 0) { $groupselection .= "<tr>"; }
	$row++;
	$groupselection .= "<td width=\"50%\" class=\"stdautorow colored-row\" valign=\"top\">";
	$checked = "";
	if (in_array($Id,$user_groups)) {
		$checked = "checked=\"checked\"";
	}
	if ($user['USER_MEMBERSHIP_LEVEL'] == "Moderator" && !in_array($Id,$my_group_list) ) {
		$hidden = "";
		if ($checked == "checked=\"checked\"") {
			$hidden = "value=\"$Id\"";
		}
		$groupselection .= "<input type=\"hidden\" name=\"group[$i]\" $hidden />";
		$gparraysize++;
		$i++;
		continue;
	}
	$groupselection .= "<input type=\"checkbox\" id=\"group-$i\" name=\"group[$i]\" $checked value=\"$Id\" /> ";
	$groupselection .= "<label for=\"group-$i\" class=\"radio\">$Name</label>";
	$groupselection .= "</td>";
	$gparraysize++;
	$i++;
	if ($row == 2) {
		$groupselection .= "</tr>";
	$row = 0;
	}
}
$groupselection .= "<input type=\"hidden\" name=\"grouparr_size\" value=\"{$gparraysize}\" />";
$dbh -> finish_sth($sth);

if ($row > 0) {
	for ( $i=0; $i<(2-$row); $i++) {
		$groupselection .= "<td width=\"50%\" valign=\"top\">&nbsp;</td>";
	}
	$groupselection .= "</tr>";
}
$groupselection .= "</table>";

$isuser_checked = "";
if ($status == "User") {
	$isuser_checked = "checked=\"checked\"";
}

// Is user a moderator
$moddisplay = "";
$ismod_checked = "";
if ($status == "Moderator") {
	$ismod_checked = "checked=\"checked\"";
}

// Is user a global moderator
$moddisplay = "";
$isgmod_checked = "";
if ($status == "GlobalModerator") {
	$isgmod_checked = "checked=\"checked\"";
}

if ($status == "User") {
	$moddisplay = "display: none;";
}

// Create forum list and figure out what they moderate
$query = "
	SELECT FORUM_ID
	FROM {$config['TABLE_PREFIX']}MODERATORS
	WHERE USER_ID = ?
";
$sth = $dbh->do_placeholder_query($query,array($uid),__LINE__,__FILE__);
$modboards = array();
while(list($modboard) = $dbh->fetch_array($sth)) {
	$modboards[] = $modboard;
}

$modforumlist = "<select name=\"modforums[]\" multiple=\"multiple\" size=\"10\">";
$initialcat = "";
foreach ($tree['categories'] as $cat => $cat_title) {
	if (!isset($tree[$cat])) continue;
	$modforumlist .= "<optgroup label='{$tree['categories'][$cat]}'>";
	foreach($tree[$cat] as $forum_id => $forum_title) {
		if (in_array($forum_id,$modboards)) {
			$modforumlist .= "<option value='$forum_id' selected='selected'>$forum_title</option>";
		} else {
			$modforumlist .= "<option value='$forum_id'>$forum_title</option>";
		}
	}
}

$modforumlist .= "</select>";
$adminforumlist = $modforumlist;
$adminforumlist = str_replace("modforums[]","adminforums[]",$adminforumlist);

// Is the user an admin?
$isadmin_checked = "";
$admindisplay = "";
if ($status == "Administrator") {
	$isadmin_checked="checked=\"checked\"";
}
else {
	$admindisplay = "display: none;";
}

// Is coppa user
$under13_checked = "";
if ($coppa) {
	$under13_checked="checked=\"checked\"";
}

// Do they have the extra settings enabled?
$extra1text = "";
$extra2text = "";
$extra3text = "";
$extra4text = "";
$extra5text = "";
if ($config['CUSTOM_FIELD_1']) {
	$extra1text = <<<EOF
<tr><td class="autorow colored-row autobottom" align="left" valign="top">
<br />
<span class="autorow-title">
<label class="radio" for="extra1">
{$config['CUSTOM_FIELD_1']}
</label>
</span>
</td><td class="stdautorow colored-row autobottom" valign="top">
<br />
<input type="text" name="CUSTOM_FIELD_1" value="$CUSTOM_FIELD_1" size="50" id="extra1" />
</td></tr>
EOF;
}
if ($config['CUSTOM_FIELD_2']) {
	$extra2text = <<<EOF
<tr><td class="autorow colored-row autobottom" align="left" valign="top">
<br />
<span class="autorow-title">
<label class="radio" for="extra2">
{$config['CUSTOM_FIELD_2']}
</label>
</span>
</td><td class="stdautorow colored-row autobottom" valign="top">
<br />
<input type="text" name="CUSTOM_FIELD_2" value="$CUSTOM_FIELD_2" size="50" id="extra2" />
</td></tr>
EOF;
}
if ($config['CUSTOM_FIELD_3']) {
	$extra3text = <<<EOF
<tr><td class="autorow colored-row autobottom" align="left" valign="top">
<br />
<span class="autorow-title">
<label class="radio" for="extra3">
{$config['CUSTOM_FIELD_3']}
</label>
</span>
</td><td class="stdautorow colored-row autobottom" valign="top">
<br />
<input type="text" name="CUSTOM_FIELD_3" value="$CUSTOM_FIELD_3" size="50" id="extra3" />
</td></tr>
EOF;
}
if ($config['CUSTOM_FIELD_4']) {
	$extra4text = <<<EOF
<tr><td class="autorow colored-row autobottom" align="left" valign="top">
<br />
<span class="autorow-title">
<label class="radio" for="extra4">
{$config['CUSTOM_FIELD_4']}
</label>
</span>
</td><td class="stdautorow colored-row autobottom" valign="top">
<br />
<input type="text" name="CUSTOM_FIELD_4" value="$CUSTOM_FIELD_4" size="50" id="extra4" />
</td></tr>
EOF;
}
if ($config['CUSTOM_FIELD_5']) {
	$extra5text = <<<EOF
<tr><td class="autorow colored-row autobottom" align="left" valign="top">
<br />
<span class="autorow-title">
<label class="radio" for="extra5">
{$config['CUSTOM_FIELD_5']}
</label>
</span>
</td><td class="stdautorow colored-row autobottom" valign="top">
<br />
<input type="text" name="CUSTOM_FIELD_5" value="$CUSTOM_FIELD_5" size="50" id="extra5" />
</td></tr>
EOF;
}

// Get rid of http in homepage
$homepage = str_replace("http://","",$homepage);

// Change quotes to &quot;
$femail = str_replace("\"","&quot;",$femail);
$sig = str_replace("\"","&quot;",$sig);
$homepage = str_replace("\"","&quot;",$homepage);
$occ = str_replace("\"","&quot;",$occ);
$hobbies = str_replace("\"","&quot;",$hobbies);
$loc = str_replace("\"","&quot;",$loc);
$icq = str_replace("\"","&quot;",$icq);
$yahoo = str_replace("\"","&quot;",$yahoo);
$msn = str_replace("\"","&quot;",$msn);
$aim = str_replace("\"","&quot;",$aim);
$CUSTOM_FIELD_1 = str_replace("\"","&quot;",$CUSTOM_FIELD_1);
$CUSTOM_FIELD_2 = str_replace("\"","&quot;",$CUSTOM_FIELD_2);
$CUSTOM_FIELD_3 = str_replace("\"","&quot;",$CUSTOM_FIELD_3);
$CUSTOM_FIELD_4 = str_replace("\"","&quot;",$CUSTOM_FIELD_4);
$CUSTOM_FIELD_5 = str_replace("\"","&quot;",$CUSTOM_FIELD_5);

// Do they have a specified avatar?
$currentav = "";
if ($picture && $picture != "http://") {
	$currentav = "<img src=\"$picture\" />";
}

// Birthday defaults
$bdaytext = $ubbt_lang['SHOW_BDAY'];
if (isset($config['BIRTHDAYS_IN_CALENDAR']) && $config['BIRTHDAYS_IN_CALENDAR']) {
	$bdaytext .= " {$ubbt_lang['SHOW_BDAY_1']}";
}
$showbday_checked = "";
if ($showbday) {
	$showbday_checked = "checked=\"checked\"";
}

$time_formats = "";
if (!$timeformat) { $timeformat = $config['TIME_FORMAT']; }
foreach($config['TIME_FORMATS'] as $k => $v) {
	$selected = "";
	if ($timeformat == $v) {
		$selected = "selected=\"selected\"";
	}
	$time_formats .= "<option value=\"$k\" $selected>" . $html->convert_time(time(),0,$v,1) . "</option>";
}

$flat = ""; $threaded = "";
if($display == "flat")     { $flat = "selected=\"selected\""; };
if($display == "threaded") { $threaded = "selected=\"selected\""; }

// Default time offset
if (!$timeoffset) { $timeoffset = 0; }

// Default flat posts per page
if (!$flatposts) { $flatposts = $config['POSTS_PER_PAGE']; }

// Default picture view
$SHOW_AVATARS_checked = "";
if (!$SHOW_AVATARS) { $SHOW_AVATARS = $config['SHOW_AVATARS']; }
if ($SHOW_AVATARS == "1") {
	$SHOW_AVATARS_checked = "checked=\"checked\"";
}

// Default sig view
$showsigs_checked = "";
if ($showsigs != "no") {
	$showsigs_checked = "checked=\"checked\"";
}

// Who's online defaults
$visible_checked = "";
if ($visible != "no") {
	$visible_checked = "checked=\"checked\"";
}

// Default accept priv
$acceptpriv_checked = "";
if ($acceptpriv != "no") {
	$acceptpriv_checked = "checked=\"checked\"";
}

// Default email notifications
$notify_checked = "";
if ($notify != "Off") {
	$notify_checked = "checked=\"checked\"";
}

$tabs = array(
	"{$ubbt_lang['USER_INFO']}" => "",
	"{$ubbt_lang['PERMS']}" => "",
	"{$ubbt_lang['FIELDS']}" => "",
	"{$ubbt_lang['PREFS']}" => "",
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['MEM_MAN']);
$admin->setReturnTab($returntab);
$admin->setParentTitle($ubbt_lang['MEM_MAN'],"membermanage.php");
$admin->setPageTitle($ubbt_lang['EDIT_PROF']);
$admin->sendHeader();
$admin->createTopTabs($tabs,$returntab);
$admin->setCommonSubmit($ubbt_lang['UPDATE_USER']);

// Include the template
include("../templates/default/admin/showuser.tmpl");

if ($banned) {
	$loginas = "javascript:void(0)\" onclick=\"nobecomeban()\"";
}
elseif ($config['COOKIE_PATH'] == "/") {
	$loginas = "{$config['BASE_URL']}/admin/loginas.php?uid=$uid";
}
else {
	$loginas = "javascript:void(0)\" onclick=\"nobecome()\"";
}

if ($uid != $user['USER_ID']) {
	if ($user['USER_MEMBERSHIP_LEVEL'] == "Administrator") {
		$bottomtabs = array(
			"{$ubbt_lang['DELETE_USER']}" => "{$config['BASE_URL']}/admin/deleteuser.php?uid=$uid",
			"{$ubbt_lang['SEND_PASS']}" => "{$config['BASE_URL']}/admin/sendpassword.php?uid=$uid",
			"{$ubbt_lang['BECOME_USER']}" => "$loginas",
			"{$ubbt_lang['MERGE_USER']}" => "{$config['BASE_URL']}/admin/mergeuser.php?uid=$uid",
			"{$ubbt_lang['VIEW_PROFILE']}" => make_ubb_url("ubb=showprofile&User=$uid", $dname, false),
			"{$ubbt_lang['SEND_PM']}" => make_ubb_url("ubb=sendprivate&User=$uid", "", false),
			"{$ubbt_lang['VIEW_POSTS']}" => make_ubb_url("ubb=userposts&id=$uid", "", false),
		);
	}
	else {
		$bottomtabs[$ubbt_lang['SEND_PASS']] = "{$config['BASE_URL']}/admin/sendpassword.php?uid=$uid";
	}
	$admin->createBottomTabs($bottomtabs);
}

$admin->sendFooter();
?>
