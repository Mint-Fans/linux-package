<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");
require ("../languages/{$config['LANGUAGE']}/admin/view_subscriptions.php");

// Get the input
$returntab = get_input("returntab","both");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

$id = get_input("id","get","int");

$query = "
	select t1.SUBSCRIPTION_ID,t2.USER_DISPLAY_NAME,t3.SUBSCRIPTION_NAME,t1.SUBSCRIPTION_START_DATE,t1.SUBSCRIPTION_END_DATE,SUBSCRIPTION_STATUS,SUBSCRIPTION_IS_ACTIVE,SUBSCRIPTION_PAYMENT,t1.USER_ID,t1.CUSTOM_ID,t3.GROUP_ID
	from {$config['TABLE_PREFIX']}SUBSCRIPTION_DATA as t1,
	{$config['TABLE_PREFIX']}USERS as t2,
	{$config['TABLE_PREFIX']}SUBSCRIPTIONS as t3
	where t1.SUBSCRIPTION_ID = ?
	and t1.USER_ID = t2.USER_ID
	and t1.GROUP_ID = t3.GROUP_ID
";
$sth = $dbh->do_placeholder_query($query,array($id),__LINE__,__FILE__);
list($invoice,$user,$name,$start,$end,$status,$active,$payment,$uid,$custom,$group_id) = $dbh->fetch_array($sth);

if ($active) {
	$active = $ubbt_lang['TEXT_YES'];
} else {
	$active = $ubbt_lang['TEXT_NO'];
}

if (!$end) {
	$end = $ubbt_lang['NO_END'];
} else {
	$end = $html->convert_time($end);
}

if (!$start) {
	$start = $ubbt_lang['NOT_STARTED'];
} else {
	$start = $html->convert_time($start);
}

// Grab the paypal history
if ($payment == "paypal") {
	$query = "
		select *
		from {$config['TABLE_PREFIX']}PAYPAL_DATA
		where CUSTOM_ID = ?
		order by LOG_ID desc
	";
	$sth = $dbh->do_placeholder_query($query,array($custom),__LINE__,__FILE__);
	while($history[] = $dbh->fetch_array($sth,MYSQL_ASSOC)) {
		// Boo!
	} // end while
} elseif ($payment == "check") {
	$query = "
		select *
		from {$config['TABLE_PREFIX']}CHECK_DATA
		where CUSTOM_ID = ?
		order by LOG_ID desc
	";
	$sth = $dbh->do_placeholder_query($query,array($custom),__LINE__,__FILE__);
	while($history[] = $dbh->fetch_array($sth,MYSQL_ASSOC)) {
		// Boo!
	} // end while

	foreach($history as $k => $v) {
		if ($history[$k]) {
			$history[$k]['PAYMENT_DATE'] = $html->convert_time($history[$k]['PAYMENT_DATE']);
		} else {
			unset($history[$k]);
		}
	}
}

$tabs = array(
	"{$ubbt_lang['SUB_DETAILS']}" => "",
);

// Create the Page
$admin->setCurrentMenu($ubbt_lang['VIEW_SUBS']);
$admin->setReturnTab($returntab);
$admin->setParentTitle($ubbt_lang['VIEW_SUBS'],"view_subscriptions.php");
$admin->setPageTitle($ubbt_lang['SUB_DETAILS']);
$admin->sendHeader();
$admin->createTopTabs($tabs);

// Include the template
include("../templates/default/admin/sub_history.tmpl");

$admin->sendFooter();
?>
