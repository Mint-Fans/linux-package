<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","both");

// -----------------
// Get the user info
$userob = new user;
$user = $userob->authenticate();

$admin = new Admin;
$admin->doAuth();

foreach($_POST['single_rss'] as $feed => $forum_id) {
	$cache = $_POST['single_cache'][$feed];
	$active = $_POST['single_active'][$feed];
	$name = stripslashes($_POST['single_name'][$feed]);
	if (!$cache) {$cache = 5; }
	$cache = $cache * 60;
	if (!$active) $active = 0;
	$query_vars = array($active,$cache,$name,$feed);
	$query = "
		update {$config['TABLE_PREFIX']}RSS_FEEDS
		set FEED_IS_ACTIVE = ? ,
				FEED_CACHE_TIME = ? ,
				FEED_NAME = ?
		where FEED_ID = ?
	";
	$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);

	$query_vars = array($active,$name,$forum_id);
	$query = "
		update {$config['TABLE_PREFIX']}FORUMS
		set FORUM_IS_RSS = ? ,
				FORUM_RSS_TITLE = ?
		where FORUM_ID = ?
	";
	$dbh->do_placeholder_query($query,$query_vars,__LINE__,__FILE__);
}

generate_rss_feeds(1);

// What config vars are we updating?
$newconfig = array("MY_FEEDS");

// Update the config file
include("doeditconfig.php");

// ---------------
// Log this action
admin_log("RSS","$log_diffs");

$admin->redirect($ubbt_lang['RSS_UPDATED'],"{$config['BASE_URL']}/admin/rss.php?returntab=$returntab",$ubbt_lang['RSS_F_LOC']);
?>