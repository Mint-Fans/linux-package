<?php
//	Script Version 7.5.9

// Require the library
require ("../libs/admin.inc.php");
require ("../languages/{$config['LANGUAGE']}/admin/generic.php");

// -------------
// Get the input
$returntab = get_input("returntab","post");
$DEFAULT_STYLESHEET = get_input("DEFAULT_STYLESHEET","post");

// -----------------
// Get the user info

$userob = new user;
$user = $userob -> authenticate("USER_DISPLAY_NAME");

$admin = new Admin;

$admin->doAuth();

// What theme vars are we updating?
$newconfig = array("DEFAULT_STYLE");

$query = "
	select STYLE_ID,STYLE_IS_ACTIVE
	from {$config['TABLE_PREFIX']}STYLES
";
$sth = $dbh->do_query($query,__LINE__,__FILE__);
$active_array = $_POST['active'];

while(list($id,$active) = $dbh->fetch_array($sth)) {
	if (isset($active_array[$id])) {
		$new_active = $active_array[$id];
	} else {
		$new_active = 0;
	}

	if ($active != $new_active) {
		$query = "
			update {$config['TABLE_PREFIX']}STYLES
			set STYLE_IS_ACTIVE = ?
			where STYLE_ID = ?
		";
		$dbh->do_placeholder_query($query,array($new_active,$id),__LINE__,__FILE__);
	}
}

// Update the config file
include("doeditconfig.php");

// Update the cache file
build_forum_cache();

$admin->redirect($ubbt_lang['STYLES_UPDATED'],"{$config['BASE_URL']}/admin/styles.php?returntab=$returntab",$ubbt_lang['STYLES_F_LOC']);

?>
