<?php defined('UBB_MAIN_PROGRAM') or exit;
//	Script Version 7.5.9

// Change this to something other than 30 if you'd like.
// You'll also want to change the TOP_POSTERS_30 language string
// in the portal_islands.php language file
$days = 30;

$today = $html->get_date();
$limittime = ($today - (86400 * $days));

$query = "
	SELECT	u.USER_ID, u.USER_DISPLAY_NAME, count(*) as total,
		up.USER_NAME_COLOR, u.USER_MEMBERSHIP_LEVEL
	FROM	{$config['TABLE_PREFIX']}USERS as u,
		{$config['TABLE_PREFIX']}USER_PROFILE as up,
		{$config['TABLE_PREFIX']}POSTS as p
	WHERE	u.USER_ID <> 1 AND u.USER_ID = up.USER_ID AND
		u.USER_IS_APPROVED = 'yes' AND u.USER_IS_BANNED <> 1
	AND u.USER_ID = p.USER_ID
	AND p.POST_POSTED_TIME > $limittime
	GROUP BY u.USER_ID
	ORDER BY total DESC
	LIMIT	{$config['TOP_POSTERS']}
";
$sth = $dbh->do_query($query, __LINE__, __FILE__);
$users = array();
$i = 0;
while(list($uid,$username,$total,$namecolor,$memberlevel) = $dbh->fetch_array($sth)) {
	$users[$i]['namecolor'] = $html->user_color($username, $namecolor, $memberlevel);
	$users[$i]['name'] = $username;
	$users[$i]['posts'] = $total;
	$users[$i]['uid'] = $uid;
	$i++;
} // end while


$smarty->assign("users",$users);

$island = $smarty->fetch("island_top_posters_30.tpl");

lock_and_write("{$config['FULL_PATH']}/cache/top_posters_30.php",$island);

@chmod("{$config['FULL_PATH']}/cache/top_posters_30.php",0666);

?>
