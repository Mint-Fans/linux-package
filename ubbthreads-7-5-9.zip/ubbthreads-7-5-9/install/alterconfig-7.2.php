<?php

$newconfigs['GRAPHICS_LIBRARY'] = 'gd';
$newconfigs['MAX_THUMB_W_H'] = 125;
$newconfigs['MAX_MEDIUM_W_H'] = 450;
$newconfigs['MAX_FULL_W_H'] = 1200;
$newconfigs['MAX_GALLERY_UPLOAD'] = "1048576";
$newconfigs['THUMB_QUALITY'] = 60;
$newconfigs['MEDIUM_QUALITY'] = 70;
$newconfigs['FULL_QUALITY'] = 80;
$newconfigs['POST_LAYOUT'] = 'side';
$newconfigs['ENABLE_MOODS'] = 1;
$newconfigs['BIRTHDAY_NOTICE'] = 1;

?>