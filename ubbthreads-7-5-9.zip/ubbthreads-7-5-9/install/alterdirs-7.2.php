<?php

$newdirs['0'] = "tmp";
$newdirs['1'] = "gallery";
$newdirs['2'] = "gallery/default/full";
$newdirs['3'] = "gallery/default/medium";
$newdirs['4'] = "gallery/default/thumbs";

?>