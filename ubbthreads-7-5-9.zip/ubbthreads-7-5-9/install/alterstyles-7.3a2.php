<?php

$newstyles['.email-header']['set'] = "background: #0066A7;
color: #F0F0F0;
font-size: 10pt;
padding:4px;
border-bottom: 1px solid #224988;
text-align:center;";
$newstyles['.email-tdheader']['set'] = "padding: 4px 6px;
color: #E0E0E0;
background: #2E669A;
border: 1px solid #224988;
border-bottom: 0px;
font-size: 10pt;";
$newstyles['.email-tdbody']['set'] = "background: #E9F5F7;
color: #000;
padding: 4px 6px;
border: 1px solid #224988;
font-size: 10pt;";
$newstyles['.email-footer']['set'] = "background: #0066A7;
color: #F0F0F0;
font-size: 10pt;
padding:4px;
border-top: 1px solid navy;
text-align:center;";
$newstyles['.email-body']['set'] = " background: #FDFBE7;
color: #F0F0F0;
padding: 4px;
border-collapse: collapse;
border: 1px solid #0F0F0F;
font-family: Verdana, Arial, Helvetica, sans-serif;";

?>