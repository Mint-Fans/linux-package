<?php

$newstyles['.search_highlight']['set'] = "background: #FFFF00;
color: #000000;";

?>