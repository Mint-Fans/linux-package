<?php

include ("altertable.inc.php");

echo "<table border='0' width='70%' align='center'>";

// Check if we need to pick up at a certain step
$query = "
	SELECT LAST_ALTER_STEP
	FROM {$config['TABLE_PREFIX']}VERSION
";
$sth = $dbh->do_query($query);
list($thisstep) = $dbh->fetch_array($sth);

if (!$thisstep) {
	$thisstep = 1;
}

// How many steps in this altertable?
$totalsteps = 15;
for($i=$thisstep;$i<=$totalsteps;$i++) {
	if (!defined('DIDFAIL')) {
		ob_start();
		step_start($i);
		$whichstep = "";
		$whichstep = "alterstep$i";
		$whichstep();
		if (function_exists('ob_flush')) {
			ob_flush();
		}
		else {
			ob_end_flush();
		}
	}
}

if (!defined('DIDFAIL')) {
	step_stop();
}

//  All database updates go here
function alterstep1() {
}

function alterstep2() {
	global $config;
	$query = "
		ALTER TABLE {$config['TABLE_PREFIX']}ONLINE
		ADD 	ONLINE_AGENT varchar(255),
		ADD	ONLINE_REFERER varchar(255),
		ADD	INDEX Ondx3 (USER_ID)
	";
	$sth = do_query($query,"Adding fields to {$config['TABLE_PREFIX']}ONLINE to store agent and referer variables.  Also adding an index to the USER_ID in this table...");
}

function alterstep3() {
	global $config;
	$query = "
		create table {$config['TABLE_PREFIX']}SEARCH_AGENTS (
			AGENTS text
		) ENGINE=MyISAM
	";
	$sth = do_query($query,"Creating a new table, {$config['TABLE_PREFIX']}SEARCH_AGENTS}, to store what Agent each Search Engine users...");
}

function alterstep4() {
        global $config;

        $agents = <<<EOF
Alexa=ia_archiver
Altavista=Scooter
AllTheWeb=FAST-WebCrawler
Excite=ArchitextSpider
Google=Googlebot
Yahoo=Yahoo! Slurp
Inktomi=Slurp
MSN=MSNBOT
EOF;

        $query = "
                insert into {$config['TABLE_PREFIX']}SEARCH_AGENTS
                values ('$agents')
        ";
        $sth = do_query($query,"Inserting several Search Agents into the {$config['TABLE_PREFIX']}SEARCH_AGENTS} table...");

}

function alterstep5() {
        global $config;
        $query = "
                alter table {$config['TABLE_PREFIX']}USER_PROFILE
                add USER_CUSTOM_TITLE varchar(255),
		add USER_LANGUAGE varchar(50),
		add USER_MOOD varchar(50),
        	add USER_REPORT_POST_NOTIFY tinyint(1) not null default '0',
		add USER_RELATIVE_TIME tinyint(1)

        ";
        $sth = do_query($query,"Adding a Language, Custom Title and Mood field to the {$config['TABLE_PREFIX']}USER_PROFILE table...");
}

function alterstep6() {
        global $config;
        $query = "
                alter table {$config['TABLE_PREFIX']}GROUPS
                add GROUP_CUSTOM_TITLE tinyint(1) default '0'
        ";
        $sth = do_query($query,"Adding a Custom Title field to the {$config['TABLE_PREFIX']}USER_PROFILE table...");
}

function alterstep7() {
        global $config;
        $query = "
		alter table {$config['TABLE_PREFIX']}ONLINE type=heap
        ";
        $sth = do_query($query,"Converting {$config['TABLE_PREFIX']}ONLINE to a memory (heap) table...");
}

function alterstep8() {
        global $config;
        $query = "
		alter table {$config['TABLE_PREFIX']}TOPIC_VIEWS type=heap
        ";
        $sth = do_query($query,"Converting {$config['TABLE_PREFIX']}TOPIC_VIEWS to a memory (heap) table...");
}

function alterstep9() {
	global $config;
	$query = "
        	create table {$config['TABLE_PREFIX']}POINTER_DELETE (
                	TOPIC_ID int(9) unsigned not null,
                	DELETE_ON int(11) unsigned not null,
                	index ndx1 (TOPIC_ID),
                	index ndx2 (DELETE_ON)
        	) ENGINE=MyISAM
	";
	$sth = do_query($query,"Creating new table {$config['TABLE_PREFIX']}POINTER_DELETE to store deletion date of pointers for moved topics...");
}

function alterstep10() {
	global $config;
	$query = "
        	create table {$config['TABLE_PREFIX']}BANNED_USERS (
        	USER_ID int(9) not null,
        	BAN_EXPIRATION int(11),
        	BAN_REASON text,
        	UNIQUE user_ndx (USER_ID)
        	) ENGINE=MyISAM
	";
	$sth = do_query($query,"Creating new table {$config['TABLE_PREFIX']}BANNED_USERS to store expiration time of bans.");
}

function alterstep11() {
	global $config,$dbh;
	$query = "
		select USER_DISPLAY_NAME,USER_ID
		from {$config['TABLE_PREFIX']}USERS
		where USER_IS_BANNED='1'
	";
	$sth = do_query($query,"Grabbing banned users...");

	while(list($uname,$uid) = $dbh->fetch_array($sth)) {
		$query = "
			insert into {$config['TABLE_PREFIX']}BANNED_USERS
			(USER_ID,BAN_EXPIRATION)
			values
			('$uid','0')
		";
		do_query($query,"Adding $uname to BANNED_USERS table as a permanent ban...");
	}
}

function alterstep12() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}POSTS
		add POST_LAST_EDIT_REASON varchar(255)
	";
	$sth = do_query($query,"Adding a field to the {$config['TABLE_PREFIX']}POSTS table to store a reason a post has been edited...");
}

function alterstep13() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}TOPICS
		add index TOPIC_LAST_REPLY_NDX (TOPIC_LAST_REPLY_TIME)
	";
	$sth = do_query($query,"Adding a new index to the {$config['TABLE_PREFIX']}TOPICS table that will be used by the revamped Active Topics featre...");

}

function alterstep14() {
	global $config;
	$query = "
	create table {$config['TABLE_PREFIX']}CAPTCHA (
		CAPTCHA_ID varchar(32) not null primary key,
		CAPTCHA_TIMESTAMP int(11)
	) ENGINE=MyISAM
	";
	do_query($query,"Adding a new table, {$config['CAPTCHA']}, to make sure CAPTCHA image creation is called correctly...");
}

function alterstep15() {
	global $config;
	$query ="
		alter table {$config['TABLE_PREFIX']}FORUMS
		add FORUM_GUEST_CAPTCHA varchar(2)
	";
	do_query($query,"Adding a field to the FORUMS table to store CAPTCHA verification for guest posts...");
}

?>