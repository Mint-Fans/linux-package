<?php

include ("altertable.inc.php");

echo "<table border='0' width='70%' align='center'>";

// Check if we need to pick up at a certain step
$query = "
	SELECT LAST_ALTER_STEP
	FROM {$config['TABLE_PREFIX']}VERSION
";
$sth = $dbh->do_query($query);
list($thisstep) = $dbh->fetch_array($sth);

if (!$thisstep) {
	$thisstep = 1;
}

// How many steps in this altertable?
$totalsteps = 3;
for($i=$thisstep;$i<=$totalsteps;$i++) {
	$refresh = 0;
	if (!defined('DIDFAIL')) {
		ob_start();
		step_start($i);
		$whichstep = "";
		$whichstep = "alterstep$i";
		$refresh = $whichstep();
		if ($refresh && !defined('DIDFAIL')) {
			$currenstep = $i;
			break;
		}
		if (function_exists('ob_flush')) {
			ob_flush();
		}
		else {
			ob_end_flush();
		}
	}
}

if (!defined('DIDFAIL')) {
	step_stop();
}

//  All database updates go here
function alterstep1() {
}

function alterstep2() {
	global $config,$dbh;
	$query = "
	CREATE TABLE {$config['TABLE_PREFIX']}BBCODE (
		BBCODE_ID int(4) NOT NULL auto_increment,
		BBCODE_MENU_SHOW tinyint(1) NOT NULL default '1',
		BBCODE_ENABLE tinyint(1) NOT NULL default '1',
		BBCODE_DESCRIPTION varchar(128) default NULL,
		BBCODE_MENU_PROMPT varchar(128) default NULL,
		BBCODE_TAG varchar(64) default NULL,
		BBCODE_MATCH_REGEX varchar(255) default NULL,
		BBCODE_MARKUP_RESULT text default NULL,
		BBCODE_MENU_ORDER int(4) NOT NULL default '0',
		UNIQUE KEY BBCODE_ndx (BBCODE_ID,BBCODE_ENABLE)
	) ENGINE=MyISAM
	";
	$sth = do_query($query,"{$config['TABLE_PREFIX']}BBCODE table created.");
	include("{$config['FULL_PATH']}/install/custom_codes/tags.php");
	$order = 0;

	foreach($export_tags as $custom) {
		$tag = $custom['tag'];
		$descrip = $custom['descrip'];
		$prompt = $custom['prompt'];
		$regex = $custom['regex'];
		$markup = $custom['markup'];
		$query = "
			INSERT INTO {$config['TABLE_PREFIX']}BBCODE
			(BBCODE_MENU_ORDER, BBCODE_MENU_SHOW, BBCODE_ENABLE, BBCODE_TAG, BBCODE_DESCRIPTION,BBCODE_MENU_PROMPT, BBCODE_MATCH_REGEX, BBCODE_MARKUP_RESULT)
			VALUES
			( ? , ? , ? , ? , ? , ? , ? , ? )
		";
		$dbh->do_placeholder_query($query,array($order,1,1,$tag,$descrip,$prompt,$regex,$markup));
		$order++;
	}

	build_custom_tag_cache();
}

function alterstep3() {
	global $config;
	$query = "
		alter table {$config['TABLE_PREFIX']}USER_PROFILE
		add USER_SHOW_LEFT_MYSTUFF tinyint(1) not null default '0'
	";
	do_query($query,"Adding a new field to the {$config['TABLE_PREFIX']}USER_PROFILE table.");
}

?>