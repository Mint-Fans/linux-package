<?php
//	Script Version 7.5.9

$metarefresh = "";
$step_navigation = "";
require("install_header.tmpl");

// suhosin Check by VNC Web Services (http://www.virtualnightclub.net/)
if(extension_loaded("suhosin") && ini_get("suhosin.get.max_value_length")) {
	if(ini_get("suhosin.get.max_value_length") <= 2048) {
		$suhosin = "<span style=\"color:#CC0000;\">You may experience issues with a blank configuration file if you continue, please see <a href=\"http://www.ubbwiki.com/article/view/16/issues-with-suhosin.html\" target=\"_blank\">UBB.Wiki: Issues with suhosin</a>; this issue pertains to the settings of the suhosin module with your webhost.  Your current suhousin length is: ". ini_get("suhosin.get.max_value_length") .".</span><br /><br />";
	} else {
		$suhosin = "";
	}
}

echo "<table border='0' width='95%' align='center'>";
echo "<tr><td class=\"stdautorow\">";
echo $suhosin;
echo "If you are doing an initial install of UBB.threads&#8482;, <a href='install.php'>Go here</a>.<br /><br />";
echo "If you are upgrading UBB.threads&#8482; from a previous version, <a href='upgrade.php'>Go here</a>.";
echo "</td></tr>";
echo "</table>";
require("install_footer.tmpl");

?>