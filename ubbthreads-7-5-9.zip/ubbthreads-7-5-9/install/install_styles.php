<?php
//	Script Version 7.5.9

$dir = opendir("{$config['FULL_PATH']}/install/styles");

while( ($fh = readdir($dir)) != false) {
	if ($fh == "." || $fh == "..") continue;

	$file = file_get_contents("{$config['FULL_PATH']}/install/styles/$fh");


	preg_match("/--STYLE_DETAILS--(.*)--END_STYLE_DETAILS--/sm",$file,$content);
	$style_details = $content[1];

	preg_match("/--STYLE_VARS--(.*)--END_STYLE_VARS--/sm",$file,$content);
	$style_vars = $content[1];

	preg_match("/--IMAGE_VARS--(.*)--END_IMAGE_VARS--/sm",$file,$content);
	$image_vars = $content[1];

	preg_match("/--WRAPPER_SET--(.*)--END_WRAPPER_SET--/sm",$file,$content);
	$wrapper_set = "";
	if (isset($content[1])) {
		$wrapper_set = $content[1];
	}


	preg_match("/STYLE_NAME:(.*)/",$style_details,$content);
	$style_name = trim($content[1]);

	preg_match("/WRAPPER_ID:(.*)/",$style_details,$content);
	$wrapper_id = trim($content[1]);

	$style_vars = preg_replace("#FULL_URL#",$config['FULL_URL'],$style_vars);

	eval("\$style_array = $style_vars");

	$css_file = "";
	foreach($style_array as $class => $properties) {
		$css_file .= "$class {\r\n$properties\r\n}\r\n";
	}

	eval("\$image_array = $image_vars");

	if ($wrapper_set) {
		$wrapper_set = preg_replace("#FULL_URL#",$config['FULL_URL'],$wrapper_set);
		eval("\$wrapper_array = $wrapper_set");
		include("{$config['FULL_PATH']}/styles/wrappers.php");
		$wrappers[] = $wrapper_array;
		foreach($wrappers as $key => $value) {
			$wrapper_id = $key;
		}

		$wrapper_file = "<?php\n\$wrappers = " . var_export($wrappers,true) . "?>\n";
		$check = lock_and_write("{$config['FULL_PATH']}/styles/wrappers.php",$wrapper_file);
		if ($check == "no_write") {
			$admin->error($ubbt_lang['NO_WRITE_WRAPPERS']);
		}
	}

	$time = time();
	$query = "
		insert into {$config['TABLE_PREFIX']}STYLES
		(STYLE_NAME,STYLE_IMG,STYLE_EDITED_TIME,STYLE_VARS,STYLE_WRAPPERS,STYLE_IS_ACTIVE)
		values
		( ? , ? , ? , ? , ? , ? )
	";
	$dbh->do_placeholder_query($query,array($style_name,serialize($image_array),$time,serialize($style_array),$wrapper_id,1));

	$query = "
		select last_insert_id()
	";
	$sth = $dbh->do_query($query,__LINE__,__FILE__);
	list($style_id) = $dbh->fetch_array($sth);

	$css_name = "{$style_name}_{$time}.css";


	$new_style_array = <<<THE_YELLOW_BRICK_ROAD
<?php
\$style_array = array(
	"id" => '$style_id',
	"general" => "{$image_array['general']}",
	"avatars" => "{$image_array['avatars']}",
	"forumimages" => "{$image_array['forumimages']}",
	"graemlins" => "{$image_array['graemlins']}",
	"icons" => "{$image_array['icons']}",
	"markup_panel" => "{$image_array['markup_panel']}",
	"news" => "{$image_array['news']}",
	"wrappers" => $wrapper_id,
	"css" => "$css_name"
);
?>
THE_YELLOW_BRICK_ROAD;

	$check = lock_and_write("{$config['FULL_PATH']}/styles/$style_id.php",$new_style_array);
	if ($check == "no_write") {
		error("Cannot open {$config['FULL_PATH']}/styles/$style_id.php for writing");
	}

	$check = lock_and_write("{$config['FULL_PATH']}/styles/$css_name",$css_file);
	if ($check == "no_write") {
		$error("Cannot open {$config['FULL_PATH']}/styles/$css_name for writing");
	}
}

?>