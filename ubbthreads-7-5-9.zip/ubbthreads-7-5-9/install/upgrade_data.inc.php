<?php
//	Script Version 7.5.9

$file_list = array(
/********FILE_LIST_ARRAY_START********/
/********FILE_LIST_ARRAY_END********/
);


function upgrade_db_7000_85_to_7000_90_1 () {

	global $dbh, $config;

	$query = <<<QUERY
-- upgrade_db_7000_85_to_7000_90_1

alter table {$config['TABLE_PREFIX']}USER_PROFILE

add USER_START_VIEW varchar(20) not null default 'cfrm',
add USER_FAVORITES_TAB varchar(10) not null default 'forums',
add USER_FAVORITES_SORT varchar (10) not null default 'reply',
add USER_SHOW_AVATARS tinyint(1) not null default '1',

drop column USER_SHOW_AVATARS_IN_PROFILES,
drop column USER_SHOW_AVATARS_WITH_POSTS,
drop column USER_TEXT_AREA_COLUMNS,
drop column USER_TEXT_AREA_ROWS,
drop column USER_PREFERRED_STYLE_SHEET,
drop column USER_POST_PREVIEW_ON
QUERY;

	$dbh->do_query($query);
}

?>