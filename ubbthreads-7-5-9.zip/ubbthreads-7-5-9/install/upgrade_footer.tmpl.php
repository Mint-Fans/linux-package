<?php
echo <<<EOF
</td></tr></table>
<br />

<!-- Copyright -->

<table width="95%" align="center">
<tr><td align="center" class="smallrow" style="color: #838383;"><!--
<br />
<a href="http://www.ubbcentral.com/landing/goto.php?a=UBB.threads">Powered by UBB.threads&#8482;</a><br />

UBB.threads&#8482;

-->
</td></tr></table>

<!-- <div style="width: 600px; height: 4px; font-size: 3px;"> &nbsp; </div> -->

</center>
</td>

</tr>
</tbody></table>
</td>
</tr>
<tr>
<td colspan="3" bgcolor="#3399cc" style="border-top: 1px solid black;">
<table width="100%"><tbody>
<tr>
<td width="75%">
<span class="u_small" style="color: rgb(255, 255, 255);">
<a href="http://www.ubbcentral.com/" class="u_footer_links">UBBCentral.com</a> |
<a href="http://www.ubbcentral.com/cgi-bin/directme.cgi?to=threadsmembers" class="u_footer_links">UBB.threads&#8482; Member Area</a> |
<a href="http://www.ubbcentral.com/cgi-bin/directme.cgi?to=threadssupport" class="u_footer_links">Documents &amp; Support</a>
</span>
</td>
<td width="25%" align="right"><span class="u_small" style="color: rgb(255, 255, 255);"><a href="javascript:scrollTo(0, 0)" class="u_footer_links">Top of Page</a></span></td>
</tr>
</tbody></table>
</td>
</tr>
</tbody></table>

</body></html>
EOF;
?>