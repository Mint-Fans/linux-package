<?php
//	Script Version 7.5.9

echo <<<EOF
<!-- START OF header.tmpl TEMPLATE -->
<html dir="ltr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
$metarefresh
<link rel="stylesheet" href="css/styles.css" />
<title>UBB.threads Upgrade Utility</title>

</head>

<body bgcolor="#e9e9ca" text="#333333" link="#336699" vlink="#336699" alink="#336699" style="margin: 0px; padding: 0px;">

<table cellspacing="0" cellpadding="0" border="0" width="100%" height="100%"><tbody>
	<tr>
		<td background="css/cp_menu_bg_large.gif" rowspan="2" bgcolor="#a7a400" width="125"><a href="http://www.ubbcentral.com/" target="_blank"><img src="css/cp_logo_top.gif" width="125" height="82" border="0" alt="UBB"></a></td>
		<td width="33" rowspan="2" style="background-color: #82b5e8; background-image: url('css/cp_menu_bg.gif'); background-position: bottom left; background-repeat: repeat-x;"><img src="css/cp_logo_left.gif" width="33" height="82" border="0" alt=""></td>
		<td bgcolor="#82b5e8" align="right" valign="top" width="100%">&nbsp;<!-- <a href="http://www.UBB.threads.com/" target="_blank"><img src="css/cp_ip_logo.gif" width="125" height="19" border="0" alt="Powered by UBB"></a> --></td>
	</tr>
	<tr>
		<td align="center" valign="bottom" style="background-color: #82b5e8; background-image: url('css/cp_menu_bg.gif'); background-position: bottom left; background-repeat: repeat-x;" width="100%" nowrap="nowrap">&nbsp;</td>
	</tr>
	<tr>
		<td width="125" valign="top" height="100%" align="right">
			<table width="125" height="100%" border="0" cellspacing="0" cellpadding="0" align="left"><tbody>
				<tr>
					<td valign="top" background="css/cp_left_nav_grey_bg.gif" height="100%">
						<table border="0" cellspacing="0" cellpadding="0" height="100%"><tbody>
							<tr>
								<td valign="top"><table border="0" cellspacing="0" cellpadding="0"><tbody>
										<tr>
											<td valign="top" background="css/cp_left_nav_corner_bg.gif"><a href="http://www.ubbcentral.com/" target="_blank"><img src="css/cp_logo_bottom.gif" width="121" height="27" border="0" alt=""></a></td>
											<td background="css/cp_left_nav_corner_side.gif" rowspan="2"><img src="css/cp_left_nav_corner_side.gif" width="4" height="3" border="0" alt=""></td>
										</tr>
										<tr>
											<td background="css/cp_left_nav_corner_bg.gif">&nbsp;</td>
										</tr>
								</tbody></table></td>
							</tr>
							<tr>
								<td>
								</td>
							<tr>
								<td height="3" valign="bottom" background="css/cp_left_nav_grey_bg.gif"><img src="css/cp_left_nav_head_top.png" width="125" height="3" alt="" /></td>
							</tr>
							<tr>
								<td height="100%" valign="bottom" background="css/cp_left_nav_grey_bg.gif"><br /><img src="css/cp_city_left.png" width="125" height="179" border="0" alt=""></td>
							</tr>

						</tbody></table><!-- end nav -->
					</td>
				</tr>
			</tbody></table>
		</td>
		<td bgcolor="#e9e9ca" width="100%" valign="top" colspan="2" align="center">
			<table bgcolor="#333329" width="100%" cellspacing="0" cellpadding="3"><tbody>
				<tr>
					<td style="padding-left: 10px;">
						<span class="u_small" style="color: rgb(233, 233, 202);">
						UBB.threads&#8482; Upgrade/Install Utility
						</span>
					</td>
				</tr>
			</tbody></table>
			<table width="97%" cellpadding="3"><tbody>
				<tr>
					<td>
						<center>
<br />
<table width="95%" border="0" cellspacing="0" align="center" style="margin-left: auto; margin-right: auto;" class="hiddenfornow" id="main-container-table">
<tr>
<td width="100%" align="left" class="stdautorow">
EOF;
?>