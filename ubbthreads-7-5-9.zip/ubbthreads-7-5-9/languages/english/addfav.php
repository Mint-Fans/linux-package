<?php
$ubbt_lang['REM_FAV'] = "The selected topic or post has been removed from your Watched Topic list.";
$ubbt_lang['ENTRY_OUT'] = "Post/Topic removed.";
$ubbt_lang['NO_PERM'] = "You do not have permission to view this topic. You cannot add it to your Watched Topic list.";
$ubbt_lang['MAIN_ONLY'] = "You can only add main topics to your Watched Topic list.";
$ubbt_lang['DUP_ENTRY'] = "This has already been added to your Watched Topics.";
$ubbt_lang['ENTRY_IN'] = "Post/Topic added.";
$ubbt_lang['FAV_CONFIRM'] = "The selected post/topic has been added to your list.";
$ubbt_lang['FORUM_RETURN'] = "Return to topic now.";
?>