<?php
$ubbt_lang['NO_PERM'] = "You do not have permission to view this forum. You cannot add it to your Watched Forum list.";
$ubbt_lang['FORUM_IN'] = "Forum added.";
$ubbt_lang['FORUM_OUT'] = "Forum removed.";
$ubbt_lang['FORUM_CONFIRM'] = "The selected forum has been added to your list of watched forums.";
$ubbt_lang['FORUMOUT_CONFIRM'] = "This forum has been removed from your list of watched forums.";
$ubbt_lang['FORUM_RETURN'] = "Return to forum now.";
?>