<?php
$ubbt_lang['NEW_AVATAR'] = "Add a New Avatar";
$ubbt_lang['AVATAR_FORM'] = "This form will allow you to upload a new avatar for users to choose if you are allowing them to choose an avatar for their picture. Note your {$config['FULL_PATH']}/images/{$style_array['avatars']} directory will need to be writeable by the web server for this to work.";
$ubbt_lang['AVATAR_IMAGE'] = "Avatar Image";
$ubbt_lang['P_SUBMIT'] = "Add New Avatar";
?>