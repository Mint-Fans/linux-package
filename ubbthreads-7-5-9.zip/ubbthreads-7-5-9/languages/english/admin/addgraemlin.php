<?php
$ubbt_lang['ADD_NEW'] = "Add New Graemlin";
$ubbt_lang['GRAEMLIN_FORM'] = "Graemlins are the smiley images available for use in posts. Please be sure that your /images/{$style_array['graemlins']} directory is writeable by the web server.";
$ubbt_lang['G_IMAGE'] = "Graemlin Image";
$ubbt_lang['M_STRING'] = "Markup String:";
$ubbt_lang['S_CODE'] = "Graemlin Code:";
$ubbt_lang['G_SUBMIT'] = "Add Graemlin";
$ubbt_lang['M_STRING_1'] = "This can be hardcoded, like \"smile\" so users can type :smile: or [smile] to add the smile Graemlin to their post. Please use only one word - no spaces.";
$ubbt_lang['S_CODE_1'] = "If you wish to use a shorter code, called a keystroke, such as <b>:)</b> for the new Graemlin, please enter it in this field rather than the Markup String field. This field is optional.";
?>