<?php
$ubbt_lang['F_SUBMIT'] = "Add new forum picture";
$ubbt_lang['NEW_PICON'] = "Add New Posting Icon";
$ubbt_lang['ICON_FORM'] = "Posting icons are the small icons users can assign to each post that they make. Please make sure that your /images/ directory is writeable by the web server.";
$ubbt_lang['P_ICON'] = "Posting Icon (15x15 pixels):";
$ubbt_lang['I_SUBMIT'] = "Add New Posting Icon";
$ubbt_lang['NEW_AVATAR'] = "Add New Avatar";
$ubbt_lang['AVATAR_FORM'] = "Avatars are the small pictures that users may designate to display under their names, next to each of their posts. Please make sure that your your: '%%AVVY_DIR%%' directory is writeable by the web server.";
$ubbt_lang['AVATAR_IMAGE'] = "Avatar Image:";
$ubbt_lang['A_SUBMIT'] = "Add New Avatar";
$ubbt_lang['NEW_BIMAGE'] = "Add New Forum Image";
$ubbt_lang['BIMAGE_FORM'] = "Forum Images are the small pictures that appear next to the forum name on the forum summary page. Please make sure that your /images/ directory is writeable by the web server.";
$ubbt_lang['BIMAGE'] = "Forum Image:";
$ubbt_lang['NEW_NEWSIMAGE'] = "Add New News Image";
$ubbt_lang['NEWSIMAGE_FORM'] = "News Images are images that you may choose from to go with news postings that will appear on the main portal page. Please make sure that your /images/ directory is writeable by the web server.";
$ubbt_lang['NEWS_IMAGE'] = "News Image:";
$ubbt_lang['N_SUBMIT'] = "Add New News Image";
$ubbt_lang['NEW_MOOD'] = "Add New Mood";
$ubbt_lang['MOOD_FORM'] = "Mood Images are images that users may select from to indicate their current mood while online. Please make sure that your /images/ directory is writeable by the web server.";
$ubbt_lang['MOOD_IMAGE'] = "Mood Image";
$ubbt_lang['M_SUBMIT'] = "Add New Mood";
?>