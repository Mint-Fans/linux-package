<?php
$ubbt_lang['APPROVE'] = "Approve";
$ubbt_lang['DELETE'] = "Delete";
$ubbt_lang['ACTION'] = "Action";
$ubbt_lang['NONE'] = "None";
$ubbt_lang['SUBJECT'] = "Subject";
$ubbt_lang['POSTER'] = "Poster";
$ubbt_lang['BOARD'] = "Forum";
$ubbt_lang['SUBMIT'] = "Submit";
?>