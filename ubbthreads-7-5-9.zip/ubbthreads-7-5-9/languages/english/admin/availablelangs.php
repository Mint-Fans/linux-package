<?php
$ubbt_lang['HEAD'] = "Activate/Deactivate a language";
$ubbt_lang['BODY'] = "The following languages are installed in your /languages directory.  You can find more languages at <a href=\"http://www.ubbwiki.com/archive/listing/2/ubb-threads-v7-x-language-files.html\" target=\"_blank\">UBBWiki.com</a>.";
$ubbt_lang['ACTIVE'] = "Active";
$ubbt_lang['LANGUAGE'] = "Language";
$ubbt_lang['DESCRIPTION'] = "Language Name (as seen by users)";
$ubbt_lang['UPDATE'] = "Update Languages";
$ubbt_lang['LANG_EDITOR'] = "Language Editor";
$ubbt_lang['LANG_INSTR'] = "There are two ways to edit languages: choose the language you wish to edit, then the specific file you wish to change; or search for a specific string within a language set.";
$ubbt_lang['LANG_SEARCH'] = "Search String:";
$ubbt_lang['IN'] = "Search File:";
$ubbt_lang['SEARCH_ALL'] = "Search All Files";
$ubbt_lang['CHOOSE_FILE'] = "Choose Specific Language File:";
$ubbt_lang['GO'] = "Go";
$ubbt_lang['TEXT_OR'] = "- or -";
?>