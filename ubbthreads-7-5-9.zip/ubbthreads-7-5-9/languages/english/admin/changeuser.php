<?php
$ubbt_lang['F_LOC'] = "this Member's profile.";
$ubbt_lang['NO_R_ADMIN'] = "You cannot remove administrative privileges from yourself.";
$ubbt_lang['NAME_TAKEN'] = "The new display name you have chosen is already in use by another member.";
$ubbt_lang['TOO_MANY_G'] = "This user belongs to too many groups. Normal group limit is approx. 63 groups.";
$ubbt_lang['NO_GROUPS'] = "The user must belong to at least 1 group.";
?>