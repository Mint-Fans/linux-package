<?php
$ubbt_lang['GROUP_HEAD'] = "Create New Group";
$ubbt_lang['GROUP_BODY'] = "Enter a name for the new group you want to create.";
$ubbt_lang['GROUP_NAME'] = "Group Name:";
$ubbt_lang['ADD_GROUP'] = "Add Group";
?>