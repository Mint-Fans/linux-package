<?php
$ubbt_lang['CUSTOM_BOX'] = "Custom Island #";
$ubbt_lang['BOX_NAME'] = "Name";
$ubbt_lang['CACHE_TIME'] = "Cache Time";
$ubbt_lang['STATIC'] = "Static";
$ubbt_lang['MINUTES'] = "min";
$ubbt_lang['EDIT'] = "Edit";
$ubbt_lang['ADD'] = "Add Additional Custom Island";
?>