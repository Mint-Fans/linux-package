<?php
$ubbt_lang['COMMAND'] = "SQL Command";
$ubbt_lang['INFO'] = "Information";
$ubbt_lang['BACKUP'] = "Backup Tables";
$ubbt_lang['TOTALS'] = "Totals";
$ubbt_lang['ROWS'] = "Rows";
$ubbt_lang['DATA'] = "Data";
$ubbt_lang['INDEXES'] = "Indexes";
$ubbt_lang['OPTIMIZE'] = "Optimize Table";
?>