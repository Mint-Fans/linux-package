<?php
$ubbt_lang['DELETE_FORUM'] = "Delete Forum";
$ubbt_lang['CONFIRM'] = "Are you sure you want to delete the forum '%s' and all the content within? This action can not be undone!";
$ubbt_lang['Y_DELETE'] = "Yes, delete this forum and all content within.";
$ubbt_lang['N_DELETE'] = "No, do not delete this forum.";
?>