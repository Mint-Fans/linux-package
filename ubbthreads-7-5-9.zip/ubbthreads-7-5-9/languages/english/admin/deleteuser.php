<?php
$ubbt_lang['DEL_USER'] = "Delete Member";
$ubbt_lang['CHOOSE'] = "Warning: Deleting a member can not be undone.";
$ubbt_lang['NO_DELETE'] = "Do not delete this member.";
$ubbt_lang['DELETE_1'] = "Delete member and do not alter posts. Ownership will be set to Anonymous with an Anonymous name of: ";
$ubbt_lang['DELETE_2'] = "Delete member and delete all posts. If there are any replies to a post by this member, they will be attached to the post's parent. If the user's post is a topic, the entire topic will be deleted.";
$ubbt_lang['PROCEED'] = "Continue";
?>