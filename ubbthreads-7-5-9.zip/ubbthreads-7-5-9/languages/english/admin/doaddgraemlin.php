<?php
$ubbt_lang['F_LOC'] = "the Graemlins screen.";
$ubbt_lang['NO_CODE'] = "You must provide a markup code for the Graemlin.";
$ubbt_lang['NAME_EXISTS'] = "There is already a Graemlin in /images/{$style_array['graemlins']} with the name";
$ubbt_lang['NO_MOVE'] = "We could not move the Graemlin into the /images/{$style_array['graemlins']} directory. Please fix the permissions on this directory and try again.";
$ubbt_lang['G_ADDED'] = "New Graemlin Added";
$ubbt_lang['G_CONFIRM'] = "The new Graemlin has been added.";
$ubbt_lang['NO_GRAEMLIN'] = "You did not upload a Graemlin!";
?>