<?php
$ubbt_lang['F_LOC'] = "the Member Management screen.";
$ubbt_lang['PDN_APP'] = "Display name change approved.";
$ubbt_lang['PDN_BODY'] = "Your request has been approved for the display name ";
$ubbt_lang['PDN_DEN'] = "Display name change denied.";
$ubbt_lang['DEN_BODY'] = "Your request has been denied for the display name ";
$ubbt_lang['PDN_CONFIRM'] = "Display name changes approved/deleted.";
$ubbt_lang['CONF_BODY'] = "All checked display name requests have been processed.";
$ubbt_lang['TAKEN'] = "The requested name is already in use.";
?>