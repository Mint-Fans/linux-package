<?php
$ubbt_lang['F_LOC'] = "the Member Management screen.";
$ubbt_LANG['APP_BODY_2'] = "All checked users have been approved or deleted and notified.";
$ubbt_lang['APP_BODY_2'] = "The selected action has been taken.";
?>