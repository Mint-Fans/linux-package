<?php
$ubbt_lang['NO_IMAGE'] = "You did not upload anything!";
$ubbt_lang['ICON_EXISTS'] = "There is already an image in /images/groups with the name";
$ubbt_lang['G_ADDED'] = "Group Image updated.";
$ubbt_lang['NO_MOVE'] = "Unable to write to the images/groups directory. Please check permissions and try again.";
?>