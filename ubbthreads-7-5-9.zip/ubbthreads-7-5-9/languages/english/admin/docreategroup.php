<?php
$ubbt_lang['F_LOC'] = "the Group Management screen.";
$ubbt_lang['DUP_GROUP'] = "That group name already exists. Please go back and choose another.";
$ubbt_lang['MAX_GROUP'] = "You can only have 99 groups.";
$ubbt_lang['GROUP_CONFIRM'] = "The group has been created.";
$ubbt_lang['G_ADDED'] = "New group has been added.";
?>