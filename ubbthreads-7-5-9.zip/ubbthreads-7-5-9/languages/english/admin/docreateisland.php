<?php
$ubbt_lang['NODIR'] = "Unable to create a directory in your /ContentIslands directory. Please fix the permissions on this directory and try again.";
$ubbt_lang['NOSOURCE'] = "You didn't choose a source forum!";
$ubbt_lang['NOCATS'] = "You must choose individual forums, not a category.";
$ubbt_lang['NOFORMAT'] = "You didn't choose an output format!";
?>