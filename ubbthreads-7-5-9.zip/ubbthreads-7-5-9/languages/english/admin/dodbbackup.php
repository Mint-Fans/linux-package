<?php
$ubbt_lang['COMPLETE'] = "Backup complete.";
$ubbt_lang['NOBACKUP'] = "is 0 bytes or did not get created.";
$ubbt_lang['BACKUP'] = "Backup Tables";
$ubbt_lang['BACKUP_TEXT'] = "has been backed up.";
$ubbt_lang['BODY'] = "You will need to verify that this command actually backed up the selected tables.";
$ubbt_lang['STRUCTURE'] = "Backing up table structure for";
$ubbt_lang['DATA'] = "Backing up table data for";
$ubbt_lang['COMMAND'] = "SQL Command";
$ubbt_lang['INFO'] = "Information";
$ubbt_lang['DISABLED'] = "This feature is not enabled. You need to edit your Primary Settings > Logging in order to turn this on.";
$ubbt_lang['DUMPDIR'] = "Backup directory updated.";
$ubbt_lang['F_LOC'] = "the Database Backup screen.";
$ubbt_lang['REDIR'] = "Please wait while we forward you to the Database Backup screen.";
?>