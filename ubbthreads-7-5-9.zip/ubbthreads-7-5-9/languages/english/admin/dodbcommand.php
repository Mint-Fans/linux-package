<?php
$ubbt_lang['SQL_HEAD'] = "SQL Command Results";
$ubbt_lang['SQL_RESULTS'] = "Results from your SQL command:";
$ubbt_lang['SQL_ROWS'] = "row(s) affected by your query.";
$ubbt_lang['COMMAND'] = "SQL Command";
$ubbt_lang['INFO'] = "Information";
$ubbt_lang['BACKUP'] = "Backup Tables";
$ubbt_lang['DELETED'] = "Saved query deleted.";
$ubbt_lang['SAVED'] = "Query saved.";
$ubbt_lang['F_LOC'] = "the SQL Command screen.";
$ubbt_lang['GO_BACK'] = "Execute another sql command.";
$ubbt_lang['NO_COMMAND'] = "You didn't enter a SQL command.";
$ubbt_lang['OPTIMIZED'] = "Table optimized.";
?>