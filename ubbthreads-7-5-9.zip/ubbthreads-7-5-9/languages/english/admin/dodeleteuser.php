<?php
$ubbt_lang['F_LOC'] = "this member profile.";
$ubbt_lang['F_LOC_MAIN'] = "the Control Panel Home.";
$ubbt_lang['MAIN_ADMIN'] = "You cannot view or edit the first Administrator.";
$ubbt_lang['DEL_CONF'] = "The user has been deleted.";
$ubbt_lang['NO_ACTION'] = "No action was taken on the specified member.";
$ubbt_lang['USER_DELETED'] = "Member has been deleted.";
?>