<?php
$ubbt_lang['F_LOC'] = "the Avatars screen.";
$ubbt_lang['NOREMOVE'] = "Unable to remove avatar. Please check permissions on the files in your avatars directory and try again.";
$ubbt_lang['REMOVED'] = "Avatars have been updated.";
$ubbt_lang['NO_OVERW'] = " is not writeable by the web server. Please fix the permissions on this file and try again.";
?>