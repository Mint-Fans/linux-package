<?php

$ubbt_lang['NO_WRITE'] = "cache_builders/custom/portal_box_%s is not writeable. You will either need to change the permissions on this file or edit it by hand.";
$ubbt_lang['PROBLEM'] = "There is a problem with the Body of your custom island. The PHP error was:<br /><br />%s<br /><br />Please go back and check your PHP syntax.";
?>