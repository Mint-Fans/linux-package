<?php
$ubbt_lang['F_LOC'] = "the Forum Images screen.";
$ubbt_lang['NOREMOVE'] = "Unable to remove image. Please check permissions on the files in your forumimages directory and try again.";
$ubbt_lang['REMOVED'] = "Forum images have been updated.";
$ubbt_lang['NO_OVERW'] = " is not writeable by the web server. Please fix the permissions on this file and try again.";
?>