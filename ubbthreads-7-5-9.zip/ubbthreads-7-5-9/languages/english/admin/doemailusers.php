<?php
$ubbt_lang['EMAIL_USERS'] = "Email Members";
$ubbt_lang['OPTIONS'] = "Address Export Options:";
$ubbt_lang['BROWSER'] = "Show list in browser window.";
$ubbt_lang['EMAIL_LIST'] = "Send list to me via email.";
$ubbt_lang['FORMAT'] = "Output Format:";
$ubbt_lang['ONE_PER'] = "One address per line.";
$ubbt_lang['COMMA'] = "All addresses on one line, separated by commas.";
$ubbt_lang['SEMI'] = "All addresses on one line, separated by semicolons.";
$ubbt_lang['GENERATE'] = "Create Email List";
$ubbt_lang['SEND'] = "Send Email";
$ubbt_lang['SUBJECT'] = "Subject:";
$ubbt_lang['BODY'] = "Body:";
$ubbt_lang['EXTRA_TO'] = "Default To:";
$ubbt_lang['EXTRA_TO_1'] = "All emails are sent via BCC. Some servers require at least one address in the To: field. If this is required by your server, enter a valid email address here. Multiple emails will be sent to this address depending on number of users you are sending to.";
$ubbt_lang['ONE_BY_ONE'] = "Send emails one at a time, instead of using BCC:";
$ubbt_lang['ONE_BY_ONE_1'] = "Note: This option will be slower than sending via BCC.";
?>