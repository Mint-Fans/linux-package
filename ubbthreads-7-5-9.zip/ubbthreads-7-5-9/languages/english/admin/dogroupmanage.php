<?
$ubbt_lang['NODELETE'] = "There are %%TOTAL%% users in the '%%GROUP%%' group that do not belong to any other group. You cannot delete this group until these users are reassigned to at least 1 other group.";
$ubbt_lang['DEFAULT_GROUP'] = "The '%%GROUP%%' group you are trying to delete is one of your default groups for new users. You need to remove this from your default groupis before deleting this group.";
?>