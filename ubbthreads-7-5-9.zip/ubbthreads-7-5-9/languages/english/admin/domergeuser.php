<?php
$ubbt_lang['USER_MERGED'] = "User %s has been merged with %s";
$ubbt_lang['NO_ID'] = "We could not find a user in the system with User ID %s.";
$ubbt_lang['MERGE_USER'] = "Merge User";
$ubbt_lang['CHOOSE'] = "Enter the User ID of the user you want to merge with. <b>Warning:</b> Merging a user with another cannot be undone.";
$ubbt_lang['MERGE_ID'] = "User ID";
$ubbt_lang['CONFIRM'] = "Please verify that you want to merge this user (this user will no longer exist):";
$ubbt_lang['CONFIRM2'] = "With this user (this user will still remain):";
$ubbt_lang['PROCEED'] = "Yes, merge this user";
$ubbt_lang['WRONG'] = "No, do not merge this user";
$ubbt_lang['LOGIN'] = "Username";
$ubbt_lang['DISPLAY'] = "Display Name";
$ubbt_lang['EMAIL'] = "Email";
$ubbt_lang['POSTS'] = "Posts";
$ubbt_lang['MEM_MAN'] = "the Member Management Screen.";
?>