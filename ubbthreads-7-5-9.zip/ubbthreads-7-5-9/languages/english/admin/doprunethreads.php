<?php
$ubbt_lang['COUNTER'] = "%s out of a total %s topics have been pruned at this point. %s topics that were not selected to be pruned have been excluded.";
$ubbt_lang['F_LOC'] = "the next step.";
$ubbt_lang['F_LOC_MAIN'] = "the Prune Topics screen.";
?>