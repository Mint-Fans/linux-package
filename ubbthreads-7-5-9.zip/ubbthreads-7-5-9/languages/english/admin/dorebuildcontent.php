<?php
$ubbt_lang['REBUILDING_POSTS'] = "Currently rebuilding posts %s-%s of %s total posts.";
$ubbt_lang['REBUILDING_PMS'] = "Currently rebuilding private messages %s-%s of %s total private messages.";
$ubbt_lang['REBUILDING_POST_COUNTS'] = "Currently rebuilding post counts for users %s-%s of %s total users.";
$ubbt_lang['REBUILDING_SIGNATURES'] = "Currently rebuilding signatures for users %s-%s of %s total users.";
$ubbt_lang['REBUILDING_FORUMS'] = "Currently rebuilding forums %s-%s of %s total forums.";
$ubbt_lang['REBUILDING_TOPICS'] = "Currently rebuilding topics %s-%s of %s total topics.";
$ubbt_lang['PRUNING_PRIVATE_TOPICS'] = "Currently handling private topics %s-%s of %s total private topics. Any orphaned private topics will be removed.";

$ubbt_lang['REBUILD_POSTS_COMPLETE'] = "Rebuild Complete!<br />A total of %s posts were rebuilt.";
$ubbt_lang['REBUILD_TOPICS_COMPLETE'] = "Rebuild Complete!<br />A total of %s topics were rebuilt.<br /><strong>It is recommended that you now rebuild the forums.</strong>";
$ubbt_lang['REBUILD_PMS_COMPLETE'] = "Rebuild Complete!<br />A total of %s private messages were rebuilt.";
$ubbt_lang['REBUILD_POST_COUNTS_COMPLETE'] = "Rebuild Complete!<br />The post counts of %s users were recalculated.";
$ubbt_lang['REBUILD_FORUMS_COMPLETE'] = "Rebuild Complete!<br />A total of %s forums were rebuilt.";
$ubbt_lang['REBUILD_SIGNATURES_COMPLETE'] = "Rebuild Complete!<br />The signatures of %s users were recalculated.";
$ubbt_lang['PRUNE_PRIVATE_TOPICS_COMPLETE'] = "Prune Complete!<br />All orphaned private topics were removed.";


$ubbt_lang['REBUILD_FORWARDED'] = "the goal of this redirect.";
?>