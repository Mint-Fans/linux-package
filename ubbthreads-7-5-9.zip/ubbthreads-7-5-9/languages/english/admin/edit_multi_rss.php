<?php
$ubbt_lang['TAB_TITLE_NEW'] = "Add new multi-forum feed";
$ubbt_lang['TAB_TITLE_EDIT'] = "Edit multi-forum feed";
$ubbt_lang['FEED_NAME'] = "Feed Name";
$ubbt_lang['CACHE_TIME'] = "Cache Time";
$ubbt_lang['CACHE_TIME_1'] = "In Minutes. Higher cache times are better for overall forum performance.";
$ubbt_lang['FEED_TYPE'] = "Island Type";
$ubbt_lang['TOPICS_ONLY'] = "New Topics Only";
$ubbt_lang['RECENT_POSTS'] = "Recent Posts";
$ubbt_lang['UPDATE_FEED'] = "Update Feed";
$ubbt_lang['ADD_FEED'] = "Add Feed";
$ubbt_lang['SOURCE_FORUMS'] = "Source Forums";
$ubbt_lang['SOURCE_FORUMS_1'] = "You may choose multiple forums as your source.<br /><br />Use caution when selecting your source forums. This ignores user groups, so posts from private forums will be listed in the feed.";
$ubbt_lang['ALL_FORUMS'] = "All Forums";
$ubbt_lang['ITEMS'] = "Number of posts to list in feed";
$ubbt_lang['INCLUDE'] = "Include Body in feed";
$ubbt_lang['INCLUDE_1'] = "Number of characters";
$ubbt_lang['FEED_IS_ACTIVE'] = "Feed is Active";
?>