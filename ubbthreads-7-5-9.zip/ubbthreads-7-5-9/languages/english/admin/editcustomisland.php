<?php
$ubbt_lang['TAB_TITLE'] = "Edit Custom Portal Island";
$ubbt_lang['BOX_NAME'] = "Name";
$ubbt_lang['BOX_NAME_1'] = "This appears as the header for the custom portal box.";
$ubbt_lang['ALWAYS_BUILD'] = "Always Build";
$ubbt_lang['ALWAYS_BUILD_1'] = "With this option checked, this island will always be built even if it's not used in your portal. This would allow you to use the island elsewhere on your site.";
$ubbt_lang['CUSTOM_BOX'] = "Custom Island";
$ubbt_lang['CACHE_TIME'] = "Cache Time";
$ubbt_lang['CACHE_TIME_1'] = "In Minutes. If zero is specified, the body of this custom box will be static, ie. never updated. This setting would be used for things like links, banner ads, etc.";
$ubbt_lang['BODY'] = "Body";
$ubbt_lang['BODY_DESC'] = "This should contain the PHP code or HTML for the custom box. \$body contains the actual content that should be printed in the custom box.<br /><br /><b>Warning: Invalid PHP code that has syntax errors can result in breaking the entire portal.</b>";
$ubbt_lang['EXAMPLE'] = "/* PHP CODE HERE, IF NECESSARY */\n\n/* DO NOT CHANGE THE LINE BELOW */\n\$body = <<<EOF\n\nBody of the custom box here\n\nEOF;\n/* DO NOT CHANGE THE LINE ABOVE */";
$ubbt_lang['UPDATE_ISLAND'] = "Update Custom Portal Box";
?>