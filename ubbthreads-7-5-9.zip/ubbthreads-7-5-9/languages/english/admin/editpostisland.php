<?php
$ubbt_lang['TAB_TITLE'] = "Edit Post Island";
$ubbt_lang['BOX_NAME'] = "Name";
$ubbt_lang['BOX_NAME_1'] = "This appears as the header for the post island.";
$ubbt_lang['ALWAYS_BUILD'] = "Always Build";
$ubbt_lang['ALWAYS_BUILD_1'] = "With this option checked, this island will always be built even if it's not used in your portal. This would allow you to use the island elsewhere on your site.";
$ubbt_lang['CACHE_TIME'] = "Cache Time";
$ubbt_lang['CACHE_TIME_1'] = "In Minutes. Higher cache times are better for overall forum performance.";
$ubbt_lang['ISLAND_TYPE'] = "Island Type";
$ubbt_lang['TOPICS_ONLY'] = "New Topics Only";
$ubbt_lang['RECENT_POSTS'] = "Recent Posts";
$ubbt_lang['UPDATE_ISLAND'] = "Update Post Island";
$ubbt_lang['SOURCE_FORUMS'] = "Source Forums";
$ubbt_lang['SOURCE_FORUMS_1'] = "You may choose multiple forums as your source.<br /><br />Use caution when selecting your source forums. This ignores user groups, so posts from private forums will be listed if chosen as one of your source forums.";
$ubbt_lang['ALL_FORUMS'] = "All Forums";
$ubbt_lang['ITEMS'] = "Number of Topics/Posts to display";
?>