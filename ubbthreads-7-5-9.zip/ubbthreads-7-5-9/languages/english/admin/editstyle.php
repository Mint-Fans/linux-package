<?php
$ubbt_lang['EDIT_STYLE'] = "Edit or Add a Style";
$ubbt_lang['INSTR'] = "You can use this screen to create a style consisting of css properties, images and table wrappers. If you use any images within your css properties make sure you include the full url and the images reside within their own directory in the styles directory.<br /><i>Example: {$config['FULL_URL']}/styles/image/image.gif<br /><br />Please Note: The inline style preview area does not work with IE6 due to some javascript limitations. This does work with IE7 and Firefox.</i>";
$ubbt_lang['UPDATE_STYLE'] = "Update or Add Style";
$ubbt_lang['STYLE_SETTINGS'] = "Style Settings";
$ubbt_lang['PREVIEW'] = "Preview";
$ubbt_lang['PREVIEW_AREA'] = "Preview Area";
$ubbt_lang['UPDATE_PREVIEW'] = "Update Preview Area";
$ubbt_lang['COPY'] = "Copy";
$ubbt_lang['COPY_DESC'] = "This will copy the settings from the %s class";
$ubbt_lang['COPY_SETTINGS'] = "You may copy all settings from any existing style. Copy Style Settings From";
$ubbt_lang['STYLE_BASICS'] = "Name, Images & Wrapper";
$ubbt_lang['STYLE_NAME'] = "Style Name";
$ubbt_lang['GENERAL_IMAGES'] = "General Images";
$ubbt_lang['AVATAR_IMAGES'] = "Avatar Images";
$ubbt_lang['FORUM_IMAGES'] = "Forum Images";
$ubbt_lang['ICON_IMAGES'] = "Icon Images";
$ubbt_lang['GRAEMLIN_IMAGES'] = "Graemlin Images";
$ubbt_lang['MARKUP_IMAGES'] = "Markup Panel Images";
$ubbt_lang['NEWS_IMAGES'] = "News Images";
$ubbt_lang['MOOD_IMAGES'] = "Mood Images";
$ubbt_lang['WRAPPER_SET'] = "Wrapper Set";
$ubbt_lang['SET'] = "Set";
$ubbt_lang['CHANGE'] = "Change";

$ubbt_lang['LINK_PROP'] = "Special Link Properties";
$ubbt_lang['LINK'] = "Unvisited Link";
$ubbt_lang['VLINK'] = "Visited Link";
$ubbt_lang['ALINK'] = "Active Link";
$ubbt_lang['HLINK'] = "Hover Link";

$ubbt_lang['STYLE_GENERAL'] = "General CSS Properties";
$ubbt_lang['body_desc'] = "<b>body Class</b><br /><br />This class is for the settings of the overall page properties.";
$ubbt_lang['.ubb_popup_body_desc'] = "<b>.ubb_popup_body Class</b><br /><br />This class is for the settings of the overall page properties on pages that open in popups.";
$ubbt_lang['.t_outer_desc'] = "<b>.t_outer Class</b><br /><br />This is normally used in combination with the .t_inner class for use in the table wrappers.";
$ubbt_lang['.t_inner_desc'] = "<b>.t_inner Class</b><br /><br />This is normally used in combination with the .t_outer class for use in the table wrappers.";
$ubbt_lang['.t_standard_desc'] = "<b>.t_standard Class</b><br /><br />This is used for tables that don't need the full table wrapper. Things like popup menus and pagination blocks.";
$ubbt_lang['.tdheader_desc'] = "<b>.tdheader Class</b><br /><br />This is used for the header cell properties in all blocks of content.";
$ubbt_lang['.alt-1_desc'] = "<b>.alt-1 Class</b><br /><br />This is used for the actual content within a table. Used in combination with .alt-2 for alternating colored rows.";
$ubbt_lang['.alt-2_desc'] = "<b>.alt-1 Class</b><br /><br />This is used for the actual content within a table. Used in combination with .alt-1 for alternating colored rows.";
$ubbt_lang['.breadcrumbs_desc'] = "<b>.breadcrumb Class</b><br /><br />This is used for the breadcrumb bar at the top of each screen.";
$ubbt_lang['.navigation_desc'] = "<b>.navigation Class</b><br /><br />This is used for the navigation bar that is right below the breadcrumb bar.";
$ubbt_lang['.footer_desc'] = "<b>.footer Class</b><br /><br />This is used for the footer bar at the bottom of each screen.";
$ubbt_lang['.body_col_desc'] = "<b>.body_col Class</b><br /><br />This describes the general properties of the body column. Top and Bottom margin should be the same as the .left_col and .right_col. Right and Left Margin shouldn't be set as these are controlled by the .left and .right classes.";

$ubbt_lang['STYLE_COLUMNS'] = "Left/Right Column Properties";
$ubbt_lang['.lefttdheader_desc'] = "<b>.lefttdheader Class</b><br /><br />This is used for the header cell properties in all blocks of content in the left column.";
$ubbt_lang['.leftalt-1_desc'] = "<b>.leftalt-1 Class</b><br /><br />This is used for the actual content within a table in the left column. Used in combination with .leftalt-2 for alternating colored rows.";
$ubbt_lang['.leftalt-2_desc'] = "<b>.leftalt-2 Class</b><br /><br />This is used for the actual content within a table in the left column. Used in combination with .leftalt-1 for alternating colored rows.";
$ubbt_lang['.righttdheader_desc'] = "<b>.righttdheader Class</b><br /><br />This is used for the header cell properties in all blocks of content in the right column.";
$ubbt_lang['.rightalt-1_desc'] = "<b>.rightalt-1 Class</b><br /><br />This is used for the actual content within a table in the right column. Used in combination with .rightalt-2 for alternating colored rows.";
$ubbt_lang['.rightalt-2_desc'] = "<b>.rightalt-2 Class</b><br /><br />This is used for the actual content within a table in the right column. Used in combination with .rightalt-1 for alternating colored rows.";
$ubbt_lang['.left_col_desc'] = "<b>.left_col Class</b><br /><br />This describes the general properties of the left column. Top and Bottom margin should be the same as the .body_col and .right_col. Right margin is how much space you want between the left column and the body column.";
$ubbt_lang['.right_col_desc'] = "<b>.right_col Class</b><br /><br />This describes the general properties of the right column. Top and Bottom margin should be the same as the .body_col and .left_col. Left margin is how much space you want between the right column and the body column.";

$ubbt_lang['STYLE_CFRM'] = "Category/Forum Properties";
$ubbt_lang['.category_desc'] = "<b>.category Class</b><br /><br />This is used to give special properties to the Category Column";
$ubbt_lang['.newinforum_desc'] = "<b>.newinforum Class</b><br /><br />This is used for properties of the cell that holds the indicator for new posts in a forum.";
$ubbt_lang['.forumtitle_desc'] = "<b>.forumtitle Class</b><br /><br />This is used for properties of the cell that holds the forum title.";
$ubbt_lang['.forumdescript_desc'] = "<b>.forumdescript Class</b><br /><br />This is used for the text of the forum description that goes below the forum title.";
$ubbt_lang['.threadtotal_desc'] = "<b>.threadtotal Class</b><br /><br />This is used for properties of the cell that shows the total number of topics in the forum.";
$ubbt_lang['.posttotal_desc'] = "<b>.posttotal Class</b><br /><br />This is used for properties of the cell that shows the total number of posts in the forum.";
$ubbt_lang['.posttime_desc'] = "<b>.posttime Class</b><br /><br />This is used for properties of the cell that shows the information on the last post and time in the forum.";
$ubbt_lang['.newtotal_desc'] = "<b>.newtotal Class</b><br /><br />This is used for properties of the text that designates the total # of new posts or new replies.";
$ubbt_lang['.forum_extras_desc'] = "<b>.forum_extras Class</b><br /><br />This is used for properties of the text that shows the list of moderators or subforums.";
$ubbt_lang['.forum_viewing_desc'] = "<b>.forum_viewing Class</b><br /><br />This is used for properties of the text that shows how many users are browsing a specific forum at any one time.";

$ubbt_lang['STYLE_FORUM'] = "Forum Summary Properties";
$ubbt_lang['.newintopic_desc'] = "<b>.newintopic Class</b><br /><br />This is used for properties of the cell that holds the indicator for new posts in a topic. This will be used for odd numbered rows.";
$ubbt_lang['.topicicon_desc'] = "<b>.topicicon Class</b><br /><br />This is used for properties of the cell that holds the topic icon. This will be used for odd numbered rows.";
$ubbt_lang['.topicsubject_desc'] = "<b>.topicsubject Class</b><br /><br />This is used for properties of the cell that shows the topic subject. This will be used for odd numbered rows.";
$ubbt_lang['.topicreplies_desc'] = "<b>.topicreplies Class</b><br /><br />This is used for properties of the cell that shows the total replies to a topic. This will be used for odd numbered rows.";
$ubbt_lang['.topicviews_desc'] = "<b>.topicviews Class</b><br /><br />This is used for properties of the cell that shows the the total views of a topic. This will be used for odd numbered rows.";
$ubbt_lang['.topictime_desc'] = "<b>.topictime Class</b><br /><br />This is used for properties of the cell that shows the information on the last reply to a topic. This will be used for odd numbered rows.";
$ubbt_lang['.alt-newintopic_desc'] = "<b>.alt-newintopic Class</b><br /><br />This is used for properties of the cell that holds the indicator for new posts in a topic. This will be used for even numbered rows.";
$ubbt_lang['.alt-topicicon_desc'] = "<b>.alt-topicicon Class</b><br /><br />This is used for properties of the cell that holds the topic icon. This will be used for even numbered rows.";
$ubbt_lang['.alt-topicsubject_desc'] = "<b>.alt-topicsubject Class</b><br /><br />This is used for properties of the cell that shows the topic subject. This will be used for even numbered rows.";
$ubbt_lang['.alt-topicreplies_desc'] = "<b>.alt-topicreplies Class</b><br /><br />This is used for properties of the cell that shows the total replies to a topic. This will be used for even numbered rows.";
$ubbt_lang['.alt-topicviews_desc'] = "<b>.alt-topicviews Class</b><br /><br />This is used for properties of the cell that shows the the total views of a topic. This will be used for even numbered rows.";
$ubbt_lang['.alt-topictime_desc'] = "<b>.alt-topictime Class</b><br /><br />This is used for properties of the cell that shows the information on the last reply to a topic. This will be used for even numbered rows.";
$ubbt_lang['.new-newintopic_desc'] = "<b>.new-newintopic Class</b><br /><br />This is used for properties of the cell that holds the indicator for new posts in a topic. This will be used on odd numbered rows that are designated as new.";
$ubbt_lang['.new-topicicon_desc'] = "<b>.new-topicicon Class</b><br /><br />This is used for properties of the cell that holds the topic icon. This will be used on odd numbered rows that are designated as new.";
$ubbt_lang['.new-topicsubject_desc'] = "<b>.new-topicsubject Class</b><br /><br />This is used for properties of the cell that shows the topic subject. This will be used on odd numbered rows that are designated as new.";
$ubbt_lang['.new-topicreplies_desc'] = "<b>.new-topicreplies Class</b><br /><br />This is used for properties of the cell that shows the total replies to a topic. This will be used on odd numbered rows that are designated as new.";
$ubbt_lang['.new-topicviews_desc'] = "<b>.new-topicviews Class</b><br /><br />This is used for properties of the cell that shows the the total views of a topic. This will be used on odd numbered rows that are designated as new.";
$ubbt_lang['.new-topictime_desc'] = "<b>.new-topictime Class</b><br /><br />This is used for properties of the cell that shows the information on the last reply to a topic. This will be used on odd numbered rows that are designated as new.";
$ubbt_lang['.new-alt-newintopic_desc'] = "<b>.new-alt-newintopic Class</b><br /><br />This is used for properties of the cell that holds the indicator for new posts in a topic. This will be used on even numbered rows that are designated as new.";
$ubbt_lang['.new-alt-topicicon_desc'] = "<b>.new-alt-topicicon Class</b><br /><br />This is used for properties of the cell that holds the topic icon. This will be used on even numbered rows that are designated as new.";
$ubbt_lang['.new-alt-topicsubject_desc'] = "<b>.new-alt-topicsubject Class</b><br /><br />This is used for properties of the cell that shows the topic subject. This will be used on even numbered rows that are designated as new.";
$ubbt_lang['.new-alt-topicreplies_desc'] = "<b>.new-alt-topicreplies Class</b><br /><br />This is used for properties of the cell that shows the total replies to a topic. This will be used on even numbered rows that are designated as new.";
$ubbt_lang['.new-alt-topicviews_desc'] = "<b>.new-alt-topicviews Class</b><br /><br />This is used for properties of the cell that shows the the total views of a topic. This will be used on even numbered rows that are designated as new.";
$ubbt_lang['.new-alt-topictime_desc'] = "<b>.new-topictime Class</b><br /><br />This is used for properties of the cell that shows the information on the last reply to a topic. This will be used on odd numbered rows that are designated as new.";

$ubbt_lang['.inline_selected_desc'] = "<b>.inline_selected Class</b><br /><br />This is used for properties of the highlighted rows select for inline moderation or for private topics you intend to act upon.";
$ubbt_lang['.inline_selector_desc'] = "<b>.inline_selector Class</b><br /><br />This is used for selector (checkbox) column used for inline moderation or private topic rows.";

$ubbt_lang['STYLE_POST'] = "Post Properties";
$ubbt_lang['.subjecttable_desc'] = "<b>.subjecttable Class</b><br /><br />Column that holds the subject of the post.";
$ubbt_lang['.author-content_desc'] = "<b>.author-content Class</b><br /><br />Cell that holds the author information.";
$ubbt_lang['.post-content_desc'] = "<b>.post-content Class</b><br /><br />Cell that holds the actual post content.";
$ubbt_lang['.post-options_desc'] = "<b>.post-options Class</b><br /><br />Cell that holds the options for a post.";
$ubbt_lang['.post-buttons_desc'] = "<b>.post-buttons Class</b><br /><br />Cell that holds the individual buttons within a post: ie. reply, quote, etc.";
$ubbt_lang['.post_inner_desc'] = "<b>.post_inner Class</b><br /><br />This surrounds the content of the post. Mainly used to keep posts from stretching the screen.";
$ubbt_lang['.signature_desc'] = "<b>.signature Class</b><br /><br />This surrounds the signatures that are displayed in posts.";
$ubbt_lang['.pollcolor_desc'] = "<b>.pollcolor Class</b><br /><br />This is used for the color of the poll graphs.";
$ubbt_lang['.private_unread_desc'] = "<b>.private_unread Class</b><br /><br />Cell that holds the list of users who have not yet read a private message.";
$ubbt_lang['.post_top_link_desc'] = "<b>.post_top_link Class</b><br /><br />Cell that holds the 'Top' anchor, allowing users to quickly jump to the top of the current thread.";

$ubbt_lang['STYLE_MARKUP'] = "Markup Panel Properties";
$ubbt_lang['.markup_panel_desc'] = "<b>.markup_panel Class</b><br /><br />This is used for the general properties of the table that holds the markup panel options.";
$ubbt_lang['.markup_panel_normal_button_desc'] = "<b>.markup_panel_normal_button Class</b><br /><br />Buttons on the markup panel in a normal state.";
$ubbt_lang['.markup_panel_hover_button_desc'] = "<b>.markup_panel_hover_button Class</b><br /><br />Buttons on the markup panel that are being hovered over.";
$ubbt_lang['.markup_panel_down_button_desc'] = "<b>.markup_panel_down_button Class</b><br /><br />Buttons on the markup panel that are currently being clicked on.";
$ubbt_lang['.markup_panel_popup_desc'] = "<b>.markup_panel_select_text Class</b><br /><br />Table properties of popup menus in the markup panel.";
$ubbt_lang['.markup_panel_unselect_text_desc'] = "<b>.markup_panel_select_text Class</b><br /><br />Default text in dropdown menus.";
$ubbt_lang['.markup_panel_select_text_desc'] = "<b>.markup_panel_select_text Class</b><br /><br />Currently selected text in popup menus.";

$ubbt_lang['STYLE_POPUP'] = "Popup Menu Properties";
$ubbt_lang['.popup_menu_desc'] = "<b>.popup_menu Class</b><br /><br />Table properties for popup menus.";
$ubbt_lang['.popup_menu_header_desc'] = "<b>.popup_menu_header Class</b><br /><br />Header cell in a popup menu.";
$ubbt_lang['.popup_menu_content_desc'] = "<b>.popup_menu_content Class</b><br /><br />Content within a popup menu.";
$ubbt_lang['.popup_menu_highlight_desc'] = "<b>.popup_menu_highlight Class</b><br /><br />Content that is currently being hovered over in a popup menu.";

$ubbt_lang['STYLE_UBBCODE'] = "UBBCode Properties";
$ubbt_lang['.ubbcode-block_desc'] = "<b>.ubbcode-block Class</b><br /><br />Properties for the container that holds php, code and quote ubbcode.";
$ubbt_lang['.ubbcode-header_desc'] = "<b>.ubbcode-header Class</b><br /><br />Properties for the header of php, code and quote ubbcode.";
$ubbt_lang['.ubbcode-body_desc'] = "<b>.ubbcode-body Class</b><br /><br />Properties for the body of php, code and quote ubbcode.";
$ubbt_lang['.bbcodestring_desc'] = "<b>.bbcodestring Class</b><br /><br />Properties for strings that appear in code tags.";
$ubbt_lang['.bbcodecomment_desc'] = "<b>.bbcodecomment Class</b><br /><br />Properties for comments that appear in code tags.";
$ubbt_lang['.bbcodekeyword_desc'] = "<b>.bbcodekeyword Class</b><br /><br />Properties for keywords that appear in code tags.";
$ubbt_lang['.bbcodedefault_desc'] = "<b>.bbcodedefault Class</b><br /><br />Properties for text that appear in code tags.";
$ubbt_lang['.bbcodehtml_desc'] = "<b>.bbcodehtml Class</b><br /><br />Properties for various text that appear in only PHP code tags.";

$ubbt_lang['STYLE_TABS'] = "Tab Properties";
$ubbt_lang['.tab_grippy_desc'] = "<b>.tab_grippy Class</b><br /><br />Properties for unselected tabs.";
$ubbt_lang['.tab_grippy_sel_desc'] = "<b>.tab_grippy_sel Class</b><br /><br />Properties for the currently selected tab.";

$ubbt_lang['STYLE_FORMS'] = "Form Properties";
$ubbt_lang['form_desc'] = "<b>form Class</b><br /><br />General properties for the form tags. Normally you want these inline with no margin.";
$ubbt_lang['.form-input_desc'] = "<b>.form-input Class</b><br /><br />This is used for the properties of form input area. This includes types of text, password and textareas.";
$ubbt_lang['.form-button_desc'] = "<b>.form-button Class</b><br /><br />This is used for the properties of form buttons. This includes types of submit, button or reset.";
$ubbt_lang['.form-select_desc'] = "<b>.form-select Class</b><br /><br />This is used for the properties of form select dropdowns.";
$ubbt_lang['.form-radio_desc'] = "<b>.form-radio Class</b><br /><br />This is used for the properties of form radio buttons.";
$ubbt_lang['.form-checkbox_desc'] = "<b>.form-checkbox Class</b><br /><br />This is used for the properties of form checkboxes.";

$ubbt_lang['STYLE_MISC'] = "Misc. Properties";
$ubbt_lang['.date_desc'] = "<b>.date Class</b><br /><br />This is used for any special date properties.";
$ubbt_lang['.time_desc'] = "<b>.time Class</b><br /><br />This is used for any special time properties.";
$ubbt_lang['.small_desc'] = "<b>.small Class</b><br /><br />This is used for text that should be smaller than normal.";
$ubbt_lang['.standouttext_desc'] = "<b>.standouttext Class</b><br /><br />This is used for text that you want to bring attention to.";
$ubbt_lang['.adminname_desc'] = "<b>.adminname Class</b><br /><br />This is used for the text properties of an Administrator's name.";
$ubbt_lang['.modname_desc'] = "<b>.modname Class</b><br /><br />This is used for the text properties of a Moderator's Name.";
$ubbt_lang['.globalmodname_desc'] = "<b>.globalmodname Class</b><br /><br />This is used for the text properties of a Global Moderator's Name.";
$ubbt_lang['.bots_desc'] = "<b>.bots Class</b><br /><br />This is used for the text properties of an search bot's name specifically with respect to who's online scripts.";
$ubbt_lang['.shout_border_desc'] = "<b>.shout_border Class</b><br /><br />This is used for the border that separates each shout in the shoutbox.";
$ubbt_lang['.shout_delete_desc'] = "<b>.shout_delete Class</b><br /><br />This is used for the delete link in the shoutbox.";
$ubbt_lang['.popup_content_desc'] = "<b>.popup_content Class</b><br /><br />This is used for popup content on mouseovers.";
$ubbt_lang['.popup_content_header_desc'] = "<b>.popup_content_header Class</b><br /><br />This is used for the popup content header on mouseovers.";
$ubbt_lang['.search_highlight_desc'] = "<b>.search_highlight Class</b><br /><br />This is used to highlight search words when displayed in posts.";

$ubbt_lang['STYLE_EMAIL'] = "Email Properties";
$ubbt_lang['.email-header_desc'] = "<b>.email-header Class</b><br /><br />A common header for all outgoing emails. Could be a link to the board or whatever";
$ubbt_lang['.email-body_desc'] = "<b>.email-body Class</b><br /><br />The background of all outgoing Html emails";
$ubbt_lang['.email-tdheader_desc'] = "<b>.email-tdheader Class</b><br /><br />Properties for Post and PM headers of all outgoing Html emails";
$ubbt_lang['.email-tdbody_desc'] = "<b>.email-tdbody Class</b><br /><br />Properties for the body content of all outgoing Html emails";
$ubbt_lang['.email-footer_desc'] = "<b>.email-footer Class</b><br /><br />Properties for the bottom signature of all outgoing Html emails";

$ubbt_lang['STYLE_EXTRA'] = "Extra Properties";

?>