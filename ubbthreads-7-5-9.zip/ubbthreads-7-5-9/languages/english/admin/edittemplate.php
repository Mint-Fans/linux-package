<?php
$ubbt_lang['T_NAME'] = "Template:";
$ubbt_lang['EDIT_HEAD'] = "Edit template";
$ubbt_lang['EDIT_BODY'] = "Use the box below to edit this template.";
$ubbt_lang['UPDATE'] = "Update";
$ubbt_lang['TEMPLATE_EDIT'] = "Template Editor";
$ubbt_lang['NONE'] = "You did not select a template to edit.";
?>