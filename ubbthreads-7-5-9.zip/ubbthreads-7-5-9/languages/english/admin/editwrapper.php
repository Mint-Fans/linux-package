<?php
$ubbt_lang['PRIMARY_S'] = "Styles";
$ubbt_lang['EDIT_WRAPPER'] = "Edit Wrapper";
$ubbt_lang['DELETE_WRAPPER'] = "Delete this Wrapper";
$ubbt_lang['WRAPPER_EDIT'] = "Fill out the fields below for this wrapper. Remember that these wrappers go around blocks of content. All blocks of content start and end with an opening and closing &lt;tr> tags. So your open wrapper should end with an opening table tag, and your closing wrapper should start with a closing table tag.<br /><br />Width should always be set to 100% so the content fills the proper area<br /><br />You can use the .t_inner and .t_outer classes for your wrappers. These are in the actual style settings and will adjust the wrapper look depending on the style they are used in.<br /><br /> If you use any images within your wrapper make sure you include the entire URL to the image and that the images reside within their own directory in the styles directory.<br /><i>Example: {$config['FULL_URL']}/styles/image/image.gif</i>";
$ubbt_lang['WRAPPER_NAME'] = "Name";
$ubbt_lang['WRAPPER_OPEN'] = "Opening HTML";
$ubbt_lang['WRAPPER_CLOSE'] = "Closing HTML";
$ubbt_lang['UPDATE_WRAPPER'] = "Update Wrapper";
$ubbt_lang['PREVIEW_WRAPPER'] = "Preview Wrapper";

?>