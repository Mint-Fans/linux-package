<?php
$ubbt_lang['EXTERNAL'] = "External Island Instructions";
$ubbt_lang['EXTERNAL_DESC'] = "This page will show you what you'll need to put into a page outside of UBB.threads to use this Content Island inside of it. The page will need to be PHP enabled.";
$ubbt_lang['CODE'] = "Code to place inside your PHP enabled webpage.";
$ubbt_lang['WILL_INCLUDE'] = "Inserting the code above will insert the following HTML into it's place. As you can see there are 2 CSS classes you'll want to define for the included HTML, those being tdheader and alt-1. You can modify the properties of the table itself in the code above.";
?>