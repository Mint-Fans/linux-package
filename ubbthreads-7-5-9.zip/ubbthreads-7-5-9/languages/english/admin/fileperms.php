<?php
$ubbt_lang['INTRO'] = "This page will test to make sure all files and directories have the proper permissions. Note that not all of these permissions are required for your forum to be operational. Some of these permissions are only used in the control panel, for example the languages. You only need to change these permissions if you want to update your language files in the control panel.";
$ubbt_lang['CACHE_DIRECTORY'] = "Cache Directory";
?>