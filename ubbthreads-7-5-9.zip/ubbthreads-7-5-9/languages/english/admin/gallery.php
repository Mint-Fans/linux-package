<?php
$ubbt_lang['WARNING'] = "FATAL: It appears you don't have GD2 or ImageMagick6 installed. You cannot use the gallery features without one of these being installed on your system.";
$ubbt_lang['UPDATE'] = "Update Gallery Settings";
$ubbt_lang['GRAPHICS_LIBRARY'] = "What Graphics Library do you want to use?";
$ubbt_lang['USE_GD'] = "Use GD2";
$ubbt_lang['USE_IM'] = "Use ImageMagick";
$ubbt_lang['THUMB_SIZE'] = "Thumbnail image max width/height in pixels.";
$ubbt_lang['IMAGE_SIZE_1'] = "If either the width or height exceed this value then the larger sized property will be scaled to this, with the other being proportionally scaled.";
$ubbt_lang['MED_SIZE'] = "Medium image max width/height in pixels.";
$ubbt_lang['FULL_SIZE'] = "Full image max width/height in pixels.";
$ubbt_lang['THUMB_QUALITY'] = "Thumbnail Image Quality";
$ubbt_lang['QUALITY_1'] = "Higher settings will lead to better quality, but larger filesizes.";
$ubbt_lang['MEDIUM_QUALITY'] = "Medium Image Quality";
$ubbt_lang['FULL_QUALITY'] = "Full Image Quality";
?>