<?php
$ubbt_lang['POST_ISLAND_ID'] = "Gallery Island #";
$ubbt_lang['ISLAND_TITLE'] = "Island Title";
$ubbt_lang['ISLAND_SOURCE'] = "Island Source";
$ubbt_lang['ISLAND_CACHE'] = "Cache Time";
$ubbt_lang['EDIT'] = "Edit";
$ubbt_lang['UNDEFINED'] = "Undefined";
$ubbt_lang['MINUTES'] = "min";
$ubbt_lang['MULTIPLE'] = "Multiple Forums";
$ubbt_lang['ALL_FORUMS'] = "All Forums";
?>