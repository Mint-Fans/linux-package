<?php
$ubbt_lang['WORKGROUPS'] = "Select the groups with which you would like to work.";
$ubbt_lang['G_EDIT'] = "Group Editor";
$ubbt_lang['G_ACCESS'] = "Group Access";
$ubbt_lang['ADD_GROUP'] = "Add New Group";
$ubbt_lang['UPDATE_GROUPS'] = "Update Groups";
$ubbt_lang['G_ID'] = "#";
$ubbt_lang['G_NAME'] = "Name";
$ubbt_lang['TOTAL_USERS'] = "Members";
$ubbt_lang['G_DELETE'] = "Delete";
$ubbt_lang['NO_CUSTOM'] = "You do not have any custom groups to edit.";
$ubbt_lang['PERMS'] = "Edit Permissions";
$ubbt_lang['FORUM'] = "Forum";
$ubbt_lang['SITE'] = "Site";
$ubbt_lang['CP'] = "CP";
$ubbt_lang['POST_COUNT'] = "Post Count";
$ubbt_lang['D_NOTE'] = "By filling in the Post Count field you can make it so users will automatically be added to that particular group once they reach the designated Post Count. Leave blank, or 0, to disable this feature.";
$ubbt_lang['IMAGE'] = "Image";
$ubbt_lang['CHANGE'] = "Change";
?>