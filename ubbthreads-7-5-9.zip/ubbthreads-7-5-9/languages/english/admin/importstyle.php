<?php
$ubbt_lang['IMPORT_STYLE'] = "Import a Style";
$ubbt_lang['IMPORT_DETAILS'] = "Browse to the style you'd like to import and click continue when done.";
$ubbt_lang['CONTINUE'] = "Continue";
$ubbt_lang['NO_STYLE'] = "We could find no style information in the file you uploaded.";
$ubbt_lang['STYLE_DETAILS'] = "Style Details";
$ubbt_lang['IMAGE_VARS_CONTAMINATED'] = "One of the image vars for this style has a bad value.";
$ubbt_lang['STYLE_VARS_CONTAMINATED'] = "One of the style vars for this style has a bad value.";
?>