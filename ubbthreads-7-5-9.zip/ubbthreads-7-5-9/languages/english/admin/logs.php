<?php
$ubbt_lang['F_LOC'] = "the log summary.";
$ubbt_lang['ADMIN_HEAD'] = "View Admin Logs";
$ubbt_lang['HEAD'] = "Show the Log File";
$ubbt_lang['VIEW'] = "View";
$ubbt_lang['DATE'] = "Date";
$ubbt_lang['IP'] = "IP address";
$ubbt_lang['USERNAME'] = "Username";
$ubbt_lang['NR'] = "Nr.";
$ubbt_lang['STATUS'] = "Status";
$ubbt_lang['EXTRA'] = "Extra Information";
$ubbt_lang['OPER'] = "Operation";
$ubbt_lang['ADMIN'] = "Administrator";
$ubbt_lang['MOD'] = "Moderator";
$ubbt_lang['UNKNOWN'] = "Unknown";
$ubbt_lang['GO'] = "Go!";
$ubbt_lang['SQL_HEAD'] = "View SQL Errors";
$ubbt_lang['LOG_NAME'] = "Log";
$ubbt_lang['REMOVE'] = "Remove";
$ubbt_lang['REMOVED'] = "has been removed.";
$ubbt_lang['DETAILS'] = "Details for log:";
$ubbt_lang['REFERER_HEAD'] = "View Referer Logs";
?>