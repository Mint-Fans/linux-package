<?php
$ubbt_lang['MERGE_USER'] = "Merge User";
$ubbt_lang['CHOOSE'] = "Enter the User ID of the user you want to merge this user into. <b>Warning:</b> Merging a user with another cannot be undone.";
$ubbt_lang['MERGE_ID'] = "User ID";
$ubbt_lang['PROCEED'] = "Continue";
?>