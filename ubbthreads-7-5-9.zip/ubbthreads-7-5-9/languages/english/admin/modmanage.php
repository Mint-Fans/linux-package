<?php
$ubbt_lang['MODS'] = "Moderators";
$ubbt_lang['ADD'] = "Add";
$ubbt_lang['NOMODS'] = "(No Moderators)";
$ubbt_lang['REMOVE'] = "Remove";
$ubbt_lang['DO_UPDATE'] = "Update Moderators";
?>