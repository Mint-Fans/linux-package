<?php
$ubbt_lang['TITLE'] = "Moderator Search for";
$ubbt_lang['CHOOSE'] = "Choose an existing Moderator...";
$ubbt_lang['PROFILE'] = "Profile";
$ubbt_lang['ADD'] = "Add";
$ubbt_lang['SEARCH'] = "... or search for a new Moderator.";
$ubbt_lang['UNAME'] = "Display Name:";
$ubbt_lang['UNUM'] = "User Number";
$ubbt_lang['FIND_USERS'] = "Find Users";
$ubbt_lang['CLOSE'] = "Close Window";
?>