<?php

$ubbt_lang['MAIN_PORTAL'] = "Enable the Main Portal Index page?";
$ubbt_lang['PORTAL_NEWS'] = "Forums to pull news from:";
$ubbt_lang['PORTAL_NEWS_1'] = "Only displays on the Main Portal Index page. You may specify multiple forums to pull news and announcements for the main page.<br /><br />Note: This ignores user groups, so anyone will be able to read these items regardless of their permissions.";
$ubbt_lang['POPULAR'] = "Exclude popular topics in these forums:";
$ubbt_lang['POPULAR_1'] = "Leave empty or 0 to display any popular topic.";
$ubbt_lang['popular_topics'] = "Cache time for Popular Topics";
$ubbt_lang['top_posters'] = "Cache time for Top Posters";
$ubbt_lang['top_posters_30'] = "Cache time for Top Posters (30)";
$ubbt_lang['online_now'] = "Cache time for Who's Online";
$ubbt_lang['forum_stats'] = "Cache time for Forum Stats";
$ubbt_lang['public_calendar'] = "Cache time for Public Calendar";
$ubbt_lang['CACHE_1'] = "In Minutes: Higher cache times are better for overall forum speed.";
$ubbt_lang['NEWS_ITEMS'] = "Number of news items to display on the Main Portal page?";
$ubbt_lang['TOP_POSTERS'] = "Total # of Top Posters to list?";
$ubbt_lang['TOTAL_ONLINE'] = "How many Usernames should be displayed in Who's Online?";
$ubbt_lang['TOTAL_ONLINE_DESC'] = "Enter 0 to display all.";
$ubbt_lang['LEFT_COLUMN'] = "Allow users to turn off the left column?";
$ubbt_lang['RIGHT_COLUMN'] = "Allow users to turn off the right column?";
$ubbt_lang['LEFT_COLUMN_PORTAL'] = "Only show left column on portal page?";
$ubbt_lang['RIGHT_COLUMN_PORTAL'] = "Only show right column on portal page?";
$ubbt_lang['COLUMN_1'] = "Columns will always display on the Main Portal Index page.";
$ubbt_lang['BIRTHDAYS'] = "Only show birthdays for users online in past X days.";
$ubbt_lang['BIRTHDAYS_1'] = "Leave empty or 0 to show all user's birthdays.";
$ubbt_lang['FEATURED'] = "Only Feature Members who have posted in the past X days.";
$ubbt_lang['FEATURED_1'] = "Leave empty or 0 to feature any member.";
?>