<?php
$ubbt_lang['REFERER_HEAD'] = "View Referer Logs";
$ubbt_lang['SQL_HEAD'] = "View SQL Errors";
$ubbt_lang['ADMIN_HEAD'] = "View Admin Logs";
$ubbt_lang['SHOW_LOGS'] = "Show Entries dated between:";
$ubbt_lang['AND'] = "and";
$ubbt_lang['PURGE_LOGS'] = "Purge Entries older than:";
$ubbt_lang['TOTAL_LOGS'] = "You have %s entries with the oldest being dated %s";
$ubbt_lang['DATE'] = "Date";
$ubbt_lang['REFERER'] = "Refering URL";
?>