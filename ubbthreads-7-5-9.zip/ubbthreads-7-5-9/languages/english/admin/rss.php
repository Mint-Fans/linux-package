<?php
$ubbt_lang['SINGLE_RSS'] = "Single Forum RSS";
$ubbt_lang['MULTI_RSS'] = "Multi Forum RSS";
$ubbt_lang['MY_RSS'] = "My Feeds";
$ubbt_lang['NAME'] = "Feed Title";
$ubbt_lang['SOURCE'] = "Source Forum";
$ubbt_lang['ACTIVE'] = "Active";
$ubbt_lang['CACHE_TIME'] = "Cache Time (minutes)";
$ubbt_lang['SINGLE_DESC'] = "These are your RSS feeds for single forums. You can activate/deactivate your feeds here, change the feed name and also set the cache time. Higher cache times are better for overall forum performance. Also it's a good idea to stagger your cache times instead of having all with the same value.<br /><br />New single forum feeds are made by editing the individual forums.";
$ubbt_lang['FEED_URL'] = "Feed URL:";
$ubbt_lang['EDIT'] = "Edit";
$ubbt_lang['UPDATE'] = "Update RSS Feeds";
$ubbt_lang['MULTI_DESC'] = "Your manually created RSS feeds that span multiple forums are below. You can activate/deactivate your feeds here, change the feed name and also set the cache time. Higher cache times are better for overall forum performance. Also it's a good idea to stagger your cache times instead of having all with the same value.<br /><br />";
$ubbt_lang['NUM_SOURCE'] = "Number of Forums";
$ubbt_lang['FORUMS_TEXT'] = "Forums";
$ubbt_lang['NEW_MULTI'] = "Add New Multi Forum RSS Feed";
$ubbt_lang['MY_FEEDS_ENABLE'] = "Enable the 'My Feeds' option for 'My Stuff' menu?";
$ubbt_lang['MY_FEEDS_ENABLE_DESC'] = "These feeds are generated, based upon the user's permissions. They are 'automatic' in the sense that there is no further per forum setup required. Users can choose from their available feeds that they are permitted to see and the forum generates them automatically.<br />";
?>