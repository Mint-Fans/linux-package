<?php
$ubbt_lang['NO_DATE'] = "You must select a date range.";
$ubbt_lang['SELECT'] = "Select Topics";
$ubbt_lang['HEAD'] = "The topics checked below will be included in this process. Uncheck a checkbox to exclude that topic.";
$ubbt_lang['PAGE'] = "Pages:";
$ubbt_lang['MOVE'] = "Move?";
$ubbt_lang['TITLE'] = "Topic Title";
$ubbt_lang['FORUM'] = "Forum";
$ubbt_lang['FIRST'] = "First Post";
$ubbt_lang['LAST'] = "Last Post";
$ubbt_lang['SAVE'] = "Save Changes";
$ubbt_lang['NO_TARGET'] = "No target forum selected!";
$ubbt_lang['NO_MATCHES'] = "No topics were found matching that criteria.";
$ubbt_lang['DIRECT_HEAD'] = "You have chosen to move %s topics into %s. This process can not be undone easily. Are you sure you wish to continue?";
$ubbt_lang['BEGIN_NOW'] = "Yes, I wish to do this. Begin now.";
$ubbt_lang['REVIEW'] = "Let me review the selected topics first.";
$ubbt_lang['CANCEL'] = "No, I don't wish to do this. Cancel.";
?>