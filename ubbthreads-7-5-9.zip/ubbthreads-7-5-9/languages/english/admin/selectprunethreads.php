<?php
$ubbt_lang['NO_DATE'] = "You must choose a month, day, and year.";
$ubbt_lang['SELECT'] = "Select Topics";
$ubbt_lang['HEAD'] = "The topics checked below will be included in this process. Uncheck a checkbox to exclude that topic.";
$ubbt_lang['PAGE'] = "Pages:";
$ubbt_lang['MOVE'] = "Prune?";
$ubbt_lang['TITLE'] = "Topic Title";
$ubbt_lang['FORUM'] = "Forum";
$ubbt_lang['FIRST'] = "First Post";
$ubbt_lang['LAST'] = "Last Post";
$ubbt_lang['SAVE'] = "Save Changes";
$ubbt_lang['NO_MATCHES'] = "No topics were found matching that criteria.";
$ubbt_lang['DIRECT_HEAD'] = "You have chosen to prune %s topics. This process can not be undone. Are you sure you wish to continue?";
$ubbt_lang['BEGIN_NOW'] = "Yes, I wish to do this. Begin now.";
$ubbt_lang['REVIEW'] = "Let me review the selected topics first.";
$ubbt_lang['CANCEL'] = "No, I don't wish to do this. Cancel.";
?>