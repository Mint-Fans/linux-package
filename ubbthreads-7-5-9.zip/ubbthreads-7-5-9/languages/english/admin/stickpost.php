<?php
$ubbt_lang['STICKHEAD'] = "Post is now sticky.";
$ubbt_lang['STICKBODY'] = "The selected post has been marked as sticky and will appear at the top of the forum.";
$ubbt_lang['ANNOUNCEHEAD'] = "Post is now an announcement";
$ubbt_lang['ANNOUNCEBODY'] = "The selected post has been made into an announcement and will appear at the top of every forum.";
?>