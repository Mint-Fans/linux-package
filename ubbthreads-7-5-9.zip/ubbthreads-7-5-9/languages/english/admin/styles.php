<?php
$ubbt_lang['PRIMARY_S'] = "Styles";
$ubbt_lang['ADD_S'] = "Create New Style";
$ubbt_lang['DEFAULT_S'] = "Default Stylesheet:";
$ubbt_lang['AVAILABLE_S'] = "The following styles are available for your use. You can find more styles at <a href=\"http://www.ubbdev.com/forums/ubbthreads.php/category/4/community-development.html\" target=\"_blank\">UBBDev.com</a>.";
$ubbt_lang['UPDATE_STYLES'] = "Update Styles";
$ubbt_lang['EDIT_IT'] = "Edit";
$ubbt_lang['PREVIEW_IT'] = "Preview";
$ubbt_lang['WRAPPERS'] = "Wrappers";
$ubbt_lang['EXPORT_WRAPPER'] = "Export w Wrapper";
$ubbt_lang['EXPORT'] = "Export w/o Wrapper";
$ubbt_lang['DELETE'] = "Delete";
$ubbt_lang['DELETE_CONFIRM'] = "Are you sure you want to delete this style?";
$ubbt_lang['IMPORT_STYLE'] = "Import Style";
?>