<?php
$ubbt_lang['PRIMARY_S'] = "Styles";
$ubbt_lang['WRAPPERS'] = "Wrappers";
$ubbt_lang['ADD_WRAPPER'] = "Create a New Wrapper";
$ubbt_lang['WRAPPER_DEF'] = "A wrapper is a matching set of HTML that will surround each block of content. All content starts and ends with the &lt;tr> tags, so your open wrapper should end with an opening table tag, and your closing wrapper should begin with a closing table tag.";
$ubbt_lang['ID'] = "Id";
$ubbt_lang['NAME'] = "Name";
$ubbt_lang['HTML'] = "HTML";
$ubbt_lang['EDIT'] = "Edit";
$ubbt_lang['PREVIEW'] = "Preview";

?>