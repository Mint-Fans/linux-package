<?php
$ubbt_lang['DISABLED'] = "The calendar is disabled.";
$ubbt_lang['NEXTMONTH'] = "Next Month &gt;&gt;";
$ubbt_lang['PREVMONTH'] = "&lt;&lt; Previous Month";
$ubbt_lang['ADDEVENT'] = "Add New Event";
$ubbt_lang['TOPIC'] = "Forum Topic";
$ubbt_lang['BDAY'] = "Birthday";
$ubbt_lang['EVENT'] = "Event";
$ubbt_lang['TODAY'] = "Today";
$ubbt_lang['CAL_HEAD'] = "Calendar";
$ubbt_lang['SUNDAY'] = "Su";
$ubbt_lang['MONDAY'] = "M";
$ubbt_lang['TUESDAY'] = "Tu";
$ubbt_lang['WEDNESDAY'] = "W";
$ubbt_lang['THURSDAY'] = "Th";
$ubbt_lang['FRIDAY'] = "F";
$ubbt_lang['SATURDAY'] = "Sa";
$ubbt_lang['BIRTHDAYS'] = "birthdays";
$ubbt_lang['EVENTS'] = "events";
?>