<?php
$ubbt_lang['WATCHING_FORUM'] = "You are watching this forum.";
$ubbt_lang['NO_FORUMS'] = "There are no forums for you to view.";
$ubbt_lang['VIEWING'] = "viewing";
$ubbt_lang['TOTAL_FORUMS'] = "forum(s) in this category.";
$ubbt_lang['NEW_MEM'] = "Welcome to our newest member,";
$ubbt_lang['THREAD_TEXT'] = "Threads";
$ubbt_lang['REGED_USERS'] = "Registered User(s).";
$ubbt_lang['POSTS_TEXT'] = "Posts";
$ubbt_lang['LAST_POST'] = "Last Post";
$ubbt_lang['NEW_BOARD'] = "New Forum";
$ubbt_lang['NOT_APPROVED'] = "NA";
$ubbt_lang['SUBFORUMS'] = "Subforums:";
$ubbt_lang['DOUBLE_CLICK'] = "Double Click this icon to mark this forum as read.";
$ubbt_lang['NOTIFY_OPTIONS'] = "Notification Options";
$ubbt_lang['REMOVE_WATCH'] = "Stop watching this forum";
$ubbt_lang['NO_NOTIFY'] = "Do not notify me.";
$ubbt_lang['IMMEDIATE_NOTIFY'] = "Notify me for new posts.";
$ubbt_lang['NEW_TOPIC_NOTIFY'] = "Notify me for new topics.";
$ubbt_lang['CATEGORY_TEXT'] = "Category";
$ubbt_lang['FORUM_TEXT'] = "Forums";
$ubbt_lang['TEASER_LATEST_POST'] = "Private Thread";
?>