<?php
$ubbt_lang['POST_DEL_HEAD'] = "This post has been deleted.";
$ubbt_lang['DELETE_EXPIRED'] = "You may no longer delete this post.";
$ubbt_lang['NO_EDIT'] = "You may not edit this post.";
?>