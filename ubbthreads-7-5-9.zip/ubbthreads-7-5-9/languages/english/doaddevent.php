<?php
$ubbt_lang['HEAD'] = "Event added.";
$ubbt_lang['BODY'] = "The event has been added to the calendar. You will be returned to the calendar in a moment.";
?>