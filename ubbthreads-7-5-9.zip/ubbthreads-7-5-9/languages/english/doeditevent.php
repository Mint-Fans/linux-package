<?php
$ubbt_lang['NO_EDIT'] = "You do not have permission to edit this event.";
$ubbt_lang['HEAD'] = "Event updated.";
$ubbt_lang['BODY'] = "The event has been updated. You will be returned to the calendar in a moment.";
$ubbt_lang['DELETE_HEAD'] = "Confirm deletion.";
$ubbt_lang['DELETE_BODY'] = "If you are sure you want to delete this event from the calendar, click the button below.";
$ubbt_lang['DO_DELETE'] = "Yes, I want to delete this event.";
?>