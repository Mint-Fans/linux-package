<?php
$ubbt_lang['NO_FORUM'] = "You must select a forum to be the target of this move.";
$ubbt_lang['NO_CAT'] = "You need to choose a forum, not a category.";
$ubbt_lang['UNAPPROVED'] = "You cannot move a branch of a thread that has unapproved posts in it.";
$ubbt_lang['NOMERGE'] = "We cannot find the post you specified.";
$ubbt_lang['POST_MOVED'] = "Post Moved";
$ubbt_lang['POST_MERGED'] = "Post Merged";
$ubbt_lang['POST_BODY'] = "This affects the original post and all of its replies.";
$ubbt_lang['PM_MOVE_SUBJ'] = "Your Post has been moved";
$ubbt_lang['PM_MERGE_SUBJ'] = "Your Post has been merged";
$ubbt_lang['PM_BODY'] = "You can now find your post titled: '%%SUBJECT%%' and all its replies [<a href=\"%%NEW_ADDY%%\"> Here </a>]%%IF_REASON%%";
$ubbt_lang['PM_REASON'] = "<br /><br />The reason for the change is:<br /><br /> %%REASON%%";
?>