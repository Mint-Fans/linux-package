<?php
$ubbt_lang['INVALID_RATING'] = "The rating you have chosen is invalid. Please try again.";
$ubbt_lang['NOMORERATE'] = "You have already rated this topic.";
$ubbt_lang['THANKS'] = "Thank you.";
$ubbt_lang['RATED'] = "Your rating for this topic has been accepted.";
?>