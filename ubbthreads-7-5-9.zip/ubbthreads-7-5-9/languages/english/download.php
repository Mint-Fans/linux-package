<?php
$ubbt_lang['NO_DOWNLOAD'] = "You do not have access to download this attachment.";
?>