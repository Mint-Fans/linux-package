<?php
$ubbt_lang['NO_EDIT'] = "You do not have permission to edit this event.";
$ubbt_lang['EVENT_HEAD'] = "Edit this event.";
$ubbt_lang['EVENT_BODY'] = "You may edit or delete this event below.";
$ubbt_lang['SUBJECT'] = "Event Title";
$ubbt_lang['COMMENTS'] = "Comments";
$ubbt_lang['DATE'] = "Event Date";
$ubbt_lang['RECURRING'] = "Recurring";
$ubbt_lang['YEARLY'] = "Yearly";
$ubbt_lang['MONTHLY'] = "Monthly";
$ubbt_lang['NEVER'] = "Never";
$ubbt_lang['TYPE'] = "Type";
$ubbt_lang['EVENTADMIN'] = "Only Admins can add public events.";
$ubbt_lang['EVENTMODADMIN'] = "Only Admins and Moderators can add public events.";
$ubbt_lang['PUBLIC'] = "Public";
$ubbt_lang['PRIVATE'] = "Private";
$ubbt_lang['UPDATE'] = "Update Event";
$ubbt_lang['DELETE'] = "Delete Event";
$ubbt_lang['DO_PREVIEW'] = "Preview Event";
?>