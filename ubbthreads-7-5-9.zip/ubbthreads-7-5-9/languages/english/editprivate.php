<?php
$ubbt_lang['NO_PERM'] = "You do not have permission to access this topic.";
$ubbt_lang['EDIT_IT'] = "Edit your private message.";
$ubbt_lang['MESS_PREVIEW'] = "Preview your modifications.";
$ubbt_lang['SUBMIT_CHANGES'] = "Submit Changes";
$ubbt_lang['DELETE'] = "Delete this message.";
$ubbt_lang['PREVIEW'] = "Preview";
?>