<?php
$ubbt_lang['EDIT_FAV_TOPICS'] = "Edit your Watched Topics.";
$ubbt_lang['REMOVE'] = "Remove";
$ubbt_lang['TOPIC'] = "Topic";
$ubbt_lang['EMAIL'] = "Email Notification";
$ubbt_lang['NO_EMAIL'] = "None";
$ubbt_lang['IMMEDIATE_EMAIL'] = "Immediately";
$ubbt_lang['REMOVE_BUTTON'] = "Update Watched Topics";
?>