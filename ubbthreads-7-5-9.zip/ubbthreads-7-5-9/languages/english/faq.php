<?php
$ubbt_lang['HEAD'] = "FAQ (Frequently Asked Questions)";
$ubbt_lang['FAQ_BODY'] = "Frequently Asked Questions. If you know of anything else that should be addressed on this page please ";
$ubbt_lang['F_REGISTER'] = "Why should I register?";
$ubbt_lang['F_EMAIL'] = "Why do you ask for two email addresses?";
$ubbt_lang['F_COOKIES'] = "Does my browser have to be set to accept cookies?";
$ubbt_lang['F_LOGIN'] = "How do I log in?";
$ubbt_lang['F_HELP'] = "Help! I'm having trouble logging in!";
$ubbt_lang['F_TITLESTRING'] = "What is the title that appears beneath my Display Name in posts?";
$ubbt_lang['F_TITLES'] = "What are these titles about?";
$ubbt_lang['F_PASSWORD'] = "I forgot my password!";
$ubbt_lang['F_CHANGEPASSWORD'] = "How do I change my password?";
$ubbt_lang['F_IMAGE'] = "How do I add an image to my message?";
$ubbt_lang['F_LIMIT'] = "Is there a limit to the size of an image I can have in my signature?";
$ubbt_lang['F_ATTACH'] = "Can I attach a file to my post?";
$ubbt_lang['F_RULES'] = "What are the rules of conduct for the forum?";
$ubbt_lang['F_EDITDISP'] = "How do I edit my display preferences?";
$ubbt_lang['F_SUBJECT'] = "Why is a post's subject so important?";
$ubbt_lang['F_ANSWER'] = "How do I find posts that may already have the answer to the question I have?";
$ubbt_lang['F_FLASH'] = "What does the flashing envelope icon on the My Messages link in the Navigation Island indicate?";
$ubbt_lang['F_PARTICIPANTS'] = "Can I send a Private Topic to more than one person?";
$ubbt_lang['F_URL'] = "I'm having problems getting the URL tags to work.";
$ubbt_lang['F_MISTAKE'] = "What if I make a mistake in my post?";
$ubbt_lang['F_WRONGFORUM'] = "What if I post in the wrong forum?";
$ubbt_lang['F_HTML'] = "Can I use HTML in my posts?";
$ubbt_lang['F_UBB'] = "What UBBCode can I use in my posts?";
$ubbt_lang['F_POLL'] = "How do I put a poll in my post?";
$ubbt_lang['F_MOREPOSTS'] = "How do I change the number of posts displayed on a page?";
$ubbt_lang['F_REPLY'] = "What's the difference between Reply and Quick Reply?";
$ubbt_lang['F_QUOTE'] = "What's the difference between Quote and Quick Quote?";
$ubbt_lang['F_EDIT'] = "How do I edit my profile?";
$ubbt_lang['F_GALLERY'] = "How do I use Gallery Forums?";
$ubbt_lang['F_SUBSCRIBE'] = "How do Watch Lists work?";
$ubbt_lang['F_MCONTENT'] = "How do I mail myself a Topic or Private Message?";
$ubbt_lang['F_RSSINFO'] = "How do I use RSS Feeds?";
$ubbt_lang['F_UCOLORS'] = "What do the different Username Colors mean?";
$ubbt_lang['F_NPINDICATOR'] = "What do the numbers in parenthesis next to the \"Post Numbers\" mean?";
$ubbt_lang['B_REGISTER'] = "By registering with the forum, you will be able to edit your member profile and preferences. You will get the most out of your time here if you change your profile and preferences to suit your individual tastes. There are many options in your profile to make your experience here more enjoyable, so please take a few moments to try the various settings. Also, only users that are registered and logged in can take advantage of the \"New Posts\" feature upon each visit. Once you've registered and logged in, click \"Edit Profile\" or \"Edit Preference\" in the Forum Navigation island to edit your settings.";
$ubbt_lang['B_EMAIL'] = "The Email Address field is used for email notifications, Watch Lists and to email your password. The Public Email Address field is what other users see when they view your profile. We realize that you may not want everyone to know your real email address, but we need to know it in case you want to watch certain content or if you want to have replies emailed to you. For this reason you can give us your real email address in the Email Address field and only the Administrators of the board will see it. You can provide a different email address for the general public using the Public Email Address. Some people like to put in something like scream@no.spam.yahoo.com. This way people can still figure out what your real email address is, but spamming agents can't just parse through the page and obtain your email address to spam you.";
$ubbt_lang['B_COOKIES'] = "Yes. Cookies are used to remember your login information as well as what posts you have read during your current session. Without accepting cookies some functions won't work properly.";
$ubbt_lang['B_LOGIN'] = "If you have registered with these forums, you must log in to take advantage of the personalization of settings. To log in, look in the upper right-hand corner of your screen for the \"Log In\" link. This link will take you to a page where you can enter your Username (email address) and Password. Keep in mind that the password is always case-sensitive. This means that the software considers \"S\" and \"s\" to be different characters.<br/><br/>Once you have entered your Username (email address) and Password, you'll be brought to your Starting View. (You can change the page used for your Default Starting View by clicking \"Edit Preferences\" in the Forum Navigation island.) If you have any Private Messages waiting for you, you'll see a flashing envelope on the My Messages island. (Note that this only applies if the Private Messaging feature has been enabled by the Administrators of the board.)";
$ubbt_lang['B_HELP'] = "This checklist may help you successfully log in:";
$ubbt_lang['B_HELP1'] = "1) Make sure you are entering your password correctly. Passwords are case-sensitive.";
$ubbt_lang['B_HELP2'] = "2) Ensure that your browser supports cookies; if so, check the security level you are using. High levels of security restriction in certain browsers will automatically reject cookies. In order to use the key features of these forums, you'll need to accept cookies. The maker of your browser can help you with additional problems you may have with your cookie settings.";
$ubbt_lang['B_HELP3'] = "3) Completely log out by hitting the Log Out link in the upper right-hand corner of the page, and then log back in again.";
$ubbt_lang['B_HELP4'] = "4) After logging in, you may have to hit the Reload or Refresh button on your browser to expedite the authentication.";
$ubbt_lang['B_HELP5'] = "5) If these steps don't work you can try purging your cookies for this site using the <a href=\"{$config['BASE_URL']}/ubbthreads.php?ubb=mycookies\">My Cookies</a> tool.";
$ubbt_lang['B_HELP6'] = "6) If you continue to have problems, go to the Log In page and click \"{$ubbt_lang['FORGOTTEN']}\". Enter your real email address into the Email Address field and a temporary password will be emailed to the email address used for the account setup.";
$ubbt_lang['B_TITLESTRING'] = "It's a system-generated User Title to give ranking to your postcount. You will progress through the various levels according to the cumulative number of posts you have made.";
$ubbt_lang['B_TITLES'] = "Everyone has a title within the forum. You will notice the title below the Display Name in each post. Some titles are automatically assigned based on the number of posts a user has made, and some titles are assigned by the forum owner to denote official representatives of the company or other VIPs in the forums.";
$ubbt_lang['B_PASSWORD'] = "If you have forgotten your password, don't worry! You can very easily have a temporary password emailed to you. Go to the Log In page and click \"Have you forgotten your login information?\". Enter your real email address into the Email Address field and a temporary password will be emailed to the email address used for the account setup.
<br/><br/>
This process is safe because the password is only emailed to the original owner of the account. There is no way to steal the password by using this feature.";
$ubbt_lang['B_CHANGEPASSWORD'] = "You may change your password any time. On the Forum Navigation island, click \"Edit Profile\". Edit the Password and Verify Password fields and then click \"Submit\" to save the information. (Keep in mind that passwords are case-sensitive.)";
$ubbt_lang['B_IMAGE'] = "In order to add an image to your message or your signature, you must have the image already available on a web server and reachable by a URL. This can be an image on your own personal web page, for example. To place an image within a message, simply use the following Markup Tag:
<br/><br/>
[image]http://www.url_to_image.com/image_name.gif[/image]
<br/><br/>
For example, if you have an image called cateye.gif and its available from your own website at http://www.mywebsite.com/pics, then you would use the following image markup:
<br/><br/>
	[image]http://www.mywebsite.com/pics/cateye.gif[/image]
<br/><br/>
You can do the same for your signature. Click the {$ubbt_lang['MY_HOME']} option found on any page. Then, under the Main Configuration heading, click on \"Personal Information, email, password...\". Look for the Signature box, and enter your desired information, including any images/markup as above.
<br/><br/>
Note: To keep the forums loading quickly for everyone, it is recommended that you do not exceed 35k for your image size.";
$ubbt_lang['B_LIMIT'] = "We ask that you keep your images relatively small. As a rule, please do not exceed 600 x 125 pixels and/or 35k for a signature image. This will ensure that the forums load quickly for all users.";
$ubbt_lang['B_CANTATTACH'] = "No. File attachment has been turned off for these boards.";
$ubbt_lang['B_EDITDISP'] = "Yes, you'll be missing a trick if you fail to take advantage of the versatility offered. There are many aspects of how the Forums are displayed that may be customized. On the Forum Navigation island, click \"Edit Preferences\".
<br/><br/>
You can choose the stylesheet in which you wish to view the forums, how many posts are displayed on each page, whether or not you want to view users' pictures alongside their posts, and much more. Once saved, these become your default settings. You may edit these preferences again at anytime.";
$ubbt_lang['B_SUBJECT'] = "The first post of a given topic establishes the subject by which all subsequent replies will be known. Once there's been a reply, the topic subject cannot be subsequently changed. It's therefore important to get the subject right from the outset. Make it as descriptive and as specific as possible. For example, \"LCD burn-in questions\", is much better than something completely generic, such as \"Newbie needs help!\". Not only is it more likely to elicit a response, but it'll also make it much easier for all posts in the topic to be subsequently located.";
$ubbt_lang['B_ANSWER'] = "One of the key benefits of the discussion board format is that it enables commonly asked questions to be answered once, for the benefit of all. Before posting your question, it is always worth checking to see if it has already been asked - and answered! You can do this via the Search island. Using the Search island, you can perform a quick keyword search, or click on the \"Advanced\" button to search by more specific criteria. Various options are available, both for how the search term is specified and for controlling how many forums you want to search. This is where the specificity of topic subjects is important, making it much easier to locate precisely what it is you're after from a list of search results.";
$ubbt_lang['B_FLASH'] = "It means that you have unread Private Messages. When you hover over this image it should display how many unread Private Messages that you have.";
$ubbt_lang['B_PARTICIPANTS'] = "On the \"New Private Topic\" screen, you can type in a new user then press \"add\" or you can select them from the \"My Buddies\" dropdown. You can add up to the forum maximum of users (this limit will show on the \"New Private Topic\" screen) to the Private Topic.";
$ubbt_lang['B_URL'] = "If the tags are showing up in your text or you're getting a link, but it's to \"http:///\", you're including some unwanted spaces in the syntax. Avoid any intervening spaces, and everything will work fine.";
$ubbt_lang['B_MISTAKE'] = "Users can edit their own posts up to {$config['MAX_EDIT_TIME']} minutes after they are made. Where the change is substantial, it is courteous mark the post as edited so as to alert readers to the changed content. For cosmetic changes, it's better not to do so.";
$ubbt_lang['B_WRONGFORUM'] = "Let the forum Administrator or Moderator know - he/she will be able to move it for you.";
$ubbt_lang['B_HTML'] = "There are 2 ways that this can be configured on a per-forum basis. If HTML is On then you will see <b>HTML is On</b> and you can use normal HTML in your posts. If UBBCode is on you will see <b>UBBCode is On</b>.";
$ubbt_lang['B_UBB'] = "The following tags are available for your use if UBBCode is enabled:<br/><br/>
<strong>Text Formatting</strong><br/>
  <span class=\"standouttext\">
  [b]
  </span>
  text
  <span class=\"standouttext\">
  [/b]
  </span>
         = Makes the given text bold.<br/>

  <span class=\"standouttext\">
  [i]
  </span>
  text
  <span class=\"standouttext\">
  [/i]
  </span>
         = Makes the given text italic.<br/>

  <span class=\"standouttext\">
  [u]
  </span>
  text
  <span class=\"standouttext\">
  [/u]
  </span>
         = Underlines the given text.<br/>

  <span class=\"standouttext\">
  [s]
  </span>
  text
  <span class=\"standouttext\">
  [/s]
  </span>
  = Will post your text with a line through it (strike through).<br/>

  <span class=\"standouttext\">
  [color:red]
  </span>
  text
  <span class=\"standouttext\">
  [/color]
  </span>
  = Makes the given text red.<br/>

  <span class=\"standouttext\">
  [color:#00FF00]
  </span>
  text
  <span class=\"standouttext\">
  [/color]
  </span>
  = Makes the given text green.

  <span class=\"standouttext\">
  [size:20pt]
  </span>
  text
  <span class=\"standouttext\">
  [/size]
  </span>
  = Will change the size of the text to whatever size value you specify.<br/>

  <span class=\"standouttext\">
  [font:Comic Sans MS]
  </span>
  text
  <span class=\"standouttext\">
  [/font]
  </span>
  = Will post your text with the specified font.<br/>

<br/><strong>Links</strong><br/>
  <span class=\"standouttext\">
  [email]
  </span>
  joe@email.com
  <span class=\"standouttext\">
  [/email]
  </span>
  = Makes the given email address clickable.<br/>

  <span class=\"standouttext\">
  [email=
  </span>
  joe@email.com
  <span class=\"standouttext\">
  ]
  </span>
  text
  <span class=\"standouttext\">
  [/email]
  </span>
  = Makes the given email address clickable.<br/>

  <span class=\"standouttext\">
  [url]
  </span>
  link
  <span class=\"standouttext\">
  [/url]</span>
  = Makes the given url into a link.<br/>

  <span class=\"standouttext\">
  [url=
  </span>
  link
  <span class=\"standouttext\">
  ]
  </span>
  title
  <span class=\"standouttext\">
  [/url]</span>
  = Makes the given title into a hyperlink pointing to link.<br/>

  <span class=\"standouttext\">
  [img]
  </span>
  link
  <span class=\"standouttext\">
  [/img]</span>
  = Embeds an image.<br/>

<br/><strong>Code Tags &amp; Highlighting</strong><br/>
  <span class=\"standouttext\">
  [code]
  </span>
  text
  <span class=\"standouttext\">
  [/code]
  </span>
   = Surrounds the given text with pre format tags.<br/>

  <span class=\"standouttext\">
  [php]
  </span>
  text
  <span class=\"standouttext\">
  [/php]
  </span>
  = Passes the text through the PHP Syntax Highlighter<br/>

  <span class=\"standouttext\">
  [highlight]
  </span>
  text
  <span class=\"standouttext\">
  [/highlight]
  </span>
  = Will highlight your text.<br/>

  <span class=\"standouttext\">
  [spoiler]
  </span>
  text
  <span class=\"standouttext\">
  [/spoiler]
  </span>
  = Will wrap your text in a spoiler container. Users must click a button in order to see this text, thus giving them the ability to specify if they want to read the item.<br/>

  <span class=\"standouttext\">
  [spoiler:warning]
  </span>
  text
  <span class=\"standouttext\">
  [/spoiler]
  </span>
  = Will wrap your text in a spoiler container and allow you to specify the warning message displayed. Users must click a button in order to see this text, thus giving them the ability to specify if they want to read the item.<br/>

<br/><strong>Text and Image Alignment</strong><br/>
  <span class=\"standouttext\">
  [align:left|center|right]
  </span>
  text
  <span class=\"standouttext\">
  [/align]
  </span>
  = Will align the text in the direction defined.<br/>

  <span class=\"standouttext\">
  [img:left|center|right]
  </span>
  Image URL
  <span class=\"standouttext\">
  [/img]
  </span>
  = Will allow you to allow text to wrap on the specified side of your image.<br/>

<br/><strong>Misc.</strong><br/>
  <span class=\"standouttext\">
  [list]<br/>
  [*]Item 1<br/>
  [*]Item 1<br/>
  [/list]</span> =  Makes a bullet list. [list=A] or [list=1] will make order/numbered lists. Other options include: circle, i, I, a, A, 1, disc, square.<br/>

  <span class=\"standouttext\">
  [quote]
  </span>
  text
  <span class=\"standouttext\">
  [/quote]
  </span>
  = Surrounds the given text with blockquote and hr's. This UBBCode tag is used for quoting a reply.<br/>

  <span class=\"standouttext\">
  [quote=username]
  </span>
  text
  <span class=\"standouttext\">
  [/quote]
  </span>
  = Surrounds the given text with blockquote and hr's. This UBBCode tag is used for quoting a reply. The username specified will be shown as quoted.";
$ubbt_lang['B_POLL'] = "Putting a poll in your post is simple.";
$ubbt_lang['B_POLLFORMAT'] = "If polls are enabled, start by creating a new post in a forum. Below the body of your post, you will see a text box that allows you to specify how many polls you want to have in your post and the system will guide you through the rest.";
$ubbt_lang['B_MOREPOSTS'] = "You can change the number of posts displayed on each page by editing your display preferences. You can set this to anything between 1 and 99 posts per page. By default, this is set to {$config['TOPICS_PER_PAGE']} posts per page.";
$ubbt_lang['B_REPLY'] = "Quick Reply is made as a \"Quick Response\" block, so you can make a response to a post (or thread) before you forget or as you read them. Quick Reply is meant as a \"no thrills\" response box, as it's just there for a fast/non-formatted response.<br/><br/>

Reply however brings you to a \"Full Response\" page that allows for heavy posting.<br/><br/>

You can also click the \"Full Reply\" button from the Quick Reply box which will forward you (and all of your Quick Reply text) to the Full Reply page.";
$ubbt_lang['B_QUOTE'] = "Quote will quote the users text to the Full Reply page. Quick Quote will quote the users text to the Quick Reply box below the thread.";
$ubbt_lang['B_EDIT'] = "Click the \"My Profile\" link from the \"My Stuff\" dropdown on the Forum Navigation island.";
$ubbt_lang['B_GALLERY'] = "Using Gallery Forums are just like using any other forums... However, you can post images too!<br/><br/>

After you create your post (subject and post, both required) you can click on the \"Image Manager\" link.<br/><br/>

Adding images are as easy as:<br/>
1. Click \"Browse\" and a navigation area will appear that shows your computers files, navigate around to locate the image you'd like to upload. Once located, click on the image and select \"open\"; you can also choose to add a description (note that in v7.2 you do not have the option to change the description once another image is added).<br/>
2. If you wish to add another image, repeat step one; otherwise, select \"done\".<br/><br/>

From here, just press submit, and your new \"Gallery Posting\" should appear for users to comment on your image(s).";
$ubbt_lang['B_ATTACH'] = "When creating a new thread or response, you'll see a \"File Manager\" link on the \"Full Reply\" or \"New Post\" page. When selecting this option you'll receive a popup which will allow you to attach files to your post.<br/><br/>

Steps:<br/>
1. Click \"File Manager\" to bring up the \"Attachment\" window.<br/>
2. Click \"Browse\" to bring up the file browser window; this will allow you to browse your computer for any files or images you wish to upload; please note that you're bound by whatever the \"allowed file type\" setting is for the board.<br/>
3. Click \"open\" on the file you wish to upload.<br/>
4. Enter a description of what the file is (if you want to).<br/>
5. Click \"add file\" to add another file, or \"done\" to close the window and complete your posting.<br/><br/>

Please note that you must enter some text in both the \"subject\" and \"post\" fields when responding otherwise you will receive an error; you cannot just respond with an attachment ;).";
$ubbt_lang['B_SUBSCRIBE'] = "<strong>Subscribing to a Forum</strong><br/>
Enter the Forum and Select \"Add Forum to Watched Forums\" from the \"Forum Options\" dropdown.<br/>

<br/><strong>Subscribing to a Topic</strong><br/>
Enter the Topic and Select \"Add Topic to your Watched Topics\" option from the \"Topic Options\" dropdown.<br/>

<br/><strong>Managing Watch Lists</strong><br/>
Select \"My Watch Lists\" from the \"My Stuff\" dropdown, from here you can select the type of List that you wish to edit and by clicking the \"Edit Watched Topics\" (or \"Edit Watched Forums\" or \"Edit Watched Users\") link you can remove them or toggle the \"Email Notification\" option.<br/>

<br/><strong>Toggling EMailed Watch Lists</strong><br/>
See the above \"Managing Watch Lists\" directions.<br/>

<br/><strong>Toggling the Default \"EMail Watchedlist\" Options</strong><br/>
Select \"My Preferences\" from the \"My Stuff\" dropdown. From here you can manage the \"By default should anything added to your Watch Lists be emailed to you?\" option.";
$ubbt_lang['B_MCONTENT'] = "<strong>EMailing a Post or Thread</strong><br/>
To email a post, simply navigate to the post and select \"email post\" from the bottom set of buttons (near reply, quote, notify, etc).<br/><br/>

From this \"email post\" screen, you can select to mail yourself:<br/>
Just this post<br/>
This post and all replies<br/>
The entire thread<br/>

<br/><strong>EMailing a Private Topic</strong><br/>
When viewing a Private Message, simply click the \"EMail Topic\" button from the bottom set of buttons (near reply, quote, etc).";
$ubbt_lang['B_RSSINFO'] = "<strong>RSS Feeds for Forums</strong><br/>
For forums which have an RSS Feed configured for them, you can enter the forum and select the feed link from the \"Forum Options\" dropdown.<br/>

<br/><strong>My Feeds</strong><br/>
If the administration has enabled the \"My Feeds\" option, you can manage RSS feeds from the \"Feeds\" link in the \"My Stuff\" dropdown in the navigation area.<br/><br/>

From the My Feeds area you can see all of the RSS Feeds available to you, including all of the forums which have individual feeds. You will also be able to retrieve the feeds for your inbox and the global feeds for recent topics. Please note that these may or may not be available based on admin preferences.";
$ubbt_lang['B_UCOLORS'] = "The username colors generally specify a users status. Some select users can can also have special colors signified by the Administration.<br/><br/>

The default user status colors are:<br/>
<span class=\"adminname\">Administration</span><br/>
<span class=\"globalmodname\">Global Moderator</span><br/>
<span class=\"modname\">Moderator</span><br/>
<span class=\"bots\">Search Engine Robot</span>";
$ubbt_lang['B_NPINDICATOR'] = "The numbers in parenthesise indicate how many new topics (or posts) have been made since your last visit to the forums.";
?>