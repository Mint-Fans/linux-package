<?php
$ubbt_lang['NORESULTS'] = "You cannot view poll results until the poll is over.";
$ubbt_lang['COUNTED'] = "You have voted in this poll.";
$ubbt_lang['SUBMIT_VOTE'] = "Submit Vote";
$ubbt_lang['NOTYET'] = "Votes will not be accepted until voting for this poll begins.";
$ubbt_lang['ACCEPTED'] = "Votes accepted starting: ";
$ubbt_lang['UNTIL'] = "until";
$ubbt_lang['CHOOSE_ONE'] = "Only one choice allowed";
$ubbt_lang['CHOOSE_MANY'] = "Multiple choices allowed";
$ubbt_lang['CHOOSE_NUM'] = "%%NUMBER%% choices allowed";
$ubbt_lang['MUSTVOTE'] = "You must vote before you can view the results of this poll.";
$ubbt_lang['VIEWRESULTS'] = "View the results of this poll.";
$ubbt_lang['TOTALVOTES'] = "total votes";
$ubbt_lang['VOTING_ENDS'] = "Voting on this poll ends: %%END%%";
?>