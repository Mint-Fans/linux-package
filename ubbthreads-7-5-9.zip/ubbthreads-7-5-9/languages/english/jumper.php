<?php
$ubbt_lang['NO_JUMP'] = "You must select a forum in which to jump. Please go back and try again.";
?>