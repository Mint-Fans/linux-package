<?php
$ubbt_lang['MY_ADDRESS'] = "Choose a recipient";
$ubbt_lang['CLOSE'] = "close";
$ubbt_lang['CLOSE_X'] = "[x]";
?>