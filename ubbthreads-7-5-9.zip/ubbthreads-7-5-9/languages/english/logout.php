<?php
$ubbt_lang['LOGIN_PROMPT'] = "Please log in.";
$ubbt_lang['LOGIN_PROMPT2'] = "Enter your Username and Password to log in. If you have not yet registered you can";
$ubbt_lang['REG_ONE'] = "register here";
$ubbt_lang['PASSWORD_TEXT'] = "Password";
?>