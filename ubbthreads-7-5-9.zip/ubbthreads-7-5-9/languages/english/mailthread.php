<?php
$ubbt_lang['MAIL_FRIEND'] = "Email posts to a friend";
$ubbt_lang['SENT_FROM1'] = "Email will be sent from: ";
$ubbt_lang['SENT_FROM2'] = "using the name: ";
$ubbt_lang['USE_REAL'] = "Enter an alternate sending name, if desired";
$ubbt_lang['WHAT_EMAIL'] = "Email address to send to (multiple addresses separated by commas)";
$ubbt_lang['SEND_IT'] = "Send it!";
$ubbt_lang['EMAIL_WHAT'] = "What to send:";
$ubbt_lang['EMAIL_1POST'] = "Just this post";
$ubbt_lang['EMAIL_TOEND'] = "This post and all replies";
$ubbt_lang['EMAIL_ENTIRE'] = "The entire thread";
$ubbt_lang['EMAIL_EXTRA'] = "Fill in comments below to be added at front of Email (text only)";
?>