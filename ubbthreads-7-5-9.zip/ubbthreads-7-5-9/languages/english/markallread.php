<?php
$ubbt_lang['MARKALLREAD'] = "Mark All Posts as Read";
$ubbt_lang['CONFIRM_MARK'] = "By clicking on the link below all posts will be marked as read and you will be returned to the main index of the forum.";
?>