<?php
$ubbt_lang['NO_PERM'] = "You do not have permission to access this private message.";
$ubbt_lang['REPLY_HEAD'] = "Add private message to: ";
$ubbt_lang['DELETE_MESS'] = "Delete this Message";
$ubbt_lang['REPLY_MESS'] = "Reply to this Message";
$ubbt_lang['BODY_TEXT'] = "Body of Message";
$ubbt_lang['PREVIEW'] = "I want to preview this message.";
$ubbt_lang['IN_RESPONSE'] = "In response to:";
$ubbt_lang['REMOVED'] = "has removed themself from this topic.";
$ubbt_lang['PM_HOWMANY'] = "%%HOWMANY%% private messages have been processed";
$ubbt_lang['PM_SUBJECT'] = "Messages processed";
$ubbt_lang['PM_RETURN'] = "Return to messages";
$ubbt_lang['TOO_LONG'] = "This topic has reached it's maximum length of %%TOTAL%% posts. You may not add another post to this topic.";
?>