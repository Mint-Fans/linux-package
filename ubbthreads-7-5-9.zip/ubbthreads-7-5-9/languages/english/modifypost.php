<?php
$ubbt_lang['DELETE_THREAD'] = "Delete this topic.";
$ubbt_lang['NO_DELETE_FIRST'] = "Since this post is the first post in a topic and already has replies it may not be deleted.";
$ubbt_lang['DELETE_TIMER'] = "This post may no longer be deleted.";
$ubbt_lang['FILE_TOO_BIG'] = "Files can be no larger than %%ATTACH_SIZE%% bytes.";
$ubbt_lang['FILESALLOWED'] = "You may upload files with the following extension only:";
$ubbt_lang['NO_EDIT'] = "You cannot edit this post.";
$ubbt_lang['PEDIT_DELETE'] = "Delete this post.";
$ubbt_lang['DELETE_CONF'] = "If you are sure you want to do this, click the button below.";
$ubbt_lang['YES_DELETE'] = "Yes, I want to delete this post.";
$ubbt_lang['PEDIT_APPROVE'] = "Approve this post.";
$ubbt_lang['APPROVE_CONF'] = "If you are sure you want to do this, click the button below.";
$ubbt_lang['YES_APPROVE'] = "Yes, I want to approve this post.";
$ubbt_lang['MAKE_STICKY'] = "Make post sticky.";
$ubbt_lang['TEXT_STICKY'] = "This will make this thread always appear on top when sorting by descending date.";
$ubbt_lang['RET_NORM'] = "Return to normal date.";
$ubbt_lang['MODIF_HEAD'] = "The thread has been modified.";
$ubbt_lang['FORUM_RETURN'] = "Return to the forum";
$ubbt_lang['VIEW_POST'] = "View your post";
$ubbt_lang['EDIT_MORE'] = "Edit more.";
$ubbt_lang['PEDIT_CHANGE'] = "Change this post.";
$ubbt_lang['POST_TEXT'] = "Post";
$ubbt_lang['EDITTIME'] = "This post can no longer be edited because the maximum edit time has expired.";
$ubbt_lang['MAX_QUOTE'] = "For readability, you can only quote messages %%QUOTE%% levels deep. Please edit your message and try again.";
?>