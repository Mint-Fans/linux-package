<?php
$ubbt_lang['IMAGE_UPLOAD'] = "Image Upload";
$ubbt_lang['ADDSIG'] = "Add my signature to this post.";
$ubbt_lang['ADDEVENT'] = "List as an event in the calendar on ";
$ubbt_lang['STICKY'] = "Make this topic a sticky topic.";
$ubbt_lang['ANNOUNCE'] = "Make this topic a global announcement.";
$ubbt_lang['ADDTOFAV'] = "Add this topic to my Watched Topics.";
$ubbt_lang['READ_PERM'] = "You are not logged in or you do not have permission to create a new topic here.";
$ubbt_lang['MAKENEW_HEAD'] = "New Post";
$ubbt_lang['MAKENEW_IMAGE'] = "New Image";
$ubbt_lang['FILL_FORM'] = "Posting Form:";
$ubbt_lang['NO_HTML'] = "HTML is disabled.";
$ubbt_lang['YES_HTML'] = "HTML is enabled.";
$ubbt_lang['NO_MARKUP'] = "UBBCode is disabled.";
$ubbt_lang['YES_MARKUP'] = "UBBCode is enabled";
$ubbt_lang['POST_ICON'] = "Post Icon";
$ubbt_lang['POST_TEXT'] = "Post";
$ubbt_lang['POST_DESCRIPTION'] = "Description";
$ubbt_lang['DO_PREVIEW'] = "Preview Post";
$ubbt_lang['FLOODCONTROL'] = "You can only make a post every %%SO_OFTEN%% seconds. Please try again once this time has expired.";
$ubbt_lang['NEWS_IMAGE'] = "News Image:";
$ubbt_lang['LOCK_TOPIC'] = "Lock this topic";
?>