<?php
$ubbt_lang['SEARCH_TIPS'] = "Advanced Search Tips";
$ubbt_lang['AND'] = "Use <b>+keyword</b> for required keywords.";
$ubbt_lang['NOT'] = "Use <b>-keyword</b> to exclude posts with a keyword.";
$ubbt_lang['PHRASE'] = "Use quotes around a phrase to search for a phrase.";
$ubbt_lang['WILD'] = "Use a * at the end of the word to match partial words.";
?>