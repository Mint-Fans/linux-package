<?php
$ubbt_lang['HEAD'] = "Show Events for";
$ubbt_lang['BDAY'] = "Birthday";
$ubbt_lang['EVENT'] = "Event";
$ubbt_lang['TOPIC'] = "Topic";
$ubbt_lang['BY'] = "by";
$ubbt_lang['PRIVATE'] = "Private";
$ubbt_lang['PUBLIC'] = "Public";
?>