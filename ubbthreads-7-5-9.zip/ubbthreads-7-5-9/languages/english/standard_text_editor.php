<?php
$ubbt_lang['AREA_BIGGER'] = "Make textarea bigger";
$ubbt_lang['AREA_SMALLER'] = "Make textarea smaller";
$ubbt_lang['ADJUST_SIZE'] = "Adjust the font size";
$ubbt_lang['CHANGE_TYPE'] = "Change the font type";
$ubbt_lang['ENTERURL'] = "Enter the complete URL for the link you wish to add.";
$ubbt_lang['ENTERURL2'] = "Now enter the title of the webpage you are linking to.";
$ubbt_lang['ENTEREMAIL'] = "Enter the complete email address you wish to add.";
$ubbt_lang['ENTERIMAGE'] = "Enter the complete URL for the image you wish to display.";
$ubbt_lang['ENTERITEM'] = "Enter the new list item. When finished with your list, enter a blank value to close the list.";
$ubbt_lang['ENTERBBCODE'] = "Enter the contents in the format shown below:";
$ubbt_lang['HYPER_ALT'] = "Create a link to a webpage";
$ubbt_lang['EMAIL_ALT'] = "Create a link to an email";
$ubbt_lang['BOLD_ALT'] = "Bold some text";
$ubbt_lang['UNDERLINE_ALT'] = "Underline some text";
$ubbt_lang['STRIKE_ALT'] = "Strikethrough some text";
$ubbt_lang['QUOTE_ALT'] = "Quote some text";
$ubbt_lang['LIST_ALT'] = "Create a list";
$ubbt_lang['IMAGE_ALT'] = "Enter an image";
$ubbt_lang['COLOR_ALT'] = "Color some text";
$ubbt_lang['ITALICS_ALT'] = "Italicize some text";
$ubbt_lang['SMILIES'] = "Smilies";
$ubbt_lang['SPOILER_ALT'] = "[spoiler]Spoiler text here[/spoiler]";
$ubbt_lang['MORE_SMILIES'] = "View more smilies";
$ubbt_lang['NO_COLOR_SELECTED'] = "No color.";
$ubbt_lang['NON_IMAGE_ALT'] = "Insert a non-floating image.";
$ubbt_lang['LEFT_IMAGE_ALT'] = "Insert a left-floating image.";
$ubbt_lang['RIGHT_IMAGE_ALT'] = "Insert a right-floating image.";
$ubbt_lang['CENTER_IMAGE_ALT'] = "Insert a center-floating image.";
$ubbt_lang['BBCODE_ALT'] = "Enter a media tag";
$ubbt_lang['HTML_ALT'] = "[html]...text...[/html]";
$ubbt_lang['SQL_ALT'] = "[sql]...text...[/sql]";
$ubbt_lang['PHP_ALT'] = "[php]...text...[/php]";
$ubbt_lang['CODE_ALT'] = "[code]...text...[/code]";

?>