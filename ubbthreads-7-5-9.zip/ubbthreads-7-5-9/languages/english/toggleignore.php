<?php
$ubbt_lang['NOIGNORE'] = "You cannot ignore an Admin or Moderator.";
$ubbt_lang['CRAZY'] = "You can't ignore yourself!";
$ubbt_lang['IGNORED'] = "User has been ignored.";
$ubbt_lang['IGNORED_BODY'] = "You are now ignoring this user. You will no longer see the body of any of their posts.";
$ubbt_lang['UNIGNORED'] = "User is no longer ignored.";
$ubbt_lang['UNIGNORED_BODY'] = "You are no longer ignoring this user. You will now see their posts again.";
?>