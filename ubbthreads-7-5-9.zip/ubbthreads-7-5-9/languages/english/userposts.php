<?php
$ubbt_lang['TOPIC_TITLE'] = "Title";
$ubbt_lang['TOPIC_FORUM'] = "Forum";
$ubbt_lang['TOPIC_TIME'] = "Post Time";
$ubbt_lang['INVALID_USER_SPECIFIED'] = "That user does not exist.";
$ubbt_lang['TOPIC_PARTICIPATED'] = "Topics Participated In";
$ubbt_lang['TOPIC_PARTICIPATED_2'] = "Topics %%NAME%% has participated in.";
$ubbt_lang['TOPIC_CREATED'] = "Topics Created";
$ubbt_lang['TOPIC_CREATED_2'] = "Topics created by %%NAME%%.";
$ubbt_lang['ALL_POSTS'] = "All Posts";
$ubbt_lang['ALL_POSTS_2'] = "All posts made by %%NAME%%.";
$ubbt_lang['TOPIC_CREATED_NO_RESULTS'] = "This user has made no topics.";
$ubbt_lang['TOPC_PARTICIPATED_NO_RESULTS'] = "This user has participated in no topics.";
$ubbt_lang['ALL_POSTS_NO_RESULTS'] = "This user has made no posts.";
?>