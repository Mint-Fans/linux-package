<?php
$ubbt_lang['POLL_RES'] = "Poll Results";
$ubbt_lang['TOTAL_VOTES'] = "Total Votes";
?>