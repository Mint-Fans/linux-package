<?
$ubbt_lang['WATCHED_TOPIC_TITLE'] = "Watched Topic: %%TITLE%%";
$ubbt_lang['WATCHED_FORUM_TITLE'] = "Watched Forum: %%FORUM%% : %%TITLE%%";
$ubbt_lang['WATCHED_USER_TITLE'] = "Watched User: %%USER%% : %%TITLE%%";
$ubbt_lang['NEW_POST_BOD'] = "posted a new topic at the site: ";
$ubbt_lang['REPLY_BOD'] = "made a new post at the site: ";
?>