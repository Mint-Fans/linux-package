<?php
$ubbt_lang['SHOW_WITH'] = "Show Wrapper with Style ";
$ubbt_lang['CHANGE'] = "Change";
?>