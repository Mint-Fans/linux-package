<?php defined( 'UBB_MAIN_PROGRAM' ) or exit;
//	Script Version 7.5.9

// -------------------------------------------------------------
// Setup the hidden poll variables no matter what step we are on
$pollhidden = "";
for($i=1;$i<=$questions;$i++) {

	// -------------------------------
	// What options for this question?
	$numoptions = get_input("totalchoices","post","int");
	$pollhidden .= <<<EOF
		<input type="hidden" name="totalchoices" value="$numoptions" />
EOF;

	for ($x=1;$x<=$numoptions;$x++) {
		$option = get_input("option-$x","post");
		$option = str_replace("\"","&quot;",$option);

		$pollhidden .= <<<EOF
			<input type="hidden" name="option-$x" value="$option" />
EOF;

	}
	$pname = get_input("name","post");
	$pname = preg_replace("/\"/","&quot;",$pname);
	$pname = str_replace(array('<', '>'), array('&lt;', '&gt;'), $pname);
	$pchoices = get_input("totalchoices","post");
	$ptype = get_input("type","post");
	$pmulti = get_input("multi","post");

	$pollhidden .= <<<EOF
		<input type="hidden" name="name" value="$pname" />
		<input type="hidden" name="totalchoices" value="$pchoices" />
		<input type="hidden" name="type" value="$ptype" />
		<input type="hidden" name="multi" value="$pmulti" />
EOF;
}

// Smarty variables needed in each step:
$smarty_data['stylesheet'] = $stylesheet;
$smarty_data['id'] = $id;
$smarty_data['questions'] = $questions;
$smarty_data['day'] = $day;
$smarty_data['month'] = $month;
$smarty_data['year'] = $year;
$smarty_data['hour'] = $hour;
$smarty_data['min'] = $min;
$smarty_data['ampm'] = $ampm;
$smarty_data['stopday'] = $stopday;
$smarty_data['stopmonth'] = $stopmonth;
$smarty_data['stopyear'] = $stopyear;
$smarty_data['stophour'] = $stophour;
$smarty_data['stopmin'] = $stopmin;
$smarty_data['stopampm'] = $stopampm;
$smarty_data['enablestart'] = $enablestart;
$smarty_data['enablestop'] = $enablestop;
$smarty_data['noview'] = $noview;
$smarty_data['mustvote'] = $mustvote;
$smarty_data['pollhidden'] = $pollhidden;

// ----------------
// Step 1 of a poll
if ($addpoll == 1) {

	$smarty_data['pollarray'] = $pollarray;

	return array(
		"header" => array (
			"title" => $ubbt_lang['NEW_POLL'],
			"refresh" => 0,
			"user" => $user,
			"Board" => $Board,
			"Category" => $cat_id,
			"forum_parent" => $forum_parent,
			"bypass" => 0,
			"onload" => "",
		),
		"template" => "addpost_newpoll1",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

// ----------------
// Step 2 of a poll
if ($addpoll == 2) {

	$pname = get_input("name","post");
	$pname = str_replace(array('<', '>'), array('&lt;', '&gt;'), $pname);
	$pchoices = get_input("totalchoices","post");
	$ptype = get_input("type","post");
	$pmulti = get_input("multi","post");

	for ($x=1;$x<=$pchoices;$x++) {
		$option = get_input("option-$x","post");
		$option = str_replace("\"","&quot;",$option);
		$pollarray[$x]['option'] = $option;
	}

	if (!$pname || !$pchoices || !$ptype ) {
		$html->not_right_bare("{$ubbt_lang['ALL_FIELDS']}");
	}
	$pollarray['name'] = $pname;

	if ($ptype == "one") {
		$pollarray['choices'] = $ubbt_lang['CHOOSE_ONE'];
	}
	if ($ptype == "many") {
		$pollarray['choices'] = $ubbt_lang['CHOOSE_MANY'];
	}
	if ($ptype == "multi") {
		$pollarray['choices'] = $ubbt_lang['CHOOSE_NUM'] . " $pmulti " .  $ubbt_lang['CHECKBOX'];
	}
	$pollarray['options'] = $pchoices;

	$smarty_data['pname'] = $pname;
	$smarty_data['pchoices'] = $pchoices;
	$smarty_data['ptype'] = $ptype;
	$smarty_data['pmulti'] = $pmulti;
	$smarty_data['FormSubject'] = $FormSubject;
	$smarty_data['FormBody'] = $FormBody;
	$smarty_data['pollarray'] = $pollarray;
	$smarty_data['stylesheet'] = $stylesheet;
	$smarty_data['id'] = $id;


	return array(
		"header" => array (
			"title" => $ubbt_lang['NEW_POLL'],
			"refresh" => 0,
			"user" => $user,
			"Board" => $Board,
			"Category" => $cat_id,
			"forum_parent" => $forum_parent,
			"bypass" => 0,
			"onload" => "",
		),
		"template" => "addpost_newpoll2",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

// ----------------
// Step 3 of a poll
if ($addpoll == 3) {

	$checkenablestart = ""; $checkenablestop = ""; $checknoview = ""; $checkmustvote = "";
	if ($enablestart) {
		$checkenablestart = "checked = \"checked\"";
	}
	if ($enablestop) {
		$checkenablestop = "checked = \"checked\"";
	}
	if ($noview) {
		$checknoview = "checked = \"checked\"";
	}
	if ($mustvote) {
		$checkmustvote = "checked = \"checked\"";
	}

	// -------------------------------
	// What options for this question?
	$numoptions = get_input("totalchoices","post");

	for ($x=1;$x<=$numoptions;$x++) {
		$option = get_input("option-$x","post");
		$option = str_replace("\"","&quot;",$option);
		if ((!$option) && ($option != "0")) {
			$html -> not_right_bare("{$ubbt_lang['ALL_FIELDS']}");
		}
	}
	$pname = get_input("name","post");
	$pname = str_replace(array('<', '>'), array('&lt;', '&gt;'), $pname);
	$pchoices = get_input("totalchoices","post");
	$ptype = get_input("type","post");
	$pmulti = get_input("multi","post");

	if (!$pname || !$pchoices || !$ptype ) {
		$html -> not_right_bare("{$ubbt_lang['ALL_FIELDS']}");
	}

	$pollarray['name'] = "$pname";

	if ($ptype == "one") {
		$pollarray['choices'] = $ubbt_lang['CHOOSE_ONE'];
	}
	if ($ptype == "many") {
		$pollarray['choices'] = $ubbt_lang['CHOOSE_MANY'];
	}
	if ($ptype == "multi") {
		$pollarray['choices'] = $ubbt_lang['CHOOSE_NUM'] . "$pmulti" .  $ubbt_lang['CHECKBOX'];
	}
	$pollarray['options'] = $pchoices;

	$currdate = date("d m Y h i A");
	list ($aday,$amonth,$ayear,$ahour,$amin,$aampm) = preg_split("# #",$currdate);

	$timeselection = <<<EOF
		<select name="day" class="form-select">
EOF;
	$timeselection2 = <<<EOF
		<select name="stopday" class="form-select">
EOF;
	for ($i=1;$i<=31;$i++) {

		if (!$day) { $day = $aday; }
		if (!$stopday) { $stopday = $aday; }

		if ($i<10) { $i = "0$i"; }

		// Start time
		$selected = "";
		if ($day == $i) {
			$selected = "selected=\"selected\"";
		}
		$timeselection .="<option $selected>$i</option>";

		// Stop time
		$selected = "";
		if ($stopday == $i) {
			$selected = "selected=\"selected\"";
		}
		$timeselection2 .="<option $selected>$i</option>";

	}

	$timeselection .= <<<EOF
		</select>
		<select name="month" class="form-select">
EOF;
	$timeselection2 .= <<<EOF
		</select>
		<select name="stopmonth" class="form-select">
EOF;

	for ($i=1;$i<=12;$i++) {

		if (!$month) { $month = $amonth; }
		if (!$stopmonth) { $stopmonth = $amonth; }

		if ($i<10) { $i = "0$i"; }

		// Start
		$selected = "";
		if ($month == $i) {
			$selected = "selected=\"selected\"";
		}
		$thismonth = "MONTH$i";
		$timeselection .= "<option value=\"$i\" $selected>{$ubbt_lang[$thismonth]}</option>";

		// Stop
		$selected = "";
		if ($stopmonth == $i) {
			$selected = "selected=\"selected\"";
		}
		$thismonth = "MONTH$i";
		$timeselection2 .= "<option value=\"$i\" $selected>{$ubbt_lang[$thismonth]}</option>";

	}

	$timeselection .= <<<EOF
		</select>
		<select name="year" class="form-select">
EOF;
	$timeselection2 .= <<<EOF
		</select>
		<select name="stopyear" class="form-select">
EOF;

	for ($i=$ayear;$i<=($ayear+10);$i++) {
		if (!$year) { $year = $ayear; }
		if (!$stopyear) { $stopyear = $ayear; }

		// Start
		$selected = "";
		if ($i == $year) { $selected = "selected = \"selected\""; }
		$timeselection .= "<option $selected>$i</option>";

		// Stop
		$selected = "";
		if ($i == $stopyear) { $selected = "selected = \"selected\""; }
		$timeselection2 .= "<option $selected>$i</option>";

	}

	$timeselection .= <<<EOF
		</select>
		<select name="hour" class="form-select">
EOF;
	$timeselection2 .= <<<EOF
		</select>
		<select name="stophour" class="form-select">
EOF;

	for($i=1;$i<=12;$i++) {

		if (!$hour) { $hour = $ahour; }
		if (!$stophour) { $stophour = $ahour; }

		if ($i < 10) { $i = "0$i"; }

		// Start
		$selected = "";
		if ($i == $hour) {
			$selected = "selected=\"selected\"";
		}
		$timeselection .= "<option $selected>$i</option>";

		// Stop
		$selected = "";
		if ($i == $stophour) {
			$selected = "selected=\"selected\"";
		}
		$timeselection2 .= "<option $selected>$i</option>";
	}

	$timeselection .= <<<EOF
		</select>
		<select name="min" class="form-select">
EOF;
	$timeselection2 .= <<<EOF
		</select>
		<select name="stopmin" class="form-select">
EOF;

	for ($i=0;$i<=59;$i++) {

		if (!$min) { $min = $amin; }
		if (!$stopmin) { $stopmin = $amin; }

		if ($i < 10) { $i = "0$i"; }

		// Start
		$selected = "";
		if ($i == $min) {
			$selected = "selected=\"selected\"";
		}
		$timeselection .= "<option $selected>$i</option>";

		// Stop
		$selected = "";
		if ($i == $stopmin) {
			$selected = "selected=\"selected\"";
		}
		$timeselection2 .= "<option $selected>$i</option>";
	}

	// Start
	if (!$ampm) { $ampm = $aampm; }
	if (!$stopampm) { $stopampm = $aampm; }

	$AM = ""; $PM = "";
	${$ampm} = "selected=\"selected\"";
	$timeselection .= <<<EOF
		</select>
		<select name="ampm" class="form-select">
		<option $AM>{$ubbt_lang['AM']}</option>
		<option $PM>{$ubbt_lang['PM']}</option>
EOF;

	// Stop
	$AM = ""; $PM = "";
	${$stopampm} = "selected=\"selected\"";

	$timeselection2 .= <<<EOF
		</select>
		<select name="stopampm" class="form-select">
		<option $AM>{$ubbt_lang['AM']}</option>
		<option $PM>{$ubbt_lang['PM']}</option>
EOF;

	$smarty_data['checkenablestart'] = $checkenablestart;
	$smarty_data['timeselection'] = $timeselection;
	$smarty_data['checkenablestop'] = $checkenablestop;
	$smarty_data['timeselection2'] = $timeselection2;
	$smarty_data['checknoview'] = $checknoview;
	$smarty_data['checkmustvote'] = $checkmustvote;
	$smarty_data['pollarray'] = $pollarray;
	$smarty_data['pname'] = $pname;
	$smarty_data['pchoices'] = $pchoices;
	$smarty_data['ptype'] = $ptype;
	$smarty_data['pmulti'] = $pmulti;
	$smarty_data['stylesheet'] = $stylesheet;
	$smarty_data['id'] = $id;

	return array(
		"header" => array (
			"title" => $ubbt_lang['NEW_POLL'],
			"refresh" => 0,
			"user" => $user,
			"Board" => $Board,
			"Category" => $cat_id,
			"forum_parent" => $forum_parent,
			"bypass" => 0,
			"onload" => "",
		),
		"template" => "addpost_newpoll3",
		"data" => & $smarty_data,
		"footer" => true,
		"location" => "",
	);
}

?>
