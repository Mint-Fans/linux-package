<?php
//	Script Version 7.5.9

function rebuild_signatures($users) {
	global $config, $dbh, $html;

	$select_query = "
		SELECT	USER_DEFAULT_SIGNATURE, USER_ID
		FROM	{$config['TABLE_PREFIX']}USER_PROFILE
		WHERE	USER_ID in ( ? )
	";

	$update_query = "
		UPDATE	{$config['TABLE_PREFIX']}USER_PROFILE
		SET	USER_SIGNATURE = ?
		WHERE	USER_ID = ?
	";

	$sth = $dbh->do_placeholder_query($select_query, array($users), __LINE__, __FILE__);

	while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
		$sig = $html->do_markup($result['USER_DEFAULT_SIGNATURE'], "signature", "markup");

		if ($config['DO_CENSOR']) {
			$sig = $html->do_censor($sig);
		}

		$dbh->do_placeholder_query($update_query, array($sig, $result['USER_ID']), __LINE__, __FILE__);
	}
}

function rebuild_private_messages($privates) {
	global $config, $dbh, $html;

	$select_query = "
		SELECT	POST_ID, POST_DEFAULT_BODY
		FROM	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
		WHERE	POST_ID in ( ? )
	";

	$update_query = "
		UPDATE	{$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
		SET	POST_BODY = ?
		WHERE	POST_ID = ?
	";

	$sth = $dbh->do_placeholder_query($select_query, array($privates), __LINE__, __FILE__);

	while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
		$post = $html->do_markup($result['POST_DEFAULT_BODY'], "post", "markup");

		if ($config['DO_CENSOR']) {
			$post = $html->do_censor($post);
		}

		$dbh->do_placeholder_query($update_query, array($post, $result['POST_ID']), __LINE__, __FILE__);
	}
}

function rebuild_posts($posts) {
	global $config, $dbh, $html;

	$select_query = "
		SELECT	POST_ID, POST_DEFAULT_BODY, POST_MARKUP_TYPE
		FROM	{$config['TABLE_PREFIX']}POSTS
		WHERE	POST_ID in ( ? )
	";

	$update_query = "
		UPDATE	{$config['TABLE_PREFIX']}POSTS
		SET	POST_BODY = ?
		WHERE	POST_ID = ?
	";

	$sth = $dbh->do_placeholder_query($select_query, array($posts), __LINE__, __FILE__);

	$last_id = 0;
	while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
		$post = $html->do_markup($result['POST_DEFAULT_BODY'], "post", $result['POST_MARKUP_TYPE']);

		if ($config['DO_CENSOR']) {
			$post = $html->do_censor($post);
		}

		$dbh->do_placeholder_query($update_query, array($post, $result['POST_ID']), __LINE__, __FILE__);
	}
}

function rebuild_user_postcounts($users) {
	global $config, $dbh, $html;

	$select_query = "
		SELECT	COUNT(POST_ID) AS COUNT, USER_ID
		FROM	{$config['TABLE_PREFIX']}POSTS
		WHERE	USER_ID in ( ? )
		GROUP BY USER_ID
	";

	$update_query = "
		UPDATE	{$config['TABLE_PREFIX']}USER_PROFILE
		SET	USER_TOTAL_POSTS = ?
		WHERE	USER_ID = ?
	";

	$sth = $dbh->do_placeholder_query($select_query, array($users), __LINE__, __FILE__);

	while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
		$dbh->do_placeholder_query($update_query, array($result['COUNT'], $result['USER_ID']), __LINE__, __FILE__);
	}
}

function prune_empty_private_topics($private_topics) {
	global $config, $dbh, $html;

	// We know if we were called the array has good shit, so just do it baby
	for ($i=0; $i<count($private_topics); $i++) {
		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_TOPICS
			WHERE TOPIC_ID = ?
		";

		$dbh->do_placeholder_query($query, array($private_topics[$i]), __LINE__, __FILE__);

		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_POSTS
			WHERE TOPIC_ID = ?
		";

		$dbh->do_placeholder_query($query, array($private_topics[$i]), __LINE__, __FILE__);

		$query = "
			DELETE FROM {$config['TABLE_PREFIX']}PRIVATE_MESSAGE_USERS
			WHERE TOPIC_ID = ?
		";

		$dbh->do_placeholder_query($query, array($private_topics[$i]), __LINE__, __FILE__);
	}
}

function rebuild_topics($topics) {
	foreach ($topics as $topic) {
		rebuild_topic($topic);
	}
}

function rebuild_forums($forums) {
	foreach ($forums as $forum) {
		rebuild_forum($forum);
	}
}

function rebuild_shouts($shouts) {
	global $config, $dbh;

	$select_query = "
		SELECT	SHOUT_ID, SHOUT_TEXT
		FROM	{$config['TABLE_PREFIX']}SHOUT_BOX
		WHERE	SHOUT_ID in ( ? )
	";

	$update_query = "
		UPDATE	{$config['TABLE_PREFIX']}SHOUT_BOX
		SET	SHOUT_TEXT = ?
		WHERE	SHOUT_ID = ?
	";

	$sth = $dbh->do_placeholder_query($select_query, array($posts), __LINE__, __FILE__);

	$last_id = 0;
	while ($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
		$result['SHOUT_TEXT'] = str_replace('%%GRAEMLIN_URL%%', '<<GRAEMLIN_URL>>', $result['SHOUT_TEXT']);
		$result['SHOUT_TEXT'] = str_replace("{$config['BASE_URL']}/images/", '', $result['SHOUT_TEXT']);
		$post = $html->do_markup($result['SHOUT_TEXT'], "shoutbox", "markup");

		if ($config['DO_CENSOR']) {
			$post = $html->do_censor($post);
		}

		$dbh->do_placeholder_query($update_query, array($post, $result['SHOUT_ID']), __LINE__, __FILE__);
	}
}

function rebuild_topic($topic) {
	global $config, $dbh;

	// Get total # of replies
	$query = "
		SELECT	COUNT(POST_ID) AS COUNT
		FROM	{$config['TABLE_PREFIX']}POSTS
		WHERE	TOPIC_ID = ?
	";

	$sth = $dbh->do_placeholder_query($query, array($topic), __LINE__, __FILE__);
	$tmp = $dbh->fetch_array($sth, MYSQL_ASSOC);
	$replies = $tmp['COUNT'];
	$replies--;

	$query = "
		SELECT	p.USER_ID, p.POST_ID, p.POST_POSTED_TIME, p.POST_BODY, p.POST_SUBJECT, p.POST_ICON,
			p.POST_POSTER_NAME, u.USER_DISPLAY_NAME
		FROM 	{$config['TABLE_PREFIX']}POSTS as p,
			{$config['TABLE_PREFIX']}USERS as u
		WHERE	p.TOPIC_ID = ? AND p.POST_IS_APPROVED = '1' AND
			p.USER_ID = u.USER_ID
		ORDER BY p.POST_ID DESC
		LIMIT 1
	";

	$sth = $dbh->do_placeholder_query($query, array($topic), __LINE__, __FILE__);
	$result = $dbh->fetch_array($sth, MYSQL_ASSOC);

	if (!($result['USER_ID'] > 1)) {
		$result['USER_DISPLAY_NAME'] = $result['POST_POSTER_NAME'];
	}

	$query_vars = array(
		array_get($result, 'USER_ID', 0),
		$result['USER_DISPLAY_NAME'],
		array_get($result, 'POST_ID', 0),
		array_get($result, 'POST_POSTED_TIME', 0),
		$replies,
		$topic
	);

	$query = "
		UPDATE	{$config['TABLE_PREFIX']}TOPICS
		SET	TOPIC_LAST_POSTER_ID = ? ,
			TOPIC_LAST_POSTER_NAME = ? ,
			TOPIC_LAST_POST_ID  = ? ,
			TOPIC_LAST_REPLY_TIME = ? ,
			TOPIC_REPLIES = ?
		WHERE	TOPIC_ID = ?
	";

	$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
}

function rebuild_forum($forum) {
	global $config, $dbh;

	$forums = array();
	if ($forum === "all") {
		$query = "
			select FORUM_ID
			from {$config['TABLE_PREFIX']}FORUMS
		";

		$sth = $dbh->do_query($query, __LINE__, __FILE__);

		while($result = $dbh->fetch_array($sth, MYSQL_ASSOC)) {
			$forums[] = $result['FORUM_ID'];
		}
	} else {
		$forums[] = $forum;
	}

	foreach($forums as $forum_id) {
    $query = "
      select TOPIC_ID
      from {$config['TABLE_PREFIX']}ANNOUNCEMENTS
      where FORUM_ID = ?
    ";
    $sth = $dbh->do_placeholder_query($query,array($forum_id),__LINE__,__FILE__);
    while(list($tid) = $dbh->fetch_array($sth)) {
      $query = "
        select FORUM_ID,TOPIC_IS_STICKY
        from {$config['TABLE_PREFIX']}TOPICS
        where TOPIC_ID = ?
      ";
      $sti = $dbh->do_placeholder_query($query,array($tid),__LINE__,__FILE__);
      list ($fid,$sticky) = $dbh->fetch_array($sti);
      if ($fid != $forum_id && $sticky == 1) {
        $query = "
          delete from {$config['TABLE_PREFIX']}ANNOUNCEMENTS
          where FORUM_ID = ?
          and TOPIC_ID = ?
        ";
        $dbh->do_placeholder_query($query,array($fid,$tid),__LINE__,__FILE__);
        $query = "
          update {$config['TABLE_PREFIX']}ANNOUNCEMENTS
          set FORUM_ID = ?
          where TOPIC_ID = ?
        ";
        $dbh->do_placeholder_query($query,array($fid,$tid),__LINE__,__FILE__);
      }
      if ($sticky == 0) {
        $query = "
          delete from {$config['TABLE_PREFIX']}ANNOUNCEMENTS
          where FORUM_ID = ?
          and TOPIC_ID = ?
        ";
        $dbh->do_placeholder_query($query,array($fid,$tid),__LINE__,__FILE__);
      }
    }
		$query = "
			SELECT	COUNT(TOPIC_ID) AS TOPICS, SUM(TOPIC_REPLIES) AS REPLIES
			FROM	{$config['TABLE_PREFIX']}TOPICS
			WHERE	FORUM_ID = ? AND TOPIC_IS_APPROVED = 1
		";

		$sth = $dbh->do_placeholder_query($query, array($forum_id), __LINE__, __FILE__);
		$tmp_res = $dbh->fetch_array($sth, MYSQL_ASSOC);
		$total_topics = ($tmp_res['TOPICS'] === null) ? 0 : $tmp_res['TOPICS'];
		$total_posts = ($tmp_res['REPLIES'] === null) ? 0 : $tmp_res['REPLIES'];

		$total_posts = $total_posts + $total_topics;

		$query = "
			SELECT	TOPIC_LAST_POSTER_ID, TOPIC_ID, TOPIC_LAST_POST_ID, TOPIC_LAST_REPLY_TIME, TOPIC_LAST_POSTER_NAME
			FROM	{$config['TABLE_PREFIX']}TOPICS
			WHERE	FORUM_ID = ? AND TOPIC_IS_APPROVED = '1'
			ORDER BY TOPIC_LAST_REPLY_TIME DESC
			LIMIT 1
		";
		$sth = $dbh->do_placeholder_query($query, array($forum_id), __LINE__, __FILE__);

		$tmp_res = $dbh->fetch_array($sth, MYSQL_ASSOC);



		if (!$tmp_res) {
			$tmp_res = array(
				'TOPIC_LAST_POSTER_ID' => 0,
				'TOPIC_ID' => 0,
				'TOPIC_LAST_POST_ID' => 0,
				'TOPIC_LAST_REPLY_TIME' => 0,
				'TOPIC_LAST_POSTER_NAME' => "",
				'POST_SUBJECT' => "",
				'POST_ICON' => ""
			);
		} else {
			$query = "
				SELECT	POST_SUBJECT, POST_ICON
				FROM	{$config['TABLE_PREFIX']}POSTS
				WHERE	TOPIC_ID = ?
				ORDER BY POST_ID DESC
				LIMIT 1
			";

			$sth = $dbh->do_placeholder_query($query, array($tmp_res['TOPIC_ID']), __LINE__, __FILE__);
			$tmp_res = array_merge($tmp_res, $dbh->fetch_array($sth, MYSQL_ASSOC));
		}


		if (!$tmp_res['TOPIC_LAST_POSTER_ID']) $tmp_res['TOPIC_LAST_POSTER_ID'] = 0;
		if (!$tmp_res['TOPIC_ID']) $tmp_res['TOPIC_ID'] = 0;
		if (!$tmp_res['TOPIC_ID']) $tmp_res['TOPIC_ID'] = 0;

		$query_vars = array(
			$tmp_res['TOPIC_LAST_POSTER_ID'],
			$tmp_res['TOPIC_ID'],
			$tmp_res['TOPIC_LAST_POST_ID'],
			$tmp_res['TOPIC_LAST_REPLY_TIME'],
			$tmp_res['TOPIC_LAST_POSTER_NAME'],
			$tmp_res['POST_SUBJECT'],
			$tmp_res['POST_ICON'],
			$total_topics,
			$total_posts,
			$forum_id
		);

		$query = "
			UPDATE	{$config['TABLE_PREFIX']}FORUMS
			SET	FORUM_LAST_POSTER_ID = ? ,
				FORUM_LAST_TOPIC_ID = ? ,
				FORUM_LAST_POST_ID = ? ,
				FORUM_LAST_POST_TIME = ? ,
				FORUM_LAST_POSTER_NAME = ? ,
				FORUM_LAST_POST_SUBJECT = ? ,
				FORUM_LAST_POST_ICON = ? ,
				FORUM_TOPICS = ? ,
				FORUM_POSTS = ?
			WHERE	FORUM_ID = ?
		";
		$dbh->do_placeholder_query($query, $query_vars, __LINE__, __FILE__);
	}
}

?>
